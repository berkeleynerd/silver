from pathlib import Path
import json,hashlib,tarfile,ast,shutil
REPO=Path('/home/canto/src/github.com/berkeleynerd/silver/tmp/retained-tool-capacity');BASE=REPO/'docs/evidence';ROOT=Path('/home/canto/src/github.com/berkeleynerd/silver/tmp/wfs-20261020');OLD=Path('/tmp/silver-producer-fixed-tail-20261018')
assert not ROOT.exists();ROOT.mkdir()
def identity(p):
 b=Path(p).read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
with tarfile.open(BASE/'retained-producer-fixed-tail-20261018/observations.tar.gz') as fixed,tarfile.open(BASE/'retained-why-session-save-state-20261019/capture.tar.gz') as state:
 oldplan=json.loads(fixed.extractfile('plan.json').read());sp=json.loads(state.extractfile('plan.json').read())
 # Never silently refresh an installed/captured input that no longer matches.
 for path,row in oldplan['file_identities'].items():assert identity(path)==row,('old input changed',path)
 plan=json.loads(json.dumps(oldplan).replace(str(OLD),str(ROOT)))
 plan['inputs']=[c for c in plan['inputs'] if c['name']!='input_is_valid']
 for member in fixed.getmembers():
  if member.isfile() and member.name.startswith('overlay/'):
   out=ROOT/member.name;out.parent.mkdir(parents=True,exist_ok=True)
   raw=fixed.extractfile(member).read();out.write_bytes(raw.replace(str(OLD).encode(),str(ROOT).encode()))
 for case in plan['inputs']:
  cwd=Path(case['cwd']);cwd.mkdir();(cwd/'temp').mkdir()
  assert len(case['server']['socket'].encode())<108
  for name in [case['argv'][-1],'why3.conf']:
   data=fixed.extractfile(case['name']+'/'+name).read()
   (cwd/name).write_bytes(data if name.endswith('.gnat-json') else data.replace(str(OLD).encode(),str(ROOT).encode()))
 for name in ['run.py','driver-resolution.json']:
  (ROOT/name).write_bytes(fixed.extractfile(name).read().replace(str(OLD).encode(),str(ROOT).encode()))
 for name in ['session_observer.py','snapshot-observer.py','table-observer.py']:
  data=state.extractfile(name).read()
  if name=='snapshot-observer.py':data=data.replace(b'exact stopped first Input_Is_Valid/cvc5 inline entry',b'exact stopped fixed-library registration endpoint')
  (ROOT/name).write_bytes(data)
 for k in ['session_observer','shared_observer','table_observer']:plan[k]=sp[k]
 plan['session_observer']['scope']='Complete raw-task session forest and retained helper roots at fixed process registration; no numeric universal capacity claim'
 probe=fixed.extractfile('probe.py').read().decode().replace(str(OLD),str(ROOT))
 # Snapshot protected endpoint before observing it. Target remains stopped throughout.
 marker="    SUMMARY['completed']=True;save()";assert probe.count(marker)==1
 probe=probe.replace(marker,"    capture_fixed_session()\n    SUMMARY['completed']=True;save()")
 observer=state.extractfile('entry-observer.py').read().decode();a=observer.index('def raw_graph(');b=observer.index('class Preparation(',a)
 probe+='\n'+observer[a:b]+'\n'+'''# New endpoint observer: definitions only until the final registration stop.
import importlib.util
_spec=importlib.util.spec_from_file_location('fixed_session_observer',ROOT/'session_observer.py')
_session_module=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_session_module)
def capture_fixed_session():
    global data
    # Activate durable all-read logging only at the stopped endpoint.
    exec(compile((ROOT/'snapshot-observer.py').read_text(),str(ROOT/'snapshot-observer.py'),'exec'),globals())
    exec(compile((ROOT/'table-observer.py').read_text(),str(ROOT/'table-observer.py'),'exec'),globals())
    checks={}
    for name,spec in PLAN['session_observer']['symbols'].items():
        ptr=address(name);checks[name]={'address':ptr,'elf_value':spec['elf_value']}
        if 'code_hex' in spec:
            got=data(ptr,len(bytes.fromhex(spec['code_hex']))).hex()
            assert got==spec['code_hex'],('session root code mismatch',name)
            checks[name]['code_hex']=got
    bias=address('camlWhy3__Ident')-PLAN['session_observer']['ident_elf_value']
    assert all(row['address']==bias+row['elf_value'] for row in checks.values())
    (OUT/'session-symbols.json').write_text(json.dumps({'load_bias':bias,'checks':checks},indent=2)+'\\n')
    session=_session_module.SessionCapture(data,address,OUT,PLAN['session_observer']['limits'])
    try:
        roots=session.capture_roots();assert roots['complete'],roots
        result=session.capture_session();assert result['complete'],result
        helpers=session.capture_helpers();assert helpers['complete'],helpers
        SUMMARY['fixed_session']={'complete':True,'identity':identity(OUT/'session-result.json'),
            'case':CASE['name'],'endpoint':PLAN['endpoint']['symbol']}
        save()
    finally:session.close()
    capture_identifier()
    table_roots=read_table_state()
    graph=raw_graph(table_roots)
    graph['scope']='Every retained Hsdecl representative reachable payload at registration, conservative selectable superset'
    (OUT/'representative-graph.json').write_text(json.dumps(graph,sort_keys=True)+'\\n')
    aux=capture_auxiliary();assert aux['complete'],aux
    SUMMARY['representative_graph']={'identity':identity(OUT/'representative-graph.json'),'roots':len(table_roots),'blocks':len(graph['blocks'])}
    save();_memory_log.close()
'''
 (ROOT/'probe.py').write_text(probe)
 plan['scope']='Four missing fixed-library typed forest/representative snapshots at pre-scheduling registration; Input_Is_Valid retains prior PID97103 state subject to source-domain preservation join'
 plan['retained_Input_Is_Valid']={'managed_run':'20261019T000304-fcb988ec2c03','pid':97103,'packet':'docs/evidence/retained-why-session-save-state-20261019'}
 plan['parent_snapshot']={'packet':'docs/evidence/retained-producer-fixed-tail-20261018','plan_sha256':hashlib.sha256(fixed.extractfile('plan.json').read()).hexdigest()}
 plan['file_identities']={}
 for path,row in oldplan['file_identities'].items():
  new=path.replace(str(OLD),str(ROOT))
  if path.startswith(str(OLD)):
   if Path(new).is_file():plan['file_identities'][new]=identity(new)
  else:plan['file_identities'][path]=row
 for path in ROOT.rglob('*'):
  if path.is_file():plan['file_identities'][str(path)]=identity(path)
 (ROOT/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
 for path in ROOT.glob('*.py'):ast.parse(path.read_text(),filename=str(path))
 print('Prepared',ROOT,'cases',[c['name'] for c in plan['inputs']],'inputs',len(plan['file_identities']))
 print('GDB',plan['gdbroot'],'retained input hashes all matched; no native process launched')
