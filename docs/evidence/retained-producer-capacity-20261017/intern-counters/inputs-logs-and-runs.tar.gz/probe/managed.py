from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent;case=sys.argv[1]
repo=Path('/home/canto/src/github.com/berkeleynerd/silver')
cmd=['python3',str(repo/'scripts/dev.py'),'tool','--task','#119','--jobs','1','--reason','Read missing GNATCOLL intern counters and per-symbol lengths for '+case+'; retained exact-source ALIs, read-only debugger, false backend, no solver or validation rerun','--workspace',str(root)]
inputs=[root/'prepare.py',root/'pool_reader.py',root/'run_case.py',root/'managed.py',root/'inputs.json',root/'naming.adc',root/'static-layout.gdb',root/'static-layout.txt',root/case/'options.json',root/case/'invocation.json',root/case/'object-paths.txt']
inputs+=sorted((root/'library-src').glob('*'))+sorted((root/'library-obj').glob('*.ali'))+sorted((root/case).glob('*.adb'))+sorted((root/case/'obj').glob('*.ali'))
inputs+=[repo/'.tools/linux-x86_64/alire/cache/releases/gnatprove_16.1.0_82528bef/libexec/spark/bin/gnat2why',Path('/tmp/silver-capacity-debugger-20261018/root/usr/bin/gdb')]
for x in inputs:cmd+=['--input',str(x)]
cmd+=['--','python3',str(root/'run_case.py'),case]
raise SystemExit(subprocess.call(cmd,cwd=repo))
