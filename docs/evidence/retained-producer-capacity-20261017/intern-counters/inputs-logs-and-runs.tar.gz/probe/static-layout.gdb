set pagination off
set auto-load off
set debuginfod enabled off
set language c
ptype /o gnatcoll__symbols__symbol_table_record
ptype /o gnatcoll__symbols__string_htable__set
ptype /o gnatcoll__symbols__string_htable__ht_types__hash_table_type
info address why__gen__names__why3_symbol_alloc
info address common_containers__intern_strings
python
import gdb,json
T=gdb.lookup_type('gnatcoll__symbols__symbol_table_record').strip_typedefs()
layout={f.name:[f.bitpos//8,f.type.sizeof] for f in T.fields()}
assert layout['calls_to_find']==[56,4]
assert layout['total_size']==[64,8]
assert layout['size_saved']==[72,8]
assert layout['hash']==[8,48]
H=gdb.lookup_type('gnatcoll__symbols__string_htable__set').strip_typedefs()
hash_layout={f.name:[f.bitpos//8,f.type.sizeof] for f in H.fields()}
HT=gdb.lookup_type('gnatcoll__symbols__string_htable__ht_types__hash_table_type').strip_typedefs()
ht_layout={f.name:[f.bitpos//8,f.type.sizeof] for f in HT.fields()}
assert hash_layout['ht']==[8,40]
assert ht_layout['length']==[24,4]
assert layout['hash'][0]+hash_layout['ht'][0]+ht_layout['length'][0]==40
print('INTERN_LAYOUT '+json.dumps({'pool_record':layout,'hash_set':hash_layout,'hash_table':ht_layout},sort_keys=True))
end
ptype /o gnatcoll__symbols__string_htable__node_type
ptype /o gnatcoll__utils__cst_string_access
ptype /o gnatcoll__symbols__string_htable__ht_types__buckets_type
python
exec(open('/tmp/silver-producer-intern-counters-20261018/pool_reader.py').read())
print('VERIFIED_FULL_POOL_LAYOUT '+json.dumps(pool_layout(),sort_keys=True))
end
quit
