from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time
root=Path(__file__).resolve().parent
case=sys.argv[1];dest=root/case
plan=json.loads((dest/'invocation.json').read_text())
gdbroot=Path('/tmp/silver-capacity-debugger-20261018/root')
gdb=gdbroot/'usr/bin/gdb'
opts=json.loads((dest/'options.json').read_text())
assert all(x['why3_args']==['/usr/bin/false'] for x in opts['file_specific'].values())
script='''set pagination off
set python print-stack full
set confirm off
set auto-load off
set debuginfod enabled off
set startup-with-shell off
set disable-randomization off
unset environment LD_LIBRARY_PATH
set language c
python
import gdb,json
exec(open(READER).read())
snapshots=[]
class CounterBreakpoint(gdb.Breakpoint):
    def __init__(self,spec,phase,halt):
        super().__init__(spec,internal=True)
        self.phase,self.halt=phase,halt
    def stop(self):
        row=snapshot(self.phase)
        snapshots.append(row)
        print('INTERN_SNAPSHOT '+json.dumps(row,sort_keys=True))
        return self.halt
CounterBreakpoint('gnat2why__driver__translate_standard_package','before_standard',False)
CounterBreakpoint('gnat2why__driver__translate_cunit','after_standard',False)
CounterBreakpoint('why__gen__names__free','before_symbol_free',True)
class BackendGuard(gdb.Breakpoint):
    def __init__(self):
        super().__init__('gnat2why__driver__run_gnatwhy3',internal=True)
        self.count=0
    def stop(self):
        self.count+=1
        print('FALSE_BACKEND_CALL '+str(self.count))
        return self.count>=63
BackendGuard()
class CollectionGuard(gdb.Breakpoint):
    def stop(self):
        print('UNEXPECTED_RESULT_COLLECTION')
        return True
CollectionGuard('gnat2why__driver__collect_one_result',internal=True)
end
run
python
print('INTERN_FINAL '+json.dumps(snapshots,sort_keys=True))
end
quit
'''.replace('READER',repr(str(root/'pool_reader.py')))
(dest/'probe.gdb').write_text(script)
env=dict(os.environ);env.update(plan['environment']);env['LD_LIBRARY_PATH']=str(gdbroot/'usr/lib/x86_64-linux-gnu');env['DEBUGINFOD_URLS']=''
command=[str(gdb),'-nx','-q','-batch','-x',str(dest/'probe.gdb'),'--args',*plan['argv']]
start=time.monotonic()
p=subprocess.Popen(command,cwd=plan['cwd'],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
try:output,_=p.communicate(timeout=45)
except subprocess.TimeoutExpired:
    os.killpg(p.pid,signal.SIGTERM)
    try:output,_=p.communicate(timeout=5)
    except subprocess.TimeoutExpired:
        os.killpg(p.pid,signal.SIGKILL);output,_=p.communicate()
    (dest/'probe.log').write_text(output)
    raise SystemExit('Measurement timed out; raw log retained')
(dest/'probe.log').write_text(output)
rows=[json.loads(s.removeprefix('INTERN_SNAPSHOT ')) for s in output.splitlines() if s.startswith('INTERN_SNAPSHOT ')]
result={'case':case,'command':command,'cwd':plan['cwd'],'elapsed_seconds':time.monotonic()-start,'debugger_exit':p.returncode,'snapshots':rows,
        'false_backend_calls':sum(s.startswith('FALSE_BACKEND_CALL ') for s in output.splitlines()),
        'producer_sha256':hashlib.sha256(Path(plan['argv'][0]).read_bytes()).hexdigest(),'debugger_sha256':hashlib.sha256(gdb.read_bytes()).hexdigest(),
        'scope':'missing representation counters; existing exact-source prerequisites; no solver, proof validation or inferior calls'}
(dest/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'case':case,'elapsed_seconds':result['elapsed_seconds'],'debugger_exit':p.returncode,'phases':[r['phase'] for r in rows],'false_backend_calls':result['false_backend_calls']}))
if p.returncode or [r['phase'] for r in rows]!=['before_standard','after_standard','before_symbol_free'] or 'UNEXPECTED_RESULT_COLLECTION' in output:
    print(output);raise SystemExit('Expected complete pool boundaries not observed')
for row in rows:
    print(json.dumps({'phase':row['phase'],**{pool:{k:row[pool][k] for k in ('calls_to_find','distinct_nonempty_symbols','maximum_symbol_length')} for pool in ('why','entity')}}))
