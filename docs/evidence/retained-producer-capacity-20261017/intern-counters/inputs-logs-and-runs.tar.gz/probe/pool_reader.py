"""Read current stopped-inferior pool memory; never invokes inferior code."""
import gdb,json

def fields(name):
    return {f.name:(f.bitpos//8,f.type.sizeof) for f in gdb.lookup_type(name).strip_typedefs().fields()}

def pool_layout():
    record=fields('gnatcoll__symbols__symbol_table_record')
    table=fields('gnatcoll__symbols__string_htable__set')
    ht=fields('gnatcoll__symbols__string_htable__ht_types__hash_table_type')
    node=fields('gnatcoll__symbols__string_htable__node_type')
    buckets=fields('gnatcoll__symbols__string_htable__ht_types__buckets_type')
    assert record['calls_to_find']==(56,4)
    assert record['total_size']==(64,8) and record['size_saved']==(72,8)
    assert record['hash']==(8,48) and table['ht']==(8,40)
    assert ht['length']==(24,4) and ht['buckets']==(8,16)
    assert node['element']==(0,16) and node['next']==(16,8)
    assert buckets['P_ARRAY']==(0,8) and buckets['P_BOUNDS']==(8,8)
    return {'pool_record':record,'hash_set':table,'hash_table':ht,'node':node,'buckets':buckets}

def snapshot(phase):
    layout=pool_layout()
    inferior=gdb.selected_inferior()
    def read(addr,n,signed=False):
        return int.from_bytes(bytes(inferior.read_memory(addr,n)),'little',signed=signed)
    def one(name):
        sym=int(gdb.parse_and_eval('&'+name))
        addr=read(sym,8)
        assert addr
        calls=read(addr+56,4)
        total=read(addr+64,8)
        saved=read(addr+72,8)
        length=read(addr+40,4)
        array=read(addr+24,8)
        bounds=read(addr+32,8)
        lb=read(bounds,4);ub=read(bounds+4,4)
        assert 0<=lb<=ub<=2000000,(lb,ub)
        raw=bytes(inferior.read_memory(array,(ub-lb+1)*8))
        seen=set();sum_lengths=0;max_len=0;max_bytes=b''
        for i in range(ub-lb+1):
            cursor=int.from_bytes(raw[i*8:(i+1)*8],'little')
            while cursor:
                assert cursor not in seen
                seen.add(cursor)
                text_addr=read(cursor,8);text_bounds=read(cursor+8,8)
                first=read(text_bounds,4,True);last=read(text_bounds+4,4,True)
                n=max(0,last-first+1)
                sum_lengths+=n
                if n>max_len:
                    max_len=n;max_bytes=bytes(inferior.read_memory(text_addr,n))
                cursor=read(cursor+16,8)
        assert len(seen)==length,(name,len(seen),length)
        assert sum_lengths==total,(name,sum_lengths,total)
        return {'calls_to_find':calls,'distinct_nonempty_symbols':length,'total_size':total,
                'size_saved':saved,'maximum_symbol_length':max_len,
                'maximum_symbol_latin1':max_bytes.decode('latin1'),'bucket_count':ub-lb+1,
                'sum_symbol_lengths':sum_lengths}
    return {'phase':phase,'why':one('why__gen__names__why3_symbol_alloc'),
            'entity':one('common_containers__intern_strings'),'layout':layout}
