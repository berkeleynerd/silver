set pagination off
set python print-stack full
set confirm off
set auto-load off
set debuginfod enabled off
set startup-with-shell off
set disable-randomization off
unset environment LD_LIBRARY_PATH
set language c
python
import gdb,json
exec(open('/tmp/silver-producer-intern-counters-20261018/pool_reader.py').read())
snapshots=[]
class CounterBreakpoint(gdb.Breakpoint):
    def __init__(self,spec,phase,halt):
        super().__init__(spec,internal=True)
        self.phase,self.halt=phase,halt
    def stop(self):
        row=snapshot(self.phase)
        snapshots.append(row)
        print('INTERN_SNAPSHOT '+json.dumps(row,sort_keys=True))
        return self.halt
CounterBreakpoint('gnat2why__driver__translate_standard_package','before_standard',False)
CounterBreakpoint('gnat2why__driver__translate_cunit','after_standard',False)
CounterBreakpoint('why__atree__free','before_free',True)
class BackendGuard(gdb.Breakpoint):
    def __init__(self):
        super().__init__('gnat2why__driver__run_gnatwhy3',internal=True)
        self.count=0
    def stop(self):
        self.count+=1
        print('FALSE_BACKEND_CALL '+str(self.count))
        return self.count>=63
BackendGuard()
class CollectionGuard(gdb.Breakpoint):
    def stop(self):
        print('UNEXPECTED_RESULT_COLLECTION')
        return True
CollectionGuard('gnat2why__driver__collect_one_result',internal=True)
end
run
python
print('INTERN_FINAL '+json.dumps(snapshots,sort_keys=True))
end
quit
