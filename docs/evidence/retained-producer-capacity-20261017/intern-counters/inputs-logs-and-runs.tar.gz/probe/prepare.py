from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).resolve().parent
old_deps=Path('/tmp/silver-producer-fixed-deps-plan-20261018')
old_bodies=Path('/tmp/silver-producer-fixed-bodies-20261018')
repo=Path('/home/canto/src/github.com/berkeleynerd/silver')
root.joinpath('library-src').mkdir(exist_ok=True)
root.joinpath('library-obj').mkdir(exist_ok=True)
inputs=[]
def copy(src,dst):
    dst.parent.mkdir(parents=True,exist_ok=True)
    assert not dst.exists(),dst
    shutil.copy2(src,dst)
    inputs.append({'original':str(src),'copy':str(dst),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
for p in sorted((old_deps/'library-src').iterdir()):
    if p.is_file():
        assert p.read_bytes()==(repo/'src'/p.name).read_bytes(),p
        copy(p,root/'library-src'/p.name)
for p in sorted((old_deps/'library-obj').glob('*.ali')):copy(p,root/'library-obj'/p.name)
copy(old_deps/'naming.adc',root/'naming.adc')
cases=['put','put_line','first_or_default','input_is_valid','reject','silver_io','silver_arguments','silver_output_libc','silver_runtime']
for case in cases:
    source=(old_deps if case in cases[:5] else old_bodies)/case
    dest=root/case
    dest.joinpath('obj').mkdir(parents=True,exist_ok=True)
    if case in cases[:5]:
        copy(source/'main.adb',dest/'main.adb')
        copy(source/'obj/main.ali',dest/'obj/main.ali')
    plan=json.loads((source/'invocation.json').read_text())
    opts=json.loads((source/'options.json').read_text())
    assert opts['global_gen_mode'] is False
    assert all(v['why3_args']==['/usr/bin/false'] for v in opts['file_specific'].values())
    opts['why3_dir']=str(dest/'obj')+'/'
    dest.joinpath('options.json').write_text(json.dumps(opts,indent=2)+'\n')
    def relocate(s):
        return s.replace(str(old_deps),str(root)).replace(str(old_bodies),str(root))
    plan['argv']=[relocate(x) for x in plan['argv']]
    plan['cwd']=str(dest/'obj')
    plan['basis_invocation']=str(source/'invocation.json')
    plan['scope']='additional missing intern counter measurement; read-only debugger, false backend, no solver'
    plan['status']='prepared'
    dest.joinpath('invocation.json').write_text(json.dumps(plan,indent=2)+'\n')
    dest.joinpath('object-paths.txt').write_text(relocate((source/'object-paths.txt').read_text()))
root.joinpath('inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
root.joinpath('cases.json').write_text(json.dumps(cases,indent=2)+'\n')
print(json.dumps({'copied_inputs':len(inputs),'cases':cases}))
