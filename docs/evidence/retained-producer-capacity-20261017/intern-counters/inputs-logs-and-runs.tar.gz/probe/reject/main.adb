with Silver_IO;
with Silver_Arguments;
procedure Main is
   pragma SPARK_Mode (On);
begin
   Silver_Arguments.Reject;
end Main;
