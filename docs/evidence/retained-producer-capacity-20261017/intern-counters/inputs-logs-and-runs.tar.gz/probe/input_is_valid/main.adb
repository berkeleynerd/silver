with Silver_IO;
with Silver_Arguments;
procedure Main is
   pragma SPARK_Mode (On);
begin
   if Silver_Arguments.Input_Is_Valid then
      null;
   else
      null;
   end if;
end Main;
