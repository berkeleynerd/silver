"""Read every Hsdecl weak slot without inferior calls, writes or continuation."""
def read_table_state():
    specs=PLAN['table_observer']['symbols']
    checks={}
    for name,spec in specs.items():
        addr=address(name)
        assert data(addr,32).hex()==spec['first32'], ('instruction mismatch',name)
        checks[name]={'address':addr,'first32':data(addr,32).hex()}
    module=address('camlWhy3__Decl')
    module_header=u64(module-8)
    assert module_header & 255 == 0 and module_header >> 10 > 88
    hs=u64(module+0x2c0)
    hs_fields=block_fields(hs,4)
    closure=hs_fields[0]
    closure_header=u64(closure-8)
    assert closure_header & 255 == 247 and closure_header >> 10 == 6
    cf=list(struct.unpack('<6Q',data(closure,48)))
    assert cf[0]==address('camlWhy3__Hashcons__hashcons_412')
    table=cf[4];record=block_fields(table,5)
    counter=block_fields(cf[3],1)[0]
    array,hashes,limit,oversize,rover=record
    def ordinary_array(ptr):
        head=u64(ptr-8);assert head & 255 == 0
        size=head>>10;assert size <= 1000000, 'diagnostic outer-array limit'
        return {'address':ptr,'header':head,'fields':list(struct.unpack('<'+'Q'*size,data(ptr,size*8)))}
    aa=ordinary_array(array);ha=ordinary_array(hashes)
    assert len(aa['fields'])==len(ha['fields']) >= 7
    none=u64(address('caml_ephe_none'))
    rows=[];roots=[];seen=set();total=0
    for index,(bucket,hbucket) in enumerate(zip(aa['fields'],ha['fields'])):
        head=u64(bucket-8);words=head>>10
        assert head & 255 == 251 and 2 <= words <= 1000002
        payload=list(struct.unpack('<'+'Q'*words,data(bucket,words*8)))
        assert payload[1]==none, 'Weak.Make bucket unexpectedly has data'
        hh=ordinary_array(hbucket)
        assert len(hh['fields'])==words-2
        keys=payload[2:]
        assert all(v&1 for v in hh['fields'])
        for j,key in enumerate(keys):
            if key==none:continue
            assert not key&1 and key%8==0
            block_fields(key,3)
            h=decode_tagged(hh['fields'][j])
            assert (h & ((1<<62)-1)) % len(aa['fields'])==index, 'cached hash in wrong bucket'
            if key not in seen:roots.append(key);seen.add(key)
        total+=len(keys)
        assert total<=1000000, 'diagnostic total-slot limit'
        rows.append({'index':index,'address':bucket,'header':head,'payload':payload,'hash_array':hh})
    result={'module_address':module,'module_header':module_header,'module_hsdecl_offset':0x2c0,
      'hsdecl_address':hs,'hsdecl_fields':hs_fields,'hashcons_closure_address':closure,
      'hashcons_closure_header':closure_header,'hashcons_closure_fields':cf,
      'table_address':table,'table_header':u64(table-8),'table_fields':record,
      'next_tag_ref':cf[3],'next_tag_raw':counter,'next_tag':decode_tagged(counter),
      'outer_array':aa,'hash_outer_array':ha,'ephe_none_symbol':address('caml_ephe_none'),
      'ephe_none_value':none,'buckets':rows,'retained_unique_declarations':roots,
      'outer_length':len(rows),'allocated_key_slots':total,
      'nonempty_key_slots':sum(v!=none for row in rows for v in row['payload'][2:]),
      'limit':decode_tagged(limit),'oversize':decode_tagged(oversize),'rover':decode_tagged(rover),
      'instruction_checks':checks,
      'scope':'every allocated bucket and key slot; every nonempty key retained as a conservative selectable superset'}
    assert 0<=result['rover']<len(rows)
    assert result['oversize']==sum(len(row['payload'])-2>result['limit'] for row in rows)
    path=OUT/'hsdecl-table.json';path.write_text(json.dumps(result,sort_keys=True)+'\n')
    SUMMARY['hsdecl_table']={'identity':identity(path),'outer_length':len(rows),
      'allocated_key_slots':total,'nonempty_key_slots':result['nonempty_key_slots'],
      'retained_unique_declarations':len(roots),'next_tag':result['next_tag']}
    return roots
