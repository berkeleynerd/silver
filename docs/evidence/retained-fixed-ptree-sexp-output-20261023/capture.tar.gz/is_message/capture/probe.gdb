set pagination off
set confirm off
set auto-load off
set debuginfod enabled off
set startup-with-shell off
set disable-randomization off
set language c
python
import gdb,json
root='/tmp/silver-fixed-sexp-20261023'
plan=json.load(open(root+'/plan.json'))
case=plan['cases'][4]
gdb.execute('unset environment')
for k,v in case['environment'].items():gdb.execute('set environment '+k+'='+v)
end
starti
python
exec(open(root+'/probe.py').read())
end
continue
python
finish_capture()
end
kill
quit
