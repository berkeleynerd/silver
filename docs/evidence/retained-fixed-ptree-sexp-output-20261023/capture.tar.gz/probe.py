import gdb, json, struct, hashlib, collections
from pathlib import Path

failures=[]; guards=[]; captured=False
class StopGuard(gdb.Breakpoint):
    def stop(self):
        guards.append(str(self.location))
        return True
StopGuard('*camlGnat_checks__init_1987', internal=True)
for event in ('fork','vfork','exec'):
    gdb.execute('catch '+event)
class SexpBoundary(gdb.Breakpoint):
    def stop(self):
        return 'Gnat_ast_to_ptree' in gdb.execute('bt 12',to_string=True)
SexpBoundary('*camlSexplib0__Sexp__to_string_mach_1258', internal=True)

def finish_capture():
    global captured
    inf=gdb.selected_inferior()
    expected=int(gdb.parse_and_eval('&camlSexplib0__Sexp__to_string_mach_1258'))
    pc=int(gdb.parse_and_eval('$pc'))
    assert pc==expected,(hex(pc),hex(expected),guards)
    assert not guards,guards
    assert len(inf.threads())==1
    root=int(gdb.parse_and_eval('$rax'))
    def raw(a,n): return bytes(inf.read_memory(a,n))
    def word(a):return struct.unpack('<Q',raw(a,8))[0]
    def cstring(a):
        out=bytearray()
        for i in range(256):
            b=raw(a+i,1)
            if b==b'\0':return out.decode('ascii')
            out+=b
        raise AssertionError('custom-operation name too long')
    objects={};todo=[root]
    while todo:
        v=todo.pop()
        if v&1 or str(v) in objects:continue
        assert v and v%8==0,hex(v)
        header=word(v-8);tag=header&255;size=header>>10
        assert size<10000000,('observer size guard',hex(v),tag,size)
        data=raw(v,8*size)
        row={'header':header,'tag':tag,'words':size}
        if tag==252:
            length=8*size-1-data[-1]
            assert 0<=length<8*size and data[length]==0
            row.update(length=length,data_hex=data[:length].hex())
        elif tag==255:
            row.update(data_hex=data.hex(),custom_id=cstring(word(word(v))))
        else:
            assert tag<246,('unexpected non-data block',hex(v),tag)
            fields=list(struct.unpack('<'+'Q'*size,data))
            row['fields']=fields;todo.extend(x for x in fields if not x&1)
        objects[str(v)]=row
    proc=Path('/proc')/str(inf.pid)
    process={'pid':inf.pid,'argv':[x.decode() for x in (proc/'cmdline').read_bytes().split(b'\0') if x],
             'environment':dict(x.decode().split('=',1) for x in (proc/'environ').read_bytes().split(b'\0') if x),
             'maps':(proc/'maps').read_text(),'cut':'Sexplib0.Sexp.to_string_mach entry before first instruction',
             'pc':pc,'root_register':'rax','root':root,'stack':gdb.execute('bt 8',to_string=True),
             'entry_instruction_bytes':raw(pc,120).hex()}
    out=Path(case['cwd'])/'capture'
    (out/'graph.json').write_text(json.dumps({'root':root,'objects':objects},separators=(',',':'))+'\n')
    (out/'process.json').write_text(json.dumps(process,indent=2)+'\n')
    summary={'completed':True,'objects':len(objects),'tag_counts':dict(collections.Counter(r['tag'] for r in objects.values())),
             'custom_identifiers':dict(collections.Counter(r['custom_id'] for r in objects.values() if r['tag']==255)),
             'guard_hits':guards,'inferior_calls':0,'inferior_memory_writes':0,'stopped_before_sexp_bytes':True}
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');captured=True
