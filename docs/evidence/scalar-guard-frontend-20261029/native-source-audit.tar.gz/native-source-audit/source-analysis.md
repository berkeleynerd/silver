# Guard frontend source analysis — 2026-10-29

The pinned `-gnatdM` option is a promising native-build correction for blocker
#284: its sole operational flag consumer disables current-value replacement.
The inspected paths do not suppress checks, weaken SPARK mode, or alter static
legality. This source analysis supports selecting the option after the lead's
native matrix, dynamic-check controls, and independent critical review. It is
not a standalone proof of every behavior of GNAT.

## Scope, authorization, and retained inputs

The owner authorized bounded frontend characterization and the smallest
general justified correction, with SPARK/Lean/source correspondence and focused
end-to-end validation. The published #283 review head remains
`88c127b6314d5e44eeb7b80a7e4e14220e64dfc5`; expensive complete project proof is
deferred until relevant review feedback is integrated. This subthread inspected
source and, at the lead's subsequent request, retained evidence. It performed
no compiler probes, builds, proofs, governed-file changes, or GitHub writes.

The original independently reconstructed reproducer and logs are retained in
the sibling `review-guard-frontend-20261028/` directory. They establish the
observed admitted/proved/native-rejected contrast. This record explains the
producer; the lead separately owns new matrix and execution results.

The inspected GCC revision is
`6afcc4f6da931eb93f3ab001a0dd9650ea71d1ea`, the commit targeted by GCC release
tag `releases/gcc-16.1.0` (annotated tag object
`fe7c47a8e79e165fc686592d895402744e6b54c1`). Its `gcc/ada` tree is
`a3b9f0d4c999c8c127cebdc239ca8218284137aa`.

- [retained-sources.json](retained-sources.json) records source URLs, byte counts,
  SHA256 hashes and Git blob identities for the retained files.
- [gcc-ada-tree.json](gcc-ada-tree.json) is pinned Git tree metadata.
- [frontend-source-inventory.json](frontend-source-inventory.json) identifies
  all 474 top-level `.adb`/`.ads` files covered by the successful scan.
- [completed-scan-results.json](completed-scan-results.json) records the
  completed scan findings and their retention limitations.
- [installed-gnat-alire.toml](installed-gnat-alire.toml) records the selected
  binary archive origin and SHA256
  `9f74f58a827a2ad40dd84c72a413e75ea52888e0d8f7e252fba4d26762402703`.
- [gcc.anod](sources/gnat-fsf-builds/specs/gcc.anod), retained at the
  GNAT-FSF-builds release commit `0334dd54a2c479faa3dfad47a911373581b11739`,
  selects GCC 16.1.0 and its upstream release archive for Linux at lines 12–29.
  The file's platform-specific wrapper installation at lines 297–305 is for
  Darwin. This is release/source provenance, not a reproduced binary build or
  cryptographic binary-to-source attestation.

The successful case-insensitive scan covered all **474 top-level Ada frontend
`.adb`/`.ads` files**, totaling **27,301,966 bytes**, with zero retrieval failures
in **16.075 seconds**. It did not cover `gcc/ada` subdirectories or the rest of
GCC. An earlier broad archive transfer was stopped, so it supplies no complete
repository-wide scan claim. The successful scan was not repeated for retention.

The original full per-file SHA256 list was not persisted. The 474-file inventory
here was reconstructed from pinned Git metadata, without rescanning contents.
The eight matching-file SHA256 values printed by the original scan were retained
in the conversation and checked against the subsequently retained bytes. All
15 retained GCC files were also checked against their pinned Git blob IDs and
sizes. No unavailable original SHA256 values are represented as recovered.

Model/effort selection belongs to the lead; this source-inspection process did
not runtime-confirm those settings. No token/cost measurements are available.
The scan timing above is not the elapsed time for the whole investigation.

## Exact failure route

The relevant reproducer has `X : Integer := 0`, `R : Integer range 0..9 := 0`,
and executes `R := X` under outer guard `X >= 0 and then X <= 9` and inner guard
`X = 99`. Silver's `Refine_Or_Keep` retains incoming `[0,9]` after the
contradiction, so its runtime safety argument is not itself falsified. The
native frontend nevertheless diagnoses an out-of-range value in that arm.

1. [sem_ch5.adb](sources/gcc/ada/sem_ch5.adb), lines 2015–2018, analyzes and
   resolves an `if`/`elsif` condition before calling
   `Set_Current_Value_Condition`. Lines 2027–2045 disable expansion of arms
   whose condition is known false. This is a local compiler heuristic; it is
   not Silver's full interval/path reasoning.
2. [exp_util.adb](sources/gcc/ada/exp_util.adb), lines 14034–14061, records one
   conditional source node in an eligible entity's `Current_Value`. Its
   comment at 14051–14057 explicitly says an inner condition can blot out a
   previous outer condition, because the data structures do not record both.
3. The same file, lines 7474–7608, interprets the stored condition. It strips
   `not`, inverts comparisons for false outcomes, reverses ordered relations
   when operands are swapped, and chooses the first matching atom from a true
   `and`/`and then`. A false conjunction produces no fact. Lines 7640–7694
   identify true `then` and false `else`/later-`elsif` contexts.
4. Consequently, the first outer atom `X >= 0` cannot refute `X = 99`; the
   inner equality can become the recorded fact. Reversing the outer atom order
   may let the compiler fold the inner guard false before arm expansion.
   This is a source-based prediction; the lead's matrix owns the observations.
5. [exp_ch2.adb](sources/gcc/ada/exp_ch2.adb), lines 124–179, expands current
   values only for eligible discrete references and, for conditional facts,
   only when the normalized relation is equality. Lines 204–219 rewrite an
   integer reference to an integer literal and explicitly mark it nonstatic.
6. [checks.adb](sources/gcc/ada/checks.adb), lines 3187–3194, implements
   `Bad_Value` through `Apply_Compile_Time_Constraint_Error`. Lines 3411–3433
   detect disjoint inferred and target ranges; lines 3478–3484 also report a
   known out-of-range expression.
7. [sem_util.adb](sources/gcc/ada/sem_util.adb), lines 6038–6048, explicitly
   promotes these compile-time constraint diagnostics to hard errors when
   `SPARK_Mode = On`, unless the caller forces a warning. This is independent
   of `-gnatwe`. The null-target-range exception at `checks.adb:3394–3404`
   forces a warning for likely deactivated code; ordinary out-of-range values
   do not receive that exception.

`exp_util.adb:7622–7630` explicitly disables `Get_Current_Value_Condition`
optimization in GNATprove mode, because folding can deprive proof of needed
information. That accounts for the proof/native divergence without suggesting
that GNATprove omitted a required obligation.

## Forms that make an admission-only patch difficult

These are source facts, not a claim that every listed spelling fails on every
surrounding program:

- Both operand orientations and `not`/false-`/=` outcomes can produce normalized
  equality (`exp_util.adb:7491–7493,7542–7580`). Ordered facts also feed
  relational folding through `sem_eval.adb:1641–1766`.
- Parentheses preserve the expression node and increment `Paren_Count`
  (`par-ch4.adb:1663–1682`); a grouped identifier remains an entity reference.
- Before condition capture, integer expansion can turn `X+0`, `0+X`, `X-0`,
  `X*1`, `1*X`, or `X/1` into `X`
  (`exp_ch4.adb:7931–7944,8131–8135,9990–10007,10701–10708`). Thus checking only
  visibly bare or grouped names is incomplete.
- Threshold eligibility is `Compile_Time_Known_Value`, not Ada staticness
  (`exp_util.adb:7556–7568,14094–14099`). `sem_eval.adb:1852–1864` follows a
  constant object's `Constant_Value`; lines 1881–1889 accept literals.
- Mutable references themselves are not compile-time-known to that function,
  but current-value expansion can first replace them with literals
  (`exp_ch2.adb:487–491`). Initializers and suitable assignments record known
  values (`sem_ch3.adb:4810–4812`, `sem_ch5.adb:1213–1218`). Intervening
  value-kill contexts affect whether such replacement occurs.
- `Safe_To_Capture_Value` permits ordinary variables, constants, formals and,
  for conditions, loop parameters (`sem_util.adb:28076–28102`). Source subtype
  bounds and prior folding can prevent some impossible conditions from ever
  reaching the materialized-literal failure route.

## Complete flag references within the scanned frontend

| File | Lines | Meaning |
| --- | --- | --- |
| `debug.ads` | 86 | `Debug_Flag_MM` defaults to `False`. |
| `debug.adb` | 1350 | The `M` switch sets the flag. |
| `exp_attr.adb` | 1963, 1965, 1973 | Saves the flag, enables it while analyzing `Loop_Entry` snapshot declarations, then restores it. |
| `gnat1drv.adb` | 397 | Enables it in CodePeer mode when warnings are suppressed. |
| `exp_util.adb` | 12047 | Sole operational consumer: `OK_To_Do_Constant_Replacement` returns `False`. |

The only calls to `OK_To_Do_Constant_Replacement` in the complete scanned
frontend are `exp_ch2.adb:154`, `sem_util.adb:22732`, and
`sem_util.adb:22788`. Its declaration is at `exp_util.ads:1103`; definition
and end are at `exp_util.adb:12028,12089`. The latter two calls conservatively
withhold stored known-null/non-null flags. They do not assume a new nullness
fact. The matching source locations, including definition/comment occurrences,
are retained in `completed-scan-results.json`.

`debug.adb:626–628` says exactly:

> dM   Assume all variables have been modified, and ignore current value
> indications. This debug flag disconnects the tracking of constant
> values (see Exp_Ch2.Expand_Current_Value).

`exp_attr.adb:1958–1960` explains that the compiler itself disables this
propagation for correct loop-entry snapshot semantics. `gnat1drv.adb:388–394`
describes simple value propagation as an optimization useful for generated code
and compiler warnings. CodePeer enables other settings separately; passing
`-gnatdM` does not enable CodePeer mode or those other settings.

`switch-c.adb:347–401` parses this as a debug flag and records the compilation
switch. The installed manual's exact excerpts are retained in
[installed-gnat-ugn-excerpts.txt](installed-gnat-ugn-excerpts.txt): lines
6948–6956 document the `-gnatd` syntax and direct readers to `debug.adb`;
10658–10665 classify these as internal debugging switches, normally intended
for compiler development or system debugging. Therefore describe this option
as an **internal, source-documented, pinned optimization control**, not as a
separately documented public production option or a supported-vendor fix.

## Preservation argument and its limits

The sole operational flag consumer changes eligibility for current-value
replacement. None of the flag references changes check-suppression settings,
`SPARK_Mode`, assertion policy, overflow policy, or Ada legality rules. The
proposed application should retain `-gnata` and `-gnato` and preserve the
GNATprove required-obligation policy. The original application source bytes
remain authoritative for admission, proof, and build.

**Independent-review scope finding and resolution:** This exact source audit
covers the native GCC release only. It does not establish source correspondence
for GNATprove's embedded compiler fork. The reviewer noted that adding the flag
to a shared generated GPR would change that frontend's effective options even
if the GNATprove CLI invocation remained unchanged. The lead accepted this
finding and selected **native `Build_Command`-only `-cargs:Ada -gnatdM`**, leaving
the generated GPR and proof options unchanged. No proof-frontend source audit
is required or claimed for that placement. The lead will check the final proof
project lacks `M` and the native ALI records `M`. Earlier shared-project
diagnostic controls must retain their actual configuration labels; they are
not final-placement evidence. Negative proof controls are scoped executable
evidence, not a source inventory of the embedded compiler fork.

There is no mutable-value bypass in the scalar range-check route examined:

- `Compile_Time_Known_Value` (`sem_eval.adb:1812–1918`) does not consult mutable
  entities' `Current_Value`; a mutable reference is not a known literal merely
  because a conditional fact exists.
- `Determine_Range` (`checks.adb:5190–5197`) uses that predicate for a singleton
  range. Otherwise it starts with expression type bounds at 5214–5300.
  The case at 5307–5563 specializes arithmetic, attributes and conversions,
  not identifier current values. `Determine_Range` does not consult an
  identifier's `Current_Value`. Elsewhere in `checks.adb`, line 8783 clears
  a flag entity's current value; that is not a read or an alternative range
  inference route.
- `Test_In_Range` compares concrete values against target bounds only under
  `Compile_Time_Known_Value` (`sem_eval.adb:7406–7467`). Its remaining subtype
  cases can establish in-range status; other cases return unknown
  (7473–7494). `Is_Out_Of_Range` delegates to this function (5667–5677).
- An unresolved scalar range check is enabled, not suppressed
  (`checks.adb:3497–3500`). Mandatory static expressions continue through the
  ordinary folding and diagnostic code; `M` does not control that code.

The option is **not identical to GNATprove mode**. It does not disable
`Get_Current_Value_Condition` or every use of conditional facts. In particular,
relational comparison folding remains active. The claim here is that `M`
blocks the identified materialized-literal route while retaining the normal
runtime check machinery, not that it implements a general GNAT semantics model.

Before selection, the independent review should challenge the consumer/call-site
coverage, expansion order, range-check route, static-expression preservation,
and source correspondence. The lead's diagnostic matrix and dynamic range/
overflow controls should be assessed as separate executable evidence. Changes
to generated driver/source-shape records still require their normal source and
semantic correspondence work; a pin update alone does not establish that work.

Potential practical effects include changed native code and compiler warnings,
additional dynamic checks, and reduced constant-propagation optimization. These
are preferable to introducing an incomplete frontend normalization model or
silently narrowing the admitted language, provided the scoped preservation
argument and relevant executable evidence withstand review. Any future compiler
pin change must re-establish applicability of this exact internal control.
