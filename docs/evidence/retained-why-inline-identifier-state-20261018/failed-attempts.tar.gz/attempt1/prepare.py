"""Prepare one fresh diagnostic; never starts an inferior or a solver."""
from pathlib import Path
import json,struct,shutil,hashlib
ROOT=Path(__file__).resolve().parent
OLD=Path('/tmp/silver-producer-fixed-tail-20261018')
def identity(p):
 b=Path(p).read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
plan=json.loads((OLD/'plan.json').read_text().replace(str(OLD),str(ROOT)))
oldcase=next(c for c in plan['inputs'] if c['name']=='input_is_valid')
plan['inputs']=[oldcase]
assert not (ROOT/'input_is_valid').exists(), 'fresh directory required'
shutil.copytree(OLD/'overlay',ROOT/'overlay')
cwd=Path(oldcase['cwd']);cwd.mkdir();(cwd/'temp').mkdir()
for name in [oldcase['argv'][-1],'why3.conf']:shutil.copy2(OLD/'input_is_valid'/name,cwd/name)
# The overlay config has absolute private driver paths. Relocate only these;
# driver bytes/import contents remain identical and resolution is rechecked.
for p in [ROOT/'overlay'/'why3.conf',cwd/'why3.conf']:
 p.write_text(p.read_text().replace(str(OLD),str(ROOT)))
plan['file_identities']={p:m for p,m in plan['file_identities'].items() if not p.startswith(str(ROOT)) or Path(p).is_file()}
for p in list(plan['file_identities']):plan['file_identities'][p]=identity(p)
binary=Path(oldcase['argv'][0]).read_bytes();shoff=struct.unpack_from('<Q',binary,40)[0];es,n=struct.unpack_from('<HH',binary,58)
sections=[struct.unpack_from('<IIQQQQIIQQ',binary,shoff+i*es) for i in range(n)];symbols={}
for s in sections:
 if s[1]!=2:continue
 st=sections[s[6]];names=binary[st[4]:st[4]+st[5]]
 for off in range(s[4],s[4]+s[5],s[9]):
  idx,info,other,sh,addr,size=struct.unpack_from('<IBBHQQ',binary,off)
  name=names[idx:names.find(b'\0',idx)].decode()
  if sh and sh<len(sections) and addr and size:
   sec=sections[sh];raw=sec[4]+addr-sec[3]
   symbols[name]={'symbol':name,'address':addr,'size':size,'first32':binary[raw:raw+32].hex()}
plan['entry_observers']={'prepare':symbols['camlWhy3__Driver__prepare_task_3376'],'apply':symbols['camlWhy3__Driver__apply_3383']}
# Permit normal scheduling/preparation; all printing/submission remains guarded.
plan['forbidden_calls']={n:s for n,s in plan['forbidden_calls'].items() if 'print_task_prepared' in n or 'call_on_buffer' in n or 'send_request' in n}
plan['scope']='first actual cvc5 inline_trivial entry, one fixed Input_Is_Valid input; diagnostic only'
probe=(OLD/'probe.py').read_text().replace(str(OLD),str(ROOT))
probe=probe.replace("Phase(PLAN['endpoint']['symbol'],True)","Phase(PLAN['endpoint']['symbol'])")
probe=probe.replace("'end_of_registration' if self.final", "'inline_trivial_entry' if self.final")
probe+='\n'+(ROOT/'entry-observer.py').read_text()
(ROOT/'probe.py').write_text(probe)
resolution=(OLD/'driver-resolution.json').read_text().replace(str(OLD),str(ROOT))
(ROOT/'driver-resolution.json').write_text(resolution)
for p in [ROOT/'prepare.py',ROOT/'entry-observer.py',ROOT/'probe.py',ROOT/'static-entry-disassembly.txt']:
 plan['file_identities'][str(p)]=identity(p)
(ROOT/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
run=(OLD/'run.py').read_text().replace(str(OLD),str(ROOT))
run=run.replace('timeout=600','timeout=120')
run=run.replace("import json,hashlib,subprocess,os,signal,time,re,atexit", "import json,hashlib,subprocess,os,signal,time,re,atexit,resource\nresource.setrlimit(resource.RLIMIT_AS,(6*1024**3,6*1024**3))")
run=run.replace('All five registration segments completed; no solver scheduling or driver preparation; inputs unchanged.', 'First Input_Is_Valid cvc5 inline entry captured; no printing or solver request; diagnostic only.')
(ROOT/'run.py').write_text(run)
print('Prepared first-inline diagnostic. Run only after managed worker allocation.')
