"""Snapshot immediate inlining counters/backing state without inferior calls.

Auxiliary tables retain their complete backing slots plus shallow key/data
objects. They are observations, not transferred capacity claims.
"""
def read_shared_state():
    checks={}
    for name,spec in PLAN['shared_observer']['symbols'].items():
        addr=address(name)
        assert data(addr,32).hex()==spec['first32'], ('instruction mismatch',name)
        checks[name]={'address':addr,'first32':data(addr,32).hex()}
    def block(ptr,tag=0,words=None):
        assert ptr and not ptr&7
        head=u64(ptr-8);size=head>>10
        assert head&255==tag and (words is None or size==words), ('block shape',ptr,head,tag,words)
        assert size<=1000000, 'diagnostic block limit'
        return {'address':ptr,'header':head,'fields':list(struct.unpack('<'+'Q'*size,data(ptr,size*8))) if size else []}
    def module(name,offset):
        ptr=address(name);head=u64(ptr-8)
        assert head&255==0 and head>>10>offset//8
        return {'symbol':name,'address':ptr,'header':head,'offset':offset,'value':u64(ptr+offset)}
    def counter(ptr):
        row=block(ptr,0,1);row['decoded']=decode_tagged(row['fields'][0]);assert row['decoded']>=0
        return row
    ident_module=module('camlWhy3__Ident',0xe8)
    ident_closure=block(ident_module['value'],247,3)
    assert ident_closure['fields'][0]==address('camlWhy3__Ident__fun_6183')
    ident={'module':ident_module,'closure':ident_closure,'counter':counter(ident_closure['fields'][2])}
    none=u64(address('caml_ephe_none'))
    def shallow(ptr):
        if ptr==none or ptr&1:return None
        return block(ptr)
    def weak(name,offset):
        m=module(name,offset);hs=block(m['value'],0,4)
        cl=block(hs['fields'][0],247,6)
        assert cl['fields'][0]==address('camlWhy3__Hashcons__hashcons_412')
        record=block(cl['fields'][4],0,5);outer=block(record['fields'][0]);hashes=block(record['fields'][1])
        assert len(outer['fields'])==len(hashes['fields'])>=7
        rows=[];objects={};slots=0;nonempty=0
        for i,(bp,hp) in enumerate(zip(outer['fields'],hashes['fields'])):
            b=block(bp,251);h=block(hp)
            assert len(b['fields'])>=2 and b['fields'][1]==none
            assert len(h['fields'])==len(b['fields'])-2
            slots+=len(h['fields']);assert slots<=1000000,'diagnostic slot limit'
            for key,rh in zip(b['fields'][2:],h['fields']):
                v=decode_tagged(rh)
                if key==none:continue
                assert (v&((1<<62)-1))%len(outer['fields'])==i
                objects[str(key)]=shallow(key);nonempty+=1
            rows.append({'index':i,'bucket':b,'hash_array':h})
        limit,oversize,rover=map(decode_tagged,record['fields'][2:])
        assert oversize==sum(len(r['bucket']['fields'])-2>limit for r in rows)
        assert 0<=rover<len(rows)
        return {'module':m,'hashcons_module':hs,'closure':cl,'counter':counter(cl['fields'][3]),
          'table':record,'outer_array':outer,'hash_outer_array':hashes,'buckets':rows,'key_objects':objects,
          'allocated_key_slots':slots,'nonempty_key_slots':nonempty,'limit':limit,'oversize':oversize,'rover':rover}
    hashcons={name:weak(mod,off) for name,mod,off in [
      ('Ty.Hsty','camlWhy3__Ty',0x298),('Theory.Hstdecl','camlWhy3__Theory',0x2f0),('Task.Hstask','camlWhy3__Task',0x1d8)]}
    sm=module('camlWhy3__Task',0x198);s=block(sm['value'],0,32);m=block(s['fields'][0],0,56)
    hc=block(m['fields'][5],247,5)
    assert hc['fields'][0]==address('camlWhy3__Hcpt__hashcons_655')
    assert hc['fields'][3:]==[m['fields'][3],m['fields'][4]]
    c=counter(m['fields'][4]);record=block(m['fields'][3],0,4);outer=block(record['fields'][1])
    size,seed,initial=map(decode_tagged,[record['fields'][i] for i in [0,2,3]])
    assert len(outer['fields'])>=16 and len(outer['fields'])&(len(outer['fields'])-1)==0
    buckets=[];seen=set();containers={};objects={}
    for i,p in enumerate(outer['fields']):
        rows=[]
        while p!=1:
            assert p not in seen,'repeated/cyclic ephemeron bucket node';seen.add(p)
            assert len(seen)<=1000000,'diagnostic bucket-list limit'
            b=block(p,0,3);h,ep,p=b['fields'];hv=decode_tagged(h)
            assert hv&(len(outer['fields'])-1)==i
            e=block(ep,251,3);containers[str(ep)]=e
            for v in e['fields'][1:]:
                if v!=none and not v&1:objects[str(v)]=shallow(v)
            rows.append(b)
        buckets.append({'index':i,'nodes':rows})
    assert size==len(seen)
    hcpt={'module':sm,'set_module':s,'map_module':m,'closure':hc,'counter':c,'table':record,
      'outer_array':outer,'size':size,'seed':seed,'initial_size':initial,'buckets':buckets,
      'containers':containers,'key_data_objects':objects}
    result={'ident':ident,'hashcons':hashcons,'Task.Stdecl':hcpt,'ephe_none_symbol':address('caml_ephe_none'),
      'ephe_none_value':none,'instruction_checks':checks,
      'scope':'same stopped first inline entry; auxiliary backing complete, key/data payloads shallow; no continuation'}
    path=OUT/'shared-state.json';path.write_text(json.dumps(result,sort_keys=True)+'\n')
    SUMMARY['shared_state']={'identity':identity(path),'identifier_counter':ident['counter']['decoded'],
      'hashcons_counters':{n:r['counter']['decoded'] for n,r in hashcons.items()},'Task.Stdecl_nextid':c['decoded']}
    return result
