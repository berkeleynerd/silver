# Appended to the retained read-only probe. No inferior calls or data writes.
SUMMARY['driver_preparation']=[]
SUMMARY['inline_entry']=None

def raw_graph(roots):
 """Lossless OCaml payload graph, limited to logical declaration roots.
 Custom/string/double blocks are retained as opaque bytes; no C pointers are
 followed. Closures/lazy/objects fail closed. Limits are diagnostic aborts,
 never capacity conclusions. Shared addresses are represented once here;
 semantic occurrence analysis must follow every edge separately.
 """
 pending=list(roots);blocks={};total=0
 while pending:
  ptr=pending.pop()
  if ptr & 1 or str(ptr) in blocks:continue
  assert ptr and ptr % 8 == 0, ('unaligned pointer',hex(ptr))
  header=u64(ptr-8);tag=header & 255;words=header >> 10
  assert words <= 1<<20, ('oversized block',hex(ptr),words)
  assert tag < 246 or tag >= 251, ('unhandled runtime block',hex(ptr),tag)
  size=words*8;total+=size+8
  assert len(blocks)<1000000 and total<=128*1024*1024, 'diagnostic dump limit'
  payload=data(ptr,size)
  row={'header':header,'tag':tag,'words':words}
  if tag<246:
   fields=list(struct.unpack('<'+'Q'*words,payload));row['fields']=fields
   pending.extend(fields)
  else:row['payload_hex']=payload.hex()
  blocks[str(ptr)]=row
 return {'roots':roots,'blocks':blocks,'retained_payload_bytes':total,
         'opaque_tags':sorted({r['tag'] for r in blocks.values() if r['tag']>=251})}

class Preparation(gdb.Breakpoint):
 def __init__(self):
  spec=PLAN['entry_observers']['prepare'];addr=address(spec['symbol'])
  assert data(addr,32).hex()==spec['first32']
  super().__init__('*'+hex(addr));self.silent=True
 def stop(self):
  try:
   frame=gdb.selected_frame();reg=lambda n:int(frame.read_register(n))
   drv=reg('rax');task=reg('rbx');fields=block_fields(drv,11)
   row={'driver':drv,'driver_tag':decode_tagged(fields[10]),'input_task':task,
        'input_shape':task_shape(task),'directives':[ocaml_string(x) for x in list_values(fields[3])],
        'visited_directives':[]}
   SUMMARY['driver_preparation'].append(row)
   assert len(SUMMARY['driver_preparation'])==1, 'unexpected prior preparation'
   assert row['directives'][:2]==['counterexamples_dependent_intros','inline_trivial']
   save();return False
  except Exception as e:
   SUMMARY['failures'].append('prepare observer: '+repr(e));save();return True

class InlineEntry(gdb.Breakpoint):
 def __init__(self):
  spec=PLAN['entry_observers']['apply'];addr=address(spec['symbol'])
  assert data(addr,32).hex()==spec['first32']
  super().__init__('*'+hex(addr));self.silent=True
  self.final=True;self.start=False
 def stop(self):
  try:
   frame=gdb.selected_frame();reg=lambda n:int(frame.read_register(n))
   task=reg('rax');pair=block_fields(reg('rbx'),2);name=ocaml_string(pair[1])
   assert len(SUMMARY['driver_preparation'])==1
   prep=SUMMARY['driver_preparation'][0];prep['visited_directives'].append(name)
   if name!='inline_trivial':
    assert prep['visited_directives']==['counterexamples_dependent_intros']
    save();return False
   assert prep['visited_directives']==['counterexamples_dependent_intros','inline_trivial']
   assert SUMMARY['inline_entry'] is None
   shape=task_shape(task);ordered=list(reversed(shape['declaration_addresses']))
   decls=[];kinds=[]
   for td in ordered:
    tdnode,tdtag=block_fields(td,2)
    head=u64(tdnode-8);tag=head & 255;words=head >> 10
    assert tag in (0,1,2,3)
    if tag==0:
     assert words==1
     decls.append(u64(tdnode))
    kinds.append({'tdecl':td,'node_tag':tag,'node_words':words,'tag':decode_tagged(tdtag)})
   graph=raw_graph(decls)
   graph.update(ordered_tdecls=kinds,task_address=task,
       scope='all logical declaration payloads at first cvc5 inline_trivial entry')
   path=OUT/'inline-entry-graph.json';path.write_text(json.dumps(graph,sort_keys=True)+'\n')
   SUMMARY['inline_entry']={'task':task,'shape':shape,'ordered_tdecls':kinds,
       'graph':identity(path),'declaration_roots':len(decls),'stored_blocks':len(graph['blocks'])}
   # Reuse the retained final GC/resource invariants, now at the actual entry.
   return Phase.stop(self)
  except Exception as e:
   SUMMARY['failures'].append('inline entry observer: '+repr(e));save();return True
Preparation();InlineEntry()
