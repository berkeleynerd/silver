"""Offline memory-model regression; reject every zero-byte memory read."""
from pathlib import Path
import json,struct,tempfile,hashlib
script=Path(__file__).with_name('table-observer.py').read_text()
names=json.loads(Path(__file__).with_name('plan.json').read_text())['table_observer']['symbols']
def run(mixed=False,bad_hash_length=False):
 mem={};nextptr=0x10000
 def put(addr,b):
  for i,v in enumerate(b):mem[addr+i]=v
 def block(fields,tag=0):
  nonlocal nextptr
  ptr=nextptr+8;nextptr+=8*(len(fields)+1)
  put(ptr-8,struct.pack('<Q',(len(fields)<<10)|tag))
  put(ptr,struct.pack('<'+'Q'*len(fields),*fields));return ptr
 def data(addr,n=8):
  assert n>0,'zero-byte memory read'
  return bytes(mem[addr+i] for i in range(n))
 def u64(addr):return int.from_bytes(data(addr),'little')
 def fields(ptr,n):
  assert u64(ptr-8)&255==0 and u64(ptr-8)>>10==n
  return list(struct.unpack('<'+'Q'*n,data(ptr,n*8)))
 def tagged(n):return 2*n+1
 def decode(raw):return raw>>1
 symbols={n:0x1000+64*i for i,n in enumerate(names)}
 for addr in symbols.values():put(addr,b'\x90'*32)
 none=0xee00;empty=block([0,none],251);empty_hash=block([])
 buckets=[empty]*7;hashes=[empty_hash]*7
 decl=block([1,1,1])
 if mixed:
  buckets[0]=block([0,none,decl,none],251)
  hashes[0]=block([tagged(0)] if bad_hash_length else [tagged(0),tagged(0)])
 table=block([block(buckets),block(hashes),tagged(7),tagged(0),tagged(0)])
 cl=block([symbols['camlWhy3__Hashcons__hashcons_412'],0,0,block([tagged(10)]),table,0],247)
 hs=block([cl,0,0,0]);module=block([0]*88+[hs]);symbols['camlWhy3__Decl']=module
 symbols['caml_ephe_none']=0xeeee0;put(0xeeee0,struct.pack('<Q',none))
 with tempfile.TemporaryDirectory() as tmp:
  env={'PLAN':{'table_observer':{'symbols':{n:{'first32':(b'\x90'*32).hex()} for n in names}}},'SUMMARY':{},'OUT':Path(tmp),'address':symbols.__getitem__,'data':data,'u64':u64,'block_fields':fields,'decode_tagged':decode,'struct':struct,'json':json,'identity':lambda p:{'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()}}
  exec(compile(script,'table-observer.py','exec'),env)
  roots=env['read_table_state']()
  assert roots==([decl] if mixed else [])
  result=json.loads((Path(tmp)/'hsdecl-table.json').read_text())
  assert result['outer_length']==7
  assert result['allocated_key_slots']==(2 if mixed else 0)
  assert result['nonempty_key_slots']==(1 if mixed else 0)
run();run(mixed=True)
try:run(mixed=True,bad_hash_length=True)
except AssertionError:pass
else:raise AssertionError('inconsistent bucket/hash lengths accepted')
print('PASS: all-empty buckets, mixed empty/nonempty slots, zero-byte reads forbidden, mismatched cached-hash length rejected; native runs0')
