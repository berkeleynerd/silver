"""Prepare the new missing-state capture; no inferior is started here."""
from pathlib import Path
import json,hashlib,shutil,ast
ROOT=Path(__file__).resolve().parent
OLD='/tmp/silver-why-entry-capture-20261018'
def identity(p):
 b=Path(p).read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
plan=json.loads((ROOT/'plan.json').read_text().replace(OLD,str(ROOT)))
(ROOT/'prior-plan.json').write_bytes((ROOT/'plan.json').read_bytes())
case=plan['inputs'][0];cwd=Path(case['cwd']);cwd.mkdir();(cwd/'temp').mkdir()
for name in [case['argv'][-1],'why3.conf']:shutil.copy2(ROOT/'input'/name,cwd/name)
for p in [ROOT/'overlay'/'why3.conf',cwd/'why3.conf']:
 p.write_text(p.read_text().replace(OLD,str(ROOT)))
resolution=(ROOT/'driver-resolution.json').read_text().replace(OLD,str(ROOT))
(ROOT/'driver-resolution.json').write_text(resolution)
probe=(ROOT/'probe.py').read_text().replace(OLD,str(ROOT))
# Insert the full table observer before the existing entry observer starts.
probe=probe.replace('# Appended to the retained read-only probe. No inferior calls or data writes.',
 (ROOT/'table-observer.py').read_text()+'\n# Existing entry observer, extended to complete table roots.')
probe=probe.replace('graph=raw_graph(decls)',"table_roots=read_table_state()\n   graph=raw_graph(list(dict.fromkeys(decls+table_roots)))\n   graph['input_declaration_roots']=decls\n   graph['hsdecl_declaration_roots']=table_roots")
probe=probe.replace("scope='all logical declaration payloads at first cvc5 inline_trivial entry'",
 "scope='all first-entry logical declarations and every nonempty Hsdecl weak-table slot'")
assert 'table_roots=read_table_state()' in probe
(ROOT/'probe.py').write_text(probe)
run=(ROOT/'run.py').read_text().replace(OLD,str(ROOT))
run=run.replace('First Input_Is_Valid cvc5 inline entry captured;', 'Complete Hsdecl state at first Input_Is_Valid cvc5 inline entry captured;')
(ROOT/'run.py').write_text(run)
managed=(ROOT/'managed.py').read_text().replace('First Input_Is_Valid cvc5 inline_trivial entry graph; read-only debugger; no printer/solver request; one-pair diagnostic',
 'Capture previously missing complete Hsdecl representative table at first Input_Is_Valid cvc5 inline entry; new state input beyond accepted244roots; one read-only debugger run; no printer or solver request')
(ROOT/'managed.py').write_text(managed)
syms=json.loads((ROOT/'elf-symbols.json').read_text())
names=['camlWhy3__Decl__mk_decl_3622','camlWhy3__Hashcons__hashcons_412','camlWhy3__Hashcons__Make_433','camlStdlib__Weak__create_584','camlStdlib__Weak__find_or_781','caml_ephemeron_create','caml_ephemeron_get_key']
plan['table_observer']={'symbols':{n:syms[n] for n in names},'module':'camlWhy3__Decl','module_hsdecl_offset':704,'hashcons_table_field':4,'weak_record_fields':5,'ephemeron_first_key':2}
plan['scope']='one complete retained Hsdecl state at the exact first Input_Is_Valid/cvc5 inline_trivial entry; new missing input'
plan['file_identities']={p:m for p,m in plan['file_identities'].items() if not p.startswith(str(ROOT)) or Path(p).is_file()}
for p in list(plan['file_identities']):plan['file_identities'][p]=identity(p)
for name in ['prepare-state.py','table-observer.py','probe.py','static-table-disassembly.txt']:
 plan['file_identities'][str(ROOT/name)]=identity(ROOT/name)
for p in ROOT.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
(ROOT/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print('Prepared the single missing-state capture; no target has run.')
