"""Offline decoder fixture: exact offsets, empty arrays, live/dead slots, failures."""
from pathlib import Path
import struct,json,hashlib,tempfile
source=Path(__file__).with_name('shared-observer.py').read_text()
class Memory:
 def __init__(self):self.mem={};self.next=0x100000;self.syms={};self.codes={}
 def write(self,a,b):
  for i,v in enumerate(b):self.mem[a+i]=v
 def data(self,a,n):
  assert n>0,'zero-byte read'
  return bytes(self.mem[a+i] for i in range(n))
 def u64(self,a):return struct.unpack('<Q',self.data(a,8))[0]
 def block(self,fields,tag=0):
  a=self.next;self.next+=(len(fields)+1)*8;self.write(a,struct.pack('<Q',(len(fields)<<10)|tag))
  self.write(a+8,struct.pack('<'+'Q'*len(fields),*fields));return a+8
 def code(self,name):
  a=self.next;self.next+=64;b=bytes((len(self.codes),))*32;self.write(a,b);self.syms[name]=a;self.codes[name]={'first32':b.hex()};return a
 def module(self,name,fields):p=self.block(fields);self.syms[name]=p;return p
 def slot(self,p,i,v):self.write(p+i*8,struct.pack('<Q',v))
def fixture(out):
 m=Memory();idcode=m.code('camlWhy3__Ident__fun_6183');hcode=m.code('camlWhy3__Hashcons__hashcons_412');pcode=m.code('camlWhy3__Hcpt__hashcons_655')
 none=0x80000;m.syms['caml_ephe_none']=0x80010;m.write(0x80010,struct.pack('<Q',none))
 ir=m.block([2001]);ic=m.block([idcode,0x100000000000005,ir],247);im=m.module('camlWhy3__Ident',[1]*30);m.slot(im,29,ic)
 def weak():
  key=m.block([1,3]);empty=m.block([1,none],251);bucket=m.block([1,none,key,none],251)
  ha=m.block([1,1]);he=m.block([]);outer=m.block([bucket]+[empty]*6);hashes=m.block([ha]+[he]*6)
  table=m.block([outer,hashes,15,1,1]);ref=m.block([401]);cl=m.block([hcode,1,1,ref,table,1],247)
  return m.block([cl,1,1,1])
 for name,off,n in [('camlWhy3__Ty',664,84),('camlWhy3__Theory',752,95),('camlWhy3__Task',472,60)]:
  mod=m.module(name,[1]*n);m.slot(mod,off//8,weak())
 key=m.block([3,1,1]);e=m.block([1,key,key],251);node=m.block([1,e,1]);outer=m.block([node]+[1]*15)
 table=m.block([3,outer,1,33]);ref=m.block([99]);hc=m.block([pcode,1,1,table,ref],247);fields=[1]*56;fields[3:6]=[table,ref,hc]
 mm=m.block(fields);s=m.block([mm]+[1]*31);m.slot(m.syms['camlWhy3__Task'],51,s)
 env=dict(PLAN={'shared_observer':{'symbols':m.codes}},address=lambda n:m.syms[n],data=m.data,u64=m.u64,struct=struct,json=json,OUT=out,SUMMARY={},decode_tagged=lambda n:(n-(1<<64) if n>=1<<63 else n)>>1,identity=lambda p:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 exec(source,env);return m,env,ir,table
with tempfile.TemporaryDirectory() as td:
 m,e,ir,table=fixture(Path(td));r=e['read_shared_state']()
 assert r['ident']['counter']['decoded']==1000
 assert all(x['counter']['decoded']==200 and x['allocated_key_slots']==2 and x['nonempty_key_slots']==1 for x in r['hashcons'].values())
 assert r['Task.Stdecl']['counter']['decoded']==49 and r['Task.Stdecl']['size']==1
 m.slot(ir,0,(1<<64)-1)
 try:e['read_shared_state']()
 except AssertionError:pass
 else:raise AssertionError('negative counter accepted')
 m.slot(ir,0,2001);m.slot(table,0,5)
 try:e['read_shared_state']()
 except AssertionError:pass
 else:raise AssertionError('omitted ephemeron node accepted')
print('PASS: private ref/closure/module offsets, all auxiliary routes, empty arrays, sentinel/live slots, negative-counter and size-rejection fixtures')
