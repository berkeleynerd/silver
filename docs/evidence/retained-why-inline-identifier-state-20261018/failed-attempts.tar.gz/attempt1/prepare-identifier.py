"""Relocate retained capture and add one read-only immediate-state observer."""
from pathlib import Path
import json,hashlib,shutil,ast
ROOT=Path(__file__).resolve().parent
OLD=Path('/tmp/silver-why-inline-state-capture2-20261018')
def identity(p):
 b=Path(p).read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
plan=json.loads((OLD/'plan.json').read_text().replace(str(OLD),str(ROOT)))
case=plan['inputs'][0];cwd=Path(case['cwd']);cwd.mkdir();(cwd/'temp').mkdir()
for name in [case['argv'][-1],'why3.conf']:shutil.copy2(ROOT/'input'/name,cwd/name)
for p in [ROOT/'input'/'why3.conf',ROOT/'overlay'/'why3.conf',cwd/'why3.conf']:
 p.write_text(p.read_text().replace(str(OLD),str(ROOT)))
(ROOT/'driver-resolution.json').write_text((OLD/'driver-resolution.json').read_text().replace(str(OLD),str(ROOT)))
probe=(OLD/'probe.py').read_text().replace(str(OLD),str(ROOT))
marker='# Existing entry observer, extended to complete table roots.'
assert probe.count(marker)==1
probe=probe.replace(marker,(ROOT/'shared-observer.py').read_text()+'\n'+marker)
assert probe.count('table_roots=read_table_state()')==1
probe=probe.replace('table_roots=read_table_state()','read_shared_state()\n   table_roots=read_table_state()')
(ROOT/'probe.py').write_text(probe)
(ROOT/'run.py').write_text((OLD/'run.py').read_text().replace(str(OLD),str(ROOT)))
managed=(OLD/'managed.py').read_text()
a=managed.index(" '--reason',");b=managed.index(" '--workspace',",a)
managed=managed[:a]+" '--reason','Capture missing private Ident counter and immediate Hashcons/Hcpt state at same first Input_Is_Valid/cvc5 inline entry; preserve input graph and complete Hsdecl join; one read-only debugger worker; no inline, print or solver request',\n"+managed[b:]
(ROOT/'managed.py').write_text(managed)
syms=json.loads((ROOT/'elf-symbols.json').read_text())
names=['camlWhy3__Ident__entry','camlWhy3__Ident__fun_6183','camlWhy3__Ty__entry','camlWhy3__Theory__mk_tdecl_3155','camlWhy3__Task__mk_task_2047','camlWhy3__Task__entry','camlWhy3__Hcpt__MakeMap_1085','camlWhy3__Hcpt__hashcons_655','camlWhy3__Hcpt__fun_2952','camlWhy3__Hashcons__Make_433','camlWhy3__Hashcons__hashcons_412']
plan['shared_observer']={'symbols':{n:syms[n] for n in names},'ident_module_offset':232,'ident_closure_ref_field':2,
 'hashcons_module_offsets':{'Ty.Hsty':664,'Theory.Hstdecl':752,'Task.Hstask':472},
 'Task.Stdecl_module_offset':408,'Stdecl_M_field':0,'M_table_field':3,'M_nextid_field':4,'M_hashcons_field':5}
plan['scope']='private identifier counter plus immediate shared state at exact retained entry; no family invariance claim'
plan['file_identities']={p:m for p,m in plan['file_identities'].items() if not p.startswith(str(ROOT)) or Path(p).is_file()}
for p in list(plan['file_identities']):plan['file_identities'][p]=identity(p)
for name in ['shared-observer.py','prepare-identifier.py','static-identifier-disassembly.txt']:
 plan['file_identities'][str(ROOT/name)]=identity(ROOT/name)
for p in ROOT.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
(ROOT/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print('Prepared; no target executed.')
