"""One managed first-inline observation; --print only emits the exact command."""
from pathlib import Path
import json,subprocess,sys,shlex
ROOT=Path(__file__).resolve().parent
REPO=Path('/home/canto/src/github.com/berkeleynerd/silver')
plan=json.loads((ROOT/'plan.json').read_text())
cmd=['python3',str(REPO/'scripts/dev.py'),'tool','--task','#119','--jobs','1',
 '--reason','Missing Ident counter capture after two diagnosed auxiliary decoder failures; all raw reads flushed before interpretation; core counter graph and Hsdecl persisted before optional raw auxiliary traversal; offline signature constructor sharing cycle and replay fixtures passed; one worker no inline print or solver',
 '--workspace',str(ROOT)]
paths=set(plan['file_identities'])|{str(ROOT/n) for n in ['managed.py','run.py','plan.json','driver-resolution.json']}
paths.add(plan['gdbroot']+'/usr/bin/gdb')
for p in sorted(paths):cmd+=['--input',p]
cmd+=['--','python3',str(ROOT/'run.py')]
if '--print' in sys.argv:print(shlex.join(cmd))
else:raise SystemExit(subprocess.call(cmd,cwd=REPO))
