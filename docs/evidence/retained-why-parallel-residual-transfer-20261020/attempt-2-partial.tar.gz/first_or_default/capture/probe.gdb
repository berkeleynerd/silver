set pagination off
set confirm off
set auto-load off
set debuginfod enabled off
set startup-with-shell off
set disable-randomization off
set breakpoint always-inserted on
set language c
python
import gdb,json
root='/tmp/silver-r53-20261020-a2'
COLLECTOR_ROOT='/home/canto/src/github.com/berkeleynerd/silver/tmp/cvc5-quiet-route/docs/evidence/retained-why-parallel-residual-transfer-20261020/collector'
CAPTURE_ROOT=root
plan=json.load(open(root+'/plan.json'))
CASE_INDEX=0
case=plan['inputs'][CASE_INDEX]
gdb.execute('unset environment')
for k,v in case['environment'].items():gdb.execute('set environment '+k+'='+v)
end
starti
python
exec(open(COLLECTOR_ROOT+'/probe.py').read())
end
continue
python
finish_capture()
end
kill
quit
