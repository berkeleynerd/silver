from pathlib import Path
import json, os, resource, subprocess
base=Path(__file__).resolve().parent.parent
i=base/'inputs';o=base/'outputs'
resource.setrlimit(resource.RLIMIT_STACK,(16*1024*1024,resource.getrlimit(resource.RLIMIT_STACK)[1]))
probe=subprocess.run([str(o/'bin/admission_probe')],text=True,capture_output=True,timeout=120)
values=dict(line.split(':',1) for line in probe.stdout.splitlines() if line.startswith('case_'))
cases=json.loads((i/'cases.json').read_text())
results=[];failures=[]
for c in cases:
    d=i/c['label'];out=o/c['label'];out.mkdir(exist_ok=True)
    command=['gnatmake','-q','-c','-u','-j2','-gnat2022','-gnata','-gnato','-gnatdM','-D',str(out),'-I'+str(d),'-I/home/canto/src/github.com/berkeleynerd/silver/tmp/packages-416-native/src',str(d/'main.adb')]
    r=subprocess.run(command,cwd=out,text=True,capture_output=True,timeout=60)
    accepted=values.get(c['label'])=='TRUE'
    result={'label':c['label'],'name':c['name'],'command':command,'analyzer_accepted':accepted,'expected_accepted':c['accepted'],'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'expected_frontend_success':c['frontend']}
    if accepted!=c['accepted'] or (r.returncode==0)!=c['frontend']:
        failures.append(result);print(json.dumps(result),flush=True)
    results.append(result)
(o/'results.json').write_text(json.dumps({'probe_stdout':probe.stdout,'probe_stderr':probe.stderr,'probe_returncode':probe.returncode,'affinity':sorted(os.sched_getaffinity(0)),'cases':results,'failures':failures},indent=2)+'\n')
print(len(cases),'cases;',len(failures),'mismatches; affinity',sorted(os.sched_getaffinity(0)),flush=True)
raise SystemExit(int(probe.returncode!=0 or bool(failures)))
