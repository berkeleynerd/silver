from pathlib import Path
import json, os, subprocess
base = Path(__file__).resolve().parent.parent
out = base / 'outputs'
command = ['gcc', '-c', '-gnat2022', '-gnatc', '-gnatS', str(base / 'inputs/standard_probe.adb'), '-o', str(out / 'standard_probe.o')]
result = subprocess.run(command, cwd=out, capture_output=True, text=True)
(out / 'standard.stdout').write_text(result.stdout)
(out / 'standard.stderr').write_text(result.stderr)
(out / 'standard-result.json').write_text(json.dumps({'command':command, 'returncode':result.returncode, 'affinity':sorted(os.sched_getaffinity(0))}, indent=2)+'\n')
print(result.returncode, result.stdout, result.stderr)
raise SystemExit(result.returncode)
