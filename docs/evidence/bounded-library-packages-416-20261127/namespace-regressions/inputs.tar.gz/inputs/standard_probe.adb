procedure Standard_Probe is begin null; end Standard_Probe;
