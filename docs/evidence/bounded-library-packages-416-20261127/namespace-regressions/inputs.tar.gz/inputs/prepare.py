from pathlib import Path
import importlib, json, sys
root=Path(__file__).resolve().parents[3]
sys.path.insert(0, str(root))
m=importlib.import_module('tests.test_library_packages')
cases=[]
def collect(self, source, expected=0, *, specification=m.SPEC, body=m.BODY):
    label=f'case_{len(cases):02}'
    cases.append(dict(label=label,name=self.specification.stem,spec=specification.decode(),body=body.decode(),main=source.decode(),accepted=expected==0,frontend=expected==0))
m.LibraryPackageTests.check=collect
for method in ('test_standard_package_identities_are_excluded_before_compilation', 'test_standard_itself_and_character_image_names_remain_package_identities','test_package_identity_hides_each_use_visible_runtime_operation'):
    test=m.LibraryPackageTests(method)
    test.setUp()
    getattr(test,method)()
    test.doCleanups()
for name in ['Root_Integer','Root_Real','Universal_Integer','Universal_Real','Universal_Fixed','Universal_Access']:
    cases.append(dict(label=f'case_{len(cases):02}',name=name.lower(),spec=f'package {name} is pragma SPARK_Mode(On);procedure Noop;end {name};',body=f'package body {name} is pragma SPARK_Mode(On);procedure Noop is begin null;end Noop;end {name};',main=f'with {name};procedure Main is pragma SPARK_Mode(On);begin {name}.Noop;end Main;',accepted=True,frontend=True))
i=Path(__file__).resolve().parent
for c in cases:
    d=i/c['label'];d.mkdir(exist_ok=True)
    for filename,key in ((c['name']+'.ads','spec'),(c['name']+'.adb','body'),('main.adb','main')):
        (d/filename).write_text(c[key])
(i/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
original=Path('/home/canto/src/github.com/berkeleynerd/silver/tmp/open-pr-reviews-20261127/pr424-visibility/inputs/admission_probe.adb').read_text()
start=original.index('\nbegin\n   Check')
quote=lambda s:'"'+s.replace('"','""')+'"'
checks=['   Check ('+', '.join(quote(c[k]) for k in ('label','spec','body','main'))+');' for c in cases]
(i/'admission_probe.adb').write_text(original[:start]+'\nbegin\n'+'\n'.join(checks)+'\nend Admission_Probe;\n')
print(len(cases),'cases generated')
