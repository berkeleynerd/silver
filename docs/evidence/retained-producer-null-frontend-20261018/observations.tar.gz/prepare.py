from pathlib import Path
import hashlib, json

root = Path(__file__).resolve().parent
repo = Path('/home/canto/src/github.com/berkeleynerd/silver/tmp/retained-tool-capacity')
prior = repo/'docs/evidence/retained-main-semantics-20261018/fixed-capture'
observed = Path('/tmp/silver-producer-parent-tapped3-20261018/retained-temporaries')
install = Path('/home/canto/src/github.com/berkeleynerd/silver/.tools/linux-x86_64/alire/cache/releases/gnatprove_16.1.0_82528bef/libexec/spark')
runtime = install/'lib/gcc/x86_64-pc-linux-gnu/16.1.0'
source = root/'main.adb'
source.write_bytes((repo/'samples/null.adb').read_bytes())
(root/'temporary').mkdir(exist_ok=True)
for name in ('static-all-tables.json','decrease-hooks.json'):
    (root/name).write_bytes((prior/name).read_bytes())
counter = (prior/'counter-all.py').read_text()
counter = counter.replace("root=Path('/tmp/silver-frontend-fixed-counter-20261018')", "root=Path("+repr(str(root))+")\ndest=Path(gdb.current_progspace().filename).parent if False else Path(__file__).parent")
# The runner supplies the per-phase output directory as a Python global.
counter = counter.replace("dest=Path(gdb.current_progspace().filename).parent if False else Path(__file__).parent", "dest=Path(capture_directory)")
counter = counter.replace("root/'all-miss'", 'dest')
counter = counter.replace("Phase('why__gen__names__free','before_symbol_free',True)", "Phase('gnat2why__driver__gnat_to_why','producer_entry');Phase('why__gen__names__free','before_symbol_free');Phase('namet__finalize','before_name_finalize',True)")
assert "before_name_finalize" in counter and "root/'all-miss'" not in counter
(root/'counter.py').write_text(counter)
cases=[]
for phase, option_name in [('phase1','0-00af4613.tmp'),('phase2','21-d471e07c.tmp')]:
    dest=root/phase;dest.mkdir(exist_ok=True)
    opts=json.loads((observed/option_name).read_bytes())
    if 'why3_dir' in opts:opts['why3_dir']=str(dest)+'/'
    options=dest/'options.tmp';options.write_text(json.dumps(opts,separators=(',',':'))+'\n')
    config=dest/'GNAT-TEMP-000002.TMP';config.write_bytes((observed/'13-GNAT-TEMP-000002.TMP').read_bytes())
    mapping=dest/'GNAT-TEMP-000003.TMP';mapping.write_text(f'main%b\nmain.adb\n{source}\nsystem%s\nsystem.ads\n{runtime}/adainclude/system.ads\n')
    objects=dest/'GNAT-TEMP-000004.TMP';objects.write_text(str(dest)+'\n')
    args=[str(install/'bin/gnat2why'),'-c','-x','ada','-gnatA','-gnat2022','-gnata','-gnato','-Wno-free-nonheap-object','-gnatc','-gnates='+str(options)]
    if phase=='phase1':args.append('-gnatis')
    args += ['-gnatec='+str(config),'-gnatem='+str(mapping),str(source),'-o','main~1.ali' if phase=='phase1' else 'main~1.spark','-gnateI1']
    if phase=='phase2':args.append('-gnateO='+str(objects))
    assert len(args)==18
    env=dict(PATH=str(install/'bin')+':/usr/bin:/bin',LC_ALL='C',TMPDIR=str(root/'temporary'),ADA_INCLUDE_PATH=str(runtime/'adainclude'),ADA_OBJECTS_PATH=str(runtime/'adalib'))
    cases.append(dict(name=phase,argv=args,cwd=str(dest),environment=env))
files=[source,root/'counter.py',root/'static-all-tables.json',root/'decrease-hooks.json',install/'bin/gnat2why',runtime/'adainclude/system.ads',runtime/'adalib/system.ali']
files += [p for c in cases for p in Path(c['cwd']).iterdir() if p.is_file()]
def identity(p):
    raw=p.read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
plan=dict(scope='exact selected indexed null light frontend phases through final name output; all-miss range observation; no backend/solver',cases=cases,inputs={str(p):identity(p) for p in files},prior_counter_sha256=identity(prior/'counter-all.py'),endpoint='before_name_finalize')
(root/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'cases':len(cases),'inputs':len(files),'argv_count':len(args),'root':str(root)}))
