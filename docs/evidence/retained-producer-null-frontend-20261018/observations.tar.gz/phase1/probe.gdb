set pagination off
set breakpoint always-inserted on
set confirm off
set auto-load off
set debuginfod enabled off
set startup-with-shell off
set disable-randomization off
unset environment LD_LIBRARY_PATH
set language c
starti
python
capture_directory = '/tmp/silver-null-light-20261018/phase1'
exec(open('/tmp/silver-null-light-20261018/counter.py').read())
end
continue
python
final()
end
continue
quit
