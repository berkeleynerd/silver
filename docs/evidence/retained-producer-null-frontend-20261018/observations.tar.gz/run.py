from pathlib import Path
import hashlib,json,os,signal,subprocess,time,shutil

root=Path(__file__).resolve().parent
plan=json.loads((root/'plan.json').read_bytes())
gdbroot=Path('/tmp/silver-capacity-debugger-20261018/root')
def ident(p):
    b=Path(p).read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
assert all(ident(p)==v for p,v in plan['inputs'].items())
results=[]
for case in plan['cases']:
    dest=Path(case['cwd'])
    if case['name']=='phase2':
        shutil.copy2(root/'phase1/main~1.ali',dest/'main~1.ali')
    script='''set pagination off
set breakpoint always-inserted on
set confirm off
set auto-load off
set debuginfod enabled off
set startup-with-shell off
set disable-randomization off
unset environment LD_LIBRARY_PATH
set language c
starti
python
capture_directory = CAPTURE
exec(open(COUNTER).read())
end
continue
python
final()
end
continue
quit
'''.replace('CAPTURE',repr(str(dest))).replace('COUNTER',repr(str(root/'counter.py')))
    (dest/'probe.gdb').write_text(script)
    env=dict(case['environment'],LD_LIBRARY_PATH=str(gdbroot/'usr/lib/x86_64-linux-gnu'),DEBUGINFOD_URLS='')
    cmd=[str(gdbroot/'usr/bin/gdb'),'-nx','-q','-batch','-x',str(dest/'probe.gdb'),'--args',*case['argv']]
    start=time.monotonic()
    p=subprocess.Popen(cmd,cwd=dest,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
    timed_out=False
    try:out,_=p.communicate(timeout=60)
    except subprocess.TimeoutExpired:
        timed_out=True;os.killpg(p.pid,signal.SIGTERM);out,_=p.communicate()
    (dest/'probe.log').write_text(out)
    row=dict(name=case['name'],command=cmd,duration_seconds=time.monotonic()-start,returncode=p.returncode,timed_out=timed_out)
    results.append(row)
    (root/'result.json').write_text(json.dumps(dict(cases=results),indent=2)+'\n')
    assert p.returncode==0 and not timed_out, row
    assert 'exited normally' in out, out[-2000:]
    x=json.loads((dest/'pool-counters.json').read_bytes())
    assert x['phases'][-1]['phase']=='before_name_finalize'
    assert any(p['phase']=='producer_entry' for p in x['phases'])
    assert x['backend_calls']==x['unexpected_collect']==0
    assert x['coherence_failures']==[] and x['cache_calls']['real']==0
    assert len(x['queries'])==len(x['returns'])==x['range_mutations']
    row['range_queries']=len(x['queries']);row['table_positions']=len(x['phases'][-1]['pools'])
    print(json.dumps(row),flush=True)
assert all(ident(p)==v for p,v in plan['inputs'].items())
spark=json.loads((root/'phase2/main~1.spark').read_bytes())
assert spark['proof']==spark['flow']==[]
result=dict(cases=results,retained_inputs_unchanged=True,Main_VCs=0,completed=True)
(root/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
