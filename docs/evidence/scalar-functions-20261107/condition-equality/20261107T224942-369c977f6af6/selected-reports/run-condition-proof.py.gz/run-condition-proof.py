from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
from scripts.platforms import native_layout
from scripts.run_history import ManagedRun, registry

host = native_layout(root)
name = sys.argv[1]
assert name in ('Read_Primary_Into', 'Read_Relation_Into')
output = root / 'tmp/condition-proof-repair'
output.mkdir(exist_ok=True)
project = output / 'probe.gpr'
project.write_text('''with "../../proof/silver_proof_containers.gpr";
project Probe is
   for Source_Dirs use ("../../src");
   for Object_Dir use "obj";
   package Compiler is
      for Default_Switches ("Ada") use ("-gnat2022", "-gnata", "-gnato", "-g");
   end Compiler;
end Probe;
''')
source = root / 'src/silver_output_profile.adb'
lines = source.read_text().splitlines()
starts = [i for i, line in enumerate(lines, 1) if line == '   procedure ' + name]
assert len(starts) == 2, starts
first, body = starts
last = next(i for i, line in enumerate(lines, 1) if i > body and line == '   end ' + name + ';')
if name == 'Read_Primary_Into':
    branch = next(i for i, line in enumerate(lines, 1) if body < i < last and line.strip() == 'elsif Boolean_Atom_After (Text, Context, Position) /= 0 then')
    added = branch + 4
    assert lines[added - 1].strip() == 'pragma Assert (Static => Result = Primary_Model (Text, Context, Position, Facts, Initials => Initials));'
    endpoint = next(i for i, line in enumerate(lines, 1) if first < i < body and 'Post =>' in line)
    expected = [('VC_ASSERT', added), ('VC_POSTCONDITION', endpoint)]
else:
    branch = next(i for i, line in enumerate(lines, 1) if body < i < last and line.strip() == 'elsif Context.Pure then')
    added = branch + 2
    assert lines[added - 1].strip() == 'pragma Assert (Static => Result = Expected);'
    endpoints = [i for i, line in enumerate(lines, 1) if body < i < last and line.strip() == 'pragma Assert (Static => Result = Relation_Model (Text, Context, Position, Facts, Initials => Initials));']
    assert len(endpoints) == 1, endpoints
    endpoint = endpoints[0]
    expected = [('VC_ASSERT', added), ('VC_ASSERT', endpoint)]
selection = output / (name + '.lines')
selection.write_text(''.join('silver_output_profile.adb:' + str(line) + '\n' for line in (added, endpoint)))
limits = ['--limit-subp=silver_output_profile.adb:' + str(first), '--limit-lines=' + str(selection)]
events_path = registry(host) / 'runs/20261107T181811-5b7564ac5afc/events.jsonl'
events = [json.loads(line) for line in events_path.read_text().splitlines()]
toolchain = next(event['inputs']['tools'] for event in events if event['event'] == 'prepared')

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

for tool, value in toolchain.items():
    assert digest(value['path']) == value['sha256'], tool
selected_inputs = sorted((root / 'src').glob('*.ad?')) + sorted((root / 'scripts').glob('*.py')) + [root / 'proof/silver_proof_containers.gpr', Path(__file__), project, selection]
inputs = {str(path): digest(path) for path in selected_inputs}
env = dict(os.environ)
for key in ('ADA_INCLUDE_PATH', 'ADA_OBJECTS_PATH', 'GPR_PROJECT_PATH', 'GPR_RUNTIME_PATH', 'GPR_CONFIG', 'GPR_TOOL'):
    env.pop(key, None)
env['PATH'] = os.pathsep.join([str(Path(toolchain[tool]['path']).parent) for tool in ('gcc', 'gprbuild', 'gnatprove')] + ['/usr/bin', '/bin'])
env['GNATPROVE_ALIRE_PREFIX'] = str(Path(toolchain['gnatprove']['path']).parent.parent)
reports = output / 'obj/explore/condition-repair/gnatprove'
cache = output / 'cache'
command = [toolchain['gnatprove']['path'], '-P', str(project), '-u', 'silver_output_profile.adb', '--mode=all', '--report=all', '--warnings=continue', '--checks-as-errors=on', '--level=2', '--prover=cvc5,z3,altergo', '--timeout=30', '--subdirs=explore/condition-repair', *limits, '--memcached-server=file:' + str(cache), '-XSILVER_HOST=' + host.key, '-j6']
scope = ['condition-repair:' + name + ':new-assertion-and-original-endpoint']
reason = 'Test the two authorized branch-local Static equalities on baseline 96950ce3e8. Select this worker plus its added assertion and original failed endpoint together; preserve every contract, domain, original assertion and 30-second prover settings. Six workers in isolated output/cache; audit actual selected checks and session roots.'
with ManagedRun(host, 'tool-gnatprove', command,
                {'scope': scope, 'inputs_sha256': inputs, 'tools': toolchain},
                [output, root / '.silver' / host.key / 'proof-containers/obj/explore/condition-repair'],
                workers=6, task='#298', reason=reason, evidence=[reports], failure_reports=[reports]) as run:
    print('Managed run:', run.run_id, flush=True)
    cache.mkdir(exist_ok=True)
    run.prepare({'scope': scope, 'inputs_sha256': inputs, 'tools': toolchain, 'limits': limits, 'expected_checks': expected})
    log = run.directory / 'native.log'
    run.evidence.append(log)
    run.event('command', command=command, cwd=str(output))
    print('Native log:', log, flush=True)
    with log.open('w') as stream:
        result = subprocess.run(command, cwd=output, env=env, stdout=stream, stderr=subprocess.STDOUT, pass_fds=run.pass_fds)
    print(log.read_text(), flush=True)
    assert {str(path): digest(path) for path in selected_inputs} == inputs, 'source changed'
    for tool, value in toolchain.items():
        assert digest(value['path']) == value['sha256'], tool
    archive = run.directory / 'selected-reports'
    archive.mkdir(exist_ok=True)
    entity = 'silver_output_profile__' + name.lower()
    artifacts = list(reports.glob('*.spark')) + [reports / 'gnatprove.out', reports / 'gnatprove.sarif', reports / (entity + '.gnat-json')]
    artifacts += list((reports / entity).glob('*'))
    for artifact in artifacts:
        if artifact.is_file():
            shutil.copy2(artifact, archive / artifact.name)
    for artifact in [source, project, selection, Path(__file__)]:
        shutil.copy2(artifact, archive / artifact.name)
    run.evidence.append(archive)
    failures = run.unresolved_obligations()
    report = json.loads((reports / 'silver_output_profile.spark').read_text())
    checks = [{key: value for key, value in check.items() if key != 'check_tree'} for check in report['proof']]
    selected_checks = [check for check in checks if (check['rule'], check['line']) in expected]
    present = {(check['rule'], check['line']) for check in selected_checks}
    assert present == set(expected), ('missing expected checks', expected, present)
    assert len(selected_checks) == len(expected), ('unexpected duplicate checks', selected_checks)
    session = ET.parse(reports / entity / 'why3session.xml').getroot()
    roots = session.findall('./file/theory/goal')
    assert roots, 'empty session'
    session_goals = [{'name': goal.get('name'), 'proved': goal.get('proved')} for goal in roots]
    audit = {'run_id': run.run_id, 'expected_checks': expected, 'entities': report['entities'], 'selected_checks': selected_checks, 'all_checks': checks, 'session_roots': session_goals, 'session_goal_count': len(session.findall('.//goal'))}
    (archive / 'scope-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
    print(json.dumps(audit, indent=2), flush=True)
    valid = all(check['severity'] == 'info' and check.get('how_proved') in ('prover', 'trivial') for check in selected_checks)
    valid = valid and all(goal.get('proved') == 'true' for goal in roots)
    if result.returncode or failures or not valid:
        run.finish('failure', returncode=result.returncode, failure_keys=failures)
        raise RuntimeError('focused condition proof failed')
    run.finish('success', returncode=0)
