# Remaining native parser obligations — 2026-11-07

Bounded read-only diagnosis for authorized #298, selected inherited GPT-6 Astra / Extra High. Runtime model/effort and token/cost measurements are unavailable. No native/Lean run, source edit, cache write, GitHub action or subagent was used. Only this scratch report was written. No effort escalation is indicated by the present evidence.

## Exact inputs and live-run boundary

The inspected managed run is `20261107T181811-5b7564ac5afc`, under main checkout `.git/silver-runs/linux-x86_64/78cde64c3e47f2cb/runs/`. Its events record eight workers and `gnatprove --mode=all --report=all --level=2 --prover=cvc5,z3,altergo --timeout=30`, subdirectory `explore/function-parser-safety`. The prepared fingerprint is `bd7f3d775d4392cffc54953382bdc1ed6cb00a8be41b0770730b479e8504a098`. At inspection the event stream had reached `native-tool` without a final outcome; `native.log` had no diagnostic for either worker. Therefore this report describes saved session leaves, not a completed managed-run result.

The run's recorded `src/silver_output_profile.adb` SHA-256, `117b2b03ec738aa5c2bc21e29565a1dca6e86f15614410925f75cab7a583c9ac`, exactly matches the frozen file in `tmp/scalar-functions-298`, whose HEAD is `2603f6a800428d0da6250bb782ef231d421d2620`.

The comparison candidate is `tmp/scalar-functions-source-integration-298`, HEAD `96950ce3e81070d9d6ff524e108fd34e97c8dcc8`; its native output file SHA-256 is `4d89527f3f9449b818622cf77f64c57b2e4812b712a268f49cbc7a257aae92c0`.

## Two unresolved split leaves

All session paths below are relative to the frozen worktree's `.silver/linux-x86_64/compiler/obj/explore/function-parser-safety/gnatprove/`.

| Worker | Split goals | Sole unresolved split leaf | Source check |
| --- | --- | --- | --- |
| `Read_Primary_Into` | 470 | `def'vc.469` | `GP_Check:1976:VC_POSTCONDITION:silver_output_profile.adb:3655:28`, specifically the Static `Result = Primary_Model(...)` conjunct declared at line 3657 |
| `Read_Relation_Into` | 759 | `def'vc.731` | `GP_Check:2121:VC_ASSERT:silver_output_profile.adb:4121:32`, terminal `Result = Relation_Model(...)` assertion |

Each unresolved split leaf has Alt-Ergo, CVC5 and Z3 attempts recorded as **timeout** at 30 seconds. Primary's `introduce_premises` child `def'vc.469.0` additionally records CVC5_CE timeout at 10 seconds. Relation's child `def'vc.731.0` had no recorded proof attempt. Neither provides a counterexample. Every other first-level split goal in each saved session is marked proved; an unproved session root does not mean its other leaves failed.

The shape table was mapped to XML goals in preorder: Primary has 495 shape strings followed by 472 goal mappings, and Relation has 810 strings followed by 761 mappings. This identifies:

- Primary `.469`: shape `H492`, checksum `58d07549b6a81211d7fe485171738a73`; introduced goal `H491` is `bool_eq(Result, Primary_Model(Text, Context, Position, Facts, Initials)) = True`. Neighbor `.467` is proved flow validity and `.468` is proved result cursor range, confirming the failed leaf is the Static equality component.
- Relation `.731`: shape `H780`, checksum `4e09089c09de36792c0cc7eb90ec5713`; introduced goal `H779` is `bool_eq(Result, Relation_Model(Text, Context, Position, Facts, Initials)) = True`. Its merged branch premise `H778` includes `bool_eq(Result, Expected) = True` on a branch. Goal `.732` already assumes this terminal assertion, while `.758` is the subsequently proved Static postcondition. Thus the failing check is the line 4121 assertion, not the final postcondition.

The `.gnat-json` AST retains the source labels above. In the candidate the unchanged worker region is shifted by 18 lines: Primary's postcondition starts at 3673, Static conjunct 3675; Relation's assertion is at 4139.

## What the source and generated expressions establish

`Read_Relation_Into` has a new pure-context dispatch at frozen lines 4055–4056. It calls `Read_Boolean_Relation_Into` with the same `Text`, `Context`, `Position`, `Facts` and `Initials`. `Relation_Model` chooses that same callee at lines 3417–3418. The runtime pure branch has no local `Result = Expected` checkpoint, unlike its neighboring branches. This is a natural first localization point, but the merged failing shape does not prove it is the responsible branch.

`Read_Primary_Into`'s Boolean-atom branch at lines 3747–3750 writes the same cursor/facts aggregate selected by `Primary_Model` at lines 3325–3326. It lacks a local model-equality checkpoint. Parenthesized, Boolean-array and validity-call branches already contain explicit equality assertions. The position-zero and no-dynamic-context invalid exits also lack a direct model-equality checkpoint. The final failure alone does not select one of these paths.

I checked the endpoint model calls' generated arguments rather than attributing all equality failures to array extensionality. Primary's postcondition uses `temp___28413/28414` for Context/Facts; the earlier asserted model calls use `temp___28246/28247` and `temp___28364/28365`. These bindings all name the same worker Context/Facts inputs. Relation's postcondition and final-assertion pairs `temp___28826/28827` and `temp___28785/28786` likewise name the same inputs. This rules out a differing Context/Facts temporary binding at those endpoints.

The generated `Relation_Model` definition contains no string-literal symbols. `Primary_Model` uses the already named `Validity_Call_Word`; `Boolean_Atom_After`'s one shared definition contains the two true/false literal symbols (`Temp___String_Literal_6490` and `_6494`). No counterpart to the earlier three distinct array type-word symbols was identified here. This was a bounded symbol/argument inspection, not a complete normalization proof of every imperative branch.

The candidate's delta against the frozen source adds parser-function/formal array equality helpers, shares the three array type words, and adds the `Function_Body_At` metadata-growth precondition. It changes neither worker, their model bodies, nor `Lemma_Condition_Equality`. Those changes therefore do not directly repair either localized equality path. Solver behavior may vary with the compilation unit, so only fresh matching evidence can determine candidate discharge; the old failures cannot be attributed to the candidate as its result.

## Smallest discriminating next check

Keep the original worker contracts, all input domains, native execution and timeout settings. In an isolated authorized repair workspace, add only local Static assertions first:

1. After the `Context.Pure` call in `Read_Relation_Into`, assert `Result = Expected`. If that assertion fails, separately expose the selected model branch with `Same_Condition (Expected, Boolean_Relation_Model (Text, Context, Position, Facts, Initials))` and the existing worker postcondition. This distinguishes model-branch selection from transport of the callee result.
2. At `Read_Primary_Into`'s Boolean-atom exit, assert the exact existing Static postcondition expression `Result = Primary_Model (Text, Context, Position, Facts, Initials => Initials)`. If the final postcondition still fails while this local check passes, add the same branch-local check to the position-zero and no-dynamic-context invalid exits to locate the remaining join obligation.

Use a focused managed native proof of these two workers on the candidate plus that minimal diagnostic delta, retaining source hashes and the new leaf labels. Do not add another global equality helper merely because the old joined goals timed out. The existing checked `Lemma_Condition_Equality` is the next transport tool only if the localized evidence shows ordinary record equality must be converted to `Same_Condition`/logical identity. No timeout increase, contract weakening, narrowed domain, or assumption is proposed.

Exact first delta: after frozen line 4056 (candidate 4074), before the `else`, add `pragma Assert (Static => Result = Expected);`. After frozen line 3750 (candidate 3768), before `elsif Context.Dynamic_First = 0`, add `pragma Assert (Static => Result = Primary_Model (Text, Context, Position, Facts, Initials => Initials));`. Candidate line numbers are before inserting either assertion. The proof selection must include both new assertions and both original endpoints, either through both full worker scopes or a complete multi-line selection. A filtered endpoint proof that merely assumes an unchecked new assertion is insufficient.

This is an evidence-backed diagnostic patch proposal, not a validated repair. If the extra local checks all prove and only the joined equality remains, the next hypothesis is a missing stable logical identity across the join; inspect that new task before changing more source. Successful local assertions must not replace the worker's full required Static postcondition proof.

## Artifact fingerprints at 22:42 UTC

| Artifact | SHA-256 |
| --- | --- |
| `silver_output_profile__read_primary_into.gnat-json` | `6e0509dcf6424b72e9cfb450a98fdd117f5b133e5517791d49d44b995276f3d5` |
| `silver_output_profile__read_primary_into/why3session.xml` | `f2622d57be71ebb7f3a47c1c9698d80a8781bf74b4212c2e8f74c46fc065957c` |
| `silver_output_profile__read_primary_into/why3shapes` | `a25973114cd37a5aa4df3171cd6ba0caf2b35ac044f97240a6e7937e81897b41` |
| `silver_output_profile__read_relation_into.gnat-json` | `92ec0d7c8aa81f277a99335d9caf48785f0c3a8731a805198086ee350c2f002c` |
| `silver_output_profile__read_relation_into/why3session.xml` | `ababfb834e8de2f07f4303669c694186775d8c860ded9b12b3cd2128f738797f` |
| `silver_output_profile__read_relation_into/why3shapes` | `a580e4b2f3822976ecea7f5d6b7254a6b422661fe4fd8e36fb175e23dbe021e8` |
