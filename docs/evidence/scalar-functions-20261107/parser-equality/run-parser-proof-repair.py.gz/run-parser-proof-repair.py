from pathlib import Path
import hashlib
import json
import os
import subprocess
import shutil
import sys

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
from scripts.platforms import native_layout
from scripts.run_history import ManagedRun, registry

host = native_layout(root)
output = root / 'tmp/parser-proof-repair'
output.mkdir(exist_ok=True)
project = output / 'probe.gpr'
project.write_text('''with "../../proof/silver_proof_containers.gpr";
project Probe is
   for Source_Dirs use ("../../src");
   for Object_Dir use "obj";
   package Compiler is
      for Default_Switches ("Ada") use ("-gnat2022", "-gnata", "-gnato", "-g");
   end Compiler;
end Probe;
''')
source = root / 'src/silver_output_profile.adb'
lines = source.read_text().splitlines()
name = sys.argv[1]
first = next(i for i, line in enumerate(lines, 1) if line.startswith('   function ' + name + ' ') or line == '   function ' + name)
limit = '--limit-subp=silver_output_profile.adb:' + str(first)

events = [json.loads(line) for line in (registry(host) / 'runs/20261107T181811-5b7564ac5afc/events.jsonl').read_text().splitlines()]
toolchain = next(event['inputs']['tools'] for event in events if event['event'] == 'prepared')
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
for tool, value in toolchain.items():
    assert digest(value['path']) == value['sha256'], tool
selected = sorted((root / 'src').glob('*.ad?')) + [root / 'proof/silver_proof_containers.gpr', Path(__file__), project]
inputs = {str(path): digest(path) for path in selected}
env = dict(os.environ)
for key in ('ADA_INCLUDE_PATH', 'ADA_OBJECTS_PATH', 'GPR_PROJECT_PATH', 'GPR_RUNTIME_PATH', 'GPR_CONFIG', 'GPR_TOOL'):
    env.pop(key, None)
env['PATH'] = os.pathsep.join([str(Path(toolchain[tool]['path']).parent) for tool in ('gcc', 'gprbuild', 'gnatprove')] + ['/usr/bin', '/bin'])
env['GNATPROVE_ALIRE_PREFIX'] = str(Path(toolchain['gnatprove']['path']).parent.parent)
reports = output / 'obj/explore/parser-repair/gnatprove'
cache = output / 'cache'
command = [toolchain['gnatprove']['path'], '-P', str(project), '-u', 'silver_output_profile.adb', '--mode=all', '--report=all', '--warnings=continue', '--checks-as-errors=on', '--level=2', '--prover=cvc5,z3,altergo', '--timeout=30', '--subdirs=explore/parser-repair', limit, '--memcached-server=file:' + str(cache), '-XSILVER_HOST=' + host.key, '-j2']
reason = sys.argv[2]
with ManagedRun(host, 'tool-gnatprove', command,
                {'scope': ['parser-repair:' + name], 'inputs_sha256': inputs, 'tools': toolchain},
                [output, root / '.silver' / host.key / 'proof-containers/obj/explore/parser-repair'],
                workers=2, task='#298', reason=reason, evidence=[reports], failure_reports=[reports]) as run:
    print('Managed run:', run.run_id, flush=True)
    cache.mkdir(exist_ok=True)
    run.prepare({'scope': ['parser-repair:' + name], 'inputs_sha256': inputs, 'tools': toolchain, 'limit': limit})
    log = run.directory / 'native.log'
    run.evidence.append(log)
    run.event('command', command=command, cwd=str(output))
    print('Native log:', log, flush=True)
    with log.open('w') as stream:
        result = subprocess.run(command, cwd=output, env=env, stdout=stream, stderr=subprocess.STDOUT, pass_fds=run.pass_fds)
    print(log.read_text(), flush=True)
    assert {str(path): digest(path) for path in selected} == inputs, 'source changed'
    for tool, value in toolchain.items():
        assert digest(value['path']) == value['sha256'], tool
    archive = run.directory / 'selected-reports'
    archive.mkdir(exist_ok=True)
    for artifact in list(reports.glob('*.spark')) + [reports / 'gnatprove.out']:
        if artifact.exists():
            shutil.copy2(artifact, archive / artifact.name)
    for artifact in (reports / ('silver_output_profile__' + name.lower())).glob('*'):
        if artifact.is_file():
            shutil.copy2(artifact, archive / artifact.name)
    shutil.copy2(source, archive / source.name)
    run.evidence.append(archive)
    failures = run.unresolved_obligations()
    if result.returncode or failures:
        run.finish('failure', returncode=result.returncode, failure_keys=failures)
        raise RuntimeError('focused parser proof failed')
    run.finish('success', returncode=0)
