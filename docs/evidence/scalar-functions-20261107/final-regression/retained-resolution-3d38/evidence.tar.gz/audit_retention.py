"""Resolve retained/fresh applicability from bytes and evidence. No test/module execution."""
from pathlib import Path
import ast,collections,gzip,hashlib,json,re,subprocess,tarfile,datetime
OUT=Path(__file__).resolve().parent
REVIEW=OUT.parents[1];REG=REVIEW.parent/'scalar-functions-298';ROOT=REVIEW.parent/'scalar-functions-source-integration-298'
PRIOR=REVIEW/'tmp/regression-applicability-review-298';DELTA=REVIEW/'tmp/regression-delta-68c4-298'
EVID=ROOT/'docs/evidence/scalar-functions-20261107/final-regression';PACK=EVID/'repaired-compiler-policy-093645'
BASE='d396db2aeb498cd132bbe4b9f0ea3f0fb93687f8';GOV='f6308191545c1012d76132ae535977e55fd4f018'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def js(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,v):(OUT/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
cache={}
def digest(p):
 p=Path(p).resolve();s=p.stat();key=(str(p),s.st_size,s.st_mtime_ns)
 if key not in cache:
  h=hashlib.sha256()
  with p.open('rb') as f:
   for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
  assert (s.st_size,s.st_mtime_ns)==(p.stat().st_size,p.stat().st_mtime_ns),p
  cache[key]=h.hexdigest()
 return cache[key]
def blob(ref,p):return git('show',ref+':'+p)
target=git('rev-parse','HEAD').decode().strip()
roots=['src','proof','tests','scripts','samples','catalogue','rosetta','silver.gpr','alire.toml']
assert not git('diff','--name-only',GOV+'..'+target,'--',*roots)
assert not git('diff','--name-only','--',*roots)
changes=git('diff','--name-only',BASE+'..'+target,'--',*roots).decode().splitlines()
assert len(changes)==22 and [x for x in changes if not x.startswith('proof/')]==['src/silver_output_profile.adb']
tracked=git('ls-tree','-r','--name-only',target,'--',*roots).decode().splitlines()
actual_test_py=sorted(str(p.relative_to(ROOT)) for p in (ROOT/'tests').rglob('*.py'))
tracked_test_py=sorted(p for p in tracked if p.startswith('tests/') and p.endswith('.py'))
assert actual_test_py==tracked_test_py
# Byte-complete tracked source/test identity across exact target and regression checkout.
completed=OUT/'completed-byte-comparison.json'
retained_blob_hashes=None
if completed.exists():
 previous=js(completed);artifact=OUT/previous['artifact']
 assert digest(artifact)==previous['sha256'] and previous['completed']
 assert not git('diff','--name-only',previous['target']+'..'+target,'--',*roots)
 retained_blob_hashes={x['path']:x['sha256'] for x in js(artifact)}
 assert set(retained_blob_hashes)==set(tracked) and len(tracked)==previous['rows']
identities=[]
for p in tracked:
 t=retained_blob_hashes[p] if retained_blob_hashes is not None else sha(blob(target,p))
 a=digest(ROOT/p);b=digest(REG/p)
 assert t==a==b,p
 identities.append({'path':p,'sha256':t,'integration_equals_commit':True,'regression_equals_integration':True})
save('target-input-identities.json',identities)
mods={Path(p).stem:(p,ast.parse((ROOT/p).read_bytes())) for p in tracked_test_py if Path(p).name.startswith('test')}
classes={(m,n.name):(p,n) for m,(p,t) in mods.items() for n in t.body if isinstance(n,ast.ClassDef)}
def methods(m,c):
 p,n=classes[m,c];result={}
 for b in n.bases:
  if isinstance(b,ast.Name) and (m,b.id) in classes:result.update(methods(m,b.id))
 for f in n.body:
  if isinstance(f,(ast.FunctionDef,ast.AsyncFunctionDef)) and f.name.startswith('test'):
   result[f.name]={'path':p,'defining_class':c,'line':f.lineno,'ast_sha256':sha(ast.dump(f,include_attributes=False).encode())}
 return result
inventory=[]
for m,(p,t) in sorted(mods.items()):
 candidates={c:(m,c,m) for mm,c in classes if mm==m}
 assert not any(isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name=='load_tests' for n in t.body),m
 for n in t.body:
  if isinstance(n,ast.ImportFrom) and n.module and n.module.startswith('tests.'):
   imported=n.module.split('.')[-1]
   for a in n.names:
    if (imported,a.name) in classes:candidates[a.asname or a.name]=(imported,a.name,n.module)
 for _,(dm,dc,im) in sorted(candidates.items()):
  for name,entry in sorted(methods(dm,dc).items()):inventory.append({'id':im+'.'+dc+'.'+name,'discovered_in':m,**entry})
assert inventory==js(PRIOR/'independent-ast-inventory.json')
assert len(inventory)==len({x['id'] for x in inventory})==637
assert [x['id'] for x in inventory]==js(EVID/'test-input-census.json')['test_ids']
save('canonical-inventory.json',inventory)
# Account for import code dependencies without importing any project/test module.
repo_py={p for p in tracked if p.endswith('.py')}
imports={}
for p in repo_py:
 t=ast.parse((ROOT/p).read_bytes());deps=set()
 for n in ast.walk(t):
  names=[]
  if isinstance(n,ast.Import):names=[a.name for a in n.names]
  elif isinstance(n,ast.ImportFrom) and n.module:
   names=[n.module,*[n.module+'.'+a.name for a in n.names]]
  for name in names:
   for candidate in [name.replace('.','/')+'.py',name.replace('.','/')+'/__init__.py']:
    if candidate in repo_py:deps.add(candidate)
 imports[p]=deps
code_closures={}
for m,(p,_) in mods.items():
 found=set();pending=[p]
 while pending:
  q=pending.pop()
  if q not in found:found.add(q);pending.extend(imports[q]-found)
 if p in ['tests/test_lean_source.py','tests/test_lean_evidence.py','tests/test_lean_modules.py','tests/test_lean_run_history.py']:
  found.add('proof/generate_source_certificate.py')
 assert all(blob(BASE,q)==(ROOT/q).read_bytes() for q in found),p
 code_closures[p]=sorted(found)
save('code-import-closures.json',code_closures)
# Parse retained raw evidence, including normal two-line unittest descriptions.
def parse_log(data):
 s=data.decode();starts=list(re.finditer(r'^test_\w+ \(([^)\n]+)\)',s,re.M));out=[]
 for i,m in enumerate(starts):
  end=starts[i+1].start() if i+1<len(starts) else s.find('\n======================================================================',m.end())
  block=s[m.end():end if end!=-1 else len(s)]
  statuses=re.findall(r'(?:^|\.\.\. )(ok|ERROR|FAIL|skipped[^\n]*)$',block,re.M)
  assert len(statuses)==1,(m[1],statuses)
  out.append({'id':m[1],'outcome':statuses[0]})
 return out
verified=[]
for rid in ['20261108T021923-5ef7f9b81de7']:
 for x in js(EVID/rid/'retained-files.json'):
  b=gzip.decompress((EVID/rid/(x['name']+'.gz')).read_bytes());assert len(b)==x['size'] and sha(b)==x['sha256']
  verified.append({'path':str(EVID/rid/(x['name']+'.gz')),'raw_bytes':len(b),'raw_sha256':sha(b)})
old_raw=gzip.decompress((EVID/'20261108T021923-5ef7f9b81de7/native.log.gz').read_bytes());old_results=parse_log(old_raw)
assert old_results==js(PRIOR/'independent-original-results.json')
assert [x['id'] for x in old_results]==[x['id'] for x in inventory]
new_raw=gzip.decompress((PACK/'compiler-policy-driver.log.gz').read_bytes());new_results=parse_log(new_raw)
assert len(new_results)==338 and {x['id']:x['outcome'] for x in new_results}==js(PACK/'summary.json')['per_id']
assert collections.Counter(x['outcome'] for x in new_results)=={'ok':335,'ERROR':3}
# Immutable repaired-run packet including identity refresh.
for f in js(PACK/'index.json'):
 b=(PACK/f['artifact']).read_bytes();assert len(b)==f['stored_bytes'] and sha(b)==f['stored_sha256']
 raw=b if (f['bytes'],f['sha256'])==(f['stored_bytes'],f['stored_sha256']) else gzip.decompress(b)
 assert len(raw)==f['bytes'] and sha(raw)==f['sha256']
 verified.append({'path':str(PACK/f['artifact']),'raw_bytes':len(raw),'raw_sha256':sha(raw),'stored_sha256':sha(b)})
# Exact previous/current identity records and live current hashes.
identity_groups={}
prior_prepared=js(PRIOR/'independent-input-identities.json')
original_events=[json.loads(x) for x in gzip.decompress((EVID/'20261108T021923-5ef7f9b81de7/events.jsonl.gz').read_bytes()).splitlines()]
original_prepared=next(e['inputs']['inputs_sha256'] for e in original_events if e['event']=='prepared')
assert {x['path']:x['old'] for x in prior_prepared}==original_prepared
save('original-to-accepted-identities.json',prior_prepared)
old_expected={
 'original-prepared-inputs':{x['path']:x['current'] for x in prior_prepared},
 'native-build-inputs':{x['path']:x['sha256'] for x in js(PRIOR/'native-build-input-check.json')},
 'native-tools':{x['path']:x['sha256'] for x in js(PRIOR/'independent-audit-summary.json')['native_tools']},
 'lean-tools':{x['path']:x['sha256'] for x in js(PRIOR/'original-pinned-lean-tools.json')},
}
for group in old_expected:
 rows=json.loads(gzip.decompress((PACK/'retained-applicability-identities'/(group+'.json.gz')).read_bytes()))
 assert {x['path']:x['previous'] for x in rows}==old_expected[group],group
 for x in rows:assert digest(x['path'])==x['current'],(group,x['path'])
 identity_groups[group]={'rows':rows,'live_current_hashes_match':True}
save('retained-identity-resolution.json',identity_groups)
# Repaired-run declared input postflight, then target correspondence, plus tools.
ev=[json.loads(x) for x in gzip.decompress((PACK/'managed/events.jsonl.gz').read_bytes()).splitlines()]
prepared=next(e['inputs']['inputs_sha256'] for e in ev if e['event']=='prepared')
post=js(PACK/'postflight-inputs.json');assert len(post)==len(prepared)==1115
assert {x['path']:x['expected'] for x in post}==prepared
for row in post:assert row['equal'] and row['expected']==row['current']==digest(row['path']),row['path']
selector=js(PACK/'postflight-selector-tools.json');assert not(selector['added'] or selector['removed'] or selector['changed'])
for x in selector['tools']:assert x['equal'] and digest(x['path'])==x['expected']==x['actual']
# Prior repaired chunk has one actual success; verify complete old bundle and exactly 20 current inputs.
chunk=REVIEW/'tmp/local-watchdog-fixture-298';chunk_meta=js(chunk/'shareable-evidence.json')
assert digest(chunk/'shareable-evidence.tar.gz')==chunk_meta['sha256']
chunk_members=[]
with tarfile.open(chunk/'shareable-evidence.tar.gz') as t:
 for m in t.getmembers():
  assert m.isfile();b=t.extractfile(m).read();assert digest(chunk/m.name)==sha(b),m.name
  chunk_members.append({'path':m.name,'bytes':len(b),'sha256':sha(b)})
assert len(chunk_members)==60
chunk_inputs=js(chunk/'results/copied-inputs-before.json');assert len(chunk_inputs)==20
assert chunk_inputs==js(chunk/'results/copied-inputs-after.json')
for p,want in chunk_inputs.items():assert digest(ROOT/p)==digest(REG/p)==want,p
completion=js(chunk/'results/completion-review.json');result=completion['fixture_result']
assert completion['managed_outcome']=='success' and result['passed'] and (result['errors'],result['failures'],result['skips'])==(0,0,0)
assert (completion['observed_build_processes'],completion['observed_audit_invocations'],result['successful_subtests'])==(25,12,11)
save('chunk-resolution.json',{'bundle':chunk_meta,'verified_members':chunk_members,'completion':completion,'copied_inputs':chunk_inputs,'all_20_equal_current':True})
# Reconstruct native probe dependency closures from actual Ada with clauses.
sourcepaths=set(tracked);probes={}
for main in ['tests/library_reports_probe.adb','tests/report_projection_probe.adb','tests/image_model_probe.adb']:
 found=set();pending=[main]
 while pending:
  p=pending.pop()
  if p in found:continue
  found.add(p)
  for clause in re.findall(r'^\s*(?:(?:limited|private)\s+)?with\s+([^;]+);',(ROOT/p).read_text(),re.M|re.I):
   for name in clause.split(','):
    unit=name.strip().lower().replace('.','-')
    if re.fullmatch(r'[a-z][a-z0-9_-]*',unit):
     pending.extend(q for q in ['src/'+unit+'.ads','src/'+unit+'.adb'] if q in sourcepaths)
 assert 'src/silver_output_profile.adb' not in found
 assert all(blob(BASE,p)==(ROOT/p).read_bytes() for p in found)
 probes[main]=sorted(found)
assert probes==js(DELTA/'native-probe-source-closures.json')
save('native-probe-closures.json',probes)
# Exact classification origins; acceptance is limited to this target, not final 637 completion.
proposal=js(REG/'tmp/repaired-input-regressions/per-id-delta.json');assert proposal==js(DELTA/'per-id-delta.json')
assert {x['id'] for x in proposal}=={x['id'] for x in inventory}
oldmap={x['id']:x['outcome'] for x in old_results};newmap={x['id']:x['outcome'] for x in new_results}
final=[]
for p in proposal:
 r={'id':p['id'],'definition':p['definition'],'dependency_reason':p['reason'],'code_imports':code_closures[p['definition']['path']]}
 if p['classification']=='reusable':
  rid=p['prior_evidence_run'];assert rid in ['20261108T021923-5ef7f9b81de7','20261108T065724-7d260468ca14']
  if rid.startswith('20261108T021923'):assert oldmap[p['id']]=='ok'
  else:assert p['id']==result['test_id']
  r.update(disposition='accepted_retained',evidence_run=rid,outcome='ok',future_promotion_invalidates=p['id'].startswith('test_rosetta.'))
 elif p['classification'] in ['rerun_compiler','rerun_source_policy']:
  r.update(disposition='accepted_fresh' if newmap[p['id']]=='ok' else 'pending_compile_timeout',evidence_run='20261108T093645-d959cfabae08',outcome=newmap[p['id']])
 else:
  r.update(disposition='pending_platform_wrapper' if p['classification']=='rerun_platform_wrapper' else 'pending_platform_body_via_wrapper',evidence_run=None,outcome=None)
 final.append(r)
counts=dict(collections.Counter(x['disposition'] for x in final));assert counts=={'accepted_retained':286,'accepted_fresh':335,'pending_compile_timeout':3,'pending_platform_wrapper':1,'pending_platform_body_via_wrapper':12}
save('per-id-resolution.json',final);save('verified-evidence.json',verified)
save('raw-success-origins.json',{'original':old_results,'repaired':new_results})
summary={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'review_target':target,'briefed_target':'1aaa381dd3e26ad250eb671f01a4114badba64ae','governed':GOV,'regression_commit':git('-C',str(REG),'rev-parse','HEAD').decode().strip(),'source_test_trees_equal':True,'tracked_inputs_compared':len(identities),'test_modules':len(mods),'canonical_ids':637,'inherited_methods':[x for x in inventory if x['defining_class']!=x['id'].split('.')[-2]],'imported_aliases':[x for x in inventory if x['id'].startswith('tests.')],'changed_inputs_from_prior_target':changes,'counts':counts,'rejected_reuse':[],'accepted_outcomes':621,'still_pending_ids':16,'future_rosetta_fresh_methods':3,'current_native_build_inputs_rehashed':len(identity_groups['native-build-inputs']['rows']),'repaired_postflight_files_rehashed':len(post),'postflight_tool_entries_verified':len(selector['tools']),'chunk_inputs_unchanged':20,'scope':'Applicability for exact current source target; no final 637, complete native or complete Lean acceptance. No tests, proof, signals, production edits, publication or merge.'}
save('summary.json',summary)
print(json.dumps({k:v for k,v in summary.items() if k not in ['inherited_methods','imported_aliases','changed_inputs_from_prior_target']},indent=2))
