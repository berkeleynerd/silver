"""Bound unchanged unittest discovery to four CPUs; retain actual observations."""
import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import sys

here = Path(__file__).resolve().parent
root = here.parent.parent
mode = sys.argv[1]
assert mode in {"compiler-policy", "platform-wrapper"}
commands = json.loads((here / "commands.json").read_text())
prepared = commands[mode]
extra = prepared[prepared.index("--") + 1:]
command = [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v", *extra]
original = sorted(os.sched_getaffinity(0))
assert len(original) >= 4
selected = original[-4:]
os.sched_setaffinity(0, selected)
assert sorted(os.sched_getaffinity(0)) == selected
out = here / mode
out.mkdir(exist_ok=False)
inherited_fds = []
for entry in Path("/proc/self/fd").iterdir():
    try:
        fd = int(entry.name)
        target = os.readlink(entry)
        if fd > 2:
            inherited_fds.append({"fd": fd, "target": target, "inheritable": os.get_inheritable(fd)})
    except OSError:
        continue
lease_fds = tuple(row["fd"] for row in inherited_fds
                  if "/silver-runs/" in row["target"] and row["target"].endswith("/lease"))
assert len(lease_fds) == 1, inherited_fds


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


launch = {"utc": utc(), "mode": mode, "launcher_pid": os.getpid(),
          "original_affinity": original, "selected_affinity": selected,
          "inherited_fds": inherited_fds, "passed_lease_fds": lease_fds,
          "cwd": str(root), "command": command,
          "scope": "unchanged unittest discovery; inherited CPU allowance, not exclusive cores or memory limit"}
(out / "launch.json").write_text(json.dumps(launch, indent=2) + "\n")
print("REGRESSION_LAUNCH", json.dumps(launch), flush=True)
child = subprocess.Popen(command, cwd=root, pass_fds=lease_fds, start_new_session=True)
observer_errors = []
interruptions = []
affinity_violations = []


def forward_interrupt(signum, frame):
    interruptions.append({"utc": utc(), "signal": signum})
    (out / "interruptions.json").write_text(json.dumps(interruptions, indent=2) + "\n")
    try:
        os.killpg(child.pid, signum)
    except ProcessLookupError:
        pass


signal.signal(signal.SIGINT, forward_interrupt)
signal.signal(signal.SIGTERM, forward_interrupt)


def observe():
    table = {}
    for directory in Path("/proc").iterdir():
        if not directory.name.isdigit():
            continue
        try:
            status = dict(line.split(":", 1) for line in (directory / "status").read_text().splitlines())
            pid = int(directory.name)
            table[pid] = {"pid": pid, "ppid": int(status["PPid"]),
                          "rss_kib": int(status.get("VmRSS", "0 kB").split()[0]),
                          "allowed_cpus": status["Cpus_allowed_list"].strip(),
                          "affinity": sorted(os.sched_getaffinity(pid)),
                          "command": (directory / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")}
        except (OSError, ValueError, KeyError):
            continue
    owned = {os.getpid()}
    while True:
        expanded = owned | {pid for pid, row in table.items() if row["ppid"] in owned}
        if expanded == owned:
            break
        owned = expanded
    members = [table[pid] for pid in sorted(owned) if pid in table]
    available = int(next(line for line in Path("/proc/meminfo").read_text().splitlines()
                         if line.startswith("MemAvailable:")).split()[1])
    violations = [row["pid"] for row in members if not set(row["affinity"]).issubset(selected)]
    if violations:
        affinity_violations.append({"utc": utc(), "pids": violations})
    row = {"utc": utc(), "mem_available_kib": available, "processes": members,
           "affinity_violations": violations}
    with (out / "observations.jsonl").open("a") as stream:
        stream.write(json.dumps(row) + "\n")
    print("REGRESSION_RESOURCES", json.dumps({"utc": row["utc"], "available_gib": round(available / 2**20, 3),
          "process_count": len(members), "rss_gib": round(sum(p["rss_kib"] for p in members) / 2**20, 3),
          "affinity_violations": violations}), flush=True)


try:
    while child.poll() is None:
        try:
            observe()
        except Exception as error:
            observer_errors.append({"utc": utc(), "error": repr(error)})
            (out / "observer-errors.json").write_text(json.dumps(observer_errors, indent=2) + "\n")
        try:
            child.wait(timeout=15)
        except subprocess.TimeoutExpired:
            pass
finally:
    # Keep this process and the child's inherited lease until the actual child exits.
    child.wait()
try:
    observe()
except Exception as error:
    observer_errors.append({"utc": utc(), "error": repr(error)})
    (out / "observer-errors.json").write_text(json.dumps(observer_errors, indent=2) + "\n")
result = {"utc": utc(), "actual_unittest_exitcode": child.returncode, "child_pid": child.pid,
          "observer_errors": observer_errors, "interruptions": interruptions,
          "affinity_violations": affinity_violations}
(out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
print("REGRESSION_FINISHED", json.dumps(result), flush=True)
sys.exit(child.returncode if child.returncode else int(bool(observer_errors or interruptions or affinity_violations)))
