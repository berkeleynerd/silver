from pathlib import Path
import ast,collections,gzip,hashlib,json,re,subprocess
review=Path(__file__).resolve().parents[2]
root=review.parent/'scalar-functions-source-integration-298'
reg=review.parent/'scalar-functions-298'
out=Path(__file__).parent
base='c437a41d30dbdbd174773cab1f5d647dc6e7bbf3'
target='5aa1509fc5ac2d6f2dc02c5803d94da7e201aaf1'
evidence=root/'docs/evidence/scalar-functions-20261107/final-regression'
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
def sha(b):return hashlib.sha256(b).hexdigest()
def js(p):return json.loads(p.read_text())
def save(n,d):(out/n).write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
assert git('rev-parse','HEAD').decode().strip()==target
paths=git('ls-tree','-r','--name-only',target,'tests').decode().splitlines()
mods={Path(p).stem:(p,ast.parse(git('show',target+':'+p))) for p in paths if Path(p).name.startswith('test') and p.endswith('.py')}
classes={}
for m,(p,t) in mods.items():
 for c in t.body:
  if isinstance(c,ast.ClassDef):classes[(m,c.name)]=(p,c)
def methods(m,c):
 p,node=classes[m,c];result={}
 for b in node.bases:
  if isinstance(b,ast.Name) and (m,b.id) in classes:result.update(methods(m,b.id))
 for f in node.body:
  if isinstance(f,(ast.FunctionDef,ast.AsyncFunctionDef)) and f.name.startswith('test'):
   result[f.name]={'path':p,'defining_class':c,'line':f.lineno,'ast_sha256':sha(ast.dump(f,include_attributes=False).encode())}
 return result
inventory=[]
for m,(p,t) in sorted(mods.items()):
 candidates={c:(m,c,m) for mm,c in classes if mm==m}
 for n in t.body:
  if isinstance(n,ast.ImportFrom) and n.module and n.module.startswith('tests.'):
   imported=n.module.split('.')[-1]
   for a in n.names:
    if (imported,a.name) in classes:candidates[a.asname or a.name]=(imported,a.name,n.module)
 for cname,(definition_module,definition_class,id_module) in sorted(candidates.items()):
  for name,entry in sorted(methods(definition_module,definition_class).items()):
   inventory.append({'id':id_module+'.'+definition_class+'.'+name,'discovered_in':m,**entry})
census=js(evidence/'test-input-census.json')
assert [e['id'] for e in inventory]==census['test_ids'],([e['id'] for e in inventory if e['id'] not in census['test_ids']],len(inventory))
assert len(inventory)==len({e['id'] for e in inventory})==637
log=gzip.decompress((evidence/'20261108T021923-5ef7f9b81de7/native.log.gz').read_bytes()).decode()
starts=list(re.finditer(r'^test_\w+ \(([^)]+)\)',log,re.M))
raw_results=[]
for i,m in enumerate(starts):
 block=log[m.end():starts[i+1].start() if i+1<len(starts) else log.index('\n======================================================================',m.end())]
 verdicts=list(re.finditer(r'(?:^|\.\.\. )(ok|ERROR|FAIL|skipped[^\n]*)$',block,re.M))
 assert len(verdicts)==1,(m[1],len(verdicts))
 raw_results.append({'id':m[1],'outcome':verdicts[0][1]})
assert len(raw_results)==637,len(raw_results)
assert [e['id'] for e in raw_results]==census['test_ids']
record=js(evidence/'20261108T021923-5ef7f9b81de7/result.json')
assert raw_results==record['results']
assert re.search(r'Ran 637 tests in 8701\.275s\s+FAILED \(errors=2\)',log)
changes=git('diff','--name-status',base,target).decode().splitlines()
changed_paths=[s.split('\t')[-1] for s in changes]
non_docs=[s for s in changed_paths if not(s.startswith('docs/') or s=='roadmap.md')]
assert len(non_docs)==90
assert set(non_docs)=={s for s in non_docs if s.startswith('proof/') or s in ['tests/test_platforms.py','tests/test_lean_modules.py']}
assert not git('diff',base,target,'--','src','scripts','samples','catalogue','rosetta','alire.toml','silver.gpr','proof/silver_proof_containers.gpr','proof/lean-toolchain','proof/lakefile.lean','proof/generate_source_certificate.py')
# All target tracked test files match actual integration bytes and the inventory is exact.
actual_test_files=sorted(str(p.relative_to(root)) for p in (root/'tests').rglob('*.py'))
tracked_test_files=sorted(p for p in paths if p.endswith('.py'))
assert actual_test_files==tracked_test_files
for p in tracked_test_files:assert (root/p).read_bytes()==git('show',target+':'+p)
for p in ['proof','src','scripts']:
 assert not git('diff','47fe4003c0',target,'--',p)
assert not git('diff','560144172c',target,'--','src')
# Retained raw artifact identities, not just narrative records.
artifacts=[]
for rid in ['20261108T021805-6a448d871b26','20261108T021923-5ef7f9b81de7']:
 index=js(evidence/rid/'retained-files.json')
 for item in index:
  blob=gzip.decompress((evidence/rid/(item['name']+'.gz')).read_bytes())
  assert len(blob)==item['size'] and sha(blob)==item['sha256']
  artifacts.append({'artifact':rid+'/'+item['name']+'.gz','bytes':len(blob),'sha256':sha(blob)})
policy=evidence/'source-policy-47fe4003c0'
for item in js(policy/'index.json'):
 blob=gzip.decompress((policy/item['artifact']).read_bytes())
 assert len(blob)==item['bytes'] and sha(blob)==item['sha256']
 artifacts.append({'artifact':'source-policy-47fe4003c0/'+item['artifact'],'bytes':len(blob),'sha256':sha(blob)})
def events(relative):return [json.loads(x) for x in gzip.decompress((evidence/relative).read_bytes()).decode().splitlines()]
original_events=events('20261108T021923-5ef7f9b81de7/events.jsonl.gz')
build_events=events('20261108T021805-6a448d871b26/events.jsonl.gz')
policy_events=events('source-policy-47fe4003c0/20261108T072619-eca79cdaf440-events.jsonl.gz')
def prepared(ev):return next(e['inputs'] for e in ev if e['event']=='prepared')
# Original prepared map currently has exactly eight modified production proofs plus the two test repairs.
identity=[]
for name,wanted in prepared(original_events)['inputs_sha256'].items():
 p=Path(name);blob=p.read_bytes();identity.append({'path':name,'old':wanted,'current':sha(blob),'unchanged':sha(blob)==wanted})
drift=[e for e in identity if not e['unchanged']]
assert len(drift)==10,len(drift)
assert {str(Path(e['path']).relative_to(reg)) for e in drift}=={p for p in non_docs if not p.startswith('proof/Silver/FunctionSourceParts/')}
# Separate original compiler, adapter and native/Lean tool identities are still those tested.
tools=[]
for relative,entry in census['binaries'].items():
 p=reg/relative;digest=sha(p.read_bytes());assert digest==entry['sha256'];tools.append({'path':str(p),'sha256':digest,'kind':'compiler/adapter'})
for name,entry in prepared(build_events)['tools'].items():
 p=Path(entry['path']);digest=sha(p.read_bytes());assert digest==entry['sha256'];tools.append({'path':str(p),'sha256':digest,'kind':name,'recorded_version':entry.get('version')})
policy_checked=[]
for name,wanted in prepared(policy_events)['inputs_sha256'].items():
 p=Path(name);digest=sha(p.read_bytes());assert digest==wanted,(p,digest,wanted);policy_checked.append({'path':name,'sha256':digest})
policy_paths={str(Path(e['path']).relative_to(root)) for e in policy_checked if Path(e['path']).is_relative_to(root)}
proof_paths=set(git('ls-tree','-r','--name-only',target,'proof').decode().splitlines())
assert proof_paths<=policy_paths,(proof_paths-policy_paths)
assert 'tests/test_lean_source.py' in policy_paths
policy_log=gzip.decompress((policy/'20261108T072619-eca79cdaf440-native.log.gz').read_bytes()).decode()
policy_results=[{'id':m[1],'outcome':m[2]} for m in re.finditer(r'^test_\w+ \(([^)]+)\) \.\.\. (ok|ERROR|FAIL)$',policy_log,re.M)]
assert len(policy_results)==4 and all(r['outcome']=='ok' for r in policy_results)
assert policy_events[-1]['event']=='finished' and policy_events[-1]['outcome']=='success'
assert build_events[-1]['outcome']=='success' and original_events[-1]['outcome']=='failure'
summary={'review_target':target,'original_snapshot':base,'raw_log_census_exact':True,'count':637,'original_outcomes':dict(collections.Counter(x['outcome'] for x in raw_results)), 'ast_inherited':[e for e in inventory if e['defining_class']!=e['id'].split('.')[-2]],'imported_aliases':[e for e in inventory if e['id'].startswith('tests.')],'production_test_delta':non_docs,'unchanged_original_prepared_inputs':len(identity)-len(drift),'changed_original_prepared_inputs':drift,'native_tools':tools,'policy_fresh_results':policy_results,'policy_inputs_verified':len(policy_checked),'policy_complete_proof_inventory_verified':len(proof_paths),'test_methods_not_executed':True,'native_assurance':'separate mandatory condition; not accepted here','complete_lean_assurance':'separate mandatory condition; not accepted here','future_rosetta':'not applied or accepted; three fresh tests required after promotion'}
save('independent-ast-inventory.json',inventory);save('independent-original-results.json',raw_results);save('independent-input-identities.json',identity);save('independent-policy-inputs.json',policy_checked);save('verified-retained-artifacts.json',artifacts);save('independent-audit-summary.json',summary)
print(json.dumps({k:v for k,v in summary.items() if k not in ['production_test_delta','native_tools','changed_original_prepared_inputs','ast_inherited','imported_aliases']},indent=2))
