# Independent regression applicability review

Disposition: accept composition of regression results for exact integration
`5aa1509fc5ac2d6f2dc02c5803d94da7e201aaf1`, with production Lean/source/scripts
`47fe4003c0` and native source `560144172c`. This does not accept complete native
proof/audit, complete Lean/source correspondence, or any future Rosetta change.
The original full-suite run remains FAILED (errors=2). No new test was run by
this applicability review; only evidence, source, AST and byte identities were
read. Selected reviewer GPT-6 Astra / Extra High; runtime telemetry unavailable.

## Complete inventory and result provenance

Independently parsed every tracked test module and reproduced unittest discovery
order, local class inheritance and explicitly imported TestCase classes. The
result is exactly the original 637 unique IDs, with no additions, omissions or
untracked Python test files. Five Array-report methods inherit unchanged base
bodies. Nine `tests.test_shared_bindings` IDs arise from the imported class in
`test_integer_loops`, distinct from its ordinary nine discovery IDs. There are
no dynamic `load_tests`/`setattr` hooks or generated test classes to defeat this
resolution. Exact source definitions are recorded per ID.

Independently extracted all 637 outcomes from the retained raw original log,
including 15 cases whose docstrings or subprocess output split the usual
single-line result. The IDs/order match both the original preflight census and
result record; outcomes are 635 ok and 2 ERROR, zero skips, elapsed 8701.275 s.
Raw compressed original build/test artifacts and all five source-policy packet
artifacts were decompressed and verified against their retained hashes/sizes.

The independent per-ID matrix contains:

| Final evidence | IDs | Actual run |
| --- | ---: | --- |
| Retained original successful results | 619 | `20261108T021923-5ef7f9b81de7` |
| Fresh affected source-policy methods | 4 | `20261108T072619-eca79cdaf440` |
| Fresh repaired chunk fixture | 1 | `20261108T065724-7d260468ca14` |
| Fresh platform bodies through original wrapper | 12 | `20261108T075522-000e545aebc8` |
| Fresh original platform wrapper | 1 | `20261108T075522-000e545aebc8` |
| Total | 637 | One final disposition per original ID |

The coordinator's preparation matrix was treated as a lead. It did not supply
acceptance: discovery, raw outcomes, exact byte comparisons, affected method
selection, input scopes and dependency reasoning were independently checked.

## Exact changes and shared dependencies

Between the original `c437a41d30dbdbd174773cab1f5d647dc6e7bbf3` and target there
are 90 non-documentation changes: 80 added FunctionSourceParts Lean modules,
eight modified Lean files and two test repairs. The eight are the Boolean
candidate/libraries, ComposeSourceBridge, FunctionSourceCandidate, PredicateBasic
candidate, PredicateEquations, PredicateLoopCandidate and PredicateSourceRequirements.
All native source, scripts, samples, catalogue, Rosetta inputs, native projects,
Lean pin/lakefile/generator, and configuration are unchanged. Other changed files
are review/evidence/design documentation and roadmap; test references to markdown
are generated Rosetta outputs, not these documents. The actual target tests and
complete proof inventory agree with the reviewed commit.

The original 1,031 captured test inputs were rehashed: 1,021 remain identical;
the other ten are exactly the eight modified Lean files and two approved test
repairs. Added proof files are separately covered by complete target inventory
comparison. All 2,588 original native build inputs and recorded tool binaries,
compiler, adapter, Lean and Lake identities were independently compared again.
Generated compiler/configuration files and native tool context remained equal.
The original successful native build thus remains applicable; this is a build
claim, not acceptance of the separately required full native proof/audit.

The shared `LeanModuleTests.lake` helper now takes a keyword-only timeout with
default 60 and forwards it unchanged to subprocess.run. Only the selected chunk
method's local build supplies 180. The other two methods, their shared build
helper, and audit calls retain the same default 60. No dynamic override or
reflection caller exists. Reversing that parameter/forwarding change and the
single selected keyword makes the whole module AST identical to the original.
This verifies that retaining the two unaffected methods does not ignore their
shared helper. Their native modules are synthetic except unchanged AxiomAudit,
Audit and toolchain pin. The platform AST likewise becomes exactly the original
after removing its one new constant and reverting three watchdog keywords.

The platform shared worker helper affects six methods (eleven serial calls),
and the separate concurrent method launches four workers. Five other class
methods do not use the changed timeout, but every setUp copies the entire current
proof tree. All twelve are therefore covered freshly. Remaining installation
methods in the file neither call the changed helper nor consume the changed Lean
modules. Imports, generator, tool mocks, assertions, barrier and cleanup remain
unchanged. A successful original wrapper invokes these exact twelve methods with
no skip or conditional-selection paths, under the required symlink environment.
That establishes coverage of their bodies, not a second non-symlink invocation.

## Production proof reads versus synthetic/native fixtures

Reviewed direct and indirect production-root reads, not just the keyword proof:

- Four CompilerSourcePolicyTests inspect the whole recursive Lean inventory or
  project import closures. Their original successes are replaced by the actual
  four fresh passes. The retained launcher selects exactly those unchanged
  methods with normal imports; its managed success and raw no-skip log agree.
  All 847 declared inputs remain identical, including the complete 824-file
  production proof tree (821 Lean paths plus generator, pin and native GPR).
- Other source-policy/generator tests read unchanged AuthoritativeSource and
  binding modules, lakefile, generator, native source, checked-in certificates
  and eight output-line chunks, or synthetic strings. The native certificate
  probe copies only Lexical, Admission, Cursor, SourceLexer, CertificateWitness
  and AxiomAudit, all unchanged. Their import dependencies are included in that
  fixed small chain and pinned Lean distribution, not the new project modules.
- LeanEvidenceTests constructs literal temporary proof trees. LeanRunnerPhaseTests
  replaces ROOT/PROOF with synthetic roots, creates literal candidate placeholders
  and fake tools, and mocks runner subprocesses. LeanRunHistoryTests reuses exactly
  that fixture. Native probes copy only unchanged AxiomAudit, source bindings,
  lakefile and pin; removal/resource tests use synthetic proof modules. No changed
  proof file is indirectly read by those retained methods.
- Other native, report, provenance, dev and sample tests use unchanged compiler
  sources/binaries/configuration, synthetic reports, application GNATprove output,
  or the unchanged native proof-container GPR. They do not execute the altered
  production Lean graph. Shared test helper imports and inherited base definitions
  are unchanged and resolved in the inventory. Generated sample/native workspaces
  depend on unchanged source and tools, not production Lean module packaging.

## Exact repair rerun scope and limits

The successful chunk fixture's copied inputs equal the target: nine helpers,
seven production Lean modules, lakefile/pin/generator and the repaired test.
Its generated temporary closure is the original 17-module cold build and edit
cases; it does not copy or certify all 821 production modules. The seven are
Lexical, Admission, Cursor, SourceLexer, CertificateWitness,
OutputProfileBodySource and AxiomAudit. Recorded success includes 11 edits,
25 builds and 12 fresh audits, plus exact postflight source/distribution/input
checks. The existing verified bundle remains byte-identical.

The successful platform wrapper instead uses all 866 exact target fixture files,
including the complete 821-file Lean set and 30 real certificate generators.
The final run, complete input postflight, process cleanup and verified bundle
are retained separately. Its tool execution is mocked according to the original
tests; routing assertions and generators are real. Fifteen workers directly
parented by the nested suite match the static call inventory. An extra sampled
child with inherited worker command text is not another setup invocation.
Original successful nested stdout is not exposed by the wrapper; no fabricated
nested log or fresh standalone class run is claimed.

These scopes suffice for the original test semantics and their affected input
closures. Neither fixture proves the whole project. Every required test has an
applicable successful result for the exact target, so an otherwise identical
full-suite rerun is unnecessary under development.md's composition rule.

The three current Rosetta tests are among the 619 retained results because their
present inputs are unchanged. Their later promotion patch has not been applied
or accepted here: all three must run freshly after that patch. Any other later
source/test/tool change requires ordinary applicability review. Complete native
proof/audit and complete Lean/source correspondence remain mandatory separate
conditions. No publication, merge or CLI memory update was performed.

The retained supported-sample manifest also equals the target manifest byte for
byte and contains all 72 entries. Its two test methods passed in the original
full suite; their unchanged manifest/source/catalogue/compiler/tool dependencies
support reuse of those concrete sample results, not universal language assurance.

At handoff, integration advanced to `d396db2aeb498cd132bbe4b9f0ea3f0fb93687f8`.
The exact comparison adds only this platform evidence and its review/README;
these four documentation paths are not test inputs, so the same disposition
extends to that observed follow-up. No Rosetta or production change is included.
