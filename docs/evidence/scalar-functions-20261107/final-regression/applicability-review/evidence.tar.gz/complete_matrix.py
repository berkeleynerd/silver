from pathlib import Path
import ast,collections,copy,gzip,hashlib,json,subprocess
out=Path(__file__).resolve().parent;review=out.parents[1];root=review.parent/'scalar-functions-source-integration-298';reg=review.parent/'scalar-functions-298';evidence=root/'docs/evidence/scalar-functions-20261107/final-regression'
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
def save(n,v):(out/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
summary=read(out/'independent-audit-summary.json');target=summary['review_target'];base=summary['original_snapshot']
# Review default-preserving shared helper and exact whole-module repair semantics.
normalized=[]
for name in ['test_lean_modules.py','test_platforms.py']:
 path='tests/'+name;before=ast.parse(git('show',base+':'+path));after=ast.parse(git('show',target+':'+path))
 if name=='test_lean_modules.py':
  for n in ast.walk(after):
   if isinstance(n,ast.FunctionDef) and n.name=='lake':
    assert [a.arg for a in n.args.kwonlyargs]==['timeout'] and ast.literal_eval(n.args.kw_defaults[0])==60
    n.args.kwonlyargs=[];n.args.kw_defaults=[]
   if isinstance(n,ast.Call):
    for k in list(n.keywords):
     if k.arg=='timeout' and isinstance(k.value,ast.Name) and k.value.id=='timeout':k.value=ast.Constant(60)
     elif k.arg=='timeout' and isinstance(k.value,ast.Constant) and k.value.value==180:
      assert isinstance(n.func,ast.Attribute) and n.func.attr=='lake';n.keywords.remove(k)
 else:
  after.body=[n for n in after.body if not(isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PLATFORM_SETUP_TIMEOUT_SECONDS' for t in n.targets))]
  for n in ast.walk(after):
   if isinstance(n,ast.keyword) and n.arg=='timeout':
    if isinstance(n.value,ast.Name) and n.value.id=='PLATFORM_SETUP_TIMEOUT_SECONDS':n.value=ast.Constant(60)
    elif isinstance(n.value,ast.Constant) and n.value.value==900:n.value=ast.Constant(180)
 assert ast.dump(before,include_attributes=False)==ast.dump(after,include_attributes=False),name
 normalized.append({'path':path,'only_reviewed_watchdog_delta':True,'normalized_ast_equals_original':True})
# Original native build and installed tools remain applicable, including generated config.
build_events=[json.loads(l) for l in gzip.decompress((evidence/'20261108T021805-6a448d871b26/events.jsonl.gz').read_bytes()).decode().splitlines()]
build_inputs=next(e['inputs']['inputs_sha256'] for e in build_events if e['event']=='prepared');build_check=[]
for name,wanted in build_inputs.items():
 p=Path(name);p=p if p.is_absolute() else reg/p;got=sha(p.read_bytes());assert got==wanted,(name,got,wanted);build_check.append({'path':str(p),'sha256':got})
lean_tools=[]
for name,item in read(evidence/'preflight-input-inventory.json')['tool_identity'].items():
 p=reg/name;got=sha(p.read_bytes());assert got==item['sha256'];lean_tools.append({'path':str(p),'sha256':got})
# Confirm the actual frozen fixture copies against the review target, not only their summaries.
fixture_checks=[]
chunk=review/'tmp/local-watchdog-fixture-298';platform=review/'tmp/final-platform-fixture-298'
for name,digest in read(chunk/'results/copied-inputs-before.json').items():
 assert sha(git('show',target+':'+name))==digest
 fixture_checks.append({'fixture':'chunk','path':name,'sha256':digest})
assert len(fixture_checks)==20 # nine helpers, seven modules, lakefile/pin/generator, test
for row in read(platform/'frozen-inputs/copy-inventory.json'):
 assert sha(git('show',target+':'+row['path']))==row['sha256']
 fixture_checks.append({'fixture':'platform','path':row['path'],'sha256':row['sha256']})
fixture_results={}
for label,case in [('chunk',chunk),('platform',platform)]:
 manifest=read(case/'shareable-evidence.json');assert sha((case/'shareable-evidence.tar.gz').read_bytes())==manifest['sha256']
 completion=read(case/'results/completion-review.json');assert completion['managed_outcome']=='success'
 result=completion['fixture_result'];assert result['passed'] and not any(result[k] for k in ['errors','failures','skips'])
 fixture_results[label]={'bundle':manifest,'completion':completion,'run_id':completion['run_id']}
# Independent per-ID partition, preserving all original results.
policies={x['id'] for x in summary['policy_fresh_results']};ast_map={x['id']:x for x in read(out/'independent-ast-inventory.json')};matrix=[]
for entry in read(out/'independent-original-results.json'):
 identity=entry['id'];module=identity.removeprefix('tests.').split('.')[0]
 if identity in policies:group='fresh_source_policy';basis='Reads complete current proof inventory or affected import closure';run='20261108T072619-eca79cdaf440'
 elif identity=='test_lean_modules.LeanModuleTests.test_output_body_chunks_reuse_objects_across_content_and_occurrence_edits':group='fresh_chunk_fixture';basis='Selected method changed; exact seven production modules plus generated temporary fixture closure and assertions exercised';run=fixture_results['chunk']['run_id']
 elif identity.startswith('test_platforms.PlatformIsolationTests.'):
  group='fresh_platform_body_via_wrapper';basis='Exact body selected by successful original wrapper; complete 821 Lean input set, no skip path, required symlink environment';run=fixture_results['platform']['run_id']
 elif identity=='test_platforms.InstallationEnvironmentTests.test_symlinked_tmpdir_preserves_platform_setup_and_routing':group='fresh_platform_wrapper';basis='Original wrapper passed on exact final test and complete current source tree';run=fixture_results['platform']['run_id']
 else:
  group='retained_original_pass';run='20261108T021923-5ef7f9b81de7';assert entry['outcome']=='ok'
  if module=='test_lean_modules':basis='Unchanged method and synthetic module inputs; shared lake helper still passes default60 identically; AxiomAudit/Audit/pin unchanged'
  elif module=='test_lean_source':basis='Unchanged generator, bindings/certificates/chunks, sources, six native helper modules and tool inputs; no traversal of changed proof closure'
  elif module in ['test_lean_evidence','test_lean_run_history']:basis='Synthetic temporary proof roots for runner/history; actual native probes copy only unchanged AxiomAudit, source bindings, lakefile and pin'
  elif module=='test_platforms':basis='Other installation tests do not call changed worker helpers or read changed production proof modules; their imports and assertions unchanged'
  elif module=='test_rosetta':basis='Current Rosetta inputs unchanged; NOT applicable to future promotion, which requires all three fresh tests'
  else:basis='Unchanged native source/compiler/adapter/tools/configuration, generated inputs, samples/catalogue and shared helpers; any proof reports are generated GNATprove/synthetic inputs or unchanged native GPR, not changed Lean tree'
 matrix.append({'id':identity,'original_outcome':entry['outcome'],'final_group':group,'evidence_run':run,'dependency_basis':basis,'definition':ast_map[identity]})
counts=dict(collections.Counter(x['final_group'] for x in matrix));assert counts=={'retained_original_pass':619,'fresh_chunk_fixture':1,'fresh_source_policy':4,'fresh_platform_wrapper':1,'fresh_platform_body_via_wrapper':12},counts
assert len(matrix)==637 and len({x['id'] for x in matrix})==637
save('independent-final-matrix.json',matrix);save('fixture-target-byte-identities.json',fixture_checks);save('native-build-input-check.json',build_check);save('repair-ast-equivalence.json',normalized);save('original-pinned-lean-tools.json',lean_tools)
summary.update({'final_counts':counts,'review_disposition':'Regression composition accepted for exact target; original full suite remains failed. No complete native/Lean assurance or future Rosetta applicability accepted.','fixture_bundles':{k:v['bundle'] for k,v in fixture_results.items()},'native_build_inputs_unchanged':len(build_check),'pinned_lean_tools_unchanged':lean_tools,'fixture_frozen_source_files_equal_target':len(fixture_checks),'repairs_static_equivalence':normalized})
save('independent-audit-summary.json',summary);print(json.dumps({'counts':counts,'native_build_inputs':len(build_check),'fixture_inputs':len(fixture_checks),'lean_tools':lean_tools},indent=2))
