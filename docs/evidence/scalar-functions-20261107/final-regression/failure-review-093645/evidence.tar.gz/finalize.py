"""Inspect final immutable results without discovery, tests, proof or mutation outside owned scratch."""
from pathlib import Path
import ast,collections,datetime,gzip,hashlib,json,re,shutil
OUT=Path(__file__).resolve().parent
REG=OUT.parents[2]/'scalar-functions-298'
INTEG=OUT.parents[2]/'scalar-functions-source-integration-298'
PACK=INTEG/'docs/evidence/scalar-functions-20261107/final-regression/repaired-compiler-policy-093645'
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,o):(OUT/n).write_text(json.dumps(o,indent=2)+'\n')
raw=(REG/'tmp/repaired-input-regressions/compiler-policy-driver.log').read_bytes()
(OUT/'final-driver.log.gz').write_bytes(gzip.compress(raw,mtime=0))
s=raw.decode();trace_start=s.index('\n======================================================================\nERROR:')
body=s[:trace_start];trace=s[trace_start:]
(OUT/'final-tracebacks.txt').write_text(trace)
headers=list(re.finditer(r'^test_\w+ \(([^)\n]+)\)([^\n]*)',body,re.M))
selected=(REG/'tmp/repaired-input-regressions/compiler-policy-ids.txt').read_text().splitlines()
assert len(selected)==len(set(selected))==338
results=[]
for i,m in enumerate(headers):
 end=headers[i+1].start() if i+1<len(headers) else len(body)
 chunk=body[m.start():end]
 statuses=re.findall(r'(?:^|\.\.\. )(ok|ERROR|FAIL|skipped [^\n]*)$',chunk,re.M)
 assert len(statuses)==1,(m[1],statuses)
 results.append({'id':m[1],'status':statuses[0],'line':body[:m.start()].count('\n')+1,'two_line_description':not m[2].startswith(' ... ')})
assert len(results)==338 and len({r['id'] for r in results})==338
assert {r['id'] for r in results}==set(selected)
counts=dict(collections.Counter(r['status'] for r in results));assert counts=={'ok':335,'ERROR':3}
missing_shape=[r for r in results if r['two_line_description']]
assert len(missing_shape)==1 and missing_shape[0]['id']=='test_path_refinement.PathRefinementTests.test_counted_loop_definiteness_decides_required_rejection'
assert missing_shape[0]['status']=='ok'
error_heads=list(re.finditer(r'^ERROR: (test_\w+) \((test_[^)]+)\)$',trace,re.M))
exceptions=[]
for i,m in enumerate(error_heads):
 end=error_heads[i+1].start() if i+1<len(error_heads) else len(trace)
 chunk=trace[m.end():end]
 e=re.search(r"subprocess.TimeoutExpired: Command '(.*)' timed out after (\d+) seconds",chunk)
 assert e,m[2]
 command=ast.literal_eval(e[1]);assert command[1]=='compile'
 exceptions.append({'id':m[2],'exception':'subprocess.TimeoutExpired','deadline_seconds':int(e[2]),'command':command})
assert {e['id'] for e in exceptions}=={r['id'] for r in results if r['status']=='ERROR'}
assert [e['deadline_seconds'] for e in exceptions]==[300,120,120]
assert 'Ran 338 tests in 9885.693s\n\nFAILED (errors=3)' in trace
save('final-per-id.json',results)
# Verify every indexed stored payload and, where compressed by retention, original bytes.
index=json.loads((PACK/'index.json').read_text());verified=[]
for f in index:
 b=(PACK/f['artifact']).read_bytes();assert len(b)==f['stored_bytes'] and sha(b)==f['stored_sha256'],f['artifact']
 original=b if (f['bytes']==f['stored_bytes'] and f['sha256']==f['stored_sha256']) else gzip.decompress(b)
 assert len(original)==f['bytes'] and sha(original)==f['sha256'],f['artifact']
 verified.append(f)
copy=OUT/'coordinator-final-packet';copy.mkdir(exist_ok=True)
for name in ['index.json','summary.json','postflight-inputs.json','managed/events.jsonl.gz','managed/native.log.gz','compiler-policy/result.json.gz','compiler-policy/launch.json.gz','compiler-policy-managed-exit.json.gz','compiler-policy-ids.txt.gz']:
 q=copy/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(PACK/name,q)
summary=json.loads((PACK/'summary.json').read_text());assert summary['per_id']=={r['id']:r['status'] for r in results}
events=[json.loads(l) for l in gzip.decompress((PACK/'managed/events.jsonl.gz').read_bytes()).splitlines()]
prepared=next(e for e in events if e.get('event')=='prepared')['inputs']['inputs_sha256']
post=json.loads((PACK/'postflight-inputs.json').read_text())
assert len(prepared)==len(post)==1115
assert {f['path']:f['expected'] for f in post}==prepared
assert all(f['equal'] and f['current']==f['expected'] for f in post)
finish=next(e for e in events if e.get('event')=='finished')
assert finish['outcome']=='failure' and finish['returncode']==1
assert summary['finished']==finish
assert summary['actual_launcher']['actual_unittest_exitcode']==1 and summary['actual_driver']['actual_driver_exitcode']==1
assert not summary['actual_launcher']['observer_errors'] and not summary['actual_launcher']['interruptions'] and not summary['actual_launcher']['affinity_violations']
shutil.copyfile(INTEG/'tmp/repaired-regression-exit-processes.json',OUT/'coordinator-exit-processes.json')
final={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run_id':'20261108T093645-d959cfabae08','final_log':{'bytes':len(raw),'sha256':sha(raw)},'selected_ids':338,'parsed_unique_ids':338,'exact_selected_set':True,'ordered_ids_equal_sorted_selectors':[r['id'] for r in results]==sorted(selected),'counts':counts,'skips':0,'two_line_description':missing_shape,'exceptions':exceptions,'unittest_seconds':9885.693,'managed_seconds':finish['duration_seconds'],'managed_finished_utc':finish['utc'],'actual_launcher':summary['actual_launcher'],'actual_driver':summary['actual_driver'],'verified_coordinator_index_count':len(verified),'verified_coordinator_index_sha256':sha((PACK/'index.json').read_bytes()),'postflight':{'prepared_keys':1115,'recorded_postflight_keys':1115,'exact_prepared_map':True,'recorded_drift':[],'scope':'Reviewer reconciled coordinator postflight rows with exact original prepared map; coordinator rehashed live files. No second full rehash performed.'},'scope':'Read-only final evidence review; no test, proof, signal or production mutation.'}
save('final-summary.json',final)
print(json.dumps(final,indent=2))
