"""Read-only inspection of coordinator evidence; writes only this scratch tree."""
from pathlib import Path
import ast, collections, datetime, gzip, hashlib, json, os, re, shutil, subprocess, tarfile
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2] / 'scalar-functions-298'
EVID = ROOT / 'tmp/repaired-input-regressions'
PRIOR = ROOT / 'docs/evidence/scalar-functions-20261107/final-regression/20261108T021923-5ef7f9b81de7'
CASES = [
 ('maximum-expression-diagnostic', 'workspace-index.json', 'failed-workspace-before-cleanup.tar.gz', 'test_samples.SupportedSampleTests.test_maximum_dynamic_expression',300),
 ('self-actuals-diagnostic', 'index.json', 'retained-workspace.tar.gz', 'test_scalar_functions.ScalarFunctionTests.test_native_boolean_and_integer_self_actuals',120),
 ('ordered-calls-diagnostic', 'index.json', 'retained-workspace.tar.gz', 'test_scalar_functions.ScalarFunctionTests.test_native_ordered_calls_snapshot_and_full_unused_coverage',120)]
def sha(b):return hashlib.sha256(b).hexdigest()
def save(name,obj):
 (OUT/name).write_text(json.dumps(obj,indent=2)+'\n')
def iso(m):return datetime.datetime.fromtimestamp(m,datetime.timezone.utc).isoformat()
result={'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'regression_root':str(ROOT),'run_id':'20261108T093645-d959cfabae08','cases':[]}
log_bytes=(EVID/'compiler-policy-driver.log').read_bytes()
(OUT/'active-log-snapshot.gz').write_bytes(gzip.compress(log_bytes,mtime=0))
log=log_bytes.decode().splitlines();result['log_snapshot']={'bytes':len(log_bytes),'sha256':sha(log_bytes),'lines':len(log)}
result['suite_summaries']=[l for l in log if re.match(r'Ran \d+ tests|FAILED \(|OK$|REGRESSION_FINISH',l)]
current=None;markers=[]
for n,l in enumerate(log,1):
 m=re.match(r'test_\S+ \(([^)]+)\) \.\.\. (.*)',l)
 if m:current=m[1]
 if (m and m[2]=='ERROR') or l=='ERROR':markers.append({'line':n,'id':current})
result['error_markers']=markers
observations=[]
with (EVID/'compiler-policy/observations.jsonl').open() as f:
 for l in f:
  try:o=json.loads(l)
  except json.JSONDecodeError:continue
  if '2026-11-08T11:39:00' <= o['utc'] <= '2026-11-08T11:51:15': observations.append(o)
save('failure-window-observations.json',observations)
launch=json.loads((EVID/'compiler-policy/launch.json').read_text())
result['affinity']={k:launch[k] for k in ['original_affinity','selected_affinity']}
for dn,ix,archive,test_id,deadline in CASES:
 dest=OUT/dn;dest.mkdir(exist_ok=True)
 index=json.loads((EVID/dn/ix).read_text());shutil.copyfile(EVID/dn/ix,dest/ix)
 packet=(EVID/dn/archive).read_bytes();(dest/archive).write_bytes(packet)
 indexed={x['path']:x for x in index.get('files',index.get('artifacts',[]))}
 info={'test_id':test_id,'compile_deadline_seconds':deadline,'packet_sha256':sha(packet),'packet_bytes':len(packet),'packet_index_utc':index['utc'],'workspace':index['workspace']}
 with tarfile.open(dest/archive) as t:
  names=[x.name for x in t.getmembers() if x.isfile()]
  assert set(names)==set(indexed),(dn,'archive/index member mismatch')
  assert len(names)==len(indexed),(dn,'duplicate members')
  for n in names:
   b=t.extractfile(n).read();i=indexed[n]
   assert len(b)==i['bytes'] and sha(b)==i['sha256'],(dn,n)
  info['verified_files']=len(names)
  source=t.extractfile('main.adb').read();(dest/'main.adb').write_bytes(source)
  info['source']={'bytes':len(source),'sha256':sha(source)}
  info['spark_units']=sorted(Path(n).name for n in names if n.endswith('.spark'))
  info['executable_members']=[n for n in names if n.startswith('bin/')]
  info['reports']={}
  for n in ['obj/gnatprove/gnatprove.out','obj/gnatprove/gnatprove.sarif','obj/gnatprove/main~1.spark']:
   if n not in names:continue
   b=t.extractfile(n).read();(dest/Path(n).name).write_bytes(b)
   report={'sha256':sha(b),'mtime':iso(t.getmember(n).mtime)}
   if n.endswith('.out'):
    report['total_line']=[l for l in b.decode().splitlines() if l.startswith('Total ')]
    report['analyzed_units']=[l for l in b.decode().splitlines() if l.startswith('Analyzed ')]
   elif n.endswith('.sarif'):
    j=json.loads(b);report['invocations']=[i for r in j['runs'] for i in r.get('invocations',[])]
   else:
    j=json.loads(b);report.update({k:j.get(k) for k in ['progress','stop_reason','spark']})
    report['entities']=[v['name'] for v in j.get('entities',{}).values()]
    report['records']={k:[{x:i.get(x) for x in ['rule','severity','how_proved','message']} for i in j.get(k,[])] for k in ['flow','proof','warn_error']}
   info['reports'][n]=report
 workspace=Path(index['workspace']).name
 rows=[o for o in observations if any(workspace in p['command'] for p in o['processes'])]
 info['resources']={'sample_count':len(rows),'first_utc':rows[0]['utc'],'last_utc':rows[-1]['utc'],'max_counted_processes':max(len(o['processes']) for o in rows),'min_available_kib':min(o['mem_available_kib'] for o in rows),'affinity_violations':[v for o in rows for v in o['affinity_violations']],'why3_commands':sorted(set(p['command'] for o in rows for p in o['processes'] if 'why3server' in p['command']))}
 result['cases'].append(info)
for fn in ['before.json','stopped.json','after.json','preservation-and-cleanup.json']:
 shutil.copyfile(EVID/'maximum-expression-diagnostic'/fn,OUT/'maximum-expression-diagnostic'/fn)
shutil.copyfile(EVID/'failure-markers.json',OUT/'failure-markers.json')
comparisons=[]
for p in ['tests/test_samples.py','tests/test_scalar_functions.py','tests/test_shared_bindings.py','tests/test_silver.py','src/silver_output_profile.adb']:
 old=subprocess.run(['git','show','c437a41d30dbdbd174773cab1f5d647dc6e7bbf3:'+p],cwd=ROOT,capture_output=True,check=True).stdout
 now=(ROOT/p).read_bytes()
 comparisons.append({'path':p,'old_sha256':sha(old),'current_sha256':sha(now),'equal':old==now})
result['prior_source_comparison']=comparisons
prior_index=json.loads((PRIOR/'retained-files.json').read_text());prior_verified=[]
for f in prior_index:
 b=gzip.decompress((PRIOR/(f['name']+'.gz')).read_bytes())
 assert len(b)==f['size'] and sha(b)==f['sha256']
 prior_verified.append(f)
 if f['name']=='native.log':
  prior_lines=b.decode().splitlines();matches=[l for l in prior_lines if any('('+c[3]+')' in l for c in CASES)]
  (OUT/'prior-three-outcomes.txt').write_text('\n'.join(matches)+'\n')
  assert len(matches)==3 and all(l.endswith(' ... ok') for l in matches)
  result['prior_outcome_lines']=matches
 elif f['name']=='events.jsonl':
  events=[json.loads(l) for l in b.splitlines()];(OUT/'prior-events-summary.json').write_text(json.dumps([{k:e[k] for k in ['event','utc','command','resources','workers','returncode','outcome','duration_seconds'] if k in e} for e in events],indent=2)+'\n')
result['verified_prior_artifacts']=prior_verified
shutil.copyfile(PRIOR/'result.json',OUT/'prior-result.json')
# Static selector match check against the earlier accepted inventory, no imports/discovery.
mat=OUT.parents[1]/'regression-delta-68c4-298'
result['scope']='Read-only evidence inspection. No build, proof, unittest, audit invocation, signal or lease/cache mutation.'
save('inspection.json',result)
print(json.dumps({'output':str(OUT),'errors':markers,'cases':[{'test':x['test_id'],'verified_files':x['verified_files'],'source':x['source'],'spark_units':x['spark_units'],'resources':x['resources']} for x in result['cases']],'suite_summaries':result['suite_summaries']},indent=2))
