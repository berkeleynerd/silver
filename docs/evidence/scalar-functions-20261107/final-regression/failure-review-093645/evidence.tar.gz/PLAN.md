# Conditional unchanged-check retry plan

This plan is not execution authorization for this reviewer. Run
20261108T093645-d959cfabae08 finished failed at 12:21:44 UTC. Independent final
parsing reconciles all 338 selected IDs: 335 passed and exactly three had compile
subprocess.TimeoutExpired exceptions, at 300/120/120 s; there were no skips.
The earlier pending classification was resolved from actual final tracebacks,
not inferred from elapsed time. No retry has been executed by this reviewer.

1. Let the original suite finish. Retain the actual final tracebacks, wrapper
   finish, managed outcome and final per-ID outcomes. Independently compare the
   complete prepared inputs after a nonzero run, because the managed subprocess
   failure can occur before its normal postflight. Preserve the failed outcome.
2. Preserve failure workspaces and process evidence. Before a retry, the coordinator
   checks actual descendant/process identities, relevant workspaces and leases;
   stale processes must not contaminate another attempt. This reviewer neither
   signals nor cleans processes or artifacts. The preserved maximum tree records
   cleanup completed at 11:51:05 UTC; this is not a blanket absence claim for all
   future descendants. An ancestry-only sampler loses reparented orphans.
3. After the current native and Lean runs truly finish and release reservations,
   recheck allowed CPU mask, host headroom, shared managed budget and output lease.
   Prefer the complete actual host CPU allowance, with a matching reservation,
   and no inherited four-CPU restriction. At preparation the launcher originally
   allowed CPUs 0–21, and the host budget was 22. The concrete commands below use
   22 only for that condition. They are ordinary managed test commands, not a
   change to production -j0 or any test/prover option. Retain actual inherited
   masks and Why3 job arguments; a reservation is not OS enforcement or exclusive
   cores. Wait if the full allocation is unavailable rather than launching over
   the still-productive dense runs.
4. Run only maximum_dynamic_expression first through unchanged discovery and the
   exact complete-ID selector. Keep its 300 s compilation deadline, 10 s execution
   deadline, production timeout 0, steps 100000, full input domain, report audit,
   source correspondence checks and assertions unchanged. If it fails, preserve
   its evidence and inspect the exact exception/obligation before deciding the
   next experiment; do not launch a blind repetition or expose another case to
   its orphan work. This distinguishes resource allowance from weakening checks.
5. If the first case succeeds and its owned subprocesses have finished, run each
   scalar-function case as a separate ordinary managed invocation. Keep the 120 s
   compile and 10 s execution deadlines and all report/function/output assertions.
   Separate invocations isolate any newly orphaned work and make outcomes exact.
6. Keep successful unaffected IDs from the completed four-CPU run only after exact
   final input/tool/configuration applicability review. Later successful retries
   supplement that failed run; they do not relabel it successful. A resource-only
   retry can establish a fresh passing check, but cannot by itself prove why the
   original failed. Complete native/Lean and the full platform wrapper remain
   separate required evidence.

`commands.json` contains the three exact argv arrays, run sequentially from the
regression checkout under the above conditions. Their full-ID substring selectors
were matched statically against all 637 previously resolved IDs: each matches one
and only one intended ID. No discovery or test was executed here.

## Current evidence and hypothesis

All 181 + 161 + 173 archived files independently match their index. Exact retained
application bytes are in each packet's `main.adb`. The maximum packet lacks a Main
.spark report; scalar packets each lack silver_io.spark and any bin/ executable.
Scalar GNATprove reports summarize 20 and 23 checks with none unproved among those
listed, but only four units; five units and application/function coverage are
required. Their SARIF executionSuccessful values cannot supply missing coverage
or an end-to-end test result. Report mtimes are later than the ERROR windows.

All three methods passed in retained raw log 021923 on older compiler inputs.
Their two test files and two shared helpers are byte-identical to c437a41d; parser
bytes changed from 9ec28d94 to 036a53b4. The old run reserved two workers and ran
discovery directly, without this new affinity wrapper; no actual CPU-affinity
record or per-method elapsed time was retained. Do not call it a controlled
same-input performance comparison.

Current samples show Why3 -j 22 under CPUs 18–21 for all three cases. A preserved
maximum-expression orphan remained until 11:51 on those same four CPUs, overlapping
both scalar errors and disappearing from later ancestry-only resource counts.
This makes oversubscription and orphan contention plausible hypotheses. Sampled
host available memory remained above 50 GiB across the three workspace windows;
there is no observed host memory-pressure evidence in those samples. The final tracebacks confirm compilation timeouts; causation and per-CPU
utilization remain unestablished. The successful unaffected methods can be
retained subject to complete final applicability review.

## Remaining platform wrapper scheduling

Coordinator requested this bounded scheduling assessment after the three-method
plan. Run the unchanged remaining platform wrapper after the three isolated
methods, with no four-CPU affinity restriction and the full then-available managed
allocation. Its existing current outer deadline is 900 s, not the historical
180 s shown in failed run 021923. It executes eleven sequential setup workers and
one four-worker group, generating the current certificates; native/Lean tools in
those fixture workers are mocked. Four CPUs are not inherently insufficient, but
waiting avoids contention without changing fixture inputs or checks. Additional
cores do not imply proportional speedup for its sequential portions. Keep the
exact twelve-body PlatformIsolationTests selection and its current inner deadlines.
Use the existing prepared ordinary dev.py test command, --jobs 0, only once dense
runs have released resources; record actual worker grant and inherited mask. The
wrapper is fresh required evidence on the changed parser/proof-copy inputs, not
one of the three failed methods and not native cross-platform proof evidence.
