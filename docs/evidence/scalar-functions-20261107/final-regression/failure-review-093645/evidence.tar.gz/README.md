# Bounded regression failure diagnosis

Final outcome is in final-summary.json, exact per-ID outcomes in final-per-id.json,
and original exceptions in final-tracebacks.txt. The final driver log and selected
coordinator packet metadata/events are retained. This review independently resolves
all 338 selected IDs and their outcomes, verifies the coordinator's 34 indexed
payloads, and reconciles its 1,115-row postflight map against original preparation.
The coordinator performed live postflight hashing; this reviewer did not repeat it.

inspection.json and the three named diagnostic directories retain verified
workspace archives, source/report extracts and resource windows. inspect_packets.py
is the read-only archive/comparator inspection script; finalize.py is the read-only
final parser/verifier. Neither executes tests, compilers or proof tools. These
scripts write only their own scratch directory. The inspection snapshot was
refreshed after final completion during report preparation; final-summary.json
is the authoritative final census rather than the earlier marker list.

PLAN.md and commands.json describe three separate unchanged failed-method retries,
serialized under the full actual allowance after native/Lean resources release.
platform-wrapper-command.json supplies the remaining original wrapper afterward.
No commands were executed by this reviewer. Report fragment records the reviewed
facts and limits; the committed review report additionally identifies this bundle.

manifest.json indexes every payload by size and SHA256. shareable-evidence.tar.gz
contains those payloads and the manifest; shareable-evidence.json records its hash.
