"""Retain the actual completed 338-test run without repeating any test."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import re

root = Path(__file__).resolve().parent.parent
regression = root.parent / 'scalar-functions-298'
scratch = regression / 'tmp/repaired-input-regressions'
run_id = '20261108T093645-d959cfabae08'
run = root.parents[1] / '.git/silver-runs/linux-x86_64/78cde64c3e47f2cb/runs' / run_id
events = [json.loads(line) for line in (run / 'events.jsonl').read_text().splitlines()]
finished = [event for event in events if event['event'] == 'finished']
assert len(finished) == 1, 'Actual managed completion is required'
actual_exit = json.loads((scratch / 'compiler-policy-managed-exit.json').read_text())
result = json.loads((scratch / 'compiler-policy/result.json').read_text())
log = (scratch / 'compiler-policy-driver.log').read_text()
selected = (scratch / 'compiler-policy-ids.txt').read_text().splitlines()
outcomes = {}
pending = None
for line in log.splitlines():
    match = re.match(r'^test_\S+ \(([^)]+)\)(?: \.\.\.\s*(.*))?$', line)
    if match:
        assert pending is None, (pending, line)
        pending, rest = match.groups()
        assert pending not in outcomes, pending
    else:
        rest = line.strip()
    status = re.search(r'(?:^|\.\.\.\s+)(ok|ERROR|FAIL)$', rest or '')
    if pending and status:
        outcomes[pending] = status.group(1)
        pending = None
assert pending is None, pending
assert set(outcomes) == set(selected), (set(selected) - outcomes.keys(), outcomes.keys() - set(selected))
assert len(outcomes) == len(selected) == 338
assert re.search(r'^Ran 338 tests in [0-9.]+s$', log, re.M)
prepared = next(event for event in events if event['event'] == 'prepared')
input_rows = []
for name, expected in prepared['inputs']['inputs_sha256'].items():
    path = Path(name)
    current = hashlib.file_digest(path.open('rb'), 'sha256').hexdigest() if path.is_file() else None
    input_rows.append({'path': name, 'expected': expected, 'current': current, 'equal': expected == current})
packet = root / 'docs/evidence/scalar-functions-20261107/final-regression/repaired-compiler-policy-093645'
packet.mkdir(exist_ok=False)
index = []

def retain(source, relative):
    data = source.read_bytes()
    target = packet / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.suffix == '.gz' and source.suffix != '.gz':
        target.write_bytes(gzip.compress(data, mtime=0))
        decoded = gzip.decompress(target.read_bytes())
    else:
        target.write_bytes(data)
        decoded = target.read_bytes()
    assert decoded == data
    index.append({'artifact': relative, 'source': str(source), 'bytes': len(data),
                  'sha256': hashlib.sha256(data).hexdigest(), 'stored_bytes': target.stat().st_size,
                  'stored_sha256': hashlib.sha256(target.read_bytes()).hexdigest()})

for name in ['events.jsonl', 'native.log']:
    retain(run / name, 'managed/' + name + '.gz')
for name in ['affinity-launcher.py', 'capture-failed-subtree.py', 'commands.json',
             'compiler-policy-ids.txt', 'compiler-policy-preflight-status.json',
             'compiler-policy-driver.log', 'compiler-policy-managed-exit.json',
             'managed-command.json', 'failure-markers.json']:
    retain(scratch / name, name + '.gz')
for directory in ['compiler-policy', 'maximum-expression-diagnostic',
                  'self-actuals-diagnostic', 'ordered-calls-diagnostic']:
    for source in sorted((scratch / directory).rglob('*')):
        if source.is_file():
            relative = str(source.relative_to(scratch))
            retain(source, relative if source.suffix == '.gz' else relative + '.gz')
observations = [json.loads(line) for line in (scratch / 'compiler-policy/observations.jsonl').read_text().splitlines()]
summary = {
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'run_id': run_id, 'implementation': 'f6308191545c1012d76132ae535977e55fd4f018',
    'regression_commit': '4281f71171477c24995eae18c983ae69b1cd1747',
    'finished': finished[0], 'actual_driver': actual_exit, 'actual_launcher': result,
    'tests': len(outcomes), 'counts': {key: list(outcomes.values()).count(key) for key in ['ok', 'ERROR', 'FAIL']},
    'skips': 0, 'per_id': outcomes,
    'sample_manifest': 'test_manifest_samples passed all72 manifest samples on repaired compiler',
    'postflight_input_count': len(input_rows), 'postflight_input_changes': [r for r in input_rows if not r['equal']],
    'observation_count': len(observations),
    'minimum_observed_available_gib': min(row['mem_available_kib'] for row in observations) / 2**20,
    'sampled_affinity_violations': [row for row in observations if row.get('affinity_violations')],
    'scope': 'Actual failed affected regression retained as failed; no test repeated, proof/options/domain changed, or complete native/Lean assurance claimed.'
}
(packet / 'postflight-inputs.json').write_text(json.dumps(input_rows, indent=2) + '\n')
(packet / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
(packet / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
assert not summary['postflight_input_changes'], summary['postflight_input_changes']
print(json.dumps({'packet': str(packet), 'tests': len(outcomes), 'counts': summary['counts'],
                  'input_count': len(input_rows), 'artifacts': len(index),
                  'actual_driver': actual_exit, 'finished': finished[0]}, indent=2))
