"""Preserve and stop a verified orphan subtree after a test has reported ERROR."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import os
import re
import signal
import sys
import tarfile
import time

root = Path(__file__).resolve().parents[2]
pid_root = int(sys.argv[1])
workspace = root / '.silver/linux-x86_64' / sys.argv[2]
out = Path(__file__).resolve().parent / sys.argv[3]
out.mkdir(exist_ok=True)


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def processes():
    table = {}
    for directory in Path('/proc').iterdir():
        if not directory.name.isdigit():
            continue
        try:
            fields = (directory / 'stat').read_text().rsplit(') ', 1)[1].split()
            pid = int(directory.name)
            table[pid] = {'pid': pid, 'state': fields[0], 'ppid': int(fields[1]),
                          'pgid': int(fields[2]), 'sid': int(fields[3]), 'start_ticks': fields[19],
                          'command': (directory / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace'),
                          'affinity': sorted(os.sched_getaffinity(pid))}
        except (OSError, ValueError, IndexError):
            continue
    return table


def closure(table):
    owned = {pid_root}
    while True:
        expanded = owned | {pid for pid, row in table.items() if row['ppid'] in owned}
        if expanded == owned:
            return owned
        owned = expanded


before = processes()
assert before[pid_root]['ppid'] == 1 and before[pid_root]['pgid'] == 682577
assert str(workspace) in before[pid_root]['command'] and workspace.is_dir()
owned = {pid: before[pid] for pid in closure(before) if pid in before}
assert all(set(row['affinity']).issubset({18, 19, 20, 21}) for row in owned.values())
actions = []
rows = []
(out / 'before.json').write_text(json.dumps({'utc': utc(), 'root_pid': pid_root,
    'reason': 'Capture and clean only verified orphaned proof subtree after its parent test reported ERROR; no group signal or retry',
    'processes': list(owned.values())}, indent=2) + '\n')
try:
    stopped = set()
    while True:
        table = processes()
        for pid in closure(table):
            if pid in table and pid not in owned:
                owned[pid] = table[pid]
        for pid, original in sorted(owned.items()):
            current = table.get(pid)
            if current and current['start_ticks'] == original['start_ticks'] and current['state'] != 'Z' and pid not in stopped:
                os.kill(pid, signal.SIGSTOP)
                actions.append({'utc': utc(), 'pid': pid, 'signal': 'SIGSTOP'})
                stopped.add(pid)
        time.sleep(0.1)
        table = processes()
        if closure(table).issubset(owned) and all(table[pid]['state'] in {'T', 't', 'Z'} for pid in owned if pid in table):
            break
    (out / 'stopped.json').write_text(json.dumps({'utc': utc(), 'processes': [table[p] for p in owned if p in table]}, indent=2) + '\n')
    inputs = {p: str(p.relative_to(workspace)) for p in workspace.rglob('*') if p.is_file()}
    for process in owned.values():
        for name in re.findall(r'/tmp/why_[^ ]+', process['command']):
            path = Path(name)
            if path.is_file():
                inputs[path] = 'live-solver-tasks/' + path.name
    with tarfile.open(out / 'failed-workspace-before-cleanup.tar.gz', 'w:gz') as archive:
        for source, relative in sorted(inputs.items()):
            data = source.read_bytes()
            rows.append({'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
            archive.add(source, arcname=relative, recursive=False)
    (out / 'workspace-index.json').write_text(json.dumps({'workspace': str(workspace), 'utc': utc(), 'files': rows}, indent=2) + '\n')
    for name in ['compiler-policy-driver.log', 'compiler-policy/launch.json', 'compiler-policy/observations.jsonl']:
        source = out.parent / name
        data = source.read_bytes()
        target = out / (source.name + '.gz')
        target.write_bytes(gzip.compress(data, mtime=0))
        actions.append({'artifact': target.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                        'scope': 'Snapshot from active suite; not final managed outcome'})
finally:
    table = processes()
    for pid, original in sorted(owned.items(), reverse=True):
        current = table.get(pid)
        if current and current['start_ticks'] == original['start_ticks'] and current['state'] != 'Z':
            try:
                os.kill(pid, signal.SIGTERM)
                os.kill(pid, signal.SIGCONT)
                actions.append({'utc': utc(), 'pid': pid, 'signals': ['SIGTERM', 'SIGCONT']})
            except ProcessLookupError:
                pass
    (out / 'preservation-and-cleanup.json').write_text(json.dumps(actions, indent=2) + '\n')
time.sleep(1)
table = processes()
remaining = [table[p] for p, original in owned.items() if p in table
             and table[p]['start_ticks'] == original['start_ticks'] and table[p]['state'] != 'Z']
(out / 'after.json').write_text(json.dumps({'utc': utc(), 'remaining_live_owned_processes': remaining}, indent=2) + '\n')
print(json.dumps({'snapshot_files': len(rows), 'owned_pids': len(owned), 'remaining_live': remaining, 'packet': str(out)}))
