"""Prepare per-ID applicability from the retained matrix; execute no tests."""
from pathlib import Path
import collections
import fnmatch
import hashlib
import json
import re
import shlex
import subprocess

OUT = Path(__file__).resolve().parent
PRIOR = OUT.parent / "regression-applicability-review-298"
BASE = "d396db2aeb498cd132bbe4b9f0ea3f0fb93687f8"
TARGET = "68c4fd259b34dd635bafd35a17436356a4938dfe"


def git(*args):
    return subprocess.check_output(["git", *args])


def blob(path, commit=TARGET):
    return git("show", f"{commit}:{path}")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")


matrix = json.loads((PRIOR / "independent-final-matrix.json").read_text())
assert len(matrix) == len({row["id"] for row in matrix}) == 637
changes = git("diff", "--name-only", f"{BASE}..{TARGET}").decode().splitlines()
tracked_delta = [path for path in changes if not path.startswith("docs/") and path != "roadmap.md"]
assert len(tracked_delta) == 22
assert [path for path in tracked_delta if not path.startswith("proof/")] == ["src/silver_output_profile.adb"]
unchanged_roots = ["tests", "scripts", "samples", "catalogue", "rosetta", "silver.gpr", "alire.toml",
                   "proof/lakefile.lean", "proof/lean-toolchain", "proof/generate_source_certificate.py",
                   "proof/silver_proof_containers.gpr"]
assert not git("diff", "--name-only", f"{BASE}..{TARGET}", "--", *unchanged_roots)
assert not git("diff", "--name-only", "5aa1509fc5ac2d6f2dc02c5803d94da7e201aaf1.." + TARGET, "--", "tests")
test_files = sorted({row["definition"]["path"] for row in matrix})
test_identities = [{"path": path, "sha256": sha(blob(path)), "unchanged_from_accepted_target":
                    blob(path) == blob(path, BASE)} for path in test_files]
assert all(row["unchanged_from_accepted_target"] for row in test_identities)

fixture_inputs = json.loads((PRIOR / "fixture-target-byte-identities.json").read_text())
fixture_delta = [{**row, "target_sha256": sha(blob(row["path"])),
                  "unchanged": sha(blob(row["path"])) == row["sha256"]} for row in fixture_inputs]
assert all(row["unchanged"] for row in fixture_delta if row["fixture"] == "chunk")
assert sum(row["fixture"] == "chunk" for row in fixture_delta) == 20

# Probe builds have explicit mains; their Ada with-closures do not include the parser.
tracked = set(git("ls-tree", "-r", "--name-only", TARGET).decode().splitlines())
probe_roots = ["tests/library_reports_probe.adb", "tests/report_projection_probe.adb", "tests/image_model_probe.adb"]
probe_closures = {}
for root in probe_roots:
    pending = [root]
    found = set()
    while pending:
        path = pending.pop()
        if path in found:
            continue
        found.add(path)
        text = blob(path).decode()
        for clause in re.findall(r"^\s*(?:(?:limited|private)\s+)?with\s+([^;]+);", text, re.M | re.I):
            for name in clause.split(","):
                unit = name.strip().lower().replace(".", "-")
                if not re.fullmatch(r"[a-z][a-z0-9_-]*", unit):
                    continue
                for ext in ("ads", "adb"):
                    candidate = "src/" + unit + "." + ext
                    if candidate in tracked:
                        pending.append(candidate)
    assert "src/silver_output_profile.adb" not in found
    assert all(blob(path) == blob(path, BASE) for path in found)
    probe_closures[root] = sorted(found)

retained_modules = {
    "test_argument_bounds": "Explicit seven-file argument/runtime probe; changed parser excluded from Source_Files.",
    "test_dev_runs": "Synthetic HostLayout, fixture sources/reports/tools and mocked invocation; only unchanged production GPRs copied.",
    "test_evidence": "Synthetic report/advisory/provenance records; source checks use unchanged runtime/image/vendor binding files, not production parser bytes.",
    "test_image_model": "Standalone image_model_probe and unchanged Ada dependency closure; no compiler parser link.",
    "test_image_reports": "Synthetic advisory audits or standalone library_reports_probe; inherited methods and shared fixture unchanged.",
    "test_image_setup": "Mock vendor tree plus unchanged six runtime sources, adapter source and bootstrap/configuration scripts.",
    "test_lean_evidence": "Retained synthetic proof roots and native probes copy unchanged bindings/AxiomAudit/lakefile/pin; source texts are fixture literals.",
    "test_lean_modules": "Synthetic module/source projects; unchanged seven copied Lean helpers, generator, lakefile/pin and repaired test.",
    "test_lean_run_history": "Synthetic runner/lease fixture inherited from unchanged LeanRunnerPhaseTests.",
    "test_library_reports": "Standalone library_reports_probe and unchanged Ada dependency closure; no production compiler binary or parser.",
    "test_proof_provenance": "Synthetic source/report/tool identities and mocked tools; unchanged production GPRs only.",
    "test_report_projection": "Standalone report_projection_probe/library_reports_probe with unchanged source closures and native GPR.",
    "test_rosetta": "Current render/assessment inputs unchanged; three fresh tests still required after future promotion.",
    "test_run_history": "Synthetic managed-run workspaces/resources/process fixtures; unchanged scripts and Python.",
    "test_static_proof": "Synthetic false-static-contract Ada project using unchanged native toolchain, not the compiler parser.",
}
pure_exceptions = {
    "test_boolean_objects.BooleanObjectTests.test_rosetta_expected_outputs_use_independent_task_oracles":
        "Reads unchanged samples/manifest.json and computes independent task oracles; no compiler invocation.",
    "test_capacity.CapacityEnvelopeTests.test_retained_record_and_whole_report_envelopes":
        "Pure report-envelope calculation and unchanged silver_library_reports.ads/silver_platform.ads constants; no parser or compiler invocation.",
    "test_image_adapter.ImageAdapterTests.test_adapter_failures_are_actionable_and_preserve_snapshots":
        "Invokes only unchanged Image adapter on synthetic/missing native-model files; no Silver compiler.",
    "test_image_adapter.ImageAdapterTests.test_unchanged_cleanup_retention_and_native_failure":
        "Invokes only unchanged Image adapter/vendor help/failure paths on synthetic models; no Silver compiler.",
}
source_policy_affected = {
    row["id"] for row in matrix if row["final_group"] == "fresh_source_policy"
} | {"test_lean_source.CompilerSourcePolicyTests." + name for name in (
    "test_checked_in_certificates_equal_regeneration",
    "test_output_body_split_preserves_every_line_proof_and_ordered_reconstruction",
    "test_current_compiler_sources_satisfy_byte_policy")}
assert len(source_policy_affected) == 7
wrapper = "test_platforms.InstallationEnvironmentTests.test_symlinked_tmpdir_preserves_platform_setup_and_routing"
rows = []
for old in matrix:
    identity = old["id"]
    module = Path(old["definition"]["path"]).stem
    status, reason = "rerun_compiler", "Executes changed Silver compiler binary or rebuilds the full compiler fixture; parser/source and build inputs changed."
    if identity in pure_exceptions:
        status, reason = "reusable", pure_exceptions[identity]
    elif module in retained_modules:
        status, reason = "reusable", retained_modules[module]
    elif module == "test_lean_source":
        if identity in source_policy_affected:
            status, reason = "rerun_source_policy", "Reads changed production source/certificates or complete production Lean inventory/import closure."
        else:
            status, reason = "reusable", "Uses unchanged binding/lake/generator metadata, synthetic source strings or fixed unchanged native helper chain."
    elif module == "test_platforms":
        if identity.startswith("test_platforms.PlatformIsolationTests."):
            status, reason = "rerun_platform_body_via_wrapper", "Each setUp copies changed complete production Lean tree; original wrapper selects all 12 unchanged bodies without skips."
        elif identity == wrapper:
            status, reason = "rerun_platform_wrapper", "Original wrapper must exercise the changed complete production fixture and cover all 12 nested body IDs."
        else:
            status, reason = "reusable", "Installation method uses unchanged runtime/bootstrap inputs and no full production Lean fixture or compiler parser."
    rows.append({"id": identity, "classification": status, "reason": reason,
                 "prior_evidence_run": old["evidence_run"], "prior_group": old["final_group"],
                 "definition": old["definition"]})

counts = dict(collections.Counter(row["classification"] for row in rows))
assert counts == {"reusable": 286, "rerun_compiler": 331, "rerun_source_policy": 7,
                  "rerun_platform_wrapper": 1, "rerun_platform_body_via_wrapper": 12}, counts
groups = {
    "compiler-policy": [row["id"] for row in rows if row["classification"] in ("rerun_compiler", "rerun_source_policy")],
    "platform-wrapper": [wrapper],
}
commands = {}
for name, selected in groups.items():
    # unittest's -k wraps patterns without '*' in '*...*'. Simulate selection
    # against the exact retained discovery census, including imported aliases.
    matched = {row["id"] for row in rows if any(fnmatch.fnmatchcase(row["id"], "*" + pattern + "*") for pattern in selected)}
    assert matched == set(selected), (name, matched ^ set(selected))
    command = ["python3", "scripts/dev.py", "test", "--jobs", "0", "--task", "298-regression-" + name,
               "--reason", "Fresh affected regression after reviewed parser and source repair; stable final inputs required", "--"]
    for identity in selected:
        command.extend(["-k", identity])
    commands[name] = command
    (OUT / (name + "-ids.txt")).write_text("\n".join(selected) + "\n")
    (OUT / (name + "-command.sh")).write_text("#!/bin/sh\n# Preparation only. Run from the final checkout after lease/build/resource review.\n" + shlex.join(command) + "\n")

save("per-id-delta.json", rows)
save("test-input-identities.json", test_identities)
save("fixture-input-delta.json", fixture_delta)
save("native-probe-source-closures.json", probe_closures)
save("commands.json", commands)
summary = {"base": BASE, "target": TARGET, "scope": "Preparation only; no tests/build/fixtures executed",
           "counts": counts, "total_ids": 637, "fresh_required_unique_ids": 351,
           "fresh_top_level_selected_ids": 339, "nested_platform_ids": 12,
           "tracked_input_changes": tracked_delta, "unchanged_test_modules": len(test_files),
           "tests_inventory_reused_by_exact_module_identity": True,
           "unchanged_roots": unchanged_roots, "chunk_copied_inputs_unchanged": 20,
           "platform_copied_inputs_changed": [row["path"] for row in fixture_delta if row["fixture"] == "platform" and not row["unchanged"]],
           "managed_test_selector_static_census_check": True,
           "required_preconditions": ["Stable final inputs and successful fresh compiler build",
                "Retained tool/configuration/adapter identities revalidated on final host",
                "No overlapping dense jobs; managed auto allocation reserves actual host worker capacity",
                "Complete new pass/no-skip coverage and per-ID postflight reconciliation"],
           "future_rosetta_promotion_requires_three_fresh_tests": True}
save("summary.json", summary)
normalization = git("rev-parse", "f630819154").decode().strip()
followup = git("rev-parse", "6b6969187e").decode().strip()
extra = git("diff", "--name-only", f"{TARGET}..{normalization}").decode().splitlines()
extra_production = [path for path in extra if not path.startswith("docs/")]
assert extra_production == ["proof/Silver/FunctionDeclarationDenotations.lean",
                            "proof/Silver/PredicateFunctionCallHelpers.lean"]
later = git("diff", "--name-only", f"{normalization}..{followup}").decode().splitlines()
assert all(path.startswith("docs/") for path in later)
copied_platform = {row["path"] for row in fixture_inputs if row["fixture"] == "platform"}
assert set(extra_production) <= copied_platform
save("followup-applicability.json", {
    "normalization_commit": normalization, "docs_only_followup": followup,
    "classification_counts_unchanged": counts,
    "native_source_unchanged": blob("src/silver_output_profile.adb", followup) == blob("src/silver_output_profile.adb"),
    "later_changed_paths_are_docs_only": later,
    "already_affected_platform_copies": [{"path": path, "at_68c4_sha256": sha(blob(path)),
        "at_followup_sha256": sha(blob(path, followup)),
        "same_as_normalization": blob(path, followup) == blob(path, normalization)} for path in extra_production],
    "no_new_regression_category": True,
})
print(json.dumps({key: summary[key] for key in ("counts", "total_ids", "fresh_required_unique_ids", "fresh_top_level_selected_ids", "chunk_copied_inputs_unchanged")}, indent=2))
