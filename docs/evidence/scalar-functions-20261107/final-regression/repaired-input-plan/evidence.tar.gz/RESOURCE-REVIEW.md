# Bounded resource alternative review

The coordinator proposes using the original regression worktree, synchronized
to exact final source/proof/test inputs while preserving its caches/scratch,
with a managed custom Python launcher that reserves four workers and applies
Linux sched_setaffinity before invoking the unchanged unittest discovery command.
This is proposed only; no launcher or test execution was performed by this
reviewer, and the command files in this packet retain the serialization option.

Inherited affinity can enforce a real four-CPU execution allowance despite the
tests' literal native `-j0` options. It does not cap process count or memory:
GNATprove may detect a wider CPU count and spawn more workers that share those
four CPUs. Actual descendant/memory monitoring and host headroom remain necessary.
Other runs can use those CPUs too; this does not create exclusive physical cores.

Capture the original and selected allowed masks, actual wrapper/child masks,
managed worker reservation, unchanged unittest argv and working directory,
complete declared inputs and postflight. `dev.py tool` starts under host.context;
the launcher must run discovery from the regression root. Keep this tooling
outside scripts/, and verify final tracked src/proof/tests plus scripts/config
inputs against the intended integration target. Preserve all unrelated work.

This resource variation does not change the per-ID affected-input partition.
Retained tests keep their original evidence/settings; fresh tests record the new
settings. Timing is not directly comparable. A timeout or failure under the new
setting remains a real outcome; do not loosen assertions or discard it. If exact
input/resource capture or sufficient RAM cannot be established, serialize with
an allocation accounting for actual native capacity.
