# Exact regression applicability delta — 2026-11-08

Preparation only: no compiler build, regression test or platform/chunk fixture
was executed. This plan reuses the independently accepted 637-ID matrix and its
dependency records, then compares accepted `5aa1509fc5ac2d6f2dc02c5803d94da7e201aaf1`
(extended through docs-only `d396db2aeb498cd132bbe4b9f0ea3f0fb93687f8`) with
`68c4fd259b34dd635bafd35a17436356a4938dfe`.

The only non-documentation changes are the 21 reviewed Lean files and
`src/silver_output_profile.adb`. All tracked tests, scripts, samples, catalogue,
Rosetta inputs, project files, source generator, lakefile and toolchain pin are
unchanged. Exact test-module identity preserves the prior independently resolved
637-ID inventory, including five inherited Array-report methods and nine imported
`tests.test_shared_bindings` aliases. No fresh discovery/test execution was used.

## Per-ID disposition

`per-id-delta.json` gives every ID, prior evidence run/group, exact definition and
specific dependency reason. The complete partition is:

| Disposition | Unique IDs | Needed execution |
| --- | ---: | --- |
| Reusable prior successful evidence | 286 | No rerun if retained dependencies/tool identities remain unchanged. |
| Changed compiler/build/sample consumers | 331 | Fresh run after a successful build of the repaired compiler. |
| Affected source-policy methods | 7 | Fresh checks on final parser, certificates and Lean tree. |
| Platform bodies through original wrapper | 12 | Covered by the fresh unchanged wrapper selecting all twelve bodies. |
| Original platform wrapper | 1 | Fresh wrapper on the final production fixture. |
| Total | 637 | 351 unique IDs need fresh evidence; 339 top-level selections cover them. |

The 286 reusable outcomes are a preparation disposition, not final regression
acceptance. Before composing final results, revalidate their retained tool,
configuration and unchanged adapter identities, then reconcile every required
ID with actual final-input evidence. The repaired compiler binary is necessarily
a fresh build input; its old test outcomes are not retained by argument that a
particular call might avoid the changed parser branch.

### Compiler and sample scope

The 331 IDs include every test invoking the real Silver binary, the full-compiler
output-integrity and tool-failure rebuild fixtures, both supported-sample tests,
all scalar-function tests, and both ordinary and imported shared-binding IDs.
The full list is in `compiler-policy-ids.txt` together with the seven policy IDs.
The sample manifest is unchanged, but its admission/proof/compile executions use
the changed compiler and must be fresh.

Two pure methods inside otherwise compiler-dependent modules remain reusable:

- `test_boolean_objects.BooleanObjectTests.test_rosetta_expected_outputs_use_independent_task_oracles`
  reads unchanged sample expectations and computes independent task oracles.
- `test_capacity.CapacityEnvelopeTests.test_retained_record_and_whole_report_envelopes`
  computes report envelopes from unchanged library-report/platform bounds.

In ImageAdapterTests, initializer/loop execution and wrong-image-width rejection
need fresh compiler runs. The other two methods invoke only the unchanged adapter
and native help/failure paths on synthetic model files; their old evidence is
reusable if the final adapter/native identities match.

The standalone argument-normalization probe explicitly lists seven unchanged
runtime files and excludes the parser. Library-report, image-model and report-
projection probes compile their own unchanged mains and dependency closures;
none includes silver_output_profile. Their native probe bodies and the shared
report/inherited Array fixtures remain reusable. The exact reviewed Ada source
closures are in `native-probe-source-closures.json`; native tools/project settings
must retain the prior identities.

### Seven source-policy methods

All are in `test_lean_source.CompilerSourcePolicyTests`:

- `test_checked_in_certificates_equal_regeneration`
- `test_compose_candidate_has_no_authoritative_source_dependencies`
- `test_compose_source_checks_retain_authoritative_dependencies`
- `test_current_compiler_sources_satisfy_byte_policy`
- `test_include_str_is_confined_to_the_source_bindings`
- `test_only_audit_roots_use_legacy_full_imports`
- `test_output_body_split_preserves_every_line_proof_and_ordered_reconstruction`

The first, fourth and seventh read changed parser/certificate bytes. The other
four traverse the changed production proof inventory or import closure. The nine
remaining source-test IDs use unchanged binding/lake/generator metadata, synthetic
source strings or the fixed small native helper chain, so their prior passes
remain reusable on unchanged tooling.

### Synthetic fixtures and platform scope

Existing evidence/runner/history/provenance tests construct synthetic roots,
reports, tools or proof modules. Their production inputs are unchanged scripts,
GPRs, runtime/image/vendor bindings and selected small Lean helpers. They do not
read the repaired production parser or changed semantic proofs. This includes
the synthetic false-static-contract GNATprove probe, whose toolchain is required
to remain the same, and the native Lean probes with literal source fixtures.

The repaired chunk fixture's exact 20 copied inputs remain byte-identical to
68c4: nine helpers, seven production Lean modules, lakefile/pin/generator and test.
Its source text is synthetic. Retain its successful run
`20261108T065724-7d260468ca14`; do not repeat that expensive successful fixture
solely because the production parser/certificate changed.

All 22 changed tracked inputs occur in the platform fixture's retained full-copy
inventory. Its twelve bodies and original wrapper need fresh evidence. The
wrapper still selects the unchanged twelve-member PlatformIsolationTests suite,
with no skip/conditional-selection path, under its symlinked TMPDIR. One fresh
successful wrapper covers those twelve body IDs and the wrapper ID; a separate
standalone class execution is unnecessary for this composition. The three other
installation methods use unchanged runtime/bootstrap inputs and remain reusable.

`fixture-input-delta.json` contains all prior copied-file identities and the exact
target comparison, including the unchanged chunk set and changed platform set.

## Exact commands, not executed

Run from the final integration checkout after checking its managed-run summary,
all actual workspace leases and host headroom. Freeze the final test/source/tool
inputs. Finish the already running dense validation before these regression
commands: application tests preserve their existing native `-j0` behavior, so a
four-worker reservation while other dense jobs run would understate their native
capacity use. The commands use managed `--jobs 0` only after coordination permits
the actual full available-host allocation; record the resolved allocation.

First establish a successful new compiler build:

```sh
python3 scripts/dev.py build --jobs 0 --task 298-regression-repair-build --reason 'Build the reviewed repaired compiler for affected regression inputs'
```

Then execute the two prepared command files, sequentially, from that same final
checkout. They contain fully specified `python3 scripts/dev.py test` commands,
with unchanged discovery/import behavior and one `-k` selector per requested ID:

```sh
sh /home/canto/src/github.com/berkeleynerd/silver/tmp/scalar-functions-delivery-review-298/tmp/regression-delta-68c4-298/compiler-policy-command.sh
sh /home/canto/src/github.com/berkeleynerd/silver/tmp/scalar-functions-delivery-review-298/tmp/regression-delta-68c4-298/platform-wrapper-command.sh
```

`commands.json` records the same exact argv arrays, for a coordinator that copies
the packet elsewhere. The first command selects exactly 338 top-level IDs; the
second selects exactly the original wrapper. The unittest `-k` matching rules
were statically checked against the retained 637-ID census, including both
shared-binding name forms, to exclude accidental extra/missing selections.
These are preparation artifacts, not new test runners or executed validations.

Retain raw logs, managed input maps, exact success/failure/skip outcomes, final
postflight identities and wrapper input/selection evidence. Do not claim all 351
IDs as fresh top-level unittest results: twelve are nested body coverage through
the wrapper. Preserve original failed runs and any new failure as failures; only
successful applicable reruns supplement them. Final composition must account for
all 637 IDs without uncovered tests or skips. Complete native obligation/provenance
and complete Lean/source correspondence remain separate requirements.

## Later changes

The `f630819154` semantic normalization follow-up only changes two files already
within the affected policy/platform set and leaves compiler bytes unchanged;
it adds no new regression category. The classifications extend to that bounded
follow-up and the inspected docs-only follow-up `6b6969187e`. The two copied
platform inputs are `proof/Silver/FunctionDeclarationDenotations.lean` and
`proof/Silver/PredicateFunctionCallHelpers.lean`; their 68c4 and follow-up hashes
are recorded in `followup-applicability.json`. Final execution must capture its
actual input hashes. Future source/test/tool changes require another
affected-input comparison. The coordinator may replace the command's automatic
worker selection with an explicit reservation that accounts for actual child
capacity; selection and proof settings must remain unchanged.

Current Rosetta inputs are unchanged, so its three old passes remain applicable
to 68c4. Promotion still requires all three tests freshly after the promotion
patch. That later command is `python3 scripts/dev.py test --jobs 0 --task
298-rosetta-promotion-regression --reason 'Fresh Rosetta checks after promotion'
-- -p test_rosetta.py`, under coordinated resources. It is not authorized for
execution by this preparation task, and no promotion acceptance is claimed.
