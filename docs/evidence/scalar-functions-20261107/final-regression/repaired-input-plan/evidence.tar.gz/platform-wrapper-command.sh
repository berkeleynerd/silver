#!/bin/sh
# Preparation only. Run from the final checkout after lease/build/resource review.
python3 scripts/dev.py test --jobs 0 --task 298-regression-platform-wrapper --reason 'Fresh affected regression after reviewed parser and source repair; stable final inputs required' -- -k test_platforms.InstallationEnvironmentTests.test_symlinked_tmpdir_preserves_platform_setup_and_routing
