from pathlib import Path
import os,sys,unittest
root=Path(__file__).resolve().parents[2]
os.chdir(root)
sys.path.insert(0,str(root))
sys.path.insert(0,str(root/'tests'))
from test_lean_source import CompilerSourcePolicyTests
names=(
 'test_include_str_is_confined_to_the_source_bindings',
 'test_only_audit_roots_use_legacy_full_imports',
 'test_compose_candidate_has_no_authoritative_source_dependencies',
 'test_compose_source_checks_retain_authoritative_dependencies',
)
suite=unittest.TestSuite(CompilerSourcePolicyTests(name) for name in names)
assert suite.countTestCases()==4
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() and not result.skipped and result.testsRun==4 else 1)
