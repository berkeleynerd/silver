procedure Main is
   pragma SPARK_Mode (On);
   subtype Small is Integer range 0 .. 100;
   subtype Smaller is Integer range 0 .. 99;
   function Is_Prime (N : in Integer) return Boolean is
      Result : Boolean := True;
   begin
      if N < 2 then
         Result := False;
      else
         for D in 2 .. (N / 2) loop
            if (N mod D) = 0 then
               Result := False;
            end if;
         end loop;
      end if;
      return Result;
   end Is_Prime;
   function MiXeD (X : in Smaller) return Small is
   begin
      return (X + 1);
   end MiXeD;
   function Pick (X : in Integer; Enabled : in Boolean) return Small is
      R : Small := 0;
   begin
      if Enabled and then X >= 0 and then X <= 99 then
         R := MiXeD (X);
      end if;
      return R;
   end Pick;
   function Unused (N : in Integer) return Integer is
      R : Integer := 0;
   begin
      if N > 0 then
         R := (100 / N);
      end if;
      return R;
   end Unused;
   I : Small := 0;
   B : Boolean := True;
begin
   B := Is_Prime (97);
   I := Pick (20, B);
   if I < 100 then
      I := MiXeD (I);
   end if;
   B := Is_Prime ((I + 1));
end Main;
