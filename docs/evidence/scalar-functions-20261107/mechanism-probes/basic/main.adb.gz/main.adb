procedure Main is
   pragma SPARK_Mode (On);
   subtype Small is Integer range 0 .. 100;
   function Identity (X : Small) return Small is
      Y : Small := X;
   begin
      return Y;
   end Identity;
   function Previous (X : Small) return Small is
      Y : Small := X;
   begin
      if X > 0 then
         Y := (X - 1);
      end if;
      return Y;
   end Previous;
   function Is_Prime (N : Integer) return Boolean is
      Result : Boolean := True;
   begin
      if N < 2 then
         Result := False;
      else
         for D in 2 .. (N / 2) loop
            if (N mod D) = 0 then
               Result := False;
            end if;
         end loop;
      end if;
      return Result;
   end Is_Prime;
   function Pick (B : Boolean; X : Small) return Small is
      R : Small := 0;
   begin
      if B then
         R := Identity (X);
      else
         R := Previous (X);
      end if;
      return R;
   end Pick;
   I : Small := Pick (Is_Prime (97), 97);
   F : Boolean := Is_Prime (I);
begin
   if F then
      I := Identity (I);
   else
      I := Previous (I);
   end if;
end Main;
