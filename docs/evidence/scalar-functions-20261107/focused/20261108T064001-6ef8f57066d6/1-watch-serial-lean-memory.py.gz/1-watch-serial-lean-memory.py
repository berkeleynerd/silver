from pathlib import Path
import datetime,json,subprocess,sys,time
root=Path(__file__).resolve().parent.parent
run_id=sys.argv[1]
registry=Path('/home/canto/src/github.com/berkeleynerd/silver/.git/silver-runs/linux-x86_64/78cde64c3e47f2cb/runs')/run_id
out=root/'tmp'/f'{run_id}-memory.jsonl'
needle=str(root/'.silver/linux-x86_64/proof/Silver')+'/'
while True:
    events=[json.loads(line) for line in (registry/'events.jsonl').read_text().splitlines()]
    if any(row.get('event')=='finished' for row in events):
        print('Managed run finished; observation stopped',flush=True)
        break
    row={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'run_id':run_id,'mem_available_kib':int(next(line for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')).split()[1]),'lean':[]}
    for line in subprocess.check_output(['ps','-eo','pid,ppid,pcpu,rss,etime,args'],text=True).splitlines():
        parts=line.split(None,5)
        if len(parts)==6 and '/bin/lean ' in parts[5] and needle in parts[5]:
            row['lean'].append({'module':parts[5].split(needle)[1].split('.lean')[0],'pid':int(parts[0]),'ppid':int(parts[1]),'cpu':float(parts[2]),'rss_kib':int(parts[3]),'elapsed':parts[4]})
    with out.open('a') as stream: stream.write(json.dumps(row)+'\n')
    print(row['at'],'available_GiB',round(row['mem_available_kib']/2**20,2),'Lean_GiB',round(sum(item['rss_kib'] for item in row['lean'])/2**20,2),'modules',[(item['module'],item['elapsed']) for item in row['lean']],flush=True)
    time.sleep(15 if row['mem_available_kib']<12*2**20 else 30)
