# Prepared name-qualification repair; not applied

Active serial run 064001 reports an ambiguous expectedTokens at CallsIncludedImpl:20.
Both SourceBridge and FunctionCallNative.SourceChecks are open. The Checked.included_impl
field in PredicateFunctionCallSource:75 uses its own SourceChecks.expectedTokens;
that definition and SourceBridge.expectedTokens both expand to (Source.lexLine text).getD [].

The scratch patch explicitly selects the function-call source requirement namespace.
It changes no source tokens, semantic model, domain, contract or theorem conclusion
value. The kernel proof and complete original Checked field remain required. No
production input is edited while the current closure retains its lease; other
call leaves continue productively. Retain the actual failed run, apply after lease
release along with any separately reviewed necessary changes, and recheck the
leaf/facade/consumer and whole project with retained objects.
