# Exact function-source proof decomposition — scratch proposal

Prepared 2026-11-08 after measured memory growth required cancellation of
FunctionSourceCandidate. Selected GPT-6 Astra / Extra High; runtime model/effort
telemetry unavailable. No Lean/build/test process was launched. No governed
source, proof, cache, tool configuration or integration file was changed.

`function-source-components.patch` is a concrete **uncompiled** proposal;
SHA-256 `f018c845b443695879e59f4425042f5ba12a93c028a8e8c488283b856f931bd3`.
`inventory.json` lists every proposed module, theorem, exact proposition,
table index/native name and original source hash. `proposed/` contains the
reviewable file bodies; `prepare.py` generated these scratch files only.
Read-only application checking passed against the review checkout. Static
inventory checks confirm every leaf is used exactly once by the assembly.
None of these checks establish Lean elaboration or proof success.

## Actual interruption and scope

The coordinator verified PID 582544's exact command and sent SIGTERM only to
FunctionSourceCandidate at 05:12:10.541560 UTC, after available-memory samples
11.66, 10.91 and 10.38 GiB. Its RSS/HWM had reached 40,165,948 KiB (38.31 GiB).
Lake records the required module failed after 1,735 seconds with code 143 and
continues the other source jobs. The action preserves those jobs, native
040128 and completed objects. The required source proof remains unfinished.
The snapshot/action is retained in integration scratch
`tmp/function-source-memory-preservation-action.json`.

Do not apply this proposal or start a second writer while complete run044143
owns the proof workspace or its frozen inputs. First retain that run's actual
failed outcome and completed objects. Apply only after the coordinator releases
the inputs; incorporate the separately reviewed Boolean-candidate repair at the
same stable checkpoint. This proposal changes proof packaging only.

## Exact patch inventory

One existing file changes: `proof/Silver/FunctionSourceCandidate.lean`.
It retains its original three public theorem names and result types:

- `Silver.FunctionSourceCandidate.declarations` proves the complete original
  `Compose.FunctionDeclarationNative.SourceChecks.Checked`.
- `Silver.FunctionSourceCandidate.visibility` proves the complete original
  `Compose.FunctionVisibilityNative.SourceChecks.Checked`.
- `Silver.FunctionSourceCandidate.calls` proves the complete original
  `Predicate.FunctionCallNative.SourceChecks.Checked`.

All three retain `Output.SourceShape.outputImplementation` as their token
argument. The file publicly imports 80 new leaf modules under
`proof/Silver/FunctionSourceParts/`; existing consumers through
`FunctionSourceChecks.lean` retain the same theorem references and actual-source
transport. No existing requirement definitions, token tables, source headers,
semantic models, contracts or native code change.

| Section | Exact independent requirements | Leaf count |
| --- | --- | ---: |
| Declarations | All 25 existing header rows (specification and implementation remain separate) | 25 |
| Declarations | All 7 expression rows | 7 |
| Declarations | function_return_after, function_body_at, function_declaration_at ordinary bodies | 3 |
| Declarations | parameters_at, function_locals, parameter_frame iterative bodies | 3 |
| Declarations | typeResult, stepResult, parameterCursor declarations | 3 |
| Visibility | Every non-tree field of its original Checked structure | 10 |
| Calls | Every non-tree field of its original Checked structure | 29 |
| **Total** | **Every named source requirement** | **80** |

The three `trees` fields reuse their original checked_trees proofs. They remain
fields of the exported Checked values and are not dropped or replaced.

Each declaration-table leaf selects its existing table entry with
`existingTable.get ⟨index, by decide⟩`, avoiding duplicated token literals and
any out-of-range fallback. Its predicate is exactly the original field's
functionHeader/expressionDeclaration/ordinaryFunction equality against the
complete reviewed source. A leaf does not replace full-source extraction with
substring membership, a hash or a reduced source slice. Direct fields copy the
unchanged field proposition with the same full token argument. Each leaf retains
`decide +kernel`, maxRecDepth100000 and maxHeartbeats10000000.

The original forall fields are reconstructed by introducing arbitrary `item`
and its membership in the original complete concrete table, simplifying only
that table and list-membership rules, splitting every row, and using the
corresponding imported leaf. No forall domain is replaced by a sampled subset.
A changed, missing or reordered row must still satisfy this complete assembly;
uncovered rows or mismatched leaf types fail checking. The complete inventories
are 25/7/3/3; the generated assembly references each of those leaves once.

## Why packaging addresses the observed retention

The old module checks all three structures in one process, including large
whole-table propositions, without producing a reusable module object until
completion. The new layout makes each named extraction/contract check a separate
compiler invocation and successful cache unit. With one Lake worker and one
Lean thread, only one fresh component reduction is active at once; process exit
releases its transient elaboration/kernel allocation before the next component.
The assembly consumes checked theorem constants rather than repeating the
whole-source decisions. Ordinary module imports preserve opaque theorem
interfaces; unchanged source-certificate objects remain reusable.

This bounds how many independent reductions run simultaneously, **not the
bytes needed by one reduction**. The cancelled process's active theorem/field
was not exposed. A single large named body/header could still allocate heavily;
the aggregate imports and fresh axiom audit also have unmeasured peaks. Import
and process-start overhead increase. No completion-time, peak-memory or success
guarantee is made. If one leaf fails or exceeds available headroom, its exact
named requirement and retained diagnostic become the next bounded problem;
do not weaken that requirement or blindly repeat the whole set.

## Smallest serial checks after release and application

Run from the coordinator's authoritative integration checkout only after the
existing managed workspace/input lease is released. Read the managed summary
and current headroom first. These commands are a proposed sequence, **not run**.

1. Validate the leaf packaging and bounds-checked table selection with one
   actual full-source header requirement:

   ```sh
   python3 scripts/check_lean.py --workers 1 --threads 1 \
     --target Silver.FunctionSourceParts.DeclarationHeaderFunctionTypeAtSpec \
     --task '#298 serial source component probe' \
     --reason 'Observed FunctionSourceCandidate memory growth; validate unchanged named-source leaf packaging serially.'
   ```

2. If that passes, check the actual-source consumer; its imports build all
   remaining leaves and the exact three assemblies serially, followed by the
   fresh focused axiom/import audit:

   ```sh
   python3 scripts/check_lean.py --workers 1 --threads 1 \
     --target Silver.FunctionSourceChecks \
     --task '#298 serial function source closure' \
     --reason 'Complete every decomposed exact function-source requirement and unchanged actual-source transport.'
   ```

3. On stable repaired inputs, complete the mandatory whole-project check:

   ```sh
   python3 scripts/check_lean.py --workers 1 --threads 1 \
     --task '#298 complete Lean after memory repair' \
     --reason 'Finish complete source/module/axiom assurance, including cancelled ComposeExamples, with retained objects and bounded concurrent reduction.'
   ```

The explicit counts respond to observed memory pressure; they are not changed
defaults. Reassess later concurrency from actual evidence and host headroom.
The commands leave the memory threshold unset, preserve warningAsError and all
proof/check settings, and request neither clean deletion nor optional replay.
Managed reservations and a single writer remain mandatory; another run does not
start merely because CPU slots appear free. Monitor MemAvailable and aggregate
workers, not only the active leaf. Use the current 30-second observation cadence,
15 seconds during excursions below12GiB, repeated-low/falling or imminent8GiB
reassessment, and immediate preservation action at/below8GiB.

## Expected cache and evidence applicability

Native source/tooling, actual source literals, ReviewedOutputShape, generated
line/body certificates and unrelated semantic modules are unchanged by this
patch. Retain their exact matching objects and metadata; no successful native
or source work needs discarding for this packaging change. Keep `.olean`,
`.olean.private`, `.olean.server` and Lake traces/hashes together. The 80 new
leaves and rewritten facade require checking. Changes to public import edges
may rebuild the actual-source consumer and other downstream modules; only the
runner's matching/input audit can establish actual reuse, so no cache-hit or
consumer-stability guarantee is made.

The focused consumer result is partial assurance. The complete run must freshly
audit the final module inventory and allowed axioms, cover all new leaf modules
through the public facade, and successfully check every outstanding module.
The cancelled FunctionSourceCandidate and ComposeExamples remain failed records.
No complete native/Lean/regression readiness claim follows from this proposal.
