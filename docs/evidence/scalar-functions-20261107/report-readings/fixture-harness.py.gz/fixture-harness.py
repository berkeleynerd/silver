from pathlib import Path
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import types
import unittest

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
from scripts.platforms import native_layout
from scripts.run_history import ManagedRun, registry

host = native_layout(root)
output = root / 'tmp' / 'isolated-report-fixtures'
containers = root / '.silver' / host.key / 'proof-containers'
previous = registry(host) / 'runs/20261107T175157-cb8fa517991c/events.jsonl'
events = [json.loads(line) for line in previous.read_text().splitlines()]
tools = next(e['inputs']['tools'] for e in events if e['event'] == 'prepared')

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

selected = sorted(root.joinpath('src').glob('*.ad?')) + [
    root / 'tests/test_library_reports.py', root / 'tests/library_reports_probe.adb',
    root / 'proof/silver_proof_containers.gpr', Path(__file__),
    root / 'scripts/run_history.py', root / 'scripts/platforms.py']
inputs = {str(path): digest(path) for path in selected}
for name, identity in tools.items():
    assert digest(identity['path']) == identity['sha256'], name
repair_files = ('src/silver_library_reports.ads', 'src/silver_library_reports.adb',
                'tests/library_reports_probe.adb', 'tests/test_library_reports.py')
equivalence = {}
for name in repair_files:
    committed = subprocess.check_output(['git', 'show', '7411be1673:' + name], cwd=root)
    expected = hashlib.sha256(committed).hexdigest()
    assert digest(root / name) == expected, name
    equivalence[name] = expected

command = [sys.executable, str(Path(__file__).resolve())]
with ManagedRun(host, 'isolated-native-report-fixtures', command,
                {'scope': ['tests/test_library_reports.py'], 'inputs_sha256': inputs,
                 'tools': tools, 'repair_commit': '7411be1673', 'equivalent_files': equivalence},
                [output, containers], workers=2, task='#298',
                reason='Build and run patched report fixtures in isolated outputs using exact retained Alire tool binaries; active report and parser proof inputs and tool contexts stay frozen') as run:
    print('Managed run:', run.run_id, flush=True)
    output.mkdir(parents=True, exist_ok=True)
    probe = output / 'probe'
    probe.mkdir(exist_ok=True)
    environment = dict(os.environ)
    for name in ('ADA_INCLUDE_PATH', 'ADA_OBJECTS_PATH', 'GPR_PROJECT_PATH', 'GPR_RUNTIME_PATH', 'GPR_CONFIG', 'GPR_TOOL'):
        environment.pop(name, None)
    bins = [str(Path(tools[name]['path']).parent) for name in ('gcc', 'gprbuild', 'gnatprove')]
    environment['PATH'] = os.pathsep.join(bins + ['/usr/bin', '/bin'])
    environment['GNATPROVE_ALIRE_PREFIX'] = str(Path(tools['gnatprove']['path']).parent.parent)
    spec = importlib.util.spec_from_file_location('report_fixtures', root / 'tests/test_library_reports.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.native_layout = lambda: types.SimpleNamespace(key=host.key, context=output)
    def direct_command(_host, *arguments):
        assert arguments[:3] == ('exec', '--', 'gprbuild')
        result = [tools['gprbuild']['path'], *map(str, arguments[3:])]
        run.event('command', command=result, cwd=str(output))
        return result
    module.alire_command = direct_command
    module.tool_environment = lambda _host: environment
    class RetainedTemporaryDirectory:
        def __init__(self, **_): self.name = str(probe)
        def cleanup(self): pass
    module.tempfile = types.SimpleNamespace(TemporaryDirectory=RetainedTemporaryDirectory)
    suite = unittest.defaultTestLoader.loadTestsFromModule(module)
    log = output / 'tests.log'
    run.evidence.extend([output, log])
    with log.open('w') as stream:
        result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    print(log.read_text(), flush=True)
    assert {str(path): digest(path) for path in selected} == inputs, 'source input changed'
    for name, identity in tools.items():
        assert digest(identity['path']) == identity['sha256'], name
    summary = {'run_id': run.run_id, 'tests': result.testsRun,
               'failures': len(result.failures), 'errors': len(result.errors),
               'success': result.wasSuccessful(), 'repair_commit': '7411be1673',
               'equivalent_files': equivalence, 'inputs_sha256': inputs,
               'tools': tools, 'environment': {name: environment[name] for name in ('PATH', 'GNATPROVE_ALIRE_PREFIX')}}
    binary = probe / 'library_reports_probe'
    if binary.exists(): summary['binary_sha256'] = digest(binary)
    (output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    if not result.wasSuccessful():
        run.finish('failure', returncode=1)
        raise RuntimeError('native report fixture failures')
    run.finish('success', returncode=0)
