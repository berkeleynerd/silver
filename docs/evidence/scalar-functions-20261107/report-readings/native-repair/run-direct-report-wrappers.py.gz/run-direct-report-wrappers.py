from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
from scripts.platforms import native_layout
from scripts.run_history import ManagedRun,registry
host=native_layout(root); output=root/'tmp/report-wrapper-tasks';output.mkdir(exist_ok=True)
previous=registry(host)/'runs/20261107T175157-cb8fa517991c/events.jsonl'
events=[json.loads(l) for l in previous.read_text().splitlines()]
tools=next(e['inputs']['tools'] for e in events if e['event']=='prepared')
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for n,t in tools.items():assert digest(t['path'])==t['sha256'],n
source=root/'tmp/report-proof-repair/obj/explore/runtime-source-identity/gnatprove'
tasks=[]
for name in ('1f0848173778af2fdb91-runtime_projection_correspondence.gnat-json','silver_library_reports__complete_runtime_proof.gnat-json'):
 p=output/name;p.write_bytes((source/name).read_bytes());json.loads(p.read_text());tasks.append(p)
configuration=output/'why3.conf';configuration.write_bytes((source/'why3.conf').read_bytes())
selected=sorted((root/'src').glob('*.ad?'))+tasks+[Path(__file__),configuration]
inputs={str(p):digest(p) for p in selected}
env=dict(os.environ)
env['PATH']=os.pathsep.join([str(Path(tools[n]['path']).parent) for n in ('gnatwhy3','gcc','gprbuild','gnatprove')]+['/usr/bin','/bin'])
command=[tools['gnatwhy3']['path'],'--standalone','--timeout','30','--steps','0','--memlimit','1000','--prover','cvc5,z3,altergo','--proof','per_check','-j','2','--counterexample','off','--entity','0','--debug-save-vcs','--proof-dir',str(output/'proofs')]
with ManagedRun(host,'direct-native-wrapper-diagnostic',command,{'scope':[p.name for p in tasks],'inputs_sha256':inputs,'tools':tools,'generation_run':'20261107T201752-b4973527efeb','diagnostic_entity':0},[output,root/'tmp/report-proof-repair/cache'],workers=2,task='#298',reason='Retain interrupted focused GNAT generation and directly check only its two complete wrapper tasks; --limit-lines still transformed unrelated report entities. Exact source/task hashes, original timeout, full wrapper obligations, isolated output.',evidence=[output]) as run:
 print('Managed run:',run.run_id,flush=True);summary=[]
 (output/'proofs/sessions').mkdir(parents=True,exist_ok=True)
 for task in tasks:
  cmd=[*command,str(task)];log=output/(task.stem+'.json');run.event('command',command=cmd,cwd=str(output))
  with log.open('w') as stream:result=subprocess.run(cmd,cwd=output,env=env,stdout=stream,stderr=subprocess.STDOUT,pass_fds=run.pass_fds)
  print(task.name,'exit',result.returncode,'output',log.read_text()[-5000:],flush=True)
  summary.append({'task':task.name,'returncode':result.returncode,'output':str(log)})
  if result.returncode:raise RuntimeError('gnatwhy3 failed')
 assert {str(p):digest(p) for p in selected}==inputs,'input changed'
 from xml.etree import ElementTree as E
 sessions=list(output.rglob('why3session.xml'));assert len(sessions)==2,sessions
 for session in sessions:
  tree=E.parse(session).getroot(); roots=tree.findall('./file/theory/goal')
  assert roots and all(g.attrib.get('proved')=='true' for g in roots),str(session)
 (output/'summary.json').write_text(json.dumps({'run_id':run.run_id,'inputs_sha256':inputs,'tasks':summary,'success':True},indent=2)+'\n')
 run.finish('success',returncode=0)
