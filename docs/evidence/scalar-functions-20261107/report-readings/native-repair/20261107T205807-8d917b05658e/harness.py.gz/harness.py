from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
from scripts.platforms import native_layout
from scripts.run_history import ManagedRun, registry
host=native_layout(root)
output=root/'tmp/report-proof-repair'
output.mkdir(exist_ok=True)
project=output/'probe.gpr'
project.write_text('''with "../../proof/silver_proof_containers.gpr";
project Probe is
   for Source_Dirs use ("../../src", "../../tests");
   for Object_Dir use "obj";
   for Exec_Dir use ".";
   for Main use ("library_reports_probe.adb");
   package Compiler is
      for Default_Switches ("Ada") use ("-gnat2022", "-gnata", "-gnato");
   end Compiler;
end Probe;
''')
limits=output/'limits.txt'
line=next(i for i,l in enumerate((root/'src/silver_library_reports.adb').read_text().splitlines(),1) if l.startswith('   procedure '+sys.argv[1]))
limits.write_text('silver_library_reports.adb:'+str(line)+'\n')
events=[json.loads(l) for l in (registry(host)/'runs/20261107T175157-cb8fa517991c/events.jsonl').read_text().splitlines()]
tools=next(e['inputs']['tools'] for e in events if e['event']=='prepared')
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name,t in tools.items():assert digest(t['path'])==t['sha256'],name
selected=sorted((root/'src').glob('*.ad?'))+[root/'tests/library_reports_probe.adb',root/'proof/silver_proof_containers.gpr',Path(__file__),project,limits]
inputs={str(p):digest(p) for p in selected}
env=dict(os.environ)
for k in ('ADA_INCLUDE_PATH','ADA_OBJECTS_PATH','GPR_PROJECT_PATH','GPR_RUNTIME_PATH','GPR_CONFIG','GPR_TOOL'):env.pop(k,None)
env['PATH']=os.pathsep.join([str(Path(tools[n]['path']).parent) for n in ('gcc','gprbuild','gnatprove')]+['/usr/bin','/bin'])
env['GNATPROVE_ALIRE_PREFIX']=str(Path(tools['gnatprove']['path']).parent.parent)
reports=output/'obj/explore/runtime-source-identity/gnatprove'
cache=output/'cache'
command=[tools['gnatprove']['path'],'-P',str(project),'-u','silver_library_reports.adb','--mode=all','--report=all','--warnings=continue','--checks-as-errors=on','--level=2','--prover=cvc5,z3,altergo','--timeout=30','--subdirs=explore/runtime-source-identity','--limit-subp='+limits.read_text().strip(),'--memcached-server=file:'+str(cache),'-XSILVER_HOST='+host.key,'-j2']
with ManagedRun(host,'tool-gnatprove',command,{'scope':['report-object-ghost-helper'],'inputs_sha256':inputs,'tools':tools},[output,root/'.silver'/host.key/'proof-containers/obj/explore/runtime-source-identity'],workers=2,task='#298',reason='Original Mixed_Object saved timeouts for flow-name precondition, termination-loop invariant and universal witness transfer. Extract exact existing ghost reasoning into focused helpers; validate this selected subprogram at unchanged30-second settings before checking its consumer.',evidence=[reports],failure_reports=[reports]) as run:
 print('Managed run:',run.run_id,flush=True)
 cache.mkdir(parents=True,exist_ok=True)
 run.prepare({'scope':['report-object-ghost-helper'],'inputs_sha256':inputs,'tools':tools,'limits':limits.read_text()})
 log=run.directory/'native.log';run.evidence.append(log)
 run.event('command',command=command,cwd=str(output))
 with log.open('w') as stream:
  result=subprocess.run(command,cwd=output,env=env,stdout=stream,stderr=subprocess.STDOUT,pass_fds=run.pass_fds)
 print(log.read_text(),flush=True)
 assert {str(p):digest(p) for p in selected}==inputs,'source changed'
 for name,t in tools.items():assert digest(t['path'])==t['sha256'],name
 failures=run.unresolved_obligations()
 if result.returncode or failures:
  run.finish('failure',returncode=result.returncode,failure_keys=failures)
  raise RuntimeError('focused report proof failed')
 run.finish('success',returncode=0)
