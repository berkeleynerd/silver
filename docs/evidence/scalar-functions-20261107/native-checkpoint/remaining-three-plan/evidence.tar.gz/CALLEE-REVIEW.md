# Bounded Callee_At reader review — 2026-11-08

No objection to the exact two-line patch with SHA256
`34b2aeb798af54caa06e0005e1f164ee40e7209be5bcde88a6391ef15bea2c4c`.
This is read-only source review, not an applied or Lean-validated repair.

`Source.expressionBodies` in `SourceLexer.lean` requires the token pattern
`return <resultType> is (`. Native `Callee_At` instead has
`return Functions . Function_Count is (`. The existing
`SourceBridge.qualifiedExpressionBody` in `SourceDeclarations.lean` handles
exactly that qualified return-type shape. It retains the balanced expression,
trailing semicolon and singleton-match requirements.

The patch changes only the `Checked.callee_at_body` proposition in
`PredicateFunctionCallSource.lean` and the corresponding theorem proposition in
`FunctionSourceParts/CallsCalleeAtBody.lean`. Both complete callee headers remain
checked by `calleeAt_spec` and `calleeAt_impl`; those checks retain the exact
return type, parameter types, contracts and separate unique declaration/body
headers. `FunctionSourceCandidate` still assembles the same field from the same
leaf. The typed callee tree, render, denotation and native source are unchanged.
The existing namespace opens resolve the qualified reader without another import.

Rebuild the affected leaf and its actual import/aggregate closure on the final
source inputs. Old successful unrelated leaves do not prove this changed claim;
this inspection makes no complete Lean/source closure claim.
