# Native auditor refresh preparation

No run launched yet. Source/report fix53d3a3b22b awaits separate critical review.
This isolated native checkout retains parser036a53b4/report3254d7d3 and the original
canonical warm sessions/cache. Integration Lean65188 remains frozen separately.
After approval, apply only reviewed auditor/test/boundary files; inspect current
managed runs, exact native sources/configuration and host headroom; use one ordinary
managed prove --full --jobs12 with explicit reason. Keep every option/obligation.
Require actual driver exit and managed finish, complete provenance and standalone
mandatory checker. Old094547 remains failed and its packet unchanged.

Prepared retention helpers are copies of existing reviewed task-local collectors
with only scratch/output destinations changed. They must not execute before a
completed run and actual active-run-id/pre-full-status exist.
