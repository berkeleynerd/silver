"""Retain final run evidence without changing native inputs or outputs."""
import datetime,gzip,hashlib,json,xml.etree.ElementTree as E
from pathlib import Path
root=Path.cwd();reg=root.parents[1]/'.git/silver-runs/linux-x86_64/78cde64c3e47f2cb/runs';rid=(root/'tmp/native-auditor-refresh-298/active-run-id.txt').read_text().strip();run=reg/rid;packet=root/'docs/evidence/scalar-functions-20261107/native-checkpoint/auditor-refresh-53d3';reports=root/'.silver/linux-x86_64/compiler/obj/gnatprove'
events=[json.loads(l) for l in (run/'events.jsonl').open()];finish=next((e for e in reversed(events) if e['event']=='finished'),None);assert finish,'run still active; do not retain as completed'
assert hashlib.sha256((root/'src/silver_output_profile.adb').read_bytes()).hexdigest()=='036a53b4bd9a9d7c711b4ddf8d83467a6b470184bfce2ac6677b15cf4f57ef47'
assert hashlib.sha256((root/'src/silver_library_reports.adb').read_bytes()).hexdigest()=='3254d7d3236cbaa689e61a4dc13478d29ab9cafe6cfdd5f0ba8b2ecff4d13b25'
records=[]
def capture(src,dest):
 before=src.stat();data=src.read_bytes();after=src.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),str(src)+' changed while reading';target=packet/dest;target.parent.mkdir(parents=True,exist_ok=True)
 with gzip.GzipFile(filename=str(target)+'.gz',mode='wb',mtime=0) as f:f.write(data)
 records.append({'path':str(dest)+'.gz','sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)});return data
for n in ['events.jsonl','native.log']:capture(run/n,Path('runs')/rid/n)
capture(root/'tmp/native-auditor-refresh-298/pre-full-status.json',Path('resources/pre-full-status.json'))
for src in sorted(reports.iterdir()):
 if src.is_file() and (src.suffix=='.spark' or src.name in ['gnatprove.sarif','gnatprove.out','proof-provenance.json','proof-inputs.json','why3.conf']):capture(src,Path('final-reports')/src.name)
def proved(n):
 if n.get('proved')=='true':return True
 if any(x.find('result') is not None and x.find('result').get('status')=='valid' for x in n.findall('proof')):return True
 return any(t.findall('goal') and all(proved(g) for g in t.findall('goal')) for t in n.findall('transf'))
sessions=[]
for src in sorted(reports.glob('*/why3session.xml')):
 data=capture(src,Path('final-sessions')/src.parent.name/src.name);r=E.fromstring(data);roots=r.findall('./file/theory/goal');bad=[g.get('name') for g in roots if not proved(g)];sessions.append({'entity':src.parent.name,'roots':len(roots),'unproved_roots':bad})
 if (src.parent/'why3shapes').is_file():capture(src.parent/'why3shapes',Path('final-sessions')/src.parent.name/'why3shapes')
 if bad and (reports/(src.parent.name+'.gnat-json')).is_file():capture(reports/(src.parent.name+'.gnat-json'),Path('failed-tasks')/(src.parent.name+'.gnat-json'))
for dirname in ['src','scripts','.silver/linux-x86_64/generated']:
 for src in sorted((root/dirname).rglob('*')):
  if src.is_file() and src.suffix in {'.adb','.ads','.py'}:
   relative=src.relative_to(root) if dirname in {'src','scripts'} else Path('generated')/src.relative_to(root/dirname)
   capture(src,Path('final-inputs')/relative)
for name in ['silver.gpr','alire.toml','proof/silver_proof_containers.gpr']:capture(root/name,Path('final-inputs')/name)
for name in ['alire.toml','alire/alire.lock','alire/settings.toml']:capture(root/'.silver/linux-x86_64/toolchain'/name,Path('final-inputs/toolchain')/name)
(packet/'final-session-inventory.json').write_text(json.dumps({'scope':'read-only final saved Why3 sessions, separate from mandatory full report/provenance audit','sessions':sessions,'root_count':sum(s['roots'] for s in sessions),'unproved_entities':[s['entity'] for s in sessions if s['unproved_roots']]},indent=2)+'\n')
(packet/'runs'/rid/'index.json').write_text(json.dumps({'artifact_root':'../..','run_id':rid,'finished':finish,'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'artifacts':records},indent=2)+'\n')
print(json.dumps({'outcome':finish['outcome'],'root_count':sum(s['roots'] for s in sessions),'unproved_entities':[s['entity'] for s in sessions if s['unproved_roots']],'artifacts':len(records),'uncompressed_bytes':sum(s['bytes'] for s in records)},indent=2))
