"""Inventory and verify the completed evidence packet without rerunning proof."""
from collections import Counter
from pathlib import Path
import datetime
import gzip
import hashlib
import json

root = Path.cwd()
packet = root / 'docs/evidence/scalar-functions-20261107/native-checkpoint/auditor-refresh-53d3'
rid = (root / 'tmp/native-auditor-refresh-298/active-run-id.txt').read_text().strip()
index_path = packet / 'runs' / rid / 'index.json'
index = json.loads(index_path.read_text())
assert index['finished']['event'] == 'finished'
records = {record['path']: record for record in index['artifacts']}
assert len(records) == len(index['artifacts'])
actual = {str(path.relative_to(packet)) for path in packet.rglob('*.gz')}
assert actual == records.keys(), 'unindexed or missing gzip files'
for name, record in records.items():
    data = gzip.decompress((packet / name).read_bytes())
    assert len(data) == record['bytes'], name
    assert hashlib.sha256(data).hexdigest() == record['sha256'], name

units = []
proof = Counter()
flow = Counter()
non_info = []
for path in sorted((packet / 'final-reports').glob('*.spark.gz')):
    report = json.loads(gzip.decompress(path.read_bytes()))
    unit_proof = Counter(record['severity'] for record in report['proof'])
    unit_flow = Counter(record['severity'] for record in report['flow'])
    proof.update(unit_proof)
    flow.update(unit_flow)
    for kind in ['proof', 'flow']:
        non_info.extend({'unit': path.name[:-3], 'kind': kind, 'record': record}
                        for record in report[kind] if record['severity'] != 'info')
    units.append({'report': path.name[:-3], 'progress': report['progress'],
                  'stop_reason': report['stop_reason'], 'warn_error': report['warn_error'],
                  'proof_records_by_severity': dict(unit_proof),
                  'flow_records_by_severity': dict(unit_flow),
                  **{key: report[key] for key in ['skip_proof', 'skip_flow_proof', 'pragma_assume']}})

expected_units = {path.stem for directory in [root / 'src', root / '.silver/linux-x86_64/generated']
                  for path in directory.rglob('*') if path.suffix in {'.adb', '.ads'}}
actual_units = {unit['report'][:-6] for unit in units}
summary = {'scope': 'Final saved native reports; managed full audit remains authoritative',
           'run_id': rid, 'managed_outcome': index['finished']['outcome'], 'report_units': len(units),
           'expected_units_from_current_sources': sorted(expected_units),
           'missing_units': sorted(expected_units - actual_units),
           'unexpected_units': sorted(actual_units - expected_units),
           'proof_records_by_severity': dict(proof), 'flow_records_by_severity': dict(flow),
           'non_info_records': non_info,
           'proof_provenance_exists': 'final-reports/proof-provenance.json.gz' in records,
           'proof_inputs_exists': 'final-reports/proof-inputs.json.gz' in records, 'units': units}
(packet / 'final-report-inventory.json').write_text(json.dumps(summary, indent=2) + '\n')

events = [json.loads(line) for line in gzip.decompress(
    (packet / 'runs' / rid / 'events.jsonl.gz').read_bytes()).decode().splitlines()]
prepared = next(event for event in events if event['event'] == 'prepared')
inputs = prepared['inputs']['inputs_sha256']
input_records = {name.removeprefix('final-inputs/').removesuffix('.gz'): record
                 for name, record in records.items() if name.startswith('final-inputs/')}
input_checks = []
for name, sha in inputs.items():
    if name.startswith('.tools/'):
        continue
    archived_name = name.removeprefix('.silver/linux-x86_64/')
    assert archived_name in input_records, 'input not retained: ' + name
    assert input_records[archived_name]['sha256'] == sha, 'input differs: ' + name
    input_checks.append(name)
verified = {'utc': datetime.datetime.now(datetime.UTC).isoformat(), 'run_id': rid,
            'indexed_gzip_artifacts': len(records), 'all_hashes_and_lengths_match': True,
            'all_gzip_artifacts_indexed': True,
            'retained_native_inputs_matching_preflight': input_checks,
            'alire_index_and_settings_identities_in_events': sum(name.startswith('.tools/') for name in inputs),
            'audit_phase_finished': any(event['event'] == 'phase-end' and event.get('phase') == 'audit'
                                        for event in events)}
(packet / 'artifact-verification.json').write_text(json.dumps(verified, indent=2) + '\n')
if index['finished']['outcome'] == 'success':
    assert not non_info and not summary['missing_units'] and not summary['unexpected_units']
    assert summary['proof_provenance_exists'] and summary['proof_inputs_exists']
    assert verified['audit_phase_finished']
    assert all(unit['progress'] == 'PROGRESS_PROOF' and unit['stop_reason'] == 'STOP_REASON_NONE'
               and not any(unit[key] for key in ['skip_proof', 'skip_flow_proof', 'pragma_assume'])
               for unit in units)
print(json.dumps({'units': len(units), 'proof': dict(proof), 'flow': dict(flow),
                  'artifacts': len(records), 'matching_native_inputs': len(input_checks),
                  'provenance': summary['proof_provenance_exists'],
                  'audit_phase_finished': verified['audit_phase_finished']}, indent=2))
