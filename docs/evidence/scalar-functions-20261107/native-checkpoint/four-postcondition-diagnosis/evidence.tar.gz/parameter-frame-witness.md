# Source-derived counterexample to Parameter_Frame's static postcondition

Frozen native parser SHA256:
`9ec28d94a41c81bb68168bb674792bc44bf1ddeae69e71d4d3e11b153786b77f`.
No compiler, prover or executable was run for this argument. It is a direct
source-level evaluation, independently checked against frozen dependency bytes.

Choose `Text : String := "x"` (bounds 1..1) and
`Frame := (Invalid_State with delta First_Parameter => 1)`.

The record is well typed: Invalid_State supplies every initialized field and
array; Formal_Count includes 1. Position, all environment counts, metadata count
and parameter count are zero. All fields other than First_Parameter are exactly
those of Invalid_State. The function's written precondition holds:

1. Text'First = 1 and Text'Length = 1 lies in 1..Max_Source_Length.
2. Frame.Position = 0 <= Text'Last + 1 = 2.
3. Functions.Valid_Metadata holds: both quantified active ranges are empty.
4. Frame.First_Parameter = 1 <= Parameter_Count + 1 = 1.
5. Valid_Names and Scalar_Expressions.Valid_Environment hold on empty ranges.
6. Array_Bindings.Valid_Environment is empty Valid_Metadata plus another empty
   active range; its empty values/count fields are initialized.
7. Valid_Subtypes and Valid_Booleans hold on empty ranges.
8. Valid_Mutable_Bounds holds on an empty range.
9. Valid_Declaration_Values has Count = Scalar_Names.Count = 0 and empty range.
10. Valid_Name_State(Text, Dynamic_First=0, Dynamic_After=0) is explicitly true.
11. Target = 0 <= Names.Count = 0.
12. Frame.First_Parameter > 0.

These are every conjunct of Valid_State plus the explicit Text/first-parameter
requirements. No positive-position condition or canonical-zero-state condition
is present. Parameter_Frame_Model's separate Index precondition also holds:
Index = 1 <= Frame.Functions.Parameter_Count + 1 = 1.

The executable initializes Result := Frame and Index := 1. Its while condition
1 <= 0 is false, so the loop executes zero times and it returns Frame. That
result still satisfies the runtime portion (it is valid and has Position=0).

The ghost model tests `Frame.Position = 0` before its index/beyond-last branch,
and returns the canonical Invalid_State. Thus the required static equality is
false: executable result.First_Parameter = 1, model result.First_Parameter = 0.
This scalar field difference does not depend on array extensionality or solver
strategy. The native session's failed leaf is the static postcondition within
check GP_Check:3207 (root location 5703:28, diagnostic subexpression 5709:20),
`def'vc.98`; the retained task contains this zero-first model definition and
unguarded zero-iteration executable path.

A smallest candidate repair is an entry check that returns Invalid_State when
Frame.Position=0, before the while loop. It preserves the entire declared domain
and the model's specified result. Narrowing Pre to exclude Position=0 would avoid
this witness by changing the admitted function domain and is not an authorized
repair. A focused proof of the guarded body remains required; it may expose
additional proof-engineering work. No edit or proof experiment has occurred.
