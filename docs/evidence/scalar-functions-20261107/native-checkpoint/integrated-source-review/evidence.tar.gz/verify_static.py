"""Read committed repair artifacts; no native/Lean execution or source writes."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent
TARGET = "68c4fd259b"
BASE = "0c7ed70356"


def git(*args):
    return subprocess.check_output(["git", *args])


def blob(path, commit=TARGET):
    return git("show", f"{commit}:{path}")


def source(path, commit=TARGET):
    return blob(path, commit).decode()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def token_list(text, name, ty):
    pattern = rf"^def {name} : {ty} :=\n  (\[.*\])$"
    return json.loads(re.search(pattern, text, re.M).group(1))


target = git("rev-parse", TARGET).decode().strip()
base = git("rev-parse", BASE).decode().strip()
native = blob("src/silver_output_profile.adb")
assert digest(native) == "036a53b4bd9a9d7c711b4ddf8d83467a6b470184bfce2ac6677b15cf4f57ef47"
plan = json.loads((ROOT.parent / "native-postcondition-diagnosis-298/remaining-three-plan/inventory.json").read_text())
guard = blob("src/silver_output_profile.adb", "b8365c0606")
candidate = guard.decode()
for site in plan["sites"]:
    assert candidate.count(site["before"]) == 1
    candidate = candidate.replace(site["before"], site["after"])
assert candidate.encode() == native

certificate = source("proof/Silver/OutputBodyCertificate.lean")
line_pattern = re.compile(
    r"^def outputBodyTokens_line_([0-9a-f]{64}) : LineCertificate where\n"
    r"  text := (.*)\n  tokens := (.*)\n"
    r"  correct := by decide \+kernel\n  noNewline := by decide \+kernel$", re.M)
line_map = {}
bucket_comparison = []
for bucket in range(8):
    path = f"proof/Silver/OutputBodyLines{bucket}.lean"
    current = source(path)
    old = source(path, BASE)
    entries = list(line_pattern.finditer(current))
    assert len(entries) == len(re.findall(r"^def outputBodyTokens_line_", current, re.M))
    for match in entries:
        key, text, tokens = match.groups()
        decoded = json.loads(text)
        assert digest(decoded.encode()) == key
        assert key not in line_map
        line_map[key] = (decoded, json.loads(tokens))
    bucket_comparison.append({"path": path, "unchanged": current == old,
                              "sha256": digest(current.encode()), "line_certificates": len(entries)})

single_pattern = re.compile(
    r"^def outputBodyTokens_block_(\d+)_(\d+) : ReconstructionCertificate :=\n"
    r"  ReconstructionCertificate.single outputBodyTokens_line_([0-9a-f]{64})$", re.M)
singles = sorted((int(a), int(b), key) for a, b, key in single_pattern.findall(certificate))
lines = native.decode().split("\n")
assert len(singles) == len(lines)
flat = []
for index, (start, end, key) in enumerate(singles):
    assert (start, end) == (index, index + 1)
    text, tokens = line_map[key]
    assert text == lines[index]
    flat.extend(tokens)
join_pattern = re.compile(
    r"^def outputBodyTokens_block_(\d+)_(\d+) : ReconstructionCertificate :=\n"
    r"  ReconstructionCertificate.join outputBodyTokens_block_(\d+)_(\d+) "
    r"outputBodyTokens_block_(\d+)_(\d+)\n    (.*)$", re.M)
joins = list(join_pattern.finditer(certificate))
assert len(joins) == len(lines) - 1
for match in joins:
    start, end, left, middle, right, stop = map(int, match.groups()[:6])
    assert (left, right, stop) == (start, middle, end)
    assert start < middle < end
    assert json.loads(match.group(7)) == "\n".join(lines[start:end])
assert f"  outputBodyTokens_block_0_{len(lines)}.lines" in certificate
assert f"  exact outputBodyTokens_block_0_{len(lines)}.correct" in certificate
generated_tokens = token_list(certificate, "outputBodyTokens", "Tokens")
assert flat == generated_tokens
shape = source("proof/Silver/ReviewedOutputShape.lean")
old_shape = source("proof/Silver/ReviewedOutputShape.lean", BASE)
shapes = re.compile(r"^def (\w+) : List String :=\n  (\[.*\])$", re.M)
shape_map = {name: json.loads(value) for name, value in shapes.findall(shape)}
old_shape_map = {name: json.loads(value) for name, value in shapes.findall(old_shape)}
assert shape_map.keys() == old_shape_map.keys()
assert [name for name in shape_map if shape_map[name] != old_shape_map[name]] == ["outputImplementation"]
assert shape_map["outputImplementation"] == generated_tokens


def headers(name, stop):
    result = []
    for index in range(len(flat) - 1):
        if flat[index:index + 2] != ["function", name]:
            continue
        depth = 0
        for end in range(index + 2, len(flat)):
            token = flat[end]
            if depth == 0 and token in ("is", ";"):
                if token == stop:
                    result.append(flat[index + 2:end])
                break
            depth += (token == "(") - (token == ")")
    assert len(result) == 1
    return result[0]


scalar_headers = re.findall(
    r'functionHeader "scalar_declaration_at" ";" [^\n]*?some \((\[.*?\])\)',
    source("proof/Silver/ComposeContractSourceCandidate.lean"))
assert len(scalar_headers) == 2
assert all(json.loads(header) == headers("scalar_declaration_at", ";") for header in scalar_headers)


def simple_tokens(text):
    # Only used for the two reviewed headers and loop, containing no string literals.
    assert '"' not in text
    return [part.lower() for part in re.findall(r"[A-Za-z_][A-Za-z_0-9]*|[0-9]+|=>|:=|<=|>=|/=|\.\.|[^\s]", text)]


boolean = source("proof/Silver/ComposeBooleanDeclarationSource.lean")
impl = re.search(r'def implHeader : List String := expectedTokens\n  (".*")', boolean).group(1)
post = re.search(r'def specHeader : List String := implHeader \+\+ expectedTokens\n  (".*")', boolean).group(1)
assert simple_tokens(json.loads(impl) + " " + json.loads(post)) == headers("boolean_declaration_at", ";")
parameter_expected = json.loads(re.search(
    r'\("parameter_frame", expectedTokens (".*?")\)\]',
    source("proof/Silver/FunctionDeclarationSource.lean")).group(1))
parameter_body = re.search(r"   function Parameter_Frame \(Text : String; Frame : Parser_State\) return Parser_State is\n(.*?)   end Parameter_Frame;",
                           native.decode(), re.S).group(1)
parameter_body = parameter_body + "   end Parameter_Frame;"
assert simple_tokens(parameter_expected) == simple_tokens(parameter_body)

semantic_headers = {}
for path, names in {
    "PredicateFunctionCallEquations.lean": ["actuals_model"],
    "PredicateFunctionCallHelpers.lean": ["normalized_actuals_at"],
    "FunctionDeclarationDenotations.lean": ["returnAfter_model"],
    "FunctionDeclarationImports.lean": ["returnAfter_imports"],
}.items():
    file = "proof/Silver/" + path
    before, after = source(file, BASE), source(file)
    for name in names:
        expression = re.compile(rf"^theorem {name}\b.*? := by", re.M | re.S)
        assert expression.search(before).group() == expression.search(after).group()
        semantic_headers[name] = "unchanged"

changed = git("diff", "--name-only", f"{BASE}..{TARGET}").decode().splitlines()
handwritten = [path for path in changed if not re.match(r"proof/Silver/OutputBody(?:Certificate|Lines\d)\.lean$", path)]
patch = git("diff", f"{BASE}..{TARGET}", "--", *handwritten)
(ROOT / "handwritten.patch").write_bytes(patch)
summary = {
    "scope": "Static committed-byte and certificate-data inspection only; no Lean kernel/native execution",
    "target_commit": target, "proof_base_commit": base,
    "native_sha256": digest(native), "matches_approved_candidate": True,
    "handwritten_files": handwritten, "handwritten_patch_sha256": digest(patch),
    "source_line_occurrences_including_final_empty": len(lines),
    "unique_line_certificates": len(line_map), "reconstruction_joins_checked": len(joins),
    "certificate_text_reconstructs_exact_native_bytes": True,
    "ordered_line_tokens_equal_generated_tokens_and_pin": True,
    "old_pin_token_count": len(old_shape_map["outputImplementation"]),
    "new_pin_token_count": len(generated_tokens),
    "other_source_pins_unchanged": True, "buckets": bucket_comparison,
    "both_scalar_headers_equal_source": True,
    "boolean_header_equal_source": True,
    "parameter_frame_expected_body_equal_source": True,
    "semantic_theorem_statements": semantic_headers,
    "line_lexical_proofs_and_join_witnesses_kernel_checked_here": False,
}
(ROOT / "static-verification.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps({key: value for key, value in summary.items() if key not in ("handwritten_files", "buckets")}, indent=2))
