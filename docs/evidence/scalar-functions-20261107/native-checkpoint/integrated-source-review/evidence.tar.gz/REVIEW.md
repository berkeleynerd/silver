# Bounded integrated repair review — 2026-11-08

Target: `68c4fd259b34dd635bafd35a17436356a4938dfe`.
Proof/source delta base: `0c7ed70356c3a7c72123cc6527e96cb9a7630d9f`.
Native source SHA256:
`036a53b4bd9a9d7c711b4ddf8d83467a6b470184bfce2ac6677b15cf4f57ef47`.

No mathematical or source-linkage defect was identified in this bounded repair.
The target is not accepted as a completed checked result: focused Lean compilation
failed, and the complete native/Lean/source evidence remains outstanding.
This review is independent source inspection and static committed-artifact
reconstruction. It ran no Lean, native proof, compiler, test fixture or generator,
and changed no production files, leases or caches.

## Native source and domain

The target parser bytes equal the approved five-site proposal applied to the
separately proved Parameter_Frame guard base, independently reconstructed from
the retained plan. The six changes relative to the original failed parser are
therefore exactly the two guarded frame postconditions, comma guards in ghost
model and executable loop, Parameter_Frame zero-position guard, and return-token
guard. No precondition, assertion level, invariant, variant or existing post fact
is removed. No admitted input is excluded.

The two declaration contracts strengthen only successful results and expose
fields their existing bodies preserve. Function_Local_At's original required
frame equalities remain. Actuals_After retains its full static model-equality
contract and corresponding loop invariant; its matching comma guard preserves
the native link to the changed Actuals_Model expression. The Parameter_Frame
guard now agrees with the existing model on the demonstrated zero-position
witness rather than narrowing the input domain. The return guard makes native
progress composition explicit on a successful keyword.

## Semantic proof structure

All existing Lean semantic model definitions and native input-domain predicates
are unchanged. The new actualAfter_zero theorem quantifies over arbitrary source,
context, facts and formal; it assumes no validity, positive cursor, nonempty
environment or restricted result kind. Its Boolean branch reduces the existing
zero-position relation rejection. Its scalar branch covers both empty and
nonempty array metadata, reducing zero-position parsing and summarization to the
canonical invalid result. actualsAfter_zero then uses the existing first rejection
branch without recursive induction or assumptions about formal indexes.

The actuals typed tree adds only the source's failed-comma branch. Its evaluation
is equivalent to the unchanged model because the old recursive call at zero is
zero. actuals_model and normalized_actuals_at split that branch; the nonzero case
keeps the existing recursion on last - first. The latter retains native-domain
totalization, all import/definition hypotheses and its unrestricted theorem
statement; no callee equality is newly assumed.

The return command uses the existing guard constructor with matching rendering
and evaluation. returnAfter_model and returnAfter_imports split the keyword
cursor and use actualAfter_zero for the rejected case. ReturnImports remains
unchanged, including its token and actual-reader equalities. All four existing
semantic theorem statements were independently compared and are identical.
The new guard changes source-tree definitions, not the admitted semantic models.

The two previously reviewed qualifier/reader fixes are exact: expectedTokens is
fully qualified in CallsIncludedImpl, and both Callee_At source propositions use
the existing qualifiedExpressionBody extractor. Full exact header requirements,
balanced-expression/semicolon extraction and unique matching are retained.
No typed Callee_At tree, denotation or native body changes.

## Source reconstruction

The delta contains 14 handwritten files and seven generated files: the main
OutputBodyCertificate plus buckets 0, 1, 2, 4, 5 and 7. Buckets 3 and 6 are
byte-identical. Static inspection verified:

- All 6,021 ordered line occurrences, including the final empty line, reproduce
  the exact committed native bytes through 3,913 unique line certificates.
- All 6,020 reconstruction joins have contiguous child ranges and exact source
  strings; the root and source theorem refer to the complete range.
- Ordered line-certificate tokens equal both the generated complete token list
  and outputImplementation: 62,191 old tokens become 62,309. Every other source
  pin is unchanged.
- Both scalar header token requirements equal the complete native declaration;
  the Boolean specHeader does likewise. Parameter_Frame's expected loop body
  includes the exact guard and every existing invariant/variant.

The typed comma and return trees' existing render functions produce the inserted
source guards in the correct order. Source leaves retain their complete body
claims through these renders. The generated line lexical proofs, join character
witnesses and resulting source theorems still need actual kernel checking; this
text/data reconstruction is not a substitute for that closure.

## Observed validation limit and next evidence

The retained events/log for focused managed run
`20261108T090716-23e8e3641bc7` establish failure at 09:10:38 UTC, exit 1 after
200.406 s managed and a 172.551 s build. This reviewer verified all three indexed
packet artifacts by decompressed size/hash and inspected the raw error goals.
PredicateCallAdmission, PredicateFunctionCallNative and
PredicateFunctionCallEquations compiled, covering the new zero lemmas, call trees
and actuals_model. returnAfter_model's goal still contained apply2/apply4;
normalized_actuals_at's goal still contained modelCalls.actual, preventing the
comma hypothesis from matching. The log also records consequent unused-simp and
recursion diagnostics. These are failed proof normalizations on the exact target,
not completed proofs.

The bounded follow-up `f630819154` adds only apply2/apply4 in the return-model simp
list and modelCalls in the two comma-branch simp lists. Its proof diff was reviewed
and retained here. No theorem statement, semantic definition, input domain,
native source, typed tree, source header, pin or generated certificate changes.
The static source-linkage disposition therefore extends to that follow-up; actual
successful compilation remains required. No linter or checker is disabled.

Acceptance requires successful affected semantic compilation on the repaired
target, the six full selected native checks, and complete native
obligation/provenance plus Lean/source-correspondence evidence on final inputs.
The existing regression applicability also needs the requested per-ID delta
before execution is selected. No result in this review supersedes those checks.
