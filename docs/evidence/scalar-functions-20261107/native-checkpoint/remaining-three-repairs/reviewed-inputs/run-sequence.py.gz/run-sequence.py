"""Run each specifically authorized body once, sequentially; stop on failure."""
import collections
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import xml.etree.ElementTree as ET

root = Path.cwd()
scratch = root / 'tmp/remaining-three-repairs-298'
packet = root / 'docs/evidence/scalar-functions-20261107/native-checkpoint/remaining-three-repairs'
source_hash = '036a53b4bd9a9d7c711b4ddf8d83467a6b470184bfce2ac6677b15cf4f57ef47'
source_commit = 'ee02fce26ac8f3cbe911022b2f9f1611f33594ab'
targets = [('Scalar_Declaration_At', 1512), ('Boolean_Declaration_At', 4457),
           ('Actuals_Model', 4803), ('Actuals_After', 4828),
           ('Function_Local_At', 5628), ('Function_Return_After', 5747)]
assert not (packet / 'summary.json').exists(), 'Do not repeat the sequence'
packet.mkdir(parents=True, exist_ok=True)


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def capture(base, records, src, relative, native_input=None):
    before = src.stat()
    data = src.read_bytes()
    after = src.stat()
    assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), src
    dest = base / (str(relative) + '.gz')
    dest.parent.mkdir(parents=True, exist_ok=True)
    with gzip.GzipFile(filename=str(dest), mode='wb', mtime=0) as stream:
        stream.write(data)
    record = {'path': str(relative) + '.gz', 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
    if native_input is not None:
        record['native_input'] = native_input
    records.append(record)


def tree_proved(tree):
    if any(a.get('result') == 'Valid' for a in tree.get('proof_attempts', {}).values()):
        return True
    return any(children and all(tree_proved(c) for c in children)
               for children in tree.get('transformations', {}).values())


def canonical_rows():
    rows = []
    for base in [root / '.silver/linux-x86_64/compiler/obj/gnatprove',
                 root / '.silver/linux-x86_64/proof-cache/gnatprove/ea6aba21eca447a9c8473fc1c3ea0300b03a95ce919d8a326f68a67989029329']:
        for path in sorted(base.rglob('*')):
            if path.is_file():
                st = path.stat()
                rows.append({'path': str(path.relative_to(root)), 'bytes': st.st_size, 'mtime_ns': st.st_mtime_ns})
    return rows


common = []
for name in ['PLAN.md', 'remaining-three.patch', 'review-inventory.json', 'before.adb',
             'after.adb', 'canonical-before.json', 'pre-sequence-status.json', 'run-sequence.py']:
    capture(packet, common, scratch / name, Path('reviewed-inputs') / name)
for base, dest in [(root / 'src', Path('inputs/src')),
                   (root / '.silver/linux-x86_64/generated', Path('inputs/generated'))]:
    for path in sorted(base.rglob('*')):
        if path.is_file() and path.suffix in {'.adb', '.ads'}:
            capture(packet, common, path, dest / path.relative_to(base), str(path.relative_to(root)))
for name, dest in [('silver.gpr', 'inputs/silver.gpr'),
                   ('proof/silver_proof_containers.gpr', 'inputs/silver_proof_containers.gpr'),
                   ('alire.toml', 'inputs/alire.toml'),
                   ('.silver/linux-x86_64/toolchain/alire.toml', 'inputs/toolchain/alire.toml'),
                   ('.silver/linux-x86_64/toolchain/alire/alire.lock', 'inputs/toolchain/alire.lock')]:
    capture(packet, common, root / name, Path(dest), name)
save(packet / 'index.json', {'artifact_root': '.', 'source_commit': source_commit, 'artifacts': common})
results = []

for name, line in targets:
    assert hashlib.sha256((root / 'src/silver_output_profile.adb').read_bytes()).hexdigest() == source_hash
    slug = name.lower().replace('_', '-')
    local = scratch / slug
    local.mkdir(exist_ok=False)
    cache = local / 'cache'
    cache.mkdir()
    subdirs = 'explore/remaining-three-' + slug
    reports = root / '.silver/linux-x86_64/compiler/obj' / subdirs / 'gnatprove'
    assert not reports.exists(), 'Do not reuse or repeat a target'
    status = json.loads(subprocess.check_output([sys.executable, 'scripts/dev.py', 'runs', 'status'], text=True))
    assert status['available_cpus'] - status['reserved_workers'] >= 4
    save(local / 'pre-run-status.json', status)
    reason = ('Coordinator-authorized exact Astra-reviewed five-site repair ee02fce26a; '
              'one complete focused body ' + name + ', unchanged full precondition domain, '
              'original level2/30s CVC5,Z3,Alt-Ergo; all runtime/static contracts and guards; '
              'sequential four-worker run with isolated explore output and separate scratch cache; '
              'stop at first failure, no retry')
    command = [sys.executable, '-B', 'scripts/dev.py', 'tool', '--task', '#298', '--jobs', '4',
               '--reason', reason, '--workspace', str(scratch),
               '--input', str(scratch / 'run-sequence.py'),
               '--input', str(scratch / 'remaining-three.patch'), '--', 'gnatprove',
               '-P', '../../../silver.gpr', '-u', 'silver_output_profile.adb',
               '--mode=all', '--report=all', '--warnings=error', '--checks-as-errors=on',
               '--level=2', '--prover=cvc5,z3,altergo', '--timeout=30', '--subdirs=' + subdirs,
               '--limit-subp=silver_output_profile.adb:' + str(line),
               '--memcached-server=file:' + str(cache), '-XSILVER_HOST=linux-x86_64']
    print('START', json.dumps({'utc': utc(), 'target': name, 'line': line, 'reserved_before': status['reserved_workers']}), flush=True)
    with (local / 'driver.log').open('wb') as output:
        returncode = subprocess.call(command, cwd=root, stdout=output, stderr=subprocess.STDOUT)
    match = re.search(r'Managed run: (\S+)', (local / 'driver.log').read_text())
    assert match, 'Tool setup failed before a managed run; stop without retry'
    run_id = match.group(1)
    run = Path(status['registry']) / 'runs' / run_id
    events = [json.loads(x) for x in (run / 'events.jsonl').read_text().splitlines()]
    finish = events[-1]
    assert finish['event'] == 'finished', 'No real managed completion; stop'
    assert hashlib.sha256((root / 'src/silver_output_profile.adb').read_bytes()).hexdigest() == source_hash
    dest = packet / 'runs' / slug
    artifacts = []
    for filename in ['events.jsonl', 'native.log']:
        capture(dest, artifacts, run / filename, Path('managed') / filename)
    for filename in ['driver.log', 'pre-run-status.json']:
        capture(dest, artifacts, local / filename, Path('observations') / filename)
    for path in sorted(reports.rglob('*')):
        if path.is_file() and (path.suffix in {'.spark', '.gnat-json', '.trace'} or
                path.name in {'gnatprove.sarif', 'gnatprove.out', 'why3.conf', 'why3session.xml', 'why3shapes'} or
                (path.suffix in {'.stdout', '.stderr'} and path.stat().st_size)):
            capture(dest, artifacts, path, Path('reports') / path.relative_to(reports))
    spark = json.loads((reports / 'silver_output_profile.spark').read_text())
    branches = [b for record in spark['proof'] for b in record.get('check_tree', [])]
    post = [r for r in spark['proof'] if r['rule'] == 'VC_POSTCONDITION']
    session_roots = []
    goal_nodes = []
    for session in reports.glob('*/why3session.xml'):
        xml = ET.parse(session).getroot()
        session_roots.extend(xml.findall('./file/theory/goal'))
        goal_nodes.extend(xml.findall('.//goal'))
    entities = {int(k): v['name'] for k, v in spark['entities'].items()}
    checked_entities = sorted({entities[r['entity']] for r in spark['proof']})
    inventory = {'target': name, 'body_line': line, 'run_id': run_id, 'source_commit': source_commit,
                 'source_sha256': source_hash, 'actual_tool_exitcode': returncode, 'finished': finish,
                 'proof_records_by_severity': dict(collections.Counter(r['severity'] for r in spark['proof'])),
                 'flow_records_by_severity': dict(collections.Counter(r['severity'] for r in spark['flow'])),
                 'checked_proof_entities': checked_entities, 'proof_tree_branches': len(branches),
                 'proved_proof_tree_branches': sum(tree_proved(b) for b in branches),
                 'postcondition_tree_branches': sum(len(r['check_tree']) for r in post),
                 'proved_postcondition_tree_branches': sum(tree_proved(b) for r in post for b in r['check_tree']),
                 'saved_session_roots': len(session_roots),
                 'saved_session_roots_marked_proved': sum(g.get('proved') == 'true' for g in session_roots),
                 'saved_session_goal_nodes': len(goal_nodes),
                 'saved_session_goal_nodes_marked_proved': sum(g.get('proved') == 'true' for g in goal_nodes),
                 'progress': spark['progress'], 'stop_reason': spark['stop_reason'],
                 'skip_proof': spark['skip_proof'], 'skip_flow_proof': spark['skip_flow_proof'],
                 'pragma_assume': spark['pragma_assume'],
                 'non_info_records': [r for kind in ['proof', 'flow'] for r in spark[kind] if r['severity'] != 'info'],
                 'proof_records': [{'line': r['line'], 'column': r['col'], 'rule': r['rule'],
                                    'severity': r['severity'], 'tree_branches': len(r['check_tree']),
                                    'all_tree_branches_proved': all(tree_proved(b) for b in r['check_tree'])}
                                   for r in spark['proof']]}
    save(dest / 'obligation-inventory.json', inventory)
    save(dest / 'index.json', {'artifact_root': '.', 'run_id': run_id, 'source_commit': source_commit, 'artifacts': artifacts})
    prepared = next(e for e in events if e['event'] == 'prepared')['inputs']['inputs_sha256']
    matched = [r for r in common if r.get('native_input') in prepared]
    assert all(prepared[r['native_input']] == r['sha256'] for r in matched)
    result = {k: inventory[k] for k in ['target', 'body_line', 'run_id', 'actual_tool_exitcode',
               'proof_records_by_severity', 'flow_records_by_severity', 'proof_tree_branches',
               'proved_proof_tree_branches', 'postcondition_tree_branches', 'proved_postcondition_tree_branches']}
    result.update({'outcome': finish['outcome'], 'duration_seconds': finish['duration_seconds'],
                   'retained_native_inputs_matching_preflight': len(matched)})
    results.append(result)
    save(packet / 'summary.json', {'source_commit': source_commit, 'source_sha256': source_hash, 'results': results})
    print('FINISHED', json.dumps(result), flush=True)
    if returncode != 0 or finish['outcome'] != 'success':
        print('STOP_AT_FAILURE', name, flush=True)
        break
    assert spark['proof'] and checked_entities == ['Silver_Output_Profile.' + name]
    assert not inventory['non_info_records'] and all(tree_proved(b) for b in branches)
    assert not any(spark[k] for k in ['skip_proof', 'skip_flow_proof', 'pragma_assume'])

baseline = json.loads((scratch / 'canonical-before.json').read_text())['files']
rows = canonical_rows()
assert baseline == rows, 'Canonical failed report/session/cache metadata changed'
save(packet / 'canonical-preservation.json', {'utc': utc(), 'files': len(rows),
     'bytes': sum(r['bytes'] for r in rows), 'metadata_matches': True,
     'scope': 'Path/size/mtime metadata preservation; not fresh byte hashing of canonical directories'})
seen = set()
total = 0
for index in packet.rglob('index.json'):
    data = json.loads(index.read_text())
    for record in data['artifacts']:
        path = index.parent / data['artifact_root'] / record['path']
        content = gzip.decompress(path.read_bytes())
        assert len(content) == record['bytes'] and hashlib.sha256(content).hexdigest() == record['sha256'], path
        seen.add(path.resolve())
        total += len(content)
assert seen == {p.resolve() for p in packet.rglob('*.gz')}
save(packet / 'artifact-verification.json', {'utc': utc(), 'indexed_gzip_artifacts_verified': len(seen),
     'uncompressed_bytes_verified': total, 'all_gzip_files_indexed': True})
success = len(results) == len(targets) and all(r['outcome'] == 'success' and r['actual_tool_exitcode'] == 0 for r in results)
print('SEQUENCE_FINISHED', json.dumps({'success': success, 'targets_completed': len(results),
      'verified_artifacts': len(seen), 'canonical_metadata_unchanged': True}), flush=True)
sys.exit(0 if success else 1)
