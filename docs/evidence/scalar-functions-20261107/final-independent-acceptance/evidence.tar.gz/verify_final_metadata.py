"""Static metadata, dependency, and historical-evidence comparison only."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import ast
import gzip
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
E = ROOT / "docs/evidence/scalar-functions-20261107"
TARGET = "4d9ce491eedc50776b71577d8229ece67e38b0e7"
BEFORE = "f4957c07cb70a8246d957a2baa63a9c65557a5a1"


def sha(b):
    return hashlib.sha256(b).hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def load(p):
    b = p.read_bytes()
    return json.loads(gzip.decompress(b) if p.suffix == ".gz" else b)


report = {"target": TARGET, "scope": "Static metadata and dependency audit; no renderer or test execution",
          "started_utc": datetime.now(timezone.utc).isoformat()}
before = json.loads(git("show", BEFORE + ":rosetta/coverage.json"))
after = load(ROOT / "rosetta/coverage.json")
assert set(before) == set(after)
assert before["schema_version"] == after["schema_version"] and before["policy"] == after["policy"]
assert set(before["tasks"]) == set(after["tasks"])
task = "Primality by trial division"
changed_tasks = [k for k in before["tasks"] if before["tasks"][k] != after["tasks"][k]]
assert changed_tasks == [task]
assert set(after["supported"]) - set(before["supported"]) == {"scalar-functions"}
assert not set(before["supported"]) - set(after["supported"])
provenance_keys = ("revision", "assessed", "rubric", "tier", "model", "effort")
assert all(before["tasks"][task][k] == after["tasks"][task][k] for k in provenance_keys)
review = after["tasks"][task]["review"]
assert review["date"] == "2026-11-07" and review["model"] == "gpt-6.1-sol" and review["effort"] == "high"
assert set(after["tasks"][task]["surface"]) <= set(after["supported"])
assert not {"functions", "procedures", "booleans"} & set(after["supported"])
changed = git("diff", "--name-only", BEFORE, TARGET, "--", "rosetta").decode().splitlines()
changed_pages = [p for p in changed if p.endswith("/silver.md")]
target_page = "rosetta/p/primality-by-trial-division/silver.md"
other_pages = [p for p in changed_pages if p != target_page]
assert len(other_pages) == 258
position = re.compile(r"(?m)^Position \d+")
stage = re.compile(r"(?m)^Position (\d+).*?, in stage (\d+)\.$")
for p in other_pages:
    old = git("show", BEFORE + ":" + p).decode()
    new = (ROOT / p).read_text()
    assert position.sub("Position N", old) == position.sub("Position N", new), p
old_stage = stage.search(git("show", BEFORE + ":" + target_page).decode()).group(2)
new_stage = stage.search((ROOT / target_page).read_text()).group(2)
assert (old_stage, new_stage) == ("8", "1")
stage_counts = Counter()
for p in (ROOT / "rosetta").rglob("silver.md"):
    match = stage.search(p.read_text())
    if match:
        stage_counts[match.group(2)] += 1
assert stage_counts["1"] == 71
allowed_other_changes = {"rosetta/assess.js", "rosetta/assessment-scalar-functions-20261107.md",
                         "rosetta/coverage.json", "rosetta/progression.md", "rosetta/refresh.py"}
assert set(changed) - set(changed_pages) == allowed_other_changes
assert sha((ROOT / "samples/rosetta_primality_by_trial_division.adb").read_bytes()) == "6e2d5263135fb3aa0c36554425303c3b87a375315207c37ee897c5ed71b457a4"
ro_summary = load(E / "rosetta-delivery/summary.json")
assert sha((ROOT / "rosetta/coverage.json").read_bytes()) == ro_summary["coverage_sha256"]
ros_events = [json.loads(b) for b in gzip.decompress((E / "rosetta-delivery/events.jsonl.gz").read_bytes()).splitlines()]
ros_inputs = next(x for x in ros_events if x["event"] == "prepared")["inputs"]["inputs_sha256"]
ros_differences = [p for p, expected in ros_inputs.items() if not (ROOT / p).is_file() or sha((ROOT / p).read_bytes()) != expected]
assert not ros_differences, ros_differences
report["rosetta"] = {"baseline": BEFORE, "supported_added": ["scalar-functions"], "supported_removed": [],
                     "changed_tasks": changed_tasks, "task_count": len(after["tasks"]),
                     "provenance": {k: after["tasks"][task][k] for k in provenance_keys},
                     "separate_review": review, "stage_before": 8, "stage_after": 1,
                     "stage_one_before": 70, "stage_one_after": stage_counts["1"],
                     "other_generated_pages_only_position_changed": len(other_pages),
                     "other_changed_files": sorted(allowed_other_changes), "prepared_inputs_matched": len(ros_inputs),
                     "source_sha256": sha((ROOT / "samples/rosetta_primality_by_trial_division.adb").read_bytes()),
                     "coverage_sha256": ro_summary["coverage_sha256"]}

# The doc-only change preserves the already approved auditor boundary verbatim
# outside the explicitly changed current-status introduction.
approved_boundary = git("show", "dfda468593:docs/trusted-boundary.md").decode()
current_boundary = (ROOT / "docs/trusted-boundary.md").read_text()
heading = "## Small scalar-function boundary"
next_heading = "## Scalar guard refinement boundary"
def elide_current_intro(s):
    return s[:s.index(heading)] + s[s.index(next_heading):]
assert elide_current_intro(approved_boundary) == elide_current_intro(current_boundary)

docs = ["README.md", "language.md", "roadmap.md", "docs/scalar-functions.md",
        "docs/scalar-functions-report-capacity.md", "docs/assurance.md", "docs/trusted-boundary.md", "docs/session-memory.md"]
patch = git("diff", "0333d33503", TARGET, "--", *docs).decode()
links, current_file = [], None
for line in patch.splitlines():
    if line.startswith("+++ b/"):
        current_file = line[6:]
    elif line.startswith("+") and not line.startswith("+++"):
        for dest in re.findall(r"\[[^\]]*\]\(([^)]+)\)", line[1:]):
            if not dest.startswith(("http:", "https:", "mailto:")):
                path, _, anchor = dest.partition("#")
                resolved = (ROOT / current_file).parent / path if path else ROOT / current_file
                resolved = resolved.resolve()
                assert resolved.is_file(), (current_file, dest)
                if anchor:
                    headings = re.findall(r"(?m)^#+ (.*)$", resolved.read_text())
                    ids = {re.sub(r"[^\w\- ]", "", h.lower()).replace(" ", "-") for h in headings}
                    assert anchor in ids, (current_file, dest)
                links.append({"source": current_file, "destination": dest})
report["documentation"] = {"files": docs, "changed_local_links_checked": len(links), "links": links,
                           "approved_auditor_boundary_preserved": True,
                           "oracle_changed": bool(git("diff", "--name-only", "0333d33503", TARGET, "--", "oracle.md").strip())}
assert not report["documentation"]["oracle_changed"]

# No target test bytes drifted in the actual regression checkout after recording.
regression = ROOT.parent / "scalar-functions-298"
tracked_tests = git("ls-files", "tests").decode().splitlines()
assert all((ROOT / p).read_bytes() == (regression / p).read_bytes() for p in tracked_tests)
platform_preflight = load(E / "final-regression/isolated-final/platform-wrapper/00-preflight.json.gz")
assert all(sha((regression / p).read_bytes()) == h for p, h in platform_preflight["inputs"].items())
assert all(sha((regression / ".silver/linux-x86_64/compiler/bin" / name).read_bytes()) == h
           for name, h in platform_preflight["binaries"].items())
report["actual_regression_checkout"] = {"test_files_identical": len(tracked_tests),
                                       "recorded_inputs_match": len(platform_preflight["inputs"]),
                                       "binary_hashes_match": platform_preflight["binaries"]}

# Failed full-Lean history remains a failed packet and has no completed evidence.
failed = E / "complete-lean/20261108T094147-fb5330310904"
failed_index = load(failed / "index.json")
for row in failed_index:
    p = failed / row["artifact"]
    b = gzip.decompress(p.read_bytes())
    assert sha(b) == row["sha256"] and len(b) == row["bytes"]
    assert p.read_bytes() == git("show", TARGET + ":" + str(p.relative_to(ROOT)))
fs = load(failed / "summary.json")
assert fs["finished"]["outcome"] == "failure" and fs["actual_tool_exit"]["exit_code"] == 1
assert not (failed / "lean-evidence.json.gz").exists()
report["old_lean_failure"] = {"verified_members": len(failed_index), "outcome": "failure", "actual_exit": 1,
                              "completed_evidence_absent": True}

composition = load(E / "final-regression/final-645-id-resolution.json")
per_id = []
for row in composition["rows"]:
    ident = row["id"]
    origin = row["final_result_origin"]
    if origin == "fresh pending resolution":
        basis = "Accepted original-method current-input success; the twelve nested platform IDs use the original wrapper execution contract and observed child command."
    elif origin == "fresh Rosetta refresh":
        basis = "Accepted original Rosetta-method success after exact metadata/render update; replaces the old result for this existing ID."
    elif ident.startswith(("test_lean_source.", "test_lean_modules.", "test_lean_evidence.")):
        basis = "Retained prior independent acceptance. Added public facade edge changes no source-binding include_str or legacy-module predicate, lower candidate/source-check closure, synthetic fixture or fixed chunk-copy helper; unchanged whole-project checking is separately completed."
    else:
        basis = "Retained prior independent acceptance. The sole intervening facade edge and status/Rosetta documentation do not alter this native/Python fixture's executed dependencies; tests, scripts, source, binaries and project options retain their recorded scope."
    per_id.append({"id": ident, "accepted": True, "result_origin": origin, "evidence": row["final_result"], "applicability": basis})
(OUT / "accepted-645-id-resolution.json").write_text(json.dumps({"target": TARGET, "inventory_count": len(per_id),
        "scope": "Independent final composition of retained accepted and fresh original-method evidence; no test execution by this reviewer",
        "remaining_pending": [], "rows": per_id}, indent=2) + "\n")
report["accepted_per_id_sha256"] = sha((OUT / "accepted-645-id-resolution.json").read_bytes())
report["finished_utc"] = datetime.now(timezone.utc).isoformat()
(OUT / "metadata-and-applicability-verification.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"changed_assessments": changed_tasks, "position_only_pages": len(other_pages),
                  "rosetta_prepared_inputs": len(ros_inputs), "local_links_checked": len(links),
                  "regression_test_files": len(tracked_tests), "accepted_ids": len(per_id),
                  "old_failed_payloads_verified": len(failed_index), "output": str(OUT)}, indent=2))
