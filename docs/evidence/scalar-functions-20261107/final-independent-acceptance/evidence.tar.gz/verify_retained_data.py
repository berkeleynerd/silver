"""Read retained data and Git objects only; never invoke production validation."""
from pathlib import Path
from datetime import datetime, timezone
import ast
from collections import Counter
import gzip
import hashlib
import json
import re
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
E = ROOT / "docs/evidence/scalar-functions-20261107"
TARGET = "4d9ce491eedc50776b71577d8229ece67e38b0e7"
GOVERNED = "0333d3350384c1af05380e288d9fdd386a13b5a3"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    data = path.read_bytes()
    return gzip.decompress(data) if path.suffix == ".gz" else data


def obj(path):
    return json.loads(read(path))


def events(path):
    return [json.loads(line) for line in read(path).splitlines()]


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def compare_map(root, values):
    missing, changed = [], []
    for relative, expected in values.items():
        p = root / relative
        if not p.is_file():
            missing.append(relative)
        elif sha(p.read_bytes()) != expected:
            changed.append(relative)
    return {"count": len(values), "missing": missing, "changed": changed}


def check_map(root, values):
    result = compare_map(root, values)
    assert not result["missing"] and not result["changed"], result
    return result


report = {"target": TARGET, "governed_inputs": GOVERNED,
          "started_utc": datetime.now(timezone.utc).isoformat(),
          "scope": "Read-only retained-data and exact input reconciliation; no production auditor, test, build, proof, renderer or tool-version command executed."}
assert git("rev-parse", "HEAD").decode().strip() == TARGET

# All intervening implementation paths are unchanged. Test IDs therefore retain
# the independently reviewed inventory; the facade is the only later proof edge.
governed_paths = ["src", "proof", "scripts", "tests", "samples", "catalogue", "silver.gpr", "alire.toml"]
delta = git("diff", "--name-only", GOVERNED, TARGET, "--", *governed_paths).decode().splitlines()
assert not delta, delta
prior_delta = git("diff", "--name-only", "53d3a3b22b", TARGET, "--", *governed_paths).decode().splitlines()
assert prior_delta == ["proof/Silver.lean"], prior_delta
assert git("show", "53d3a3b22b:scripts/check_evidence.py") == (ROOT / "scripts/check_evidence.py").read_bytes()
assert git("show", "53d3a3b22b:tests/test_evidence.py") == (ROOT / "tests/test_evidence.py").read_bytes()
report["governed_changes_since_0333"] = delta
report["governed_changes_since_independently_reviewed_53d3"] = prior_delta
report["auditor_sha256"] = sha((ROOT / "scripts/check_evidence.py").read_bytes())

# Verify indexed retained payloads without re-executing their producers.
native = E / "native-checkpoint/auditor-refresh-53d3"
lean = E / "complete-lean/20261108T172947-84b3cd350332"
focused = E / "focused/20261108T172824-28123f63af08"
indices = [native / "runs/20261108T155015-d9cbdb714cbd/index.json",
           lean / "index.json", focused / "index.json",
           E / "frame-flow-import-diagnosis/index.json",
           *(E / "final-regression/isolated-final" / n / "index.json"
             for n in ("maximum-expression", "self-actuals", "ordered-calls", "platform-wrapper")),
           E / "rosetta-delivery/index.json"]
artifacts = []
for index in indices:
    data = obj(index)
    base = index.parent
    rows = data
    if isinstance(data, dict):
        base = (base / data.get("artifact_root", ".")).resolve()
        rows = data["artifacts"]
    names = []
    for row in rows:
        name = row.get("artifact", row.get("path"))
        p = base / name
        b = read(p)
        assert sha(b) == row["sha256"] and len(b) == row["bytes"], p
        # The indexed data is also the actual committed payload at the target.
        relative = str(p.relative_to(ROOT))
        assert git("show", f"{TARGET}:{relative}") == p.read_bytes(), relative
        names.append(relative)
    assert len(names) == len(set(names)), index
    artifacts.append({"index": str(index.relative_to(ROOT)), "verified_members": len(names),
                      "decoded_bytes": sum(row["bytes"] for row in rows)})
report["indexed_payloads"] = artifacts

# Native snapshot/provenance equality, archive identities, and current inputs.
ni = obj(native / "final-reports/proof-inputs.json.gz")
np = obj(native / "final-reports/proof-provenance.json.gz")
assert np["complete"] is True
assert all(np[k] == v for k, v in ni.items())
ne = events(native / "runs/20261108T155015-d9cbdb714cbd/events.jsonl.gz")
prepared = next(x for x in ne if x["event"] == "prepared")
assert prepared["inputs"]["inputs_sha256"] == ni["inputs_sha256"]
assert ne[-1]["outcome"] == "success" and ne[-1]["failure_keys"] == []
assert any(x["event"] == "phase-end" and x.get("phase") == "native-tool" and x["returncode"] == 0 for x in ne)
assert any(x["event"] == "phase-end" and x.get("phase") == "audit" for x in ne)
native_exit = obj(native / "observations/actual-tool-exit.json.gz")
assert native_exit["actual_driver_exit_code"] == 0
native_root = ROOT.parent / "scalar-functions-parser-repairs-298"
native_current = check_map(native_root, ni["inputs_sha256"])
repository_inputs = {p: h for p, h in ni["inputs_sha256"].items() if not p.startswith((".silver/", ".tools/"))}
native_repo = check_map(ROOT, repository_inputs)
archived_inputs = 0
for p in (native / "final-inputs").rglob("*.gz"):
    relative = str(p.relative_to(native / "final-inputs"))[:-3]
    if relative.startswith(("generated/", "toolchain/")):
        relative = ".silver/linux-x86_64/" + relative
    assert sha(read(p)) == ni["inputs_sha256"][relative], relative
    archived_inputs += 1
for name, expected in np["reports_sha256"].items():
    assert sha(read(native / "final-reports" / (name + ".gz"))) == expected, name
for name, tool in ni["tools"].items():
    assert sha(Path(tool["path"]).read_bytes()) == tool["sha256"], name
native_log = read(native / "runs/20261108T155015-d9cbdb714cbd/native.log.gz").decode()
native_success = "Success: all checks proved (18525 checks)."
native_audit = "Complete GNATprove evidence: 77 units, 1165 entities, 1605 flow_checks, 16920 proof_checks, 330 limitation_notes, 18 imported_entities, 6253 trusted_math_notes, 62 vendor_spec_entities, 6 array_initialization_advisories, 12 operator_reassociation_advisories"
assert native_success in native_log and native_audit in native_log
report["native"] = {"run": "20261108T155015-d9cbdb714cbd", "actual_exit": native_exit,
                    "complete_provenance": True, "snapshot_matches_provenance_and_prepared_event": True,
                    "current_native_workspace_inputs": native_current, "current_repository_inputs": native_repo,
                    "archived_native_inputs": archived_inputs, "provenance_report_hashes_verified": len(np["reports_sha256"]),
                    "current_tool_executable_hashes_verified": len(ni["tools"]),
                    "command": ni["command"], "initial_state": ni["initial_state"],
                    "actual_log_checks": native_success, "actual_log_complete_audit": native_audit}

# Actual full Lean import inventory, fresh audit, and exact complete input set.
le = events(lean / "events.jsonl.gz")
li = le[0]["inputs"]["sources"]
lr = obj(lean / "lean-evidence.json.gz")
ls = obj(lean / "summary.json")
assert le[-1]["outcome"] == "success" and le[-1]["failure_keys"] == []
assert ls["actual_tool_exit"]["exit_code"] == 0
assert lr["scope"] == "complete" and lr["axiom_audit"] == "passed"
assert lr["clean_build"] is False and lr["kernel_recheck"] is None
assert all(p["exit_code"] == 0 for p in lr["phases"])
lean_current = check_map(ROOT, li)
lean_current_integration = check_map(ROOT.parent / "scalar-functions-source-integration-298", li)
source_modules = {".".join(p.relative_to(ROOT / "proof").with_suffix("").parts): p
                  for p in (ROOT / "proof").rglob("*.lean") if ".lake" not in p.parts and p.name != "lakefile.lean"}
ll = read(lean / "lean-proof.log.gz").decode()
logged_modules = re.findall(r"^SILVER_MODULE (\S+)$", ll, re.M)
assert len(logged_modules) == len(set(logged_modules)) == 820
assert set(logged_modules) == set(source_modules) == set(lr["modules"])
assert "Silver axiom audit passed: 145525 declarations; foundations: [propext, Classical.choice, Quot.sound]" in ll
assert "Build completed successfully (857 jobs)." in ll
assert "import Silver.ScalarFunctionFrameFlow" in (ROOT / "proof/Silver.lean").read_text()
checker_ast = ast.parse((ROOT / "scripts/check_lean.py").read_text())
cert_expr = next(n.value for n in checker_ast.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "CERTIFICATE_ROOTS" for t in n.targets))
certs = {Path(ast.literal_eval(k.args[0])) for k in cert_expr.keys}
candidates = certs | {Path(f"Silver/OutputBodyLines{i}.lean") for i in range(8)}
expected_lean_inputs = {str(p.relative_to(ROOT)) for p in source_modules.values() if p.relative_to(ROOT / "proof") not in candidates}
expected_lean_inputs |= {"proof/lakefile.lean", "proof/lean-toolchain", "proof/generate_source_certificate.py"}
expected_lean_inputs |= {str(p.relative_to(ROOT)) for pattern in ("src/*.ads", "src/*.adb", "scripts/*.py") for p in ROOT.glob(pattern)}
assert expected_lean_inputs == set(li)
for path, h in lr["tools_sha256"].items():
    assert sha((ROOT.parent / "scalar-functions-source-integration-298" / path).read_bytes()) == h, path
fe = events(focused / "events.jsonl.gz")
fr = obj(focused / "lean-focused-evidence.json.gz")
fx = obj(focused / "actual-tool-exit.json")
assert fx["exit_code"] == 0
assert fe[-1]["outcome"] == "success" and fr["axiom_audit"] == "passed"
assert fr["scope"] == "focused" and fr["targets"] == ["Silver.ScalarFunctionFrameFlow"]
fl = read(focused / "lean-focused.log.gz").decode()
assert "Silver axiom audit passed: 9973 declarations" in fl and "Build completed successfully (97 jobs)." in fl
report["lean"] = {"run": lr["run_id"], "scope": lr["scope"], "phases": lr["phases"],
                  "module_count": len(logged_modules), "module_sets_match_exactly": True,
                  "declarations": 145525, "foundations": ["propext", "Classical.choice", "Quot.sound"],
                  "current_review_inputs": lean_current, "current_integration_inputs": lean_current_integration,
                  "complete_input_selector_matches": True, "input_digest": lr["inputs_digest_sha256"],
                  "clean_build": False, "kernel_recheck": None, "workers": lr["lake_workers"],
                  "threads": lr["threads_per_process"], "focused_run": fr["run_id"],
                  "focused_scope": fr["scope"], "focused_declarations": 9973}

# Bind the final per-ID composition to the independently accepted inventory.
bundle_root = E / "native-policy-independent-review"
manifest = obj(bundle_root / "manifest.json")
bundle = bundle_root / manifest["archive"]
assert sha(bundle.read_bytes()) == manifest["archive_sha256"]
with tarfile.open(bundle) as archive:
    assert {m.name for m in archive.getmembers()} == {x["path"] for x in manifest["members"]}
    for member in manifest["members"]:
        b = archive.extractfile(member["path"]).read()
        assert sha(b) == member["sha256"] and len(b) == member["bytes"]
    prior = json.load(archive.extractfile("regression-delta.json"))
final = obj(E / "final-regression/final-645-id-resolution.json")
prior_rows = {x["id"]: x for x in prior["rows"]}
final_rows = {x["id"]: x for x in final["rows"]}
assert len(prior_rows) == len(prior["rows"]) == len(final_rows) == len(final["rows"]) == 645
assert prior_rows.keys() == final_rows.keys()
for ident, row in prior_rows.items():
    assert all(final_rows[ident][k] == v for k, v in row.items()), ident
assert all(x["final_outcome"] == "success" for x in final_rows.values())
prior_pending = {x["id"] for x in prior_rows.values() if x["disposition"] == "pending_prior_required_validation"}
fresh_pending = {x["id"] for x in final_rows.values() if x["final_result_origin"] == "fresh pending resolution"}
rosetta_ids = {x["id"] for x in final_rows.values() if x["final_result_origin"] == "fresh Rosetta refresh"}
assert prior_pending == fresh_pending and len(fresh_pending) == 16 and len(rosetta_ids) == 3
fresh = []
for name in ("maximum-expression", "self-actuals", "ordered-calls", "platform-wrapper"):
    base = E / "final-regression/isolated-final" / name
    summary = obj(base / "summary.json")
    pre = obj(base / "00-preflight.json.gz")
    ev = events(next(base.glob("*events.jsonl.gz")))
    exit_record = obj(next(base.glob("*actual-exit.json.gz")))
    log = read(next(base.glob("*native.log.gz"))).decode()
    assert ev[-1]["outcome"] == "success" and summary["outcome"] == "success"
    assert exit_record["returncode"] == 0 and summary["actual_driver_exit"] == 0
    assert exit_record["inputs_unchanged"] is True and summary["inputs_unchanged"] is True
    assert "Ran 1 test in " in log and log.rstrip().endswith("OK") and "... ok" in log
    assert summary["selector"] in log
    differences = compare_map(ROOT, pre["inputs"])
    expected_differences = [] if name == "platform-wrapper" else ["proof/Silver.lean"]
    assert differences["changed"] == expected_differences and not differences["missing"], (name, differences)
    for ident, value in summary["per_id"].items():
        expected_value = "ok" if ident == summary["selector"] else "ok via original successful wrapper"
        assert value == expected_value and ident in fresh_pending
        if ident != summary["selector"]:
            assert name == "platform-wrapper" and ident.startswith("test_platforms.PlatformIsolationTests.")
        assert final_rows[ident]["final_result"]["run_id"] == summary["run_id"]
    fresh.append({"name": name, "run_id": summary["run_id"], "ids": sorted(summary["per_id"]),
                  "actual_driver_exit": summary["actual_driver_exit"], "test_seconds": summary["test_seconds"],
                  "recorded_input_count": len(pre["inputs"]), "current_input_differences": differences,
                  "command": pre["command"], "binaries": pre["binaries"]})
assert set().union(*(set(x["ids"]) for x in fresh)) == fresh_pending
platform_ast = ast.parse((ROOT / "tests/test_platforms.py").read_text())
pc = next(n for n in platform_ast.body if isinstance(n, ast.ClassDef) and n.name == "PlatformIsolationTests")
platform_ids = {"test_platforms.PlatformIsolationTests." + n.name for n in pc.body if isinstance(n, ast.FunctionDef) and n.name.startswith("test_")}
assert len(platform_ids) == 12 and platform_ids < fresh_pending
assert not any(isinstance(n, ast.Attribute) and n.attr in ("skipTest", "skip", "skipIf", "skipUnless") for n in ast.walk(pc))
assert not any(isinstance(n, ast.FunctionDef) and n.decorator_list for n in pc.body)
assert not any(isinstance(n, ast.FunctionDef) and n.name == "load_tests" for n in platform_ast.body)
platform_observations = events(E / "final-regression/isolated-final/platform-wrapper/07-observations.jsonl.gz")
platform_child_commands = sorted({p["command"] for observation in platform_observations for p in observation["processes"]
                                  if re.search(r"/tests/test_platforms\.py PlatformIsolationTests -v\s*$", p["command"])})
assert len(platform_child_commands) == 1
ro = E / "rosetta-delivery"
ros_events = events(ro / "events.jsonl.gz")
ros_log = read(ro / "native.log.gz").decode()
assert ros_events[-1]["outcome"] == "success"
assert "Ran 3 tests in 6.422s" in ros_log and ros_log.rstrip().endswith("OK")
assert all(ident in ros_log for ident in rosetta_ids)
report["regression"] = {"inventory": len(final_rows), "inventory_and_prior_fields_exact": True,
                        "prior_independent_review": manifest["review_commit"], "prior_bundle_sha256": manifest["archive_sha256"],
                        "prior_successes": 629, "remaining_old_results": 626, "resolved_pending": len(fresh_pending),
                        "refreshed_rosetta": sorted(rosetta_ids), "pending": [], "fresh_runs": fresh,
                        "nested_platform_ids": sorted(platform_ids), "nested_stdout_retained": False,
                        "observed_nested_class_command": platform_child_commands,
                        "final_rows_sha256": sha((E / "final-regression/final-645-id-resolution.json").read_bytes())}

report["finished_utc"] = datetime.now(timezone.utc).isoformat()
(OUT / "retained-data-verification.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"target": TARGET, "native_inputs": native_current["count"],
                  "native_repository_inputs": native_repo["count"], "native_reports": len(np["reports_sha256"]),
                  "verified_payloads": sum(x["verified_members"] for x in artifacts),
                  "lean_inputs": lean_current["count"], "lean_modules": len(logged_modules),
                  "regression_ids": len(final_rows), "fresh_pending_resolutions": len(fresh_pending),
                  "refreshed_rosetta": len(rosetta_ids), "output": str(OUT / "retained-data-verification.json")}, indent=2))
