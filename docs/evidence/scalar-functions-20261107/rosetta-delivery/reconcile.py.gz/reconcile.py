from pathlib import Path
import collections,hashlib,json,re,subprocess,sys
sys.path.insert(0,str(Path.cwd()))
from rosetta import refresh
root=Path.cwd();before=json.loads(subprocess.check_output(['git','show','HEAD:rosetta/coverage.json']));after=json.loads(Path('rosetta/coverage.json').read_text());manifest=json.loads(Path('rosetta/manifest.json').read_text())['tasks'];target='Primality by trial division'
changed=[t for t in set(before['tasks'])|set(after['tasks']) if before['tasks'].get(t)!=after['tasks'].get(t)];assert changed==[target]
assert set(after['supported'])-set(before['supported'])=={'scalar-functions'} and set(before['supported'])<=set(after['supported'])
provenance=('revision','assessed','rubric','tier','model','effort')
assert all(before['tasks'][target].get(k)==after['tasks'][target].get(k) for k in provenance)
def stages(coverage):
 candidates=[]
 for task in manifest:
  assessed=coverage['tasks'].get(task['title'])
  if assessed and refresh.verdict(assessed,refresh.reasons(assessed,coverage['policy'])) in refresh.OUTLOOKS:
   candidates.append({'title':task['title'],'task':dict(task),'assessed':assessed})
 stage=0;result={}
 for position,(item,new) in enumerate(refresh.progression(candidates,coverage['supported']),1):
  stage+=bool(new) or position==1;result[item['title']]={'stage':stage,'rank':position}
 return result
b=stages(before);a=stages(after);delta={t:{'before':b[t]['stage'],'after':a[t]['stage']} for t in b if b[t]['stage']!=a[t]['stage']};assert delta=={target:{'before':8,'after':1}}
files=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines();rank_only=[]
for filename in files:
 if filename.endswith('/silver.md') and filename!='rosetta/p/primality-by-trial-division/silver.md':
  old=subprocess.check_output(['git','show','HEAD:'+filename],text=True);new=Path(filename).read_text()
  assert re.sub(r'^Position \d+', 'Position #',old,flags=re.M)==re.sub(r'^Position \d+','Position #',new,flags=re.M),filename
  rank_only.append(filename)
page=Path('rosetta/p/primality-by-trial-division/silver.md').read_text();assert 'in stage 1.' in page
summary={'baseline':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'changed_assessments':changed,'supported_added':['scalar-functions'],'supported_removed':[],'original_provenance':{k:before['tasks'][target].get(k) for k in provenance},'stage_changes':delta,'stage1_before':sum(x['stage']==1 for x in b.values()),'stage1_after':sum(x['stage']==1 for x in a.values()),'target_rank':a[target]['rank'],'generated_non_target_pages_changed_only_in_rank':len(rank_only),'changed_tracked_files':len(files),'coverage_sha256':hashlib.sha256(Path('rosetta/coverage.json').read_bytes()).hexdigest(),'render_command':['python3','rosetta/refresh.py','--render'],'actual_render_tool_session':96012,'actual_render_exit':0,'regression_run':'20261108T174013-0af40cd230ed','regression_tool_session':35377,'regression_actual_exit':0,'test_count':3,'test_seconds':6.422,'native_or_lean_input_changed':False}
assert summary['stage1_before']==70 and summary['stage1_after']==71
Path('tmp/final-rosetta-delivery/summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
