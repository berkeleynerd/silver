# Final approved platform wrapper: actual success

Review target: integration `5aa1509fc5ac2d6f2dc02c5803d94da7e201aaf1`;
production proof/src/scripts are `47fe4003c0`. Exact test-only source commit
`92412ec75f4b1bcf5ab99022ac378801a3d16763` (integrated as `9e89c80f82`),
test SHA256 `92e107283974c2f905f5a7c96eab3fc306c51df5ec4034b06148a2ffd8773a30`.

The coordinator authorized the previously reviewed exact patch and one complete
wrapper. Managed native Linux run `20261108T075522-000e545aebc8` exited 0/success.
The original `test_symlinked_tmpdir_preserves_platform_setup_and_routing` passed:
1 test, 0 errors/failures/skips/reporting errors. Unittest elapsed 622.697586243s;
observer elapsed 626.777666379s; managed elapsed 647.801088295s. Limits remain
worker180 / wrapper900 / barrier15. No retry or further budget change occurred.

Normal imports and the original wrapper selected all 12 PlatformIsolationTests.
Its assertion establishes that the nested unittest process returned success.
The class has no skip/decorator/conditional-selection paths. This freshly covers
all 12 bodies under the required symlink environment and the outer method. It
is not a separate fresh non-symlink invocation. The original method captures
nested stdout/stderr internally and does not retain successful output; neither
collector nor observer replaces that subprocess call or invents nested records.
Mocked tool behavior, real generators, assertions and cleanup are unchanged.
These are routing/setup regressions, not real complete native or Lean proofs.

The process observer recorded one nested suite and 15 setup workers directly
parented by it, matching the reviewed 11 serial calls plus four concurrent calls.
Its raw substring filter reports 16 setup-command matches: PID646031 was a child
of worker645859, first sampled with its parent's command line and zero CPU ticks,
not a direct child of suite642921. `worker-observation-review.json` retains that
classification without rewriting raw observations. The same exact TMPDIR/TMP/TEMP
symlink alias was verified for the nested suite and all matching observations.
Short-lived process sampling is not an exact generator-invocation census.

All 884 captured managed input hashes were checked unchanged after actual exit.
The 866 frozen/copied source files (54,490,363 bytes), their modes, all 821 Lean
paths, and the corresponding current regression checkout bytes/modes match the
final fixture inputs. Only the approved test file differs from the previous
866-file snapshot; the remaining865 inputs match `47fe4003c0`. The finalizer ran
once after managed completion. No descendants, lease or temporary entries remain;
the observer sent no cleanup signal. Sampled available memory never fell below
43.962GiB. Four workers were reserved; peak preflight reservation17/22.

Retain the original full-suite failure and all earlier diagnostic failures as
failures. This success resolves the second regression fixture only. The separate
637-result applicability review and complete native/Lean assurance remain required.
Private inherited environment is excluded from the shareable bundle. Selected
reviewer GPT-6 Astra / Extra High; live runtime telemetry unavailable. No source,
proof or script edits in the review worktree; no publication/merge/CLI-memory update.
