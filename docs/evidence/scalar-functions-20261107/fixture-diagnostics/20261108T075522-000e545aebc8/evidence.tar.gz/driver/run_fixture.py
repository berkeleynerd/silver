"""One isolated approved platform fixture, with owned-session observation."""
import ctypes,hashlib,json,os,shutil,signal,stat,subprocess,sys,time
from pathlib import Path
CASE=Path(__file__).resolve().parents[1];FROZEN=CASE/'frozen-inputs';RESULTS=CASE/'results'
ROOT=Path('/tmp/silver-platform-final-root-298-20261108');TEMPS=Path('/tmp/silver-platform-final-temporaries-298-20261108')
def digest(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(name,value):(RESULTS/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def event(name,**kw):
 with (RESULTS/'observer-events.jsonl').open('a') as f:f.write(json.dumps({'event':name,'monotonic_ns':time.monotonic_ns(),'utc_ns':time.time_ns(),**kw},sort_keys=True)+'\n')
def proc_stat(pid):
 raw=Path(f'/proc/{pid}/stat').read_text();a=raw[raw.rfind(')')+2:].split()
 return {'pid':pid,'ppid':int(a[1]),'sid':int(a[3]),'state':a[0],'start_ticks':int(a[19]),'utime_ticks':int(a[11]),'stime_ticks':int(a[12]),'rss_pages':int(a[21])}
def members(sid):
 rows=[]
 for p in Path('/proc').iterdir():
  if p.name.isdecimal():
   try:
    row=proc_stat(int(p.name))
    if row['sid']==sid:rows.append(row)
   except (OSError,ValueError,IndexError):pass
 return rows
def inventory():
 rows=[]
 for item in json.loads((FROZEN/'copy-inventory.json').read_text()):
  p=ROOT/item['path'];rows.append({'path':item['path'],'sha256':digest(p),'mode':stat.S_IMODE(p.stat().st_mode),'bytes':p.stat().st_size})
 return rows
assert not ROOT.exists() and not ROOT.is_symlink() and not TEMPS.exists() and not TEMPS.is_symlink()
assert not RESULTS.exists(),'Refuse repeated execution';RESULTS.mkdir()
for name,sha in json.loads((FROZEN/'snapshot-sha256.json').read_text()).items():assert digest(FROZEN/name)==sha,name
items=json.loads((FROZEN/'copy-inventory.json').read_text());assert len(items)==866
ROOT.mkdir();TEMPS.mkdir(mode=0o700)
for item in items:
 source=FROZEN/item['path'];destination=ROOT/item['path'];destination.parent.mkdir(parents=True,exist_ok=True)
 assert digest(source)==item['sha256'] and stat.S_IMODE(source.stat().st_mode)==item['mode'];shutil.copy2(source,destination)
expected=[{k:item[k] for k in ['path','sha256','mode','bytes']} for item in items];before=inventory();assert before==expected
write('copied-inputs-before.json',before)
expected_lean=sorted(i['path'] for i in items if i['path'].startswith('proof/') and i['path'].endswith('.lean'))
assert len(expected_lean)==821 and sorted(str(p.relative_to(ROOT)) for p in (ROOT/'proof').rglob('*.lean'))==expected_lean
assert not any((ROOT/x).exists() for x in ['.tools','.silver','proof/.lake'])
env=json.loads((FROZEN/'private-inherited-environment.json').read_text());old_tmp={k:env.get(k) for k in ['TMPDIR','TMP','TEMP']}
env.update({k:str(TEMPS) for k in ['TMPDIR','TMP','TEMP']})
write('temporary-environment-change.json',{'previous':old_tmp,'scoped':{k:env[k] for k in old_tmp},'nested_method_retains_own_alias_override':True})
visible={'PATH','TMPDIR','TMP','TEMP','LANG','LC_ALL'}
write('fixture-environment.json',{k:{'value':v} if k in visible or k.startswith(('LEAN','LAKE','ELAN')) else {'sha256':hashlib.sha256(v.encode()).hexdigest()} for k,v in sorted(env.items())})
libc=ctypes.CDLL(None,use_errno=True)
if libc.prctl(36,1,0,0,0)!=0:raise OSError(ctypes.get_errno(),'cannot enable owned-child subreaping')
command=['/usr/bin/python3','-B',str(CASE/'driver/fixture_child.py')]
write('fixture-command.json',{'argv':command,'cwd':str(ROOT),'observer_outer_timeout':None,'approved_nested_suite_timeout':900,'approved_worker_timeout':180,'original_barrier_timeout':15,'assertions_mock_behavior_and_cleanup_unchanged':True,'source_commit':'92412ec75f4b1bcf5ab99022ac378801a3d16763'})
seen=set();started=time.monotonic_ns()
with (RESULTS/'unittest-stdout.bin').open('wb') as out,(RESULTS/'unittest-stderr.bin').open('wb') as err:
 child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=out,stderr=err,start_new_session=True);assert os.getsid(child.pid)==child.pid;event('fixture-process-start',pid=child.pid,sid=child.pid)
 while child.poll() is None:
  rows=members(child.pid)
  for row in rows:
   identity=(row['pid'],row['start_ticks'])
   if identity not in seen:
    seen.add(identity)
    try:
     row['cmdline']=Path(f"/proc/{row['pid']}/cmdline").read_bytes().replace(b'\0',b' ').decode(errors='replace')
     raw=Path(f"/proc/{row['pid']}/environ").read_bytes().split(b'\0');selected={}
     for field in raw:
      key,sep,value=field.partition(b'=')
      if key in [b'TMPDIR',b'TMP',b'TEMP']:selected[key.decode()]=value.decode()
     row['temporary_environment']=selected
     tmp=selected.get('TMPDIR');alias=Path(tmp) if tmp else None
     if alias is not None and alias.is_relative_to(TEMPS):row['temporary_path_observation']={'is_symlink':alias.is_symlink(),'resolved':str(alias.resolve()),'exists':alias.exists()}
    except OSError:row.setdefault('cmdline','<exited before read>')
    event('process-first-seen',**row)
  event('process-sample',processes=rows,loadavg=Path('/proc/loadavg').read_text(),memavailable_kib=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable'))))
  time.sleep(1)
 returncode=child.wait()
while True:
 remaining=members(child.pid)
 if not remaining:break
 for row in remaining:
  try:
   now=proc_stat(row['pid'])
   if now['sid']==child.pid and now['start_ticks']==row['start_ticks'] and row['state']!='Z':os.kill(row['pid'],signal.SIGKILL);event('post-fixture-owned-descendant-cleanup',pid=row['pid'],start_ticks=row['start_ticks'],sid=child.pid)
   if row['ppid']==os.getpid():
    reaped,status=os.waitpid(row['pid'],os.WNOHANG)
    if reaped:event('owned-descendant-reaped',pid=reaped,wait_status=status)
  except (OSError,ChildProcessError):pass
 time.sleep(.1)
after=inventory();write('copied-inputs-after.json',after);assert before==after
assert sorted(str(p.relative_to(ROOT)) for p in (ROOT/'proof').rglob('*.lean'))==expected_lean
fixture=json.loads((RESULTS/'fixture-result.json').read_text()) if (RESULTS/'fixture-result.json').exists() else None
summary={'returncode':returncode,'fixture_result':fixture,'duration_seconds':(time.monotonic_ns()-started)/1e9,'all_866_copied_bytes_modes_unchanged':True,'complete_821_lean_file_set_unchanged':True,'no_remaining_fixture_descendants':True,'remaining_temporary_entries':[str(p) for p in TEMPS.iterdir()]}
write('summary.json',summary);print(json.dumps(summary,sort_keys=True),flush=True);raise SystemExit(returncode)
