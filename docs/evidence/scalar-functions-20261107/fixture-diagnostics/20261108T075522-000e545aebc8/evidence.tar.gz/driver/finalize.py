from pathlib import Path
import hashlib,json,re,shutil,stat,subprocess
review=Path(__file__).resolve().parents[1];case=review/'tmp/final-platform-fixture-298';results=case/'results';regression=review.parent/'scalar-functions-298';run_id='20261108T075522-000e545aebc8'
status=subprocess.run(['/usr/bin/python3','scripts/dev.py','runs','status'],cwd=regression,text=True,capture_output=True,check=True);(case/'postflight-status.json').write_text(status.stdout)
s=json.loads(status.stdout);run=next(r for r in s['runs'] if r['run_id']==run_id);assert not run['active']
directory=Path(run['directory']);events=[json.loads(l) for l in (directory/'events.jsonl').read_text().splitlines()];assert any(e['event']=='finished' for e in events)
for source,destination in [('events.jsonl','managed-events.jsonl'),('native.log','managed-native.log')]:shutil.copyfile(directory/source,results/destination)
expected=next(e for e in events if e['event']=='prepared')['inputs']['inputs_sha256'];actual={};differences=[]
for name,wanted in expected.items():
 try:
  with Path(name).open('rb') as f:got=hashlib.file_digest(f,'sha256').hexdigest()
 except OSError as exc:got={'error':type(exc).__name__,'message':str(exc)}
 actual[name]=got
 if got!=wanted:differences.append({'path':name,'expected':wanted,'actual':got})
post={'run_id':run_id,'files_checked':len(expected),'all_unchanged':not differences,'differences':differences,'actual_sha256':actual};(results/'postflight-managed-input-verification.json').write_text(json.dumps(post,indent=2,sort_keys=True)+'\n');assert not differences
source_differences=[]
for item in json.loads((case/'frozen-inputs/copy-inventory.json').read_text()):
 p=regression/item['path']
 with p.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 if digest!=item['sha256'] or stat.S_IMODE(p.stat().st_mode)!=item['mode']:source_differences.append(item['path'])
(results/'governed-source-postflight.json').write_text(json.dumps({'files_checked':866,'all_bytes_modes_match_final_fixture_inputs':not source_differences,'differences':source_differences},indent=2)+'\n');assert not source_differences
fixture=json.loads((results/'fixture-result.json').read_text());summary=json.loads((results/'summary.json').read_text());observer=[json.loads(l) for l in (results/'observer-events.jsonl').read_text().splitlines()];seen=[e for e in observer if e['event']=='process-first-seen'];nested=[e for e in seen if 'test_platforms.py PlatformIsolationTests -v' in e.get('cmdline','')];workers=[e for e in seen if 'test_platforms.py --setup-worker ' in e.get('cmdline','')];selected=nested+workers
aliases=[{'pid':e['pid'],'temporary_environment':e.get('temporary_environment'),'path':e.get('temporary_path_observation')} for e in selected]
identity={tuple(sorted(e.get('temporary_environment',{}).items())) for e in selected}
aliases_verified=bool(nested) and bool(workers) and len(identity)==1 and all(set(e.get('temporary_environment',{}))=={'TMPDIR','TMP','TEMP'} and len(set(e['temporary_environment'].values()))==1 and e.get('temporary_path_observation',{}).get('is_symlink') is True for e in selected)
actual_nested_lines=[]
for stream in sorted(results.glob('exception-*-*.bin')):
 for line in stream.read_bytes().decode(errors='replace').splitlines():
  if 'PlatformIsolationTests.test_' in line or line.startswith(('Ran ','FAILED','OK')):actual_nested_lines.append({'stream':stream.name,'line':line})
completion={'run_id':run_id,'fixture_result':fixture,'managed_outcome':run['state'],'managed_duration_seconds':run['duration_seconds'],'observer_summary':summary,'captured_managed_inputs_unchanged':not differences,'governed_866_bytes_modes_unchanged':not source_differences,'nested_processes_observed':len(nested),'setup_workers_observed':len(workers),'all_observed_nested_workers_used_same_symlink_alias':aliases_verified,'alias_observations':aliases,'actual_retained_nested_output_lines':actual_nested_lines,'minimum_sampled_available_gib':min(e['memavailable_kib'] for e in observer if e['event']=='process-sample')/1024**2,'owned_cleanup_signals':[e for e in observer if e['event']=='post-fixture-owned-descendant-cleanup']}
(results/'completion-review.json').write_text(json.dumps(completion,indent=2)+'\n')
print(json.dumps({k:v for k,v in completion.items() if k not in ['alias_observations','actual_retained_nested_output_lines']},indent=2));print(json.dumps({'actual_nested_lines':actual_nested_lines},indent=2))
