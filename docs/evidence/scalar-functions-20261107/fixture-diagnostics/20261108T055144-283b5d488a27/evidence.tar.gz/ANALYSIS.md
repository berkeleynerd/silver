# #298 initial-build-only observation

Managed run `20261108T055144-283b5d488a27` failed on its unchanged 60-second
initial-build deadline. The diagnostic driver returned 124; the managed Alire
wrapper returned 1; Lake was terminated with signal 9 during authorized timeout
cleanup. This was one initial-build observation, with no repeat, audit or edit
variants. The earlier successful configuration-only diagnostic is unchanged.

All 19 prepared source/configuration hashes matched the retained failed-fixture
inventory. The recreated workspace had no `.lake` directory before launch.
The command, source, one-thread setting, 2048 MiB module setting and warning
policy match the original initial build. Current inherited environment was
explicitly preserved before Alire; historical environment/scheduling is unknown.
Managed preflight found 20/22 workers reserved and 39.1 GiB available; this run
reserved one worker. All inputs remained byte-identical afterward.

Relative to the monotonic instant before Lake spawn:

| Phase | Observed time | Evidence |
| --- | ---: | --- |
| Configuration trace | 0.574 s | First sampled appearance; precedes elaboration |
| Configuration olean | 21.166 s | First sampled final path |
| Lexical process start | approximately 21.219 s | Kernel start tick, 10ms precision |
| CertificateWitness process start | approximately 32.049 s | Kernel start tick |
| Admission process start | approximately 43.569 s | Kernel start tick |
| Cursor process start | approximately 55.289 s | Kernel start tick |
| Deadline detected | 60.282 s | Configured deadline remains 60 s; observation adds polling overhead |
| Verified cleanup signals | 60.329 / 60.330 s | Only diagnostic Lake 602629 and Cursor 602805 |
| Cursor reaped | 62.285 s | Adopted by diagnostic subreaper after Lake exit |
| All diagnostic descendants gone | 62.389 s | Session/process inspection and exit confirmation |

Stdout reports successful Lexical, CertificateWitness and Admission builds in
10, 11 and 11 seconds respectively. The Cursor process was still active at
the deadline. Those three completed object families and partial Cursor setup
are preserved in `work/`, with input/artifact hashes in `results/`. Stderr only
reported new-manifest creation and the unchanged toolchain; no compiler error
was printed. Absence of an error does not establish the unfinished obligations.

| Process | Last sampled CPU seconds | Of which system | Peak sampled RSS |
| --- | ---: | ---: | ---: |
| Lake, including post-configuration build coordination | 22.36 | 5.27 | 862.6 MiB |
| Lexical | 9.59 | 4.15 | 466.9 MiB |
| CertificateWitness | 8.05 | 5.22 | 459.8 MiB |
| Admission | 8.65 | 5.13 | 460.0 MiB |
| Cursor, interrupted | 5.25 | 3.67 | 339.4 MiB |

The current trace demonstrates configuration followed by serial module-process
cost sufficient to exhaust the deadline before the original build completed.
It does not isolate every module's import, elaboration, serialization and process
startup costs. Sampled per-thread scheduler waits were only about 0.24--0.34 s
for the first three modules, with limits for transient threads and unsampled
final intervals. Storage-read counters were zero in their last readable I/O
samples; that observation is not a full filesystem or memory-stall profile.

The earlier failed fixture had a Lake sample at 32 seconds elapsed with 58.1%
lifetime-average CPU, then a defunct Lake at 61 seconds with 61.7%, and Lexical
at 10 seconds with 57.5%. Those averages differ from the configuration-only
observation's 21.15 sampled aggregate CPU seconds in 22.878 observed wall
seconds, but cannot isolate historical configuration CPU, I/O or scheduling.
No historical contention explanation is established.

Read-only comparison with previously successful real fixture
`20261106T145355-acbd4750fe92` / commit `524dbfbd40` found identical bytes for
all seven copied production modules, the test, lean-toolchain,
bootstrap_lean.py and platforms.py, and identical Lean/Lake executable hashes.
The lakefile, generator and check_lean.py differ; exact identities are retained
in `results/prior-success-comparison.json`. No full host, loaded-library,
ambient-environment or OS-cache equivalence is claimed.

The smallest prospective execution is one standalone profiling observation of
the unchanged CertificateWitness module, which has only three Lean meta imports
and no Silver imports in its retained setup. Pinned Lean's profiler measures
`import` and serialization. A scratch direct compile with only
`-Dprofiler=true -Dprofiler.threshold=0` added to the same -j1/-M2048 and
warningAsError settings, isolated output paths and the same 60-second deadline,
could distinguish import/startup/serialization from theorem work. This is a
specific unresolved performance question, not a correctness rerun. It has not
been launched and requires coordinator scheduling. There is no evidence here
supporting source/test/harness changes or a timeout increase.

The diagnostic signals affected only the fresh verified session tree. All its
descendants were reaped/exited and the worker lease released; shared status
returned to 20/22 reserved. Managed elapsed time was 94.409 seconds, including
runner preflight, setup, timeout cleanup and evidence collection. The original
whole fixture, axiom audit and all object-reuse/content/occurrence edit cases
still require successful completion. Selected reviewer model/effort remains
GPT-6 Astra / Extra High; independent runtime telemetry is unavailable.
