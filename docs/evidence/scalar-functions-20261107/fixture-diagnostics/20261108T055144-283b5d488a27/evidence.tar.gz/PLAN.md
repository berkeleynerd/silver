# #298 one instrumented initial-build-only observation

Coordinator authorized this exact next observation after configuration-only
run `20261108T054614-dc5613468a66`. Preserve that diagnostic and all evidence.
Use its identical frozen fixture/helper inputs and explicitly recorded inherited
environment in a new isolated work/results directory. Before Lake, recreate and
verify the same 19 prepared hashes and require missing .lake state.

Managed dev.py tool from the released regression context reserves one worker,
with explicit driver/frozen input declarations and work/results leases. Recheck
shared status and available memory. Exact Lake command after executable:

```
--rehash --reconfigure -K silverThreads=1 -K silverMemoryMb=2048 build
  +Silver.OutputBodyCertificate +Silver.Independent +Silver.AxiomAudit
```

Keep LEAN_NUM_THREADS=1, one managed worker and 60-second process deadline.
Retain streams, exact identities, monotonic times, child/module starts, process
CPU/I/O/schedstat/wait/RSS samples and configuration/artifact changes. Retain all
partial or completed objects after outcome. Stop before audit and edit variants.
No full fixture, repeated launch, changed source/test/harness/options or publish.

The observer enables Linux child-subreaping for its own future descendants. On
timeout it verifies each process's new session and start-tick identity before
signalling that process, then reaps only its adopted diagnostic descendants.
External native and Lean processes cannot match that new session. Stay active
until all diagnostic descendants exit. No signals are planned before timeout.

This measures the initial build with the documented current environment; the
historical inherited environment and kernel/page-cache state remain unknown.
Even success is not a passing whole fixture. Use the measured phase evidence to
select the smallest later check without attributing prior delays to contention.
