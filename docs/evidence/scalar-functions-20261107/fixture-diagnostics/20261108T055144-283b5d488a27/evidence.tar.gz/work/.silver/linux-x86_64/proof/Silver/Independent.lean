module
public theorem Silver.independent : True := True.intro
