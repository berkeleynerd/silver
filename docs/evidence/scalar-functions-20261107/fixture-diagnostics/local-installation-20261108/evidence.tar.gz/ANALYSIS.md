# #298 authenticated local-install comparison

Both authorized stages completed successfully and released their one-worker
leases. No further diagnostic or fixture run followed.

Bootstrap run `20261108T061828-f176c7d39979` used the unchanged Lean installer,
platform helper and pin in fresh root
`/tmp/silver-certificate-witness-local-298-20261108`. Mount checks verified the
writable container-root overlay and sufficient free disk/headroom. The cached
904,280,152-byte release ZIP matched pinned SHA256
3013aba02bb8bf31b1cf8c9d956d60fb95bb1c10920dfe91abcaa59cb461ddac before and after
copy. Bootstrap reported Lean 4.34.1, native x86_64-unknown-linux-gnu, commit
5045d0056413266e57c625dcd7c365b10e377c52. No download, live relocation, native
bootstrap or project proof-object copying was performed.

Complete original/local inventories matched all 18,381 entries: relative file
sets, SHA256 bytes, sizes, permission modes, directories and symlink targets.
All 15,127 lib/lean files also matched the retained profiler A input map. The
managed run finished successfully after 181.102 seconds including installation,
comparison and before/after input stability checks. All bootstrap descendants
exited. The local installation remains retained; existing installations and
archive were preserved.

Profile B `20261108T062237-55f39cc9f940` then ran exactly one fresh direct
CertificateWitness compile under the original 60-second deadline. Source,
setup, compiler arguments and environment match A after the documented path
normalization. The observer diff changes only its frozen-input location,
installation path and baseline-run identifier; no timing/monitor/cleanup or
proof-setting code changed. Source/output stayed on virtiofs as in profiler A;
only installed tools/libraries moved to overlay. Fresh project outputs were
rebuilt, with no cached project artifact copied.

| Measurement | A: virtiofs installation | B: overlay installation |
| --- | ---: | ---: |
| Observed command seconds | 9.604 | 4.836 |
| Exclusive import seconds | 6.870 | 2.910 |
| Last sampled user CPU seconds | 3.17 | 2.24 |
| Last sampled system CPU seconds | 5.17 | 1.90 |
| Peak sampled RSS MiB | 460.0 | 461.1 |
| Exclusive olean serialization seconds | 0.136 | 0.461 |

Thus B's observed command was 4.767 seconds shorter and its reported import
cost 3.960 seconds lower. Elaboration/type checking stayed small. Not every
component improved: serialization and several other categories rose. This is
one sequential observation, not a repeated/randomized benchmark or an exact
causal decomposition. Both runs' identity checks warmed caches; B also followed
extraction and a complete distribution comparison. Other jobs and scheduling
were not held fixed. Profiler regions do not attribute all startup/teardown.

All 4,966 sampled mapped-file identities matched A after normalizing only the
installation prefix, including 4,959 lib/lean files and the compiler itself.
All 4,960 mapped installation files resolved to the new installation; none
resolved to the old one. External mapped system-library identities matched too.
The managed B input map captured 17,751 regular distribution files among 17,795
inputs and passed its final byte-stability check. B's managed run lasted 49.534
seconds including preflight/postflight and retention, separate from compiler
time. No signal or timeout was needed, and all diagnostic descendants exited.
Postflight returned to 20/22 reserved workers.

This observation supports storage-related import overhead as a useful current
hypothesis. It does not establish the cause of historical failures. In
particular, the original failing fixture's temporary source/output workspace
was under /tmp; the profiling A/B workspaces deliberately both used virtiofs
to keep their own source/output storage constant. November6 successful-fixture
imported-artifact identities remain unestablished.

The next task is to assess one unchanged original fixture using this validated
local distribution in a separate test root, with exact copied source/helper
inputs, normal ROOT derivation and normal temporary workspace selection. No
existing tool selector or test assertion/deadline should change. The full cold
initial build still has 17 module inputs and forced configuration; a faster
single-module import is not evidence that this serial build fits 60 seconds.
The route and its remaining timing risk need coordinator review before any
fixture execution. Neither the initial build nor full fixture was rerun here.

All prior diagnostic bundles/drivers/results remain unchanged. Selected reviewer
setting is GPT-6 Astra / Extra High, with independent runtime telemetry
unavailable. No publication, live-install change or CLI memory update occurred.
