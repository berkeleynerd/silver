"""One authenticated isolated Lean bootstrap; refuse identity differences."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import time

CASE = Path(__file__).resolve().parents[1]
FROZEN = CASE / 'frozen-bootstrap'
RESULTS = CASE / 'bootstrap-results'
INSTALL = Path('/tmp/silver-certificate-witness-local-298-20261108')
REGRESSION = Path('/home/canto/src/github.com/berkeleynerd/silver/tmp/scalar-functions-298')
ORIGINAL = REGRESSION / '.tools/linux-x86_64/lean'
ARCHIVE = ORIGINAL.parent / 'lean-4.34.1-linux.zip'
EXPECTED = '3013aba02bb8bf31b1cf8c9d956d60fb95bb1c10920dfe91abcaa59cb461ddac'


def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def save(name, value):
    (RESULTS / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def phase(name, **extra):
    value = {'phase': name, 'monotonic_ns': time.monotonic_ns(), 'utc_ns': time.time_ns(), **extra}
    with (RESULTS / 'phases.jsonl').open('a') as f:
        f.write(json.dumps(value, sort_keys=True) + '\n')
    print(json.dumps(value, sort_keys=True), flush=True)


def mount_info(path):
    candidates = []
    for line in Path('/proc/self/mountinfo').read_text().splitlines():
        a, b = line.split(' - ', 1)
        aa, bb = a.split(), b.split()
        mount = Path(aa[4].replace('\\040', ' '))
        if path.resolve().is_relative_to(mount):
            candidates.append({'mount': str(mount), 'type': bb[0], 'source': bb[1],
                               'options': aa[5], 'mountinfo': line})
    return max(candidates, key=lambda x: len(x['mount']))


def inventory(root):
    result = {}
    for directory, dirs, files in os.walk(root, followlinks=False):
        for name in sorted(dirs + files):
            p = Path(directory) / name
            s = p.lstat()
            row = {'mode': stat.S_IMODE(s.st_mode)}
            if stat.S_ISLNK(s.st_mode):
                row.update(type='symlink', target=os.readlink(p))
                if not p.resolve().is_relative_to(root.resolve()):
                    raise RuntimeError(f'Escaping distribution symlink: {p}')
            elif stat.S_ISREG(s.st_mode):
                row.update(type='file', bytes=s.st_size, sha256=digest(p))
            elif stat.S_ISDIR(s.st_mode):
                row.update(type='directory')
            else:
                raise RuntimeError(f'Unexpected distribution entry: {p}')
            result[str(p.relative_to(root))] = row
    return result


assert not INSTALL.exists() and not INSTALL.is_symlink(), 'Refuse existing installation path'
assert not RESULTS.exists(), 'Refuse repeat bootstrap results'
mount = mount_info(INSTALL.parent)
assert mount['type'] == 'overlay' and mount['mount'] == '/'
assert 'noexec' not in mount['options'].split(',')
assert os.access(INSTALL.parent, os.W_OK)
fs = os.statvfs(INSTALL.parent)
assert fs.f_bavail * fs.f_frsize >= 6 * 1024**3
mem = Path('/proc/meminfo').read_text()
assert int(next(line.split()[1] for line in mem.splitlines() if line.startswith('MemAvailable'))) >= 12 * 1024**2
RESULTS.mkdir()
save('bootstrap-preflight.json', {'mount': mount, 'available_disk_bytes': fs.f_bavail * fs.f_frsize,
                                'meminfo': mem, 'loadavg': Path('/proc/loadavg').read_text(),
                                'install_absent': True, 'native_host': list(os.uname())})
try:
    phase('archive-authentication-start')
    assert ARCHIVE.is_file() and digest(ARCHIVE) == EXPECTED
    phase('archive-authentication-complete', sha256=EXPECTED)
    INSTALL.mkdir(mode=0o755)
    (INSTALL / 'scripts').mkdir()
    (INSTALL / 'proof').mkdir()
    tools = INSTALL / '.tools/linux-x86_64'
    tools.mkdir(parents=True)
    for name in ['bootstrap_lean.py', 'platforms.py']:
        shutil.copyfile(FROZEN / name, INSTALL / 'scripts' / name)
        assert digest(FROZEN / name) == digest(INSTALL / 'scripts' / name)
    shutil.copyfile(FROZEN / 'lean-toolchain', INSTALL / 'proof/lean-toolchain')
    copied_archive = tools / ARCHIVE.name
    shutil.copyfile(ARCHIVE, copied_archive)
    assert digest(copied_archive) == EXPECTED
    save('copied-inputs.json', {str(p.relative_to(INSTALL)): digest(p)
                              for p in [copied_archive, INSTALL / 'proof/lean-toolchain',
                                        INSTALL / 'scripts/bootstrap_lean.py', INSTALL / 'scripts/platforms.py']})
    phase('unchanged-bootstrap-start')
    command = ['/usr/bin/python3', '-B', str(INSTALL / 'scripts/bootstrap_lean.py')]
    with (RESULTS / 'bootstrap-stdout.bin').open('wb') as out, (RESULTS / 'bootstrap-stderr.bin').open('wb') as err:
        proc = subprocess.Popen(command, cwd=INSTALL, stdout=out, stderr=err, start_new_session=True)
        save('bootstrap-command.json', {'argv': command, 'cwd': str(INSTALL), 'pid': proc.pid,
                                       'session': proc.pid, 'start_monotonic_ns': time.monotonic_ns()})
        returncode = proc.wait()
    assert returncode == 0, f'bootstrap exit {returncode}'
    leftovers = []
    for p in Path('/proc').iterdir():
        if p.name.isdecimal():
            try:
                raw = (p / 'stat').read_text()
                fields = raw[raw.rfind(')') + 2:].split()
                if int(fields[3]) == proc.pid:
                    leftovers.append(int(p.name))
            except (OSError, ValueError):
                pass
    assert not leftovers, f'Unexpected bootstrap descendants: {leftovers}'
    local = tools / 'lean'
    assert local.is_dir() and not local.is_symlink()
    assert (local / '.silver-distribution-sha256').read_text().strip() == EXPECTED
    assert mount_info(local)['type'] == 'overlay'
    phase('unchanged-bootstrap-complete', returncode=returncode)
    phase('complete-distribution-comparison-start')
    original = inventory(ORIGINAL)
    fresh = inventory(local)
    save('original-distribution-inventory.json', original)
    save('local-distribution-inventory.json', fresh)
    only_a = sorted(set(original) - set(fresh))
    only_b = sorted(set(fresh) - set(original))
    changed = [n for n in sorted(set(original) & set(fresh)) if original[n] != fresh[n]]
    baseline_events = [json.loads(x) for x in (CASE / 'frozen-profile/baseline-profile-managed-events.jsonl').read_text().splitlines()]
    baseline = next(e for e in baseline_events if e['event'] == 'prepared')['inputs']['inputs_sha256']
    prefix = str(ORIGINAL) + '/'
    selected = {k[len(prefix):]: v for k, v in baseline.items() if k.startswith(prefix + 'lib/lean/')}
    mismatch_baseline = [n for n, sha in selected.items() if fresh.get(n, {}).get('sha256') != sha]
    assert len(selected) == 15127
    record = {'outcome': 'match' if not (only_a or only_b or changed or mismatch_baseline) else 'mismatch',
              'original_root': str(ORIGINAL), 'local_root': str(local),
              'archive_sha256': EXPECTED, 'original_entries': len(original), 'local_entries': len(fresh),
              'only_original': only_a, 'only_local': only_b, 'different_entries': changed,
              'baseline_profile_library_files': len(selected), 'baseline_profile_library_mismatches': mismatch_baseline,
              'source_and_output_relocation': 'Not performed by bootstrap; profiling workspace stays on original virtiofs class',
              'native_bootstrap_performed': False, 'project_proof_artifacts_copied': False,
              'no_remaining_bootstrap_descendants': True, 'no_signals': True}
    save('identity-comparison.json', record)
    phase('complete-distribution-comparison-finished', outcome=record['outcome'], entries=len(fresh))
    if record['outcome'] != 'match':
        raise RuntimeError('Distribution mismatch; standalone profile B must not run')
except BaseException as e:
    save('failure.json', {'type': type(e).__name__, 'message': str(e), 'monotonic_ns': time.monotonic_ns()})
    raise
