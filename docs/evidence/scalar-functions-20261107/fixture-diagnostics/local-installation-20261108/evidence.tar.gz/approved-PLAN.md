# #298 proposed matched storage/import comparison — not launched

## Question and fixed baseline

Does placing the unchanged pinned Lean distribution on the container-local
filesystem materially reduce the measured CertificateWitness import cost?
Baseline A is the retained, completed profiler run
`20261108T060219-fd618279bf6d`: 9.604s observed command, 6.870s exclusive import,
3.17s user and 5.17s system sampled CPU. Do not repeat A. B is exactly one fresh
standalone compile after a separate managed bootstrap/identity stage. This is
a diagnostic comparison, not a performance feature, fixture repair, acceptance
gate or passing full fixture.

## Read-only findings and applicable setup

`development.md:117-120` directs use of scripts/bootstrap_lean.py when tools
need installation and bootstrap/rebuild when an installation moves.
`docs/platform-coexistence.md` permits reuse of authenticated release archives
without changing old installations, keeps native host namespaces separate, and
requires native bootstrap/rebuild when the Silver compiler installation moves.
`scripts/bootstrap_lean.py` independently selects the native host, checks the
lean-toolchain pin, verifies the release ZIP SHA256, safely extracts to its own
staging directory, writes the distribution marker, and checks Lean --version.

Read-only mount and capacity observations are in `read-only-preflight.json`:

- Existing Lean installation: repository mount is virtiofs, source host.
- /tmp and /var/tmp: writable root overlay mount, distinct from virtiofs,
  without noexec; approximately 9.87 GB available when observed. Its full
  mountinfo is retained. This is the container-local writable layer; its
  underlying physical block device is not exposed by the observed namespace.
- /dev/shm: tmpfs, noexec, only approximately 64 MiB; unsuitable.

Select the new, currently absent root:
`/tmp/silver-certificate-witness-local-298-20261108`.
Re-read mount identity and free space before provisioning; require at least
6 GiB free and the same writable overlay (no noexec). No path has been created
there. This extends diagnostic ownership beyond the review worktree and needs
coordinator allocation before execution.

Existing authenticated archive, retained in place:
`<regression>/.tools/linux-x86_64/lean-4.34.1-linux.zip`.
Its expected SHA256 is
`3013aba02bb8bf31b1cf8c9d956d60fb95bb1c10920dfe91abcaa59cb461ddac`.
The read-only check verifies that digest against actual bytes. ZIP size is
904,280,152 bytes; 18,381 members expand to 3,290,453,049 bytes. A new copy plus
one staged installation needs about 4.20 GB, excluding small evidence files;
staging is renamed into the fresh destination, not duplicated. Preserve the
existing archive, all active installations and every existing proof object.

Native Alire/GNAT bootstrap is not applicable: no Silver native installation,
compiled Ada path binding or native proof workspace moves. The managed command
uses the regression worktree's already bootstrapped Alire context solely as
its existing tool entrypoint. Only a fresh Lean installation and this standalone
Lean module are provisioned/rebuilt. This distinction avoids modifying native
artifacts while following the applicable Lean bootstrap requirement.

## Concrete ownership and sequential managed commands

Use these exact path assignments in the proposed launcher (not executed):

```
REG=/home/canto/src/github.com/berkeleynerd/silver/tmp/scalar-functions-298
REVIEW=/home/canto/src/github.com/berkeleynerd/silver/tmp/scalar-functions-delivery-review-298
CASE=$REVIEW/tmp/lean-local-comparison-298
INSTALL=/tmp/silver-certificate-witness-local-298-20261108
```

Immutable reviewed drivers and frozen inputs will be prepared under CASE before
either command. The same shared regression context is leased by dev.py itself.
Both stages reserve exactly one managed worker and require fresh shared-status,
headroom and filesystem checks. No concurrent bootstrap/profile stage.

1. Managed bootstrap and identity stage, cwd REG:

```
python3 -B scripts/dev.py tool --jobs 1 --task '#298 final regression' \
  --reason 'Authorized isolated native Lean bootstrap and complete identity comparison for one storage/import diagnostic; preserve live installs' \
  --workspace "$INSTALL" --workspace "$CASE/bootstrap-results" \
  --input "$CASE/bootstrap-driver" --input "$CASE/frozen-bootstrap" \
  --input "$REG/.tools/linux-x86_64/lean-4.34.1-linux.zip" \
  --input "$REG/.tools/linux-x86_64/lean" \
  -- /usr/bin/python3 -B "$CASE/bootstrap-driver/provision.py"
```

The provisioner refuses any existing INSTALL, creates real directories (no
installation symlink), copies the unchanged bootstrap_lean.py and platforms.py
into INSTALL/scripts and the unchanged pin into INSTALL/proof/lean-toolchain,
and copies the authenticated ZIP into INSTALL/.tools/linux-x86_64/. It records
source/copy hashes, then executes exactly:

```
/usr/bin/python3 -B "$INSTALL/scripts/bootstrap_lean.py"
```

The copied unchanged helper derives ROOT from its own location, so native host
selection and all installation writes resolve inside INSTALL. No monkeypatch,
changed installer or fallback download is allowed. The archive must exist and
match before invoking bootstrap. Record the produced version, distribution
marker, executable selectors and resolved paths. Ensure all symlinks remain
inside the new distribution except none explicitly justified by the archive.

Create complete relative inventories for A and B: every regular file's SHA256,
size and executable mode plus every symlink's literal target; include all bin/
and lib/ artifacts, not just lean/lake executables, and record the expected
bootstrap marker. Compare complete file sets/identities and explicitly compare
B's lib/lean files against A's 15,127-file profiler input map. Any missing,
extra or mismatching distribution content stops the comparison before compiling.
No repair/retry, silent exclusion or live installation change follows a mismatch.
Retain managed input stability and both inventories. Native system libraries
outside the distribution are separately covered by actual loaded-file identity
capture during B, rather than claimed to be part of the ZIP.

2. Only after matching bootstrap/identity success, managed profile B, cwd REG:

```
python3 -B scripts/dev.py tool --jobs 1 --task '#298 final regression' \
  --reason 'One matched host-local Lean import profile against retained A060219; identical distribution/source/options, cache-warm identity preflight, no fixture pass claimed' \
  --workspace "$CASE/work" --workspace "$CASE/results" \
  --input "$CASE/profile-driver" --input "$CASE/frozen-profile" \
  --input "$CASE/bootstrap-results/identity-comparison.json" \
  --input "$INSTALL/.tools/linux-x86_64/lean" \
  -- /usr/bin/python3 -B "$CASE/profile-driver/observe.py"
```

The existing profiler observer is adapted only for the explicitly selected
installation and fresh owned paths, with its diff reviewed before launch.
The original source/setup, environment snapshot, profiler switches and monitors
remain fixed. Work and output stay under CASE on the same virtiofs filesystem
as A; only the large installed-tool/library input path changes to overlay. This
keeps source/output storage class constant and avoids adding relocation of
project proof artifacts to the comparison. CASE/work has its own HostLayout
and read-only Lean selector symlink to the new installation. No compiled project
artifact from A or any production run is copied.

Exact measured command, cwd CASE/work/.silver/linux-x86_64/proof:

```
$INSTALL/.tools/linux-x86_64/lean/bin/lean \
  -j1 -M2048 -DwarningAsError=true -Dprofiler=true -Dprofiler.threshold=0 \
  $CASE/work/.silver/linux-x86_64/proof/Silver/CertificateWitness.lean \
  -o $CASE/work/.silver/linux-x86_64/proof/.lake/build/lib/lean/Silver/CertificateWitness.olean \
  -i $CASE/work/.silver/linux-x86_64/proof/.lake/build/lib/lean/Silver/CertificateWitness.ilean \
  -c $CASE/work/.silver/linux-x86_64/proof/.lake/build/ir/Silver/CertificateWitness.c \
  --setup $CASE/work/CertificateWitness.setup.json --json
```

Both source and setup must match A byte-for-byte. Fresh output directories
must contain no objects. Environment starts from the same private pre-Alire
snapshot and unchanged lean_environment function; LEAN_NUM_THREADS remains 1.
Record each relocation in LEAN/LEAN_SYSROOT/LAKE/LAKE_HOME/PATH and workspace
LAKE_CONFIG/cache variables. LEAN_PATH selects the fresh workspace library
directory, exactly as Lake's compiler child did. The actual ELF executable and
sampled installed-library mappings must resolve to INSTALL, not A. Reject an
unexpected old-installation or unreviewed library override before interpreting
results; do not rewrite the inherited environment silently.

## Measurement, stopping and interpretation

Keep the same 60-second compiler deadline, streams, monotonic and kernel-start
timing, CPU/I/O/wait/schedstat/RSS and artifact sampling, exclusive profiler
categories, and verified new-session timeout cleanup/subreaping. On success
or timeout, retain all results and freshly rebuilt module artifacts, wait for
all descendants, release the lease, and stop. No retry or second B run. Do not
launch the initial build, audit/edit variants, whole fixture, full suite, or
modify source/test/harness/options/deadlines.

Managed B input hashing warms the new distribution before compilation, as A's
managed preflight warmed its lib/lean directory. Extraction and full-distribution
identity comparison add warmth too. Do not flush OS caches or disturb other
jobs; record this as an uncontrolled but explicit measurement difference.
Record current peer jobs/headroom, compare measured import and total/system CPU
costs with retained A, and distinguish one observed contrast from repeatable
causality. Stable bytes, current mounted-storage difference and a lower B cost
would support the storage hypothesis; they would not explain every historical
timeout or establish the old November6 imported-artifact identity. A failure
or unchanged result remains useful evidence, not permission for another run.

This task prepares only the plan. No new installation, bootstrap, version query,
compiler process, module rebuild or managed run has been launched for B.
