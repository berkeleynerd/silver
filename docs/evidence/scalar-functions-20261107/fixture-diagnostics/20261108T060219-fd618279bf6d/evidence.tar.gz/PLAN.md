# #298 one direct CertificateWitness profiling observation

Coordinator authorized exactly one direct compile after the retained initial
build timed out. Source is byte-identical CertificateWitness; the retained
setup JSON has no Silver import artifacts and is copied byte-for-byte. Use
fresh isolated outputs, original -j1/-M2048/warningAsError, original --json and
setup/output forms, adding only -Dprofiler=true -Dprofiler.threshold=0. Deadline
remains 60 seconds. No Lake invocation, full fixture, edit variants or repeat.

Pinned Lake/Build/Actions.compileLeanModule overrides only LEAN_PATH in its
compiler subprocess. Recreate that override on the explicitly saved pre-Alire
lean_environment with LEAN_NUM_THREADS=1 and relocated scratch paths. Preserve
prior diagnostic workspaces, drivers, results and archives unchanged.

Use managed regression dev.py tool, one worker, explicit work/results leases
and frozen-driver inputs plus compiler binaries and the installed lib/lean
input directory. The full installed Lean library directory is hashed in the
managed pre/post identity capture; this deliberately reads/warms file caches,
which limits wall-time comparison with prior unprofiled commands. Also retain
sampled mapped-file identities and compare shared files with the previous
initial-build diagnostic. The November6 successful fixture's imported standard
library artifact identities have not been established; matching compiler
binaries is not evidence of those identities.

Capture raw profiler streams, monotonic process and artifact timing, CPU/I/O/
wait/schedstat/RSS samples and post-run library identities. On timeout only,
verify and stop this newly created session tree, reaping adopted descendants.
Retain all outputs and stop. Interpret profiler-covered costs and unmeasured
startup/teardown separately; do not subtract cumulative nested timers as if
independent without checking their documented semantics.
