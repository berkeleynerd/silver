# #298 direct CertificateWitness profile

Managed native Linux run `20261108T060219-fd618279bf6d` succeeded. Exactly one
direct compiler process checked the unchanged CertificateWitness source with
its byte-identical retained setup, original -j1/-M2048/warningAsError settings,
output forms and --json, adding -Dprofiler=true -Dprofiler.threshold=0. Its
observed command duration was 9.604 seconds within the unchanged 60-second
deadline. No signal, repeat or descendant cleanup was needed. All owned
processes exited and the one-worker reservation was released.

Pinned Lake's Build/Actions.compileLeanModule overrides only LEAN_PATH when
spawning the compiler. This diagnostic reproduced that child environment from
the retained pre-Alire environment using the unchanged lean_environment helper,
with new scratch source/output paths. The original installation and prior two
diagnostic drivers, results and evidence archives were not changed.

The pinned profiler documents exclusive cumulative times. Its material entries:

| Component | Seconds |
| --- | ---: |
| Imports | 6.870 |
| Initialization | 0.240 |
| Olean serialization | 0.136 |
| Elaboration | 0.0469 |
| Type checking | 0.00236 |
| C generation | 0.0303 |

The complete category list and raw JSON/text streams remain in results. The
last sampled aggregate process CPU was 8.34 seconds (3.17 user, 5.17 system),
maximum sampled RSS 460.0 MiB, and sampled scheduler-wait counters totalled
0.147 seconds. No major page fault appeared in samples. The last profiler
stream chunk arrived at 7.895 seconds; startup, teardown and observation cost
are not all attributed by the profiler. Import work dominates this observed
module. Its theorem/elaborator body is not the dominant measured cost.

Artifact identity was checked separately from executable identity. Managed
preflight and final stability checking captured all 15,127 files in the
installed lib/lean directory, among 15,168 declared/input files; the successful
run confirms those bytes remained unchanged. This preflight deliberately reads
and warms library caches, limiting direct timing comparison with earlier
unprofiled commands. The 4,966 sampled mapped files, including 4,959 installed
standard-library files, all have identical SHA256 hashes to the preceding
initial-build diagnostic. There were no mismatches or newly unrecorded mapped
files. Sampling can omit files mapped only briefly. No imported-artifact hash
inventory has been established for the November6 successful fixture, so matching
Lean/Lake executable hashes does not imply that earlier library correspondence.

The resolved installed library path is on the repository's virtiofs mount,
source `host`, with rw,nosuid,nodev,relatime options. Thousands of imported
artifacts, measured import cost and substantial system CPU make filesystem
metadata/mapping overhead a concrete remaining hypothesis. This mount fact
does not establish causality. Current CPU scheduling, profiler overhead,
initialization details and unmeasured teardown remain relevant limits.

The coordinator reported at 06:03:38 that only PredicateNativeShapeCandidate
remained active in the complete Lean run, while native12 continued; about
43 GiB was available and 20 workers remained reserved. Those contemporaneous
resource facts do not explain earlier timing. Diagnostic preflight had shown
20/22 reserved and 47.3 GiB available; final shared status again showed 20/22.
Managed elapsed time was 128.499 seconds, including full-library identity
hashing before/after, setup and evidence capture, separate from compiler time.

The smallest justified next action is to prepare a controlled host-local Lean
installation comparison plan with identical authenticated tool/library/source
bytes and compilation settings, fresh managed output ownership, and explicit
cache/measurement limits. Follow platform-coexistence/bootstrap requirements;
keep the live installation and productive proof caches intact. One matched
host-local observation could test the filesystem hypothesis before modifying
any fixture or timeout. No such installation, run or plan execution occurred
in this bounded task. There is no evidence supporting a theorem rewrite or
fixture-timeout increase here. The original full fixture and its audit/edit
stages remain required and unresolved.

Selected reviewer configuration remains GPT-6 Astra / Extra High; independent
runtime telemetry is unavailable. No source/test/harness edits or publication
were performed. CLI memory was not updated.
