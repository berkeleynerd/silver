"""One isolated CertificateWitness profile, with unchanged 60-second deadline."""
import hashlib
import ctypes
import json
import os
from pathlib import Path
import selectors
import shutil
import signal
import subprocess
import sys
import time
from unittest import mock

BASE = Path(__file__).resolve().parents[1]
FROZEN, WORK, RESULTS = (BASE / n for n in ('frozen-inputs', 'work', 'results'))
REGRESSION = Path('/home/canto/src/github.com/berkeleynerd/silver/tmp/scalar-functions-298')
TOOLS = REGRESSION / '.tools/linux-x86_64/lean'
sys.path.insert(0, str(FROZEN))
from scripts import check_lean
from scripts.bootstrap_lean import lean_environment
from scripts.platforms import HostLayout, host_key


def digest(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def write(name, value):
    (RESULTS / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def read(p):
    try:
        return Path(p).read_text()
    except (OSError, UnicodeError) as e:
        return {'unavailable': type(e).__name__}


def ticks(pid):
    s = Path(f'/proc/{pid}/stat').read_text()
    a = s[s.rfind(')') + 2:].split()
    return {'pid': pid, 'state': a[0], 'ppid': int(a[1]), 'pgrp': int(a[2]),
            'sid': int(a[3]), 'minflt': int(a[7]), 'majflt': int(a[9]),
            'utime_ticks': int(a[11]), 'stime_ticks': int(a[12]),
            'start_ticks': int(a[19]), 'rss_pages': int(a[21])}


def members(sid):
    found = []
    for d in Path('/proc').iterdir():
        if d.name.isdecimal():
            try:
                s = ticks(int(d.name))
                if s['sid'] == sid:
                    found.append(s)
            except (OSError, ValueError, IndexError):
                pass
    return found


if WORK.exists() or RESULTS.exists():
    raise RuntimeError('Refuse repeat: diagnostic work or result directory already exists')
WORK.mkdir()
RESULTS.mkdir()
write('preparation-start.json', {'monotonic_ns': time.monotonic_ns(), 'utc_ns': time.time_ns()})
for name, expected in json.loads((FROZEN / 'snapshot-sha256.json').read_text()).items():
    assert digest(FROZEN / name) == expected, name
host = HostLayout(WORK, host_key())
assert host.key == 'linux-x86_64'
host.lean.parent.mkdir(parents=True)
host.lean.symlink_to(TOOLS, target_is_directory=True)
host.proof.mkdir(parents=True)
source = host.proof / 'Silver/CertificateWitness.lean'
source.parent.mkdir()
shutil.copyfile(FROZEN / 'proof/Silver/CertificateWitness.lean', source)
setup = WORK / 'CertificateWitness.setup.json'
shutil.copyfile(FROZEN / 'CertificateWitness.setup.json', setup)
lib = host.proof / '.lake/build/lib/lean/Silver'
ir = host.proof / '.lake/build/ir/Silver'
lib.mkdir(parents=True)
ir.mkdir(parents=True)
comparisons = [{'path': str(source.relative_to(WORK)), 'sha256': digest(source),
                'expected_sha256': digest(FROZEN / 'proof/Silver/CertificateWitness.lean'),
                'matches': digest(source) == digest(FROZEN / 'proof/Silver/CertificateWitness.lean')},
               {'path': str(setup.relative_to(WORK)), 'sha256': digest(setup),
                'expected_sha256': digest(FROZEN / 'CertificateWitness.setup.json'),
                'matches': digest(setup) == digest(FROZEN / 'CertificateWitness.setup.json')}]
write('prepared-input-comparison.json', comparisons)
assert all(x['matches'] for x in comparisons)
assert not list(lib.iterdir()) and not list(ir.iterdir())
before = {str(p.relative_to(WORK)): digest(p) for p in WORK.rglob('*') if p.is_file() and '.tools' not in p.parts}
write('input-before.json', before)
inherited = json.loads((FROZEN / 'private-inherited-environment.json').read_text())
env = {**lean_environment(host, inherited=inherited), 'LEAN_NUM_THREADS': '1',
       'LEAN_PATH': str(host.proof / '.lake/build/lib/lean')}
# Pinned Lake Build/Actions.compileLeanModule overrides only LEAN_PATH.
# This is a direct reproduction of that child environment, with relocated paths.
raw_names = {'PATH', 'TMPDIR', 'TMP', 'TEMP', 'LANG', 'LC_ALL', 'OMP_NUM_THREADS', 'MALLOC_ARENA_MAX'}
write('environment.json', {k: {'value': v} if k in raw_names or k.startswith(('LEAN', 'LAKE', 'ELAN'))
                           else {'sha256': hashlib.sha256(v.encode()).hexdigest(), 'value_recorded': False}
                           for k, v in sorted(env.items())})
command = [str(TOOLS / 'bin/lean'), '-j1', '-M2048', '-DwarningAsError=true',
           '-Dprofiler=true', '-Dprofiler.threshold=0', str(source),
           '-o', str(lib / 'CertificateWitness.olean'),
           '-i', str(lib / 'CertificateWitness.ilean'),
           '-c', str(ir / 'CertificateWitness.c'), '--setup', str(setup), '--json']
write('command.json', {'argv': command, 'cwd': str(host.proof), 'timeout_seconds': 60,
                      'configuration_only': False, 'direct_single_module_profile': True, 'history_environment_unrecorded': True,
                      'clock_ticks_per_second': os.sysconf('SC_CLK_TCK'),
                      'page_size': os.sysconf('SC_PAGE_SIZE'), 'uname': list(os.uname()),
                      'boot_id': read('/proc/sys/kernel/random/boot_id'),
                      'monotonic_ns': time.monotonic_ns(),
                      'boottime_ns': time.clock_gettime_ns(time.CLOCK_BOOTTIME)})
tool_paths = [TOOLS / 'bin/lake', TOOLS / 'bin/lean', Path('/usr/bin/python3')]
write('tool-identities.json', {str(p): {'resolved': str(p.resolve()), 'sha256': digest(p)} for p in tool_paths})
loaded_libraries = set()
seen, artifact_state = {}, {}
stream = (RESULTS / 'samples.jsonl').open('w')

def event(value):
    value.update(monotonic_ns=time.monotonic_ns(), boottime_ns=time.clock_gettime_ns(time.CLOCK_BOOTTIME))
    stream.write(json.dumps(value, sort_keys=True) + '\n')
    stream.flush()


def sample(sid):
    rows = members(sid)
    for s in rows:
        pid = s['pid']
        p = Path('/proc') / str(pid)
        identity = (pid, s['start_ticks'])
        if identity not in seen:
            seen[identity] = time.monotonic_ns()
            event({'event': 'process_first_seen', **s, 'cmdline': read(p / 'cmdline')})
        s['io'] = read(p / 'io')
        s['wchan'] = read(p / 'wchan')
        s['schedstat'] = read(p / 'schedstat')
        s['status'] = read(p / 'status')
        threads = {}
        try:
            for task in (p / 'task').iterdir():
                threads[task.name] = {'schedstat': read(task / 'schedstat'), 'wchan': read(task / 'wchan')}
        except OSError:
            pass
        s['threads'] = threads
        maps = read(p / 'maps')
        if isinstance(maps, str):
            for line in maps.splitlines():
                parts = line.split(maxsplit=5)
                if len(parts) == 6 and parts[5].startswith('/') and not parts[5].endswith(' (deleted)'):
                    loaded_libraries.add(parts[5])
    changes = []
    for p in (host.proof / '.lake').rglob('*'):
        if p.is_file():
            try:
                stat = p.stat()
            except FileNotFoundError:
                continue
            identity = (stat.st_size, stat.st_mtime_ns)
            key = str(p.relative_to(host.proof))
            if artifact_state.get(key) != identity:
                artifact_state[key] = identity
                changes.append({'path': key, 'bytes': stat.st_size, 'mtime_ns': stat.st_mtime_ns})
    event({'event': 'sample', 'processes': rows, 'artifact_changes': changes,
           'meminfo': read('/proc/meminfo'), 'loadavg': read('/proc/loadavg'),
           'pressure_cpu': read('/proc/pressure/cpu'), 'pressure_io': read('/proc/pressure/io'),
           'pressure_memory': read('/proc/pressure/memory')})
    return rows


# Adopt only our future orphaned descendants so timeout cleanup can reap them.
libc = ctypes.CDLL(None, use_errno=True)
if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER on this verified Linux host
    raise OSError(ctypes.get_errno(), 'cannot enable diagnostic child subreaping')
selector = selectors.DefaultSelector()
start = time.monotonic_ns()
process = subprocess.Popen(command, cwd=host.proof, env=env, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, start_new_session=True)
leader = ticks(process.pid)
assert leader['sid'] == process.pid and leader['pgrp'] == process.pid
write('launch.json', {'monotonic_before_popen_ns': start, 'monotonic_after_popen_ns': time.monotonic_ns(),
                      'leader': leader})
outputs = {}
for name, pipe in [('stdout', process.stdout), ('stderr', process.stderr)]:
    os.set_blocking(pipe.fileno(), False)
    selector.register(pipe, selectors.EVENT_READ, name)
    outputs[name] = (RESULTS / (name + '.bin')).open('wb')
next_sample = time.monotonic()
timed_out = False
cleanup_signalled = set()
while True:
    now = time.monotonic()
    if now >= next_sample:
        sample(process.pid)
        next_sample = now + 0.25
    if not timed_out and time.monotonic_ns() - start >= 60_000_000_000 and (process.poll() is None or members(process.pid)):
        timed_out = True
        event({'event': 'deadline', 'seconds': 60})
        # Only identities in the newly created diagnostic session are eligible.
        for row in members(process.pid):
            try:
                current = ticks(row['pid'])
                if current['sid'] == process.pid and current['start_ticks'] == row['start_ticks']:
                    os.kill(row['pid'], signal.SIGKILL)
                    cleanup_signalled.add((row['pid'], row['start_ticks']))
                    event({'event': 'timeout_cleanup_signal', 'pid': row['pid'],
                           'start_ticks': row['start_ticks'], 'sid': process.pid, 'signal': 'SIGKILL'})
            except (ProcessLookupError, FileNotFoundError):
                pass
    if timed_out:
        for row in members(process.pid):
            identity = (row['pid'], row['start_ticks'])
            if row['state'] != 'Z' and identity not in cleanup_signalled:
                try:
                    current = ticks(row['pid'])
                    if current['sid'] == process.pid and current['start_ticks'] == row['start_ticks']:
                        os.kill(row['pid'], signal.SIGKILL)
                        cleanup_signalled.add(identity)
                        event({'event': 'timeout_cleanup_signal', 'pid': row['pid'],
                               'start_ticks': row['start_ticks'], 'sid': process.pid, 'signal': 'SIGKILL'})
                except (ProcessLookupError, FileNotFoundError):
                    pass
            if row['pid'] != process.pid and row['ppid'] == os.getpid():
                try:
                    reaped, status = os.waitpid(row['pid'], os.WNOHANG)
                    if reaped:
                        event({'event': 'reaped_adopted_diagnostic_child', 'pid': reaped, 'wait_status': status})
                except ChildProcessError:
                    pass
    for key, _ in selector.select(timeout=max(0, min(0.05, next_sample - time.monotonic()))):
        data = os.read(key.fileobj.fileno(), 65536)
        if data:
            outputs[key.data].write(data)
            outputs[key.data].flush()
            event({'event': 'stream_chunk', 'stream': key.data, 'bytes': len(data)})
        else:
            selector.unregister(key.fileobj)
            key.fileobj.close()
    if process.poll() is not None and not selector.get_map():
        remaining = sample(process.pid)
        if not remaining:
            break
        # Do not report exit while a diagnostic descendant is still present.
        event({'event': 'waiting_for_diagnostic_descendants', 'pids': [r['pid'] for r in remaining]})
end = time.monotonic_ns()
for f in outputs.values():
    f.close()
stream.close()
assert not members(process.pid)
after = {name: digest(WORK / name) for name in before}
write('input-after.json', after)
assert before == after
write('artifact-inventory.json', {str(p.relative_to(WORK)): {'sha256': digest(p), 'bytes': p.stat().st_size}
                                 for p in WORK.rglob('*') if p.is_file() and '.tools' not in p.parts})
loaded_identities = {name: {'sha256': digest(name), 'bytes': Path(name).stat().st_size}
                     for name in sorted(loaded_libraries) if Path(name).is_file()}
write('loaded-file-identities.json', loaded_identities)
prior_identities = json.loads((FROZEN / 'prior-observed-file-identities.json').read_text())
common = sorted(set(prior_identities) & set(loaded_identities))
write('import-identity-comparison.json', {
    'prior_run': '20261108T055144-283b5d488a27',
    'current_sampled_mapped_files': len(loaded_identities),
    'common_files': len(common),
    'mismatches': [n for n in common if prior_identities[n]['sha256'] != loaded_identities[n]['sha256']],
    'not_captured_in_prior_run': [n for n in loaded_identities if n not in prior_identities],
    'current_standard_library_observed_files': sum(1 for n in loaded_identities if n.startswith(str(TOOLS / 'lib/lean') + '/')),
    'limits': ['Mapped files are sampled; rapidly unmapped files may be absent.',
               'Managed declared input also hashes the full installed lib/lean directory before and after this run.',
               'No contemporaneous imported-standard-library hash inventory is established for the November6 successful fixture.',
               'Preflight hashing warms file caches; profiler diagnostics are not a strict wall-time replay of the earlier module build.']})
summary = {'outcome': 'timeout' if timed_out else 'success' if process.returncode == 0 else 'failure',
           'returncode': process.returncode, 'command_elapsed_seconds': (end - start) / 1e9,
           'timed_out': timed_out, 'no_remaining_diagnostic_processes': True, 'child_subreaper_enabled': True,
           'prepared_files_matched': len(comparisons), 'inputs_unchanged': before == after,
           'configuration_marker': json.loads((RESULTS / 'loaded.json').read_text()) if (RESULTS / 'loaded.json').exists() else None,
           'not_a_fixture_pass': True, 'module_build_requested': True,
           'process_start_ticks_and_first_seen': [{'pid': p, 'start_ticks': t, 'first_seen_monotonic_ns': n}
                                                for (p, t), n in seen.items()]}
write('summary.json', summary)
print(json.dumps(summary, sort_keys=True), flush=True)
sys.exit(124 if timed_out else process.returncode)
