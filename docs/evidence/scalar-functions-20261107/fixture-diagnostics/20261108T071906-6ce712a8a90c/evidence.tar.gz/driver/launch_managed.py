from pathlib import Path
import hashlib,json,os,subprocess
case=Path(__file__).resolve().parents[1];regression=case.parents[2]/'scalar-functions-298'
first=case.parent/'local-watchdog-fixture-298'
retained=json.loads((first/'shareable-evidence.json').read_text())
assert hashlib.sha256((first/'shareable-evidence.tar.gz').read_bytes()).hexdigest()==retained['sha256']
complete=json.loads((first/'results/completion-review.json').read_text());assert complete['postflight_unchanged']
summary=json.loads((first/'results/summary.json').read_text());assert summary['no_remaining_fixture_descendants']
status=subprocess.run(['/usr/bin/python3','scripts/dev.py','runs','status'],cwd=regression,text=True,capture_output=True,check=True)
(case/'preflight-status.json').write_text(status.stdout);s=json.loads(status.stdout)
active=[{k:r.get(k) for k in ['run_id','workers','kind','worktree']} for r in s['runs'] if r['active']]
assert not any(r['run_id']=='20261108T065724-7d260468ca14' for r in active)
assert all(r['worktree']!=str(regression) for r in active)
assert s['reserved_workers']+4<=s['available_cpus']
mem=next(x for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:'));assert int(mem.split()[1])>12*1024*1024
for row in json.loads((case/'frozen-inputs/copy-inventory.json').read_text()):
 p=regression/row['path']
 with p.open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==row['sha256'],row['path']
 assert p.stat().st_mode&0o7777==row['mode'],row['path']
host={'uname':list(os.uname()),'memory':mem,'active_runs':active,'reserved_workers':s['reserved_workers'],'available_cpus':s['available_cpus'],'loadavg':Path('/proc/loadavg').read_text(),'tmp_mount':subprocess.run(['findmnt','-T','/tmp','-J'],text=True,capture_output=True,check=True).stdout,'regression_mount':subprocess.run(['findmnt','-T',str(regression),'-J'],text=True,capture_output=True,check=True).stdout,'all_866_governed_inputs_rechecked':True,'first_fixture_retained_sha256':retained['sha256']}
(case/'preflight-host.json').write_text(json.dumps(host,indent=2)+'\n')
cmd=['/usr/bin/python3','scripts/dev.py','tool','--task','#298 final regression','--reason','Authorized one unchanged symlink-TMPDIR fixture after retained final-input180s failure; exact866-file821Lean local source copy removes repeated virtiofs ROOT reads, original outer180/worker60/barrier15 and all12cases retained; four workers for actual host-concurrency case alongside native12 and serialclosure1, no retry','--jobs','4']
for p in ['/tmp/silver-platform-test-root-298-20261108','/tmp/silver-platform-test-temporaries-298-20261108',str(case/'results')]:cmd+=['--workspace',p]
for p in [case/'driver',case/'frozen-inputs']:cmd+=['--input',str(p)]
cmd+=['--','/usr/bin/python3','-B',str(case/'driver/run_fixture.py')]
(case/'managed-command.json').write_text(json.dumps({'cwd':str(regression),'argv':cmd},indent=2)+'\n')
print(json.dumps({'active':active,'reserved_workers':s['reserved_workers'],'available_cpus':s['available_cpus'],'memory':mem,'starting_one_unchanged_platform_fixture':True}),flush=True)
r=subprocess.run(cmd,cwd=regression);raise SystemExit(r.returncode)
