"""Execute one unchanged outer platform fixture; retain actual unittest errors."""
import hashlib,json,os,subprocess,sys,tempfile,time,traceback,unittest
from pathlib import Path
CASE=Path(__file__).resolve().parents[1];RESULTS=CASE/'results'
ROOT=Path('/tmp/silver-platform-test-root-298-20261108')
TEMPS=Path('/tmp/silver-platform-test-temporaries-298-20261108')
os.chdir(ROOT);sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
import test_platforms
from scripts import bootstrap,bootstrap_lean,check_lean,dev,platforms,run_history

def write(name,value):(RESULTS/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
modules={m.__name__:str(Path(m.__file__).resolve()) for m in [test_platforms,bootstrap,bootstrap_lean,check_lean,dev,platforms,run_history]}
assert all(Path(p).is_relative_to(ROOT) for p in modules.values())
assert all(m.ROOT==ROOT for m in [test_platforms,bootstrap,bootstrap_lean,check_lean,platforms])
assert check_lean.PROOF==ROOT/'proof';assert platforms.host_key()=='linux-x86_64'
assert Path(tempfile.gettempdir()).resolve()==TEMPS
assert all(os.environ[k]==str(TEMPS) for k in ['TMPDIR','TMP','TEMP'])
assert not (ROOT/'.tools').exists() and not (ROOT/'.silver').exists()
count=unittest.defaultTestLoader.loadTestsFromTestCase(test_platforms.PlatformIsolationTests).countTestCases();assert count==12
write('fixture-import-paths.json',{'modules':modules,'ROOT':str(ROOT),'PROOF':str(check_lean.PROOF),'host':platforms.host_key(),'TMPDIR':os.environ['TMPDIR'],'TMP':os.environ['TMP'],'TEMP':os.environ['TEMP'],'fixture_monkeypatched':False,'nested_class_discovered_count':count,'test_sha256':hashlib.sha256((ROOT/'tests/test_platforms.py').read_bytes()).hexdigest()})
class RecordingResult(unittest.TextTestResult):
 def __init__(self,*a,**kw):super().__init__(*a,**kw);self.observations=[];self.reporting_errors=[]
 def observe(self,test,label,err):
  try:
   exc=err[1];item={'label':label,'test_id':test.id(),'monotonic_ns':time.monotonic_ns(),'exception_type':type(exc).__name__,'exception':str(exc),'traceback':''.join(traceback.format_exception(*err))}
   if isinstance(exc,subprocess.TimeoutExpired):
    item.update(timeout_seconds=exc.timeout,command=exc.cmd)
    for key in ['stdout','stderr']:
     value=getattr(exc,key)
     if value is not None:
      data=value if isinstance(value,bytes) else value.encode();name=f'exception-{len(self.observations):02d}-{key}.bin';(RESULTS/name).write_bytes(data);item[key]={'file':name,'bytes':len(data),'original_type':type(value).__name__}
   self.observations.append(item);write('fixture-observations.json',self.observations)
  except Exception as exc:self.reporting_errors.append({'type':type(exc).__name__,'message':str(exc)});write('reporting-errors.json',self.reporting_errors)
 def startTest(self,test):write('fixture-start.json',{'test_id':test.id(),'monotonic_ns':time.monotonic_ns(),'utc_ns':time.time_ns()});super().startTest(test)
 def addError(self,test,err):self.observe(test,'error',err);super().addError(test,err)
 def addFailure(self,test,err):self.observe(test,'failure',err);super().addFailure(test,err)
identifier='test_platforms.InstallationEnvironmentTests.test_symlinked_tmpdir_preserves_platform_setup_and_routing'
suite=unittest.defaultTestLoader.loadTestsFromName(identifier);assert suite.countTestCases()==1
start=time.monotonic_ns();result=unittest.TextTestRunner(stream=sys.stdout,verbosity=2,resultclass=RecordingResult).run(suite)
summary={'test_id':identifier,'tests_run':result.testsRun,'errors':len(result.errors),'failures':len(result.failures),'skips':len(result.skipped),'passed':result.wasSuccessful() and result.testsRun==1 and not result.skipped,'duration_seconds':(time.monotonic_ns()-start)/1e9,'reporting_errors':result.reporting_errors,'source_assertions_deadlines_and_cleanup_unchanged':True,'nested_class_discovered_count':count,'nested_stdout_on_success':'Original method captures internally; this collector does not replace its subprocess call or fabricate nested outcomes.'}
write('fixture-result.json',summary);print(json.dumps(summary,sort_keys=True),flush=True)
raise SystemExit(0 if summary['passed'] and not result.reporting_errors else 1)
