module

public import Silver.ComposeDeclarations
public import Silver.ComposeSubtypeChecks
public import Silver.ComposeArrayChecks
public import Silver.ComposeBooleanArrayHeaderChecks
public import Silver.StringObligations

@[expose] public section

/-! The raw String initializer projection retains Image arithmetic schemas
alongside the proved frozen execution model. Its source witness fixes all
Image operands, including their actual visibility and arithmetic syntax. -/
namespace Silver.Compose
open Bindings

set_option maxHeartbeats 1000000

inductive DeclarationChecksAt (text : Source) (arguments : Bool) (state : ParserState)
    (declaration : Declaration) : List Integer.Obligation → Prop
  | string {raw result} :
      (characterDeclarationAt text state arguments).position = 0 →
      ExpressionAt text state.names (declarationValuePosition text state) raw result state.scalarNames
        (declarationIntegerHidden text state) state.arrayNames.names state.arrayNames.values true →
      declaration.initializer = raw.freezeImages
        (frozenIntegers state.scalarNames state.arrayNames.names state.arrayNames.values) →
      DeclarationChecksAt text arguments state declaration
        (raw.imageObligations (ArrayBindings.integerRanges state.arrayNames.names state.arrayNames.values true
          (ScalarExpression.ranges state.scalarNames)) state.names.shape)
  | character {raw result} :
      (characterDeclarationAt text state arguments).position ≠ 0 →
      CharacterAt text state.names state.scalarNames state.arrayNames.names state.arrayNames.values true
        (fixedAfter text (characterDeclarationParts text state).typeAfter ":=" false) raw result →
      declaration.initializer = Expression.freezeImages [Value.character raw]
        (frozenIntegers state.scalarNames state.arrayNames.names state.arrayNames.values) →
      DeclarationChecksAt text arguments state declaration
        (Expression.imageObligations [Value.character raw]
          (ArrayBindings.integerRanges state.arrayNames.names state.arrayNames.values true
            (ScalarExpression.ranges state.scalarNames)) state.names.shape)

theorem declaration_image_trace {text : Source} {arguments : Bool} {state next : ParserState}
    {declaration : Declaration} (parsed : DeclarationAt text arguments state declaration next) :
    ∃ checks, DeclarationChecksAt text arguments state declaration checks := by
  cases parsed with
  | string noCharacter source =>
      cases source with
      | declaration _ _ _ _ _ _ _ _ value => exact ⟨_, .string noCharacter value rfl⟩
  | character source =>
      have positive : (characterDeclarationAt text state arguments).position ≠ 0 := by
        rw [character_declaration_complete source]
        exact character_declaration_positive source
      cases source with
      | declaration parts _ _ value =>
          exact ⟨_, .character positive (by simpa only [parts] using value) rfl⟩

theorem declaration_image_checks {text : Source} {arguments : Bool} {state : ParserState}
    {declaration : Declaration} {checks : List Integer.Obligation}
    (normal : NamesNormal state.names)
    (trace : DeclarationChecksAt text arguments state declaration checks) : Integer.discharged checks = true := by
  cases trace with
  | string _ parsed _ => exact Expression.image_obligations_discharge (expressionAt_inferLength normal parsed)
  | character _ parsed _ => exact Expression.image_obligations_discharge (characterExpression_inferLength normal parsed)

theorem declaration_image_unique {text : Source} {arguments : Bool} {state : ParserState}
    {declaration : Declaration} {first second : List Integer.Obligation}
    (left : DeclarationChecksAt text arguments state declaration first)
    (right : DeclarationChecksAt text arguments state declaration second) : first = second := by
  cases left with
  | string absent parsed _ =>
      cases right with
      | string _ other _ => rw [(expressionTail_unique parsed other).1]
      | character present _ _ => exact False.elim (present absent)
  | character present parsed _ =>
      cases right with
      | string absent _ _ => exact False.elim (present absent)
      | character _ other _ => rw [(character_unique parsed other).1]

/-- The scalar projection may freeze array reads, but its complete raw
initializer stays in the obligation trace, including arithmetic and indexing. -/
def ScalarDeclarationChecksAt (text : Source) (state : ParserState) (declaration : Integer.Declaration)
    (checks : List Integer.Obligation) : Prop :=
  ∃ raw result,
    ScalarExpression.At text state.scalarNames (scalarDeclarationValuePosition text state) raw result
      (arrays := state.arrayNames.names) (initials := state.arrayNames.values) (elaborating := true) ∧
    declaration.value = raw.freezeArrays
      (frozenIntegers state.scalarNames state.arrayNames.names state.arrayNames.values) ∧
    checks = raw.obligations (ArrayBindings.integerRanges state.arrayNames.names state.arrayNames.values true
      (ScalarExpression.ranges state.scalarNames))

theorem scalar_declaration_checks_trace {text arguments state next declaration}
    (parsed : ScalarDeclarationAt text arguments state declaration next) :
    ∃ checks, ScalarDeclarationChecksAt text state declaration checks := by
  cases parsed with
  | declaration _ _ _ reading => exact ⟨_, _, _, reading, rfl, rfl⟩

theorem scalar_declaration_checks_discharge {text state declaration checks}
    (trace : ScalarDeclarationChecksAt text state declaration checks) : Integer.discharged checks = true := by
  obtain ⟨raw, result, parsed, _, rfl⟩ := trace
  exact Integer.Expr.obligations_discharge parsed.inferred

theorem scalar_declaration_checks_unique {text state declaration first second}
    (left : ScalarDeclarationChecksAt text state declaration first)
    (right : ScalarDeclarationChecksAt text state declaration second) : first = second := by
  obtain ⟨raw, result, parsed, _, rfl⟩ := left
  obtain ⟨other, otherResult, otherParsed, _, rfl⟩ := right
  rw [(ScalarExpression.at_unique parsed otherParsed).1]

inductive InitializerChecksAt (text : Source) (arguments : Bool) :
    ParserState → List Integer.Obligation → ParserState → Prop
  | done {state : ParserState} : state.position ≠ 0 →
      fixedAfter text state.position "begin" true ≠ 0 → InitializerChecksAt text arguments state [] state
  | function {state final : ParserState} {rest : List Integer.Obligation}  :
      state.position ≠ 0 → fixedAfter text state.position "begin" true = 0 →
      (functionDeclarationAt text state arguments).position ≠ 0 →
      InitializerChecksAt text arguments (functionDeclarationAt text state arguments) rest final →
      InitializerChecksAt text arguments state rest final
  | string {state middle final : ParserState} {declaration : Declaration}
      {checks rest : List Integer.Obligation} :
      state.position ≠ 0 → fixedAfter text state.position "begin" true = 0 →
      (functionDeclarationAt text state arguments).position = 0 →
      (subtypeDeclarationAt text state arguments).position = 0 →
      (scalarDeclarationAt text state arguments).position = 0 →
      (arrayDeclarationAt text state arguments).position = 0 →
      (booleanDeclarationAt text state arguments).position = 0 →
      DeclarationAt text arguments state declaration middle →
      DeclarationChecksAt text arguments state declaration checks →
      InitializerChecksAt text arguments middle rest final →
      InitializerChecksAt text arguments state (checks ++ rest) final
  | scalar {state middle final : ParserState} {declaration : Integer.Declaration}
      {checks rest : List Integer.Obligation} :
      state.position ≠ 0 → fixedAfter text state.position "begin" true = 0 →
      (functionDeclarationAt text state arguments).position = 0 →
      (subtypeDeclarationAt text state arguments).position = 0 →
      ScalarDeclarationAt text arguments state declaration middle →
      ScalarDeclarationChecksAt text state declaration checks →
      InitializerChecksAt text arguments middle rest final →
      InitializerChecksAt text arguments state (checks ++ rest) final
  | array {state middle final : ParserState} {declaration : Integer.ArrayDeclaration}
      {checks rest : List Integer.Obligation} :
      state.position ≠ 0 → fixedAfter text state.position "begin" true = 0 →
      (functionDeclarationAt text state arguments).position = 0 →
      (subtypeDeclarationAt text state arguments).position = 0 →
      (scalarDeclarationAt text state arguments).position = 0 →
      ArrayDeclarationAt text arguments state declaration middle →
      ArrayDeclarationChecksAt text state declaration checks →
      InitializerChecksAt text arguments middle rest final →
      InitializerChecksAt text arguments state (checks ++ rest) final

  | booleanArray {state middle final : ParserState}
      {checks rest : List Integer.Obligation} :
      state.position ≠ 0 → fixedAfter text state.position "begin" true = 0 →
      (functionDeclarationAt text state arguments).position = 0 →
      (subtypeDeclarationAt text state arguments).position = 0 →
      (scalarDeclarationAt text state arguments).position = 0 →
      BooleanArrayDeclarationAt text arguments state middle →
      BooleanArrayHeaderChecksAt text state checks →
      InitializerChecksAt text arguments middle rest final →
      InitializerChecksAt text arguments state (checks ++ rest) final

  | subtype {state middle final : ParserState} {checks rest : List Integer.Obligation} :
      state.position ≠ 0 → fixedAfter text state.position "begin" true = 0 →
      (functionDeclarationAt text state arguments).position = 0 →
      SubtypeDeclarationAt text arguments state middle →
      SubtypeDeclarationChecksAt text state checks →
      InitializerChecksAt text arguments middle rest final →
      InitializerChecksAt text arguments state (checks ++ rest) final

  | boolean {state middle final : ParserState} {rest : List Integer.Obligation} :
      state.position ≠ 0 → fixedAfter text state.position "begin" true = 0 →
      (functionDeclarationAt text state arguments).position = 0 →
      (subtypeDeclarationAt text state arguments).position = 0 →
      (scalarDeclarationAt text state arguments).position = 0 →
      (arrayDeclarationAt text state arguments).position = 0 →
      BooleanDeclarationAt text arguments state middle →
      InitializerChecksAt text arguments middle rest final →
      InitializerChecksAt text arguments state rest final

theorem declarations_image_trace {text : Source} {arguments : Bool} {state final : ParserState}
    {declarations : List Declaration} (parsed : DeclarationsAt text arguments state declarations final) :
    ∃ checks, InitializerChecksAt text arguments state checks final := by
  induction parsed with
  | done positive stop => exact ⟨[], .done positive stop⟩
  | next positive more noFunction noSubtype noScalar noArray noBoolean first rest ih =>
      obtain ⟨checks, trace⟩ := declaration_image_trace first
      obtain ⟨remaining, following⟩ := ih
      exact ⟨checks ++ remaining, .string positive more noFunction noSubtype noScalar noArray noBoolean first trace following⟩
  | scalar positive more noFunction noSubtype first rest ih =>
      obtain ⟨checks, trace⟩ := scalar_declaration_checks_trace first
      obtain ⟨remaining, following⟩ := ih
      exact ⟨checks ++ remaining, .scalar positive more noFunction noSubtype first trace following⟩
  | array positive more noFunction noSubtype noScalar first rest ih =>
      obtain ⟨checks, trace⟩ := array_declaration_checks_trace first
      obtain ⟨remaining, following⟩ := ih
      exact ⟨checks ++ remaining, .array positive more noFunction noSubtype noScalar first trace following⟩
  | booleanArray positive more noFunction noSubtype noScalar first rest ih =>
      obtain ⟨checks, trace⟩ := boolean_array_header_checks_trace first
      obtain ⟨remaining, following⟩ := ih
      exact ⟨checks ++ remaining, .booleanArray positive more noFunction noSubtype noScalar first trace following⟩
  | subtype positive more noFunction first rest ih =>
      obtain ⟨checks, trace⟩ := subtype_declaration_checks_trace first
      obtain ⟨remaining, following⟩ := ih
      exact ⟨checks ++ remaining, .subtype positive more noFunction first trace following⟩

  | boolean positive more noFunction noSubtype noScalar noArray first rest ih =>
      obtain ⟨remaining, following⟩ := ih
      exact ⟨remaining, .boolean positive more noFunction noSubtype noScalar noArray first following⟩

  | function positive more accepted _ ih =>
      obtain ⟨checks, reading⟩ := ih
      exact ⟨checks, .function positive more accepted reading⟩

theorem initializer_checks_discharge {text : Source} {arguments : Bool} {state final : ParserState}
    {checks : List Integer.Obligation} (normal : NamesNormal state.names)
    (trace : InitializerChecksAt text arguments state checks final)
    (subtypes : IntegerSubtypes.ValidEnvironment text state.subtypeNames) :
    Integer.discharged checks = true := by
  induction trace with
  | done => rfl
  | string _ _ _ _ _ _ _ declaration checks _ ih =>
      rw [Integer.discharged_append, declaration_image_checks normal checks,
        ih (declaration_normal normal declaration) (by
          cases declaration with
          | string _ source => cases source; exact subtypes
          | character source => cases source; exact subtypes)]
      rfl
  | scalar _ _ _ _ declaration checks _ ih =>
      rw [Integer.discharged_append, scalar_declaration_checks_discharge checks]
      cases declaration
      simpa only [Bool.true_and] using ih normal subtypes
  | array _ _ _ _ _ declaration checks _ ih =>
      rw [Integer.discharged_append, array_declaration_checks_discharge declaration checks subtypes]
      rw [(array_declaration_preserves declaration).1, array_declaration_subtypes declaration] at ih
      simpa only [Bool.true_and] using ih normal subtypes
  | booleanArray _ _ _ _ _ declaration checks _ ih =>
      rw [Integer.discharged_append, boolean_array_header_checks_discharge checks]
      rw [(boolean_array_declaration_preserves declaration).1, (boolean_array_declaration_preserves declaration).2.2.2] at ih
      simpa only [Bool.true_and] using ih normal subtypes
  | subtype _ _ _ declaration checks _ ih =>
      rw [Integer.discharged_append, subtype_declaration_checks_discharge checks]
      have nextSubtypes := subtype_declaration_valid declaration subtypes
      cases declaration
      simpa only [Bool.true_and] using ih normal nextSubtypes

  | boolean _ _ _ _ _ _ declaration _ ih =>
      cases declaration
      exact ih normal subtypes

  | function _ _ accepted _ ih =>
      have kept := functionDeclarationAt_preserves_outer _ _ _ accepted
      apply ih (kept.names.symm ▸ normal)
      simpa only [IntegerSubtypes.ValidEnvironment, kept.subtypeItems] using subtypes

theorem initializer_checks_valid {text : Source} {arguments : Bool} {state final : ParserState}
    {checks : List Integer.Obligation} (normal : NamesNormal state.names)
    (trace : InitializerChecksAt text arguments state checks final)
    (subtypes : IntegerSubtypes.ValidEnvironment text state.subtypeNames) :
    ∀ check ∈ checks, check.Valid := by
  have all := List.all_eq_true.mp (initializer_checks_discharge normal trace subtypes)
  exact fun check member => Integer.Obligation.discharge_sound (all check member)

theorem initializer_trace_unique {text : Source} {arguments : Bool} {state leftState rightState : ParserState}
    {left right : List Integer.Obligation} (first : InitializerChecksAt text arguments state left leftState)
    (second : InitializerChecksAt text arguments state right rightState) : left = right ∧ leftState = rightState := by
  induction first generalizing right rightState with
  | done positive stop =>
      cases second with
      | done => exact ⟨rfl, rfl⟩
      | function _ more _ _ => exact False.elim (stop more)
      | string _ more _ _ _ _ _ _ _ _ | scalar _ more _ _ _ _ _ | array _ more _ _ _ _ _ _ | booleanArray _ more _ _ _ _ _ _ | subtype _ more _ _ _ _ | boolean _ more _ _ _ _ _ _ => exact False.elim (stop more)
  | string positive more noFunction noSubtype noScalar noArray noBoolean parsed checks rest ih =>
      cases second with
      | done _ stop => exact False.elim (stop more)
      | function _ _ accepted _ => exact False.elim (accepted noFunction)
      | string _ _ _ _ _ _ _ other otherChecks remaining =>
          obtain ⟨rfl, rfl⟩ := declaration_unique parsed other
          have same := declaration_image_unique checks otherChecks
          obtain ⟨rfl, rfl⟩ := ih remaining
          exact ⟨congrArg (fun initial => initial ++ _) same, rfl⟩
      | scalar _ _ _ _ other _ _ =>
          have accepted := scalar_declaration_positive other
          rw [← scalar_declaration_complete other, noScalar] at accepted
          contradiction
      | array _ _ _ _ _ other _ _ =>
          have accepted := array_declaration_positive other
          rw [← array_declaration_complete other, noArray] at accepted
          contradiction
      | booleanArray _ _ _ _ _ other _ _ =>
          have accepted := boolean_array_declaration_positive other
          rw [← boolean_array_declaration_complete other, noArray] at accepted
          contradiction
      | boolean _ _ _ _ _ _ other _ =>
          have accepted := boolean_declaration_positive other
          rw [← boolean_declaration_complete other, noBoolean] at accepted
          contradiction
      | subtype _ _ _ other _ _ =>
          have accepted := subtype_declaration_positive other
          rw [← subtype_declaration_complete other, noSubtype] at accepted
          contradiction

  | scalar positive more noFunction noSubtype parsed checks rest ih =>
      cases second with
      | done _ stop => exact False.elim (stop more)
      | function _ _ accepted _ => exact False.elim (accepted noFunction)
      | string _ _ _ _ noScalar _ _ _ _ _ | array _ _ _ _ noScalar _ _ _ | booleanArray _ _ _ _ noScalar _ _ _ | boolean _ _ _ _ noScalar _ _ _ =>
          have accepted := scalar_declaration_positive parsed
          rw [← scalar_declaration_complete parsed, noScalar] at accepted
          contradiction
      | scalar _ _ _ _ other otherChecks remaining =>
          obtain ⟨rfl, rfl⟩ := scalar_declaration_unique parsed other
          have same := scalar_declaration_checks_unique checks otherChecks
          obtain ⟨rfl, rfl⟩ := ih remaining
          exact ⟨congrArg (fun initial => initial ++ _) same, rfl⟩
      | subtype _ _ _ other _ _ =>
          have accepted := subtype_declaration_positive other
          rw [← subtype_declaration_complete other, noSubtype] at accepted
          contradiction

  | array positive more noFunction noSubtype noScalar parsed checks rest ih =>
      cases second with
      | done _ stop => exact False.elim (stop more)
      | function _ _ accepted _ => exact False.elim (accepted noFunction)
      | string _ _ _ _ _ noArray _ _ _ _ | boolean _ _ _ _ _ noArray _ _ =>
          have accepted := array_declaration_positive parsed
          rw [← array_declaration_complete parsed, noArray] at accepted
          contradiction
      | scalar _ _ _ _ other _ _ =>
          have accepted := scalar_declaration_positive other
          rw [← scalar_declaration_complete other, noScalar] at accepted
          contradiction
      | array _ _ _ _ _ other otherChecks remaining =>
          obtain ⟨rfl, rfl⟩ := array_declaration_unique parsed other
          have same := array_declaration_checks_unique checks otherChecks
          obtain ⟨rfl, rfl⟩ := ih remaining
          exact ⟨congrArg (fun initial => initial ++ _) same, rfl⟩

      | subtype _ _ _ other _ _ =>
          have accepted := subtype_declaration_positive other
          rw [← subtype_declaration_complete other, noSubtype] at accepted
          contradiction

      | booleanArray _ _ _ _ _ other _ _ => exact False.elim (array_declaration_kinds_disjoint parsed other)
  | booleanArray positive more noFunction noSubtype noScalar parsed checks rest ih =>
      cases second with
      | done _ stop => exact False.elim (stop more)
      | function _ _ accepted _ => exact False.elim (accepted noFunction)
      | string _ _ _ _ _ noArray _ _ _ _ | boolean _ _ _ _ _ noArray _ _ =>
          have accepted := boolean_array_declaration_positive parsed
          rw [← boolean_array_declaration_complete parsed, noArray] at accepted
          contradiction
      | scalar _ _ _ _ other _ _ =>
          have accepted := scalar_declaration_positive other
          rw [← scalar_declaration_complete other, noScalar] at accepted
          contradiction
      | booleanArray _ _ _ _ _ other otherChecks remaining =>
          have sameState := boolean_array_declaration_unique parsed other
          cases sameState
          have same := boolean_array_header_checks_unique checks otherChecks
          obtain ⟨rfl, rfl⟩ := ih remaining
          exact ⟨congrArg (fun initial => initial ++ _) same, rfl⟩

      | subtype _ _ _ other _ _ =>
          have accepted := subtype_declaration_positive other
          rw [← subtype_declaration_complete other, noSubtype] at accepted
          contradiction

      | array _ _ _ _ _ other _ _ => exact False.elim (array_declaration_kinds_disjoint other parsed)
  | subtype positive more noFunction parsed checks rest ih =>
      cases second with
      | done _ stop => exact False.elim (stop more)
      | function _ _ accepted _ => exact False.elim (accepted noFunction)
      | string _ _ _ noSubtype _ _ _ _ _ _ | scalar _ _ _ noSubtype _ _ _ | array _ _ _ noSubtype _ _ _ _ | booleanArray _ _ _ noSubtype _ _ _ _ | boolean _ _ _ noSubtype _ _ _ _ =>
          have accepted := subtype_declaration_positive parsed
          rw [← subtype_declaration_complete parsed, noSubtype] at accepted
          contradiction
      | subtype _ _ _ other otherChecks remaining =>
          have same := subtype_declaration_unique parsed other
          cases same
          have sameChecks := subtype_declaration_checks_unique checks otherChecks
          obtain ⟨rfl, rfl⟩ := ih remaining
          exact ⟨congrArg (fun initial => initial ++ _) sameChecks, rfl⟩

  | boolean positive more noFunction noSubtype noScalar noArray parsed rest ih =>
      cases second with
      | done _ stop => exact False.elim (stop more)
      | function _ _ accepted _ => exact False.elim (accepted noFunction)
      | string _ _ _ _ _ _ noBoolean _ _ _ =>
          have accepted := boolean_declaration_positive parsed
          rw [← boolean_declaration_complete parsed, noBoolean] at accepted
          contradiction
      | scalar _ _ _ _ other _ _ =>
          have accepted := scalar_declaration_positive other
          rw [← scalar_declaration_complete other, noScalar] at accepted
          contradiction
      | array _ _ _ _ _ other _ _ =>
          have accepted := array_declaration_positive other
          rw [← array_declaration_complete other, noArray] at accepted
          contradiction
      | booleanArray _ _ _ _ _ other _ _ =>
          have accepted := boolean_array_declaration_positive other
          rw [← boolean_array_declaration_complete other, noArray] at accepted
          contradiction
      | subtype _ _ _ other _ _ =>
          have accepted := subtype_declaration_positive other
          rw [← subtype_declaration_complete other, noSubtype] at accepted
          contradiction
      | boolean _ _ _ _ _ _ other remaining =>
          have same := boolean_declaration_unique parsed other
          cases same
          exact ih remaining

  | function positive more accepted rest ih =>
      cases second with
      | done _ stop => exact False.elim (stop more)
      | function _ _ _ remaining => exact ih remaining
      | string _ _ noFunction _ _ _ _ _ _ _
        | scalar _ _ noFunction _ _ _ _
        | array _ _ noFunction _ _ _ _ _
        | booleanArray _ _ noFunction _ _ _ _ _
        | subtype _ _ noFunction _ _ _
        | boolean _ _ noFunction _ _ _ _ _ =>
          exact False.elim (accepted noFunction)

end Silver.Compose
