# #298 symlink-TMPDIR fixture — read-only route assessment

Prepared 2026-11-08 while the separately authorized chunk-reuse fixture runs.
No platform test, helper, proof or watchdog was edited, no second fixture was
executed, and no proposed local platform root or installation was created.

## Finding

The outer 180 seconds is an inherited subprocess watchdog, not an elapsed-time
assertion or a documented platform-routing performance contract. It was added
as 60 seconds in `8b8619f3ad53895dbad2e8e14e767fa5e51de628`, then raised to 180
in `3fdda42dc1b058b54dc7c6c83054af85a2d6f574`, both on 2026-10-08.
`watchdog-provenance.json` retains the exact line history. The latter commit
introduced literal-output support and split source certificates; its description
contains validation results but no specific explanation of the 180-second value.
There were 18 tracked Lean files at introduction, 33 when 180 was adopted, 741 at
the earlier failed full suite, and 821 at current governed target `47fe4003c0`
(counts include lakefile.lean).

The selected method creates physical/alias temporary directories and runs the
complete 12-method `PlatformIsolationTests` class under inherited symlinked
TMPDIR/TMP/TEMP. Its success criterion is the nested process's zero exit status;
all nested assertions remain required. Worker invocations have separate existing
60-second deadlines; concurrent setup has its existing 15-second rendezvous
watchdog. No Oracle or production proof timeout is involved. Changing only the
outer watchdog would change the allowed suite duration without changing routing
acceptance, but a new numeric budget needs a concrete scope rationale and must
not hide an inner worker timeout.

## Retained evidence and limits

The complete run `20261108T021923-5ef7f9b81de7` failed this outer method at 180
seconds and subsequently passed all 12 direct PlatformIsolationTests methods.
The final-input follow-up `20261108T064731-9f1ab6dc731c` also failed the unchanged
outer 180-second deadline (one error, zero skips; unittest 180.644 seconds,
managed 187.347 seconds). Its packet proves all 1,100 governed inputs and all
821 Lean files matched `47fe4003c0` before and after, and records no remaining
child. The standard traceback did not retain TimeoutExpired's partial nested
stdout/stderr. These outcomes remain failed.

The coordinator separately observed the nested suite around 104 seconds in
four concurrent setup workers, each about 36 seconds old. That is a sampled
phase observation, not an exact case duration or causal attribution.
The complete-run log has no per-test timestamps: an embedded simulated managed
run ID gives 03:51:44 during the third direct class method and another gives
03:55:30 in a later provenance module. The 226-second gap includes the tail of
the class and intervening tests, excludes the first two class tests, and belongs
to the earlier 741-file snapshot. It cannot establish this class's full duration
or justify a precise replacement deadline. The relevant exact log excerpt and
its source hash are retained in `earlier-fullsuite-platform-excerpt.json`.

## Why local source placement is a distinct, smaller next experiment

Each of the 12 nested methods calls PlatformIsolationTests.setUp, which copies
all production `proof/**/*.lean` files from ROOT into a fresh temporary project,
as well as project configuration and certificate-bound source. Its destination
already resides on the root overlay through /tmp. ROOT and the helper/test
installation currently reside on virtiofs. Thus the class repeats at least
12 x 821 Lean-file source copies, including source-side enumeration/metadata
operations; moving only TMPDIR would not change that source-side work.

An unchanged local test root would put these repeatedly read source/helper
inputs on the overlay too. No production input would be removed or replaced.
This is a directly identifiable storage path difference and a concrete reason
for one changed-location experiment, without guessing an outer deadline.
The earlier CertificateWitness local-library comparison supports storage
sensitivity in this environment but does not measure Python copying or prove
this fixture's cause.

Much of the nested work already occurs on overlay: mock setup prepares each
host workspace, runs the real Python source-certificate generator, hashes and
snapshots files, and checks routing/evidence. There are 15 setup-worker launches
in the complete class, including one four-host concurrent group, with 30
certificate roots per successful generation cycle. The mocked proof-failure
variants still require the original behavior and checks. Source placement may
therefore be insufficient; there is no promise that the unchanged 180-second
outer deadline will fit. If it does not, captured nested streams and phase
observations should identify what remains before selecting a timeout adjustment.

## Concrete route for coordinator review — not executed

Use fresh owned paths, proposed:

- `/tmp/silver-platform-test-root-298-20261108` for the source/test root.
- `/tmp/silver-platform-test-temporaries-298-20261108` for exclusive temporary
  workspace ownership on the same existing root overlay.
- A new review scratch/results directory separate from all retained runs.

Copy the exact files listed in `proposed-input-inventory.json`: test_platforms.py,
all nine scripts/*.py helpers, all 821 Lean sources, proof/lean-toolchain,
proof/generate_source_certificate.py, proof/silver_proof_containers.gpr,
alire.toml, silver.gpr, and all 30 distinct source files named by CERTIFICATE_ROOTS.
The 866 files total 54,490,005 bytes. Every listed byte was compared with current
original-regression inputs and Git snapshot `47fe4003c0`; no selected input includes the separate approved
Lean-module-test watchdog change. Preserve bytes and modes, retain inventory,
and check the complete Lean file set before/after. This matches the files the
original selected class actually copies; no source/module reduction is proposed.

Do not copy `.tools`, `.silver`, `.lake`, native executables, compiled project
objects or prior fixture outputs. All foreign/native Alire and Lean effects in
this test are its existing mocks; real Python and its source-certificate
generator remain actual execution. No installation bootstrap or Lean selector
is necessary for this platform-only route.

Use a fresh Python process with cwd at the copied ROOT and normal __file__-
derived test/platforms/check_lean paths. Before running, verify all imported
project helpers resolve inside that root, expected ROOT/PROOF values, native
host identity and copied bytes. Do not externally monkeypatch ROOT, subprocess,
unittest methods, deadlines, assertions, concurrency or cleanup. The fixture's
existing internal mocks remain unchanged.

Run exactly
`test_platforms.InstallationEnvironmentTests.test_symlinked_tmpdir_preserves_platform_setup_and_routing`
through a reporting-only unittest result collector. Use the current pre-tool
inherited environment (the original dev.py test passes it through), recording
it privately and comparing relevant settings with the retained launch context.
Make only the explicit scoped TMPDIR/TMP/TEMP change needed for the fresh owned
temporary root. The original method must still create its own physical/alias
pair and overwrite all three variables with its alias for the nested class.
Verify that alias and all four nested workers still use the original routing
logic. Do not turn the alias into a physical path in the environment.

Preserve the original 180-second outer limit, every 60-second worker limit,
15-second concurrency barrier, mocked tool policy, real generators, complete
12-case nested class and all assertions. Reporting-only addError can retain
actual TimeoutExpired stdout/stderr before original cleanup; its output must
not be reconstructed from process samples. On success, the original zero-exit
assertion establishes completion of the unchanged nested class; sampled child
commands and final root inventories supplement that result rather than replace
it. If further success-stream capture is desired, specify and review that
reporting mechanism without replacing the original subprocess call.

Use the original regression managed runner, with explicit workspaces for copied
root, scoped temporary root and results, and explicit frozen-input/driver
identities. Do not run dev.py from the non-Git copy and create a different shared
ledger. Reserve four workers for the actual four-host concurrency case rather
than silently inheriting the earlier two-worker reservation; the reservation is
not an OS cap. Start only after the current one-worker chunk fixture releases
its regression context and fresh shared status/headroom permit native12 +
serial closure1 + platform4 (17 of 22 workers). Review actual current reservations
instead of treating this arithmetic as a reservation grant.

Retain one actual result, all errors/skips, partial streams if failure, process
observations, complete source/input postflight and exact managed outcome. Clean
up only verified descendants of the completed owned process session if required.
No automatic repeat or timeout increase follows failure. Keep full project
assurance and the native macOS validation claim separate: this is a Linux test
of mocked cross-host routing.

## Disposition

Recommend coordinator review of the unchanged local-source route first. It
changes an identified repeated I/O path while retaining all temporal and
correctness checks. The evidence also establishes that a later outer-watchdog
repair would be a test-policy change rather than an Oracle amendment, but it
does not yet establish the smallest sufficient numeric budget. No second run,
new watchdog patch, implementation or publication is authorized by this
assessment itself.
