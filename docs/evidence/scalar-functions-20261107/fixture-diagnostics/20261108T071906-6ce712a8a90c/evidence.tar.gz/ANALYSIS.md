# #298 unchanged platform fixture from local source storage — failed

Native Linux managed run `20261108T071906-6ce712a8a90c` finished failed: one
outer test, one TimeoutExpired error, zero failures/skips and no reporting
errors. The unchanged nested PlatformIsolationTests invocation exceeded its
original 180-second watchdog. Unittest elapsed was 181.156 seconds, observation/
cleanup/postcheck 186.468 seconds, and managed elapsed 204.808 seconds. No repeat
or timeout adjustment followed. Earlier failed runs and the separate successful
chunk-reuse fixture remain unchanged.

The coordinator approved exactly one unchanged run from fresh local source and
temporary roots after successful chunk-fixture retention. All 866 required files
(54,490,005 bytes), including the complete 821-file Lean set, nine helpers and
thirty certificate-bound sources, matched `47fe4003c0` before execution, including
actual source modes. The selected platform test did not include the separate
Lean-module watchdog patch. No binaries, installations, live selectors or project
objects were moved or copied. Original foreign/native tool mocks and real Python
generators remained unchanged. This run tests mocked host routing on Linux; it
is not native macOS or project proof validation.

The copied root used ordinary __file__/ROOT/PROOF derivation. Imports and all
copied identities were checked. The original pre-tool environment had no
TMPDIR/TMP/TEMP; the approved scoped override set all three to the fresh owned
overlay temporary root. The method then created its original physical/alias pair
and set all three variables to that alias for the nested suite. Actual process
observations verified the nested suite and all seven observed setup workers
used the same live symlink alias. It was not replaced with its resolved physical
path in their environment. Outer180, worker60, concurrency-barrier15, the complete
12-case nested class, every assertion, internal mock and original cleanup stayed
unchanged. The result collector did not replace the subprocess call or methods.

The reporting-only collector preserved the actual TimeoutExpired streams:
999 bytes stderr and 701 bytes stdout. Partial stderr records, in order:

- cached-build-log/fresh-audit case: `ok`;
- concurrent-different-host-setups case: `ERROR`;
- development-command routing case: `ok`;
- development-output-overrides case: `ok`;
- each-host-setup case began, with its linux-aarch64 subtest: `ERROR`.

No completed outcome for the fifth whole method or the remaining seven methods
is claimed. The nested suite was killed before its final error-summary traceback
section, so the inner exception types/messages are unavailable. The original
outer traceback establishes its 180-second timeout; the two nested ERROR labels
do not by themselves identify their causes.

One-second process observations record the first setup worker spanning about
44.9 observed seconds, the four concurrent workers spanning about 59.1-60.2,
and the first sequential each-host worker about 58.8. A next linux-x86_64 worker
was first seen just before outer failure. These sampled spans are consistent
with the existing inner watchdogs but do not establish exact child exit times
or exception identity. `results/worker-chronology.json` retains start/last/first-
absent observations. No CPU scheduling or storage root cause is inferred.

The last surviving linux-x86_64 setup worker (PID632189, verified session and
start identity) was killed only after the original fixture process had completed;
its reaping was recorded. This was owned-descendant cleanup, not a changed
execution deadline or signal during the running fixture. No descendant remains,
original cleanup emptied the scoped temporary directory, and the four-worker
lease was released. Minimum sampled available RAM was 42.673 GiB. Preflight
reserved native12 plus closure1; this fixture added4 workers. The coordinator
subsequently ran a separate one-worker read-only source-policy check. Reservations
are reported as observed, not as proof of absent scheduling effects.

All 866 copied file bytes/modes and the full 821-file Lean set were unchanged.
An explicit postflight rehashed all 884 captured managed inputs, necessary because
the failed managed command skips its normal success-path final check. A separate
comparison also rechecked all 866 original governed-source bytes/modes against
the frozen `47fe4003c0` inventory, with no differences. Actual managed events/log,
exception streams, original unittest output, root/import/environment checks and
process observations are retained. Shareable packaging excludes the private
complete inherited environment and verifies all included member identities.

Local source placement alone was insufficient. Increasing only the outer limit
cannot be assumed to repair the already observed nested errors. The next unresolved
question is their exact exception/traceback, which the interrupted suite could not
print. A separately authorized focused diagnostic of one unchanged failing nested
method could expose that error before choosing a narrowly justified repair.
No such diagnostic, new watchdog proposal, automatic retry or additional execution
was performed here. Both complete platform-fixture success and the coordinator's
separate mandatory project assurance remain outstanding.

Selected reviewer setting remains GPT-6 Astra / Extra High with independent
runtime telemetry unavailable. No publication, merge or CLI memory update occurred.
