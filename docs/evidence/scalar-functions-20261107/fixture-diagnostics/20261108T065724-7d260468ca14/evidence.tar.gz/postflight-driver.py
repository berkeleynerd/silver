from pathlib import Path
import hashlib,json,shutil,subprocess,time
review=Path(__file__).resolve().parents[1]
case=review/'tmp/local-watchdog-fixture-298';results=case/'results'
regression=review.parent/'scalar-functions-298'
run_id='20261108T065724-7d260468ca14'
status=subprocess.run(['/usr/bin/python3','scripts/dev.py','runs','status'],cwd=regression,text=True,capture_output=True,check=True)
(case/'postflight-status.json').write_text(status.stdout)
s=json.loads(status.stdout);run=next(r for r in s['runs'] if r['run_id']==run_id)
assert not run['active'], 'Do not finalize an active run'
run_dir=Path(run['directory']);events=[json.loads(line) for line in (run_dir/'events.jsonl').read_text().splitlines()]
assert any(e['event']=='finished' for e in events)
for name,destination in [('events.jsonl','managed-events.jsonl'),('native.log','managed-native.log')]:shutil.copyfile(run_dir/name,results/destination)
prepared=next(e for e in events if e['event']=='prepared');expected=prepared['inputs']['inputs_sha256']
actual={};differences=[]
for name,wanted in expected.items():
    try:
        with Path(name).open('rb') as stream:got=hashlib.file_digest(stream,'sha256').hexdigest()
    except OSError as exc:got={'error':type(exc).__name__,'message':str(exc)}
    actual[name]=got
    if got!=wanted:differences.append({'path':name,'expected':wanted,'actual':got})
postflight={'run_id':run_id,'files_checked':len(expected),'all_unchanged':not differences,'differences':differences,'actual_sha256':actual}
(results/'postflight-managed-input-verification.json').write_text(json.dumps(postflight,indent=2,sort_keys=True)+'\n')
assert not differences
fixture=json.loads((results/'fixture-result.json').read_text());observations=json.loads((results/'fixture-observations.json').read_text())
obs_events=[json.loads(line) for line in (results/'observer-events.jsonl').read_text().splitlines()]
first_seen=[e for e in obs_events if e['event']=='process-first-seen']
builds=[e for e in first_seen if '/bin/lake --rehash ' in e['cmdline']]
audits=[e for e in first_seen if '/bin/lake env ' in e['cmdline'] and 'output-body-audit.lean' in e['cmdline']]
stdout=(results/'unittest-stdout.bin').read_text();printed=[]
if 'OUTPUT_BODY_CONTENT_REUSE ' in stdout:printed=json.JSONDecoder().raw_decode(stdout.split('OUTPUT_BODY_CONTENT_REUSE ',1)[1])[0]
expected_variants=['replace','append','insert','delete_unique','reorder','repeat','delete_repeated_occurrence','crlf','remove_final_newline','add_empty_line','empty_source']
completion={'run_id':run_id,'fixture_result':fixture,'observed_build_processes':len(builds),'observed_audit_invocations':len(audits),'expected_successful_path_builds':25,'expected_successful_path_audits':12,'printed_edit_labels':[o['edit'] for o in printed],'all_11_edit_observations':len(observations)==11 and all(o['label']=='subtest-success' for o in observations),'all_11_printed_edits':[o['edit'] for o in printed]==expected_variants,'reporting_errors':fixture['reporting_errors'],'initial_19_inputs_match':all(x['matches'] for x in json.loads((results/'original-prepared-fixture-comparison.json').read_text())),'minimum_sampled_available_gib':min(e['memavailable_kib'] for e in obs_events if e['event']=='process-sample')/1024**2,'managed_outcome':run['state'],'managed_duration_seconds':run['duration_seconds'],'postflight_unchanged':not differences}
(results/'completion-review.json').write_text(json.dumps(completion,indent=2)+'\n')
(results/'printed-edit-observations.json').write_text(json.dumps(printed,indent=2)+'\n')
print(json.dumps(completion,indent=2))
