from pathlib import Path
import json,os,subprocess
case=Path(__file__).resolve().parents[1]
regression=case.parents[2]/'scalar-functions-298'
status=subprocess.run(['/usr/bin/python3','scripts/dev.py','runs','status'],cwd=regression,text=True,capture_output=True,check=True)
(case/'preflight-status.json').write_text(status.stdout)
s=json.loads(status.stdout)
active=[{k:r.get(k) for k in ['run_id','workers','kind','worktree']} for r in s['runs'] if r['active']]
mem=next(x for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:'))
host={'uname':list(os.uname()),'memory':mem,'active_runs':active,'reserved_workers':s['reserved_workers'],'available_cpus':s['available_cpus'],'loadavg':Path('/proc/loadavg').read_text(),'tmp_mount':subprocess.run(['findmnt','-T','/tmp','-J'],text=True,capture_output=True,check=True).stdout,'regression_mount':subprocess.run(['findmnt','-T',str(regression),'-J'],text=True,capture_output=True,check=True).stdout}
(case/'preflight-host.json').write_text(json.dumps(host,indent=2)+'\n')
assert s['reserved_workers']+1<=s['available_cpus']
assert int(mem.split()[1])>12*1024*1024
assert all(r['worktree']!=str(regression) for r in active)
cmd=['/usr/bin/python3','scripts/dev.py','tool','--task','#298 final regression','--reason','Authorized exact fixture-only watchdog repair 6b62dafb43 after retained diagnostics; one complete cold fixture using authenticated local tools and fresh roots, build180/default-audits60, all11variants/proofsettings/assertions preserved; one worker alongside native12 and serialclosure1, no retry','--jobs','1']
for p in ['/tmp/silver-lean-watchdog-root-298-20261108','/tmp/silver-lean-watchdog-temporaries-298-20261108',str(case/'results')]:cmd+=['--workspace',p]
for p in [case/'driver',case/'frozen-inputs',Path('/tmp/silver-certificate-witness-local-298-20261108/.tools/linux-x86_64/lean')]:cmd+=['--input',str(p)]
cmd+=['--','/usr/bin/python3','-B',str(case/'driver/run_fixture.py')]
(case/'managed-command.json').write_text(json.dumps({'cwd':str(regression),'argv':cmd},indent=2)+'\n')
print(json.dumps({'active':active,'reserved_workers':s['reserved_workers'],'available_cpus':s['available_cpus'],'memory':mem,'starting_one_fixture':True}),flush=True)
r=subprocess.run(cmd,cwd=regression)
raise SystemExit(r.returncode)
