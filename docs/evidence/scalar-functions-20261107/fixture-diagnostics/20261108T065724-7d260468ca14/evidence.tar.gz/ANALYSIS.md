# #298 complete chunk-reuse fixture with scoped watchdog — passed

Native Linux managed run `20261108T065724-7d260468ca14` completed successfully:
one test, eleven successful edit subtests, zero errors/failures/skips and no
reporting errors. Unittest elapsed was 1,079.914 seconds; outer observation and
identity verification took 1,100.613 seconds; complete managed elapsed was
1,141.938 seconds. The original whole-suite and earlier unchanged-method runs
remain failed. This result covers the one repaired fixture, not the separate
platform fixture or whole-project proof/audit assurance.

The coordinator authorized the exact reviewed patch, implemented alone in
`tests/test_lean_modules.py` as `6b62dafb43e48556e7631190751cf0c5b39446c1`
(and integrated by the coordinator as `d41d721064`). The test SHA256 is
`e1b5c2212a7f5b0c3d9cca93224237d5eb26e5064cc8e5573e60f958fb724c5c`.
Only this method's local build helper selects a 180-second subprocess watchdog;
the class default and every fresh audit retain 60 seconds. All source generation,
proof options, kernel checks, warning-as-error, one-thread/worker, 2048 MiB,
assertions and cleanup remain unchanged. No profiler or method/subprocess
monkeypatch was used.

The complete path executed its cold 17-module initial build, fresh audit,
no-op identity checks, expected restored-timestamp stale-certificate rejection,
and all eleven content/occurrence edits with fresh audits and reset builds.
The process observer independently recorded all 25 Lake build invocations and
12 fresh audit invocations. Each original affected/retained object assertion
ran, including all three olean artifact families, generated-source identities,
Independent preservation and audit chunk coverage. The original test printed
all eleven structured edit observations; those and reporting-only subtest
snapshots are retained verbatim and as parsed JSON.

Precision correction to the earlier proposed-budget assessment: this fixed
empty-source variant changes seven buckets (0,1,2,3,5,6,7), retaining bucket4.
Its reset correspondingly rebuilds those populated buckets. The earlier phrase
that broad cases could rebuild all eight overstated this fixture's actual
content distribution. The implementation comment says only "broad edit rebuilds"
and remains correct. The initial cold build includes all eight chunks; none was
removed, and the original exact reuse assertions passed. The change is still
scoped to build calls because both initial and broad rebuild work need the
larger watchdog; this result establishes no general performance bound.

Fresh owned roots were used, with no project object copied and no existing
selector changed. Normal __file__/ROOT/PROOF derivation and helper import paths
were checked. The approved scoped TMPDIR remained on the existing root overlay.
Nine helpers, seven proofs, lakefile/pin/generator matched both the prior failed
fixture and governed source `47fe4003c0`; only the approved test differed. All
19 prepared initial workspace hashes matched the retained original setup.

Complete 18,381-entry authenticated Lean distribution identity matched before
and after. Copied inputs stayed unchanged. The successful managed wrapper
completed its normal postflight; an additional explicit check rehashed all
17,793 captured managed inputs with no drift. Minimum sampled available RAM
was 42.705 GiB. This is a resource observation, not a causal explanation of
historical timing. No timeout or signal was needed. Every owned descendant
exited, original cleanup emptied the scoped temporary root, and the one-worker
lease was released before any subsequent fixture was launched.

`results/completion-review.json`, `fixture-result.json`, original stdout/stderr,
printed edit records, callback observations, process samples, copied/distribution
checks, explicit managed postflight and full managed log/events retain the
actual result. The drivers/frozen inputs and approved exact patch are retained
separately from earlier failed bundles. Shareable packaging excludes the private
inherited environment; all public artifact members are hash-verified.

Selected reviewer setting remains GPT-6 Astra / Extra High; independent runtime
telemetry is unavailable. No publication, merge or CLI memory update occurred.
The next authorized action is exactly one unchanged platform fixture via its
separately reviewed local-source-root route, after this outcome is retained.
