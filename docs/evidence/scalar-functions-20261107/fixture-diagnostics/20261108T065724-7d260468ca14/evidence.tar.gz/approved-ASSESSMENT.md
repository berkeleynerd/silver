# #298 fixture watchdog assessment — proposal only

Prepared 2026-11-08 for the delivery coordinator, against review HEAD
`a24145af843c1aa8f53f690799c79df7841bdc53`. This is the authorized read-only
assessment and unapplied repair proposal. No actual source/test/harness was
edited, no timeout-adjusted fixture was executed, and no run was repeated.
Historical failures remain failures. Selected reviewer setting is GPT-6 Astra /
Extra High; independent runtime telemetry is unavailable.

## Finding and recommendation

The inherited 60-second limit is a per-subprocess test watchdog. The inspected
code and governing documents do not establish a 60-second compilation performance
contract. A narrowly scoped 180-second watchdog for this fixture's local build
helper is justified as the next bounded repair candidate. Keep the class helper's
default and this fixture's fresh audits at 60 seconds. Apply the larger budget to
all of this method's builds, because broad edit/reset cases can rebuild all eight
chunks, not just the initial cold build.

This changes the time allowed before a build is reported as an execution error.
It does not change the fixture's correctness assertions or proof acceptance.
A build that completes between 60 and 180 seconds can then reach the same checks;
it cannot pass merely by taking longer. Timeout, nonzero unexpected build status,
missing artifacts and failed audit/assertions remain failures. The proposed 180
seconds is an engineering watchdog budget with related-test precedent, not an
observed or guaranteed completion bound. Full duration is still unmeasured.

## Provenance and purpose

`tests/test_lean_modules.py:55-58` has retained the literal `timeout=60` since
`15ca622139564b55e5e15f95b2e97a763e72ed9d` (2026-10-12), "Adopt Lean module
boundaries for fast proof edits." The original tests built small Provider,
Consumer and Independent modules and checked legacy axiom-audit rejection.
`git blame` and the complete helper line-history are retained in `provenance.json`.
No explicit rationale for the numeral 60 was found in that introduction.

The larger production-source split-certificate fixture arrived in
`eebaab79f8c65f1b0306c07c24dc148e41ed7dc3` (2026-11-06, Refs #323).
`0f3076d3da` expanded the graph to eight chunks; the current ordinary-edit/content
reuse fixture followed in `524dbfbd4084c79f7048b1710dd3a7af76affe59`
(2026-11-06, Refs #328). The inherited helper deadline did not change. The
reviewed fixture now builds 17 project modules: seven copied production modules,
Independent, eight generated chunks and the aggregate certificate. Installed
library imports add work beyond these 17 project modules.

There is no elapsed-time assertion in the method. Correctness is expressed by
actual build status, a specific expected stale-certificate rejection, exact
source/object identities and fresh axiom audits. The related module and throughput
documentation describes performance measurements without setting a 60-second
per-build acceptance contract. In particular, the successful whole method in
`20261106T145355-acbd4750fe92` took 340.850 seconds, as retained in
`docs/reviews/review-lean-incremental-throughput-20261106.md:180` and
`docs/lean-incremental-throughput.md:179`. That whole-method timing neither gives
an individual-build maximum nor establishes today's duration.

Related real Lake fixtures in `tests/test_lean_evidence.py` already use bounded
180-second subprocess watchdogs: removed-dependency invalidation (line 974),
changed resource settings (line 1038), and handwritten source ownership (line
1108). This is a local test-policy precedent, not proof that this graph will fit.

`oracle.md` requires complete automatic discharge, source/model correspondence,
no suppression or domain narrowing, and explicit language/resource restrictions.
It specifies no 60-second compilation guarantee. This fixture uses synthetic
`X0;...` source to test cache and generated-certificate mechanics; its subprocess
watchdog is not a Silver language-membership rule. `development.md:267-283` and
`docs/proof-iteration.md` require diagnosis and complete evidence without creating
fixed proof timeouts or weaker discharge rules. The proposal does not change any
production Lean setting, GNATprove solver limit or admitted-language guarantee.

## Measured unchanged-stage costs

These are retained observations, not a new experiment or a sum yielding a full
fixture duration. Config profiling and fixture output have different measurement
boundaries and different storage setups.

| Retained run | Observation | What it establishes |
| --- | --- | --- |
| `20261108T054614-dc5613468a66` | Configuration-only command 22.878 s; first configuration olean observed at 20.318 s | Forced configuration is substantial work before project builds on the original installation. A trace file precedes completed elaboration. |
| `20261108T055144-283b5d488a27` | Initial build failed at unchanged 60 s; configuration completed around 21 s; Cursor active | The original initial build had not completed the fixture graph. |
| `20261108T060219-fd618279bf6d` | CertificateWitness command 9.604 s; exclusive import 6.870 s | A small project helper pays a large installed-library import cost on virtiofs. |
| `20261108T062237-55f39cc9f940` | Identical local-distribution profile 4.836 s; import 2.910 s | Local tool/library placement reduced this observed cost in one sequential comparison. Scheduling/cache effects remain uncontrolled. |
| `20261108T064023-1bc9e7d6f89f` | Actual unchanged complete method failed at its initial 60 s build; Lexical 5.9 s, CertificateWitness 4.9 s, Admission 5.9 s, Cursor 11 s, OutputProfileBodySource 1.4 s | Local storage alone did not make the full fixture pass. Five project modules completed; SourceLexer was active and the eleven other project modules remained unobserved as compiler processes. |

In the last run, Lake was first sampled 3.2 seconds after fixture-process launch
and SourceLexer at 46.2 seconds. These are first observations, not exact process
start times. No generated-chunk compiler was observed before timeout. SourceLexer
later exited successfully, but that cannot complete the killed Lake parent or
missing fixture stages. Unittest took 64.277 seconds including error/cleanup;
outer observation/postcheck took 83.861 seconds and managed execution 113.471
seconds. None of those is a successful full-build duration.

The local fixture inputs, full 18,381-entry distribution, prepared 19-file
workspace and all 17,792 managed inputs were checked unchanged. Its private-root
route and result are retained under `tmp/local-original-fixture-298/`. The failed
shareable bundle SHA256 is
`57d1140510274cb9fac10a31538912b3808f3b1dfe06c278fea083a2fc910edc`.
No baseline failure or diagnosis was replaced by this assessment.

## Exact proposed scope and preserved checks

The unapplied `fixture-build-watchdog-180.patch` makes three code changes:

1. Add keyword-only `timeout: int = 60` to `LeanModuleTests.lake`.
2. Forward that argument to the existing `subprocess.run(timeout=...)` call.
3. Pass `timeout=180` only from the selected method's local `build()` helper,
   with a short comment describing its larger graph and broad rebuilds.

All positional command arguments, paths, environment, subprocess API, initial
cold construction, generator, actual source bytes and cleanup remain identical.
The one-worker/one-thread settings, 2048 MiB limit, `--rehash`, `--reconfigure`,
warning-as-error policy, build targets, kernel checks and fresh audit commands
are unchanged. The selected method's `audit()` does not override the default.
Other tests retain 60 seconds.

Every correctness check remains intact:

- Successful initial/no-op/edit/reset builds and the expected specific nonzero
  stale-certificate rejection with restored source timestamps.
- Exact generated-source bytes and mtimes, plus `.olean`, `.olean.server` and
  `.olean.private` bytes/mtimes and required artifact existence.
- Exact affected/reused chunk sets, changed aggregate/provider objects,
  unchanged unrelated chunk objects and unchanged Independent objects.
- Fresh axiom audit, its explicit success marker and coverage of every chunk.
- All eleven variants: replace, append, insert, delete_unique, reorder, repeat,
  delete_repeated_occurrence, crlf, remove_final_newline, add_empty_line,
  empty_source; no subtest is skipped or shortened.

The 180 seconds applies separately to each build invocation, not to the whole
method. Its successful control path includes 25 builds (including expected stale
rejection) and 12 fresh audits. This proposal does not add a whole-method timing
contract or claim that total duration is bounded by 180 seconds. It gives a hung
build up to 120 seconds more before the existing timeout behavior. It does not
repair subprocess-descendant cleanup if a future timeout occurs; the retained
failed run already records the existing child's later completion separately.

## Static review, uncertainty and eventual validation

The original test bytes match across review, regression, integration and the
isolated local fixture root; `source-identities.json` records all four. Original
SHA256: `cb287c6dc17b7955edeb701775cc04ca4f92ede68a4393d7d77acd6b5ee67657`.
The candidate is a separate scratch file only. Parsing/compilation of that text
succeeded without executing it. Reverting exactly the three timeout AST changes
produces an AST identical to the entire original file; this independently checks
that no assertion, proof argument, call ordering or audit content changed.
`static-review.json` records that result and postcheck of all four live copies.

Patch SHA256:
`5b666993e70dae3672a83012ff96e45d09a870a463c3c9f356d8e1d60cb36c4f`.
Candidate SHA256:
`e1b5c2212a7f5b0c3d9cca93224237d5eb26e5064cc8e5573e60f958fb724c5c`.

The measurement justifies investigating a larger watchdog; it cannot prove that
180 seconds will suffice, that every later rebuild/audit will complete, or that
the earlier successful environment had the same imported artifacts or scheduling.
The fixture has still not passed in this delivery environment. No timeout-adjusted
result or passing regression evidence is claimed.

If the coordinator authorizes implementation and its resource allocation, the
meaningful validation is one complete affected native fixture using the prepared
scoped change and authenticated local tools, preserving actual stage output,
all eleven edit observations and fresh audit outcomes. Review input drift before
using that result in the regression record. An unexpected failure needs its
retained diagnostic before choosing a next action; this proposal authorizes no
automatic timeout escalation or repeat. Full project assurance remains separate.
No helper-mirroring unit tests are proposed.

Current review activity owns no native process or lease. The regression context
remains with the coordinator. Live harness goal is null; no CLI memory update
or publication has been performed.
