# #298 platform fixture watchdog repair — unapplied proposal

Prepared after retaining the actual inner failure
`20261108T073911-6cec95e84ac5`. No actual test/helper/source was edited and no
changed-watchdog run was executed. The exact scratch patch is
`platform-watchdogs.patch`; it affects only tests/test_platforms.py.

## Recommendation and scope

Use one named `PLATFORM_SETUP_TIMEOUT_SECONDS = 180` test constant for both
`PlatformIsolationTests.run_worker` and its concurrent method's communicate call.
Raise only `InstallationEnvironmentTests.test_symlinked_tmpdir_preserves_platform_setup_and_routing`'s
full-class subprocess watchdog from 180 to 900 seconds. Add short comments
identifying the complete source-generation work and suite composition.

The 15-second startup barrier is unchanged. The unrelated generated-tool-command
15-second timeout is unchanged. Preserve every method/subtest, assertion, mock,
real generator, file copy/snapshot, source-policy check, audit-routing condition,
worker count, proof option and original cleanup. The patch adds no retry and
changes no production implementation, proof, native toolchain or Oracle guarantee.
It changes only time allowed before reporting a fixture execution error. Timeout
continues to fail, and extra time cannot replace any success assertion.

## Provenance and established failure

Both worker60 sites are already present in the earliest retained repository
commit `32d50d68e9` (2026-10-08), with 15 tracked proof Lean files. The available
line history gives no specific performance rationale for 60 seconds. Their use
is a subprocess watchdog, not an elapsed-time assertion. The outer symlink
wrapper was introduced with 60 seconds in `8b8619f3ad53895dbad2e8e14e767fa5e51de628`
and increased to 180 in `3fdda42dc1b058b54dc7c6c83054af85a2d6f574` later on October
8. At that increase the proof tree had 33 Lean files and seven literal candidate
certificate mappings. Current governed target `47fe4003c0` has 821 Lean files
(including lakefile) and thirty certificate roots. Complete exact file and
method history is retained in `watchdog-provenance.json`.

The unchanged final-input outer wrapper failed at 180 seconds both in
`20261108T064731-9f1ab6dc731c` and in the local-source attempt
`20261108T071906-6ce712a8a90c`. The latter retained nested concurrent-host and
first sequential-host ERROR labels before its final traceback could print.
The one-method diagnostic `20261108T073911-6cec95e84ac5` now establishes the
actual concurrent error: TimeoutExpired at `process.communicate(timeout=60)`
for its first linux-aarch64 worker. The original method's finally cleaned up
unfinished workers. This is no longer a guess based on elapsed time.

All four diagnostic host records had passed preflight but had not entered the
mocked build/audit phase. Real generators were still observed near the deadline.
Actual worker stdout (5,203 bytes) and the complete traceback are retained;
no stderr value was supplied by that exception. The diagnostic did not observe
a prior assertion or source-policy rejection. It does not establish completion
of all later checks or the exact exception of the separate sequential-host ERROR.

## Actual invocation sequence and affected direct methods

Unittest's default alphabetical order is shown below. HOST_KEYS order is
linux-aarch64, linux-x86_64, macos-aarch64, macos-x86_64. Native here means the
actual Linux x86_64 test host; simulated foreign setup uses the original mocks.

| PlatformIsolationTests method suffix | Setup workers | Ordering and timeout site |
| --- | ---: | --- |
| cached_build_log_cannot_replace_fresh_lean_audit | 1 | Native host, omit-fresh-audit negative check; shared helper |
| concurrent_different_host_setups_do_not_collide | 4 | All HOST_KEYS together; separate communicate site |
| development_commands_keep_project_outputs_and_audit_in_native_host | 0 | Mocked routing within the test process; unchanged |
| development_output_overrides_fail_before_invoking_tools | 0 | Rejection checks within the test process; unchanged |
| each_host_setup_preserves_other_hosts_and_shared_inputs | 4 | HOST_KEYS sequentially; shared helper |
| failed_proof_invalidates_only_its_host_evidence | 1 | linux-aarch64, fail-proof negative check; shared helper |
| foreign_execution_is_rejected_before_side_effects | 0 | Rejection checks within the test process; unchanged |
| lean_auto_and_explicit_resources_are_recorded_and_isolated | 2 | Native host: (workers,threads) (0,0), then (2,4); shared helper |
| lean_full_and_clean_modes_record_their_actual_checks | 2 | Native host: full, then clean; shared helper |
| legacy_archives_are_read_only_inputs | 1 | macos-x86_64, existing mock archives; shared helper |
| platform_aliases_and_disjoint_paths | 0 | Path and host-key checks; unchanged |
| unchanged_context_setup_preserves_generated_file_mtimes | 0 | Context setup twice; unchanged |

Thus the shared helper affects six direct methods and eleven serial worker
invocations. The concurrent site affects one additional method and four workers
launched together. The other five methods have no setup-worker watchdog change.
The complete class has fifteen setup invocations organized as eleven serial
workers plus one concurrent group. Each setup worker runs the unchanged thirty
certificate generators before the mocked build/audit phase, including the
expected-negative proof/audit scenarios. A fully completed passing class
therefore traverses 450 such generator invocations; this is a static control-flow
count, not a claim that the interrupted runs observed them all.
`affected-methods.json` retains complete qualified IDs and this mapping.

## Why these finite budgets are reasonable

The confirmed worker60 timeout occurs while legitimate setup/generation is still
progressing. The earlier local whole-class observation saw one successful worker
span about 44.9 seconds and later workers approaching their 60-second limits.
The successful isolated chunk fixture already required a larger test watchdog,
and related native Lake fixtures use 180-second subprocess budgets. Choosing
180 here gives three times the inherited worker budget while retaining a finite
execution limit and all work. It is an engineering margin for this current
whole-project routing fixture, not a measured maximum or a promised pass.

The outer wrapper covers the entire 12-method class, not one worker. Using the
observed roughly 45-60-second worker scale across eleven serial workers plus
one concurrent group gives a rough 540-720-second workload before variation in
copying, snapshots, cleanup and the five in-process methods. This is an estimate:
workers have different negative/full/clean/resource modes and host scheduling
was not controlled. A 900-second whole-class watchdog gives finite headroom over
that estimate. It is not obtained by summing the allowed 180 seconds for every
worker, and a run could still exceed it. No evidence establishes a uniquely
minimal numeric value. The proposed code change is minimal in behavioral scope,
and the budgets avoid repeated small increases while remaining bounded.

If either limit is reached, preserve the actual failure and stage evidence;
there is no automatic escalation or retry. The separate sequential-host ERROR
could have an additional cause; the full unchanged assertions will expose it
once their execution is allowed to proceed. No underlying host/storage fault
or universal compiler/proof performance claim is inferred.

## Static verification of the exact candidate

The original tests/test_platforms.py matches byte-for-byte in review, regression,
integration and the retained local root; SHA256
`331468a742750f40d8931089e25f2f33307278b9ba9370192a9cc462c2bc83cd`.
The candidate parses/compiles without execution. Removing its one new constant
and reverting exactly three timeout keywords produces an AST identical to the
entire original file. This checks unchanged assertions, barrier, other limits,
commands, case selection, source handling and cleanup. `git apply --check`
succeeds against original regression without applying the patch.

Patch SHA256:
`3ea1a76ed86604f7ecf4c71da7f7a26e7f2524f67df320b040dc51f15537496f`.
Candidate SHA256:
`92e107283974c2f905f5a7c96eab3fc306c51df5ec4034b06148a2ffd8773a30`.
Exact source identities and checks are in `source-identities.json` and
`static-review.json`. No helper-mirroring unit test is proposed.

## Explicit validation plan after coordinator review

1. Apply exactly the reviewed patch in the coordinator-designated source owner
   checkout and commit only tests/test_platforms.py with Refs #298. Independently
   confirm the file lies outside any active production proof input set before
   integration. No proof/src/scripts change is needed.
2. Freeze the exact final selected inputs: the same complete 866-file source/
   helper/config set with only this approved test delta, all 821 Lean files,
   thirty certificate-bound sources, nine helpers and original mocks. Recheck
   bytes/modes against the final governed snapshot, including any later reviewed
   input changes. Do not rely on an old successful or failed run's applicability.
3. Prepare a fresh owned local source root and scoped temporary root on the same
   overlay class as the reviewed route. Keep earlier roots/evidence unchanged.
   Use ordinary __file__/ROOT/PROOF imports, record the explicit TMPDIR/TMP/TEMP
   scope, and let the original wrapper create its live alias. No installed tools,
   source reductions, project objects, extra cache clearing or policy monkeypatches.
4. Run exactly one complete original symlink wrapper method through the managed
   original-regression context with four workers, after fresh lease/headroom
   checks. Keep the proposed worker180/suite900 and unchanged barrier15. Use the
   reporting-only original-result collector, complete process/alias observation,
   actual timeout streams on failure and full source/input postflight. Do not
   run the isolated concurrent diagnostic or duplicate direct class cases first.
5. Require the wrapper's actual success with zero errors/skips and the complete
   class selection unchanged. Its original subprocess selects all twelve methods
   and asserts zero exit; that nested class has no skip/decorator path. It must
   retain all expected-negative checks. Observe the fifteen worker launches when
   available, but do not turn sampling into a fabricated complete-generator or
   per-case result log. Retain actual nested output only if available through the
   authorized reporting mechanism; source/call mapping plus the real original
   zero-exit assertion establishes which unchanged class was executed.
6. On actual exit, check all descendants and owned cleanup, verify every managed
   input plus governed bytes/modes and complete Lean file set, retain the actual
   outcome and verified shareable bundle. Any error or input drift remains a
   failure requiring review; do not increase a budget or repeat automatically.

A successful final-input complete wrapper provides affected coverage for the
six shared-helper methods, the concurrent method and the other five class
methods: it executes those same original bodies with the same final inputs,
plus the required symlink environment. Their setUp resolves temporary roots
before use, and the wrapper changes no method selection or assertions. This is
coverage of the current class under the required symlink condition; it does not
claim a separate fresh non-symlink invocation. The earlier full-suite direct
case results and this final class execution can be assessed under the repository's
existing applicability/composition policy without duplicating twelve expensive
runs. The wrapper itself still needs its actual passing result.

The coordinator's broader 637-result reuse assessment and mandatory complete
native/Lean assurance remain separate final-review work. This proposal does not
accept that inventory or convert historical failures into passes. No execution,
source edit, publication, merge or CLI memory update was performed in preparing it.
