# #298 actual inner platform timeout — established, failed diagnostic retained

Native Linux managed run `20261108T073911-6cec95e84ac5` executed exactly one
unchanged existing concurrent-host method. It failed with one error, zero
failures/skips and no reporting error. The actual traceback establishes
`subprocess.TimeoutExpired` at `tests/test_platforms.py:471`, in the original
`process.communicate(timeout=60)` for the first linux-aarch64 --concurrent
setup worker. This is the previously missing inner exception, not an inferred
cause from an ERROR label or elapsed-time sample. No second diagnostic ran.

Unittest elapsed was 64.825 seconds, including 2.347 seconds of reporting-only
precleanup capture. The observed Python process from Popen launch through wait
completion took 68.177 seconds; post-exit cleanup/input checks took 0.845 seconds.
The managed run took 82.657 seconds. Process-exit observation uses one-second
polling; per-worker first/last samples are retained separately and are not exact
exit timestamps. These are actual local Python/routing-test durations, not model
work, foreign native proof time or a performance guarantee.

Actual TimeoutExpired stdout is retained as 5,203 original bytes. Its stderr
value was absent; no fabricated empty output or unavailable other-worker stream
is claimed. Stdout confirms mocked Alire/Lean bootstrap completed and the check
printed its concurrency settings. The 54 retained per-host records independently
show all four mocked Lean runs started and passed preflight, but none recorded
a build/audit phase. The observer sampled 113 real Python generator processes;
late samples still show IO, arguments and runtime certificate generation near
the deadline. Sampling can miss short generators, so 113 is not a claimed exact
invocation count. Source review places complete certificate generation and input
verification before the mocked build phase. The diagnostic establishes a worker
watchdog interrupting incomplete routing/generation work; it reports no prior
source-policy/assertion rejection. It does not prove all later checks will pass.

The selected method, four-host concurrency, 60-second communicate limit,
15-second startup barrier, assertions, real generators, tool mocks and original
finally/cleanup were unchanged. The outer full-class wrapper was not selected;
no outer deadline was raised. Normal imports used the retained local root,
all 866 governed files/modes, complete 821-file Lean set and eight declared
existing Python caches. The exact prior physical/alias path and TMPDIR/TMP/TEMP
values were recreated. All four observed workers inherited the same live symlink
alias. No source recopy, cache clearing, installation, selector or project-object
change occurred.

The original method performed its existing unfinished-worker cleanup. The
observer sent no additional cleanup signal; no owned descendants remained.
The recreated alias/physical wrapper was removed only after the test's original
cleanup, leaving the scoped temporary root empty. Minimum sampled available RAM
was 46.981 GiB. No broader host, scheduling or storage cause is asserted.

All 874 retained-root files (866 governed plus eight caches), modes and the
complete 821-file Lean set matched after execution. Explicit postflight rehashed
all 886 captured managed inputs; all matched. The 866 original governed-source
files/modes also still matched `47fe4003c0`. All 54 archived precleanup records
were checked against their captured file hashes/sizes. Exact traceback, original
streams, full inventory, process chronology, managed events/log and separate
phase review are retained. Earlier outer failures remain failures and the
successful chunk-reuse fixture remains unchanged.

The concrete next repair question is a fixture-only increase of the inherited
worker budget, together with sufficient finite headroom for the enclosing whole
12-method suite. Increasing only the outer deadline cannot repair this confirmed
inner limit. Preserve the 15-second barrier and every assertion/case/generator/
source/proof setting. The coordinator requested a precise unapplied patch and
coverage plan from the current 821-file workload; that preparation follows this
retention. No watchdog edit, additional run or automatic retry was performed.

Selected reviewer setting is GPT-6 Astra / Extra High; independent runtime
telemetry is unavailable. No publication, merge or CLI memory update occurred.
