from pathlib import Path
import hashlib,json,shutil,stat,subprocess,tarfile
review=Path(__file__).resolve().parents[1];case=review/'tmp/platform-concurrent-inner-diagnostic-298';r=case/'results';reg=review.parent/'scalar-functions-298';run_id='20261108T073911-6cec95e84ac5'
x=subprocess.run(['/usr/bin/python3','scripts/dev.py','runs','status'],cwd=reg,text=True,capture_output=True,check=True);(case/'postflight-status.json').write_text(x.stdout);s=json.loads(x.stdout);run=next(z for z in s['runs'] if z['run_id']==run_id);assert not run['active']
d=Path(run['directory']);events=[json.loads(l) for l in (d/'events.jsonl').read_text().splitlines()];assert any(z['event']=='finished' for z in events)
for src,dst in [('events.jsonl','managed-events.jsonl'),('native.log','managed-native.log')]:shutil.copyfile(d/src,r/dst)
expected=next(z for z in events if z['event']=='prepared')['inputs']['inputs_sha256'];actual={};diff=[]
for name,wanted in expected.items():
 try:
  with Path(name).open('rb') as f:got=hashlib.file_digest(f,'sha256').hexdigest()
 except OSError as exc:got={'error':type(exc).__name__,'message':str(exc)}
 actual[name]=got
 if got!=wanted:diff.append({'path':name,'expected':wanted,'actual':got})
(r/'postflight-managed-input-verification.json').write_text(json.dumps({'run_id':run_id,'files_checked':len(expected),'all_unchanged':not diff,'differences':diff,'actual_sha256':actual},indent=2,sort_keys=True)+'\n');assert not diff
source_diff=[]
for item in json.loads((case/'frozen-inputs/copy-inventory.json').read_text()):
 p=reg/item['path']
 with p.open('rb') as f:got=hashlib.file_digest(f,'sha256').hexdigest()
 if got!=item['sha256'] or stat.S_IMODE(p.stat().st_mode)!=item['mode']:source_diff.append(item['path'])
(r/'governed-source-postflight.json').write_text(json.dumps({'files_checked':866,'all_bytes_modes_match_47fe':not source_diff,'differences':source_diff},indent=2)+'\n');assert not source_diff
fixture=json.loads((r/'fixture-result.json').read_text());summary=json.loads((r/'summary.json').read_text());observations=json.loads((r/'fixture-observations.json').read_text()) if (r/'fixture-observations.json').exists() else [];es=[json.loads(l) for l in (r/'observer-events.jsonl').read_text().splitlines()];seen=[z for z in es if z['event']=='process-first-seen'];workers=[z for z in seen if '--setup-worker' in z.get('cmdline','')];base=es[0]['monotonic_ns'];samples=[z for z in es if z['event']=='process-sample'];chronology=[]
for w in workers:
 present=[z for z in samples if any(q['pid']==w['pid'] and q['start_ticks']==w['start_ticks'] for q in z['processes'])];last=present[-1];after=next((z for z in samples if z['monotonic_ns']>last['monotonic_ns']),None)
 chronology.append({'pid':w['pid'],'command':w['cmdline'],'first_seen_seconds':(w['monotonic_ns']-base)/1e9,'last_seen_seconds':(last['monotonic_ns']-base)/1e9,'next_absent_sample_seconds':(after['monotonic_ns']-base)/1e9 if after else None,'last_sampled_process':next(q for q in last['processes'] if q['pid']==w['pid']),'temporary_environment':w.get('temporary_environment'),'path_observation':w.get('temporary_path_observation')})
(r/'worker-chronology.json').write_text(json.dumps(chronology,indent=2)+'\n')
records=[]
for obs in observations:
 if 'records_archive' in obs:
  with tarfile.open(r/obs['records_archive'],'r:gz') as t:records.append({'archive':obs['records_archive'],'members':len(t.getmembers()),'bytes':(r/obs['records_archive']).stat().st_size})
completion={'run_id':run_id,'fixture_result':fixture,'actual_exception_types':[o['exception_type'] for o in observations],'actual_timeout_seconds':[o['timeout_seconds'] for o in observations if 'timeout_seconds' in o],'managed_outcome':run['state'],'managed_duration_seconds':run['duration_seconds'],'observer_summary':summary,'managed_files_checked':len(expected),'all_managed_and_governed_inputs_unchanged':not diff and not source_diff,'workers_observed':len(workers),'all_observed_workers_used_symlink_alias':len(workers)==4 and all(z.get('temporary_path_observation',{}).get('is_symlink') for z in workers),'records_archives':records,'minimum_sampled_available_gib':min(z['memavailable_kib'] for z in samples)/1024**2,'owned_cleanup_signals':[z for z in es if z['event']=='post-fixture-owned-descendant-cleanup']}
(r/'completion-review.json').write_text(json.dumps(completion,indent=2)+'\n');print(json.dumps(completion,indent=2))
