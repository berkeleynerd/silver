"""Run one unchanged concurrent-platform method and retain actual error data."""
import hashlib,json,os,stat,subprocess,sys,tarfile,tempfile,time,traceback,unittest
from pathlib import Path
CASE=Path(__file__).resolve().parents[1];RESULTS=CASE/'results'
ROOT=Path('/tmp/silver-platform-test-root-298-20261108')
TEMPS=Path('/tmp/silver-platform-test-temporaries-298-20261108')
PARENT=TEMPS/'silver tmpdir regression-g3wetwft';ALIAS=PARENT/'alias';PHYSICAL=PARENT/'physical'
os.chdir(ROOT);sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
import test_platforms
from scripts import bootstrap,bootstrap_lean,check_lean,dev,platforms,run_history

def write(name,value):(RESULTS/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def digest(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
modules={m.__name__:str(Path(m.__file__).resolve()) for m in [test_platforms,bootstrap,bootstrap_lean,check_lean,dev,platforms,run_history]}
assert all(Path(p).is_relative_to(ROOT) for p in modules.values())
assert all(m.ROOT==ROOT for m in [test_platforms,bootstrap,bootstrap_lean,check_lean,platforms]);assert check_lean.PROOF==ROOT/'proof'
assert platforms.host_key()=='linux-x86_64' and ALIAS.is_symlink() and ALIAS.resolve()==PHYSICAL
assert all(os.environ[k]==str(ALIAS) for k in ['TMPDIR','TMP','TEMP']);assert Path(tempfile.gettempdir()).resolve()==PHYSICAL
write('fixture-import-paths.json',{'modules':modules,'ROOT':str(ROOT),'PROOF':str(check_lean.PROOF),'host':platforms.host_key(),'TMPDIR':os.environ['TMPDIR'],'TMP':os.environ['TMP'],'TEMP':os.environ['TEMP'],'tempfile_selected':tempfile.gettempdir(),'alias_resolved':str(ALIAS.resolve()),'fixture_monkeypatched':False,'test_sha256':digest(ROOT/'tests/test_platforms.py')})
class RecordingResult(unittest.TextTestResult):
 def __init__(self,*a,**kw):super().__init__(*a,**kw);self.observations=[];self.reporting_errors=[]
 def observe(self,test,label,err):
  started=time.monotonic_ns()
  try:
   exc=err[1];item={'label':label,'test_id':test.id(),'monotonic_ns_before_capture':started,'exception_type':type(exc).__name__,'exception':str(exc),'traceback':''.join(traceback.format_exception(*err))}
   if isinstance(exc,subprocess.TimeoutExpired):
    item.update(timeout_seconds=exc.timeout,command=exc.cmd)
    for key in ['stdout','stderr']:
     value=getattr(exc,key)
     if value is not None:
      data=value if isinstance(value,bytes) else value.encode();name=f'exception-{len(self.observations):02d}-{key}.bin';(RESULTS/name).write_bytes(data);item[key]={'file':name,'bytes':len(data),'original_type':type(value).__name__}
   root=getattr(test,'root',None);item['workspace']=str(root) if root is not None else None
   if root is not None and root.exists():
    assert root.resolve().is_relative_to(PHYSICAL)
    inventory={};archive=RESULTS/f'precleanup-records-{len(self.observations):02d}.tar.gz';retained=[]
    with tarfile.open(archive,'w:gz',dereference=False) as tar:
     for p in sorted(root.rglob('*')):
      relative=str(p.relative_to(root));s=p.lstat();row={'mode':stat.S_IMODE(s.st_mode)}
      if p.is_symlink():row.update(type='symlink',target=os.readlink(p))
      elif p.is_file():
       row.update(type='file',bytes=s.st_size,sha256=digest(p))
       if p.suffix in {'.json','.jsonl','.log','.toml','.lock','.txt','.trace'}:
        tar.add(p,arcname=relative,recursive=False);retained.append(relative)
      elif p.is_dir():row.update(type='directory')
      else:row.update(type='other')
      inventory[relative]=row
    name=f'precleanup-inventory-{len(self.observations):02d}.json';write(name,inventory)
    item.update(workspace_inventory=name,records_archive=archive.name,records_retained=retained,snapshot_atomicity='Reporting read before original cleanup; consult observer for any still-live generator.')
   item['capture_elapsed_seconds']=(time.monotonic_ns()-started)/1e9;self.observations.append(item);write('fixture-observations.json',self.observations)
  except Exception as exc:self.reporting_errors.append({'type':type(exc).__name__,'message':str(exc)});write('reporting-errors.json',self.reporting_errors)
 def startTest(self,test):write('fixture-start.json',{'test_id':test.id(),'monotonic_ns':time.monotonic_ns(),'utc_ns':time.time_ns()});super().startTest(test)
 def addError(self,test,err):self.observe(test,'error',err);super().addError(test,err)
 def addFailure(self,test,err):self.observe(test,'failure',err);super().addFailure(test,err)
identifier='test_platforms.PlatformIsolationTests.test_concurrent_different_host_setups_do_not_collide'
suite=unittest.defaultTestLoader.loadTestsFromName(identifier);assert suite.countTestCases()==1
started=time.monotonic_ns();result=unittest.TextTestRunner(stream=sys.stdout,verbosity=2,resultclass=RecordingResult).run(suite)
summary={'test_id':identifier,'tests_run':result.testsRun,'errors':len(result.errors),'failures':len(result.failures),'skips':len(result.skipped),'passed':result.wasSuccessful() and result.testsRun==1 and not result.skipped,'unittest_duration_seconds':(time.monotonic_ns()-started)/1e9,'reporting_errors':result.reporting_errors,'reporting_capture_seconds':sum(o['capture_elapsed_seconds'] for o in result.observations),'source_assertions_worker60_barrier15_and_cleanup_unchanged':True,'scope':'One existing concurrent-host method; not the required outer suite fixture.'}
write('fixture-result.json',summary);print(json.dumps(summary,sort_keys=True),flush=True);raise SystemExit(0 if summary['passed'] and not result.reporting_errors else 1)
