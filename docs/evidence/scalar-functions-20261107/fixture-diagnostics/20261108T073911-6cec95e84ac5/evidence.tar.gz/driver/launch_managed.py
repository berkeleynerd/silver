from pathlib import Path
import hashlib,json,os,subprocess
case=Path(__file__).resolve().parents[1];regression=case.parents[2]/'scalar-functions-298'
root=Path('/tmp/silver-platform-test-root-298-20261108');temps=Path('/tmp/silver-platform-test-temporaries-298-20261108')
status=subprocess.run(['/usr/bin/python3','scripts/dev.py','runs','status'],cwd=regression,text=True,capture_output=True,check=True);(case/'preflight-status.json').write_text(status.stdout);s=json.loads(status.stdout)
active=[{k:r.get(k) for k in ['run_id','workers','kind','worktree']} for r in s['runs'] if r['active']]
assert all(r['worktree']!=str(regression) for r in active);assert s['reserved_workers']+4<=s['available_cpus']
mem=next(x for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:'));assert int(mem.split()[1])>12*1024*1024
assert not any(temps.iterdir())
for item in json.loads((case/'frozen-inputs/complete-root-inventory.json').read_text()):
 p=root/item['path']
 with p.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==item['sha256'],item['path']
 assert p.stat().st_mode&0o7777==item['mode'],item['path']
host={'uname':list(os.uname()),'memory':mem,'active_runs':active,'reserved_workers':s['reserved_workers'],'available_cpus':s['available_cpus'],'loadavg':Path('/proc/loadavg').read_text(),'all_874_root_inputs_rechecked':True};(case/'preflight-host.json').write_text(json.dumps(host,indent=2)+'\n')
cmd=['/usr/bin/python3','scripts/dev.py','tool','--task','#298 platform inner error diagnosis','--reason','Authorized exactly one unchanged existing concurrent-host method to expose actual innerERROR from retained071906; same ROOT866governed+8pycache and exact symlinkTMP alias, original4workers communicate60/barrier15/assertions/cleanup; reporting-only traceback/streams/precleanup capture, no outerfixture retry or deadline change','--jobs','4']
for p in [root,temps,case/'results']:cmd+=['--workspace',str(p)]
for p in [root,case/'driver',case/'frozen-inputs']:cmd+=['--input',str(p)]
cmd+=['--','/usr/bin/python3','-B',str(case/'driver/run_fixture.py')]
(case/'managed-command.json').write_text(json.dumps({'cwd':str(regression),'argv':cmd},indent=2)+'\n')
print(json.dumps({'active':active,'reserved_workers':s['reserved_workers'],'available_cpus':s['available_cpus'],'memory':mem,'starting_one_concurrent_method_diagnostic':True}),flush=True)
r=subprocess.run(cmd,cwd=regression);raise SystemExit(r.returncode)
