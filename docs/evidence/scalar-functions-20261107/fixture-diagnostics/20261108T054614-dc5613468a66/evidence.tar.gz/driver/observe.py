"""One isolated configuration observation, with unchanged 60-second deadline."""
import hashlib
import json
import os
from pathlib import Path
import selectors
import shutil
import signal
import subprocess
import sys
import time
from unittest import mock

BASE = Path(__file__).resolve().parents[1]
FROZEN, WORK, RESULTS = (BASE / n for n in ('frozen-inputs', 'work', 'results'))
REGRESSION = Path('/home/canto/src/github.com/berkeleynerd/silver/tmp/scalar-functions-298')
TOOLS = REGRESSION / '.tools/linux-x86_64/lean'
sys.path.insert(0, str(FROZEN))
from scripts import check_lean
from scripts.bootstrap_lean import lean_environment
from scripts.platforms import HostLayout, host_key


def digest(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def write(name, value):
    (RESULTS / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def read(p):
    try:
        return Path(p).read_text()
    except (OSError, UnicodeError) as e:
        return {'unavailable': type(e).__name__}


def ticks(pid):
    s = Path(f'/proc/{pid}/stat').read_text()
    a = s[s.rfind(')') + 2:].split()
    return {'pid': pid, 'state': a[0], 'ppid': int(a[1]), 'pgrp': int(a[2]),
            'sid': int(a[3]), 'minflt': int(a[7]), 'majflt': int(a[9]),
            'utime_ticks': int(a[11]), 'stime_ticks': int(a[12]),
            'start_ticks': int(a[19]), 'rss_pages': int(a[21])}


def members(sid):
    found = []
    for d in Path('/proc').iterdir():
        if d.name.isdecimal():
            try:
                s = ticks(int(d.name))
                if s['sid'] == sid:
                    found.append(s)
            except (OSError, ValueError, IndexError):
                pass
    return found


if WORK.exists() or RESULTS.exists():
    raise RuntimeError('Refuse repeat: diagnostic work or result directory already exists')
WORK.mkdir()
RESULTS.mkdir()
write('preparation-start.json', {'monotonic_ns': time.monotonic_ns(), 'utc_ns': time.time_ns()})
for name, expected in json.loads((FROZEN / 'snapshot-sha256.json').read_text()).items():
    assert digest(FROZEN / name) == expected, name
host = HostLayout(WORK, host_key())
assert host.key == 'linux-x86_64'
host.lean.parent.mkdir(parents=True)
host.lean.symlink_to(TOOLS, target_is_directory=True)
(WORK / 'src').mkdir()
original = b''.join(f'X{index};\n'.encode() for index in range(16)) + b'X0;\n'
(WORK / 'src/silver_output_profile.adb').write_bytes(original)
proof = WORK / 'proof'
proof.mkdir()
shutil.copyfile(FROZEN / 'proof/generate_source_certificate.py', proof / 'generate_source_certificate.py')
inputs = {proof / p.relative_to(FROZEN / 'proof'): p.read_bytes()
          for p in (FROZEN / 'proof').rglob('*') if p.is_file() and p.suffix != '.py'}
inputs[proof / 'Silver/Independent.lean'] = b'module\npublic theorem Silver.independent : True := True.intro\n'
check_lean.prepare_workspace(host, inputs)
with mock.patch.object(check_lean, 'ROOT', WORK), mock.patch.object(check_lean, 'PROOF', proof):
    check_lean.generate_certificate(host, Path('Silver/OutputBodyCertificate.lean'), 'silver_output_profile.adb')
assert not (host.proof / '.lake').exists(), 'Configuration must begin cold'
expected = json.loads((FROZEN / 'prepared-initial-build-workspace-inventory.json').read_text())['files']
comparisons = []
for name, item in expected.items():
    if '/.lake/' in name:
        continue
    p = WORK / name
    actual = digest(p)
    comparisons.append({'path': name, 'sha256': actual, 'expected_sha256': item['sha256'],
                        'bytes': p.stat().st_size, 'matches': actual == item['sha256']})
assert len(comparisons) == 19
write('prepared-input-comparison.json', comparisons)
assert all(x['matches'] for x in comparisons), 'Prepared fixture drift'
before = {str(p.relative_to(WORK)): digest(p) for p in WORK.rglob('*') if p.is_file() and '.tools' not in p.parts}
write('input-before.json', before)
inherited = json.loads((FROZEN / 'private-inherited-environment.json').read_text())
env = {**lean_environment(host, inherited=inherited), 'LEAN_NUM_THREADS': '1'}
raw_names = {'PATH', 'TMPDIR', 'TMP', 'TEMP', 'LANG', 'LC_ALL', 'OMP_NUM_THREADS', 'MALLOC_ARENA_MAX'}
write('environment.json', {k: {'value': v} if k in raw_names or k.startswith(('LEAN', 'LAKE', 'ELAN'))
                           else {'sha256': hashlib.sha256(v.encode()).hexdigest(), 'value_recorded': False}
                           for k, v in sorted(env.items())})
command = [str(host.lean / 'bin/lake'), '--rehash', '--reconfigure', '-K', 'silverThreads=1',
           '-K', 'silverMemoryMb=2048', 'env', '/usr/bin/python3', '-B',
           str(BASE / 'driver/loaded_marker.py'), str(RESULTS / 'loaded.json')]
write('command.json', {'argv': command, 'cwd': str(host.proof), 'timeout_seconds': 60,
                      'configuration_only': True, 'history_environment_unrecorded': True,
                      'clock_ticks_per_second': os.sysconf('SC_CLK_TCK'),
                      'page_size': os.sysconf('SC_PAGE_SIZE'), 'uname': list(os.uname()),
                      'boot_id': read('/proc/sys/kernel/random/boot_id'),
                      'monotonic_ns': time.monotonic_ns(),
                      'boottime_ns': time.clock_gettime_ns(time.CLOCK_BOOTTIME)})
tool_paths = [TOOLS / 'bin/lake', TOOLS / 'bin/lean', Path('/usr/bin/python3')]
write('tool-identities.json', {str(p): {'resolved': str(p.resolve()), 'sha256': digest(p)} for p in tool_paths})
loaded_libraries = set()
seen, artifact_state = {}, {}
stream = (RESULTS / 'samples.jsonl').open('w')

def event(value):
    value.update(monotonic_ns=time.monotonic_ns(), boottime_ns=time.clock_gettime_ns(time.CLOCK_BOOTTIME))
    stream.write(json.dumps(value, sort_keys=True) + '\n')
    stream.flush()


def sample(sid):
    rows = members(sid)
    for s in rows:
        pid = s['pid']
        p = Path('/proc') / str(pid)
        identity = (pid, s['start_ticks'])
        if identity not in seen:
            seen[identity] = time.monotonic_ns()
            event({'event': 'process_first_seen', **s, 'cmdline': read(p / 'cmdline')})
        s['io'] = read(p / 'io')
        s['wchan'] = read(p / 'wchan')
        s['schedstat'] = read(p / 'schedstat')
        s['status'] = read(p / 'status')
        threads = {}
        try:
            for task in (p / 'task').iterdir():
                threads[task.name] = {'schedstat': read(task / 'schedstat'), 'wchan': read(task / 'wchan')}
        except OSError:
            pass
        s['threads'] = threads
        maps = read(p / 'maps')
        if isinstance(maps, str):
            for line in maps.splitlines():
                parts = line.split(maxsplit=5)
                if len(parts) == 6 and parts[5].startswith('/') and not parts[5].endswith(' (deleted)'):
                    loaded_libraries.add(parts[5])
    changes = []
    for p in (host.proof / '.lake').rglob('*'):
        if p.is_file():
            stat = p.stat()
            identity = (stat.st_size, stat.st_mtime_ns)
            key = str(p.relative_to(host.proof))
            if artifact_state.get(key) != identity:
                artifact_state[key] = identity
                changes.append({'path': key, 'bytes': stat.st_size, 'mtime_ns': stat.st_mtime_ns})
    event({'event': 'sample', 'processes': rows, 'artifact_changes': changes,
           'meminfo': read('/proc/meminfo'), 'loadavg': read('/proc/loadavg'),
           'pressure_cpu': read('/proc/pressure/cpu'), 'pressure_io': read('/proc/pressure/io'),
           'pressure_memory': read('/proc/pressure/memory')})
    return rows


selector = selectors.DefaultSelector()
start = time.monotonic_ns()
process = subprocess.Popen(command, cwd=host.proof, env=env, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, start_new_session=True)
leader = ticks(process.pid)
assert leader['sid'] == process.pid and leader['pgrp'] == process.pid
write('launch.json', {'monotonic_before_popen_ns': start, 'monotonic_after_popen_ns': time.monotonic_ns(),
                      'leader': leader})
outputs = {}
for name, pipe in [('stdout', process.stdout), ('stderr', process.stderr)]:
    os.set_blocking(pipe.fileno(), False)
    selector.register(pipe, selectors.EVENT_READ, name)
    outputs[name] = (RESULTS / (name + '.bin')).open('wb')
next_sample = time.monotonic()
timed_out = False
while True:
    now = time.monotonic()
    if now >= next_sample:
        sample(process.pid)
        next_sample = now + 0.25
    if process.poll() is None and time.monotonic_ns() - start >= 60_000_000_000:
        timed_out = True
        event({'event': 'deadline', 'seconds': 60})
        # Only identities in the newly created diagnostic session are eligible.
        for row in members(process.pid):
            try:
                current = ticks(row['pid'])
                if current['sid'] == process.pid and current['start_ticks'] == row['start_ticks']:
                    os.kill(row['pid'], signal.SIGKILL)
                    event({'event': 'timeout_cleanup_signal', 'pid': row['pid'],
                           'start_ticks': row['start_ticks'], 'sid': process.pid, 'signal': 'SIGKILL'})
            except ProcessLookupError:
                pass
    for key, _ in selector.select(timeout=max(0, min(0.05, next_sample - time.monotonic()))):
        data = os.read(key.fileobj.fileno(), 65536)
        if data:
            outputs[key.data].write(data)
            outputs[key.data].flush()
            event({'event': 'stream_chunk', 'stream': key.data, 'bytes': len(data)})
        else:
            selector.unregister(key.fileobj)
            key.fileobj.close()
    if process.poll() is not None and not selector.get_map():
        remaining = sample(process.pid)
        if not remaining:
            break
        # Do not report exit while a diagnostic descendant is still present.
        event({'event': 'waiting_for_diagnostic_descendants', 'pids': [r['pid'] for r in remaining]})
end = time.monotonic_ns()
for f in outputs.values():
    f.close()
stream.close()
assert not members(process.pid)
after = {name: digest(WORK / name) for name in before}
write('input-after.json', after)
assert before == after
write('artifact-inventory.json', {str(p.relative_to(WORK)): {'sha256': digest(p), 'bytes': p.stat().st_size}
                                 for p in WORK.rglob('*') if p.is_file() and '.tools' not in p.parts})
write('loaded-file-identities.json', {name: {'sha256': digest(name), 'bytes': Path(name).stat().st_size}
                                    for name in sorted(loaded_libraries) if Path(name).is_file()})
summary = {'outcome': 'timeout' if timed_out else 'success' if process.returncode == 0 else 'failure',
           'returncode': process.returncode, 'lake_elapsed_seconds': (end - start) / 1e9,
           'timed_out': timed_out, 'no_remaining_diagnostic_processes': True,
           'prepared_files_matched': len(comparisons), 'inputs_unchanged': before == after,
           'configuration_marker': json.loads((RESULTS / 'loaded.json').read_text()) if (RESULTS / 'loaded.json').exists() else None,
           'not_a_fixture_pass': True, 'module_build_requested': False,
           'process_start_ticks_and_first_seen': [{'pid': p, 'start_ticks': t, 'first_seen_monotonic_ns': n}
                                                for (p, t), n in seen.items()]}
write('summary.json', summary)
print(json.dumps(summary, sort_keys=True), flush=True)
sys.exit(124 if timed_out else process.returncode)
