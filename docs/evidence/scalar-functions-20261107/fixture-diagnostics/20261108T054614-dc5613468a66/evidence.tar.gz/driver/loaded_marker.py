import json
import os
from pathlib import Path
import sys
import time

entry = time.monotonic_ns()
stat = Path('/proc/self/stat').read_text()
Path(sys.argv[1]).write_text(json.dumps({
    'event': 'configuration_loaded_marker', 'monotonic_ns': entry,
    'boottime_ns': time.clock_gettime_ns(time.CLOCK_BOOTTIME),
    'pid': os.getpid(), 'ppid': os.getppid(), 'sid': os.getsid(0),
    'start_ticks_since_boot': int(stat[stat.rfind(')') + 2:].split()[19]),
    'note': 'Python entry after lake env completed loadWorkspace; no module build.'
}, indent=2) + '\n')
