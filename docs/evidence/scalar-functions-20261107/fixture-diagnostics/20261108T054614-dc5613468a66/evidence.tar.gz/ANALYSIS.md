# #298 configuration-only observation

Managed run `20261108T054614-dc5613468a66` succeeded on native Linux x86-64.
The single command completed with status zero; there was no repeat, module
build or signal. All diagnostic descendants exited, its one-worker reservation
was released, and the shared pool returned to 20/22 reserved. The managed run
lasted 62.554 seconds including runner preflight, preparation and evidence
collection; its Lake command plus marker and exit confirmation lasted 22.878
seconds within the unchanged 60-second deadline.

All 19 prepared source/configuration files matched the retained failed-fixture
inventory before launch. The fresh workspace had no `.lake` directory. The
seven production modules, generator, lakefile, toolchain and test setup matched
the recorded fixture bytes. Input hashes stayed unchanged afterward. The only
Lake command substitution was `env` plus the recorded immediate completion
marker in place of `build` and its module targets. No `.lake/build` artifacts
were produced. Stdout was empty; stderr contained only the expected creation
of a missing manifest and unchanged-toolchain information.

Relative to the monotonic time immediately before spawning Lake:

- Configuration trace first observed at 1.067 seconds.
- Configuration olean first observed at 20.318 seconds.
- Marker child process started around 20.542 seconds (10ms Linux tick precision).
- Marker's Python entry was recorded at 21.607 seconds.
- Command/descendant exit confirmed at 22.878 seconds.

The 85 Lake samples recorded 16.84 user CPU seconds and 4.31 system CPU
seconds at the final observed process state (21.14 seconds gained after the
first sample). Sampled peak RSS was 834.7 MiB. Per-observed-thread scheduler
wait counters totalled 0.220 seconds, a lower bound because short-lived threads
can evade sampling. Last readable I/O counters recorded zero storage-read bytes
and approximately 1.05 MB written. These measurements show active configuration
computation in this observation; they do not establish the cause of the earlier
build timeouts. Main-thread futex waits are not evidence of total process
inactivity: the worker-thread and aggregate CPU measurements must be read with
them.

Pinned Lake writes its trace before configuration elaboration. The historical
trace alone never established configuration completion. Its two process
snapshots lack the CPU deltas, I/O/wait counters and exact child starts needed
to assign the historical delay. This diagnostic preserves current environment
values relevant to Lean/Lake and hashes other values; a private mode-0600
pre-Alire snapshot was used so the runner's Alire environment did not silently
alter the fixture's inherited environment. That private snapshot is excluded
from the shareable evidence archive. The historical inherited environment and
OS cache state are unknown, so this is not an exact historical environment or
scheduling reproduction.

The full initial build, axiom audit and content/occurrence/object reuse stages
remain failed or unexecuted. The smallest justified prospective check is one
instrumented initial-build-only observation of a fresh identical fixture,
under the existing 60-second deadline, retaining all module-start and stream
measurements and stopping before audit/variants. That would distinguish current
configuration cost from module compilation and expose any specific slow module.
It needs coordinator scheduling and explicit work allocation; it has not been
launched. A later passing original full fixture remains required. There is no
basis here for increasing its timeout or modifying source/test/harness inputs.

Evidence is in `results/`: prepared-input comparison, before/after hashes,
separate raw streams, complete process samples, marker/launch clocks, exact
command, environment manifest, executable/loaded-file identities, artifact
inventory, managed events/log and `analysis.json`. `PLAN.md` retains the
pre-execution plan; `driver/` contains the exact frozen observer. The frozen
input set also retains the production source and helper bytes. Selected review
setting: GPT-6 Astra / Extra High, independent runtime telemetry unavailable.
Live harness goal was null at resume; CLI memory was not updated.
