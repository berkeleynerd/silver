# #298 repeated chunk-reuse timeout: configuration-only diagnostic

Status: proposed to the delivery coordinator; no diagnostic launched.
Owner: delivery_review. Governing source, test and harness files remain unchanged.

## Retained evidence and source reading

Both the full suite (`20261108T021923-5ef7f9b81de7`) and unchanged focused
follow-up (`20261108T053156-3a0a42e9d590`) timed out on the initial Lake build
at the existing 60-second limit, before audit or reuse/edit variants. The
follow-up's 19 prepared source/configuration files are retained, plus a
configuration trace written by 05:32:52.906574 UTC. That trace records exact
silverThreads=1, silverMemoryMb=2048 and Lean hash
5045d0056413266e57c625dcd7c365b10e377c52.

Pinned Lake `Load/Lean/Elab.lean:233-258` writes and flushes that trace BEFORE
elaborating the configuration and writing its olean. Its existence does not
prove configuration completion. The two process snapshots do not measure CPU
tick deltas, I/O, wait time or exact child starts. No root cause is established.

Pinned `CLI/Main.lean:1158-1171` implements `env` by loading the workspace,
then spawning the supplied command; there is no module build invocation.
`Load/Workspace.lean:61-71` also resolves/materializes dependencies. The exact
fixture lakefile has no package requirements or post-update hook; its source
input declarations and libraries are evaluated without compiling their modules.

## Proposed run

Use regression worktree's existing managed `dev.py tool` entrypoint, reserving
one worker. This also leases its existing native toolchain context and writes
the shared managed ledger. Coordinator must coordinate that context; the review
worktree has no installed native toolchain. Explicit writable roots are only
this scratch directory's `work/` and `results/`; explicit additional inputs are
`driver/`, `frozen-inputs/`, and the pinned Lake/Lean executable selectors.
No manual edits to regression artifacts, source or harness are planned.

Recreate fixture's seven production modules, exact lakefile/toolchain/generator,
Independent theorem and synthetic X0..X15/X0 source using the unchanged
prepare_workspace/generate_certificate functions. Verify all 19 prepared
source/config hashes against the retained inventory before launching Lake.
No archived .lake state is restored. Require a missing .lake directory for the
single cold configuration observation; retain final state instead of cleanup.

Exact Lake argument vector after its absolute executable path:

```
--rehash --reconfigure -K silverThreads=1 -K silverMemoryMb=2048
  env /usr/bin/python3 -B <driver>/loaded_marker.py <results>/loaded.json
```

The marker records its immediate monotonic entry, PID/PPID and Linux process
start tick, and exits. It executes no proof/module compilation. Preserve
LEAN_NUM_THREADS=1 and the same lean_environment construction. The -K memory
option controls module weakLeanArgs, not a demonstrated Lake elaborator memory
cap. Keep the existing 60-second Lake deadline. On expiry only, stop and reap
the just-created diagnostic session tree and record timeout; no external
process signals, retries or timeout changes. This bounded cleanup is part of
the proposal, not authority already exercised.

## Instrumentation and interpretation

Capture stdout and stderr independently, monotonic launch/end times and marker
entry, /proc PID start ticks and first-seen times, 250ms CPU-tick/schedstat/I/O/
wchan/process-state/RSS observations and host memory/load/pressure. Record
configuration trace/olean appearance and hashes, final complete scratch
inventory, tool executable and loaded-library identities, exact arguments,
host/clock-tick metadata and input hashes before/after.

Take a private, mode-0600 inherited-environment snapshot before Alire launches
the driver, and feed that explicitly to lean_environment. Record relevant
Lean/Lake/search/thread values and digests for other inherited values without
publishing credentials. The historical fixture's ambient environment was not
retained: claim identical fixture/config bytes and a recorded current
environment, not identical historical scheduling or OS cache state.

Re-read shared managed status and fresh headroom before launch. The planning
observation showed 20/22 workers reserved and about 38.9 GiB available; those
numbers are not a reservation or future preflight. One run only, no whole
fixture and no adjustment to tests, timeout, memory options or proof inputs.

Configuration-only success measures workspace-loading cost in that observed
state; it does not establish why the historical full builds timed out. Slow
loading may motivate a separate precise diagnosis; fast loading leaves module
compilation/other scheduling unresolved. The full original fixture and its
reuse/edit/audit stages remain mandatory after an evidence-based next step.
