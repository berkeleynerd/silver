# #298 unchanged original fixture with local tools — failed

Managed run `20261108T064023-1bc9e7d6f89f` finished failed: one original test,
one TimeoutExpired error, zero skips/failures and zero audit/edit subtests
reached. The initial Lake build exceeded its unchanged 60-second watchdog.
Unittest execution was 64.277 seconds, the outer observation/stability work
83.861 seconds, and the complete managed command 113.471 seconds. None of
these durations reclassifies the failed initial build as a pass.

The isolated fixture root used byte-identical current test, all nine helpers,
production lakefile/pin/generator and seven proof modules. Normal __file__
derivation selected the copied ROOT/PROOF/imports, and only the new root's
selector pointed at the authenticated local installation. The scoped TMPDIR
was an explicitly approved new path on the same /tmp overlay as the original
failing workspace. No existing selector, test method, assertion, subprocess
API, proof option, deadline or cleanup was modified; no profiler was enabled.

All 18,381 complete distribution entries matched before and after execution.
The first prepared workspace matched all 19 retained source/configuration
hashes. Copied inputs stayed unchanged. Since the managed failure path skips
its normal final identity check, a separate explicit postflight rehashed every
one of the 17,792 captured managed inputs; none changed. Import/root/path and
source verification records are retained alongside the original test bytes.

The actual TimeoutExpired streams report:

- Silver.Lexical built in 5.9 seconds.
- Silver.CertificateWitness built in 4.9 seconds.
- Silver.Admission built in 5.9 seconds.
- Silver.Cursor built in 11 seconds.
- Silver.OutputProfileBodySource built in 1.4 seconds.

SourceLexer was first sampled at 46.2 seconds after the fixture Python process
started, versus Lake first sampled at 3.2 seconds. No line-chunk compiler
process appeared before the timeout. The five completed module object families
and partial workspace were archived by a reporting-only unittest result
callback before the fixture's own cleanup. This is a point-in-time snapshot;
SourceLexer still existed at the callback and is not a complete frozen build.
The retained exception's stdout/stderr are the actual original TimeoutExpired
bytes, not reconstructed log text.

After the original fixture process exited, its SourceLexer descendant was
already complete and was reaped by the observer with wait status zero. The
observer sent no signal. The fixture's original cleanup emptied its scoped
temporary directory, all diagnostic descendants exited, and the managed worker
was released. A descendant's later zero exit does not complete the killed Lake
build or the omitted audit/edit cases. Minimum observed available memory was
50.95 GiB; no contention root cause is inferred from that fact.

Local distribution placement materially improved previously measured import
cost, but this real unchanged fixture still failed. No repeat or further test
was launched. The next authorized work is read-only assessment of this fixture's
watchdog provenance and correctness requirement, with any bounded repair only
prepared for coordinator review. Current constraints still forbid changing or
executing a different timeout. Complete failed outcomes remain preserved.

Selected reviewer setting remains GPT-6 Astra / Extra High with independent
runtime telemetry unavailable. No publication, live-install change or CLI
memory update was made.
