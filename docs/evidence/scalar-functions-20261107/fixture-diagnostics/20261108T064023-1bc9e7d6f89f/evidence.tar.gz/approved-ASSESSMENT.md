# #298 unchanged original fixture with validated local tools — assessment only

No test root, selector, temporary root or test process has been created.

## Concrete route

Use a fresh Lean-only test root, proposed
`/tmp/silver-lean-fixture-root-298-20261108`, separate from the authenticated
installation and all active checkouts. Copy these exact current bytes:

- Complete tests/test_lean_modules.py (SHA256 cb287c6dc17b7955edeb701775cc04ca4f92ede68a4393d7d77acd6b5ee67657).
- All nine current scripts/*.py files, including check_lean.py,
  bootstrap_lean.py, platforms.py and run_history.py. No helper is modified.
- proof/lakefile.lean, proof/lean-toolchain, proof/generate_source_certificate.py.
- The seven production files Lexical, Admission, Cursor, SourceLexer,
  CertificateWitness, OutputProfileBodySource and AxiomAudit under proof/Silver.

Compare each against the retained failed-fixture/current governed input hashes;
retain all copied-input hashes. Extra proof modules and native binary inputs are
not read by this selected method. Do not copy any .lake or project proof object.
Create only this new root's `.tools/linux-x86_64/lean` selector as a symlink to
`/tmp/silver-certificate-witness-local-298-20261108/.tools/linux-x86_64/lean`.
It shares the already authenticated native installation read-only and changes
no existing selector. Revalidate complete distribution identities and the
resolved executable/library paths. No second Lean install, native bootstrap,
or native compiler rebuild is required: this selected fixture invokes Lean
and its generator, not a moved Silver native binary.

The unchanged test computes ROOT from its own __file__, while copied
platforms.py computes its ROOT from its own __file__. check_lean imports that
ROOT and derives PROOF normally. Thus the selected test and all helpers resolve
to the new root without any external ROOT/PROOF monkeypatch. The fixture's own
existing narrow mock context for synthetic generation remains unchanged.
The launcher should assert module.__file__, ROOT, PROOF, native host key and
resolved Lean selectors before running the selected test. Importing helpers
alone does not launch proofs. Record these observations and reject any imported
repository helper outside the copied root.

Run the original ID with normal unittest execution:
`test_lean_modules.LeanModuleTests.test_output_body_chunks_reuse_objects_across_content_and_occurrence_edits`.
The launcher uses a fresh Python process, cwd at the copied root, and the
recorded pre-Alire environment. It can use standard discovery with the exact
file/method selector, or a reporting-only TextTestResult subclass that retains
TimeoutExpired streams and snapshots test.root inside addError before original
cleanup. Such reporting must not patch the fixture method, assertions, timeout,
subprocess API or cleanup behavior. Preserve one test/zero skips as the success
criterion; the original complete method then exercises audit and all variants.

## Temporary workspace and managed ownership

The recorded original TMPDIR/TMP/TEMP values were all absent; the failing
workspace was `/tmp/silver lean modules-p7o7i_nk`. /tmp is measured writable root
overlay, not the repository's virtiofs mount. The existing fixture creates its
own TemporaryDirectory and a tool-selector symlink inside it, prepares source
and generated candidates there, then performs its unchanged builds/audits.

Do not lease all of /tmp. Proposed explicit scope is a new
`/tmp/silver-lean-fixture-temporaries-298-20261108` on that same measured overlay,
passed as TMPDIR only for the fixture process. This is an explicit temporary
path change, not an assertion of identical inherited environment. It preserves
the filesystem class and original TemporaryDirectory naming/cleanup logic,
while giving the managed runner an exact exclusive writable root. Retain both
the original unset variables and the new scoped TMPDIR value. Do not silently
apply this change; it is part of the proposed coordinator-reviewed route.

The managed command remains regression `scripts/dev.py tool --jobs 1`, with
exclusive workspace declarations for the new test root, scoped TMPDIR and
reporting scratch/results, plus declared copied test/scripts/proof inputs,
launcher and the complete authenticated installed distribution. This keeps the
shared worker pool and ledger; running dev.py from a detached non-Git test root
would create a different ledger and is not proposed. The regression context
lease is the already authorized tool wrapper, not a native installation move.

The test source retains LEAN_NUM_THREADS=1, silverThreads=1,
silverMemoryMb=2048, warningAsError, all original `--rehash --reconfigure`
build commands, the audit -j1/-M2048 settings, every assertion and the original
60-second limit on each Lake invocation. No profiler flags enter this actual
fixture run. The entire fixture has multiple invocations; do not invent a
60-second outer limit on the whole method. On timeout, retain actual exception
streams and source/objects before original cleanup if reporting can do so, stop
without retry, and preserve the failure. Any orphan cleanup must be confined to
the new verified process/session tree.

## Whether the cold initial build fits 60 seconds

It is not established and remains a substantial risk. The exact graph contains
17 modules: seven copied production modules, Independent, eight line chunks and
the certificate aggregator. Ten separate module compilations include the
CertificateWitness meta-import closure (the helper itself, eight chunks and
the aggregator); AxiomAudit additionally imports Lean. Each native compiler
process has its own import environment. The Lexical -> Admission -> Cursor ->
SourceLexer chain, source binding, independent module, proof work and forced
Lake configuration add cost.

The local witness observation had 2.91s of imports and 4.836s total. Merely using
2.91s as a rough representative for those ten import closures already suggests
about 29s, before the other modules and configuration. This is not a lower bound
or forecast: closures, paths, source/output storage, profiler overhead and
scheduling differ. The old configuration-only measurement was on the original
installation; no local configuration measurement exists. Consequently, the
rough serial total could still exceed 60 seconds and there is no evidence-based
promise of a pass. The observed storage improvement and unchanged artifact
identity give a concrete reason for one real original-fixture attempt; they do
not justify a deadline increase or acceptance of a timeout.

The smallest action toward actual required validation is coordinator review of
this isolated route, including its explicit TMPDIR scope, followed—only if
authorized—by exactly one unchanged full method. No further intermediate profile
or repeat of the already measured initial build is necessary to learn whether
the real method now fits. If it times out, record the observed failing phase
and reassess; do not infer a source defect, silently relax the fixture or repeat
it blindly. All later assurance and the separate symlink-TMPDIR fixture remain
outside this one method's claim.
