"""Run exactly the unchanged fixture; observe unittest results without patching it."""
import hashlib
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import time
import traceback
import unittest

CASE = Path(__file__).resolve().parents[1]
RESULTS = CASE / 'results'
ROOT = Path('/tmp/silver-lean-fixture-root-298-20261108')
TEMPS = Path('/tmp/silver-lean-fixture-temporaries-298-20261108')
TOOLS = Path('/tmp/silver-certificate-witness-local-298-20261108/.tools/linux-x86_64/lean')
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tests'))
from scripts import check_lean, platforms, bootstrap_lean, run_history
import test_lean_modules


def write(name, value):
    (RESULTS / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


modules = {m.__name__: str(Path(m.__file__).resolve())
           for m in [check_lean, platforms, bootstrap_lean, run_history, test_lean_modules]}
assert all(Path(p).is_relative_to(ROOT) for p in modules.values())
assert test_lean_modules.ROOT == ROOT and platforms.ROOT == ROOT and check_lean.ROOT == ROOT
assert check_lean.PROOF == ROOT / 'proof'
native = platforms.native_layout(ROOT)
assert native.key == 'linux-x86_64' and native.lean.resolve() == TOOLS.resolve()
assert (native.lean / 'bin/lake').is_file()
assert Path(tempfile.gettempdir()).resolve() == TEMPS
write('fixture-import-paths.json', {'modules': modules, 'test_ROOT': str(test_lean_modules.ROOT),
    'platforms_ROOT': str(platforms.ROOT), 'check_lean_ROOT': str(check_lean.ROOT),
    'check_lean_PROOF': str(check_lean.PROOF), 'native_key': native.key,
    'selected_tools': str(native.lean), 'resolved_tools': str(native.lean.resolve()),
    'TMPDIR': os.environ.get('TMPDIR'), 'TMP': os.environ.get('TMP'), 'TEMP': os.environ.get('TEMP'),
    'effective_temp_directory': tempfile.gettempdir(), 'fixture_monkeypatched': False,
    'test_file_sha256': digest(ROOT / 'tests/test_lean_modules.py')})


class RecordingResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.observations = []
        self.reporting_errors = []

    def observe(self, test, label, err=None, subtest=None):
        try:
            root = getattr(test, 'root', None)
            item = {'label': label, 'test_id': test.id(), 'monotonic_ns': time.monotonic_ns(),
                    'subtest': str(subtest) if subtest is not None else None,
                    'temporary_root': str(root) if root is not None else None}
            if root is not None and root.exists():
                assert root.resolve().is_relative_to(TEMPS)
                source = root / 'src/silver_output_profile.adb'
                if source.is_file():
                    item['source_sha256'] = digest(source)
                objects = root / '.silver/linux-x86_64/proof/.lake/build/lib/lean/Silver'
                item['object_hashes'] = {str(p.relative_to(objects)): {'sha256': digest(p),
                    'mtime_ns': p.stat().st_mtime_ns} for p in objects.glob('*')
                    if p.is_file() and any(p.name.endswith(s) for s in ('.olean', '.olean.private', '.olean.server'))}
                if err is not None:
                    archive = RESULTS / f'failure-workspace-{len(self.observations):02d}.tar.gz'
                    with tarfile.open(archive, 'w:gz', dereference=False) as tar:
                        for p in sorted(root.rglob('*')):
                            tar.add(p, arcname=str(p.relative_to(root)), recursive=False)
                    item['workspace_archive'] = archive.name
            if err is not None:
                exception = err[1]
                item['exception_type'] = type(exception).__name__
                item['exception'] = str(exception)
                item['traceback'] = ''.join(traceback.format_exception(*err))
                if isinstance(exception, subprocess.TimeoutExpired):
                    item['timeout_seconds'] = exception.timeout
                    item['command'] = exception.cmd
                    for name, value in [('stdout', exception.stdout), ('stderr', exception.stderr)]:
                        if value is not None:
                            output = value if isinstance(value, bytes) else value.encode()
                            filename = f'exception-{len(self.observations):02d}-{name}.bin'
                            (RESULTS / filename).write_bytes(output)
                            item[name] = {'file': filename, 'bytes': len(output), 'original_type': type(value).__name__}
            self.observations.append(item)
            write('fixture-observations.json', self.observations)
        except Exception as failure:
            self.reporting_errors.append({'type': type(failure).__name__, 'message': str(failure)})
            write('reporting-errors.json', self.reporting_errors)

    def startTest(self, test):
        write('fixture-start.json', {'test_id': test.id(), 'monotonic_ns': time.monotonic_ns(), 'utc_ns': time.time_ns()})
        super().startTest(test)

    def addError(self, test, err):
        self.observe(test, 'error', err)
        super().addError(test, err)

    def addFailure(self, test, err):
        self.observe(test, 'failure', err)
        super().addFailure(test, err)

    def addSubTest(self, test, subtest, err):
        self.observe(test, 'subtest-success' if err is None else 'subtest-failure', err, subtest)
        super().addSubTest(test, subtest, err)


identifier = 'test_lean_modules.LeanModuleTests.test_output_body_chunks_reuse_objects_across_content_and_occurrence_edits'
suite = unittest.defaultTestLoader.loadTestsFromName(identifier)
assert suite.countTestCases() == 1
start = time.monotonic_ns()
result = unittest.TextTestRunner(stream=sys.stdout, verbosity=2, resultclass=RecordingResult).run(suite)
summary = {'test_id': identifier, 'tests_run': result.testsRun, 'errors': len(result.errors),
           'failures': len(result.failures), 'skips': len(result.skipped),
           'passed': result.wasSuccessful() and result.testsRun == 1 and not result.skipped,
           'duration_seconds': (time.monotonic_ns() - start) / 1e9,
           'successful_subtests': sum(o['label'] == 'subtest-success' for o in result.observations),
           'reporting_errors': result.reporting_errors,
           'assertions_options_deadlines_and_cleanup_unchanged': True}
write('fixture-result.json', summary)
print(json.dumps(summary, sort_keys=True), flush=True)
sys.exit(0 if summary['passed'] and not result.reporting_errors else 1)
