"""One managed, isolated original-fixture execution; retain its actual result."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import time
import signal

CASE = Path(__file__).resolve().parents[1]
FROZEN, RESULTS = CASE / 'frozen-inputs', CASE / 'results'
ROOT = Path('/tmp/silver-lean-fixture-root-298-20261108')
TEMPS = Path('/tmp/silver-lean-fixture-temporaries-298-20261108')
TOOLS = Path('/tmp/silver-certificate-witness-local-298-20261108/.tools/linux-x86_64/lean')


def digest(p):
    with Path(p).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def write(name, value):
    (RESULTS / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def event(name, **fields):
    row = {'event': name, 'monotonic_ns': time.monotonic_ns(), 'utc_ns': time.time_ns(), **fields}
    with (RESULTS / 'observer-events.jsonl').open('a') as stream:
        stream.write(json.dumps(row, sort_keys=True) + '\n')


def proc_stat(pid):
    raw = Path(f'/proc/{pid}/stat').read_text()
    a = raw[raw.rfind(')') + 2:].split()
    return {'pid': pid, 'ppid': int(a[1]), 'sid': int(a[3]), 'state': a[0],
            'start_ticks': int(a[19]), 'utime_ticks': int(a[11]), 'stime_ticks': int(a[12]),
            'rss_pages': int(a[21])}


def members(sid):
    found = []
    for p in Path('/proc').iterdir():
        if p.name.isdecimal():
            try:
                row = proc_stat(int(p.name))
                if row['sid'] == sid:
                    found.append(row)
            except (OSError, ValueError, IndexError):
                pass
    return found


def inventory(root):
    result = {}
    for directory, dirs, files in os.walk(root, followlinks=False):
        for name in sorted(dirs + files):
            p = Path(directory) / name
            s = p.lstat(); row = {'mode': stat.S_IMODE(s.st_mode)}
            if p.is_symlink():
                row.update(type='symlink', target=os.readlink(p))
            elif p.is_file():
                row.update(type='file', bytes=s.st_size, sha256=digest(p))
            elif p.is_dir():
                row.update(type='directory')
            else:
                raise RuntimeError(f'Unexpected distribution entry {p}')
            result[str(p.relative_to(root))] = row
    return result


assert not ROOT.exists() and not ROOT.is_symlink() and not TEMPS.exists() and not TEMPS.is_symlink()
assert not RESULTS.exists(), 'Refuse repeated execution'
RESULTS.mkdir()
for name, expected in json.loads((FROZEN / 'snapshot-sha256.json').read_text()).items():
    assert digest(FROZEN / name) == expected, name
expected_distribution = json.loads((FROZEN / 'expected-distribution-inventory.json').read_text())
actual_distribution = inventory(TOOLS)
assert actual_distribution == expected_distribution, 'Complete installed distribution identity differs'
write('distribution-verification.json', {'entries': len(actual_distribution), 'all_entries_match': True,
                                      'root': str(TOOLS), 'expected_inventory_sha256': digest(FROZEN / 'expected-distribution-inventory.json')})
ROOT.mkdir(); TEMPS.mkdir(mode=0o700)
for name in ['scripts', 'tests', 'proof/Silver', '.tools/linux-x86_64']:
    (ROOT / name).mkdir(parents=True, exist_ok=True)
for p in (FROZEN / 'scripts').glob('*.py'):
    shutil.copyfile(p, ROOT / 'scripts' / p.name)
shutil.copyfile(FROZEN / 'test_lean_modules.py', ROOT / 'tests/test_lean_modules.py')
for p in (FROZEN / 'proof').rglob('*'):
    if p.is_file():
        shutil.copyfile(p, ROOT / 'proof' / p.relative_to(FROZEN / 'proof'))
(ROOT / '.tools/linux-x86_64/lean').symlink_to(TOOLS, target_is_directory=True)
inputs = {str(p.relative_to(ROOT)): digest(p) for p in ROOT.rglob('*') if p.is_file() and '.tools' not in p.parts}
write('copied-inputs-before.json', inputs)
env = json.loads((FROZEN / 'private-inherited-environment.json').read_text())
assert not any(env.get(k) for k in ['TMPDIR', 'TMP', 'TEMP'])
env['TMPDIR'] = str(TEMPS)
visible = {'PATH', 'TMPDIR', 'TMP', 'TEMP', 'LANG', 'LC_ALL'}
write('fixture-environment.json', {k: {'value': v} if k in visible or k.startswith(('LEAN', 'LAKE', 'ELAN'))
      else {'sha256': hashlib.sha256(v.encode()).hexdigest()} for k, v in sorted(env.items())})
libc = ctypes.CDLL(None, use_errno=True)
if libc.prctl(36, 1, 0, 0, 0) != 0:
    raise OSError(ctypes.get_errno(), 'cannot enable owned-child subreaping')
command = ['/usr/bin/python3', '-B', str(CASE / 'driver/fixture_child.py')]
write('fixture-command.json', {'argv': command, 'cwd': str(ROOT), 'outer_timeout': None,
      'original_per_Lake_timeout_seconds': 60, 'source_and_assertions_unchanged': True})
seen = set(); first_workspace = None; started = time.monotonic_ns()
with (RESULTS / 'unittest-stdout.bin').open('wb') as out, (RESULTS / 'unittest-stderr.bin').open('wb') as err:
    child = subprocess.Popen(command, cwd=ROOT, env=env, stdout=out, stderr=err, start_new_session=True)
    assert os.getsid(child.pid) == child.pid
    event('fixture-process-start', pid=child.pid, sid=child.pid)
    while child.poll() is None:
        rows = members(child.pid)
        for row in rows:
            identity = (row['pid'], row['start_ticks'])
            if identity not in seen:
                seen.add(identity)
                try:
                    row['cmdline'] = Path(f"/proc/{row['pid']}/cmdline").read_bytes().replace(b'\0', b' ').decode(errors='replace')
                except OSError:
                    row['cmdline'] = '<exited before command read>'
                event('process-first-seen', **row)
        event('process-sample', processes=rows, loadavg=Path('/proc/loadavg').read_text(),
              memavailable_kib=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable'))))
        if first_workspace is None:
            for candidate in TEMPS.glob('silver lean modules-*'):
                proof = candidate / '.silver/linux-x86_64/proof'
                if (proof / '.lake/config/0/lakefile.olean.trace').exists():
                    retained = json.loads((FROZEN / 'prepared-initial-build-workspace-inventory.json').read_text())['files']
                    comparison = []
                    for name, value in retained.items():
                        if '/.lake/' in name:
                            continue
                        p = candidate / name
                        if p.is_file():
                            actual = digest(p)
                            comparison.append({'path': name, 'sha256': actual, 'expected_sha256': value['sha256'], 'matches': actual == value['sha256']})
                    if len(comparison) == 19:
                        first_workspace = str(candidate)
                        write('original-prepared-fixture-comparison.json', comparison)
                        event('initial-workspace-captured', path=first_workspace, all_19_match=all(x['matches'] for x in comparison))
        time.sleep(1)
    returncode = child.wait()
# Clean up only verified surviving members of this already-completed fixture session.
# No outer execution deadline or signal is applied while the original fixture runs.
while True:
    remaining = members(child.pid)
    if not remaining:
        break
    for row in remaining:
        try:
            current = proc_stat(row['pid'])
            if current['sid'] == child.pid and current['start_ticks'] == row['start_ticks'] and row['state'] != 'Z':
                os.kill(row['pid'], signal.SIGKILL)
                event('post-fixture-owned-descendant-cleanup', pid=row['pid'], start_ticks=row['start_ticks'], sid=child.pid)
            if row['ppid'] == os.getpid():
                reaped, status = os.waitpid(row['pid'], os.WNOHANG)
                if reaped:
                    event('owned-descendant-reaped', pid=reaped, wait_status=status)
        except (OSError, ChildProcessError):
            pass
    time.sleep(0.1)
after = {name: digest(ROOT / name) for name in inputs}
write('copied-inputs-after.json', after)
assert inputs == after
assert inventory(TOOLS) == expected_distribution
fixture = json.loads((RESULTS / 'fixture-result.json').read_text()) if (RESULTS / 'fixture-result.json').exists() else None
summary = {'returncode': returncode, 'fixture_result': fixture,
           'duration_seconds': (time.monotonic_ns() - started) / 1e9,
           'copied_inputs_unchanged': True, 'complete_distribution_unchanged': True,
           'no_remaining_fixture_descendants': True, 'first_workspace': first_workspace,
           'remaining_temporary_entries': [str(p) for p in TEMPS.iterdir()]}
write('summary.json', summary)
print(json.dumps(summary, sort_keys=True), flush=True)
if first_workspace is None or not all(x['matches'] for x in json.loads((RESULTS / 'original-prepared-fixture-comparison.json').read_text())):
    raise RuntimeError('Initial 19-file comparison was unavailable or mismatched')
sys.exit(returncode)
