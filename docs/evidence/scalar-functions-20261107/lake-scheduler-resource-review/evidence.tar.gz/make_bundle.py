from pathlib import Path
import gzip,hashlib,io,json,tarfile
p=Path(__file__).resolve().parent
excluded={'manifest.json','shareable-evidence.tar.gz','shareable-evidence.json'}
files=sorted(f for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts and str(f.relative_to(p)) not in excluded)
entries=[{'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files]
(p/'manifest.json').write_text(json.dumps(entries,indent=2)+'\n')
files.append(p/'manifest.json')
with (p/'shareable-evidence.tar.gz').open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for f in sorted(files):
    b=f.read_bytes();m=tarfile.TarInfo(str(f.relative_to(p)));m.size=len(b);m.mtime=0;m.mode=0o644
    tar.addfile(m,io.BytesIO(b))
with tarfile.open(p/'shareable-evidence.tar.gz') as tar:
 assert set(tar.getnames())=={str(f.relative_to(p)) for f in files}
 for f in entries:
  b=tar.extractfile(f['path']).read();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
 assert tar.extractfile('manifest.json').read()==(p/'manifest.json').read_bytes()
b=(p/'shareable-evidence.tar.gz').read_bytes()
info={'bundle':'shareable-evidence.tar.gz','members':len(files),'indexed_payloads':len(entries),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'scope':'Bounded read-only Lake scheduling-hold assessment for active run 20261108T094147-fb5330310904; no signals or process-control experiment.'}
(p/'shareable-evidence.json').write_text(json.dumps(info,indent=2)+'\n')
print(json.dumps(info,indent=2))
