"""Capture /proc and pinned scheduler source without signals or tool execution."""
from pathlib import Path
import datetime,gzip,hashlib,json,os,shutil,subprocess
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]/'scalar-functions-source-integration-298'
RUN=Path('/home/canto/src/github.com/berkeleynerd/silver/.git/silver-runs/linux-x86_64/78cde64c3e47f2cb/runs/20261108T094147-fb5330310904')
def write(n,obj):(OUT/n).write_text(json.dumps(obj,indent=2)+'\n')
def readstat(p):
 s=(p/'stat').read_text();a=s[s.rfind(')')+2:].split()
 return {'state':a[0],'ppid':int(a[1]),'pgrp':int(a[2]),'sid':int(a[3]),'utime_ticks':int(a[11]),'stime_ticks':int(a[12]),'threads':int(a[17]),'start_ticks':int(a[19])}
ps={}
for p in Path('/proc').iterdir():
 if not p.name.isdecimal():continue
 try:ps[int(p.name)]=readstat(p)
 except OSError:pass
owned={691697};previous=set()
while previous!=owned:
 previous=set(owned);owned|={p for p,v in ps.items() if v['ppid'] in owned}
results=[]
for pid in sorted(owned|{691106}):
 p=Path('/proc')/str(pid)
 try:
  rec={'pid':pid,**readstat(p),'command':(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(),'cwd':os.readlink(p/'cwd'),'exe':os.readlink(p/'exe')}
  rec['status']={l.split(':',1)[0]:l.split(':',1)[1].strip() for l in (p/'status').read_text().splitlines() if l.startswith(('Name:','State:','PPid:','VmRSS:','VmHWM:','VmSize:','VmSwap:','Threads:','Cpus_allowed_list:'))}
  rec['fds']={f.name:os.readlink(f) for f in (p/'fd').iterdir()}
  rec['threads_snapshot']=[]
  for t in (p/'task').iterdir():
   try:rec['threads_snapshot'].append({'tid':int(t.name),**readstat(t),'wchan':(t/'wchan').read_text().strip()})
   except OSError:pass
  rec['limits']=(p/'limits').read_text()
  rec['lean_num_threads']=next((x.split('=',1)[1] for x in (p/'environ').read_bytes().decode().split('\0') if x.startswith('LEAN_NUM_THREADS=')),None)
  results.append(rec)
 except OSError as e:results.append({'pid':pid,'error':str(e)})
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
snap={'utc':now,'proc_scope':'Lake 691697, current descendants and Python 691106; no native process mutation or inspection required','clock_ticks_per_second':os.sysconf('SC_CLK_TCK'),'meminfo':{l.split(':')[0]:l.split(':')[1].strip() for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith(('MemTotal:','MemAvailable:','SwapTotal:','SwapFree:'))},'processes':results}
write('snapshot-'+now.replace(':','').split('.')[0]+'.json',snap)
events=[json.loads(l) for l in (RUN/'events.jsonl').read_text().splitlines()]
start=next(e for e in events if e['event']=='started');pre=next(e for e in events if e['event']=='preflight')
write('managed-context.json',{'run_id':start['run_id'],'start':{k:start[k] for k in ['utc','pid','workers','requested_workers','available_cpus','reason','resources','scope']},'configuration':start['inputs']['configuration'],'preflight':pre,'phases':[e for e in events if e['event'] in ('phase_started','phase_finished','finished')]})
files=['proof/lean-toolchain','proof/lakefile.lean','scripts/check_lean.py','scripts/run_history.py','.tools/linux-x86_64/lean/src/lean/Init/System/IO.lean','.tools/linux-x86_64/lean/src/lean/lake/Lake/Util/Proc.lean','.tools/linux-x86_64/lean/src/lean/lake/Lake/Build/Actions.lean','.tools/linux-x86_64/lean/src/lean/lake/Lake/Build/Common.lean','.tools/linux-x86_64/lean/src/lean/lake/Lake/Build/Module.lean','.tools/linux-x86_64/lean/src/lean/lake/Lake/Build/Job/Monad.lean']
identities=[]
for f in files:
 b=(ROOT/f).read_bytes();dest=OUT/'source'/f.lstrip('.');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 identities.append({'source':str(ROOT/f),'retained':str(dest.relative_to(OUT)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
for f in ['.tools/linux-x86_64/lean/bin/lake','.tools/linux-x86_64/lean/bin/lean']:
 b=(ROOT/f).read_bytes();h=hashlib.sha256(b).hexdigest();assert h==pre['tools_sha256'][f]
 identities.append({'source':str(ROOT/f),'bytes':len(b),'sha256':h,'matches_managed_preflight':True})
write('source-identities.json',identities)
log=(ROOT/'.silver/linux-x86_64/lean-proof.log').read_bytes();(OUT/'lean-log-snapshot.gz').write_bytes(gzip.compress(log,mtime=0))
write('context.json',{'utc':now,'integration_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'parser_sha256':hashlib.sha256((ROOT/'src/silver_output_profile.adb').read_bytes()).hexdigest(),'log_snapshot_bytes':len(log),'log_snapshot_sha256':hashlib.sha256(log).hexdigest(),'scope':'Read-only assessment: no process signals, proof/test commands, config/source changes, experiments, lease or cache mutation.'})
print(json.dumps({'utc':now,'memory':snap['meminfo'],'processes':[{'pid':r['pid'],'command':r.get('command'),'rss':r.get('status',{}).get('VmRSS'),'threads':r.get('status',{}).get('Threads'),'LEAN_NUM_THREADS':r.get('lean_num_threads')} for r in results],'retained_sources':len(files),'tool_hashes_match':True},indent=2))
