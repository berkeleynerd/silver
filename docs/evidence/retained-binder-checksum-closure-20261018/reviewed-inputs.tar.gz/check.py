"""Replay retained counters and finite arithmetic for the checksum transfer note."""
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def identity(raw):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}

def q(n):
    return 1 << (n - 1).bit_length()

def main():
    manifest = json.loads((ROOT / "manifest.json").read_text())
    for row in manifest["files"]:
        assert identity((ROOT / row["path"]).read_bytes()) == {k: row[k] for k in ("bytes", "sha256")}
    for tag in ("ada", "gcc"):
        corpus = json.loads((ROOT / ("inputs/" + tag + "-corpus-manifest.json")).read_text())
        assert corpus["commit"] == manifest["source_commit"]
        corpus_rows = {r["path"]: r for r in corpus["files"]}
        for row in manifest["files"]:
            name = row["path"].removeprefix("sources/")
            if name == row["path"] or name.startswith("gcc/ada/") != (tag == "ada"):
                continue
            key = name.removeprefix("gcc/ada/") if tag == "ada" else name
            assert {k: row[k] for k in ("bytes", "sha256")} == {k: corpus_rows[key][k] for k in ("bytes", "sha256")}
    assert (ROOT / "inputs/make_int_cst.bin").read_bytes()[0x10:0x18] == bytes.fromhex("8d3cf51000000089")
    assert (ROOT / "inputs/make_tree_vec.bin").read_bytes()[0xb:0x13] == bytes.fromhex("488d3cc518000000")
    assert (ROOT / "inputs/CONST_INT_code_size.bin").read_bytes() == b"\x10"
    assert (ROOT / "inputs/gen_rtx_CONST_INT.bin").read_bytes()[0x135:0x13a] == bytes.fromhex("bf21000000")
    summary = json.loads((ROOT / "inputs/output/capture/counter-summary.json").read_text())
    rows = [json.loads(s) for s in (ROOT / "inputs/output/capture/counter-events.jsonl").read_text().splitlines()]
    values = {k: v["initial"] for k, v in summary["specs"].items()}
    counts = {k: 0 for k in values}
    ggc = []
    for r in rows:
        k = r["counter"]
        assert r["old"] == values[k] and r["delta"] == r["new"] - r["old"]
        assert r["delta"] > 0 if k == "ggc_bytes" else r["delta"] in (-1, 1)
        values[k] = r["new"]
        counts[k] += 1
        if k == "ggc_bytes":
            ggc.append(r)
    for k in values:
        assert values[k] == summary["counters"][k]["current"]
        assert counts[k] == summary["counters"][k]["events"]
    cutoff = next(p for p in summary["phases"] if p["phase"] == "before_binder_translation")
    assert cutoff["values"]["ggc_bytes"] == 3550088
    assert cutoff["events"]["ggc_bytes"] == 39273
    assert sum(r["delta"] for r in ggc[:39273]) == 3550088
    assert len(ggc) == 50974 and sum(r["delta"] for r in ggc) == 4481000
    suffix = ggc[39273:]
    assert sum(r["delta"] >= 24 for r in suffix) == 10700
    assert sum(r["delta"] == 16 for r in ggc) == 3556
    assert max(r["delta"] for r in ggc[:39273]) == 131072
    source = (ROOT / "sources/gcc/hash-table.cc").read_text()
    primes = [int(s) for s in re.findall(r"\{\s*(\d+),", source.split("prime_tab[] = {")[1].split("};")[0])]
    small_primes = [p for p in primes if p <= 32749]
    next_prime = lambda n: next(p for p in primes if p >= n)
    threshold = lambda p: (3 * p + 3) // 4
    assert small_primes[-1] == 32749
    assert next_prime(1024) == 2039
    for p in small_primes:
        assert q(8*p) <= 33 * (threshold(p) - p//2)
        # No INSERT can raise m_n_elements above this threshold before
        # the next INSERT lookup resizes. Check every possible live count
        # at an expansion, including arbitrary tombstones and shrinkage.
        for live in range(threshold(p) + 1):
            n = next_prime(2*live) if (2*live > p or (8*live < p and p > 32)) else p
            assert 2*live <= n
            assert live + 1 <= threshold(n)
            if p < 32749:
                assert n <= 32749
    initial_p = max(p for p in primes if 8*p <= 131072)
    assert initial_p == 16381
    tree_extra_misses = 32
    insertion_budget = 10700 + tree_extra_misses
    initial_occupied = threshold(initial_p)
    assert initial_occupied == 12286
    assert initial_occupied + insertion_budget < threshold(32749)
    tree_array_bound = 33 * insertion_budget + q(8*32749)
    # Monotone RTL cache: every miss allocates one16-byte CONST_INT;
    # one changed value adds at most one unique key and one final growth.
    rtl_misses = 3556 + 1
    assert rtl_misses < threshold(8191)
    assert next_prime(2 * threshold(4093)) == 8191
    rtl_extra_array = q(8*8191)
    small_vector_each = q(24 + 8*251)
    assert small_vector_each == 2048
    extra_direct = tree_extra_misses*24 + 2*small_vector_each + 2*16
    correction = tree_array_bound + rtl_extra_array + extra_direct
    total = 4481000 + correction
    first_gc_threshold = 5 * 1024**2
    assert total < first_gc_threshold
    extra_array_events = insertion_budget // 2 + 1
    extra_events = extra_array_events + 1 + tree_extra_misses + 2 + 2
    event_bound = 50974 + extra_events
    assert event_bound < 65536
    base = 2**15
    max_direct = (base-1)**2
    assert 16**7 - 1 < max_direct
    assert max_direct == 1073676289
    assert 32768 * 16 < max_direct
    baseline = int("d02a2ed5", 16)
    assert baseline - baseline%16 > max_direct and baseline%16 != 0
    # Only this boundary can make UI_Add call UI_From_Int on an
    # indirect value; all earlier products/sums stay direct.
    rare_values = list(range(max_direct+1, (max_direct//16+1)*16))
    assert len(rare_values) == 14
    result = {
        "status": "Source derivation supplied for independent review; no new compiler execution",
        "model_effort": "GPT-6 Astra Max (named hash-lifetime escalation)",
        "native_executions": 0,
        "source_files_retained": sum(r["path"].startswith("sources/") for r in manifest["files"]),
        "baseline": {"events": len(ggc), "rounded_GGC_bytes": 4481000, "prefix_bytes": 3550088,
                     "suffix_allocations_at_least24": 10700, "whole16_byte_allocations": 3556},
        "tree_cache": {"extra_miss_allowance": tree_extra_misses, "suffix_miss_bound": insertion_budget,
                       "initial_capacity_bound": initial_p, "initial_occupied_bound": initial_occupied,
                       "maximum_capacity": 32749, "maximum_rounded_array": 262144,
                       "amortized_bytes_per_later_empty_insertion": 33,
                       "all_variant_suffix_arrays_bytes": tree_array_bound,
                       "all_variant_suffix_array_event_bound": extra_array_events},
        "rtl_cache": {"maximum_unique_keys": rtl_misses, "maximum_capacity": 8191,
                      "extra_array_bytes": rtl_extra_array},
        "direct_correction_bytes": extra_direct,
        "total_correction_bytes": correction,
        "universal_rounded_GGC_bytes_bound_subject_to_reviewed_source_projection": total,
        "first_collection_threshold": first_gc_threshold,
        "margin_bytes": first_gc_threshold-total,
        "allocation_event_bound": event_bound,
        "maximum_rounded_request_bound": 262144,
        "Uint_scanner": {"row_bound": 2, "digit_bound": 6, "baseline_rows": 2, "baseline_digits": 6,
                         "extra_UI_From_Int_wrapper_bound": 1, "wrapper_request_bytes": 16,
                         "rare_cache_values_first": rare_values[0], "rare_cache_values_last": rare_values[-1]},
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
