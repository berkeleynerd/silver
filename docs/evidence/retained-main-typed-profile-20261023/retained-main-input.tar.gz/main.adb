with Silver_IO; with Silver_Arguments;
procedure Main is
   pragma SPARK_Mode (On);
   D : constant String := Silver_Arguments.First_Or_Default ("abc");
   N : Integer range 0 .. 9 := 1;
   E : String := D;
   C : constant Integer := N;
begin
   if not Silver_Arguments.Input_Is_Valid then
      N := 2;
      Silver_Arguments.Reject;
      N := (9 - N);
   elsif D'Length <= 3 then
      N := 5;
      E := D;
      Silver_IO.Put_Line (E & Integer'Image (N));
   else
      Silver_Arguments.Reject;
      N := 0;
   end if;
   if D'Length = 3 then
      for I in C .. N loop
         Silver_IO.Put (Integer'Image (I));
         N := (I - 1);
      end loop;
      Silver_IO.Put_Line (Integer'Image (N));
   end if;
end Main;
