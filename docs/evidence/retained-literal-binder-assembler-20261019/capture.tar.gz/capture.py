import hashlib, json, re, subprocess, time
from pathlib import Path
from datetime import datetime, timezone

BASE = Path(__file__).resolve().parent
plan = json.loads((BASE/'plan.json').read_bytes())
def identity(raw):
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

start = time.perf_counter()
result = dict(start_UTC=datetime.now(timezone.utc).isoformat(), plan=plan, cases=[])
spec = (BASE/'b__main~1.ads').read_bytes()
body = (BASE/'b__main~1.adb').read_bytes()
assert len(body) == 10343 and len(spec) == 19920
needle = b'u00001 : constant Version_32 := 16#d02a2ed5#;'
assert spec.count(needle) == 1
env = dict(PATH=str(Path(plan['compiler']).parent)+':/usr/bin:/bin', LC_ALL='C', TMPDIR=plan['TMPDIR'])
for tag, value in [('baseline',0xd02a2ed5), ('zero',0), ('signed_boundary',0x80000000), ('maximum',0xffffffff)]:
    stem = BASE/(tag+'-')
    directory = Path(str(stem)+'w'*(plan['source_directory_bytes']-len(str(stem))))
    directory.mkdir(exist_ok=False)
    assert len(str(directory)) == 113
    changed = spec.replace(needle, ('u00001 : constant Version_32 := 16#%08x#;' % value).encode())
    (directory/'b__main~1.ads').write_bytes(changed)
    (directory/'b__main~1.adb').write_bytes(body)
    compiler = [plan['compiler'], '-S', '-x', 'ada', '-gnatA', '-gnatA', '-gnatWb', '-gnatiw', '-gnatws',
                '-Wno-free-nonheap-object','-mtune=generic','-march=x86-64','-fsplit-wide-types',
                'b__main~1.adb','-o','b__main~1.s']
    assembler = [plan['assembler'], '--64', '-o', 'b__main~1.o', 'b__main~1.s']
    row = dict(tag=tag,checksum=value,cwd=str(directory),environment=env,
               source_identities={'body':identity(body),'spec':identity(changed)},commands=[])
    for name,argv in [('compiler',compiler),('assembler',assembler)]:
        before=time.perf_counter()
        process = subprocess.run(argv,cwd=directory,env=env,capture_output=True)
        (directory/(name+'.stdout')).write_bytes(process.stdout)
        (directory/(name+'.stderr')).write_bytes(process.stderr)
        row['commands'].append(dict(role=name,argv=argv,exit=process.returncode,elapsed_seconds=time.perf_counter()-before,
                                    stdout=identity(process.stdout),stderr=identity(process.stderr)))
        assert process.returncode == 0, (tag,name,process.stderr)
    for name in ['b__main~1.s','b__main~1.o','b__main~1.ali']:
        row[name]=identity((directory/name).read_bytes())
    asm=(directory/'b__main~1.s').read_bytes()
    lines=asm.split(b'\n')
    row['assembly_extents']=dict(lines=asm.count(b'\n'),longest_line=max(map(len,lines)),bytes=len(asm))
    found=re.search(rb'^mainB:\n([^\n]*\n)',asm,re.M)
    assert found,tag
    row['checksum_directive']=found.group(1).decode()
    result['cases'].append(row)
result.update(end_UTC=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.perf_counter()-start)
(BASE/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(cases=[dict(tag=r['tag'],checksum_directive=r['checksum_directive'],assembly=r['assembly_extents'],object=r['b__main~1.o']) for r in result['cases']],elapsed_seconds=result['elapsed_seconds']),indent=2))
