	.file	"b__main~1.adb"
	.text
	.align 2
	.globl	ada_main__Tsec_default_sized_stacksBIP
	.type	ada_main__Tsec_default_sized_stacksBIP, @function
ada_main__Tsec_default_sized_stacksBIP:
.LFB2:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -48(%rbp)
	movq	%rdx, -40(%rbp)
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	movslq	%eax, %r13
	movq	-40(%rbp), %rax
	movl	4(%rax), %edx
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	movq	-40(%rbp), %rax
	movl	4(%rax), %edx
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L5
	movq	-40(%rbp), %rax
	movl	4(%rax), %eax
	movslq	%eax, %rdx
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	cltq
	subq	%rax, %rdx
	leaq	1(%rdx), %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rcx, %rax
	movq	%rbx, %rdx
	shldq	$2, %rax, %rdx
	salq	$2, %rax
	addq	%rcx, %rax
	adcq	%rbx, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	shldq	$7, %rcx, %rbx
	salq	$7, %rcx
	addq	%rcx, %rax
	adcq	%rbx, %rdx
	shldq	$7, %rax, %rdx
	salq	$7, %rax
.L5:
	movq	-40(%rbp), %rax
	movl	4(%rax), %edx
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	movq	-40(%rbp), %rax
	movl	(%rax), %ebx
	movq	-40(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%r12d, %ebx
	jg	.L10
.L9:
	movq	-48(%rbp), %rdx
	movslq	%ebx, %rax
	subq	%r13, %rax
	imulq	$10320, %rax, %rax
	addq	%rdx, %rax
	movl	$10240, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_stackIP@PLT
	cmpl	%r12d, %ebx
	je	.L10
	addl	$1, %ebx
	jmp	.L9
.L10:
	addq	$24, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	ada_main__Tsec_default_sized_stacksBIP, .-ada_main__Tsec_default_sized_stacksBIP
	.align 2
	.type	ada_main__finalize_library, @function
ada_main__finalize_library:
.LFB3:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movzwl	ada__text_io_E(%rip), %eax
	subl	$1, %eax
	movw	%ax, ada__text_io_E(%rip)
	call	ada__text_io__finalize_spec@PLT
	movzwl	system__file_io_E(%rip), %eax
	subl	$1, %eax
	movw	%ax, system__file_io_E(%rip)
	call	system__file_io__finalize_body@PLT
	call	__gnat_reraise_library_exception_if_any@PLT
	nop
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.size	ada_main__finalize_library, .-ada_main__finalize_library
	.align 2
	.globl	adafinal
	.type	adafinal, @function
adafinal:
.LFB4:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movzbl	ada_main__is_elaborated(%rip), %eax
	xorl	$1, %eax
	testb	%al, %al
	jne	.L16
	movb	$0, ada_main__is_elaborated(%rip)
	call	__gnat_runtime_finalize@PLT
	call	system__standard_library__adafinal@PLT
	jmp	.L13
.L16:
	nop
.L13:
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	adafinal, .-adafinal
	.align 2
	.globl	adainit
	.type	adainit, @function
adainit:
.LFB5:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movzbl	ada_main__is_elaborated(%rip), %eax
	testb	%al, %al
	jne	.L20
	movb	$1, ada_main__is_elaborated(%rip)
	movl	$-1, __gl_main_priority(%rip)
	movl	$-1, __gl_time_slice_val(%rip)
	movb	$98, __gl_wc_encoding(%rip)
	movb	$32, __gl_locking_policy(%rip)
	movb	$32, __gl_queuing_policy(%rip)
	movb	$32, __gl_task_dispatching_policy(%rip)
	leaq	ada_main__local_priority_specific_dispatching(%rip), %rax
	movq	%rax, __gl_priority_specific_dispatching(%rip)
	movl	$0, __gl_num_specific_dispatching(%rip)
	movl	$-1, __gl_main_cpu(%rip)
	leaq	ada_main__local_interrupt_states(%rip), %rax
	movq	%rax, __gl_interrupt_states(%rip)
	movl	$0, __gl_num_interrupt_states(%rip)
	movl	$0, __gl_unreserve_all_interrupts(%rip)
	movl	$0, __gl_detect_blocking(%rip)
	movl	$-1, __gl_default_stack_size(%rip)
	call	ada_main___elabb@PLT
	movq	$10240, __gnat_default_ss_size(%rip)
	movl	$1, __gnat_binder_ss_count(%rip)
	leaq	ada_main__sec_default_sized_stacks(%rip), %rax
	movq	%rax, __gnat_default_ss_pool(%rip)
	movl	$1, %edi
	call	__gnat_runtime_initialize@PLT
	leaq	ada_main__finalize_library(%rip), %rax
	movq	%rax, __gnat_finalize_library_objects(%rip)
	call	ada__exceptions___elabs@PLT
	call	system__soft_links___elabs@PLT
	call	system__exception_table___elabb@PLT
	movzwl	system__exception_table_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, system__exception_table_E(%rip)
	call	ada__containers___elabs@PLT
	movzwl	ada__containers_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, ada__containers_E(%rip)
	call	ada__io_exceptions___elabs@PLT
	movzwl	ada__io_exceptions_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, ada__io_exceptions_E(%rip)
	call	ada__strings___elabs@PLT
	movzwl	ada__strings_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, ada__strings_E(%rip)
	call	ada__strings__maps___elabs@PLT
	movzwl	ada__strings__maps_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, ada__strings__maps_E(%rip)
	call	ada__strings__maps__constants___elabs@PLT
	movzwl	ada__strings__maps__constants_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, ada__strings__maps__constants_E(%rip)
	call	interfaces__c___elabs@PLT
	movzwl	interfaces__c_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, interfaces__c_E(%rip)
	call	system__exceptions___elabs@PLT
	movzwl	system__exceptions_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, system__exceptions_E(%rip)
	call	system__object_reader___elabs@PLT
	movzwl	system__object_reader_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, system__object_reader_E(%rip)
	call	system__dwarf_lines___elabs@PLT
	movzwl	system__dwarf_lines_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, system__dwarf_lines_E(%rip)
	call	system__os_lib___elabb@PLT
	movzwl	system__os_lib_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, system__os_lib_E(%rip)
	call	system__soft_links__initialize___elabb@PLT
	movzwl	system__soft_links__initialize_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, system__soft_links__initialize_E(%rip)
	movzwl	system__soft_links_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, system__soft_links_E(%rip)
	call	system__traceback__symbolic___elabb@PLT
	movzwl	system__traceback__symbolic_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, system__traceback__symbolic_E(%rip)
	movzwl	ada__exceptions_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, ada__exceptions_E(%rip)
	call	ada__strings__utf_encoding___elabs@PLT
	movzwl	ada__strings__utf_encoding_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, ada__strings__utf_encoding_E(%rip)
	call	ada__tags___elabs@PLT
	call	ada__tags___elabb@PLT
	movzwl	ada__tags_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, ada__tags_E(%rip)
	call	ada__strings__text_buffers___elabs@PLT
	movzwl	ada__strings__text_buffers_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, ada__strings__text_buffers_E(%rip)
	call	ada__streams___elabs@PLT
	movzwl	ada__streams_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, ada__streams_E(%rip)
	call	system__file_control_block___elabs@PLT
	movzwl	system__file_control_block_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, system__file_control_block_E(%rip)
	call	system__finalization_root___elabs@PLT
	movzwl	system__finalization_root_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, system__finalization_root_E(%rip)
	call	ada__finalization___elabs@PLT
	movzwl	ada__finalization_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, ada__finalization_E(%rip)
	call	system__file_io___elabb@PLT
	movzwl	system__file_io_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, system__file_io_E(%rip)
	call	ada__text_io___elabs@PLT
	call	ada__text_io___elabb@PLT
	movzwl	ada__text_io_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, ada__text_io_E(%rip)
	movzwl	silver_io_E(%rip), %eax
	addl	$1, %eax
	movw	%ax, silver_io_E(%rip)
	jmp	.L17
.L20:
	nop
.L17:
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE5:
	.size	adainit, .-adainit
	.align 2
	.globl	main
	.type	main, @function
main:
.LFB6:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$48, %rsp
	movl	%edi, -20(%rbp)
	movq	%rsi, -32(%rbp)
	movq	%rdx, -40(%rbp)
	leaq	__gnat_ada_main_program_name(%rip), %rax
	movq	%rax, -16(%rbp)
	movl	gnat_argc(%rip), %eax
	testl	%eax, %eax
	jne	.L22
	movl	-20(%rbp), %eax
	movl	%eax, gnat_argc(%rip)
	movq	-32(%rbp), %rax
	movq	%rax, gnat_argv(%rip)
.L22:
	movq	-40(%rbp), %rax
	movq	%rax, gnat_envp(%rip)
	leaq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	__gnat_initialize@PLT
	call	adainit
	call	_ada_main@PLT
	call	adafinal
	call	__gnat_finalize@PLT
	movl	gnat_exit_status(%rip), %eax
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE6:
	.size	main, .-main
	.section	.rodata
	.align 8
.LC0:
	.long	1
	.long	1
	.text
	.align 2
	.globl	ada_main___elabb
	.type	ada_main___elabb, @function
ada_main___elabb:
.LFB0:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	leaq	ada_main__sec_default_sized_stacks(%rip), %rdx
	leaq	.LC0(%rip), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	ada_main__Tsec_default_sized_stacksBIP
	nop
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE0:
	.size	ada_main___elabb, .-ada_main___elabb
	.globl	ada_main_E
	.data
	.align 2
	.type	ada_main_E, @object
	.size	ada_main_E, 2
ada_main_E:
	.zero	2
	.globl	mainB
	.section	.rodata
	.align 4
	.type	mainB, @object
	.size	mainB, 4
mainB:
	.zero	4
	.globl	system__standard_libraryB
	.align 4
	.type	system__standard_libraryB, @object
	.size	system__standard_libraryB, 4
system__standard_libraryB:
	.long	-1295013055
	.globl	system__standard_libraryS
	.align 4
	.type	system__standard_libraryS, @object
	.size	system__standard_libraryS, 4
system__standard_libraryS:
	.long	-256283132
	.globl	ada__strings__text_buffersB
	.align 4
	.type	ada__strings__text_buffersB, @object
	.size	ada__strings__text_buffersB, 4
ada__strings__text_buffersB:
	.long	-1576945467
	.globl	ada__strings__text_buffersS
	.align 4
	.type	ada__strings__text_buffersS, @object
	.size	ada__strings__text_buffersS, 4
ada__strings__text_buffersS:
	.long	-1479552869
	.globl	adaS
	.align 4
	.type	adaS, @object
	.size	adaS, 4
adaS:
	.long	1987616161
	.globl	ada__stringsS
	.align 4
	.type	ada__stringsS, @object
	.size	ada__stringsS, 4
ada__stringsS:
	.long	-422249930
	.globl	systemS
	.align 4
	.type	systemS, @object
	.size	systemS, 4
systemS:
	.long	-491271779
	.globl	system__exception_tableB
	.align 4
	.type	system__exception_tableB, @object
	.size	system__exception_tableB, 4
system__exception_tableB:
	.long	1172411998
	.globl	system__exception_tableS
	.align 4
	.type	system__exception_tableS, @object
	.size	system__exception_tableS, 4
system__exception_tableS:
	.long	1872543620
	.globl	system__soft_linksB
	.align 4
	.type	system__soft_linksB, @object
	.size	system__soft_linksB, 4
system__soft_linksB:
	.long	2141234584
	.globl	system__soft_linksS
	.align 4
	.type	system__soft_linksS, @object
	.size	system__soft_linksS, 4
system__soft_linksS:
	.long	-1005850401
	.globl	system__secondary_stackB
	.align 4
	.type	system__secondary_stackB, @object
	.size	system__secondary_stackB, 4
system__secondary_stackB:
	.long	865294934
	.globl	system__secondary_stackS
	.align 4
	.type	system__secondary_stackS, @object
	.size	system__secondary_stackS, 4
system__secondary_stackS:
	.long	-666513444
	.globl	ada__exceptionsB
	.align 4
	.type	ada__exceptionsB, @object
	.size	ada__exceptionsB, 4
ada__exceptionsB:
	.long	70610257
	.globl	ada__exceptionsS
	.align 4
	.type	ada__exceptionsS, @object
	.size	ada__exceptionsS, 4
ada__exceptionsS:
	.long	1735464933
	.globl	ada__exceptions__last_chance_handlerB
	.align 4
	.type	ada__exceptions__last_chance_handlerB, @object
	.size	ada__exceptions__last_chance_handlerB, 4
ada__exceptions__last_chance_handlerB:
	.long	-2051070473
	.globl	ada__exceptions__last_chance_handlerS
	.align 4
	.type	ada__exceptions__last_chance_handlerS, @object
	.size	ada__exceptions__last_chance_handlerS, 4
ada__exceptions__last_chance_handlerS:
	.long	-1054462965
	.globl	system__exceptionsS
	.align 4
	.type	system__exceptionsS, @object
	.size	system__exceptionsS, 4
system__exceptionsS:
	.long	-804096337
	.globl	system__exceptions__machineB
	.align 4
	.type	system__exceptions__machineB, @object
	.size	system__exceptions__machineB, 4
system__exceptions__machineB:
	.long	-1016616412
	.globl	system__exceptions__machineS
	.align 4
	.type	system__exceptions__machineS, @object
	.size	system__exceptions__machineS, 4
system__exceptions__machineS:
	.long	-1927460500
	.globl	system__exceptions_debugB
	.align 4
	.type	system__exceptions_debugB, @object
	.size	system__exceptions_debugB, 4
system__exceptions_debugB:
	.long	796715139
	.globl	system__exceptions_debugS
	.align 4
	.type	system__exceptions_debugS, @object
	.size	system__exceptions_debugS, 4
system__exceptions_debugS:
	.long	-759590450
	.globl	system__img_intS
	.align 4
	.type	system__img_intS, @object
	.size	system__img_intS, 4
system__img_intS:
	.long	1972886191
	.globl	system__storage_elementsS
	.align 4
	.type	system__storage_elementsS, @object
	.size	system__storage_elementsS, 4
system__storage_elementsS:
	.long	778640757
	.globl	system__tracebackB
	.align 4
	.type	system__tracebackB, @object
	.size	system__tracebackB, 4
system__tracebackB:
	.long	1551735840
	.globl	system__tracebackS
	.align 4
	.type	system__tracebackS, @object
	.size	system__tracebackS, 4
system__tracebackS:
	.long	1680686368
	.globl	system__traceback_entriesB
	.align 4
	.type	system__traceback_entriesB, @object
	.size	system__traceback_entriesB, 4
system__traceback_entriesB:
	.long	1600873606
	.globl	system__traceback_entriesS
	.align 4
	.type	system__traceback_entriesS, @object
	.size	system__traceback_entriesS, 4
system__traceback_entriesS:
	.long	715879953
	.globl	system__traceback__symbolicB
	.align 4
	.type	system__traceback__symbolicB, @object
	.size	system__traceback__symbolicB, 4
system__traceback__symbolicB:
	.long	1642598500
	.globl	system__traceback__symbolicS
	.align 4
	.type	system__traceback__symbolicS, @object
	.size	system__traceback__symbolicS, 4
system__traceback__symbolicS:
	.long	1043206659
	.globl	ada__containersS
	.align 4
	.type	ada__containersS, @object
	.size	ada__containersS, 4
ada__containersS:
	.long	396197160
	.globl	ada__exceptions__tracebackB
	.align 4
	.type	ada__exceptions__tracebackB, @object
	.size	ada__exceptions__tracebackB, 4
ada__exceptions__tracebackB:
	.long	1881120136
	.globl	ada__exceptions__tracebackS
	.align 4
	.type	ada__exceptions__tracebackS, @object
	.size	ada__exceptions__tracebackS, 4
ada__exceptions__tracebackS:
	.long	1206112931
	.globl	interfacesS
	.align 4
	.type	interfacesS, @object
	.size	interfacesS, 4
interfacesS:
	.long	-1861092927
	.globl	interfaces__cB
	.align 4
	.type	interfaces__cB, @object
	.size	interfaces__cB, 4
interfaces__cB:
	.long	-1179802022
	.globl	interfaces__cS
	.align 4
	.type	interfaces__cS, @object
	.size	interfaces__cS, 4
interfaces__cS:
	.long	164995303
	.globl	system__parametersB
	.align 4
	.type	system__parametersB, @object
	.size	system__parametersB, 4
system__parametersB:
	.long	805808623
	.globl	system__parametersS
	.align 4
	.type	system__parametersS, @object
	.size	system__parametersS, 4
system__parametersS:
	.long	1125737153
	.globl	system__bounded_stringsB
	.align 4
	.type	system__bounded_stringsB, @object
	.size	system__bounded_stringsB, 4
system__bounded_stringsB:
	.long	158890093
	.globl	system__bounded_stringsS
	.align 4
	.type	system__bounded_stringsS, @object
	.size	system__bounded_stringsS, 4
system__bounded_stringsS:
	.long	-1790252924
	.globl	system__crtlB
	.align 4
	.type	system__crtlB, @object
	.size	system__crtlB, 4
system__crtlB:
	.long	582089625
	.globl	system__crtlS
	.align 4
	.type	system__crtlS, @object
	.size	system__crtlS, 4
system__crtlS:
	.long	-1054734345
	.globl	system__dwarf_linesB
	.align 4
	.type	system__dwarf_linesB, @object
	.size	system__dwarf_linesB, 4
system__dwarf_linesB:
	.long	1908883483
	.globl	system__dwarf_linesS
	.align 4
	.type	system__dwarf_linesS, @object
	.size	system__dwarf_linesS, 4
system__dwarf_linesS:
	.long	43856560
	.globl	ada__charactersS
	.align 4
	.type	ada__charactersS, @object
	.size	ada__charactersS, 4
ada__charactersS:
	.long	1531337210
	.globl	ada__characters__handlingB
	.align 4
	.type	ada__characters__handlingB, @object
	.size	ada__characters__handlingB, 4
ada__characters__handlingB:
	.long	1972452739
	.globl	ada__characters__handlingS
	.align 4
	.type	ada__characters__handlingS, @object
	.size	ada__characters__handlingS, 4
ada__characters__handlingS:
	.long	1922876891
	.globl	ada__characters__latin_1S
	.align 4
	.type	ada__characters__latin_1S, @object
	.size	ada__characters__latin_1S, 4
ada__characters__latin_1S:
	.long	-840308179
	.globl	ada__strings__mapsB
	.align 4
	.type	ada__strings__mapsB, @object
	.size	ada__strings__mapsB, 4
ada__strings__mapsB:
	.long	-1702171339
	.globl	ada__strings__mapsS
	.align 4
	.type	ada__strings__mapsS, @object
	.size	ada__strings__mapsS, 4
ada__strings__mapsS:
	.long	-2019720207
	.globl	system__bit_opsB
	.align 4
	.type	system__bit_opsB, @object
	.size	system__bit_opsB, 4
system__bit_opsB:
	.long	-715161666
	.globl	system__bit_opsS
	.align 4
	.type	system__bit_opsS, @object
	.size	system__bit_opsS, 4
system__bit_opsS:
	.long	793011617
	.globl	system__unsigned_typesS
	.align 4
	.type	system__unsigned_typesS, @object
	.size	system__unsigned_typesS, 4
system__unsigned_typesS:
	.long	412989124
	.globl	ada__strings__maps__constantsS
	.align 4
	.type	ada__strings__maps__constantsS, @object
	.size	ada__strings__maps__constantsS, 4
ada__strings__maps__constantsS:
	.long	1546571373
	.globl	system__address_imageB
	.align 4
	.type	system__address_imageB, @object
	.size	system__address_imageB, 4
system__address_imageB:
	.long	-107935028
	.globl	system__address_imageS
	.align 4
	.type	system__address_imageS, @object
	.size	system__address_imageS, 4
system__address_imageS:
	.long	1130058919
	.globl	system__img_address_32S
	.align 4
	.type	system__img_address_32S, @object
	.size	system__img_address_32S, 4
system__img_address_32S:
	.long	-687267016
	.globl	system__img_address_64S
	.align 4
	.type	system__img_address_64S, @object
	.size	system__img_address_64S, 4
system__img_address_64S:
	.long	-97942854
	.globl	system__img_unsS
	.align 4
	.type	system__img_unsS, @object
	.size	system__img_unsS, 4
system__img_unsS:
	.long	-1175845517
	.globl	system__ioB
	.align 4
	.type	system__ioB, @object
	.size	system__ioB, 4
system__ioB:
	.long	552368803
	.globl	system__ioS
	.align 4
	.type	system__ioS, @object
	.size	system__ioS, 4
system__ioS:
	.long	2096447186
	.globl	system__mmapB
	.align 4
	.type	system__mmapB, @object
	.size	system__mmapB, 4
system__mmapB:
	.long	-514022552
	.globl	system__mmapS
	.align 4
	.type	system__mmapS, @object
	.size	system__mmapS, 4
system__mmapS:
	.long	1562090135
	.globl	ada__io_exceptionsS
	.align 4
	.type	ada__io_exceptionsS, @object
	.size	ada__io_exceptionsS, 4
ada__io_exceptionsS:
	.long	913904068
	.globl	system__mmap__os_interfaceB
	.align 4
	.type	system__mmap__os_interfaceB, @object
	.size	system__mmap__os_interfaceB, 4
system__mmap__os_interfaceB:
	.long	423325147
	.globl	system__mmap__os_interfaceS
	.align 4
	.type	system__mmap__os_interfaceS, @object
	.size	system__mmap__os_interfaceS, 4
system__mmap__os_interfaceS:
	.long	-213608987
	.globl	system__mmap__unixS
	.align 4
	.type	system__mmap__unixS, @object
	.size	system__mmap__unixS, 4
system__mmap__unixS:
	.long	2097666480
	.globl	system__os_libB
	.align 4
	.type	system__os_libB, @object
	.size	system__os_libB, 4
system__os_libB:
	.long	-2044947094
	.globl	system__os_libS
	.align 4
	.type	system__os_libS, @object
	.size	system__os_libS, 4
system__os_libS:
	.long	-597510333
	.globl	system__atomic_operations__test_and_setB
	.align 4
	.type	system__atomic_operations__test_and_setB, @object
	.size	system__atomic_operations__test_and_setB, 4
system__atomic_operations__test_and_setB:
	.long	-1798161115
	.globl	system__atomic_operations__test_and_setS
	.align 4
	.type	system__atomic_operations__test_and_setS, @object
	.size	system__atomic_operations__test_and_setS, 4
system__atomic_operations__test_and_setS:
	.long	1470951054
	.globl	system__atomic_operationsS
	.align 4
	.type	system__atomic_operationsS, @object
	.size	system__atomic_operationsS, 4
system__atomic_operationsS:
	.long	634696632
	.globl	system__atomic_primitivesB
	.align 4
	.type	system__atomic_primitivesB, @object
	.size	system__atomic_primitivesB, 4
system__atomic_primitivesB:
	.long	1429885342
	.globl	system__atomic_primitivesS
	.align 4
	.type	system__atomic_primitivesS, @object
	.size	system__atomic_primitivesS, 4
system__atomic_primitivesS:
	.long	-654905357
	.globl	system__case_utilB
	.align 4
	.type	system__case_utilB, @object
	.size	system__case_utilB, 4
system__case_utilB:
	.long	352004203
	.globl	system__case_utilS
	.align 4
	.type	system__case_utilS, @object
	.size	system__case_utilS, 4
system__case_utilS:
	.long	1011820791
	.globl	system__case_util_nssB
	.align 4
	.type	system__case_util_nssB, @object
	.size	system__case_util_nssB, 4
system__case_util_nssB:
	.long	-1953144028
	.globl	system__case_util_nssS
	.align 4
	.type	system__case_util_nssS, @object
	.size	system__case_util_nssS, 4
system__case_util_nssS:
	.long	-2015867465
	.globl	system__stringsB
	.align 4
	.type	system__stringsB, @object
	.size	system__stringsB, 4
system__stringsB:
	.long	627948517
	.globl	system__stringsS
	.align 4
	.type	system__stringsS, @object
	.size	system__stringsS, 4
system__stringsS:
	.long	2033568133
	.globl	system__object_readerB
	.align 4
	.type	system__object_readerB, @object
	.size	system__object_readerB, 4
system__object_readerB:
	.long	-1921671660
	.globl	system__object_readerS
	.align 4
	.type	system__object_readerS, @object
	.size	system__object_readerS, 4
system__object_readerS:
	.long	-299672444
	.globl	system__val_lliS
	.align 4
	.type	system__val_lliS, @object
	.size	system__val_lliS, 4
system__val_lliS:
	.long	-1320440656
	.globl	system__val_lluS
	.align 4
	.type	system__val_lluS, @object
	.size	system__val_lluS, 4
system__val_lluS:
	.long	2102164571
	.globl	system__val_utilB
	.align 4
	.type	system__val_utilB, @object
	.size	system__val_utilB, 4
system__val_utilB:
	.long	219743417
	.globl	system__val_utilS
	.align 4
	.type	system__val_utilS, @object
	.size	system__val_utilS, 4
system__val_utilS:
	.long	236727230
	.globl	system__exception_tracesB
	.align 4
	.type	system__exception_tracesB, @object
	.size	system__exception_tracesB, 4
system__exception_tracesB:
	.long	942600679
	.globl	system__exception_tracesS
	.align 4
	.type	system__exception_tracesS, @object
	.size	system__exception_tracesS, 4
system__exception_tracesS:
	.long	238002427
	.globl	system__wch_conB
	.align 4
	.type	system__wch_conB, @object
	.size	system__wch_conB, 4
system__wch_conB:
	.long	-48920009
	.globl	system__wch_conS
	.align 4
	.type	system__wch_conS, @object
	.size	system__wch_conS, 4
system__wch_conS:
	.long	1001712382
	.globl	system__wch_stwB
	.align 4
	.type	system__wch_stwB, @object
	.size	system__wch_stwB, 4
system__wch_stwB:
	.long	1546164594
	.globl	system__wch_stwS
	.align 4
	.type	system__wch_stwS, @object
	.size	system__wch_stwS, 4
system__wch_stwS:
	.long	379963135
	.globl	system__wch_cnvB
	.align 4
	.type	system__wch_cnvB, @object
	.size	system__wch_cnvB, 4
system__wch_cnvB:
	.long	2094415333
	.globl	system__wch_cnvS
	.align 4
	.type	system__wch_cnvS, @object
	.size	system__wch_cnvS, 4
system__wch_cnvS:
	.long	1031020686
	.globl	system__wch_jisB
	.align 4
	.type	system__wch_jisB, @object
	.size	system__wch_jisB, 4
system__wch_jisB:
	.long	-449257917
	.globl	system__wch_jisS
	.align 4
	.type	system__wch_jisS, @object
	.size	system__wch_jisS, 4
system__wch_jisS:
	.long	-2000469340
	.globl	system__soft_links__initializeB
	.align 4
	.type	system__soft_links__initializeB, @object
	.size	system__soft_links__initializeB, 4
system__soft_links__initializeB:
	.long	42389151
	.globl	system__soft_links__initializeS
	.align 4
	.type	system__soft_links__initializeS, @object
	.size	system__soft_links__initializeS, 4
system__soft_links__initializeS:
	.long	-1406235821
	.globl	system__stack_checkingB
	.align 4
	.type	system__stack_checkingB, @object
	.size	system__stack_checkingB, 4
system__stack_checkingB:
	.long	-2053524869
	.globl	system__stack_checkingS
	.align 4
	.type	system__stack_checkingS, @object
	.size	system__stack_checkingS, 4
system__stack_checkingS:
	.long	636017803
	.globl	ada__strings__utf_encodingB
	.align 4
	.type	ada__strings__utf_encodingB, @object
	.size	ada__strings__utf_encodingB, 4
ada__strings__utf_encodingB:
	.long	-1955199804
	.globl	ada__strings__utf_encodingS
	.align 4
	.type	ada__strings__utf_encodingS, @object
	.size	ada__strings__utf_encodingS, 4
ada__strings__utf_encodingS:
	.long	-907515497
	.globl	ada__strings__utf_encoding__stringsB
	.align 4
	.type	ada__strings__utf_encoding__stringsB, @object
	.size	ada__strings__utf_encoding__stringsB, 4
ada__strings__utf_encoding__stringsB:
	.long	-1149759675
	.globl	ada__strings__utf_encoding__stringsS
	.align 4
	.type	ada__strings__utf_encoding__stringsS, @object
	.size	ada__strings__utf_encoding__stringsS, 4
ada__strings__utf_encoding__stringsS:
	.long	-1201670986
	.globl	ada__strings__utf_encoding__wide_stringsB
	.align 4
	.type	ada__strings__utf_encoding__wide_stringsB, @object
	.size	ada__strings__utf_encoding__wide_stringsB, 4
ada__strings__utf_encoding__wide_stringsB:
	.long	-774771445
	.globl	ada__strings__utf_encoding__wide_stringsS
	.align 4
	.type	ada__strings__utf_encoding__wide_stringsS, @object
	.size	ada__strings__utf_encoding__wide_stringsS, 4
ada__strings__utf_encoding__wide_stringsS:
	.long	1450723215
	.globl	ada__strings__utf_encoding__wide_wide_stringsB
	.align 4
	.type	ada__strings__utf_encoding__wide_wide_stringsB, @object
	.size	ada__strings__utf_encoding__wide_wide_stringsB, 4
ada__strings__utf_encoding__wide_wide_stringsB:
	.long	-1028028061
	.globl	ada__strings__utf_encoding__wide_wide_stringsS
	.align 4
	.type	ada__strings__utf_encoding__wide_wide_stringsS, @object
	.size	ada__strings__utf_encoding__wide_wide_stringsS, 4
ada__strings__utf_encoding__wide_wide_stringsS:
	.long	-676383912
	.globl	ada__tagsB
	.align 4
	.type	ada__tagsB, @object
	.size	ada__tagsB, 4
ada__tagsB:
	.long	-549081384
	.globl	ada__tagsS
	.align 4
	.type	ada__tagsS, @object
	.size	ada__tagsS, 4
ada__tagsS:
	.long	-1719522630
	.globl	system__htableB
	.align 4
	.type	system__htableB, @object
	.size	system__htableB, 4
system__htableB:
	.long	893966706
	.globl	system__htableS
	.align 4
	.type	system__htableS, @object
	.size	system__htableS, 4
system__htableS:
	.long	1668190582
	.globl	system__string_hashB
	.align 4
	.type	system__string_hashB, @object
	.size	system__string_hashB, 4
system__string_hashB:
	.long	521846328
	.globl	system__string_hashS
	.align 4
	.type	system__string_hashS, @object
	.size	system__string_hashS, 4
system__string_hashS:
	.long	-1003810551
	.globl	silver_ioB
	.align 4
	.type	silver_ioB, @object
	.size	silver_ioB, 4
silver_ioB:
	.long	1721616303
	.globl	silver_ioS
	.align 4
	.type	silver_ioS, @object
	.size	silver_ioS, 4
silver_ioS:
	.long	-301707656
	.globl	silver_output_libcS
	.align 4
	.type	silver_output_libcS, @object
	.size	silver_output_libcS, 4
silver_output_libcS:
	.long	196891268
	.globl	ada__text_ioB
	.align 4
	.type	ada__text_ioB, @object
	.size	ada__text_ioB, 4
ada__text_ioB:
	.long	-949875903
	.globl	ada__text_ioS
	.align 4
	.type	ada__text_ioS, @object
	.size	ada__text_ioS, 4
ada__text_ioS:
	.long	779253192
	.globl	ada__streamsB
	.align 4
	.type	ada__streamsB, @object
	.size	ada__streamsB, 4
ada__streamsB:
	.long	1852718939
	.globl	ada__streamsS
	.align 4
	.type	ada__streamsS, @object
	.size	ada__streamsS, 4
ada__streamsS:
	.long	-1116129959
	.globl	system__put_imagesB
	.align 4
	.type	system__put_imagesB, @object
	.size	system__put_imagesB, 4
system__put_imagesB:
	.long	1157064179
	.globl	system__put_imagesS
	.align 4
	.type	system__put_imagesS, @object
	.size	system__put_imagesS, 4
system__put_imagesS:
	.long	-223853217
	.globl	ada__strings__text_buffers__utilsB
	.align 4
	.type	ada__strings__text_buffers__utilsB, @object
	.size	ada__strings__text_buffers__utilsB, 4
ada__strings__text_buffers__utilsB:
	.long	582609823
	.globl	ada__strings__text_buffers__utilsS
	.align 4
	.type	ada__strings__text_buffers__utilsS, @object
	.size	ada__strings__text_buffers__utilsS, 4
ada__strings__text_buffers__utilsS:
	.long	-1996084541
	.globl	interfaces__c_streamsB
	.align 4
	.type	interfaces__c_streamsB, @object
	.size	interfaces__c_streamsB, 4
interfaces__c_streamsB:
	.long	481095686
	.globl	interfaces__c_streamsS
	.align 4
	.type	interfaces__c_streamsS, @object
	.size	interfaces__c_streamsS, 4
interfaces__c_streamsS:
	.long	-319125654
	.globl	system__file_ioB
	.align 4
	.type	system__file_ioB, @object
	.size	system__file_ioB, 4
system__file_ioB:
	.long	-1454475678
	.globl	system__file_ioS
	.align 4
	.type	system__file_ioS, @object
	.size	system__file_ioS, 4
system__file_ioS:
	.long	-2064081701
	.globl	ada__finalizationS
	.align 4
	.type	ada__finalizationS, @object
	.size	ada__finalizationS, 4
ada__finalizationS:
	.long	1972942225
	.globl	system__finalization_rootB
	.align 4
	.type	system__finalization_rootB, @object
	.size	system__finalization_rootB, 4
system__finalization_rootB:
	.long	-804310116
	.globl	system__finalization_rootS
	.align 4
	.type	system__finalization_rootS, @object
	.size	system__finalization_rootS, 4
system__finalization_rootS:
	.long	-389286071
	.globl	system__finalization_primitivesB
	.align 4
	.type	system__finalization_primitivesB, @object
	.size	system__finalization_primitivesB, 4
system__finalization_primitivesB:
	.long	-1909291191
	.globl	system__finalization_primitivesS
	.align 4
	.type	system__finalization_primitivesS, @object
	.size	system__finalization_primitivesS, 4
system__finalization_primitivesS:
	.long	1692640087
	.globl	system__os_locksS
	.align 4
	.type	system__os_locksS, @object
	.size	system__os_locksS, 4
system__os_locksS:
	.long	-85913455
	.globl	system__os_constantsS
	.align 4
	.type	system__os_constantsS, @object
	.size	system__os_constantsS, 4
system__os_constantsS:
	.long	-384074775
	.globl	system__file_control_blockS
	.align 4
	.type	system__file_control_blockS, @object
	.size	system__file_control_blockS, 4
system__file_control_blockS:
	.long	-2012447206
	.globl	system__memoryB
	.align 4
	.type	system__memoryB, @object
	.size	system__memoryB, 4
system__memoryB:
	.long	-1519750918
	.globl	system__memoryS
	.align 4
	.type	system__memoryS, @object
	.size	system__memoryS, 4
system__memoryS:
	.long	-98347641
	.data
	.type	ada_main__is_elaborated, @object
	.size	ada_main__is_elaborated, 1
ada_main__is_elaborated:
	.zero	1
	.globl	__gnat_version
	.section	.rodata
	.align 16
	.type	__gnat_version, @object
	.size	__gnat_version, 21
__gnat_version:
	.string	"GNAT Version: 16.1.0"
	.globl	__gnat_version_address
	.section	.data.rel.ro.local,"aw"
	.align 8
	.type	__gnat_version_address, @object
	.size	__gnat_version_address, 8
__gnat_version_address:
	.quad	__gnat_version
	.globl	__gnat_ada_main_program_name
	.section	.rodata
	.align 8
	.type	__gnat_ada_main_program_name, @object
	.size	__gnat_ada_main_program_name, 10
__gnat_ada_main_program_name:
	.string	"_ada_main"
	.local	ada_main__sec_default_sized_stacks
	.comm	ada_main__sec_default_sized_stacks,10320,32
	.type	ada_main__local_priority_specific_dispatching, @object
	.size	ada_main__local_priority_specific_dispatching, 1
ada_main__local_priority_specific_dispatching:
	.zero	1
	.type	ada_main__local_interrupt_states, @object
	.size	ada_main__local_interrupt_states, 1
ada_main__local_interrupt_states:
	.zero	1
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
