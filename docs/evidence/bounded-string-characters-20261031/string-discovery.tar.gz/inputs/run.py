from pathlib import Path
import json,subprocess,sys,time
root=Path(sys.argv[1]); results={}
for case in json.loads((root/'inputs/cases.json').read_text()):
 start=time.monotonic(); project=root/'inputs'/case/'program.gpr'; work=root/'work'/case
 build=subprocess.run(['gprbuild','-P',str(project),'-p','-j2','-cargs:Ada','-gnatdM'],capture_output=True)
 (work/'build.log').write_bytes(build.stdout+build.stderr)
 row={'build':build.returncode}
 if build.returncode==0:
  proof=subprocess.run(['gnatprove','-P',str(project),'-U','--mode=all','--report=all','--warnings=continue','--checks-as-errors=on','--level=2','--prover=cvc5,z3,altergo','--steps=100000','--timeout=0','--memlimit=1000','-j2','--no-loop-unrolling'],capture_output=True)
  (work/'proof.log').write_bytes(proof.stdout+proof.stderr);row['proof']=proof.returncode
 row['seconds']=time.monotonic()-start;results[case]=row
 (root/'work/results.json').write_text(json.dumps(results,indent=2));print(case,row,flush=True)
