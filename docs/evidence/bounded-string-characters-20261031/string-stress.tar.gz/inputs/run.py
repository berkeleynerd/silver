from pathlib import Path
import collections
import hashlib
import json
import subprocess
import sys
import time

root = Path(sys.argv[1]).resolve()
repository = root.parents[2]
sys.path.insert(0, str(repository))
from scripts.check_evidence import audit_reports

cases = json.loads((root / 'inputs/cases.json').read_text())
results = {}
(root / 'work/solver-cache').mkdir(exist_ok=True)
probe_build = subprocess.run(['gprbuild', '-P', str(root / 'inputs/probe/probe.gpr'), '-p', '-j2', '-XSILVER_HOST=linux-x86_64'], capture_output=True)
(root / 'work/probe-build.log').write_bytes(probe_build.stdout + probe_build.stderr)
if probe_build.returncode:
    raise SystemExit('native report-policy probe build failed')
binary = repository / '.silver/linux-x86_64/compiler/bin/silver'
for name, case in cases.items():
    source = root / 'inputs' / name / 'main.adb'
    project = source.parent / 'program.gpr'
    work = root / 'work' / name
    row = {'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest()}
    start = time.monotonic()
    admission = subprocess.run([str(binary), 'check', str(source)], capture_output=True)
    (work / 'admission.log').write_bytes(admission.stdout + admission.stderr)
    row['admission'] = admission.returncode
    build = subprocess.run(['gprbuild', '-P', str(project), '-p', '-j2', '-cargs:Ada', '-gnatdM'], capture_output=True)
    (work / 'build.log').write_bytes(build.stdout + build.stderr)
    row['build'] = build.returncode
    if build.returncode == 0:
        proof_start = time.monotonic()
        proof = subprocess.run(['gnatprove', '-P', str(project), '-U', '--mode=all', '--report=all',
            '--warnings=continue', '--checks-as-errors=on', '--level=2', '--prover=cvc5,z3,altergo',
            '--steps=100000', '--timeout=0', '--memlimit=1000', '-j2', '--no-loop-unrolling',
            '--memcached-server=file:' + str(root / 'work/solver-cache')], capture_output=True)
        row['proof_seconds'] = time.monotonic() - proof_start
        (work / 'proof.log').write_bytes(proof.stdout + proof.stderr)
        row['proof'] = proof.returncode
        if proof.returncode == 0:
            report_directory = work / 'obj/gnatprove'
            try:
                audit_reports(report_directory, {'main', 'silver_io', 'silver_output_libc', 'silver_arguments', 'silver_runtime'},
                    {'silver_output_libc', 'silver_runtime'}, application_kind=case['kind'], indexed_main=True)
                row['audit'] = 'pass'
            except Exception as error:
                row['audit'] = repr(error)
            report = report_directory / 'main~1.spark'
            data = json.loads(report.read_text())
            native_policy = subprocess.run([str(root / 'work/probe/library_reports_probe'),
                'assignment' if case['kind'] == 'assigned' else case['kind']],
                input=json.dumps(data).encode() + b'\n', capture_output=True, timeout=30)
            (work / 'native-policy.log').write_bytes(native_policy.stdout + native_policy.stderr)
            row['native_policy'] = native_policy.returncode == 0 and native_policy.stdout == b'accepted\n' and native_policy.stderr == b''
            row['main_report_bytes'] = report.stat().st_size
            row['proof_checks'] = len(data.get('proof', []))
            row['proof_rules'] = dict(collections.Counter(item.get('rule', '') for item in data.get('proof', [])))
            row['flow_diagnostics'] = [item.get('message', {}).get('text', '') for item in data.get('flow', [])]
            row['warning_diagnostics'] = [item.get('message', {}).get('text', '') for item in data.get('warn_error', [])]
            execution = subprocess.run([str(work / 'bin/main')], capture_output=True, timeout=10)
            row['execution'] = {'returncode': execution.returncode, 'stdout': execution.stdout.decode(), 'stderr': execution.stderr.decode()}
            row['expected_output'] = case['output']
            row['execution_pass'] = execution.returncode == 0 and execution.stdout == case['output'].encode() and execution.stderr == b''
    row['source_unchanged'] = hashlib.sha256(source.read_bytes()).hexdigest() == row['source_sha256']
    row['seconds'] = time.monotonic() - start
    results[name] = row
    (root / 'work/results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(name, {key: row[key] for key in ['admission', 'build', 'proof', 'audit', 'main_report_bytes', 'execution_pass', 'seconds'] if key in row}, flush=True)
failures = [name for name, row in results.items() if row.get('admission') != 0 or row.get('proof') != 0 or row.get('audit') != 'pass' or not row.get('native_policy') or not row.get('execution_pass') or not row['source_unchanged']]
if failures:
    raise SystemExit('failed cases: ' + ', '.join(failures))
