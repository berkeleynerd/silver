# Inherited native-state forwarding repair — 2026-11-04

Owner-authorized bounded #296 String/Character/indexing/slice integration repair.
This subthread owns only this scratch packet. No production source, policy,
Oracle, native runner, cache, test, or tracked documentation was edited here.
PR #307 must remain open. Integration and complete validation belong to the lead.

The baseline is `f4d1bf10ec3fd140779f73422ed5c487696d27a5`.
The retained complete source run `20261104T021852-a9ce2c35192f` failed only
`Silver.PredicateInheritedReady`, with 56 diagnostics. Its complete diagnostic
output is preserved as `source-failure.log`; that run remains failed.

`integration.patch` applies only to `proof/Silver/PredicateInheritedReady.lean`.
`Silver/PredicateInheritedReady.lean` contains the exact proposed full module,
with the same module origin and declaration names as production.
`PredicateInheritedReady.before.lean` preserves the original bytes.

The repair supplies the already-required `NativeState` base and bounds to the
basic-domain witnesses, then reconstructs the outer domain's mathematical
validity, scalar readiness, and String bounds from the existing preservation
proofs. It also forwards the eight existing String/Character helper-equation
fields omitted by the old wrapper. Array-value domain conversion retains both
native bounds predicates and all prior array constraints.

All six existing theorem headers are byte-identical, including the private
helper statements. Imports, theorem assumptions, state-domain definitions,
executable bodies, and public conclusions are unchanged. No new theorem,
assumption, axiom, admission restriction, or policy adjustment was introduced.
`git apply --check integration.patch` passed in the baseline worktree before
lead integration. The lead may subsequently change the production source by
applying this exact patch; that does not change the retained run identities.

## Fresh focused evidence

Managed run `20261104T022435-5b01e422a9e5` passed on native Linux x86_64:

- Exact full-module elaboration/kernel check: 1.482 seconds, exit 0.
- Fresh `#silver_audit`: 3.433 seconds, exit 0.
- Audit result: 90,451 declarations across exactly 311 Silver modules,
  including `Silver.PredicateInheritedReady`; only `propext`, `Classical.choice`,
  and `Quot.sound` were used.
- Managed check wall time, including post-check identity hashing: 6.243 seconds.
- Maximum child RSS reported by `getrusage`: 1,941,476 KiB.
- Settings: one reserved worker, `-j1 -M4096 -DwarningAsError=true`.
- Lean: 4.34.1, x86_64-unknown-linux-gnu, commit
  `5045d0056413266e57c625dcd7c365b10e377c52`, Release.
- All 6,038 captured source, tool, and dependency/artifact identities were
  unchanged between preflight and completion. All 310 expected dependency
  modules plus the repaired module appeared in the fresh audit.

`inputs.json` captures exact source, dependency, completed-artifact, and Lean/Lake
executable hashes. `after-identities.json` records the completion hashes.
`evidence.json` holds both commands, individual timings, audit scope, before/after
comparison, settings, and the newly produced scratch artifact hashes.
`check.log` preserves full output. `handoff.json` supplies a compact identity index.

Original module SHA-256:
`857740bd4627defedf31e6793d828a2824143f3edc37f6de34db4fc2c7cbccae`.
Proposed module SHA-256:
`0fa6a9462051a23e5015d2bb6a30b72709961007b021fc1484676d3eb6f9d99f`.
Patch SHA-256:
`941549ddcdee1bd1f791313159ee51250e3df4578e08854f74d69f2872641a97`.

Completed dependencies were read through scratch-local symlinks to the original
artifacts. No dependency artifacts were copied or modified. The first two
attempts failed before proof elaboration because of scratch import layout:
`attempt-1-import-setup-failure` preserves run
`20261104T022255-71c6a475b409`, which lacked the local dependency prefix, and
`attempt-2-meta-import-setup-failure` preserves run
`20261104T022356-75c6428a6522`, which omitted the meta-imported CertificateWitness.
Each directory retains its original runner, inputs, log, outcome, and post-check
identities. The corrected import discovery includes public meta imports.
These are setup failures, not successful proof evidence.

## Applicability and remaining lead work

This fresh result covers the exact repaired module and its actual completed
import closure. It does not establish the complete project's source guarantee
or fresh whole-project audit. The lead must integrate the exact bytes and run
the required complete cached source validation and whole-project audit, allowing
Lake to rebuild affected consumers. Existing expensive source certificates were
not rerun here.

No native implementation or test tooling changed in this packet. Native proof,
source correspondence, and regression applicability remain the lead's final
integration obligations; no native proof or regression execution is claimed by
this subthread. The before/after capture includes all source files under `src/`,
`proof/`, and `scripts/`, as well as the actual imported generated source files.

Selected worker model/effort: GPT-6.1 Sol Extra High, as supplied by the lead.
Runtime model/effort confirmation and token/cost measurements were unavailable.
The achieved result closes the inherited-wrapper proof repair with one successful
proof check after two retained import-setup failures. No unresolved semantic
obligation or additional failing governed module was identified in this bounded
check. Lead review and complete integration validation remain separate evidence.
