from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,platform,re,resource,subprocess,sys,time
PACKET=Path(__file__).resolve().parent
ROOT=PACKET.parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from platforms import native_layout
from bootstrap_lean import lean_environment
from run_history import ManagedRun
host=native_layout(ROOT)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source_module='Silver.PredicateInheritedReady'
imports=lambda text:[name for line in text.splitlines() if re.match(r'^(?:public )?(?:meta )?import ',line) for name in re.sub(r'^(?:public )?(?:meta )?import ','',line).split() if name.startswith('Silver.')]
dependencies=set()
def visit(name):
 if name in dependencies:return
 if name==source_module:raise RuntimeError('repaired module already present in import closure')
 dependencies.add(name)
 path=host.proof/(name.replace('.','/')+'.lean')
 if not path.is_file():raise RuntimeError(f'missing dependency source: {path}')
 for child in imports(path.read_text()):visit(child)
for name in imports((PACKET/'Silver/PredicateInheritedReady.lean').read_text())+['Silver.AxiomAudit']:visit(name)
# Lean chooses one root for the Silver module prefix. Reference completed
# immutable import artifacts within the scratch prefix; no cache data is copied.
for name in sorted(dependencies):
 relative=Path(name.replace('.','/'))
 artifact=host.proof/'.lake/build/lib/lean'/relative
 destination=PACKET/relative
 destination.parent.mkdir(parents=True,exist_ok=True)
 for file in artifact.parent.glob(artifact.name+'.*'):
  if file.is_file():
   link=destination.parent/file.name
   if link.exists() or link.is_symlink():
    if not link.is_symlink() or link.resolve()!=file.resolve():raise RuntimeError(f'preserve existing scratch path: {link}')
   else:link.symlink_to(file)
input_paths={PACKET/'Silver/PredicateInheritedReady.lean',PACKET/'AuditProbe.lean',PACKET/'check.py',PACKET/'prepare.py',PACKET/'integration.patch',PACKET/'PredicateInheritedReady.before.lean',PACKET/'source-failure.log',ROOT/'proof/Silver/PredicateInheritedReady.lean',host.lean/'bin/lean',host.lean/'bin/lake'}
for name in sorted(dependencies):
 relative=Path(name.replace('.','/'))
 for folder in [ROOT/'proof',host.proof]:
  path=(folder/relative).with_suffix('.lean')
  if path.is_file():input_paths.add(path)
 for folder in [host.proof/'.lake/build/lib/lean',host.proof/'.lake/build/ir']:
  path=folder/relative
  input_paths.update(file for file in path.parent.glob(path.name+'.*') if file.is_file())
 olean=(host.proof/'.lake/build/lib/lean'/relative).with_suffix('.olean')
 if not olean.is_file():raise RuntimeError(f'missing completed import: {olean}')
# Governing proof/native/tool inputs are captured independently of import scope,
# to establish that this scratch-only repair leaves retained native evidence applicable.
for folder in ['proof','src','scripts']:
 input_paths.update(p for p in (ROOT/folder).rglob('*') if p.is_file() and '.lake' not in p.parts and '__pycache__' not in p.parts)
inputs={
 'scope':'Exact Silver.PredicateInheritedReady proof-body forwarding repair, preserving all existing theorem statements and the native readiness/domain/bounds guarantees; complete native and whole-project validation remain lead obligations',
 'source_run':'20261104T021852-a9ce2c35192f',
 'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'native_host':host.key,'platform':platform.platform(),
 'module_name':source_module,'dependency_modules':sorted(dependencies),
 'original_sha256':sha(ROOT/'proof/Silver/PredicateInheritedReady.lean'),
 'proposed_sha256':sha(PACKET/'Silver/PredicateInheritedReady.lean'),
 'statements_unchanged':True,
 'selected_model_effort':'GPT-6.1 Sol Extra High, selected by parent; runtime confirmation unavailable',
 'token_cost_evidence':'unavailable',
 'settings':{'workers':1,'lean_threads':1,'lean_memory_mib':4096,'warning_as_error':True},
 'input_sha256':{str(p):sha(p) for p in sorted(input_paths)},
 'utc':datetime.now(timezone.utc).isoformat(),
}
(PACKET/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
commands=[
 [str(host.lean/'bin/lean'),'-j1','-M4096','-DwarningAsError=true',str(PACKET/'Silver/PredicateInheritedReady.lean'),'-o',str(PACKET/'Silver/PredicateInheritedReady.olean'),'-i',str(PACKET/'Silver/PredicateInheritedReady.ilean')],
 [str(host.lean/'bin/lean'),'-j1','-M4096','-DwarningAsError=true',str(PACKET/'AuditProbe.lean')]]
log=PACKET/'check.log';report=PACKET/'evidence.json'
if log.exists() or report.exists():raise SystemExit('Existing check evidence retained; select distinct names before another attempt')
with ManagedRun(host,'lean-diagnostic',[sys.executable,str(Path(__file__).resolve())],inputs,[PACKET],workers=1,task='#296-inherited-state-repair',reason='Check only the failed inherited readiness wrapper against completed import artifacts, retaining all existing theorem statements, full NativeState bounds and source interpretation domains',evidence=[log,report]) as run:
 run.prepare(inputs)
 env={**lean_environment(host),'LEAN_PATH':str(PACKET)+os.pathsep+str(host.proof/'.lake/build/lib/lean')}
 started=time.monotonic();phases=[];output='';code=0
 for name,command in zip(['exact-module-check','fresh-axiom-audit'],commands):
  run.event('phase',phase=name,command=command)
  tick=time.monotonic();p=subprocess.run(command,cwd=PACKET,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,pass_fds=run.pass_fds,timeout=180)
  output+=p.stdout;log.write_text(output);phases.append({'phase':name,'command':command,'elapsed_seconds':time.monotonic()-tick,'returncode':p.returncode})
  if p.returncode:code=p.returncode;break
 after={name:sha(Path(name)) for name in inputs['input_sha256']}
 changed=[name for name,expected in inputs['input_sha256'].items() if after[name]!=expected]
 (PACKET/'after-identities.json').write_text(json.dumps(after,indent=2)+'\n')
 audited_modules=sorted(set(re.findall(r'SILVER_MODULE (Silver[^\s]+)',output)))
 audit_passed='Silver axiom audit passed:' in output and source_module in audited_modules
 if not code and (changed or not audit_passed):code=125 if changed else 126
 expected_audit=sorted(dependencies|{source_module})
 if not code and audited_modules!=expected_audit:code=127
 artifacts={str(p):sha(p) for p in (PACKET/'Silver').glob('PredicateInheritedReady.*') if p.suffix!='.lean'}
 result={**inputs,'run_id':run.run_id,'phases':phases,'elapsed_seconds':time.monotonic()-started,'max_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'returncode':code,'changed_inputs':changed,'fresh_audit_passed':audit_passed,'audited_modules':audited_modules,'expected_audit_modules_match':audited_modules==expected_audit,'audit_result':re.findall(r'Silver axiom audit passed:.*',output),'output_artifact_sha256':artifacts}
 report.write_text(json.dumps(result,indent=2)+'\n')
 print(output[-5000:],flush=True);print(json.dumps({k:result[k] for k in ['run_id','elapsed_seconds','max_rss_kib','returncode','changed_inputs','fresh_audit_passed','expected_audit_modules_match','audit_result']},indent=2),flush=True)
 run.finish('success' if code==0 else 'failure',returncode=code)
 sys.exit(code)
