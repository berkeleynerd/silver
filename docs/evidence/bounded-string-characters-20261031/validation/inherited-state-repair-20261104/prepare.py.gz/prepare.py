from pathlib import Path
import difflib, hashlib, json, re, subprocess
PACKET = Path(__file__).resolve().parent
ROOT = PACKET.parents[1]
source = ROOT / 'proof/Silver/PredicateInheritedReady.lean'
original = source.read_text()
proposed, tail = original.split('/-- A simultaneous inhabitant', 1)
proposed = proposed.replace('sv.1', '⟨sv.valid, sv.bounds⟩').replace('sv.2', 'sv.base.ready')
for kind in ['stringDeclaration', 'subtypeDeclaration', 'scalarDeclaration', 'arrayDeclaration', 'declaration']:
    old = f'exact ⟨⟨bounded.1, OuterReadiness.{kind}_ready text state arguments sv.base.ready⟩, bounded.2⟩'
    new = (f'exact ⟨⟨⟨bounded.1.base, OuterReadiness.{kind}_ready text state arguments sv.base.ready,\n'
           f'      bounded.1.bounds⟩, bounded.1.bounds⟩, bounded.2⟩')
    assert old in proposed, kind
    proposed = proposed.replace(old, new)
old = '''  argument text tv state sv :=
    ⟨Compose.Expressions.model_ranges.argument text tv state ⟨sv.valid, sv.bounds⟩,
      OuterReadiness.argument_ready text state sv.base.ready⟩
  declarations text tv state arguments sv :=
    ⟨Compose.Expressions.model_ranges.declarations text tv state arguments ⟨sv.valid, sv.bounds⟩,
      OuterReadiness.declarations_ready text state arguments sv.base.ready⟩'''
new = '''  argument text tv state sv := by
    have bounded := Compose.Expressions.model_ranges.argument text tv state ⟨sv.valid, sv.bounds⟩
    exact ⟨⟨bounded.base, OuterReadiness.argument_ready text state sv.base.ready, bounded.bounds⟩,
      bounded.bounds⟩
  declarations text tv state arguments sv := by
    have bounded := Compose.Expressions.model_ranges.declarations text tv state arguments ⟨sv.valid, sv.bounds⟩
    exact ⟨⟨bounded.base, OuterReadiness.declarations_ready text state arguments sv.base.ready, bounded.bounds⟩,
      bounded.bounds⟩'''
assert old in proposed
proposed = proposed.replace(old, new)
proposed = proposed.replace('⟨valid.sourceContext.1, valid.resultContext.1, valid.positionValid,',
'''⟨⟨valid.sourceContext.valid, valid.sourceContext.bounds⟩,
    ⟨valid.resultContext.valid, valid.resultContext.bounds⟩, valid.positionValid,''')
old = '  names := base_definitions.names\n'
new = '''  names := base_definitions.names
  fixedBounds := base_definitions.fixedBounds
  characterLiteral := base_definitions.characterLiteral
  indexed := base_definitions.indexed
  characterValue := base_definitions.characterValue
  concatenatedFirst := base_definitions.concatenatedFirst
  concatenatedLast := base_definitions.concatenatedLast
  addBindingWithCharacter text tv state first after value mutable following characterObject sv fv av vv followingValid room fixed :=
    base_definitions.addBindingWithCharacter text tv state first after value mutable following characterObject
      ⟨sv.valid, sv.bounds⟩ fv av vv followingValid room fixed
  characterDeclaration text tv state arguments sv :=
    base_definitions.characterDeclaration text tv state arguments ⟨sv.valid, sv.bounds⟩
'''
assert proposed.count(old) == 1
proposed = proposed.replace(old, new)
proposed += '/-- A simultaneous inhabitant' + tail
headers = lambda text: re.findall(r'(?:private )?theorem\s+.*?(?=\s+(?:where|:=))', text, re.S)
assert headers(original) == headers(proposed)
(PACKET / 'PredicateInheritedReady.before.lean').write_text(original)
(PACKET / 'Silver/PredicateInheritedReady.lean').write_text(proposed)
(PACKET / 'integration.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True), proposed.splitlines(True), fromfile='a/proof/Silver/PredicateInheritedReady.lean', tofile='b/proof/Silver/PredicateInheritedReady.lean')))
(PACKET / 'source-failure.log').write_bytes((ROOT / 'tmp/string-state-source-20261104/run.log').read_bytes())
(PACKET / 'AuditProbe.lean').write_text('import Silver.PredicateInheritedReady\nimport Silver.AxiomAudit\n\n#silver_audit\n')
print(json.dumps({'headers_unchanged':True, 'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(), 'original_sha256':hashlib.sha256(original.encode()).hexdigest(), 'proposed_sha256':hashlib.sha256(proposed.encode()).hexdigest(), 'patch_lines':len((PACKET / 'integration.patch').read_text().splitlines())}, indent=2))
