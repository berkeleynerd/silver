"""Export bounded parenthesis-repair evidence, explicitly excluding full assurance."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
RECORD = Path(__file__).resolve().parent
RUNS = Path("/home/canto/src/github.com/berkeleynerd/silver/.git/silver-runs/linux-x86_64/d140f139bb2e1ef1/runs")
OUT = RECORD / "parenthesis-scopes"
SOURCE_HASH = "4a02223317f89de2653d89ac152ae9e66fb089a0cfa20cd3ecb4c8765d90c485"
SCOPES = [
    ("fixed-bounds", "20261103T233138-1aa86e9fc08c", 0, 1),
    ("indexed", "20261103T233219-87092b298de3", 27, 6),
    ("concatenated-last", "20261103T233240-8f2ba67b9283", 9, 2),
    ("character-progress", "20261103T233252-18c5c26c905d", 22, 2),
]


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def write(p,x):
    p.write_text(json.dumps(x,indent=2)+"\n")


def main():
    OUT.mkdir(exist_ok=True)
    selected = {}
    scopes = []
    source = ROOT / "src/silver_output_profile.adb"
    assert sha(source) == SOURCE_HASH
    commit = subprocess.check_output(["git","rev-parse","HEAD"], cwd=ROOT,text=True).strip()
    assert subprocess.check_output(["git","show","--pretty=","--name-only",commit],cwd=ROOT,text=True).strip() == "src/silver_output_profile.adb"

    def managed(run_id,prefix,success=True):
        run = RUNS / run_id
        events = [json.loads(s) for s in (run/"events.jsonl").read_text().splitlines()]
        end = events[-1]
        assert end["event"] == "finished" and end["outcome"] == ("success" if success else "failure")
        for name in ["native.log","events.jsonl"]:
            selected[prefix+"/managed/"+name] = run/name
        prepared = next(e["inputs"] for e in events if e["event"] == "prepared")
        mismatches = [name for name,expected in prepared["inputs_sha256"].items()
                      if sha(ROOT / name) != expected]
        assert not mismatches, mismatches
        selected_input = next(v for k,v in prepared["inputs_sha256"].items() if k.endswith("src/silver_output_profile.adb"))
        assert selected_input == SOURCE_HASH
        return run,events,end,prepared

    for name,run_id,proof,flow in SCOPES:
        prefix="scopes/"+name
        run,events,end,prepared=managed(run_id,prefix)
        reports=ROOT/".silver/linux-x86_64/compiler/obj/explore"/("parenthesis-"+name+"-20261103")/"gnatprove"
        data=json.loads((reports/"silver_output_profile.spark").read_text())
        assert len(data["proof"])==proof and len(data["flow"])==flow
        checks=data["proof"]+data["flow"]
        assert all(r["severity"]=="info" and r["how_proved"] in ("flow","prover","trivial")
                   and not any(r.get(k) for k in ("justification","justified","suppressed","annot_kind","justif_msg")) for r in checks)
        assert all(r["rule"] in ("numeric-variant","contracts-recursive")
                   and r["severity"]=="warning" for r in data["warn_error"])
        sarif=json.loads((reports/"gnatprove.sarif").read_text())
        assert not any(r.get("ruleId")=="operator-reassociation" for run in sarif["runs"] for r in run["results"])
        for p in reports.rglob("*"):
            if p.is_file() and (p.suffix in (".spark", ".gnat-json")
                                or p.name in ("gnatprove.out","gnatprove.sarif","why3session.xml")):
                selected[prefix+"/reports/"+str(p.relative_to(reports))]=p
        scopes.append({"name":name,"run_id":run_id,"proof_checks":proof,"flow_checks":flow,
                       "duration_seconds":end["duration_seconds"],"source_sha256":SOURCE_HASH,
                       "captured_inputs_verified":len(prepared["inputs_sha256"]),
                       "reassociation_diagnostics":0,"scope_only":True})

    build_id="20261103T233404-d80bccc33dbc"
    test_id="20261103T233411-962e761487e2"
    _,_,build,_=managed(build_id,"matching-build")
    test_run,_,test,test_inputs=managed(test_id,"affected-tests")
    log=(test_run/"native.log").read_text()
    assert "Ran 10 tests in 23.672s" in log and "\nOK\n" in log
    for ident in ("20261103T233049-8faffda0926b","20261103T233145-c3357c4469cf"):
        run,_,_,_=managed(ident,"setup-failures/"+ident,False)
        for p in (run/"reports").rglob("*"):
            if p.is_file(): selected["setup-failures/"+ident+"/reports/"+str(p.relative_to(run/"reports"))]=p
    summary={"recorded_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),
             "commit":commit,"source_sha256":SOURCE_HASH,
             "state":"Canonical scoped proofs, matching build and affected runtime tests PASS; complete native/source assurance and full suite pending",
             "proof_checks":58,"flow_checks":11,"scope_checks":69,"scopes":scopes,
             "build":{"run_id":build_id,"outcome":"success","duration_seconds":build["duration_seconds"]},
             "affected_tests":{"run_id":test_id,"outcome":"success","methods":10,"test_seconds":23.672,"managed_seconds":test["duration_seconds"]},
             "binary_sha256":sha(ROOT/".silver/linux-x86_64/compiler/bin/silver"),
             "policy":"Canonical 30s cvc5,z3,altergo, level2, mode/report all, warnings/checks as errors; one worker per isolated scope; strict audit/configuration unchanged",
             "setup_failures_preserved":["Adjacent comment line selected instead of exact declaration; no checks generated","New isolated cache directory absent; created without altering/copying normal cache"],
             "full_native_run_held":True,"full_regression_suite_held":True,
             "model_effort":"Inherited selected agent setting; runtime model/effort confirmation and token/cost evidence unavailable"}
    write(OUT/"summary.json",summary)
    selected["summary.json"]=OUT/"summary.json"
    selected["source/silver_output_profile.adb"]=source
    for name in ["operator-reassociation-seven-sites.patch","operator-reassociation-patch-assessment.json",
                 "parenthesis-input-delta.json","parenthesis-scope-exits.json","parenthesis-build-test-exits.json",
                 "run_parenthesis_scopes.py","package_parenthesis_scopes.py"]:
        selected["diagnostics/"+name]=RECORD/name
    write(OUT/"files.json",{k:{"bytes":p.stat().st_size,"sha256":sha(p)} for k,p in sorted(selected.items())})
    selected["files.json"]=OUT/"files.json"
    archive=OUT/"scoped-parenthesis-pass.tar.gz"
    assert not archive.exists()
    with tarfile.open(archive,"w:gz") as tar:
        for name,p in sorted(selected.items()):tar.add(p,arcname=name,recursive=False)
    record={"path":str(archive),"bytes":archive.stat().st_size,"sha256":sha(archive),"members":len(selected),"state":summary["state"]}
    write(OUT/"archive.json",record)
    state_path=RECORD/"round-state.json"
    state=json.loads(state_path.read_text())
    state["updated_at"]=summary["recorded_at"]
    state["parenthesis_repair"]={"summary":summary,"archive":record}
    state["continuation_checkpoint"].update(
        achieved="Seven-pair Ada-only repair committed; four canonical scopes prove 69 checks, matching build and ten StringCharacter methods pass. Original strict-audit failure and two scoped setup failures preserved.",
        unresolved="Independent source/model repair review, complete final-byte native/source assurance and full 578-method suite",
        next_step="Hand off exact commit/scoped evidence; await lead resource coordination and authorization for complete final-byte native rerun, then full suite.")
    write(state_path,state)
    print(json.dumps({"archive":record,"summary":summary},indent=2))


if __name__=="__main__":main()
