"""Four serialized canonical scope checks, preserving ordinary native reports/cache."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
RECORD = Path(__file__).resolve().parent
SCOPES = [("fixed-bounds", 158), ("indexed", 639),
          ("concatenated-last", 1042), ("character-progress", 1440)]
records = json.loads((RECORD / "parenthesis-scope-exits.json").read_text()) if (RECORD / "parenthesis-scope-exits.json").exists() else []
source = ROOT / "src/silver_output_profile.adb"
assert hashlib.sha256(source.read_bytes()).hexdigest() == "4a02223317f89de2653d89ac152ae9e66fb089a0cfa20cd3ecb4c8765d90c485"
(RECORD / "parenthesis-scopes/cache").mkdir(parents=True,exist_ok=True)
for name,line in SCOPES:
    if any(x["name"] == name and x["line"] == line and x["exit_code"] == 0 for x in records):
        continue
    task = "#296-parenthesis-scope-" + name
    command = [sys.executable, "scripts/dev.py", "tool", "--jobs", "1", "--task", task,
               "--reason", "Authorized seven-pair parenthesis repair; canonical 30s portfolio, isolated scoped output/cache; full assurance remains pending", "--",
               "gnatprove", "-P", "../../../silver.gpr", "-u", "silver_output_profile.adb",
               "--mode=all", "--report=all", "--warnings=error", "--checks-as-errors=on",
               "--level=2", "--prover=cvc5,z3,altergo", "--timeout=30",
               f"--limit-subp=silver_output_profile.adb:{line}", "--debug-save-vcs",
               "--subdirs=explore/parenthesis-" + name + "-20261103",
               "--memcached-server=file:" + str(RECORD / "parenthesis-scopes/cache"),
               "-XSILVER_HOST=linux-x86_64"]
    print("Starting scope",name,"at",datetime.datetime.now(datetime.timezone.utc).isoformat(),flush=True)
    result = subprocess.run(command,cwd=ROOT)
    records.append({"name": name, "line": line, "command": command,
                    "exit_code": result.returncode,
                    "finished_at": datetime.datetime.now(datetime.timezone.utc).isoformat()})
    (RECORD / "parenthesis-scope-exits.json").write_text(json.dumps(records,indent=2)+"\n")
    if result.returncode:
        raise SystemExit(result.returncode)
    assert hashlib.sha256(source.read_bytes()).hexdigest() == "4a02223317f89de2653d89ac152ae9e66fb089a0cfa20cd3ecb4c8765d90c485"
