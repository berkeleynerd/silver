"""Sample final-suite progress/resources; retain exact method-result lines."""
from pathlib import Path
import datetime
import json
import os
import re
import shutil
import subprocess
import time

ROOT=Path(__file__).resolve().parents[2]
RECORD=Path(__file__).resolve().parent
LAUNCH=json.loads((RECORD/"final-suite-launch-20261104.json").read_text())
RUN=Path("/home/canto/src/github.com/berkeleynerd/silver/.git/silver-runs/linux-x86_64/d140f139bb2e1ef1/runs")/LAUNCH["run_id"]
PATTERN=re.compile(r"(?m)^(test\w+) \(([^\n()]+)\)(?:[ \t]+\.\.\.[ \t]*(.*))?$")


def results(log):
    records=[]
    matches=list(PATTERN.finditer(log))
    for index,match in enumerate(matches):
        end=matches[index+1].start() if index+1<len(matches) else len(log)
        segment=log[match.end():end]
        tail=(match.group(3) or "").strip()
        description=""
        if match.group(3) is None:
            following=next((line for line in segment.splitlines() if line.strip()),"")
            described=re.match(r"^(.*?) \.\.\.[ \t]*(.*)$",following)
            if described:description,tail=described.groups()
        initial=tail
        # A test may print after unittest's partial header. Its final status
        # then occupies a separate line before the next method header.
        if tail not in ("ok","FAIL","ERROR","expected failure","unexpected success") and not tail.startswith("skipped "):
            separate=[line.strip() for line in segment.splitlines()
                      if line.strip() in ("ok","FAIL","ERROR","expected failure","unexpected success")
                      or line.strip().startswith("skipped ")]
            if separate:tail=separate[-1]
        subtest_failures=re.findall(r"(?m)^[ \t]+test\w+ .* \.\.\.[ \t]*(FAIL|ERROR)[ \t]*$",segment)
        if subtest_failures:tail="ERROR" if "ERROR" in subtest_failures else "FAIL"
        if tail=="ok":state="ok"
        elif tail.startswith("skipped "):state="skipped"
        elif tail in ("FAIL","ERROR","expected failure","unexpected success"):state=tail
        else:state="running"
        records.append({"id":match.group(2),"state":state,"raw_result":tail,
                        "initial_result_text":initial,"interleaved_output":initial!=tail,
                        "description":description,"subtest_failures":subtest_failures})
    return records


def snapshot():
    events=[json.loads(s) for s in (RUN/"events.jsonl").read_text().splitlines()]
    log=(RUN/"native.log").read_text()
    methods=results(log)
    rows=[line.split(None,7) for line in subprocess.check_output(
        ["ps","-eo","pid,ppid,pgid,etimes,rss,pcpu,comm,args"],text=True).splitlines()[1:]]
    owned={LAUNCH["runner_pid"]}
    while True:
        more={int(row[0]) for row in rows if len(row)==8 and int(row[1]) in owned}
        if more<=owned:break
        owned|=more
    processes=[{"pid":int(row[0]),"ppid":int(row[1]),"pgid":int(row[2]),
                "elapsed_seconds":int(row[3]),"rss_bytes":int(row[4])*1024,
                "cpu_percent":float(row[5]),"program":row[6],"command":row[7]}
               for row in rows if len(row)==8 and int(row[0]) in owned]
    memory={line.split(":")[0]:int(line.split()[1])*1024
            for line in Path("/proc/meminfo").read_text().splitlines()
            if line.startswith(("MemTotal:","MemAvailable:","SwapFree:"))}
    end=events[-1]
    return {"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "run_id":LAUNCH["run_id"],"last_event":{k:end.get(k) for k in ("event","phase","outcome","returncode")},
            "counts":{state:sum(x["state"]==state for x in methods)
                      for state in ("ok","skipped","FAIL","ERROR","expected failure","unexpected success","running")},
            "methods_observed":len(methods),"latest_methods":methods[-3:],
            "all_method_results":methods,"host_memory_bytes":memory,
            "suite_descendant_rss_bytes":sum(p["rss_bytes"] for p in processes),
            "free_disk_bytes":shutil.disk_usage(ROOT).free,"processes":processes,
            "memory_pressure_below4GiB":memory["MemAvailable"]<4*2**30}


def main():
    while True:
        current=snapshot()
        (RECORD/"last-final-suite-status.json").write_text(json.dumps(current,indent=2)+"\n")
        summary={k:v for k,v in current.items() if k not in ("all_method_results","processes")}
        with (RECORD/"final-suite-observations-20261104.jsonl").open("a") as stream:
            stream.write(json.dumps(summary)+"\n")
        print(json.dumps(summary),flush=True)
        if current["last_event"]["event"]=="finished":break
        time.sleep(20)


if __name__=="__main__":main()
