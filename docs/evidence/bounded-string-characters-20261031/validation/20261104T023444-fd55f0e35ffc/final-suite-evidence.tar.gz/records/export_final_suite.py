"""Export exact final-suite outcomes and retained-fixture applicability after terminal."""
from collections import Counter,defaultdict
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import re
import subprocess
import sys
import tarfile

ROOT=Path(__file__).resolve().parents[2]
RECORD=Path(__file__).resolve().parent
sys.path.insert(0,str(RECORD))
from watch_final_suite import results


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+"\n")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--session-exit-code",type=int,required=True)
    args=parser.parse_args()
    launch=json.loads((RECORD/"final-suite-launch-20261104.json").read_text())
    run=Path("/home/canto/src/github.com/berkeleynerd/silver/.git/silver-runs/linux-x86_64/d140f139bb2e1ef1/runs")/launch["run_id"]
    events=[json.loads(s) for s in (run/"events.jsonl").read_text().splitlines()]
    terminal=events[-1]
    assert terminal["event"]=="finished",terminal
    if args.session_exit_code==0:assert terminal["outcome"]=="success",terminal
    else:assert terminal["outcome"]=="failure",terminal
    prepared=next(e["inputs"] for e in events if e["event"]=="prepared")
    input_mismatches=[name for name,value in prepared["inputs_sha256"].items()
                      if not Path(name).is_file() or sha(Path(name))!=value]
    assert not input_mismatches,input_mismatches
    inventory=json.loads((RECORD/"final-suite-inventory-20261104.json").read_text())
    expected=set(inventory["test_ids"]);assert len(expected)==578
    log=(run/"native.log").read_text()
    observed=results(log)
    grouped=defaultdict(list)
    for record in observed:grouped[record["id"]].append(record)
    unknown=sorted(set(grouped)-expected)
    missing=sorted(expected-set(grouped))
    duplicates={k:v for k,v in grouped.items() if len(v)!=1}
    counts=dict(Counter(x["state"] for x in observed))
    unittest_summary=re.findall(r"(?m)^Ran (\d+) tests in ([0-9.]+)s$",log)
    assert len(unittest_summary)<=1,unittest_summary
    if args.session_exit_code==0:assert len(unittest_summary)==1,unittest_summary
    review=json.loads((RECORD/"final-three-sync-and-fixture-check.json").read_text())
    approved=review["retained_fixture_coverage"]
    skipped={x["id"] for x in observed if x["state"]=="skipped"}
    fixture=json.loads((RECORD/"fixture-closure-current-check.json").read_text())
    closure=fixture["current_inputs_sha256"]
    closure_mismatches=[k for k,v in closure.items() if sha(ROOT/k)!=v]
    assert not closure_mismatches,closure_mismatches
    for k,v in inventory["tests_sha256"].items():assert sha(ROOT/k)==v,k
    if args.session_exit_code==0:
        assert not unknown and not missing and not duplicates,(unknown,missing,duplicates)
        assert counts=={"ok":571,"skipped":7},counts
        assert skipped==set(approved),(skipped,set(approved))
        assert int(unittest_summary[0][0])==578
        assert re.search(r"(?m)^OK \(skipped=7\)$",log)
    sys.path.insert(0,str(ROOT))
    from scripts.platforms import native_layout
    from scripts.proof_provenance import validate_provenance
    from scripts.dev import hash_paths
    host=native_layout(ROOT)
    selected_inputs=[ROOT/"scripts",Path(sys.executable).resolve()]
    selected_inputs += [ROOT/name for name in ("tests","src","proof","samples","catalogue")
                        if (ROOT/name).exists()]
    selected_inputs += [ROOT/"rosetta"/name for name in ("refresh.py","manifest.json","coverage.json")
                        if (ROOT/"rosetta"/name).exists()]
    selected_inputs += [p for p in (host.compiler/"bin/silver",ROOT/"silver.gpr",ROOT/"alire.toml",
                                   host.generated,host.context) if p.exists()]
    assert hash_paths(selected_inputs)==prepared["inputs_sha256"],"Suite input path set or hashes changed"
    manifest=validate_provenance(host,host.compiler/"obj/gnatprove")
    assert len(manifest["inputs_sha256"])==2582
    out=RECORD/"final-suite-20261104";out.mkdir(exist_ok=True)
    accounting={identifier:{"actual_full_suite":grouped.get(identifier,[]),
                            "retained_installed_Lean":approved.get(identifier)}
                for identifier in sorted(expected)}
    write(out/"method-accounting.json",accounting)
    review_path="docs/reviews/string-character-fixture-reuse-20261103.md"
    review_text=subprocess.check_output(["git","show","d3f8e099ed:"+review_path],cwd=ROOT)
    (out/"installed-Lean-reuse-review.md").write_bytes(review_text)
    samples=[json.loads(s) for s in (RECORD/"final-suite-observations-20261104.jsonl").read_text().splitlines()]
    summary={"exported_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),
             "run_id":launch["run_id"],"governed_target":launch["governed_target"],
             "managed_terminal":terminal,"observed_exec_session":launch["exec_session"],
             "observed_session_exit_code":args.session_exit_code,
             "managed_seconds":terminal["duration_seconds"],
             "unittest_test_seconds":float(unittest_summary[0][1]) if unittest_summary else None,
             "actual_unique_method_ids":len(grouped),"expected_unique_method_ids":578,
             "actual_outcomes":counts,"unknown_ids":unknown,"missing_ids":missing,
             "duplicate_ids":duplicates,"actual_skipped_ids":sorted(skipped),
             "retained_reuse_matches_all_actual_skips":skipped==set(approved),
             "retained_reuse_review_commit":"d3f8e099ed",
             "first_retained_fixture_run_disposition":"20261031T214130-1e0195247bd5 remains failed; only its five individually passing methods reused under independent approval",
             "test_file_hashes_verified":50,"fixture_dependency_paths_verified":50,
             "fixture_mapping_sha256":fixture["reviewed_mapping_sha256"],
             "managed_captured_inputs_reverified":len(prepared["inputs_sha256"]),
             "complete_suite_input_path_set_and_hashes_reverified":True,
             "native_provenance_still_valid":True,"native_inputs_unchanged":2582,
             "matching_binary_sha256":sha(host.compiler/"bin/silver"),
             "resource_samples":len(samples),
             "sampled_max_suite_rss_bytes":max(x["suite_descendant_rss_bytes"] for x in samples),
             "sampled_min_MemAvailable_bytes":min(x["host_memory_bytes"]["MemAvailable"] for x in samples),
             "sampled_min_free_disk_bytes":min(x["free_disk_bytes"] for x in samples),
             "resource_limits":"20-second samples are not true peak telemetry; two managed workers do not bound application GNATprove -j0 aggregate memory",
             "native_complete_evidence_run":"20261103T234601-0e070300d2d7",
             "complete_Lean_source_run":"20261104T022554-32f68afc7380",
             "complete_Lean_source_evidence_commit":"93a14bbb15",
             "complete_Lean_source_review_commit":"5325c23dcb",
             "status_parser_note":"Observer restarted twice: first to resolve an interleaved nested managed-run banner/final standalone ok, then to handle two-line unittest descriptions and subtest failure lines. Earlier progress samples missed the two-line Rosetta ERROR; raw-log scan discovered it, accounting was corrected, and original samples are retained. Actual suite remained uninterrupted.",
             "actual_failed_method_ids":sorted(x["id"] for x in observed if x["state"] in ("FAIL","ERROR")),
             "remaining":"Lead prepared Rosetta promotion and exactly three fresh test_rosetta methods after promotion; PR remains open",
             "model_effort":"Inherited selected setting; runtime model/effort confirmation and token/cost unavailable"}
    write(out/"summary.json",summary)
    selected={"managed/native.log":run/"native.log","managed/events.jsonl":run/"events.jsonl"}
    for name in ["summary.json","method-accounting.json","installed-Lean-reuse-review.md"]:
        selected[name]=out/name
    for name in ["final-suite-inventory-20261104.json","final-suite-launch-20261104.json",
                 "final-four-sync-and-suite-preflight-20261104.json","final-three-sync-and-fixture-check.json",
                 "fixture-closure-current-check.json","final-suite-observations-20261104.jsonl",
                 "last-final-suite-status.json","rosetta-cli-error-diagnostic-20261104.json",
                 "watch_final_suite.py","export_final_suite.py"]:
        selected["records/"+name]=RECORD/name
    write(out/"files.json",{name:{"bytes":p.stat().st_size,"sha256":sha(p)} for name,p in sorted(selected.items())})
    selected["files.json"]=out/"files.json"
    archive=out/"final-suite-evidence.tar.gz";assert not archive.exists()
    with tarfile.open(archive,"w:gz") as tar:
        for name,p in sorted(selected.items()):tar.add(p,arcname=name,recursive=False)
    result={"path":str(archive),"bytes":archive.stat().st_size,"sha256":sha(archive),"members":len(selected),"outcomes":counts,"unique_ids":len(grouped)}
    write(out/"archive.json",result)
    print(json.dumps(result,indent=2))


if __name__=="__main__":main()
