# Native String/Character validation resume — 2026-11-03

Owner authorization: resume #296 / M16; feature PR must remain open. This lane owns native validation in `tmp/string-native`, preserving the integration lead’s source/proof inputs and Oracle guarantees.

`round-state.json` records live phase state. `pre-sync-input-verification.json` verified every one of the interrupted run’s 2,582 input hashes, with zero mismatches. `interrupted-native-evidence.tar.gz` retains its complete current GNATprove workspace, managed log and events, source identities and pre-sync dirty patch. The original interrupted run and solver caches remain intact. The archive is interrupted evidence, not completed assurance.

`planned-sync.json` and `final-sync.json` identify all 155 synchronized files and verify 883 tracked validation inputs against committed integration snapshot `6b6238d323836fa47f499bf32f36f674deb01f14`. Native source differences were only the reviewed #305 catalogue exporter correction; scripts/projects matched already. Host-specific generated/configuration inputs remain native and are captured by the managed provenance preflight.

Matching build `20261103T174558-b18867ff1ff2` passed. All 10 StringCharacter methods passed in `20261103T174622-40c268b4aca8` (28.217 seconds), including native dynamic copies with noncanonical null bounds and invalid input. `catalogue-check.json` records exact binary/checked-in JSON parity, with `string_slice` in both concatenation and expression operand lists. `final-test-inventory.json` contains all 578 unique methods.

Full native run `20261103T174729-ccb497165e31` is active with two workers and unchanged required logical proof options. Complete proof/audit/provenance and the final complete suite remain open. Seven installed-Lean fixture methods are expected to skip in this lane and require final independent review against retained passing results from the integration lane; no method may remain uncovered.

Current subthread inherits its model/effort; runtime model confirmation and token/cost totals are unavailable. This record makes no claim that a live model was switched.

## Native terminal diagnostic — 19:52 UTC

Run `20261103T174729-ccb497165e31` **failed**, exit1, after7483.119seconds. Its sole reported unresolved check is `Character_Declaration_At` parser-position progress at `silver_output_profile.adb:1446:19`; altergo/CVC5/Z3 all timedout at canonical30seconds. No complete audit/provenance success exists. All2,582 captured inputs were reverified with zero mismatches. `character-progress-failure/` retains76 SPARK reports, SARIF/summary/input manifest, exact Why3 XML/shapes/gnat-json, log/events and diagnostic in a2.73MB compact archive.

Lead-authorized unchanged-source120second scoped diagnostic `20261103T195805-68f1968b62cb` is separate exploratory evidence only. The full runner remains fixed at30seconds. After its terminal outcome, the lead authorized a native-only one-line strengthening of `Skip_At` postcondition range for scoped canonical tests; no lead source sync, default setting change, cache injection or full retry is authorized yet. Full suite remains held.

## Repaired native checkpoint — 20:19 UTC

The120second exploratory run was intentionally interrupted at20:08 UTC (managed state `interrupted`, exit130), after observing481second solver CPU limits and confirming a missing modular zero-input propagation fact. It is neither failed nor successful proof evidence. The shared `Skip_At` variant was not applied.

Native commit `954fd8eacb536f3e5c126427657b7a62190cbc7c` changes only the Character declaration guard `Following = 0` to `Following <= State.Position`. Contracts/preconditions, `Skip_At` and the admission model remain unchanged. Scoped canonical run `20261103T200910-01915a66a688` passed24 GNAT checks (22 proof records +2 flow records) in36.4006seconds; the complete unchanged postcondition proved. Its portable packet is `character-progress-guard-30s/scoped-guard-pass.tar.gz`. Matching build `20261103T201517-fafe2b35ed13` and all10 StringCharacter methods `20261103T201554-0768c4b64c4a` passed on repaired bytes (25.097seconds test time).

Full canonical run `20261103T201920-c39bcc381ac2` is now active with2workers, session74844, exact source matching lead `d7299a81a21ce48bb530de03325017de8d4d942b`. All2,582 native captured inputs differ from the failed run only at the repaired Ada file. All143 source/runner/project files match the lead. Native hashes include no Lean sources; the only proof-subtree native input is `proof/silver_proof_containers.gpr`. Preserve captured native inputs and all normal sessions/cache. Complete proof/audit/provenance is still pending. Final proof/tests/Rosetta synchronization,578-ID inventory comparison and full-suite memory coordination remain after native lease release.

## Resume and scheduling checkpoint — 20:41 UTC

Preserved active repaired full native session74844 without restart. The live harness goal is absent. Guard model/source equivalence repair at lead58b0d6ce2b was independently reviewed PASS and published8a3f2baf7a; complete native and whole-project source assurance remain pending. A bounded read-only scheduling assessment (`suite-worker-propagation-assessment.json`) confirms managed test `--jobs2` reserves ledger workers but does not constrain canonical application GNATprove `-j0`. Per-prover1000MB is not a sound small total suite memory bound. Lead retained the full-suite hold until the24GiB dense Lean phase is terminal; no runner settings or policy changed.

## Resource interruption — 21:58 UTC

Repaired full run20261103T201920-c39bcc381ac2 was intentionally interrupted, not failed or completed assurance. Lead-authorized actual host threshold was met:3.279GiB available and falling below4GiB during dense Lean work. Verified isolated native process group54656 received SIGINT. Managed outcome is `interrupted`, exec session74844 exited130, duration5922.615seconds. All2,582 captured input hashes were reverified unchanged, the native group is gone,75partial SPARK reports and all native sessions/cache remain, and no completed proof-provenance manifest exists. Compact retained packet: `resource-interruption/partial-native-core.tar.gz`. Canonical same-input full proof/audit continuation remains required after dense Lean terminal; full suite remains held.

## Post-lease final validation sync — 22:00 UTC

Lead authorized and completed exact14-file sync from8a3f2baf7a:8Lean files,2Rosetta files and4tests. Preimages are preserved in `pre-final14-sync.tar.gz`. All886validation files match the lead snapshot; all2,582native proof input hashes remain unchanged. Fresh `final-test-inventory-refreshed-20261103.json` matches all578unique lead method IDs and all50test-file hashes. `final-inventory-and-fixture-closure-check.json` reconfirms the independently approved7fixture IDs and exact50-path dependency mapping. No full-suite results exist yet. Canonical full native continuation and full suite remain HELD until dense Lean releases memory. The compact successful-native exporter now takes explicit `--run-id`, `--session-id` and observed `--session-exit-code`, requires terminal success plus completed strict audit/provenance, and includes all four repair/resource-history packets.

## Canonical native continuation — 22:02 UTC

After the lead confirmed successful5090second OutputBodyCertificate completion and released memory, native full run20261103T220251-899976574bd0 started with2workers, canonical30second/prover options and retained normal sessions/cache. Exec session59150; verified isolated runnerPID/PGID89167. All2,582inputs, exact tools and canonical command match resource-interrupted run20261103T201920-c39bcc381ac2. Matching build remains valid and was not repeated. Fullsuite remains HELD for remaining densePredicate phase and complete native audit. The actual<4GiBavailable-and-growing resource guard remains authorized; reverify new group89167 before any signal. `native_status.py` now targets this continuation; former monitor preserved as `native_status-resource-interrupted-run.py`.


## Strict-audit terminal failure and bounded repair — 23:20 UTC

Run20261103T220251-899976574bd0 terminated with session exit1 after4638.447s. GNATprove proved all17,404checks, but strict audit rejected7unclassified reassociation warnings. Exhaustive traversal of the unchanged auditor evaluated920,653predicates and found exactly35failed predicates, all attributable to these7records; approved vendor/math/limitation/array notes remain distinct. The7records were byte-identical in failed174729 and were missed by its earlier proof-only triage. All2,582inputs remain unchanged; no completed provenance exists. Original76SPARK reports, SARIF/out, input manifest, source, managed logs/events and diagnostics are preserved in `operator-reassociation-failure/failed-native-core.tar.gz`.

Lead authorized only7left-association parenthesis pairs in the owned Ada source, canonical scoped proof for Fixed_Bounds_Valid, Indexed_At, Concatenated_Last and Character_Declaration_At, matching build/10StringCharacter methods, and an Ada-only Refs#296commit. Complete native rerun and suite stay held for repair review/resource coordination. Source proposal lexical delta uses scripts.check_evidence.source_tokens,52157->52171; the certificate lexer has its own count. Model/effort inherited and not runtime-confirmed; no token/cost measurements available.


## Scheduling handoff — 23:37 UTC

Ada-only seven-pair repair committed ba5686cfaa34528f1cd0917bd48c97ce999def06 and integrated by lead as63288245a1. All four canonical scopes passed69checks(58proof+11flow); matching build20261103T233404-d80bccc33dbc and all10StringCharacter methods20261103T233411-962e761487e2 passed(23.672s test body). Compact scoped packet is `parenthesis-scopes/scoped-parenthesis-pass.tar.gz`; original failed full packet is `operator-reassociation-failure/failed-native-core.tar.gz`. Final read-only preflight in `parenthesis-full-preflight.json` reverified2582inputs and unchanged tools; only Ada source differs from failed full input manifest. Full native command is prepared with ordinary retained cache and2workers; it has NOT run.

Lead requested slot release while same-tier bounded repair review finishes and will reactivate the native lane via followup_task. No native process/lease is active. On reactivation: obtain latest lead proof commit; synchronize/recheck final578IDs,50test hashes and7fixture50-path closure; then launch canonical full native proof only after review/resource release, preserve successful scopes/build/tests without publication-only reruns, and coordinate full suite afterward. The prepared successful-native exporter now expects new source/build/runtime identities and includes both new packets in repair history. Final Lean/source review remains lead-owned evidence. Model/effort inherited, runtime confirmation and token/cost unavailable.


## Complete final-byte native PASS — 2026-11-03T23:47:30.334637+00:00

Canonical full run20261103T234601-0e070300d2d7 finished successfully in87.225982053s using2workers and retained ordinary sessions/cache. Exec session72866 observed exit0. All17404checks(15916proof+1488flow) proved; strict audit and completed provenance passed across76units/1099entities. Fresh independent validate_provenance/audit_sources recheck passed with2582captured inputs and78report artifacts; final sourceSHA4a02223317f89de2653d89ac152ae9e66fb089a0cfa20cd3ecb4c8765d90c485. This is cache-reusing native evidence, not a cold-performance claim. Complete Lean/source assurance and578-method suite remain separate requirements. No native process is active; fullsuite still held for dense source/resource coordination.
