"""Export completed native evidence without copying tools, caches or sessions."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import subprocess
import sys
import tarfile


ROOT = Path(__file__).resolve().parents[2]
RECORD = Path(__file__).resolve().parent
RUN_ID = "20261103T201920-c39bcc381ac2"
SOURCE_HASH = "4a02223317f89de2653d89ac152ae9e66fb089a0cfa20cd3ecb4c8765d90c485"
HISTORY = {
    "character-progress-failure/failed-native-core.tar.gz":
        "54022efecfa68ca12c7382034f74a0ad630c12784c61420c91734acde883379a",
    "character-progress-guard-30s/scoped-guard-pass.tar.gz":
        "8b7da62388d70fb503e2cb886c5a293c63f7b256683c8ba3bd53a4961f8476f4",
    "character-progress-120s/interrupted-diagnostic.tar.gz":
        "b8fe0d7395d7f8debbe1e2ff8d3fae3457d0e5eb208f9b851ad7b2908e51c71b",
    "resource-interruption/partial-native-core.tar.gz":
        "03c7406e477628573a55d857f0a0076f68f39d14c3b4cd908c7de77930465775",
    "operator-reassociation-failure/failed-native-core.tar.gz":
        "42d590209252f5ea55034f101a1ff6d68399449d2bf61859b26362c7f6cdfa15",
    "parenthesis-scopes/scoped-parenthesis-pass.tar.gz":
        "4d6e1f460bf5071adb40f1b4013c24f4b1c6bd20478beb6f3e0617de0b847683",
}


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def run_directory(common, run_id):
    paths = list((common / "silver-runs").glob("*/*/runs/" + run_id))
    assert len(paths) == 1, paths
    return paths[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--session-exit-code", required=True, type=int)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--session-id", required=True, type=int)
    args = parser.parse_args()
    assert args.session_exit_code == 0, "export requires observed successful exec-session exit"
    sys.path.insert(0, str(ROOT))
    from scripts.check_evidence import audit_sources
    from scripts.platforms import native_layout
    from scripts.proof_provenance import validate_provenance

    common = Path(subprocess.check_output(
        ["git", "-C", str(ROOT), "rev-parse", "--path-format=absolute", "--git-common-dir"],
        text=True).strip())
    run_id = args.run_id
    run = run_directory(common, run_id)
    events = [json.loads(line) for line in (run / "events.jsonl").read_text().splitlines()]
    finish = events[-1]
    assert finish["event"] == "finished" and finish["outcome"] == "success", finish
    # ManagedRun.__exit__ records successful completion with returncode=None.
    # The terminal-session exit is observed independently and supplied above.
    assert finish["returncode"] in (0, None), finish
    assert any(event.get("event") == "phase-end" and event.get("phase") == "audit"
               for event in events), "missing completed strict-audit phase"
    host = native_layout(ROOT)
    reports = host.compiler / "obj/gnatprove"
    manifest = validate_provenance(host, reports)
    stats = audit_sources(ROOT / "src", reports, host.generated,
                          effective_command=manifest["command"])
    assert digest(ROOT / "src/silver_output_profile.adb") == SOURCE_HASH
    retained = run / "proof-evidence"
    assert retained.is_dir()
    for path in retained.iterdir():
        assert path.is_file() and digest(path) == digest(reports / path.name), path

    selected = {}

    def add(name, path):
        assert name not in selected, name
        assert path.is_file(), path
        selected[name] = path

    for path in sorted(retained.iterdir()):
        add("native/proof-evidence/" + path.name, path)
    for name in ("native.log", "events.jsonl"):
        add("native/managed/" + name, run / name)
    for prior_id, prefix in (
        ("20261103T233404-d80bccc33dbc", "matching-build"),
        ("20261103T233411-962e761487e2", "affected-tests"),
    ):
        prior = run_directory(common, prior_id)
        prior_events = [json.loads(line) for line in (prior / "events.jsonl").read_text().splitlines()]
        assert prior_events[-1].get("event") == "finished"
        assert prior_events[-1].get("outcome") == "success", prior_events[-1]
        for name in ("native.log", "events.jsonl"):
            add(prefix + "/" + name, prior / name)
    for name, expected in HISTORY.items():
        path = RECORD / name
        assert digest(path) == expected, path
        add("repair-history/" + name, path)
    for directory, suffixes in ((ROOT / "src", {".ads", ".adb"}),
                                (ROOT / "scripts", {".py"}),
                                (host.generated, {".ads", ".adb"})):
        for path in sorted(directory.rglob("*")):
            if path.is_file() and path.suffix in suffixes:
                relative = path.relative_to(ROOT)
                assert manifest["inputs_sha256"].get(str(relative)) == digest(path), path
                add("captured-inputs/" + str(relative), path)
    for relative in ("silver.gpr", "alire.toml", "proof/silver_proof_containers.gpr"):
        add("captured-inputs/" + relative, ROOT / relative)
    for relative in (
        "README.md", "round-state.json", "guard-full-input-check.json", "guard-full-prelaunch.json",
        "suite-worker-propagation-assessment.json", "native-observations-" + run_id + ".jsonl",
        "last-native-status.json", "export_native_evidence.py",
        "parenthesis-full-preflight.json", "parenthesis-input-delta.json",
        "operator-reassociation-patch-assessment.json", "parenthesis-scopes/summary.json",
        "character-progress-failure/input-verification.json",
        "character-progress-guard-30s/source-change.json", "character-progress-guard-30s/source.patch",
        "character-progress-guard-30s/result.json", "character-progress-120s/interruption.json",
    ):
        add("records/" + relative, RECORD / relative)

    destination = RECORD / "completed-native"
    destination.mkdir(exist_ok=True)
    summary = {
        "exported_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "run_id": run_id,
        "managed_finished": finish,
        "observed_exec_session": args.session_id,
        "observed_session_exit_code": args.session_exit_code,
        "fresh_read_only_audit_stats": stats,
        "native_platform": host.key,
        "mode": manifest["mode"],
        "initial_state": manifest["initial_state"],
        "canonical_command": manifest["command"],
        "captured_input_count": len(manifest["inputs_sha256"]),
        "strict_report_artifacts": len(manifest["reports_sha256"]),
        "source_sha256": SOURCE_HASH,
        "native_repair_commit": "ba5686cfaa34528f1cd0917bd48c97ce999def06",
        "matching_integration_source_commit": subprocess.check_output(
            ["git", "rev-parse", "63288245a1"], cwd=ROOT, text=True).strip(),
        "earlier_guard_repair_commit": "954fd8eacb536f3e5c126427657b7a62190cbc7c",
        "earlier_guard_semantic_review_target": "58b0d6ce2babb4bb817df89ffd4392c815d4ff06",
        "earlier_guard_semantic_review_published": "8a3f2baf7a",
        "parenthesis_source_semantic_review": "Lead-owned repair review and complete Lean/source correspondence are separate required integration evidence",
        "repair_history_dispositions": {
            "20261103T174729-ccb497165e31": "failed full native proof; unchanged progress postcondition unresolved, and seven reassociation warnings already present but missed by initial proof-only triage",
            "20261103T195805-68f1968b62cb": "intentionally interrupted larger-budget diagnostic; neither failed nor successful proof",
            "20261103T200910-01915a66a688": "scoped canonical repaired-source pass, 24 GNAT checks; not full assurance",
            "20261103T201920-c39bcc381ac2": "intentionally interrupted at actual host resource threshold; all 2582 inputs unchanged and successful sessions/cache retained; not failed or completed proof",
            "20261103T220251-899976574bd0": "all 17404 checks proved, but strict audit failed on seven unclassified reassociation warnings; no completed assurance/provenance",
            "parenthesis-scopes": "four canonical isolated scopes prove 69 checks on seven-pair repair; matching build and ten affected methods pass; not complete assurance",
        },
        "limits": "Native compiler proof/audit only. Complete Lean/source and final regression accounting are separate required evidence.",
        "model_effort": "Inherited agent model/effort; runtime settings and token/cost measurements unavailable",
    }
    summary_path = destination / "summary.json"
    summary_path.write_text(json.dumps(summary, indent=2) + "\n")
    add("summary.json", summary_path)
    files = {name: {"bytes": path.stat().st_size, "sha256": digest(path)}
             for name, path in selected.items()}
    files_path = destination / "files.json"
    files_path.write_text(json.dumps(files, indent=2) + "\n")
    archive = destination / "completed-native-evidence.tar.gz"
    assert not archive.exists(), "preserve existing export; inspect it instead of overwriting"
    with tarfile.open(archive, "w:gz") as bundle:
        for name, path in selected.items():
            bundle.add(path, arcname=name, recursive=False)
        bundle.add(files_path, arcname="files.json", recursive=False)
    result = {"path": str(archive.relative_to(ROOT)), "bytes": archive.stat().st_size,
              "sha256": digest(archive), "members": len(selected) + 1, "stats": stats}
    (destination / "archive.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
