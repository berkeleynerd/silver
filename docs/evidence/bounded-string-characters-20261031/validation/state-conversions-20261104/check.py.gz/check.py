from pathlib import Path
import hashlib,json,os,resource,subprocess,sys,time
PACKET=Path(__file__).resolve().parent
ROOT=PACKET.parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from platforms import native_layout
from bootstrap_lean import lean_environment
from run_history import ManagedRun
host=native_layout(ROOT)
inputs=json.loads((PACKET/'inputs.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs['input_sha256'][str(Path(__file__).resolve())]=sha(Path(__file__).resolve())
commands=[
 [str(host.lean/'bin/lean'),'-j1','-M4096','-DwarningAsError=true',str(PACKET/'ComposeSourceBridgeProbe.lean'),'-o',str(PACKET/'ComposeSourceBridgeProbe.olean'),'-i',str(PACKET/'ComposeSourceBridgeProbe.ilean')],
 [str(host.lean/'bin/lean'),'-j1','-M4096','-DwarningAsError=true',str(PACKET/'AuditProbe.lean')]]
log=PACKET/'check.log';report=PACKET/'evidence.json'
with ManagedRun(host,'lean-diagnostic',[sys.executable,str(Path(__file__).resolve())],inputs,[PACKET],workers=1,task='#296-source-state-conversions',reason='Check existing state-domain conversions in proof bodies against completed source dependencies; keep active complete-run inputs frozen and preserve all statements and source interpretation domains',evidence=[log,report]) as run:
 run.prepare(inputs)
 env={**lean_environment(host),'LEAN_PATH':str(PACKET)+os.pathsep+str(host.proof/'.lake/build/lib/lean')}
 started=time.monotonic();phases=[];output='';code=0
 for name,command in zip(['exact-module-check','fresh-axiom-audit'],commands):
  run.event('phase',phase=name,command=command)
  tick=time.monotonic();p=subprocess.run(command,cwd=PACKET,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,pass_fds=run.pass_fds,timeout=180)
  output+=p.stdout;log.write_text(output);phases.append({'phase':name,'command':command,'elapsed_seconds':time.monotonic()-tick,'returncode':p.returncode})
  if p.returncode:code=p.returncode;break
 changed=[name for name,expected in inputs['input_sha256'].items() if sha(Path(name))!=expected]
 audit_passed='Silver axiom audit passed:' in output
 if not code and (changed or not audit_passed):code=125 if changed else 126
 result={**inputs,'run_id':run.run_id,'phases':phases,'elapsed_seconds':time.monotonic()-started,'max_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'returncode':code,'changed_inputs':changed,'fresh_audit_passed':audit_passed,'selected_lead_model_effort':'Inherited lead setting; runtime model/effort confirmation unavailable','tokens_cost':'unavailable'}
 report.write_text(json.dumps(result,indent=2)+'\n')
 print(output[-3500:],flush=True);print(json.dumps({k:result[k] for k in ['run_id','elapsed_seconds','max_rss_kib','returncode','changed_inputs','fresh_audit_passed']},indent=2),flush=True)
 run.finish('success' if code==0 else 'failure',returncode=code)
 sys.exit(code)
