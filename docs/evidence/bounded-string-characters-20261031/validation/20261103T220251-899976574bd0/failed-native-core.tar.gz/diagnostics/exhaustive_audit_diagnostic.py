"""Record every unchanged strict-auditor assertion; diagnostic only, never assurance."""
from collections import Counter
from pathlib import Path
import datetime
import difflib
import hashlib
import inspect
import json
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
RECORD = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts import check_evidence as audit
from scripts.platforms import native_layout


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    (RECORD / name).write_text(json.dumps(value, indent=2) + "\n")


def traverse(report_dir, *, source_checks):
    host = native_layout(ROOT)
    source_paths = sorted(p for d in (ROOT / "src", host.generated)
                          for p in d.rglob("*") if p.suffix in (".ads", ".adb"))
    expected_units = {p.stem for p in source_paths}
    trusted = {p.stem for p in source_paths if p.name in audit.TRUSTED_IMPORT_SPECS}
    instances = {u: audit.audit_sequence_instance(ROOT / "src" / (u + ".ads"))
                 for u in audit.SEQUENCE_INSTANCES}
    conversion = audit.audit_signed_conversion_instance(ROOT / "src" /
                                                        (audit.SIGNED_CONVERSION_UNIT + ".ads"))
    manifest = json.loads((host.compiler / "obj/gnatprove/proof-inputs.json").read_text())
    violations = []
    classifications = Counter()
    records = []
    visited = 0
    original_require = audit.require

    def record_require(condition, message):
        nonlocal visited
        visited += 1
        frame = inspect.currentframe().f_back
        local = frame.f_locals
        if "diagnostic is not proved/info:" in message:
            record = local["record"]
            kind = "info" if record.get("severity") == "info" else "unclassified"
            for flag in ("limitation", "math_note", "array_note", "advisory", "image_note"):
                if local.get(flag):
                    kind = flag
            classifications[(local["key"], kind, record.get("rule", ""))] += 1
            if local["key"] == "warn_error":
                records.append({"unit": local["unit"], "category": kind, "record": record})
        if not condition:
            failure = {"function": frame.f_code.co_name, "auditor_line": frame.f_lineno,
                       "message": message}
            if frame.f_code.co_name == "audit_reports":
                if frame.f_lineno < 590:
                    failure.update(unit=local.get("unit"), section=local.get("key"),
                                   record=local.get("record"))
                elif "result" in local:
                    failure.update(section="SARIF", result=local["result"])
            violations.append(failure)

    audit.require = record_require
    try:
        if source_checks:
            stats = audit.audit_sources(ROOT / "src", report_dir, host.generated,
                                        effective_command=manifest["command"])
        else:
            stats = audit.audit_reports(report_dir, expected_units, trusted,
                                        proof_instances=instances,
                                        signed_conversion_instance=conversion)
    finally:
        audit.require = original_require
    return {"strict_audit_pass": False, "diagnostic_only": True,
            "method": "Unchanged audit implementation; every require predicate evaluated; false predicates recorded rather than raised. No reports, source, audit policy or proof inputs modified.",
            "report_dir": str(report_dir), "source_checks_included": source_checks,
            "require_predicates_visited": visited, "violations": violations,
            "violations_by_auditor_line": dict(Counter(str(x["auditor_line"]) for x in violations)),
            "stats_from_complete_diagnostic_traversal": stats,
            "record_classifications": [{"section": k[0], "category": k[1], "rule": k[2], "count": v}
                                       for k, v in sorted(classifications.items())],
            "all_warn_error_records": records}


def main():
    host = native_layout(ROOT)
    reports = host.compiler / "obj/gnatprove"
    current = traverse(reports, source_checks=True)
    write("strict-audit-exhaustive-current.json", current)
    previous = Path("/home/canto/src/github.com/berkeleynerd/silver/.git/silver-runs/linux-x86_64/d140f139bb2e1ef1/runs/20261103T174729-ccb497165e31/reports/0")
    old = traverse(previous, source_checks=False)
    write("strict-audit-exhaustive-174729.json", old)
    packet = RECORD / "character-progress-failure/failed-native-core.tar.gz"
    with tarfile.open(packet) as archive:
        packed = json.load(archive.extractfile("reports/silver_output_profile.spark"))
    old_seven = [x for x in packed["warn_error"] if x.get("rule") == "operator-reassociation"]
    current_seven = [x["record"] for x in current["all_warn_error_records"]
                     if x["record"].get("rule") == "operator-reassociation"]
    assert len(current_seven) == 7
    manifest = json.loads((reports / "proof-inputs.json").read_text())
    mismatches = [name for name, expected in manifest["inputs_sha256"].items()
                  if sha(ROOT / name) != expected]
    assert not mismatches, mismatches
    summary = {"recorded_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "current_run": "20261103T220251-899976574bd0", "outcome": "failed strict audit; no complete assurance/provenance",
               "auditor_sha256": sha(ROOT / "scripts/check_evidence.py"),
               "current_stats": current["stats_from_complete_diagnostic_traversal"],
               "current_violations": len(current["violations"]),
               "current_violation_lines": current["violations_by_auditor_line"],
               "current_classifications": current["record_classifications"],
               "previous_stats": old["stats_from_complete_diagnostic_traversal"],
               "previous_violations": len(old["violations"]),
               "previous_violation_lines": old["violations_by_auditor_line"],
               "previous_packet": str(packet), "previous_packet_sha256": sha(packet),
               "previous_packet_operator_reassociation_records": old_seven,
               "all_seven_identical_in_previous_packet": old_seven == current_seven,
               "previous_analysis_correction": "174729 diagnostic isolated the one unresolved proof obligation, but did not exhaust strict-audit failures. Seven byte-identical reassociation warnings were already present and omitted from that failure summary.",
               "inputs_verified": len(manifest["inputs_sha256"]), "input_mismatches": mismatches}
    write("strict-audit-exhaustive-summary.json", summary)

    source = ROOT / "src/silver_output_profile.adb"
    before = source.read_text()
    pairs = [
        ("Scalars.Wide (Last_Index) - Scalars.Wide (First_Index) + 1", "(Scalars.Wide (Last_Index) - Scalars.Wide (First_Index)) + 1"),
        ("Scalars.Wide (High.Bounds.Lower) - Scalars.Wide (Low.Bounds.Upper) + 1", "(Scalars.Wide (High.Bounds.Lower) - Scalars.Wide (Low.Bounds.Upper)) + 1"),
        ("Scalars.Wide (High.Bounds.Upper) - Scalars.Wide (Low.Bounds.Lower) + 1", "(Scalars.Wide (High.Bounds.Upper) - Scalars.Wide (Low.Bounds.Lower)) + 1"),
        ("Low.Operands + High.Operands + 1", "(Low.Operands + High.Operands) + 1"),
        ("Scalars.Wide (Left.Static_Length) + Scalars.Wide (Right.Static_Length)\n", "(Scalars.Wide (Left.Static_Length) + Scalars.Wide (Right.Static_Length))\n"),
        ("Scalars.Wide (First.Lower) + Minimum - 1", "(Scalars.Wide (First.Lower) + Minimum) - 1"),
        ("Scalars.Wide (First.Upper) + Maximum - 1", "(Scalars.Wide (First.Upper) + Maximum) - 1"),
    ]
    after = before
    for left, right in pairs:
        assert after.count(left) == 1, left
        after = after.replace(left, right)
    candidate = RECORD / "silver_output_profile-parenthesized.adb"
    candidate.write_text(after)
    patch = "".join(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
                                       fromfile="a/src/silver_output_profile.adb", tofile="b/src/silver_output_profile.adb"))
    (RECORD / "operator-reassociation-seven-sites.patch").write_text(patch)
    old_tokens = audit.source_tokens(source)
    new_tokens = audit.source_tokens(candidate)
    diff = difflib.SequenceMatcher(a=old_tokens, b=new_tokens, autojunk=False)
    edits = [{"operation": op, "old_indices": [a,b], "new_indices": [c,d],
              "removed": old_tokens[a:b], "added": new_tokens[c:d]}
             for op,a,b,c,d in diff.get_opcodes() if op != "equal"]
    assert all(x["operation"] == "insert" and x["added"] in (["("], [")"]) for x in edits)
    assert len(edits) == 14
    write("operator-reassociation-patch-assessment.json", {
        "source_untouched": sha(source) == manifest["inputs_sha256"]["src/silver_output_profile.adb"],
        "source_sha256": sha(source), "candidate_sha256": sha(candidate),
        "patch_sha256": sha(RECORD / "operator-reassociation-seven-sites.patch"),
        "source_token_count": len(old_tokens), "candidate_token_count": len(new_tokens),
        "token_delta": len(new_tokens) - len(old_tokens), "exact_token_edits": edits,
        "site_count": len(pairs), "changed_lines": [166,705,707,712,1049,1052,1053],
        "semantic_intent": "Make the existing left association explicit at every flagged chain; no operand/operator, type, bound, guard or contract changes. Native revalidation and Lean source/certificate correspondence on final bytes remain required.",
        "verification_status": "Draft proposal only; no proof/build/runtime/certificate validation of candidate bytes yet."})
    print(json.dumps({k: summary[k] for k in ("current_stats", "current_violations", "current_violation_lines", "previous_violations", "all_seven_identical_in_previous_packet", "inputs_verified")}, indent=2))
    print("Draft patch:", RECORD / "operator-reassociation-seven-sites.patch")


if __name__ == "__main__":
    main()
