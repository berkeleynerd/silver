"""Preserve the original failed strict-audit checkpoint; never export as success."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
RECORD = Path(__file__).resolve().parent
RUN_ID = "20261103T220251-899976574bd0"
RUN = Path("/home/canto/src/github.com/berkeleynerd/silver/.git/silver-runs/linux-x86_64/d140f139bb2e1ef1/runs") / RUN_ID
REPORTS = ROOT / ".silver/linux-x86_64/compiler/obj/gnatprove"
OUT = RECORD / "operator-reassociation-failure"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def main():
    OUT.mkdir(exist_ok=True)
    events = [json.loads(s) for s in (RUN / "events.jsonl").read_text().splitlines()]
    terminal = events[-1]
    assert terminal["event"] == "finished" and terminal["outcome"] == "failure"
    assert not (REPORTS / "proof-provenance.json").exists()
    manifest = json.loads((REPORTS / "proof-inputs.json").read_text())
    mismatches = [name for name, expected in manifest["inputs_sha256"].items()
                  if sha(ROOT / name) != expected]
    assert not mismatches
    retained = RUN / "reports/0"
    paths = sorted(retained.iterdir())
    assert len(paths) == 78
    assert all(sha(p) == sha(REPORTS / p.name) for p in paths)
    source = ROOT / "src/silver_output_profile.adb"
    assert sha(source) == "757d2ae81671cb54839908cd8139cb3fdd0996be4876d2555f592e93c775e95f"
    lines = source.read_text().splitlines()
    context = "\n\n".join("\n".join(f"{i}: {lines[i-1]}" for i in range(a,b+1))
                            for a,b in [(150,169),(637,715),(1030,1069)])
    (OUT / "source-context.txt").write_text(context + "\n")
    summary = {
        "run_id": RUN_ID, "state": "failed strict audit; GNATprove all checks proved; no complete assurance/provenance",
        "session_id": 59150, "observed_session_exit_code": 1,
        "finished_utc": terminal["utc"], "duration_seconds": terminal["duration_seconds"],
        "strict_audit_error": terminal["error"], "source_sha256": sha(source),
        "native_commit": subprocess.check_output(["git","rev-parse","HEAD"], cwd=ROOT, text=True).strip(),
        "required_proof_checks": 15916, "required_flow_checks": 1488,
        "unclassified_diagnostics": "Exactly seven operator-reassociation warnings; exhaustive unchanged-auditor traversal found 35 predicate failures attributable to their SPARK/SARIF fields and no others.",
        "prior_failure_correction": "Seven identical warnings were already present in failed174729; earlier triage omitted them while reporting its sole unproved VC.",
        "inputs_reverified": len(manifest["inputs_sha256"]), "input_mismatches": mismatches,
        "original_reports_reverified_against_retained": len(paths),
        "provenance_manifest_present": False,
        "lexical_delta_tool": "scripts.check_evidence.source_tokens (52,157 -> 52,171); certificate lexer has separate token count",
        "model_effort": "Inherited selected agent setting; runtime model/effort confirmation and token/cost measurements unavailable",
        "scope": "Read-only failed-checkpoint preservation plus scratch diagnostics/proposal; no auditor/policy/configuration/source modifications at capture",
    }
    write(OUT / "summary.json", summary)
    selected = {"reports/" + p.name: p for p in paths}
    selected["reports/proof-inputs.json"] = REPORTS / "proof-inputs.json"
    for name in ("native.log", "events.jsonl"):
        selected["managed/" + name] = RUN / name
    for directory in (ROOT / "src", ROOT / ".silver/linux-x86_64/generated"):
        for p in directory.rglob("*"):
            if p.is_file() and p.suffix in (".adb", ".ads"):
                selected["snapshot/" + str(p.relative_to(ROOT))] = p
    for name in ("scripts/check_evidence.py", "scripts/proof_provenance.py", "scripts/platforms.py",
                 "scripts/bootstrap.py", "silver.gpr", "proof/silver_proof_containers.gpr"):
        selected["snapshot/" + name] = ROOT / name
    for name in ("operator-reassociation-diagnostic.json", "operator-reassociation-focus.json",
                 "strict-audit-exhaustive-current.json", "strict-audit-exhaustive-174729.json",
                 "strict-audit-exhaustive-summary.json", "exhaustive_audit_diagnostic.py",
                 "operator-reassociation-seven-sites.patch", "operator-reassociation-patch-assessment.json",
                 "silver_output_profile-parenthesized.adb", "package_failed_audit.py"):
        selected["diagnostics/" + name] = RECORD / name
    for name in ("summary.json", "source-context.txt"):
        selected[name] = OUT / name
    files = {name: {"bytes": p.stat().st_size, "sha256": sha(p)} for name,p in sorted(selected.items())}
    write(OUT / "files.json", files)
    selected["files.json"] = OUT / "files.json"
    archive = OUT / "failed-native-core.tar.gz"
    assert not archive.exists(), archive
    with tarfile.open(archive, "w:gz") as tar:
        for name,p in sorted(selected.items()):
            tar.add(p, arcname=name, recursive=False)
    archive_record = {"path": str(archive), "bytes": archive.stat().st_size,
                      "sha256": sha(archive), "members": len(selected),
                      "state": summary["state"]}
    write(OUT / "archive.json", archive_record)
    state_path = RECORD / "round-state.json"
    state = json.loads(state_path.read_text())
    state["updated_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    state["full_native"].update(state=summary["state"], finished_utc=terminal["utc"],
                              duration_seconds=terminal["duration_seconds"], exec_exit_code=1,
                              native_runner_pid=None, native_process_group=None,
                              terminal_failure_packet=archive_record,
                              latest_observation={"terminal": "failure", "native_process_running": False,
                                                  "complete_assurance": False,
                                                  "exact_unclassified_warnings": 7})
    state["final_suite"]["state"] = "held pending scoped parenthesis repair, complete native/source assurance and resource coordination"
    state["continuation_checkpoint"].update(
        achieved="All 17,404 native checks proved, but strict audit failed on seven reassociation warnings. Exhaustive audit traversal confirms no other current failures; original failed checkpoint preserved before any repair.",
        unresolved="Apply authorized seven-pair source repair; canonical four-scope proof, matching build/10 tests; repair review; complete native/source audit; final 578-method suite",
        next_step="Lead authorized only seven left-association parenthesis pairs in native source, then four helper scopes and matching build/10 methods; full native rerun remains held.")
    write(state_path,state)
    with (RECORD / "README.md").open("a") as f:
        f.write("\n\n## Strict-audit terminal failure and bounded repair — 23:20 UTC\n\n"
                "Run20261103T220251-899976574bd0 terminated with session exit1 after4638.447s. GNATprove proved all17,404checks, but strict audit rejected7unclassified reassociation warnings. Exhaustive traversal of the unchanged auditor evaluated920,653predicates and found exactly35failed predicates, all attributable to these7records; approved vendor/math/limitation/array notes remain distinct. The7records were byte-identical in failed174729 and were missed by its earlier proof-only triage. All2,582inputs remain unchanged; no completed provenance exists. Original76SPARK reports, SARIF/out, input manifest, source, managed logs/events and diagnostics are preserved in `operator-reassociation-failure/failed-native-core.tar.gz`.\n\n"
                "Lead authorized only7left-association parenthesis pairs in the owned Ada source, canonical scoped proof for Fixed_Bounds_Valid, Indexed_At, Concatenated_Last and Character_Declaration_At, matching build/10StringCharacter methods, and an Ada-only Refs#296commit. Complete native rerun and suite stay held for repair review/resource coordination. Source proposal lexical delta uses scripts.check_evidence.source_tokens,52157->52171; the certificate lexer has its own count. Model/effort inherited and not runtime-confirmed; no token/cost measurements available.\n")
    print(json.dumps(archive_record, indent=2))


if __name__ == "__main__":
    main()
