import Silver.ComposeStringNative
import Silver.AxiomAudit

set_option maxRecDepth 100000
set_option maxHeartbeats 4000000

namespace Silver.Compose.StringNative
open Silver.Compose.Expressions

/- The three BeforeGrouping definitions below are exact captured baseline blocks,
with only their names changed. These scratch definitions are not production inputs. -/

def fixedBoundsBodyBeforeGrouping : Expr .truth :=
  let length : Expr .number := .variable "length"
  let dynamic : Expr .truth := .variable "dynamic"
  let first : Expr .integer := .variable "first_index"
  let last : Expr .integer := .variable "last_index"
  .ite (.variable "is_character")
    (.andThen (.andThen (.andThen (.not dynamic) (.eq length (.number 1)))
      (.integerEq first (.integerNumber 1))) (.integerEq last (.integerNumber 1))) <|
  .elsif dynamic (.eq length (.number 0)) <|
  .elsif (.eq length (.number 0)) (.integerGt first last) <|
    .andThen (.andThen (.andThen (.integerGe first (.integerNumber 1)) (.integerGe last first))
      (.integerEq (.integerAdd (.integerSub (.wideInteger last) (.wideInteger first)) (.integerNumber 1)) (.wideNumber length)))
      (.integerLe (.wideInteger last) (.integerMul (.wideNumber (.variable "slot")) (.wideNumber .maxLength)))

def concatenatedLastBodyBeforeGrouping : Body .interval :=
  let left : Expr .scan := .variable "left"
  let right : Expr .value := .variable "right"
  let first : Expr .interval := .variable "first"
  let minimum : Expr .integer := .variable "minimum"
  let maximum : Expr .integer := .variable "maximum"
  let low : Expr .integer := .variable "low"
  let high : Expr .integer := .variable "high"
  let result : Expr .interval := .variable "result"
  ⟨"concatenated_last", [
    constant .interval "first" ["scalars", ".", "interval"]
      (.app (.app (.function .concatenatedFirst) left) right),
    constant .integer "minimum" ["scalars", ".", "wide"]
      (.integerAdd (.wideNumber (.field .scanMinimum left)) (.wideNumber (.field .valueMinimum right))),
    constant .integer "maximum" ["scalars", ".", "wide"]
      (.integerAdd (.integerAdd (.wideNumber (.field .scanLength left)) (.wideNumber (.field .valueLength right)))
        (.integerMul (.group <| .integerAdd (.wideNumber (.field .scanDynamic left))
          (.group <| .ite (.field .valueDynamic right) (.integerNumber 1) (.integerNumber 0)))
          (.wideNumber .maxLength))),
    constant .integer "low" ["scalars", ".", "wide"]
      (.integerSub (.integerAdd (.wideInteger (.field .intervalLower first)) minimum) (.integerNumber 1)),
    constant .integer "high" ["scalars", ".", "wide"]
      (.integerSub (.integerAdd (.wideInteger (.field .intervalUpper first)) maximum) (.integerNumber 1)),
    uninitialized .interval ["result"] ["scalars", ".", "interval"]],
    .list [
      guard (.orElse (.eq (.field .scanOperands left) (.number 0))
        (.group <| .andThen (.eq (.field .scanLength left) (.number 0)) (.eq (.field .scanDynamic left) (.number 0))))
        (.field .valueLastIndex right),
      guard (.orElse (.orElse (.orElse (.orElse
        (.app (.function .scalarEmpty) first) (.integerLt low .minimumInteger))
        (.integerGt low .maximumInteger)) (.integerLt high .minimumInteger)) (.integerGt high .maximumInteger))
        .emptyInterval,
      .assign "result" (.interval (.valueInteger low) (.valueInteger high)),
      .choose (.integerEq minimum (.integerNumber 0))
        (.assign "result" (.joinInterval result (.field .valueLastIndex right))) .nothing,
      .returned result]⟩

def indexedBodyBeforeGrouping : Body .value :=
  let text : Expr .source := .variable "text"
  let position : Expr .number := .variable "position"
  let names : Expr .names := .variable "names"
  let scalarNames : Expr .scalarNames := .variable "scalar_names"
  let arrays : Expr .arrayMetadata := .variable "arrays"
  let initials : Expr .arrayInitials := .variable "initials"
  let elaborating : Expr .truth := .variable "elaborating"
  let first : Expr .number := .variable "first"
  let after : Expr .number := .variable "after"
  let target : Expr .number := .variable "target"
  let low : Expr .scalarResult := .variable "low"
  let high : Expr .scalarResult := .variable "high"
  let following : Expr .number := .variable "following"
  let minimum : Expr .integer := .variable "minimum"
  let maximum : Expr .integer := .variable "maximum"
  let info := Expr.item names target
  let bounds (value : Expr .scalarResult) := Expr.field .scalarBounds value
  let lower (value : Expr .scalarResult) := Expr.field .intervalLower (bounds value)
  let upper (value : Expr .scalarResult) := Expr.field .intervalUpper (bounds value)
  let operands := Expr.add (.field .scalarOperands low) (.field .scalarOperands high)
  let take (p : Expr .number) (token : ShellToken) :=
    Expr.app (.app (.app (.function .takeToken) text) p) (.token token)
  ⟨"indexed_at", [
    constant .number "first" ["literal_position"] (.app (.app (.function .skip) text) position),
    constant .number "after" ["literal_position"] (.app (.app (.function .nameAfter) text) first),
    constant .number "target" ["binding_count"] (.app (.app (.app (.app (.function .lookupName) text) names) first) after),
    constant .scalarResult "low" ["scalar_expressions", ".", "expression_result"]
      (.scalarReadArrays text (take after (.symbol "(")) scalarNames arrays initials elaborating),
    uninitialized .scalarResult ["high"] ["scalar_expressions", ".", "expression_result"],
    uninitialized .number ["following"] ["literal_position"],
    uninitialized .integer ["minimum", "maximum"] ["scalars", ".", "wide"]],
    .list [
      guard (anyOf [
        .eq target (.number 0), .field .bindingCharacter info, .field .bindingDynamic info,
        .ne (.app (.app (.app (.app (.function .scalarLookup) text) scalarNames) first) after) (.number 0),
        .eq (.field .scalarAfter low) (.number 0), .app (.function .scalarEmpty) (bounds low)]) .invalidValue,
      .choose (.variable "character_element") (.list [
        .assign "following" (take (.field .scalarAfter low) (.symbol ")")),
        guard (anyOf [
          .le following position, .eq (.field .scalarOperands low) .maxOperands,
          .integerLt (lower low) (.field .bindingFirstIndex info),
          .integerGt (upper low) (.field .bindingLastIndex info)]) .invalidValue,
        .returned (.nativeValue following (.number 0) (.number 1) (.number 1)
          (.truth false) (.truth true) (.truth false) target
          (.add (.field .scalarOperands low) (.number 1))
          (.singleton (.integerNumber 1)) (.singleton (.integerNumber 1)))]) .nothing,
      .assign "high" (.scalarReadArrays text (take (.field .scalarAfter low) (.symbol ".."))
        scalarNames arrays initials elaborating),
      .assign "following" (take (.field .scalarAfter high) (.symbol ")")),
      guard (anyOf [
        .le following position, .app (.function .scalarEmpty) (bounds high), .ge operands .maxOperands,
        .group <| .andThen (.integerLe (lower low) (upper high))
          (.group <| .orElse (.integerLt (lower low) (.field .bindingFirstIndex info))
            (.integerGt (upper high) (.field .bindingLastIndex info)))]) .invalidValue,
      .assign "minimum" (.wideMaximum (.integerNumber 0)
        (.integerAdd (.integerSub (.wideInteger (lower high)) (.wideInteger (upper low))) (.integerNumber 1))),
      .assign "maximum" (.wideMaximum (.integerNumber 0)
        (.integerAdd (.integerSub (.wideInteger (upper high)) (.wideInteger (lower low))) (.integerNumber 1))),
      guard (.integerGt maximum (.wideNumber .maxLength)) .invalidValue,
      .returned (.nativeValue following (.number 0) (.capacityInteger minimum) (.capacityInteger maximum)
        (.truth false) (.truth true) (.truth false) target (.add operands (.number 1)) (bounds low) (bounds high))]⟩

theorem fixedBoundsBody_grouping_preserves_eval (calls : Calls) (locals : Locals) :
    fixedBoundsBody.eval calls locals = fixedBoundsBodyBeforeGrouping.eval calls locals := by rfl

theorem concatenatedLastBody_grouping_preserves_eval (calls : Calls) (locals : Locals) :
    concatenatedLastBody.eval calls locals = concatenatedLastBodyBeforeGrouping.eval calls locals := by rfl

theorem indexedBody_grouping_preserves_eval (calls : Calls) (locals : Locals) :
    indexedBody.eval calls locals = indexedBodyBeforeGrouping.eval calls locals := by rfl

end Silver.Compose.StringNative

#silver_audit
