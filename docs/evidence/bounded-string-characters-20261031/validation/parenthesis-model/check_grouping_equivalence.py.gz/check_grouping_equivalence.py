"""Check scratch whole-body grouping equivalences against focused model artifacts."""
from pathlib import Path
import hashlib
import json
import resource
import subprocess
import sys
import time

PACKET = Path(__file__).resolve().parent
ROOT = PACKET.parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from bootstrap_lean import lean_environment
from platforms import native_layout
from run_history import ManagedRun

mode = sys.argv[1] if len(sys.argv) > 1 else 'equivalence'
assert mode in ('equivalence', 'render')
host = native_layout(ROOT)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
evidence = json.loads((host.artifacts / 'lean-focused-evidence.json').read_text())
assert evidence['axiom_audit'] == 'passed'
assert evidence['targets'] == ['Silver.ComposeHelperEquations', 'Silver.ComposeModelHelperEquations']
assert evidence['memory_mb_per_process'] == 4096
identities = {}
for name in evidence['modules']:
    source = ROOT / 'proof' / (name.replace('.', '/') + '.lean')
    identities[str(source)] = sha(source)
    stem = host.proof / '.lake/build/lib/lean' / name.replace('.', '/')
    for suffix in ['.olean', '.olean.private', '.olean.server', '.ir']:
        path = stem.with_name(stem.name + suffix)
        if path.is_file(): identities[str(path)] = sha(path)
for path in [PACKET / 'GroupingEquivalence.lean', PACKET / 'ComposeStringNative.before.lean',
             Path(__file__).resolve(), ROOT / 'proof/lakefile.lean', ROOT / 'proof/lean-toolchain',
             host.lean / 'bin/lean', host.lean / 'bin/lake']:
    identities[str(path)] = sha(path)
if mode == 'render':
    candidate = json.loads((PACKET / 'render-parity-tokens.json').read_text())
    for name in ['source_path', 'pin_path']:
        path = Path(candidate[name]); identities[str(path)] = sha(path)
    for path in [PACKET / 'render-parity-tokens.json', PACKET / 'RenderParity.lean']:
        identities[str(path)] = sha(path)
inputs = {'scope': ('Three whole-body grouping equivalences over arbitrary Calls and Locals; seven inserted Expr.group wrappers' if mode == 'equivalence' else 'Three rendered-body parity diagnostics against literal helper tokens extracted from exact proposed pin; no embedded-source correspondence claim'),
          'selected_model_effort': 'GPT-6.1 Sol / Extra High per parent task; runtime settings independently unconfirmed',
          'tokens_and_cost': 'unavailable', 'input_sha256': identities, 'threads': 1,
          'memory_mib_per_process': 4096, 'focused_run_id': evidence['run_id']}
command = [str(host.lean / 'bin/lean'), '-j1', '-M4096', '-DwarningAsError=true', str(PACKET / ('GroupingEquivalence.lean' if mode == 'equivalence' else 'RenderParity.lean'))]
log, report = PACKET / (mode+'-check.log'), PACKET / (mode+'-check-evidence.json')
with ManagedRun(host, 'lean-diagnostic', command, inputs, [PACKET], workers=1,
                task='#296-parenthesis-model-'+mode,
                reason=('Check direct arbitrary-Calls/Locals semantic equivalence of all three changed bodies against exact captured baseline' if mode == 'equivalence' else 'Cheap scratch rendered-body parity for the three changed helpers against exact proposed source/pin; no dense candidate or embedded-source check'),
                evidence=[log, report]) as run:
    run.prepare(inputs)
    environment = {**lean_environment(host), 'LEAN_PATH': str(host.proof / '.lake/build/lib/lean')}
    started = time.monotonic()
    run.event('phase', phase='equivalence-check', command=command)
    completed = subprocess.run(command, cwd=PACKET, env=environment, text=True,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, pass_fds=run.pass_fds)
    elapsed = time.monotonic() - started
    log.write_text(completed.stdout)
    changed = [name for name, previous in identities.items() if sha(Path(name)) != previous]
    audit_passed = 'Silver axiom audit passed:' in completed.stdout
    code = completed.returncode or (125 if changed else 126 if not audit_passed else 0)
    result = dict(inputs, run_id=run.run_id, duration_seconds=elapsed,
                  max_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
                  returncode=code, changed_inputs=changed, fresh_axiom_audit_passed=audit_passed,
                  output=completed.stdout)
    report.write_text(json.dumps(result, indent=2)+'\n')
    print(completed.stdout, end='', flush=True)
    print(json.dumps({'run_id': run.run_id, 'returncode': code, 'duration_seconds': elapsed,
                      'max_rss_kib': result['max_rss_kib'], 'changed_inputs': changed}), flush=True)
    run.finish('success' if code == 0 else 'failure', returncode=code)
    sys.exit(code)
