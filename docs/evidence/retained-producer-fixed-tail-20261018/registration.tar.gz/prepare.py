from pathlib import Path
import json,hashlib,shutil,struct
OLD=Path('/tmp/silver-producer-fixed-tail-20261018');ROOT=Path(__file__).parent
plan=json.loads((OLD/'plan.json').read_text().replace(str(OLD),str(ROOT)))
plan['inputs']=[c for c in plan['inputs'] if c['name']=='input_is_valid']
case=plan['inputs'][0];cwd=Path(case['cwd']);cwd.mkdir();(cwd/'temp').mkdir()
for name in [case['argv'][-1],'why3.conf']:shutil.copy2(OLD/'input_is_valid'/name,cwd/name)
shutil.copytree(OLD/'overlay',ROOT/'overlay')
for name in ['run.py','probe.py','driver-resolution.json']:
 (ROOT/name).write_text((OLD/name).read_text().replace(str(OLD),str(ROOT)))
with (ROOT/'probe.py').open('a') as f:f.write('\n'+(ROOT/'registration-probe.py').read_text())
s=(ROOT/'run.py').read_text().replace('All five registration segments completed','Input_Is_Valid registration diagnostic completed')
(ROOT/'run.py').write_text(s)
binary=Path(case['argv'][0]).read_bytes();shoff=struct.unpack_from('<Q',binary,40)[0];es,n=struct.unpack_from('<HH',binary,58)
sections=[struct.unpack_from('<IIQQQQIIQQ',binary,shoff+i*es) for i in range(n)];symbols={}
for section in sections:
 if section[1]!=2:continue
 st=sections[section[6]];names=binary[st[4]:st[4]+st[5]]
 for off in range(section[4],section[4]+section[5],section[9]):
  idx,info,other,sh,addr,size=struct.unpack_from('<IBBHQQ',binary,off)
  name=names[idx:names.find(b'\0',idx)].decode()
  if sh and sh<len(sections) and addr:
   sect=sections[sh];raw=sect[4]+addr-sect[3];symbols[name]=(addr,raw)
specs={'entry':('camlGnat_main__register_goal_1250',0),'label':('camlGnat_expl__read_label_1110',0),'trivial':('camlGnat_main__register_goal_1250',56),'selected':('camlGnat_main__register_goal_1250',91),'add':('camlGnat_checks__add_to_check_1662',0),'discard':('camlGnat_checks__set_not_interesting_1786',0)}
plan['registration_observers']={k:{'symbol':s,'offset':o,'address':symbols[s][0]+o,'first32':binary[symbols[s][1]+o:symbols[s][1]+o+32].hex()} for k,(s,o) in specs.items()}
assert symbols['camlGnat_checks'][0]==0xafc120
plan['scope']='one Input_Is_Valid registration diagnostic; classify four raw tasks against reported G <= 1'
plan['file_identities']={p:m for p,m in plan['file_identities'].items() if Path(p).is_file()}
for p in ROOT.rglob('*'):
 if p.is_file() and p.name!='plan.json':
  b=p.read_bytes();plan['file_identities'][str(p)]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(ROOT/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
