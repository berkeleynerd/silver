# Additional read-only registration observers. Register/stack roles are pinned
# by registration-disassembly.txt; all addresses are relocated through symbols.
SUMMARY['registration']=[]
SUMMARY['registration_observers']={}
ACTIVE=None
def reg(name):return int(gdb.selected_frame().read_register(name))
def read_check(ptr):
 v=block_fields(ptr,5)
 return {'id':decode_tagged(v[0]),'kind_ordinal':decode_tagged(v[1]),
         'shape':ocaml_string(v[3]),'already_proved':bool(decode_tagged(v[4]))}
class Registration(gdb.Breakpoint):
 def __init__(self,label,spec):
  self.label=label;addr=address(spec['symbol'])+spec['offset']
  assert data(addr,32).hex()==spec['first32']
  SUMMARY['registration_observers'][label]={'address':addr,'first32':data(addr,32).hex()}
  super().__init__('*'+hex(addr));self.silent=True
 def stop(self):
  global ACTIVE
  try:
   if self.label=='entry':
    assert ACTIVE is None
    ACTIVE={'goal_id':decode_tagged(reg('rbx')),'labels_read':[]}
    SUMMARY['registration'].append(ACTIVE)
   elif self.label=='label':
    if ACTIVE is not None:ACTIVE['labels_read'].append(ocaml_string(reg('rax')))
   elif self.label=='trivial':
    assert ACTIVE is not None
    assert decode_tagged(u64(reg('rsp')+24))==ACTIVE['goal_id']
    ACTIVE['is_trivial']=bool(decode_tagged(reg('rax')))
   elif self.label=='selected':
    assert ACTIVE is not None
    assert decode_tagged(u64(reg('rsp')+24))==ACTIVE['goal_id']
    result=reg('rax')
    ACTIVE['selected_check']=None if result==1 else read_check(block_fields(block_fields(result,1)[0],2)[0])
   elif self.label=='add':
    assert ACTIVE is not None and decode_tagged(reg('rdi'))==ACTIVE['goal_id']
    ACTIVE['decision']='add_to_check';ACTIVE['toplevel']=bool(decode_tagged(reg('rax')))
    assert read_check(block_fields(reg('rbx'),2)[0])==ACTIVE['selected_check']
    ACTIVE=None
   elif self.label=='discard':
    assert ACTIVE is not None and decode_tagged(reg('rax'))==ACTIVE['goal_id']
    ACTIVE['decision']='set_not_interesting';ACTIVE=None
   save();return False
  except Exception as e:
   SUMMARY['failures'].append('registration '+self.label+': '+repr(e));save();return True
for label,spec in PLAN['registration_observers'].items():Registration(label,spec)
def goalset(ptr):
 root=block_fields(ptr,1)[0];seen=set()
 def walk(p):
  if p==1:return []
  assert p not in seen;seen.add(p)
  l,v,r,h=block_fields(p,4)
  assert decode_tagged(h)>0
  return walk(l)+[decode_tagged(v)]+walk(r)
 out=walk(root);assert out==sorted(set(out));return out
def hashtable(ptr):
 size,array,seed,initial=block_fields(ptr,4)
 assert array&1==0 and u64(array-8)&255==0
 n=u64(array-8)>>10;result=[];seen=set()
 for i in range(n):
  node=u64(array+8*i)
  while node!=1:
   assert node not in seen;seen.add(node)
   k,v,node=block_fields(node,3);result.append((k,v))
 assert len(result)==decode_tagged(size)
 return result
registration_previous_finish=finish_capture
def finish_capture():
 registration_previous_finish()
 if SUMMARY['completed']:
  try:
   assert ACTIVE is None
   base=address('camlGnat_checks')
   checks=[]
   for k,v in hashtable(u64(base+0xa0)):
    f=block_fields(v,5)
    checks.append({'check':read_check(k),'to_be_scheduled':goalset(f[0]),'to_be_proved':goalset(f[1]),'toplevel':goalset(f[2])})
   goals=[{'goal_id':decode_tagged(k),'check':read_check(block_fields(v,2)[0])} for k,v in hashtable(u64(base+0xa8))]
   SUMMARY['registration_endpoint']={'checks':checks,'goalmap':goals,
    'total_nb_goals':decode_tagged(block_fields(u64(base+0xb0),1)[0]),
    'nb_checks':decode_tagged(block_fields(u64(base+0xb8),1)[0]),
    'not_interesting':goalset(u64(base+0xc0))}
  except Exception as e:
   SUMMARY['failures'].append('registration endpoint: '+repr(e))
 save()
