from pathlib import Path
import json,hashlib,shutil,struct,re
ROOT=Path(__file__).parent;OLD=Path('/tmp/silver-producer-prefix-gc7-20261018')
def identity(p):
 b=Path(p).read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
plan=json.loads((OLD/'plan.json').read_text().replace(str(OLD),str(ROOT)))
exe=Path(plan['inputs'][0]['argv'][0]);binary=exe.read_bytes()
shoff=struct.unpack_from('<Q',binary,40)[0];es,n=struct.unpack_from('<HH',binary,58)
sections=[struct.unpack_from('<IIQQQQIIQQ',binary,shoff+i*es) for i in range(n)]
symbols={}
for section in sections:
 if section[1]!=2:continue
 st=sections[section[6]];names=binary[st[4]:st[4]+st[5]]
 for off in range(section[4],section[4]+section[5],section[9]):
  idx,info,other,sh,addr,size=struct.unpack_from('<IBBHQQ',binary,off)
  name=names[idx:names.find(b'\0',idx)].decode()
  if sh and sh<len(sections) and addr and size:
   sect=sections[sh];raw=sect[4]+addr-sect[3]
   symbols[name]={'symbol':name,'address':addr,'size':size,'first32':binary[raw:raw+32].hex()}
plan['previous_endpoint']=plan['endpoint']
plan['endpoint']=symbols['camlGnat_checks__iter_2373']
plan['dispatch_observers']={
 'transform':symbols['camlWhy3__Trans__apply_transform_args_3380'],
 'graft':symbols['camlWhy3__Session_itp__graft_transf_2167'],
 'connection':symbols['camlWhy3__Prove_client__connect_external_1140']}
forbidden_patterns=[r'camlWhy3__Driver__(?:prepare_task|prove_task|print_task_prepared)_\d+$',r'camlWhy3__Call_provers__call_on_buffer(?:_inner)?_\d+$',r'camlWhy3__Prove_client__send_request(?:_string)?_\d+$',r'camlGnat_checks__(?:run_goal|schedule_goal|schedule_goal_with_prover)_\d+$']
plan['forbidden_calls']={name:info for name,info in symbols.items() if any(re.fullmatch(p,name) for p in forbidden_patterns)}
assert len(plan['forbidden_calls'])>=10
shutil.copytree(OLD/'overlay',ROOT/'overlay')
for case in plan['inputs']:
 cwd=Path(case['cwd']);cwd.mkdir();(cwd/'temp').mkdir()
 for name in [case['argv'][-1],'why3.conf']:shutil.copy2(OLD/case['name']/name,cwd/name)
 case['argv'][-1:-1]=['--socket',str(cwd/'server.sock')]
 case['server']={'argv':[str(exe.with_name('why3server')),'--socket','server.sock','--single-client','-j','1'],'cwd':str(cwd),'environment':{'PATH':'/usr/bin:/bin','LC_ALL':'C'},'socket':str(cwd/'server.sock')}
plan['server_identity']=identity(exe.with_name('why3server'))
plan['scope']='fresh fixed Per_Check split and registration, before first scheduling iterator'
plan['file_identities'][str(exe.with_name('why3server'))]=plan['server_identity']
for p in [ROOT/'prepare.py',ROOT/'dispatch-disassembly.txt']:plan['file_identities'][str(p)]=identity(p)
resolution=(OLD/'driver-resolution.json').read_text().replace(str(OLD),str(ROOT))
(ROOT/'driver-resolution.json').write_text(resolution)
probe=(OLD/'probe.py').read_text().replace(str(OLD),str(ROOT)).replace("'end_of_typing' if self.final", "'end_of_registration' if self.final")
(ROOT/'probe.py').write_text(probe)
(ROOT/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print('prepared',ROOT,'with',len(plan['forbidden_calls']),'forbidden call guards')
