set pagination off
set breakpoint always-inserted on
set confirm off
set auto-load off
set debuginfod enabled off
set startup-with-shell off
set disable-randomization off
unset environment LD_LIBRARY_PATH
set language c
starti
set $capture_dest = "/tmp/silver-fixed-library-frontend-20261018/silver_runtime"
python
exec(open('/tmp/silver-fixed-library-frontend-20261018/counter.py').read())
end
continue
python
final()
end
quit
