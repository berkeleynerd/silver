"""Read-only GDB observations; every GC/request stops before it executes."""
import gdb, json, struct, hashlib
from pathlib import Path
ROOT=Path('/tmp/silver-producer-prefix-gc2-20261018')
PLAN=json.loads((ROOT/'plan.json').read_text())
CASE=PLAN['inputs'][CASE_INDEX]
OUT=Path(CASE['cwd'])/'capture'
INF=gdb.selected_inferior()
SUMMARY={'name':CASE['name'],'completed':False,'failures':[],'snapshots':[],
         'guard_hits':[],'startup_guard_hits':[],'protected':False,'new_threads':[],'guards':{},'counter_addresses':{}}
def data(addr,n=8):return bytes(INF.read_memory(addr,n))
def u64(addr):return int.from_bytes(data(addr),'little')
def address(name):return int(gdb.parse_and_eval('(unsigned long)&'+name))
def identity(p):
 b=Path(p).read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(): (OUT/'summary.json').write_text(json.dumps(SUMMARY,indent=2)+'\n')
def snapshot(label,native=False):
 state=u64(address('Caml_state'))
 fields={n:(struct.unpack('<d',data(state+v['offset']))[0] if v['type']=='double' else u64(state+v['offset'])) for n,v in PLAN['state_fields'].items()}
 ptr=int(gdb.parse_and_eval('$r15')) if native else fields['young_ptr']
 row={'label':label,'pc':hex(int(gdb.parse_and_eval('$pc'))),'state_address':state,
      'state':fields,'effective_young_ptr':ptr,'minor_allocated_words':(fields['young_alloc_end']-ptr)//8,
      'native_r14':int(gdb.parse_and_eval('$r14')) if native else None,'tables':{}}
 for n in ['caml_allocated_words','caml_gc_phase','caml_extra_heap_resources','caml_dependent_size','caml_dependent_allocated','caml_init_minor_heap_wsz','caml_init_heap_wsz','caml_custom_major_ratio','caml_custom_minor_ratio','caml_custom_minor_max_bsz']:
  addr=address(n);SUMMARY['counter_addresses'][n]=addr
  row[n]=struct.unpack('<d',data(addr))[0] if n=='caml_extra_heap_resources' else (int.from_bytes(data(addr,4),'little') if n=='caml_gc_phase' else u64(addr))
 for n,entry_size in [('ref_table',8),('ephe_ref_table',16),('custom_table',24)]:
  addr=fields[n];vals={k:u64(addr+i*8) for i,k in enumerate(['base','end','threshold','ptr','limit','size','reserve'])}
  vals['entry_size']=entry_size;vals['used_entries']=(vals['ptr']-vals['base'])//entry_size;row['tables'][n]=vals
 SUMMARY['snapshots'].append(row);save();print('SNAPSHOT '+json.dumps({k:row[k] for k in ['label','minor_allocated_words','caml_allocated_words','caml_extra_heap_resources']}),flush=True)
 return row
class Guard(gdb.Breakpoint):
 def __init__(self,name):
  self.label=name;addr=address(name);super().__init__('*'+hex(addr));self.silent=True
  SUMMARY['guards'][name]={'address':addr,'first32':data(addr,32).hex()}
 def stop(self):
  event={'guard':self.label,'pc':int(gdb.parse_and_eval('$pc')),'backtrace':gdb.execute('bt 12',to_string=True)}
  if not SUMMARY['protected']:
   SUMMARY['startup_guard_hits'].append(event);save();return False
  SUMMARY['guard_hits'].append(event)
  SUMMARY['failures'].append('collection/request/override guard: '+self.label)
  try:snapshot('guard:'+self.label)
  except Exception as e:SUMMARY['failures'].append(str(e))
  save();return True
class Phase(gdb.Breakpoint):
 def __init__(self,name,final=False,start=False):
  self.start=start;self.final=final;self.label=name;super().__init__('*'+hex(address(name)));self.silent=True
 def stop(self):
  try:
   row=snapshot('end_of_typing' if self.final else ('before_first_why3_module' if self.start else 'runtime_initialized'),self.final or self.start)
   if self.start:SUMMARY['protected']=True;SUMMARY['baseline']=row;save()
   if self.final:
    s=row['state'];assert row['native_r14']==row['state_address']
    assert s['minor_heap_wsz']==2**28
    assert row['minor_allocated_words'] < s['minor_heap_wsz']
    assert row['caml_allocated_words'] < s['minor_heap_wsz']
    base=SUMMARY['baseline']
    assert all(s[n]==0 for n in ['in_minor_collection','requested_major_slice','requested_minor_gc'])
    assert all(s[n]==base['state'][n] for n in ['stat_minor_words','stat_promoted_words','stat_major_words','stat_minor_collections','stat_major_collections','stat_compactions','stat_forced_major_collections'])
    assert row['caml_gc_phase']==base['caml_gc_phase']
    assert s['young_trigger']==base['state']['young_trigger']
    assert s['extra_heap_resources_minor']<=1 and row['caml_extra_heap_resources']<=1
    for t in row['tables'].values():assert t['ptr']<=t['threshold']
    proc=Path('/proc')/str(INF.pid)
    (OUT/'maps.txt').write_bytes((proc/'maps').read_bytes())
    mapped={}
    for line in (proc/'maps').read_text().splitlines():
     parts=line.split()
     if len(parts)>=6 and parts[-1].startswith('/') and Path(parts[-1]).is_file():mapped[parts[-1]]=identity(parts[-1])
    SUMMARY['mapped_files']=mapped
    SUMMARY['completed']=True;save()
  except Exception as e:SUMMARY['failures'].append(type(e).__name__+': '+str(e));save();return True
  return self.final
proc=Path('/proc')/str(INF.pid)
env=dict(s.decode().split('=',1) for s in (proc/'environ').read_bytes().split(b'\0') if s)
assert env==CASE['environment'],env
args=[s.decode() for s in (proc/'cmdline').read_bytes().split(b'\0') if s]
assert args==CASE['argv'],args
(OUT/'process.json').write_text(json.dumps({'pid':INF.pid,'executable':str((proc/'exe').resolve()),'environment':env,'argv':args,'initial_threads':len(INF.threads())},indent=2)+'\n')
for name in PLAN['guards']:Guard(name)
Phase('caml_start_program');Phase(PLAN['protected_start'],start=True);Phase(PLAN['endpoint']['symbol'],True)
for kind in ['fork','vfork','exec']:gdb.execute('catch '+kind)
def new_thread(event):SUMMARY['new_threads'].append(event.inferior_thread.num);save()
gdb.events.new_thread.connect(new_thread)
save()
def finish_capture():
 if not SUMMARY['completed'] and not SUMMARY['failures']:SUMMARY['failures'].append('stopped before endpoint without a handled guard')
 if SUMMARY['new_threads']:SUMMARY['failures'].append('unexpected new thread')
 save()
