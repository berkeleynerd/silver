from pathlib import Path
from copy import deepcopy
from datetime import datetime, timezone
import hashlib, json, platform, runpy, struct, time
R=Path.cwd(); H=R/'docs/evidence/retained-literal-driver-completion-20261019'
t0=time.perf_counter(); started=datetime.now(timezone.utc).isoformat(); n=0

def ck(v,label):
 global n
 assert v,label
 n+=1

def bad(fn,label):
 try: fn()
 except ValueError: ck(True,label)
 else: raise AssertionError(label)

a=runpy.run_path(str(H/'compose.py')); c=a['Context']()
s=b'with Silver_IO; procedure Main is pragma SPARK_Mode(On); begin Silver_IO.Put("A"); null; Silver_IO.Put_Line(""); Silver_IO.Put("bc"); null; Silver_IO.Put_Line("D"); null; Silver_IO.Put(""); end Main;'
(R/'tmp/driver-review/main.adb').write_bytes(s)
g=c.api['build'](s,c.join); v=a['evaluate'](s,c,invocation=g)
ck(v['source_counts']['output_calls']==5 and v['source_counts']['null_statements']==3,'new physical source')
ck(v['source_counts']['decoded_literal_lengths']==[1,0,2,1,0],'new literal lengths')
expected={
 'Main_compile':([1,*range(4,13),14,16], [13], [15], ['-mtune=generic','-march=x86-64']),
 'binder_compile':([1,*range(4,14),15], [14], [16], []),
 'link':([1,2,7,8,9,10,15], [3,4,5,6,11,12], [16], ['-mtune=generic','-march=x86-64'])}
for p,r in zip([p for p in g['processes'] if p['role']!='binder_generate'],v['drivers']):
 av=p['argv']; si,ii,oi,defs=expected[p['role']]
 switches=[av[i] for i in si]+defs; infiles=[av[i] for i in ii]
 if p['role']=='link': infiles+=av[13][4:].split(',')+av[14][4:].split(',')
 ck(r['retained_switches']==switches,'explicit current switch projection')
 ck(r['input_records']==infiles,'explicit current infile projection')
 ck(len(switches)+1<=16 and len(infiles)+1<=16,'sentinel records')
 ck(r['decoded_option_request']==len(av)*96,'decoded request')
 fields=[]
 for x in switches:
  fields.append(x)
  if x=='-o':fields.append(av[oi[0]])
 collected=' '.join("'"+f+"'" for f in fields)
 ck(len(collected)+1<r['strings']['COLLECT_GCC_OPTIONS'],'separate operand field bound')
 ck(r['separated_operand_pointer_request']==2*8,'separate operand pointer array')
 if r['frontend']:
  f=r['frontend']; fa=f['argv']; e=f['environment']
  ck(e['COLLECT_GCC_OPTIONS']==collected,'exact collected fields and order')
  ck(set(e)==set(p['environment'])|{'GCC_EXEC_PREFIX','COLLECT_GCC','COLLECT_GCC_OPTIONS'},'compile env selection')
  ck(fa[4]==Path(av[oi[0]]).stem+'.adb' and fa[-3]==infiles[0],'output dumpbase versus actual input')
  ck(len(fa)==(23 if p['role']=='Main_compile' else 20),'independent frontend count')
  ck(f['argv_total_bytes_including_NUL']==sum(len(x.encode())+1 for x in fa),'argv storage')
  ck(f['environment_total_bytes_including_NUL']==sum(len(k.encode())+len(x.encode())+2 for k,x in e.items()),'environment storage')
  ck(f['frontend_theme']==('ASCII' if e.get('LANG')=='C' else 'emoji'),'LANG theme selection')
 ck(r['diagnostic']['option_classifier_requested_bytes']==0,'driver fresh options')
ck(v['collect2']['diagnostic']['option_classifier_requested_bytes']==0,'collect2 fresh options')
for slots,req in [('first_ld_write_slots_upper','first_ld_pointer_request'),('second_ld_write_slots_upper','second_ld_pointer_request'),('input_object_write_slots_upper','input_object_pointer_request'),('unused_C_write_slots_upper','unused_C_pointer_request')]:
 ck(v['collect2'][slots]*8<=v['collect2'][req],'collect2 independent per-array fit')
# Source growth formula, tested around each transition through the actual demand.
capacities=[10,20,30,45,67,100,150,225,337]
for demand in sorted(set([0,1]+[x+d for x in capacities[:-1] for d in [-1,0,1]])):
 cap=next(x for x in capacities if x>=demand)
 ck(a['vector'](demand)=={'demand':demand,'capacity':cap,'request_bytes':8*(cap+1)},'source growth table')
for size in [0,7,8,15,16,3509,3510,3511,3512,3513,3514,3515,3516,3517,3518,3519,3520,3530,33282,2**31-1]:
 ck(a['chunk'](size)==max(4064,(9*size)//8+115),'independent obstack rounding')
# Source identity changes must not change this read projection.
s2=s.replace(b'Put("A")',b'Put("xyz")')
v2=a['evaluate'](s2,c)
ck(v2['drivers']==v['drivers'] and v2['collect2']==v['collect2'],'contents independent driver')
ck(v2['invocation_identity']!=v['invocation_identity'],'contents still bound')
mut=[]
q=deepcopy(g);q['processes'][0]['argv'][15]='other.o';mut.append(q)
q=deepcopy(g);q['processes'][2]['argv'][14]='other.adb';mut.append(q)
q=deepcopy(g);q['processes'][2]['environment']['LANG']='C';mut.append(q)
q=deepcopy(g);q['processes'][3]['ld_argv'][-1]+='x';mut.append(q)
q=deepcopy(g);q['source_counts']['null_statements']+=1;mut.append(q)
q=deepcopy(g);q['graph']['Main']+='x';mut.append(q)
q=deepcopy(g);q['processes'][0]['assembler_argv'][-1]+='x';mut.append(q)
q=deepcopy(g);q['processes'][0]['child_frontend']['argv_positions_upper']=23;mut.append(q)
q=deepcopy(g);q['unrecognized_review_field']=0;mut.append(q)
for q in mut:bad(lambda q=q:a['evaluate'](s,c,invocation=q),'foreign graph projection')
bad(lambda:a['evaluate'](s2,c,invocation=g),'foreign raw source')
# Independently decode the small x86 instruction subset actually in the roots.
# This decoder does not consult the retained mnemonic or operand text.
def decode(buf,at):
 start=at; rex=0
 if buf[at]==0x66: at+=1
 if 0x40<=buf[at]<=0x4f: rex=buf[at];at+=1
 op=buf[at];at+=1;kind='ordinary';dest=None
 if 0x50<=op<=0x5f or op==0xc3:
  kind='ret' if op==0xc3 else 'ordinary'
 elif op in (0xe8,0xe9):
  kind='call' if op==0xe8 else 'jump';dest=struct.unpack_from('<i',buf,at)[0];at+=4
 elif 0xb8<=op<=0xbf:
  at+=8 if rex&8 else 4
 elif op in (0x89,0x8b,0x8d,0x31,0x83,0xc1,0xc6,0xc7,0x0f):
  if op==0x0f:
   op2=buf[at];at+=1
   assert op2 in (0x11,0xef)
  modrm=buf[at];at+=1;mod=modrm>>6;rm=modrm&7
  if mod!=3 and rm==4:
   sib=buf[at];at+=1
   if mod==0 and sib&7==5:at+=4
  if mod==0 and rm==5:at+=4
  elif mod==1:at+=1
  elif mod==2:at+=4
  if op in (0x83,0xc1,0xc6):at+=1
  if op==0xc7:at+=4
 else:raise AssertionError(f'unknown root opcode {op:x}')
 return at,kind,dest
records=json.loads((H/'lifecycle.json').read_bytes());decoded=0; root_summary=[]
for rec in records:
 regs=[];calls=[]
 for root in rec['roots']:
  code=b''.join(bytes.fromhex(i['hex']) for i in root['instructions']);pos=0;rdi=None;last=None
  for ins in root['instructions']:
   end,kind,dest=decode(code,pos);raw=code[pos:end];addr=root['address']+pos
   ck(addr==ins['address'] and raw.hex()==ins['hex'],'independent instruction boundaries')
   if raw[0]==0xbf and len(raw)==5:rdi=int.from_bytes(raw[1:],'little')
   if raw[:3]==b'\x48\x8d\x3d':rdi=addr+7+struct.unpack_from('<i',raw,3)[0]
   if kind in ('call','jump'):
    target=addr+len(raw)+dest
    if target==rec['cxa_atexit_plt']:
     ck(rdi is not None,'independent callback assignment')
     regs.append({'site':addr,'root':root['address'],'destructor':rdi})
    else:calls.append({'site':addr,'root':root['address'],'target':target})
    rdi=None
   pos=end;last=kind;decoded+=1
  ck(pos==len(code) and last in ('ret','jump'),'full straight-line root termination')
 ck(regs==rec['registrations'] and calls==rec['calls'],'independent control-flow census')
 root_summary.append([rec['role'],len(rec['roots']),len(regs),len(calls),len({r['destructor'] for r in regs})])
 # Keep the fresh mutation distinct from the author suite: remove a whole call,
 # and alter runtime-root partition without touching the installed executable.
 binary=Path(rec['path']).read_bytes()
 q=deepcopy(rec);q['calls'].pop();bad(lambda q=q:a['verify_lifecycle'](q,binary),'omitted nonregistration root call')
 q=deepcopy(rec);q['CRT_init']=q['roots'][0]['address'];bad(lambda q=q:a['verify_lifecycle'](q,binary),'changed runtime/GCC partition')
ck(root_summary==[['gcc',8,30,10,9],['collect2',4,3,10,3]],'distinct executable census')
result={'status':'passed','checks':n,'started_UTC':started,'finished_UTC':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.perf_counter()-t0,'source_bytes':len(s),'source_sha256':hashlib.sha256(s).hexdigest(),'source_counts':{'C':5,'N':3,'decoded_literal_bytes':4},'decoded_initializer_instructions':decoded,'root_summary':root_summary,'negative_graph_probes':len(mut)+1,'negative_lifecycle_probes':4,'host':platform.platform(),'native_compiler_target_capture_prover_runs':0,'broad_predecessor_replay':False}
(R/'tmp/driver-review/probe-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
