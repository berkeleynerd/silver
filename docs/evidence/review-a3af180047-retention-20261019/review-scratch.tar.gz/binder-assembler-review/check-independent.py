from pathlib import Path
import copy, hashlib, json, re, runpy, struct, tarfile, time

ROOT = Path(__file__).resolve().parents[2]
PACKET = ROOT/'docs/evidence/retained-literal-binder-assembler-20261019'
SCRATCH = Path(__file__).resolve().parent
start = time.perf_counter()
count = 0
def check(value):
    global count
    assert value
    count += 1
def archive(path):
    with tarfile.open(path) as ar:
        return {m.name:ar.extractfile(m).read() for m in ar.getmembers() if m.isfile()}
api = runpy.run_path(str(PACKET/'derive.py'))
context = api['Context']('/tmp/silver-backend-compose-20261018/full-source', '/tmp/silver-backend-compose-20261018/gas-source')
original_write = Path.write_text
def redirected_write(path, content, *args, **kwargs):
    check(path == PACKET/'checks.json')
    return original_write(SCRATCH/'author-checks.json', content, *args, **kwargs)
Path.write_text = redirected_write
try:
    runpy.run_path(str(PACKET/'check.py'), run_name='__main__')
finally:
    Path.write_text = original_write
art = context.artifacts
prior = archive(ROOT/'docs/evidence/retained-binder-options-20261018/artifacts.tar.gz')
for suffix in ['adb','ads']:
    check(art['b__main~1.'+suffix] == prior['output/output/b__main~1.'+suffix])

source_needle = b'u00001 : constant Version_32 := 16#d02a2ed5#;'
check(art['b__main~1.ads'].count(source_needle)==1)
base_assembly = base_object = None
elf_rows = []
for row in context.run['cases']:
    prefix='cases/'+row['tag']+'/'
    check(art[prefix+'b__main~1.adb']==art['b__main~1.adb'])
    check(art[prefix+'b__main~1.ads']==art['b__main~1.ads'].replace(source_needle,
        ('u00001 : constant Version_32 := 16#%08x#;' % row['checksum']).encode()))
    asm=art[prefix+'b__main~1.s']
    lines=asm.splitlines(keepends=True)
    position=lines.index(b'mainB:\n')
    check(lines.count(b'mainB:\n')==1)
    check(lines[position+1].decode()==api['numeric'](row['checksum'])['directive'])
    del lines[position+1]
    normalized=b''.join(lines)
    if base_assembly is None: base_assembly=normalized
    check(normalized==base_assembly)
    check(max(map(len,asm.splitlines()))==87 and asm.count(b'\n')==1262)
    obj=art[prefix+'b__main~1.o']
    check(len(obj)==17952)
    shoff=struct.unpack_from('<Q',obj,40)[0]
    shentsize,shnum,shstrndx=struct.unpack_from('<HHH',obj,58)
    check(shentsize==64 and shnum==16)
    sections=[struct.unpack_from('<IIQQQQIIQQ',obj,shoff+i*shentsize) for i in range(shnum)]
    shstr=sections[shstrndx]
    section_names=obj[shstr[4]:shstr[4]+shstr[5]]
    def name(data,offset):return data[offset:data.index(b'\0',offset)].decode()
    symtabs=[s for s in sections if s[1]==2]
    check(len(symtabs)==1)
    symtab=symtabs[0]
    strtab=sections[symtab[6]]
    symnames=obj[strtab[4]:strtab[4]+strtab[5]]
    symbols=[struct.unpack_from('<IBBHQQ',obj,p) for p in range(symtab[4],symtab[4]+symtab[5],24)]
    symbols=[s for s in symbols if name(symnames,s[0])=='mainB']
    check(len(symbols)==1)
    _,info,other,index,value,size=symbols[0]
    section=sections[index]
    check((info,other,size)==(0x11,0,4))
    check(name(section_names,section[0])=='.rodata' and section[1]==1 and section[2]==2)
    offset=section[4]+value
    check(obj[offset:offset+4]==row['checksum'].to_bytes(4,'little'))
    masked=obj[:offset]+b'\0'*4+obj[offset+4:]
    if base_object is None:base_object=masked
    check(masked==base_object)
    elf_rows.append(dict(case=row['tag'],offset=offset,section='.rodata',section_flags=section[2]))

def rejected(artifacts,run):
    try:api['replay'](artifacts,run)
    except ValueError:check(True)
    else:raise AssertionError('mutation accepted')
for field in ['compiler','assembler']:
    run=copy.deepcopy(context.run)
    run['cases'][0]['commands'][0 if field=='compiler' else 1]['argv'].append('-g')
    rejected(art,run)
for kind in ['fixed_assembly','fixed_object','checksum_object']:
    run=copy.deepcopy(context.run); mutated=dict(art)
    filename='b__main~1.s' if kind=='fixed_assembly' else 'b__main~1.o'
    path='cases/maximum/'+filename
    raw=bytearray(mutated[path])
    location=raw.index(b'.text')+1 if kind=='fixed_assembly' else (elf_rows[-1]['offset'] if kind=='checksum_object' else 64)
    raw[location] ^= 1
    mutated[path]=bytes(raw)
    # Repair the row hash to require the semantic comparison to catch it.
    run['cases'][-1][filename]=api['identity'](bytes(raw))
    rejected(mutated,run)
values={0,1,2**31-1,2**31,2**31+1,2**32-2,2**32-1}
for k in range(10):
    for sign in [-1,1]:
        for delta in [-1,0,1]:
            signed=sign*10**k+delta
            if -2**31<=signed<2**31:values.add(signed % 2**32)
mask=((1<<64)-1)^((1<<32)-1)
for value in sorted(values):
    result=api['numeric'](value)
    signed=struct.unpack('<i',struct.pack('<I',value))[0]
    check(result['signed_value']==signed)
    check(len(result['directive'])<=19)
    check(not (((signed % 2**64)&mask) and (((-signed) % 2**64)&mask)))
    magnitude=abs(signed)
    check(len(str(magnitude))<=10 and magnitude<=2**31)
    for end in range(1,len(str(magnitude))+1):
        check(int(str(magnitude)[:end])<=2**31)

for row in context.manifest['selected_tools'].values():
    raw=Path(row['path']).read_bytes()
    check(len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'])
startup=json.loads((ROOT/'docs/evidence/retained-assembler-capacity-20261018/source-manifest.json').read_text())
supplement=['gas/as.c','gas/ehopt.c','gas/write.c','gas/config/obj-elf.c','bfd/elf.c','bfd/elfxx-x86.c']
for pathname in supplement:
    row,=[r for r in startup['files'] if r['path']==pathname]
    raw=(Path('/tmp/silver-backend-compose-20261018/gas-source')/pathname).read_bytes()
    check(len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'])
result=dict(checks=count,numeric_cases=len(values),elf=elf_rows,
    author_checks=json.loads((SCRATCH/'author-checks.json').read_text()),
    supplementary_source_pins=supplement,native_tool_executions=0,
    elapsed_seconds=time.perf_counter()-start)
(SCRATCH/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
