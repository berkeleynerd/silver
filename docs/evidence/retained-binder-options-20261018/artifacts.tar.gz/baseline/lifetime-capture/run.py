"""One fixed-binder lifetime capture; no linker, solver or Lean execution."""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import time

root = Path(__file__).parent
capture = root / 'capture'
plan = json.loads((root / 'invocation.json').read_text())
assert not (capture / 'result.json').exists(), 'preserve previous capture'
gdbroot = Path('/tmp/silver-capacity-debugger-20261018/root')
gdb = gdbroot / 'usr/bin/gdb'

def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

before = {p: identity(Path(p)) for p in plan['input_identities']}
assert before == plan['input_identities']
script = '''set pagination off
set confirm off
set auto-load off
set debuginfod enabled off
set startup-with-shell off
set disable-randomization off
set breakpoint always-inserted on
set follow-fork-mode child
set detach-on-fork on
set language c
python
import gdb,json
plan=json.load(open('/tmp/silver-binder-lifetime-20261018/invocation.json'))
gdb.execute('unset environment')
for key,value in plan['environment'].items():
    gdb.execute('set environment '+key+'='+value)
end
catch exec
run
python
exec(open('/tmp/silver-binder-lifetime-20261018/counters.py').read())
end
continue
python
finish_capture()
end
quit
'''
(capture / 'probe.gdb').write_text(script)
debugger_environment = {'PATH': '/usr/bin:/bin', 'LC_ALL': 'C', 'LANG': 'C',
    'LD_LIBRARY_PATH': str(gdbroot / 'usr/lib/x86_64-linux-gnu'), 'DEBUGINFOD_URLS': ''}
command = [str(gdb), '-nx', '-q', '-batch', '-x', str(capture / 'probe.gdb'), '--args', *plan['argv']]
start = time.monotonic()
process = subprocess.Popen(command, cwd=plan['cwd'], env=debugger_environment,
    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, start_new_session=True)
timed_out = False
try:
    output, _ = process.communicate(timeout=60)
except subprocess.TimeoutExpired:
    timed_out = True
    os.killpg(process.pid, signal.SIGTERM)
    output, _ = process.communicate(timeout=10)
(capture / 'probe.log').write_text(output)
unchanged = all(identity(Path(p)) == row for p,row in before.items())
cwd = Path(plan['cwd'])
generated = {p.name:identity(p) for p in cwd.iterdir() if p.is_file()}
result = {'command':command, 'debugger_environment':debugger_environment,
    'elapsed_seconds':time.monotonic()-start, 'returncode':process.returncode,
    'timed_out':timed_out, 'retained_inputs_unchanged':unchanged,
    'scope':'complete fixed-binder gnat1 counters and ordinary driver assembler delivery; no linker/prover',
    'gnat1_sha256':identity(Path(plan['gnat1']))['sha256'],
    'gcc_sha256':identity(Path(plan['argv'][0]))['sha256'],
    'gdb':identity(gdb), 'generated':generated}
result['object_hash_equal_baseline'] = generated.get('b__main~1.o',{}).get('sha256') == '368b82296a24b933d1154f07b54bdad7af2f291302d4db23196f9d89128e2883'
(capture / 'result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result), flush=True)
if timed_out or process.returncode or not (capture / 'counter-summary.json').exists():
    print(output)
    raise SystemExit(1)
data = json.loads((capture / 'counter-summary.json').read_text())
assert data['completed'] and not data['failures'] and not data['new_threads']
assert unchanged and result['object_hash_equal_baseline']
print(json.dumps({'counters':data['counters'], 'collection_calls':data['collection_calls'],
    'mark_calls':data['mark_calls'], 'value_expr_insert_count':len(data['value_expr_insert_calls'])}), flush=True)
