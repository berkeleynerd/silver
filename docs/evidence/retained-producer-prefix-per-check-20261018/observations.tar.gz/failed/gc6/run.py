"""Five serial prefix-only cases; abort at first failed case, preserve evidence."""
from pathlib import Path
import json,hashlib,subprocess,os,signal,time
ROOT=Path(__file__).parent;PLAN=json.loads((ROOT/'plan.json').read_text())
def identity(p):
 b=Path(p).read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert all(identity(p)==m for p,m in PLAN['file_identities'].items())
for case in PLAN['inputs']:
 assert sorted(p.name for p in Path(case['cwd']).iterdir())==sorted([case['argv'][-1],'why3.conf','temp'])
 assert not list((Path(case['cwd'])/'temp').iterdir())
gdbroot=Path(PLAN['gdbroot']);results=[]
for i,case in enumerate(PLAN['inputs']):
 out=Path(case['cwd'])/'capture';out.mkdir(exist_ok=False)
 script='''set pagination off
set confirm off
set auto-load off
set debuginfod enabled off
set startup-with-shell off
set disable-randomization off
set breakpoint always-inserted on
set language c
python
import gdb,json
root='/tmp/silver-producer-prefix-gc6-20261018'
plan=json.load(open(root+'/plan.json'))
CASE_INDEX=INDEX
case=plan['inputs'][CASE_INDEX]
gdb.execute('unset environment')
for k,v in case['environment'].items():gdb.execute('set environment '+k+'='+v)
end
starti
python
exec(open(root+'/probe.py').read())
end
continue
python
finish_capture()
end
kill
quit
'''.replace('CASE_INDEX=INDEX','CASE_INDEX='+str(i))
 (out/'probe.gdb').write_text(script)
 env={'PATH':'/usr/bin:/bin','LC_ALL':'C','LD_LIBRARY_PATH':str(gdbroot/'usr/lib/x86_64-linux-gnu'),'DEBUGINFOD_URLS':''}
 cmd=[str(gdbroot/'usr/bin/gdb'),'-nx','-q','-batch','-x',str(out/'probe.gdb'),'--args',*case['argv']]
 start=time.monotonic();p=subprocess.Popen(cmd,cwd=case['cwd'],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
 timed_out=False
 try:log,_=p.communicate(timeout=600)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(p.pid,signal.SIGTERM);log,_=p.communicate(timeout=10)
 (out/'debugger.log').write_text(log)
 summary=json.loads((out/'summary.json').read_text()) if (out/'summary.json').exists() else {}
 result={'name':case['name'],'command':cmd,'debugger_environment':env,'duration_seconds':time.monotonic()-start,'returncode':p.returncode,'timed_out':timed_out,'completed':summary.get('completed',False),'failures':summary.get('failures',['missing summary']),'guard_hits':summary.get('guard_hits',[])}
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');results.append(result)
 (ROOT/'result.json').write_text(json.dumps({'cases':results},indent=2)+'\n')
 print(json.dumps(result),flush=True)
 if p.returncode or timed_out or not result['completed'] or result['failures']:
  print(log,flush=True);raise SystemExit(1)
assert all(identity(p)==m for p,m in PLAN['file_identities'].items())
print('All five prefixes completed with semantic count guards and without collection; inputs unchanged.',flush=True)
