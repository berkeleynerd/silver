module
public import Silver.ApplicationPackageDeclarationsSignatureModel
@[expose] public section
namespace Silver.ApplicationPackageDeclarations
open Compose ApplicationPackageNames
def originalStep (calls : SignatureCalls) (text : Source) (completing : Bool)
    (state : SignatureState) : SignatureStep :=
  let before := state.header.position
  let first := calls.skip text before
  let last := calls.nameAfter text first
  if !calls.validName text ⟨first,last⟩ then .returned (rejectedSignature state.info) else
  if (completing && decide (state.formalCount ≥ state.item.count)) ||
      (!completing && decide (state.info.parameters.length = PackageBindings.maxFormals)) then
    .returned (rejectedSignature state.info)
  else
  let slot := if completing then state.formalStart + state.formalCount else state.info.parameters.length + 1
  let formalStart := if !completing && decide (state.formalCount = 0) then slot else state.formalStart
  if decide (state.formalCount > 0) && duplicateFormal calls text completing state.info ⟨first,last⟩ formalStart state.formalCount then
    .returned (rejectedSignature state.info)
  else
  let hidden := calls.hideOuter text state.header state.info ⟨first,last⟩
  if hidden.position = 0 then .returned ⟨state.info,hidden⟩ else
  let colon := calls.take text last (.symbol ":")
  let inputEnd := calls.take text colon (.word "in")
  let modeResult : Nat × ProcedureBindings.Mode := if inputEnd ≠ 0 then
    let outputEnd := calls.take text inputEnd (.word "out")
    ⟨if outputEnd ≠ 0 then outputEnd else inputEnd, if outputEnd ≠ 0 then .inputOutput else .input⟩
    else ⟨calls.take text colon (.word "out"), .output⟩
  if modeResult.1 = 0 ∨ (state.item.kind = .function ∧ modeResult.2 ≠ .input) then
    .returned (rejectedSignature state.info)
  else
  let mark := calls.typeAt text hidden state.info modeResult.1
  if mark.after = 0 then .returned (rejectedSignature state.info) else
  let parameter := state.info.parameterAt slot
  if completing && (!calls.sameName text parameter.specName ⟨first,last⟩ ||
      decide (parameter.mode ≠ modeResult.2 ∨ parameter.kind ≠ mark.kind ∨
        parameter.typeIdentity ≠ mark.identity ∨ parameter.bounds ≠ mark.bounds)) then
    .returned (rejectedSignature state.info)
  else
  let parameter : PackageBindings.Formal := if completing then
      {parameter with bodyName := ⟨first,last⟩, bodyTypeName := mark.name}
    else {specName := ⟨first,last⟩, specTypeName := mark.name, kind := mark.kind, bounds := mark.bounds, typeIdentity := mark.identity, mode := modeResult.2}
  let info := if completing then {state.info with parameters := state.info.parameters.set (slot - 1) parameter}
    else {state.info with parameters := state.info.parameters ++ [parameter]}
  let header := calls.append {hidden with position := mark.after} ⟨first,last⟩ mark modeResult.2
  if header.position = 0 then .returned ⟨info,header⟩ else
  let updated := {state with info, header, formalStart, formalCount := state.formalCount + 1}
  finishFormal calls text before updated

theorem extracted_signature_step (calls : SignatureCalls) (text : Source) (completing : Bool) (state : SignatureState) :
    signatureStep calls text completing state = originalStep calls text completing state := rfl
end Silver.ApplicationPackageDeclarations
