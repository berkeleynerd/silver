module

public import Silver.ApplicationPackageDeclarationsObjectFrameDomains
public import Silver.ApplicationPackageObjectRows
public import Silver.ComposeBooleanArrayTrace
public import Silver.IntegerExpressions

@[expose] public section

/-! The inventory is obtained from the original Object reader's successful
execution. In particular its expressions, scopes and arithmetic obligations
are conclusions of that execution, not an additional acceptance certificate. -/
namespace Silver.ApplicationPackageInitializers
open Compose Compose.Expressions Predicate ApplicationPackageDeclarations
open ApplicationPackageObjectRows ApplicationPackageNames

set_option backward.dsimp.instances true

/-- Exact calls made before the new binding is appended. The scalar interval
is the inferred initializer interval; the type interval remains separate. -/
structure ValueCalls (text : Source) (base : ParserState) (first last : Nat)
    (out : ObjectResult) : Prop where
  cursor : ValidCursor text out.initFirst
  scalar : out.mark.kind = .integer →
    let value := ScalarExpression.read text out.initFirst base.scalarNames first last (elaborating := true)
    value.after = out.initAfter ∧ value.after ≠ 0 ∧ value.bounds = out.initialBounds ∧
      value.bounds.isEmpty = false ∧ value.bounds.included out.mark.bounds = true
  boolean : out.mark.kind = .boolean →
    booleanInitializerAfter text base out.initFirst first last = out.initAfter ∧ out.initAfter ≠ 0

private def ValueSuccess (text : Source) (base : ParserState) (first last : Nat)
    (out : ObjectResult) : Prop := out.frame.position ≠ 0 → ValueCalls text base first last out

private theorem rejected_value (text : Source) (base : ParserState) (first last : Nat) :
    ValueSuccess text base first last invalidObject := fun present => (present rfl).elim

private theorem finish_value (reader : BooleanElaboration.Native.Reader) (text : Source)
    (original base : ParserState) (first last : Nat) (out : ObjectResult)
    (calls : ValueCalls text base first last out) :
    ValueSuccess text base first last (finishObject (modelObjectCalls reader) text original out) := by
  dsimp only [finishObject]
  split
  · exact rejected_value _ _ _ _
  · exact fun _ => ⟨calls.cursor, calls.scalar, calls.boolean⟩

private theorem scalar_value (reader : BooleanElaboration.Native.Reader) (text : Source)
    (original : ParserState) (first last constant : Nat) (localObject : Bool)
    (seed : ObjectResult) (range : ScalarConstraintResult)
    (cursor : ValidCursor text seed.initFirst) (kind : seed.mark.kind = .integer)
    (declared : seed.mark.bounds = range.bounds) :
    ValueSuccess text seed.frame first last
      (objectScalar (modelObjectCalls reader) text original first last constant localObject seed range) := by
  dsimp only [objectScalar, modelObjectCalls]
  split
  · exact rejected_value _ _ _ _
  · rename_i accepted
    let value := ScalarExpression.read text seed.initFirst seed.frame.scalarNames first last (elaborating := true)
    have positive : value.after ≠ 0 := fun missing => accepted (by
      change ((((decide (value.after = 0) || value.bounds.isEmpty) || _) || _) || _) = true
      simp only [missing, decide_true, Bool.true_or])
    have nonempty : value.bounds.isEmpty = false := by
      cases empty : value.bounds.isEmpty
      · rfl
      · exact (accepted (by
          change ((((decide (value.after = 0) || value.bounds.isEmpty) || _) || _) || _) = true
          simp only [empty, Bool.or_true, Bool.true_or])).elim
    have inside : (!range.bounds.isEmpty && decide (value.bounds.lower ≥ range.bounds.lower) &&
        decide (value.bounds.upper ≤ range.bounds.upper)) = true := by
      cases found : !range.bounds.isEmpty && decide (value.bounds.lower ≥ range.bounds.lower) &&
          decide (value.bounds.upper ≤ range.bounds.upper)
      · exact (accepted (by
          change ((((decide (value.after = 0) || value.bounds.isEmpty) ||
            !(value.bounds.isEmpty || (!range.bounds.isEmpty && decide (value.bounds.lower ≥ range.bounds.lower) &&
              decide (value.bounds.upper ≤ range.bounds.upper)))) || _) || _) = true
          simp only [nonempty, found, Bool.false_or, Bool.not_false, Bool.or_true, Bool.true_or])).elim
      · rfl
    have parts := Bool.and_eq_true_iff.mp inside
    have included : value.bounds.included range.bounds = true := by
      simp only [Integer.Interval.included, nonempty, Bool.false_or, decide_eq_true_eq]
      exact ⟨of_decide_eq_true (Bool.and_eq_true_iff.mp parts.1).2, of_decide_eq_true parts.2⟩
    apply finish_value
    refine ⟨cursor, fun _ => ⟨rfl, positive, rfl, nonempty, ?_⟩, ?_⟩
    · simpa only [declared] using included
    · intro impossible
      simp [kind] at impossible

private theorem boolean_finish_value (reader : BooleanElaboration.Native.Reader) (text : Source)
    (original base : ParserState) (first last constant after : Nat) (localObject : Bool)
    (seed : ObjectResult) (cursor : ValidCursor text seed.initFirst)
    (kind : seed.mark.kind = .boolean)
    (read : booleanInitializerAfter text base seed.initFirst first last = after)
    (positive : after ≠ 0) :
    ValueSuccess text base first last
      (objectBooleanFinish (modelObjectCalls reader) text original first last constant after localObject seed) := by
  dsimp only [objectBooleanFinish]
  apply finish_value
  refine ⟨cursor, ?_, fun _ => ⟨read, positive⟩⟩
  intro impossible
  simp [kind] at impossible

private theorem boolean_value (reader : BooleanElaboration.Native.Reader) (text : Source)
    (original : ParserState) (first last constant : Nat) (localObject : Bool)
    (seed : ObjectResult) (cursor : ValidCursor text seed.initFirst) (kind : seed.mark.kind = .boolean) :
    ValueSuccess text seed.frame first last
      (objectBoolean (modelObjectCalls reader) text original first last constant localObject seed) := by
  dsimp only [objectBoolean]
  split
  · exact rejected_value _ _ _ _
  · rename_i accepted
    have positive : booleanInitializerAfter text seed.frame seed.initFirst first last ≠ 0 :=
      fun missing => accepted (by simp only [modelObjectCalls, missing, decide_true, Bool.true_or])
    split
    · split
      · exact rejected_value _ _ _ _
      · exact boolean_finish_value reader text original seed.frame first last constant _ localObject _ cursor kind rfl positive
    · exact boolean_finish_value reader text original seed.frame first last constant _ localObject _ cursor kind rfl positive

private theorem initialized_value (reader : BooleanElaboration.Native.Reader) (text : Source)
    (original : ParserState) (first last constant : Nat) (localObject : Bool)
    (seed : ObjectResult) (range : ScalarConstraintResult) (cursor : ValidCursor text range.after) :
    ValueSuccess text seed.frame first last
      (objectInitialized (modelObjectCalls reader) text original first last constant localObject seed range) := by
  let marked := {seed with mark := {seed.mark with bounds := range.bounds}}
  let started := {marked with initFirst := skipAt text (tokenAfter text range.after (.symbol ":="))}
  change ValueSuccess text seed.frame first last (if decide (started.initFirst = 0) then invalidObject else
    if decide (started.mark.kind = .integer) then
      objectScalar (modelObjectCalls reader) text original first last constant localObject started range
    else objectBoolean (modelObjectCalls reader) text original first last constant localObject started)
  have start : ValidCursor text started.initFirst :=
    model_skip_valid text _ (model_fixed_valid text _ ":=" false cursor)
  split
  · exact rejected_value _ _ _ _
  · split
    · exact scalar_value reader text original first last constant localObject started range start
        (of_decide_eq_true ‹_›) rfl
    · rename_i other
      have flag : started.mark.kind = .boolean := by
        cases kind : started.mark.kind
        · exact (other (by simp only [kind, decide_true])).elim
        · rfl
      exact boolean_value reader text original first last constant localObject started start flag

attribute [local irreducible] objectInitialized

private theorem typed_value (reader : BooleanElaboration.Native.Reader) (text : Source)
    (original : ParserState) (info : PackageBindings.Metadata) (first last colon constant : Nat)
    (localObject : Bool) (seed : ObjectResult)
    (framed : seed.frame.position ≠ 0 → ReaderFrame text seed.frame)
    (colonBound : ValidCursor text colon) (constantBound : ValidCursor text constant) :
    ValueSuccess text seed.frame first last
      (objectTyped (modelObjectCalls reader) text original info first last colon constant localObject seed) := by
  unfold objectTyped
  by_cases zero : seed.frame.position = 0
  · simp only [zero, decide_true, ↓reduceIte]
    exact rejected_value _ _ _ _
  · let position := if decide (constant = 0) then colon else constant
    let mark := packageTypeAt text seed.frame info position
    have bounded : ValidCursor text position := by dsimp only [position]; split <;> assumption
    simp only [zero, decide_false, Bool.false_eq_true, ↓reduceIte]
    change ValueSuccess text seed.frame first last (if decide (mark.after = 0) then invalidObject else _)
    by_cases absent : mark.after = 0
    · simp only [absent, decide_true, ↓reduceIte]
      exact rejected_value _ _ _ _
    · have found := (package_type_domain text seed.frame info position (framed zero) bounded).resolve_left absent
      simp only [absent, decide_false, Bool.false_eq_true, ↓reduceIte]
      let marked := {seed with constantObject := decide (constant ≠ 0), mark := mark}
      change ValueSuccess text seed.frame first last (if decide (mark.kind = .integer) then
        objectInitialized (modelObjectCalls reader) text original first last constant localObject marked
          (scalarConstraintAt text mark.after seed.frame.scalarNames mark.bounds)
        else objectInitialized (modelObjectCalls reader) text original first last constant localObject marked
          ⟨mark.after, mark.bounds⟩)
      split
      · exact initialized_value reader text original first last constant localObject marked _
          (scalarConstraintAt_position_valid text mark.after seed.frame.scalarNames found.cursor)
      · exact initialized_value reader text original first last constant localObject marked _ found.cursor

/-- The exact initializer environment is the one after native shadow removal,
before append. This theorem covers both local and package-level Objects. -/
theorem object_value_calls (reader : BooleanElaboration.Native.Reader) (text : Source)
    (frame : ParserState) (framed : ReaderFrame text frame) (info : PackageBindings.Metadata)
    (localObject : Bool)
    (present : (objectStep (modelObjectCalls reader) text frame info localObject).frame.position ≠ 0) :
    let name := objectName text frame
    let base := initializerBase text frame info name localObject
    ValueCalls text base name.first name.after (objectStep (modelObjectCalls reader) text frame info localObject) := by
  have succeeded : ValueSuccess text (initializerBase text frame info (objectName text frame) localObject)
      (objectName text frame).first (objectName text frame).after
      (objectStep (modelObjectCalls reader) text frame info localObject) := by
    dsimp only [objectStep, objectNameStep, modelObjectCalls]
    split
    · exact rejected_value _ _ _ _
    · cases localObject with
      | true =>
        simp only [↓reduceIte]
        apply typed_value reader text frame info
        · exact fun accepted => framed.hide_outer info _ accepted
        · exact fixedAfter_result_bound text _ ":" false (by decide)
        · exact fixedAfter_result_bound text _ "constant" true (by decide)
      | false =>
        simp only [Bool.false_eq_true, ↓reduceIte]
        split
        · apply typed_value reader text frame info
          · exact fun _ => framed.hidden_name _
          · exact fixedAfter_result_bound text _ ":" false (by decide)
          · exact fixedAfter_result_bound text _ "constant" true (by decide)
        · exact rejected_value _ _ _ _
  exact succeeded present

end Silver.ApplicationPackageInitializers
