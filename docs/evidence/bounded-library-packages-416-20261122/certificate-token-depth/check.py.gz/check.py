import importlib.util, json, os, subprocess, sys, time
from pathlib import Path
root = Path(sys.argv[1]); out = Path(sys.argv[2])
spec = importlib.util.spec_from_file_location("generator", root / "proof/generate_source_certificate.py")
generator = importlib.util.module_from_spec(spec); spec.loader.exec_module(generator)
source = (root / "src/silver_output_profile.adb").read_text()
_, reconstruction = generator.generate_parts(source, "profile", "tokens", compact_joins=True)
index = reconstruction.index("def tokens : Tokens :=")
assert reconstruction[index-1].startswith("set_option maxRecDepth ")
header = "import Silver.SourceLexer\nopen Silver.Source\nset_option maxRecDepth 100000\nset_option maxHeartbeats 10000000\n"
files = {"baseline": header + "\n".join(reconstruction[index:index+2]) + "\n", "repaired": header + "\n".join(reconstruction[index-1:index+2]) + "\n"}
env = dict(os.environ, LEAN_PATH=str(root / ".silver/linux-x86_64/proof/.lake/build/lib/lean"))
results = {}
for name, contents in files.items():
 path = out / (name + ".lean"); path.write_text(contents)
 start = time.monotonic()
 result = subprocess.run([str(root / ".tools/linux-x86_64/lean/bin/lean"), "-j2", str(path)], capture_output=True, text=True, env=env)
 (out / (name + ".log")).write_text(result.stdout + result.stderr)
 results[name] = {"returncode": result.returncode, "elapsed_seconds": time.monotonic()-start, "output": result.stdout + result.stderr}
 print(name, results[name], flush=True)
(out / "results.json").write_text(json.dumps(results, indent=2) + "\n")
assert results["baseline"]["returncode"] != 0 and "maximum recursion depth" in results["baseline"]["output"]
assert results["repaired"]["returncode"] == 0
