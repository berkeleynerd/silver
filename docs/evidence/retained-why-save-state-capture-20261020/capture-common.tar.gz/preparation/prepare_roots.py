from pathlib import Path
import hashlib,json
REPO=Path('/home/canto/src/github.com/berkeleynerd/silver')
def ident(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def relocate(value,old,new):
 if isinstance(value,str):return value.replace(old,new)
 if isinstance(value,list):return [relocate(v,old,new) for v in value]
 if isinstance(value,dict):return {relocate(k,old,new):relocate(v,old,new) for k,v in value.items()}
 return value
rows=[]
for oldname,newname in [('wfs-20261020','wse-20261020'),('why-session-save-capture-ready-20261018','why-session-save-capture-ready-20261020')]:
 old=REPO/'tmp'/oldname;new=REPO/'tmp'/newname
 assert not new.exists(),new
 assert len(str(old))==len(str(new))
 plan=json.loads((old/'plan.json').read_text())
 for name,expected in plan['file_identities'].items():assert ident(Path(name))==expected,name
 new.mkdir()
 copied=[]
 for name in plan['file_identities']:
  p=Path(name)
  if not p.is_relative_to(old):continue
  target=new/p.relative_to(old);target.parent.mkdir(parents=True,exist_ok=True)
  raw=p.read_bytes();replacement=raw.replace(str(old).encode(),str(new).encode())
  target.write_bytes(replacement)
  copied.append({'from':str(p),'to':str(target),'original':ident(p),'relocated':ident(target),'path_replacement_only':True})
 updated=relocate(plan,str(old),str(new))
 for case in updated['inputs']:(Path(case['cwd'])/'temp').mkdir(exist_ok=False)
 # Native/tool inputs remain identical; local path-dependent helper bytes are
 # pinned anew. Final collector installation and plan additions follow.
 updated['file_identities']={name:ident(Path(name)) for name in updated['file_identities']}
 updated['missing_state_capture_origin']={'root':str(old),'plan':ident(old/'plan.json'),'reason':'prior captures lack save-table/Buffer/serializer backing; retain same path lengths and selected logical input'}
 (new/'plan.json').write_text(json.dumps(updated,indent=2)+'\n')
 rows.append({'old':str(old),'new':str(new),'copied':copied})
(REPO/'tmp/retained-tool-capacity/tmp/save-state-capture-20261020/relocation.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([{'root':r['new'],'copied':len(r['copied'])} for r in rows],indent=2))
