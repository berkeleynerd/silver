"""One restricted managed observation; --print only emits its command."""
from pathlib import Path
import json, subprocess, sys, shlex
ROOT=Path(__file__).resolve().parent
REPO=Path('/home/canto/src/github.com/berkeleynerd/silver')
plan=json.loads((ROOT/'plan.json').read_text())
cmd=['python3',str(REPO/'scripts/dev.py'),'tool','--task','#119','--jobs','1',
 '--reason','Missing current session roots after retained all-read coverage audit; source-bound fresh prefix; offline duplicate lookup, repeated visit, cycle, detached, partial persistence and exact replay fixtures passed; one worker stopped before first inline, printer, save callback, prover request or solver','--workspace',str(ROOT)]
paths=set(plan['file_identities'])|{str(ROOT/n) for n in ['managed.py','run.py','plan.json','driver-resolution.json']}
paths.add(plan['gdbroot']+'/usr/bin/gdb')
for p in sorted(paths):cmd+=['--input',p]
cmd+=['--','python3',str(ROOT/'run.py')]
if '--print' in sys.argv:print(shlex.join(cmd))
else:raise SystemExit(subprocess.call(cmd,cwd=REPO))
