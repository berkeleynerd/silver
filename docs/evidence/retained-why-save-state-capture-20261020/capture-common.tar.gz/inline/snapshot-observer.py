"""Read-only core counter capture and optional raw immediate-state inventory.

Every successful read is flushed to memory-reads.jsonl before its caller can
interpret it. Auxiliary payloads are raw shallow blocks, never constrained to
a constructor. Typed decoding and coverage checks belong to offline replay.
"""
_original_data=data
_memory_log=(OUT/'memory-reads.jsonl').open('a')
def data(addr,n=8):
    raw=_original_data(addr,n)
    _memory_log.write(json.dumps({'address':addr,'bytes':n,'hex':raw.hex()},separators=(',',':'))+'\n')
    _memory_log.flush()
    return raw

def snapshot_block(ptr):
    assert ptr and ptr%8==0, ('invalid block pointer',ptr)
    header_bytes=data(ptr-8,8);head=int.from_bytes(header_bytes,'little');words=head>>10
    assert words<=1000000, ('diagnostic block limit',ptr,words)
    payload=data(ptr,words*8) if words else b''
    return {'address':ptr,'header':head,'header_hex':header_bytes.hex(),'tag':head&255,'words':words,
      'payload_hex':payload.hex(),'fields':list(struct.unpack('<'+'Q'*words,payload))}

def snapshot_module(name,offset):
    ptr=address(name);h=data(ptr-8,8);v=data(ptr+offset,8)
    return {'symbol':name,'address':ptr,'header_hex':h.hex(),'header':int.from_bytes(h,'little'),
      'offset':offset,'value':int.from_bytes(v,'little')}

def capture_identifier():
    checks={}
    for name,spec in PLAN['shared_observer']['symbols'].items():
        ptr=address(name);raw=data(ptr,32)
        assert raw.hex()==spec['first32'],('instruction mismatch',name)
        checks[name]={'address':ptr,'first32':raw.hex()}
    m=snapshot_module('camlWhy3__Ident',0xe8);cl=snapshot_block(m['value'])
    # Raw closure/header already durable before these layout checks.
    assert m['header']&255==0 and m['header']>>10>29
    assert cl['tag']==247 and cl['words']==3
    assert cl['fields'][0]==address('camlWhy3__Ident__fun_6183')
    ref=snapshot_block(cl['fields'][2]);assert ref['tag']==0 and ref['words']==1
    ref['decoded']=decode_tagged(ref['fields'][0]);assert ref['decoded']>=0
    result={'module':m,'closure':cl,'counter':ref,'instruction_checks':checks,
      'scope':'private Ident.id_register ref at this exact stopped first Input_Is_Valid/cvc5 inline entry'}
    p=OUT/'identifier-state.json';p.write_text(json.dumps(result,sort_keys=True)+'\n')
    SUMMARY['identifier_state']={'identity':identity(p),'counter':ref['decoded']};save()
    return result

def capture_auxiliary():
    blocks={};state={'blocks':blocks,'hashcons':{},'complete':False,
      'scope':'raw immediate backing and shallow key/data objects only; no typed capacity interpretation'}
    def read(ptr):
        if str(ptr) not in blocks:
            assert len(blocks)<1000000,'diagnostic auxiliary block-count limit'
            blocks[str(ptr)]=snapshot_block(ptr)
        return blocks[str(ptr)]
    def fields(ptr):return read(ptr)['fields']
    def shallow(ptr):
        if ptr!=none and not ptr&1:read(ptr)
    path=OUT/'auxiliary-state.json'
    try:
        none=int.from_bytes(data(address('caml_ephe_none'),8),'little')
        state['ephe_none_symbol']=address('caml_ephe_none');state['ephe_none_value']=none
        for name,mod,off in [('Ty.Hsty','camlWhy3__Ty',0x298),('Theory.Hstdecl','camlWhy3__Theory',0x2f0),('Task.Hstask','camlWhy3__Task',0x1d8)]:
            m=snapshot_module(mod,off);state['hashcons'][name]={'module':m}
            hf=fields(m['value']);cf=fields(hf[0]);fields(cf[3]);tf=fields(cf[4])
            outer=fields(tf[0]);hashes=fields(tf[1])
            for p in outer:
                for v in fields(p)[2:]:shallow(v)
            for p in hashes:read(p)
        m=snapshot_module('camlWhy3__Task',0x198);state['Task.Stdecl']={'module':m}
        sf=fields(m['value']);singleton=fields(sf[7]);mf=fields(singleton[2])
        fields(mf[5]);fields(mf[4]);tf=fields(mf[3]);outer=fields(tf[1]);seen=set()
        for p in outer:
            while p!=1 and not p&1 and p not in seen:
                seen.add(p);bf=fields(p);ef=fields(bf[1])
                for v in ef[1:]:shallow(v)
                p=bf[2]
        state['complete']=True
    except Exception as exc:
        state['failure']=repr(exc)
        SUMMARY.setdefault('auxiliary_failures',[]).append(repr(exc))
    finally:
        path.write_text(json.dumps(state,sort_keys=True)+'\n')
        SUMMARY['auxiliary_state']={'identity':identity(path),'complete':state['complete'],'blocks':len(blocks)}
        save()
    return state
