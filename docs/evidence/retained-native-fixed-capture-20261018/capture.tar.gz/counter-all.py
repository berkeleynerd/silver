import gdb,json
from pathlib import Path
root=Path('/tmp/silver-native-fixed-counter-20261018')
scan=json.loads((root/'static-all-tables.json').read_text());hooks=json.loads((root/'decrease-hooks.json').read_text())
static={v:int(k,16) for k,v in scan['targets'].items() if v!='checks__determine_range_cache_n'}
base=int(gdb.parse_and_eval('&uintp__uints__last_val'))-static['uintp__uints__last_val']
inf=gdb.selected_inferior();symbols=json.loads((root/'symbol-addresses.json').read_text())
def readi_start(address):return int.from_bytes(bytes(inf.read_memory(address,4)),'little',signed=True)
counts={k:dict(positive=0,negative=0,stores=0,initial=readi_start(base+static[k]),latest=None,peak=None) for k in static}
cache_calls={'discrete':0,'real':0};hit_rows=[];events=[];phases=[]
query_rows=[];return_rows=[];coherence={};coherence_failures=[];range_mutations=0
def readp(symbol):return int.from_bytes(bytes(inf.read_memory(symbols[symbol],8)),'little')
def node_info(n):
 head=readp('atree__atree_private_part__node_offsets__table')+16*n
 slots=readp('atree__atree_private_part__slots__table');off=readi(head+12)
 return dict(n=n,kind=readi(head)&255,sloc=readi(slots+4*(off+2)),etype=readi(slots+4*(off+4)),raw_header=[readi(head+4*j) for j in range(4)])
def readi(address):return int.from_bytes(bytes(inf.read_memory(address,4)),'little',signed=True)
def signed(v):return (v+2**31)%2**32-2**31
class Store(gdb.Breakpoint):
 def __init__(self,h):
  super().__init__('*'+str(base+h['address']),internal=True);self.h=h;self.count=0
 def stop(self):
  h=self.h;addr=base+static[h['target']];old=readi(addr)
  rhs=int(h['rhs'],0) if h['rhs'].startswith(('0x','-')) or h['rhs'].isdigit() else int(gdb.parse_and_eval('$'+h['rhs']))
  new=signed(rhs if h['operation']=='mov' else old-rhs)
  row=counts[h['target']]
  if row['initial'] is None:row['initial']=old
  row['peak']=max(old,new,row['peak'] if row['peak'] is not None else old)
  row['negative']+=max(0,old-new);row['stores']+=1;row['latest']=new;self.count+=1
  return False
stores=[Store(h) for h in hooks]
def uint_value(code):
 if code==-2100000000:return None
 bias=-2100000000+32768
 if -2099999999<=code<=bias+32767**2:return str(code-bias)
 first=-699999999
 p=readp('uintp__uints__table')+8*(code-first);length=readi(p);loc=readi(p+4)
 assert 1<=length<100000,(code,length)
 digits=bytes(inf.read_memory(readp('uintp__udigits__table')+4*loc,4*length))
 ds=[int.from_bytes(digits[4*j:4*j+4],'little',signed=True) for j in range(length)]
 value=abs(ds[0])
 for d in ds[1:]:value=value*32768+d
 return str(-value if ds[0]<0 else value)
query_stack=[]
class Return(gdb.Breakpoint):
 def __init__(self,address):super().__init__('*'+str(address),internal=True)
 def stop(self):
  row=query_stack.pop();rax=int(gdb.parse_and_eval('$rax'));edx=int(gdb.parse_and_eval('$edx'))
  ok=rax&255;lo=signed(rax>>32);hi=signed(edx);assert ok in (0,1)
  assert row['tag']=='discrete','unexpected real query; reader needs Ureal decoder'
  val=(ok,uint_value(lo),uint_value(hi));key=(row['n'],row['original'],row['valid'])
  if key in coherence and coherence[key]!=val:coherence_failures.append(dict(key=key,earlier=coherence[key],current=val))
  coherence[key]=val;return_rows.append(dict(row,returned=val));return False
for row in json.loads((root/'return-instructions.json').read_text())['checks__determine_range']:
 if row['mnemonic']=='ret':Return(row['address'])
class Range(gdb.Breakpoint):
 def __init__(self,sym,tag):super().__init__(sym,internal=True);self.tag=tag
 def stop(self):
  global range_mutations
  cache_calls[self.tag]+=1
  n=int(gdb.parse_and_eval('$edi'));valid=int(gdb.parse_and_eval('$esi'))&255
  original=readi(readp('atree__orig_nodes__tableX')+4*n)
  row=dict(tag=self.tag,valid=valid,original=original,**node_info(n));query_rows.append(row)
  query_stack.append(row)
  if len(query_rows)%100==0:record("range_progress")
  addr=0x3634c80+4*(n%1024)
  if readi(addr)==n:hit_rows.append(dict(row,cache_original=readi(0x3633c80+4*(n%1024))))
  inf.write_memory(addr,bytes(4));range_mutations+=1
  return False
Range('checks__determine_range','discrete');Range('checks__determine_range_r','real')
def record(tag):
 for k,v in counts.items():v['positive']=readi(base+static[k])-v['initial']+v['negative']
 row=dict(phase=tag,pools={k:dict(v,position=readi(base+static[k])) for k,v in counts.items()},cache_calls=dict(cache_calls),cache_same_node_entries=len(hit_rows))
 phases.append(row);(root/'all-roots'/'progress.json').write_text(json.dumps(row,indent=2)+'\n');print('POOL_PHASE '+json.dumps(dict(phase=tag,table_positions=len(row['pools']),cache_calls=dict(cache_calls)),sort_keys=True))
def name_value(n):
 p=readp('namet__name_entries__table')+16*(n+399999999)
 offset=readi(p);length=int.from_bytes(bytes(inf.read_memory(p+4,2)),'little',signed=True)
 assert 0<=length<=32767,(n,length)
 return bytes(inf.read_memory(readp('namet__name_chars__table')+offset+1,length)).decode('latin1') if length else ''
def names():
 last=readi(symbols['namet__name_entries__last_val'])
 return [dict(id=n,value=name_value(n)) for n in range(-399999997,last+1)]
def source_map():
 ptr=readp('sinput__source_file__table');last=readi(symbols['sinput__source_file__last_val'])
 rows=[]
 for i in range(1,last+1):
  p=ptr+(i-1)*128;fid=readi(p)
  rows.append(dict(index=i,file_id=fid,file=name_value(fid),source_first=readi(p+56),source_last=readi(p+60),template=readi(p+72),instance=readi(p+24),inlined_call=readi(p+48)))
 return dict(record_size=128,layout_basis='same pinned frontend source/host; name fields have explicit16byte rep clause',rows=rows)
class Phase(gdb.Breakpoint):
 def __init__(self,sym,tag,halt=False):super().__init__(sym,internal=True);self.tag=tag;self.halt=halt
 def stop(self):record(self.tag);return self.halt
class Done(gdb.FinishBreakpoint):
 def __init__(self,tag,halt=False):super().__init__(gdb.newest_frame(),internal=True);self.tag=tag;self.halt=halt
 def stop(self):record(self.tag);return self.halt
class Enter(gdb.Breakpoint):
 def __init__(self,sym,tag,halt=False):super().__init__(sym,internal=True);self.tag=tag;self.halt=halt
 def stop(self):
  if self.tag=='after_gigi':record('before_gigi');(root/'all-roots/names-before-gigi.json').write_text(json.dumps(names(),indent=2)+'\n')
  Done(self.tag,self.halt);return False
Phase('_ada_frontend','frontend_entry');Phase('cstand__create_standard','standard_entry')
Enter('gigi','after_gigi');Phase('*9627401','main_return',True)
def final():
 row=dict(phases=phases,cache_calls=cache_calls,cache_same_node=hit_rows,queries=query_rows,returns=return_rows,coherence_failures=coherence_failures,range_mutations=range_mutations,stores=[dict(h,count=b.count) for h,b in zip(hooks,stores)],backend_calls=0,unexpected_collect=0)
 (root/'all-roots'/'pool-counters.json').write_text(json.dumps(row,indent=2)+'\n')
 try:row.update(source_map=source_map(),names=names())
 except Exception as error:row['optional_read_error']=str(error)
 (root/'all-roots'/'pool-counters.json').write_text(json.dumps(row,indent=2)+'\n')
 print('POOL_FINAL '+json.dumps(dict(phases=[x['phase'] for x in phases],cache_calls=cache_calls,same_node=len(hit_rows),backend_calls=0)))
