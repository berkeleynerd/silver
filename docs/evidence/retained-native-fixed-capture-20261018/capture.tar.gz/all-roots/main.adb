with Silver_IO;
with Silver_Arguments;
procedure Main is
   pragma SPARK_Mode (On);
   D : constant String := Silver_Arguments.First_Or_Default ("x");
   I : Integer := D'Length;
   C2 : constant String := D & D;
   C3 : constant String := D & D & D;
   C4 : constant String := D & D & D & D;
   C5 : constant String := D & D & D & D & D;
   C6 : constant String := D & D & D & D & D & D;
   C7 : constant String := D & D & D & D & D & D & D;
   C8 : constant String := D & D & D & D & D & D & D & D;
   C9 : constant String := D & D & D & D & D & D & D & D & D;
   C10 : constant String := D & D & D & D & D & D & D & D & D & D;
begin
   Silver_IO.Put_Line (Integer'Image (I));
   Silver_IO.Put_Line (D & D);
   Silver_IO.Put_Line (D & D & D);
   Silver_IO.Put_Line (D & D & D & D);
   Silver_IO.Put_Line (D & D & D & D & D);
   Silver_IO.Put_Line (D & D & D & D & D & D);
   Silver_IO.Put_Line (D & D & D & D & D & D & D);
   Silver_IO.Put_Line (D & D & D & D & D & D & D & D);
   Silver_IO.Put_Line (D & D & D & D & D & D & D & D & D);
   Silver_IO.Put_Line (D & D & D & D & D & D & D & D & D & D);
end Main;
