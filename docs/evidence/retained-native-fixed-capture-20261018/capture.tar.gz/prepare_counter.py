from pathlib import Path
import json
root=Path(__file__).parent;base=Path('/tmp/silver-frontend-fixed-counter-20261018');dest=root/'all-roots'
plan=json.loads((dest/'invocation.json').read_text());plan['argv'][-1]=str(dest/'obj/main.s')
prefix=Path('/home/canto/src/github.com/berkeleynerd/silver/.tools/linux-x86_64/alire/toolchains/gnat_native_16.1.0_9f74f58a')
plan['environment']={'ADA_INCLUDE_PATH':str(prefix/'lib/gcc/x86_64-pc-linux-gnu/16.1.0/adainclude'),'ADA_OBJECTS_PATH':str(prefix/'lib/gcc/x86_64-pc-linux-gnu/16.1.0/adalib')};(dest/'invocation.json').write_text(json.dumps(plan,indent=2)+'\n')
s=(base/'counter-all.py').read_text().replace(str(base),str(root)).replace("root/'all-miss'","root/'all-roots'")
s=s.replace("int(gdb.parse_and_eval('&checks__determine_range_cache_n'))",'0x3634c80').replace("int(gdb.parse_and_eval('&checks__determine_range_cache_o'))",'0x3633c80')
start=s.index('def source_map():');end=s.index('class Phase',start)
s=s[:start]+'''def name_value(n):
 p=readp('namet__name_entries__table')+16*(n+399999999)
 offset=readi(p);length=int.from_bytes(bytes(inf.read_memory(p+4,2)),'little',signed=True)
 assert 0<=length<=32767,(n,length)
 return bytes(inf.read_memory(readp('namet__name_chars__table')+offset+1,length)).decode('latin1')
def names():
 last=readi(int(gdb.parse_and_eval('&namet__name_entries__last_val')))
 return [dict(id=n,value=name_value(n)) for n in range(-399999997,last+1)]
def source_map():
 ptr=readp('sinput__source_file__table');last=readi(int(gdb.parse_and_eval('&sinput__source_file__last_val')))
 rows=[]
 for i in range(1,last+1):
  p=ptr+(i-1)*128;fid=readi(p)
  rows.append(dict(index=i,file_id=fid,file=name_value(fid),source_first=readi(p+56),source_last=readi(p+60),template=readi(p+72),instance=readi(p+24),inlined_call=readi(p+48)))
 return dict(record_size=128,layout_basis='same pinned frontend source/host; name fields have explicit16byte rep clause',rows=rows)
'''+s[end:]
start=s.index("Phase('frontend'");end=s.index('def final():',start)
s=s[:start]+'''class Done(gdb.FinishBreakpoint):
 def __init__(self,tag,halt=False):super().__init__(gdb.newest_frame(),internal=True);self.tag=tag;self.halt=halt
 def stop(self):record(self.tag);return self.halt
class Enter(gdb.Breakpoint):
 def __init__(self,sym,tag,halt=False):super().__init__(sym,internal=True);self.tag=tag;self.halt=halt
 def stop(self):
  if self.tag=='after_gigi':record('before_gigi');(root/'all-roots/names-before-gigi.json').write_text(json.dumps(names(),indent=2)+'\\n')
  Done(self.tag,self.halt);return False
Phase('_ada_frontend','frontend_entry');Phase('cstand__create_standard','standard_entry')
Enter('gigi','after_gigi');Enter('main','main_return',True)
'''+s[end:]
s=s.replace('source_map=source_map(),phases=phases','source_map=source_map(),names=names(),phases=phases').replace('backend_calls=backend.count,unexpected_collect=collect.count','backend_calls=0,unexpected_collect=0').replace('backend_calls=backend.count)))','backend_calls=0)))')
(root/'counter-all.py').write_text(s)
run=(base/'run_all.py').read_text().replace(str(base),str(root)).replace("dest=root/'all-miss'","dest=root/'all-roots'")
run=run.replace("x['phases'][-1]['phase']!='before_symbol_free'","x['phases'][-1]['phase']!='main_return'")
(root/'run_all.py').write_text(run)
