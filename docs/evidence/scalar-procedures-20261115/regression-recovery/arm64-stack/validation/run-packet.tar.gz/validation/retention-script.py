"""Retain the single authorized 16 MiB child-soft-stack scalar-guard run."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
import tarfile

sys.dont_write_bytecode=True
native=Path('/home/agent/silver-workspaces/recovery-volume/native')
root=native.parent/'integration'
packet=root/'tmp/stack-validation-20261115'
dest=native/'docs/evidence/scalar-procedures-20261115/regression-recovery/arm64-stack/validation'
sys.path.insert(0,str(root/'scripts'))
from platforms import native_layout
from run_history import status
from dev import hash_paths
from proof_provenance import input_hashes,validate_provenance,tool_identities,digest

def write(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')

host=native_layout(root)
run=next(r for r in status(host)['runs'] if r['run_id']=='20261115T223501-c0b18e3fdea3')
assert not run['active'] and run['finish'] is not None
summary=json.loads((packet/'summary.json').read_text())
outer=json.loads((packet/'original-session-terminal.json').read_text())
assert outer['original_session']==58002
launch=json.loads((packet/'command.json').read_text())
inventory=json.loads((packet/'inventory.json').read_text())
log=(packet/'launcher.log').read_text(errors='replace')
starts=list(re.finditer(r'^(test\S+) \(([^\n)]+)\)(?: \.\.\. |\n)',log,re.M))
observed=[]
for i,start in enumerate(starts):
    end=starts[i+1].start() if i+1<len(starts) else len(log)
    fragment=log[start.end():end]
    outcomes=re.findall(r'(?:^| \.\.\. )(ok|FAIL|ERROR|skipped[^\n]*)$',fragment,re.M)
    subtests=re.findall(r'^  (test\S+) \(([^\n]+?)\) (.+) \.\.\. (FAIL|ERROR)$',fragment,re.M)
    if subtests:
        observed.append(dict(id=start[2],outcome='ERROR' if any(s[3]=='ERROR' for s in subtests) else 'FAIL',
                             subtests=[dict(id=s[1],parameters=s[2],outcome=s[3]) for s in subtests]))
    else:
        assert len(outcomes)==1,(start[2],outcomes,fragment)
        observed.append(dict(id=start[2],outcome=outcomes[0]))
actual=[r['id'] for r in observed]
result=dict(expected_ids=inventory['ids'],observed=observed,
            missing_ids=sorted(set(inventory['ids'])-set(actual)),unexpected_ids=sorted(set(actual)-set(inventory['ids'])),
            complete_inventory=(set(actual)==set(inventory['ids']) and len(actual)==len(set(actual))),
            passed=[r['id'] for r in observed if r['outcome']=='ok'],failed=[r for r in observed if r['outcome']!='ok'],
            summary=re.findall(r'^(?:Ran \d+ tests? in .+|OK(?: .*)?|FAILED .*)$',log,re.M))
native_inputs=input_hashes(host)
regression_inputs=hash_paths([Path(p) for p in json.loads((packet/'input-selectors.json').read_text())])
manifest=validate_provenance(host,host.compiler/'obj/gnatprove')
tools=tool_identities(host)
lean_tools={}
for name in ['lean','lake']:
    p=host.lean/'bin'/name
    version=subprocess.run([str(p),'--version'],capture_output=True,text=True,check=True)
    lean_tools[name]=dict(path=str(p.resolve()),sha256=digest(p.resolve()),version=version.stdout+version.stderr)
binaries={}
for name in ['silver','silver_image_adapter']:
    p=host.compiler/'bin'/name
    binaries[name]=dict(path=str(p),bytes=p.stat().st_size,sha256=digest(p),executable=os.access(p,os.X_OK))
resources=[json.loads(line) for line in (packet/'resources.jsonl').read_text().splitlines()]
verification=dict(verified_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),run_id=run['run_id'],host=host.key,machine=os.uname().nodename,
    original_session=58002,original_session_exit_code=outer['exit_code'],managed_outcome=run['state'],managed_finish=run['finish'],
    launch_head=launch['head'],terminal_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    workers=run['workers'],monitor=summary,
    resource_sample_count=len(resources),maximum_sample_gap_seconds=max([b['elapsed_seconds']-a['elapsed_seconds'] for a,b in zip(resources,resources[1:])],default=0),
    no_restart_or_duplicate=True,complete_test_inventory=result['complete_inventory'],case_count=len(actual),passed_count=len(result['passed']),nonpassing_count=len(result['failed']),
    original_failed_run='20261115T220916-99f1eaeea331',original_boundary_stack_failure_retained=True,
    native_input_count=len(native_inputs),all_native_inputs_match_launch_and_full_audit=(native_inputs==json.loads((packet/'prepared-native-inputs.json').read_text())==manifest['inputs_sha256']),
    regression_input_count=len(regression_inputs),all_regression_inputs_match_launch=(regression_inputs==json.loads((packet/'prepared-regression-inputs.json').read_text())==run['inputs']['inputs_sha256']),
    native_tool_identities_match=(tools==json.loads((packet/'prepared-native-tools.json').read_text())==manifest['tools']),
    lean_tool_identities_match=(lean_tools==json.loads((packet/'prepared-lean-tools.json').read_text())),
    binaries_match_launch=(binaries==json.loads((packet/'prepared-binaries.json').read_text())),native_report_hashes_valid=len(manifest['reports_sha256']),
    selected_model='GPT-6.1 Sol',selected_effort='High',runtime_telemetry='unavailable',token_cost='unavailable',
    scope='Complete unchanged 23-case test_scalar_guards.py under explicit 16 MiB child soft stack and unlimited hard stack; parent remains 8 MiB/unlimited. Original 8 MiB failures remain failed. No full-suite/native/whole-project Lean rerun, compiler build or production/harness repair claim.')
child=json.loads((packet/'actual-child-stack.json').read_text())
before=json.loads((packet/'original-parent-stack.json').read_text())
after=json.loads((packet/'terminal-parent-stack.json').read_text())
assert child['shell_pid']==summary['pid']==run['pid']
assert child['actual_stack_soft_bytes']==16777216 and child['actual_stack_hard_bytes']==-1
assert before['soft_bytes']==after['soft_bytes']==8388608 and before['hard_bytes']==after['hard_bytes']==-1
assert len(actual)==len(set(actual))==23 and result['complete_inventory']
verification.update(actual_monitored_child_stack=child,original_parent_stack=before,terminal_parent_stack=after,
                    child_soft_limit_only=True,parent_limits_unchanged=True,
                    postlaunch_live_proc_record_retained=False,
                    postlaunch_proc_gap='Separate live /proc inspection did not produce a retained record before process termination; direct pre-exec child resource.getrlimit and unchanged exec script establish inherited stack limits.',
                    exact_boundary_test_passed=('test_scalar_guards.ScalarGuardTests.test_admission_exact_source_limit_with_active_scalar_counts' in result['passed']),
                    boundary_checks_necessarily_executed_if_test_passed='Unchanged method loops over counts 0/1/32, checking each 4096-byte source acceptance and 4097-byte rejection (expected 2). No subtest failure or skip occurred.')
for name,data in [('verification.json',verification),('test-results.json',result),
                  ('terminal-managed-run.json',run),('terminal-native-inputs.json',native_inputs),('terminal-regression-inputs.json',regression_inputs),
                  ('terminal-native-tools.json',tools),('terminal-lean-tools.json',lean_tools),('terminal-binaries.json',binaries)]:
    write(packet/name,data)
(packet/'retention-script.py').write_bytes(Path(__file__).read_bytes())
assert not dest.exists(),'Do not overwrite retained evidence'
dest.mkdir(parents=True)
for name in ['verification.json','test-results.json','terminal-managed-run.json','original-session-terminal.json']:
    write(dest/name,json.loads((packet/name).read_text()))
records={}
with tarfile.open(dest/'run-packet.tar.gz','w:gz') as archive:
    for p in sorted(packet.iterdir()):
        if p.is_file():
            name='validation/'+p.name;archive.add(p,arcname=name,recursive=False)
            records[name]=dict(bytes=p.stat().st_size,sha256=digest(p))
    for basename in ['events.jsonl','native.log']:
        p=Path(run['directory'])/basename;name='managed-run/'+basename
        archive.add(p,arcname=name,recursive=False);records[name]=dict(bytes=p.stat().st_size,sha256=digest(p))
write(dest/'retained-files.json',records)
seen=set()
with tarfile.open(dest/'run-packet.tar.gz','r:gz') as archive:
    for member in archive:
        assert member.size==records[member.name]['bytes']
        assert hashlib.file_digest(archive.extractfile(member),'sha256').hexdigest()==records[member.name]['sha256']
        seen.add(member.name)
assert seen==records.keys()
write(dest/'retention-verification.json',dict(verified_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),archive_members_verified=len(seen),all_member_sizes_and_sha256_match=True))
print(json.dumps(verification,indent=2));print('Archive members verified',len(seen))
