module
public import Silver.ComposeBooleanDeclarationSource
public import Silver.FunctionSourceParts.FunctionLocalsExpectedTokens
meta import Silver.CertificateWitness
@[expose] public section
set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
open Silver.Compose
namespace Silver.FunctionSourceCandidate.Parts.RecoveryControls
def body : List String := ["current", ":", "parser_state", ":=", "state", ";", "begin", "while", "current", ".", "position", "/=", "0", "loop", "pragma", "loop_invariant", "(", "valid_state", "(", "text", ",", "current", ")", ")", ";", "pragma", "loop_invariant", "(", "current", ".", "position", ">=", "state", ".", "position", ")", ";", "pragma", "loop_invariant", "(", "current", ".", "functions", "=", "state", ".", "functions", ")", ";", "pragma", "loop_invariant", "(", "current", ".", "procedures", "=", "state", ".", "procedures", ")", ";", "pragma", "loop_invariant", "(", "current", ".", "first_procedure_parameter", "=", "state", ".", "first_procedure_parameter", ")", ";", "pragma", "loop_invariant", "(", "current", ".", "first_parameter", "=", "state", ".", "first_parameter", ")", ";", "pragma", "loop_invariant", "(", "current", ".", "pure", "=", "state", ".", "pure", ")", ";", "pragma", "loop_invariant", "(", "static", "=>", "function_locals_model", "(", "text", ",", "state", ",", "arguments", ")", "=", "function_locals_model", "(", "text", ",", "current", ",", "arguments", ")", ")", ";", "pragma", "loop_variant", "(", "increases", "=>", "current", ".", "position", ")", ";", "if", "take_token", "(", "text", ",", "current", ".", "position", ",", "begin_keyword", ")", "/=", "0", "then", "return", "current", ";", "end", "if", ";", "current", ":=", "function_local_at", "(", "text", ",", "current", ",", "arguments", ")", ";", "end", "loop", ";", "return", "invalid_state", ";", "end", "function_locals", ";"]
def header : List String := ["function", "function_locals", "return", "parser_state", "is"]
def shortTail : List String := ["function_locals", "return", "parser_state", "is", "begin", "return", "invalid_state", ";", "end", "function_locals", ";"]
theorem unique :
    BooleanDeclarationNative.SourceChecks.ordinaryFunction "function_locals" (header ++ body) = some body := by
  decide +kernel
theorem duplicateBefore :
    BooleanDeclarationNative.SourceChecks.ordinaryFunction "function_locals"
      (["function"] ++ shortTail ++ header ++ body) = none := by
  decide +kernel
theorem duplicateAfterBoundary :
    BooleanDeclarationNative.SourceChecks.ordinaryFunction "function_locals"
      ((header ++ body ++ ["function"]) ++ shortTail) = none := by
  decide +kernel
theorem droppedTokenRejected :
    BooleanDeclarationNative.SourceChecks.ordinaryFunction "function_locals"
      (header ++ body.tail) ≠ some body := by
  decide +kernel
theorem reorderedBodyRejected :
    BooleanDeclarationNative.SourceChecks.ordinaryFunction "function_locals"
      (header ++ body.reverse) ≠ some body := by
  decide +kernel
end Silver.FunctionSourceCandidate.Parts.RecoveryControls
