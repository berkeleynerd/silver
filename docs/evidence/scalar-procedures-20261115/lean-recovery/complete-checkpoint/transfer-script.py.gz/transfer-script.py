from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

root = Path.cwd()
proof_relative = Path('.silver/linux-aarch64/proof')
build_relative = proof_relative / '.lake/build'
destination = root / proof_relative
certificate = Path('/home/agent/silver-workspaces/recovery-volume/certificate')
integration = Path('/home/agent/silver-workspaces/recovery-volume/integration')
packet = root / 'docs/evidence/scalar-procedures-20261115/lean-recovery/complete-checkpoint'
scratch = root / 'tmp/lean-recovery/cache-transfer-20261115'
packet.mkdir(parents=True, exist_ok=True)
scratch.mkdir(parents=True, exist_ok=True)


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def inventory(directory):
    return {str(p.relative_to(directory)): digest(p)
            for p in sorted(directory.rglob('*')) if p.is_file()}


status = json.loads(subprocess.check_output(
    ['python3', 'scripts/dev.py', 'runs', 'status', '--limit', '0'], text=True))
for run in status['runs']:
    if not run['active']:
        continue
    for resource in run['resources']:
        for protected in [destination, certificate / proof_relative,
                          integration / proof_relative]:
            r = Path(resource)
            assert not (r == protected or r in protected.parents or protected in r.parents), (
                'Active proof-cache lease', run['run_id'], resource)

subprocess.run(['git', 'diff', '--exit-code', '7fa2549f8', '--',
                'proof', 'src', 'scripts'], check=True)
before = inventory(root / build_relative)
marker_path = destination / '.silver-cache-tools.json'
marker = json.loads(marker_path.read_text())
for name, expected in marker.items():
    assert digest(root / name) == expected, name

report = {'integration_production_revision': '7fa2549f8',
          'destination': str(destination), 'tools_sha256': marker,
          'local_build_files_before': len(before), 'donors': {},
          'imported_files_sha256': {}, 'preserved_local_build_files': True}


def verify_donor(donor, expected_run):
    ep = donor / '.silver/linux-aarch64/lean-focused-evidence.json'
    evidence = json.loads(ep.read_text())
    assert evidence['run_id'] == expected_run and evidence['axiom_audit'] == 'passed'
    assert evidence['tools_sha256'] == marker
    assert json.loads((donor / proof_relative / '.silver-cache-tools.json').read_text()) == marker
    for name, expected in marker.items():
        assert digest(donor / name) == expected, name
    for module in evidence['modules']:
        relative = Path(*module.split('.')).with_suffix('.lean')
        expected = evidence['workspace_inputs_sha256'][str(relative)]
        assert digest(donor / proof_relative / relative) == expected, (donor, relative)
        assert digest(destination / relative) == expected, (destination, relative)
    for name, expected in evidence['artifacts_sha256'].items():
        assert digest(donor / proof_relative / name) == expected, (donor, name)
    assert digest(donor / evidence['log']) == evidence['log_sha256']
    (packet / (donor.name + '-donor-evidence.json.gz')).write_bytes(
        gzip.compress(ep.read_bytes(), mtime=0))
    return evidence


certificate_evidence = verify_donor(certificate, '20261115T183635-e890328a97c4')
for name, expected in certificate_evidence['inputs_sha256'].items():
    if name.startswith('src/') or name == 'proof/generate_source_certificate.py':
        assert digest(root / name) == expected, name

manifest_path = (certificate / 'docs/evidence/scalar-procedures-20261115/'
                 'certificate-memory/final-source-aggregate/build-artifacts.json')
manifest = json.loads(manifest_path.read_text())
archive = certificate / 'tmp/certificate-memory-20261115/final-source-aggregate-build.tar.gz'
archive_digest = 'dd7651990bf3ca3d49a12460cdacc5295b0e30434478ae447745ec1c8e099288'
assert digest(archive) == archive_digest
stage = scratch / 'certificate-full-build'
assert not stage.exists(), 'Use a new staging directory for any subsequent transfer'
stage.mkdir()
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(manifest) and {m.name for m in members} == set(manifest)
    for member in members:
        relative = Path(member.name)
        assert member.isfile() and not relative.is_absolute() and '..' not in relative.parts
        relative.relative_to(build_relative)
        out = stage / relative
        out.parent.mkdir(parents=True, exist_ok=True)
        with tar.extractfile(member) as source, out.open('wb') as target:
            shutil.copyfileobj(source, target)
        assert digest(out) == manifest[member.name], member.name
        assert digest(certificate / relative) == manifest[member.name], member.name
shutil.copyfile(manifest_path, packet / 'certificate-full-build-manifest.json')
shutil.copyfile(marker_path, packet / 'tool-cache-marker.json')


def family(relative, module):
    path = Path(*module.split('.'))
    return any(relative.parent == Path(directory) / path.parent and
               relative.name.startswith(path.name + '.')
               for directory in ['lib/lean', 'ir'])


missing_modules = [m for m in certificate_evidence['modules']
                   if not (destination / '.lake/build/lib/lean' /
                           Path(*m.split('.')).with_suffix('.olean')).exists()]
certificate_files = {str(Path(name).relative_to(build_relative)): expected
                     for name, expected in manifest.items()}
selected = {name: expected for name, expected in certificate_files.items()
            if any(family(Path(name), module) for module in missing_modules)}
for module in missing_modules:
    prefix = str(Path('lib/lean') / Path(*module.split('.')))
    for suffix in ['.olean', '.olean.private', '.olean.server', '.trace']:
        assert prefix + suffix in selected, (module, suffix)
for relative, expected in selected.items():
    target = destination / '.lake/build' / relative
    assert not target.exists(), target
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(stage / build_relative / relative, target)
    assert digest(target) == expected, target
    report['imported_files_sha256'][relative] = expected
report['donors']['certificate'] = {
    'run_id': certificate_evidence['run_id'], 'audited_modules': len(certificate_evidence['modules']),
    'archive_sha256': archive_digest, 'archive_files_verified': len(manifest),
    'full_staging_directory': str(stage), 'selected_complete_module_families': missing_modules,
    'copied_files': len(selected), 'overlapping_local_families_preserved': True}

integration_evidence = verify_donor(integration, '20261115T173050-5f33a5830ee5')
module = 'Silver.ComposeArrayDeclarationSource'
assert module in integration_evidence['modules']
integration_build = integration / build_relative
selected_integration = {str(p.relative_to(integration_build)): digest(p)
                        for p in integration_build.rglob('*')
                        if p.is_file() and family(p.relative_to(integration_build), module)}
for suffix in ['.olean', '.olean.private', '.olean.server', '.trace']:
    name = 'lib/lean/Silver/ComposeArrayDeclarationSource' + suffix
    assert name in selected_integration
for relative, expected in selected_integration.items():
    target = destination / '.lake/build' / relative
    assert not target.exists(), target
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(integration_build / relative, target)
    assert digest(target) == expected, target
    report['imported_files_sha256'][relative] = expected
report['donors']['integration'] = {
    'run_id': integration_evidence['run_id'], 'audited_modules': len(integration_evidence['modules']),
    'selected_complete_module_families': [module], 'copied_files': len(selected_integration),
    'excluded_stale_unaudited_family': 'Silver.ReviewedOutputShape'}

after = inventory(root / build_relative)
for relative, expected in before.items():
    assert after[relative] == expected, ('Changed prior local cache file', relative)
assert json.loads(marker_path.read_text()) == marker
report['local_build_files_after'] = len(after)
report['module_objects_before'] = sum(name.endswith('.olean') for name in before)
report['module_objects_after'] = sum(name.endswith('.olean') for name in after)
(packet / 'cache-transfer.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k != 'imported_files_sha256'}, indent=2))
