module

public meta import Lean.Elab.Tactic.ElabTerm
public meta import Lean.Elab.ElabRules
public meta import Lean.Meta.Tactic.AuxLemma

public section

/-!
Proof-artifact support for generated source reconstruction. Elaborating a large
concrete witness against its expected equality repeats expensive conversion in
the elaborator. Instead, elaborate the witness independently and let Lean's
kernel check it at the exact goal type before returning an auxiliary theorem.
This uses the same checked auxiliary-lemma path as `decide +kernel`; it adds no
axiom and does not disable kernel checking. Every returned goal type has a
kernel-checked proof; the type-indexed cache may reuse an existing such proof.
-/

open Lean Elab Tactic Meta

namespace Silver.CertificateWitness

/-- Check a closed reconstruction witness at the goal type in the kernel.
Generated witnesses supply all arguments explicitly; this tactic does not infer
missing arguments from the goal or capture local hypotheses. -/
elab "kernel_exact " term:term : tactic => withMainContext do
  let expected ← getMainTarget
  let proof ← Term.elabTerm term none
  Term.synthesizeSyntheticMVarsNoPostponing
  let proof ← instantiateMVars proof
  let expected ← instantiateMVars expected
  let levelsInType := (collectLevelParams {} expected).params
  let levels := (← Term.getLevelNames).reverse.filter levelsInType.contains
  let name ← withOptions (Elab.async.set · false) do
    mkAuxLemma levels expected proof
  closeMainGoalUsing `kernel_exact fun _ _ =>
    pure (mkConst name (levels.map Level.param))

/-- Construct the same explicit character-list term as a generated list literal,
without elaborating one syntax node for every character. -/
private meta def charactersExpr (text : String) : Expr := Id.run do
  let char := mkConst ``Char
  let cons := mkApp (mkConst ``List.cons [Level.zero]) char
  let mut result := mkApp (mkConst ``List.nil [Level.zero]) char
  for c in text.toList.reverse do
    result := mkApp2 cons (toExpr c) result
  return result

/-- Build the existing `string_join_ofList` witness from compact string literals
and check it at the exact goal type. The supplied strings and generated term are
untrusted candidates: the kernel checks every character and the complete join. -/
elab "kernel_join " left:str right:str : tactic => withMainContext do
  let expected ← instantiateMVars (← getMainTarget)
  let proof := mkApp2 (mkConst `Silver.Source.string_join_ofList)
    (charactersExpr left.getString) (charactersExpr right.getString)
  let levelsInType := (collectLevelParams {} expected).params
  let levels := (← Term.getLevelNames).reverse.filter levelsInType.contains
  let name ← withOptions (Elab.async.set · false) do
    mkAuxLemma levels expected proof
  closeMainGoalUsing `kernel_join fun _ _ =>
    pure (mkConst name (levels.map Level.param))

end Silver.CertificateWitness
