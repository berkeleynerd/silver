"""Retain the original completed regression run, including failed outcomes."""
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile

sys.dont_write_bytecode = True
native = Path('/home/agent/silver-workspaces/recovery-volume/native')
root = native.parent / 'integration'
packet = root / 'tmp/final-validation-20261115/regression'
dest = native / 'docs/evidence/scalar-procedures-20261115/native-recovery/final-validation/regression'
sys.path.insert(0, str(root / 'scripts'))
from platforms import native_layout
from proof_provenance import input_hashes, validate_provenance, tool_identities, digest
from dev import hash_paths
from run_history import status

def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')

host = native_layout(root)
run = next(r for r in status(host)['runs'] if r['run_id'] == '20261115T220916-99f1eaeea331')
assert not run['active'], 'Original regression is still active'
assert run['finish'] is not None, 'Preserve unknown terminal state separately'
summary = json.loads((packet / 'summary.json').read_text())
outer = json.loads((packet / 'original-session-terminal.json').read_text())
assert outer['original_session'] == 84822
launch = json.loads((packet / 'command.json').read_text())
inventory = json.loads((packet / 'inventory.json').read_text())
log = (packet / 'launcher.log').read_text(errors='replace')
starts = list(re.finditer(r'^(test\S+) \(([^\n)]+)\)(?: \.\.\. |\n)', log, re.M))
observed = []
for index, start in enumerate(starts):
    end = starts[index+1].start() if index+1 < len(starts) else len(log)
    # Some tests emit diagnostics between their verbose prefix and final result.
    fragment = log[start.end():end]
    outcomes = re.findall(r'(?:^| \.\.\. )(ok|FAIL|ERROR|skipped[^\n]*)$', fragment, re.M)
    subtests = re.findall(r'^  (test\S+) \(([^\n]+?)\) (.+) \.\.\. (FAIL|ERROR)$', fragment, re.M)
    if subtests:
        observed.append(dict(id=start[2], outcome='ERROR' if any(s[3]=='ERROR' for s in subtests) else 'FAIL',
                             subtest_results=[dict(id=s[1], parameters=s[2], outcome=s[3]) for s in subtests]))
    else:
        assert len(outcomes) == 1, (start[2], outcomes, fragment)
        observed.append(dict(id=start[2], outcome=outcomes[0]))
actual_ids = [r['id'] for r in observed]
expected_ids = inventory['ids']
assert set(actual_ids) == set(expected_ids) and len(actual_ids) == len(set(actual_ids)) == 691
result = dict(expected_cases=len(expected_ids), completed_rows=len(observed),
              distinct_completed_ids=len(set(actual_ids)),
              missing_ids=sorted(set(expected_ids) - set(actual_ids)),
              unexpected_ids=sorted(set(actual_ids) - set(expected_ids)),
              duplicate_ids=sorted({i for i in actual_ids if actual_ids.count(i) > 1}),
              passed=[r['id'] for r in observed if r['outcome'] == 'ok'],
              failed=[r['id'] for r in observed if r['outcome'] == 'FAIL'],
              errors=[r['id'] for r in observed if r['outcome'] == 'ERROR'],
              skipped=[r for r in observed if r['outcome'].startswith('skipped')],
              expected_skips=launch['expected_platform_skips'],
              failure_result_headers=re.findall(r'^(?:FAIL|ERROR): (.+)$',log,re.M),
              unittest_summary=re.findall(r'^(?:Ran \d+ tests? in .+|OK(?: .*)?|FAILED .*)$', log, re.M),
              observed=observed)
actual_skips = [dict(id=r['id'], reason=ast.literal_eval(r['outcome'].removeprefix('skipped ')))
                for r in result['skipped']]
result['actual_skip_reasons_match_expected'] = (sorted(actual_skips,key=lambda r:r['id']) ==
                                               sorted(launch['expected_platform_skips'],key=lambda r:r['id']))
write(packet / 'test-results.json', result)
native_inputs = input_hashes(host)
regression_inputs = hash_paths([Path(p) for p in json.loads((packet / 'input-selectors.json').read_text())])
native_prepared = json.loads((packet / 'prepared-native-inputs.json').read_text())
regression_prepared = json.loads((packet / 'prepared-regression-inputs.json').read_text())
manifest = validate_provenance(host, host.compiler / 'obj/gnatprove')
tools = tool_identities(host)
lean_tools = {}
for name in ['lean', 'lake']:
    p = host.lean / 'bin' / name
    version = subprocess.run([str(p), '--version'], check=True, capture_output=True, text=True)
    lean_tools[name] = dict(path=str(p.resolve()), sha256=digest(p.resolve()), version=version.stdout + version.stderr)
binaries = {}
for name in ['silver', 'silver_image_adapter']:
    p = host.compiler / 'bin' / name
    binaries[name] = dict(path=str(p), bytes=p.stat().st_size, sha256=digest(p), executable=os.access(p, os.X_OK))
samples = json.loads((packet / 'sample-manifest.json').read_text())
resources = [json.loads(line) for line in (packet / 'resources.jsonl').read_text().splitlines()]
gaps = [b['elapsed_seconds']-a['elapsed_seconds'] for a,b in zip(resources, resources[1:])]
verification = dict(verified_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    run_id=run['run_id'], host=host.key, machine=os.uname().nodename,
    launch_head=launch['head'], terminal_head=subprocess.check_output(['git','rev-parse','HEAD'], cwd=root, text=True).strip(),
    original_session=84822, original_session_exit_code=outer['exit_code'],
    managed_outcome=run['state'], managed_finish=run['finish'],
    wrapper=summary, workers=run['workers'], no_restart_or_duplicate=True,
    monitor_continuity=dict(samples=len(resources), maximum_sample_gap_seconds=max(gaps, default=0),
                            original_monitor_preserved=True, attachment_guard_required=False),
    complete_test_inventory_observed=(set(actual_ids)==set(expected_ids) and len(actual_ids)==len(set(actual_ids))),
    passed_count=len(result['passed']), failing_case_count=len(result['failed']), error_case_count=len(result['errors']),
    failure_result_count=len(result['failure_result_headers']),
    skip_count=len(result['skipped']), sample_manifest_count=len(samples['samples']),
    manifest_sample_test_passed=('test_samples.SupportedSampleTests.test_manifest_samples' in result['passed']),
    maximum_dynamic_expression_test_passed=('test_samples.SupportedSampleTests.test_maximum_dynamic_expression' in result['passed']),
    actual_skip_reasons_match_expected=result['actual_skip_reasons_match_expected'],
    sample_manifest_matches_launch=digest(root/'samples/manifest.json')==inventory['sample_manifest_sha256'],
    native_input_count=len(native_inputs), all_native_inputs_match_launch_and_full_audit=(native_inputs==native_prepared==manifest['inputs_sha256']),
    regression_input_count=len(regression_inputs), all_regression_inputs_match_launch=(regression_inputs==regression_prepared==run['inputs']['inputs_sha256']),
    native_tool_identities_match=(tools==json.loads((packet/'prepared-native-tools.json').read_text())==manifest['tools']),
    lean_tool_identities_match=(lean_tools==json.loads((packet/'prepared-lean-tools.json').read_text())),
    binaries_match_launch=(binaries==json.loads((packet/'prepared-binaries.json').read_text())),
    native_report_hashes_valid=len(manifest['reports_sha256']), binaries=binaries,
    selected_model='GPT-6.1 Sol', selected_effort='High', runtime_telemetry='unavailable', token_cost='unavailable',
    scope='Original complete regression execution and exact input/tool/binary retention. Failed results remain failed; no successful repair or all-pass claim.')
for name,data in [('verification.json',verification),('terminal-managed-run.json',run),('test-results.json',result),
                  ('terminal-native-inputs.json',native_inputs),('terminal-regression-inputs.json',regression_inputs),
                  ('terminal-native-tools.json',tools),('terminal-lean-tools.json',lean_tools),('terminal-binaries.json',binaries)]:
    write(packet/name,data)
(packet/'retention-script.py').write_bytes(Path(__file__).read_bytes())
(packet/'active-regression-checkpoint.json').write_bytes((native/'tmp/native-monitor-20261115/active-regression-checkpoint.json').read_bytes())
assert not dest.exists(), 'Do not overwrite retained evidence'
dest.mkdir(parents=True)
for name in ['verification.json','test-results.json','terminal-managed-run.json']:
    write(dest/name,json.loads((packet/name).read_text()))
retained={}
with tarfile.open(dest/'run-packet.tar.gz','w:gz') as archive:
    for p in sorted(packet.iterdir()):
        if p.is_file():
            name='regression/'+p.name
            archive.add(p,arcname=name,recursive=False)
            retained[name]=dict(bytes=p.stat().st_size,sha256=digest(p))
    for basename in ['events.jsonl','native.log']:
        p=Path(run['directory'])/basename
        name='managed-run/'+basename
        archive.add(p,arcname=name,recursive=False)
        retained[name]=dict(bytes=p.stat().st_size,sha256=digest(p))
write(dest/'retained-files.json',retained)
seen=set()
with tarfile.open(dest/'run-packet.tar.gz','r:gz') as archive:
    for member in archive:
        assert member.size==retained[member.name]['bytes']
        assert hashlib.file_digest(archive.extractfile(member),'sha256').hexdigest()==retained[member.name]['sha256']
        seen.add(member.name)
assert seen==retained.keys()
write(dest/'retention-verification.json',dict(verified_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),archive_members_verified=len(seen),every_member_size_and_sha256_matches=True))
print(json.dumps(verification,indent=2))
print('Archive members verified',len(seen))
