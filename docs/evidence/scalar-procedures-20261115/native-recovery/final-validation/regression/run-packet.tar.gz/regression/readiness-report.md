# Regression readiness, 2026-11-15

Read-only discovery at 2026-11-15T18:34:38.870038+00:00, integration HEAD `094d70c304492308dce97787c3558e938ac22103`. Actual Linux ARM64 host: 12 CPUs, approximately 15 GiB RAM, no swap. Authoritative output-profile source SHA-256: `9ede490b6cf72b352a39072cd37f4ef39774409c6024135487cf076567b59b9c`. No builds, bootstrap, tests or expensive proof checks were started. Only this owned scratch directory was written; Python bytecode generation was disabled for discovery. No independent token/cost telemetry is available.

## Inventory

`unittest.TestLoader().discover("tests")` imports and enumerates the same suite as managed `dev.py test`; it does not execute test methods or setup. Current inventory is **691 cases / 691 distinct IDs across 57 modules**, with no loader errors, duplicate IDs, added IDs or removed IDs against `docs/evidence/scalar-procedures-20261115/recovery/test-inventory.json`. `inventory.json` retains exact IDs and baseline digest. The manifest-driven sample case covers **85 samples**, using subtests rather than separate discovered IDs. Relative to the starting inventory commit `cc4c88e7f`, only `tests/test_lean_source.py` changed (53 inserted/5 removed lines); unchanged IDs do not imply unchanged behavior. Its certificate/generator assertions must run on the final proof/tooling inputs.

Two discovered cases are intentionally skipped on ARM64 because their retained 8 MiB stack/large-vector evidence is Linux x86-64-specific; both IDs/reasons are in `inventory.json`. Integration has native Lean and Lake, so missing-Lean fixture skips are not expected from tool absence. This was discovery/setup inspection, not a claim that all cases pass.

## Dependencies and workspace choice

Use the existing **integration** worktree after its active native audit releases `.silver/linux-aarch64`. It already has Alire, its local lock/context, generated installation-bound Ada configuration, the Image GNATprove overlay, both compiler executables, and pinned native Lean/Lake. Rebuild before testing the final source; existence alone does not establish current executable inputs. No bootstrap is indicated by the inspected paths. Generated configuration embeds absolute installation paths, so copying an existing binary/configuration to another location is unsafe without rebootstrap/rebuild.

The native author worktree is a poorer test destination: its source/scripts/samples/catalogue match integration, but it has no standard `compiler/bin/silver` or Image adapter binary and no native Lean/Lake. Its proof tree differs in 36 files and `test_lean_source.py` differs. Running there now would use stale proof fixtures and skip native-Lean regressions. It is still owned by the native author. Do not repurpose or synchronize it without coordinated ownership.

A completed compiler `proof-provenance.json` is mandatory for final native assurance but is not a direct `dev.py build`/test prerequisite: build executes current preflight and tests invoke the SPARK executable directly. Actual application compilation performs its own report/obligation checks. The suite also compiles native probe fixtures with GPRbuild and executes real GNATprove and small native Lean fixtures, so all pinned tools matter even beyond the prebuilt compiler.

## Lease/resource behavior

`dev.py test` leases **the entire host artifact root**, not just application directories (`scripts/dev.py:423-426`). Resolved ancestor/descendant exclusion therefore blocks it against integration's active native proof, any build, or an integration Lean run. A different branch name does not help; never bypass the managed runner or alter a live lease.

Unittest runs serially, but `src/silver.adb:132` deliberately invokes each application's GNATprove with canonical **`-j0`**. `test_samples.py` explicitly checks this policy. Managed `test --jobs N` records a reservation; it does **not** forward N to the nested application GNATprove or impose CPU/RSS limits. Probe fixtures also use native `-j2` and small Lean processes. Keep those proof settings unchanged. A low test reservation cannot make dense proof overlap safe.

## Concrete schedule and commands

1. Preserve the active integration native audit. Dense certificate work may proceed in its own leased workspace after the function-source slot releases, under the lead's existing memory guards. Inventory/review/documentation work can overlap.
2. When the integration native audit has ended successfully and released its resources, the compiler **build** is useful bounded overlap with certificate work: reserve two native workers, explicitly recording the competing dense workload. Recheck current managed state first. If measured host headroom is inadequate, defer rather than force overlap.
3. Run the full suite when dense certificate/source Lean work has completed and integration has no other artifact writer. Give it the available managed worker budget and preserve canonical application `-j0`. Do not start an integration complete Lean run concurrently with this suite because the artifact-root lease overlaps. A fresh full suite on frozen final delivery inputs avoids an unnecessary test-reuse argument.

```sh
cd /home/agent/silver-workspaces/recovery-volume/integration
PYTHONDONTWRITEBYTECODE=1 python3 scripts/dev.py runs status --limit 5
PYTHONDONTWRITEBYTECODE=1 python3 scripts/dev.py build --jobs 2 --task '#370' --reason 'Build final delivery compiler after native audit; two workers leave capacity for coordinated certificate workload'
# After dense proof allocations release and the artifact-root lease is free:
PYTHONDONTWRITEBYTECODE=1 python3 scripts/dev.py runs status --limit 5
PYTHONDONTWRITEBYTECODE=1 python3 scripts/dev.py test --task '#370' --reason 'Complete final 691-case regression and 85-sample inventory; dense proof allocations released; preserve canonical application -j0'
```

If no competing workload exists at build time, omit `--jobs 2` and use the automatic available worker budget with an accurate reason. Inspect the managed test log for actual passes/skips/failures and retain failed runs as failed. The two platform skips are independent native macOS/x86 claims, not evidence for universal assurance. Complete native and Lean/source-correspondence checkpoints remain mandatory regardless of test outcome.
