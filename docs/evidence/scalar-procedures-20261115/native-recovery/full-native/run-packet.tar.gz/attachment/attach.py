import datetime, json, os, pathlib, signal, subprocess, time
out = pathlib.Path(__file__).resolve().parent
pid = 22821
pgid = 22821
threshold_kib = 1572864

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def identity():
    p = pathlib.Path(f'/proc/{pid}')
    stat = (p/'stat').read_text().rsplit(')', 1)[1].split()
    return dict(pid=pid, ppid=int(stat[1]), process_group=int(stat[2]),
                start_ticks=int(stat[19]), state=stat[0],
                command=(p/'cmdline').read_bytes().decode().split('\0')[:-1])

expected = identity()
assert expected['process_group'] == pgid
assert expected['command'][:9] == ['python3','scripts/dev.py','prove','--full','--task','#370','--jobs','2','--reason']
assert 'frozen integrated source 8a03ab122' in expected['command'][9]
initial = dict(attached_at=now(), monitor_pid=os.getpid(), identity=expected,
               minimum_host_available_kib=threshold_kib, interval_seconds=5,
               original_wrapper_pid=22794, original_sampler_last_at='2026-11-15T18:39:22.914043+00:00',
               original_wrapper_status='disappeared; exit status unavailable',
               reason='Root explicitly authorized replacement attachment after original wrapper disappeared; no proof restart')
(out/'attachment.json').write_text(json.dumps(initial,indent=2)+'\n')
print(json.dumps(initial), flush=True)
started = time.monotonic()
guard_sent = False
while True:
    try:
        live = identity()
    except FileNotFoundError:
        terminal_reason = 'verified native PID no longer exists; actual original wrapper/tool exit unavailable to this monitor'
        break
    if live['start_ticks'] != expected['start_ticks'] or live['command'] != expected['command'] or live['process_group'] != pgid:
        terminal_reason = 'native PID identity changed; stopped attachment without signaling replacement process'
        break
    if live['state'] == 'Z':
        terminal_reason = 'verified native PID became zombie; actual original wrapper/tool exit unavailable to this monitor'
        break
    rows=[]
    for line in subprocess.check_output(['ps','-eo','pid,ppid,pgid,rss,comm'],text=True).splitlines()[1:]:
        p,pp,g,r,n=line.split(maxsplit=4)
        rows.append(dict(pid=int(p),ppid=int(pp),pgid=int(g),rss_kib=int(r),name=n))
    descendants={pid}
    while True:
        added=descendants|{r['pid'] for r in rows if r['ppid'] in descendants}
        if added==descendants: break
        descendants=added
    selected=[r for r in rows if r['pid'] in descendants]
    mem={l.split(':')[0]:int(l.split()[1]) for l in pathlib.Path('/proc/meminfo').read_text().splitlines()}
    sample=dict(time=now(), elapsed_attachment_seconds=round(time.monotonic()-started,3),
                mem_available_kib=mem['MemAvailable'],sum_rss_kib=sum(r['rss_kib'] for r in selected),
                largest_process_rss_kib=max((r['rss_kib'] for r in selected),default=0),processes=selected)
    with (out/'attached-resources.jsonl').open('a') as f: f.write(json.dumps(sample)+'\n')
    if not guard_sent and mem['MemAvailable'] < threshold_kib:
        live=identity()
        assert live['start_ticks']==expected['start_ticks'] and live['command']==expected['command'] and live['process_group']==pgid
        event=dict(time=now(),action='SIGINT',process_group=pgid,mem_available_kib=mem['MemAvailable'])
        (out/'guard-event.json').write_text(json.dumps(event,indent=2)+'\n')
        print(json.dumps(event),flush=True)
        os.killpg(pgid,signal.SIGINT)
        guard_sent=True
    time.sleep(5)
terminal=dict(finished_at=now(),reason=terminal_reason,guard_sent=guard_sent,elapsed_attachment_seconds=time.monotonic()-started,
              original_wrapper_returncode=None,tool_returncode=None)
(out/'attachment-terminal.json').write_text(json.dumps(terminal,indent=2)+'\n')
print(json.dumps(terminal),flush=True)
