"""Terminal read-only verification and evidence retention; never launches proof."""
import datetime, hashlib, json, pathlib, shutil, subprocess, sys, tarfile
own = pathlib.Path(__file__).resolve().parent
native = own.parents[1]
integration = native.parent/'integration'
packet = native/'tmp/native-recovery-20261115/full-integration'
run_id = '20261115T174959-94ae5c6fdf63'
dest = native/'docs/evidence/scalar-procedures-20261115/native-recovery/full-native'
status = json.loads(subprocess.check_output(['python3','scripts/dev.py','runs','status','--limit','0'],cwd=integration))
run = next(r for r in status['runs'] if r['run_id']==run_id)
assert not run['active'], 'Refusing retention before native run becomes terminal'
assert (own/'attachment-terminal.json').is_file(), 'Attachment still active'
sys.path.insert(0,str(integration/'scripts'))
from platforms import native_layout
from proof_provenance import input_hashes, validate_provenance, tool_identities, digest
from check_evidence import audit_sources
host=native_layout(integration)
reports=host.compiler/'obj/gnatprove'
final_inputs=input_hashes(host)
prepared=json.loads((packet/'prepared-inputs.json').read_text())
comparison=dict(prepared_count=len(prepared),final_count=len(final_inputs),
                changed=[k for k in prepared.keys()&final_inputs.keys() if prepared[k]!=final_inputs[k]],
                added=sorted(final_inputs.keys()-prepared.keys()),removed=sorted(prepared.keys()-final_inputs.keys()))
manifest=None
stats=None
error=None
current_tools=None
try:
    manifest=validate_provenance(host,reports)
    stats=audit_sources(host.root/'src',reports,host.generated,effective_command=manifest['command'])
    current_tools=tool_identities(host)
    assert current_tools==manifest['tools'], 'Terminal tool identities differ from manifest'
    assert prepared==final_inputs==manifest['inputs_sha256'], 'Native inputs differ'
except Exception as e:
    error=f'{type(e).__name__}: {e}'
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
write(own/'final-inputs.json',final_inputs)
write(own/'input-comparison.json',comparison)
write(own/'terminal-managed-run.json',run)
if current_tools is not None:write(own/'terminal-tools.json',current_tools)
resources=[]
for path in [packet/'resources.jsonl',own/'attached-resources.jsonl']:
    rs=[json.loads(l) for l in path.read_text().splitlines()]
    resources.append(dict(file=path.name,sample_count=len(rs),first_sample=rs[0]['time'],last_sample=rs[-1]['time'],
                          sampled_max_tree_rss_kib=max(r['sum_rss_kib'] for r in rs),
                          sampled_min_host_available_kib=min(r['mem_available_kib'] for r in rs)))
events=[json.loads(l) for l in (pathlib.Path(run['directory'])/'events.jsonl').read_text().splitlines()]
phases=[e for e in events if e['event'] in ['phase-start','phase-end','finished']]
summary=dict(verified_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),run_id=run_id,
             host=host.key,machine=status['machine'],frozen_source_commit=json.loads((packet/'command.json').read_text())['frozen_source_commit'],
             current_integration_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=integration,text=True).strip(),
             output_source_sha256=digest(integration/'src/silver_output_profile.adb'),
             managed_outcome=run['state'],managed_returncode=run['returncode'],native_duration_seconds=run['duration_seconds'],
             native_tool_returncode=next((e.get('returncode') for e in events if e['event']=='phase-end' and e.get('phase')=='native-tool'),None),
             audit_phase_completed=any(e['event']=='phase-end' and e.get('phase')=='audit' for e in events),
             validation_mode=manifest.get('mode') if manifest else None,initial_cache_state=manifest.get('initial_state') if manifest else None,
             original_wrapper_exit_status=None,coverage_stats=stats,verification_error=error,
             native_input_comparison=comparison,report_count=len(manifest['reports_sha256']) if manifest else None,
             tool_identity_count=len(manifest['tools']) if manifest else None,phases=phases,
             resource_series=resources,attachment=json.loads((own/'attachment.json').read_text()),
             attachment_terminal=json.loads((own/'attachment-terminal.json').read_text()),
             selected_monitor_model='GPT-6.1 Sol',selected_effort='High',
             runtime_model_effort_telemetry='unavailable',token_cost_evidence='unavailable',
             scope='Complete canonical forced cached native audit and terminal evidence checks; no Lean/source-correspondence or regression-test completion claim')
write(own/'verification.json',summary)
assert not dest.exists(), f'Refusing to overwrite existing evidence: {dest}'
dest.mkdir(parents=True)
for name in ['verification.json','input-comparison.json','terminal-managed-run.json']:
    shutil.copy2(own/name,dest/name)
if (reports/'proof-provenance.json').exists():shutil.copy2(reports/'proof-provenance.json',dest/'proof-provenance.json')
archived={}
with tarfile.open(dest/'run-packet.tar.gz','w:gz') as tar:
    def add(path,name):
        if path.is_file():
            tar.add(path,arcname=name,recursive=False)
            archived[name]=dict(bytes=path.stat().st_size,sha256=digest(path))
    for p in sorted(packet.iterdir()):add(p,'original-wrapper/'+p.name)
    for p in sorted(own.iterdir()):
        if p.is_file():add(p,'attachment/'+p.name)
    registry=pathlib.Path(run['directory'])
    for name in ['events.jsonl','native.log']:add(registry/name,'managed-run/'+name)
    for p in sorted(reports.iterdir()):
        if p.suffix=='.spark' or p.name in ['gnatprove.out','gnatprove.sarif','proof-inputs.json','proof-provenance.json']:
            add(p,'reports/'+p.name)
write(dest/'retained-files.json',archived)
print(json.dumps(summary,indent=2))
