import pathlib,json,re
base=pathlib.Path(__file__).resolve().parent
r=json.loads((base/'attached-resources.jsonl').read_text().splitlines()[-1])
log=(base.parent/'native-recovery-20261115/full-integration/launcher.log').read_text()
native_diagnostics=re.findall(r'^.*(?:warning:|error:|medium:|high:|unproved|might fail).*$',log,re.M)[-12:]
lean_run='20261115T211741-9bb82c28fe83'
lean_dir=pathlib.Path('/home/agent/silver-worktrees/procedures-lean-370/tmp/lean-recovery/complete-project-after-native-shape')
lean_log=(lean_dir/'launcher.log').read_text()
lean_resources=json.loads((lean_dir/'resources.jsonl').read_text().splitlines()[-1])
lean_diagnostics=re.findall(r'^.*(?:error:|failed|excessive memory|memory limit|interrupted|SIGINT).*$',lean_log,re.I|re.M)[-12:]
lean_summary=json.loads((lean_dir/'summary.json').read_text()) if (lean_dir/'summary.json').exists() else None
lean_guard_files=[p.name for p in lean_dir.iterdir() if p.is_file() and 'guard' in p.name]
known_terminal=(base/('lean-terminal-alerted-'+lean_run)).exists()
alerts=[] if known_terminal else [f'Lean complete after native-shape repair: {s}' for s in lean_diagnostics]
profile_report=pathlib.Path('/home/agent/silver-workspaces/recovery-volume/integration/.silver/linux-aarch64/compiler/obj/gnatprove/silver_output_profile.spark')
if profile_report.exists() and not (base/'output-profile-progress.json').exists(): alerts.append('Progress: native output-profile report exists; required records still need inspection')
if lean_summary is not None and not known_terminal:alerts.append('Complete after native-shape Lean terminal summary is present')
if lean_guard_files and not known_terminal:alerts.append('Complete after native-shape Lean guard files: '+', '.join(lean_guard_files))
if lean_resources['sum_rss_kib']>8*1048576 or r['mem_available_kib']<3*1048576:alerts.append('Resource concern: dense Lean tree above 8GiB or host available below 3GiB')
native_root=pathlib.Path('/home/agent/silver-workspaces/recovery-volume/integration')
expected_units={p.stem for directory in [native_root/'src',native_root/'.silver/linux-aarch64/generated'] for p in directory.rglob('*') if p.suffix in ['.ads','.adb']}
actual_units={p.stem for p in profile_report.parent.glob('*.spark')}
brief_summary=({k:lean_summary.get(k) for k in ['finished_at','returncode','elapsed_seconds','interrupted','peak_sum_rss_kib','minimum_mem_available_kib']} if lean_summary is not None else None)
print(json.dumps(dict(time=r['time'],mem_available_kib=r['mem_available_kib'],sum_rss_kib=r['sum_rss_kib'],
                     diagnostics=native_diagnostics+alerts,native_diagnostics=native_diagnostics,
                     native_report_inventory=dict(produced=len(actual_units),expected=len(expected_units),unexpected=sorted(actual_units-expected_units),scope='inventory only; terminal audit pending'),
                     tail=log.splitlines()[-3:],attachment_terminal=(base/'attachment-terminal.json').exists(),
                     lean=dict(run_id=lean_run,scope='complete cached continuation after independently accepted six-shape repair; prior failures and focused successes stay separate',
                               elapsed_seconds=lean_resources['elapsed_seconds'],sum_rss_kib=lean_resources['sum_rss_kib'],
                               mem_available_kib=lean_resources['mem_available_kib'],tail=lean_log.splitlines()[-4:],
                               diagnostics=lean_diagnostics,guard_files=lean_guard_files,summary=brief_summary),
                     prior_complete_lean=dict(run_id='20261115T190543-9bda6434802c',state='interrupted after two kernel-memory failures; no complete success'),
                     prior_focused_lean=dict(run_id='20261115T194603-51d997e177d8',state='focused success only; owner collected exact evidence'),
                     prior_complete_continuation=dict(run_id='20261115T195423-d7650f191422',state='interrupted after procedure metadata kernel-memory failure; no complete success'),
                     prior_focused_procedure=dict(run_id='20261115T201355-b250e246f4ef',state='focused success only; owner collected exact evidence'),
                     prior_complete_procedure=dict(run_id='20261115T201746-8829535d867a',state='interrupted after three predicate-flow kernel-memory failures; no complete success'),
                     prior_diagnostic_probe=dict(run_id='20261115T203335-d0861ad752c6',state='17-field diagnostic-only probe failed on two fields; no production gate claim'),
                     prior_focused_flow=dict(run_id='20261115T204311-34308bc25803',state='focused full flow candidate success only; owner retained exact evidence'),
                     prior_complete_flow=dict(run_id='20261115T205032-5834a8189332',state='interrupted after six native-shape kernel-memory failures; no complete success'),
                     prior_focused_shape=dict(run_id='20261115T210927-f5ecbbed5260',state='focused full shape candidate success only; owner retained exact evidence'))))
