# Native monitor checkpoint — 2026-11-15

Parent `/root` assigned routine terminal monitoring/evidence retention for #370;
selected GPT-6.1 Sol High. Live runtime model/effort telemetry and tokens/cost
are unavailable. Source/proof/toolchain/cache changes and new native/Lean/test
runs are outside this thread's authorization.

Exclusive integration native artifact ownership accepted at about 18:37 UTC.
Existing canonical full native run: `20261115T174959-94ae5c6fdf63`, PID/PGID
22821, two workers, native Linux aarch64. Full `-U`, mode all, warnings/checks
as errors, level2, cvc5/z3/altergo, timeout30, forced every-unit analysis.
Frozen source8a03ab122; output source9ede490b6cf72b352a39072cd37f4ef39774409c6024135487cf076567b59b9c.
Wrapper packet: `../native-recovery-20261115/full-integration/`. Existing
wrapper samples every5s and guards host available memory below1.5GiB.
Do not replace/restart it. Native monitoring read-only except own scratch and
`docs/evidence/scalar-procedures-20261115/native-recovery/full-native/`.

Exec session3921 belongs to original native_recovery namespace; this agent's
write_stdin returns Unknown process id. Root acknowledged and authorized using
the wrapper terminal summary/final-inputs plus durable managed outcome/logs;
root may re-engage original agent solely to poll/close session after completion.

At18:39 UTC (~49min), no warning/error/unproved diagnostics, no terminal summary.
Native tree~0.81GiB RSS and host available~10.92GiB. Dense OutputBodyCertificate
run20261115T183635-e890328a97c4 active separately under certificate_memory.
No full tests until native lease release/root coordination.

After terminal: inspect actual subprocess exit, managed final state, complete
coverage audit/provenance manifest and exact input/report/tool hashes. Preserve
failure unchanged and notify root for Astra Max diagnosis; never repair/restart.
Retain exact reports/log/resources/input comparisons, concise README and Refs#370
evidence commit on native branch; send root outcome/counts/run IDs/commit and
release artifact ownership. No push, GitHub comment or issue closure.

## Attachment update

Original wrapper PID 22794 disappeared and native PID 22821 became PPID 1;
original sampling stopped at 18:39:22 UTC. Root explicitly authorized replacement
attachment at 18:42 UTC. After verifying the exact native command, process group
22821 and /proc start ticks 823022, attach.py began at 18:43:06 UTC as PID 105970,
exec session 39882. It preserves the existing computation and samples every
5 seconds with the same 1.5 GiB host-availability SIGINT guard. Its session must
stay alive until terminal. The original wrapper exit remains unavailable;
terminal tool/audit outcome comes from durable managed events/logs and complete
manifest/input/tool checks. Sampling gap is retained and must not be hidden.

`retain.py` is prepared but has not run. It refuses an active run, performs
read-only complete report/provenance/tool/input checks, and retains exact packets.
After terminal inspection, write README/SHA256SUMS, inspect and commit only the
owned full-native evidence directory (Refs #370), then hand off ownership to root.

## Current checkpoint — 21:03 UTC

Still active: native run `20261115T174959-94ae5c6fdf63`, PID/PGID 22821,
verified start ticks 823022. Replacement attachment PID 105970 remains alive,
exec session 39882. Active orchestration cell `g8:39` loops on that session,
checks status.py each minute, reports new diagnostics/terminal states and emits
a ten-minute status. Resume with functions.wait on that cell; do not terminate
it or finish this agent while the guard is needed. Source/cache/job unchanged.
No native diagnostics or guard trigger. At 20:59, produced-report inventory
was 54/78 units, with no unexpected names; this is not a coverage verdict.
Exact CPU/session-write snapshots prove continued work despite quiet logs.

`output-profile-progress.json` and exact `.spark` snapshot retain the active
full run's helper milestone: Array_Declaration_At has all SPARK coverage,
56 positive prover records (43 precondition, 11 range, 1 assertion, 1 complete
postcondition) and 2 positive flow records (termination/dependencies), no helper
warning/error/assumption records. Original assertion at line 2342 is explicitly
proved. Declaration_At caller has 11 proof/2 flow records, all positive, all
coverage and no warnings/assumptions. Source SHA remains 9ede490b6cf72b352a39072cd37f4ef39774409c6024135487cf076567b59b9c;
all 2,606 native inputs match the full-run snapshot, canonical 30-second policy.
Root received this as whole-helper/caller progress only; complete native audit
and manifest remain pending. Do not release build/test ownership yet.

Root also delegated read-only Lean file alerts; Lean owner retains all original
sessions, guards, source/cache and terminal/evidence handling. Prior outcomes
are explicitly separated in status.py. The latest complete Lean run
`20261115T205032-5834a8189332` in `complete-project-after-predicate-flow` stopped
at 21:01:37 UTC on six PredicateNativeShapeCandidate kernel-memory diagnostics
at 196, 202, 220, 226, 262, 272 (column 2), returncode -2 / interrupted,
665.63 s. Root and lean_recovery received exact terminal alerts. The preceding
PredicateNativeHelpersCandidate passed 236 s; that does not establish full
success. Own terminal-alert marker suppresses repeats. Four complete attempts
remain interrupted; prior successful focused gates and failed diagnostic probe
are retained by their owner. Await root/author's next explicit run/path before
switching the read-only Lean alerts. Do not operate Lean sessions or signals.

Terminal native retention remains prepared in retain.py, not executed. It
refuses an active native run, verifies complete provenance/coverage and exact
input/tool identities, preserves all current native reports plus original and
attachment logs/resources/commands/CPU snapshots, and creates only owned
`docs/evidence/scalar-procedures-20261115/native-recovery/full-native/`.
After inspection, write concise README and SHA256SUMS, validate archive hashes,
commit only that directory with Refs #370 on native branch (latest 944ed3d08),
then send root outcome, exact counts/run IDs/commit and release native ownership.
Do not push, comment on GitHub, close #370, start build/tests, or repair failures.
Original wrapper exit is unavailable; derive terminal outcome from durable
managed phase/end events, logs, complete manifest and fresh checks. Sampling
gap 18:39:22–18:43:06 must remain explicit. Selected monitor model is Sol High;
live runtime telemetry, tokens and cost are unavailable. CLI memory not updated.
