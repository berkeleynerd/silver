-- Generated exact vendor binding; bootstrap and rebuild after tool changes.
package Silver_Image_Config with SPARK_Mode => On is
   Native_Gnatwhy3 : constant String := "/Volumes/EXTERNAL/Users/rebecca/src/github.com/berkeleynerd/silver/tmp/procedures-native-370/.tools/linux-aarch64/alire/cache/releases/gnatprove_16.1.0_ee22bf0d/libexec/spark/bin/gnatwhy3";
   Native_Gnatwhy3_SHA256 : constant String := "4a3b9e6cd3dc542ddb72dc82cfddbaa8b5da075aa27eb11f6d6a3e57fb148368";
end Silver_Image_Config;
