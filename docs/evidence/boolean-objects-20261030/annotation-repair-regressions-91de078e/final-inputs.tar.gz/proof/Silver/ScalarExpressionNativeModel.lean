module

public import Silver.ScalarExpressionAdmission
public import Silver.ArrayBindingsNativeEquations

@[expose] public section

/-! Result-level equations for the executable scalar helper. These definitions
retain rejection and every intermediate interval check. Their relation to the
independent AST reader, and to actual source bodies, are separate proofs. -/
namespace Silver.ScalarExpression.Native

def literalResult (number : ScalarLiteral.Result) (negative : Bool) : Result :=
  let checked := Integer.checked (Integer.Interval.singleton (signedValue number.value negative))
  if number.after = 0 ∨ checked.safe = false then invalid
  else ⟨number.after, checked.bounds, 1, true⟩

def unaryResult (operand : Result) (negative : Bool) : Result :=
  let checked := if negative then Integer.checkedNegate operand.bounds else ⟨true, operand.bounds⟩
  if operand.after = 0 ∨ checked.safe = false then invalid
  else {operand with bounds := checked.bounds}

def binaryResult (left right : Result) (operator : Nat) : Result :=
  let checked := if operator = 43 then Integer.checkedAdd left.bounds right.bounds
    else if operator = 45 then Integer.checkedSubtract left.bounds right.bounds
    else if operator = 42 then Integer.checkedMultiply left.bounds right.bounds
    else if operator = 47 then Integer.checkedDivide left.bounds right.bounds
    else if operator = 109 then Integer.checkedModulo left.bounds right.bounds
    else if operator = 114 then Integer.checkedRemainder left.bounds right.bounds
    else ⟨false, Integer.Interval.empty⟩
  if left.after = 0 ∨ right.after = 0 ∨ checked.safe = false ∨ left.operands > maxOperands - right.operands
  then invalid else ⟨right.after, checked.bounds, left.operands + right.operands, left.isStatic && right.isStatic⟩

def closeResult (text : Source) (value : Result) : Result :=
  let after := symbol text value.after 41
  if after = 0 then invalid else {value with after := after}

def atomResult (text : Source) (position : Nat) (names : Environment)
    (maskFirst maskAfter : Nat) (allowSign : Bool) : Result :=
  let first := skip text position
  let after := nameAfter text first
  let index := lookup text names first after
  if first = 0 ∨ first > text.length then invalid
  else if Cursor.byteAt text first = 43 ∨ Cursor.byteAt text first = 45 then
    if !allowSign then invalid else
      literalResult (ScalarLiteral.read text (skip text (first + 1))) (Cursor.byteAt text first == 45)
  else
    let number := ScalarLiteral.read text first
    if number.after ≠ 0 then literalResult number false
    else if index = 0 ∨ (maskFirst ≠ 0 ∧ Named.equalName text maskFirst maskAfter first after = true)
    then invalid
    else ⟨after, (binding names index).bounds.normalize, 1, (binding names index).isStatic⟩

abbrev Reader := Source → Nat → Environment → Nat → Nat → Bool → Result

def scalarReader : Reader := fun text position names maskFirst maskAfter allowSign =>
  read text position names maskFirst maskAfter allowSign

def unaryStep (recurse : Reader) (text : Source) (position : Nat) (names : Environment)
    (maskFirst maskAfter : Nat) : Result :=
  let next := skip text (position + 1)
  let number := ScalarLiteral.read text next
  closeResult text (if number.after ≠ 0 then literalResult number (Cursor.byteAt text position == 45)
    else unaryResult (recurse text next names maskFirst maskAfter false) (Cursor.byteAt text position == 45))

def compoundStep (recurse : Reader) (text : Source) (names : Environment)
    (left : Result) (maskFirst maskAfter : Nat) : Result :=
  let next := skip text left.after
  if next = 0 ∨ next > text.length then invalid
  else if Cursor.byteAt text next = 41 then {left with after := next + 1}
  else if binaryAfter text next = 0 then invalid
  else closeResult text (binaryResult left (recurse text (binaryAfter text next) names maskFirst maskAfter false)
    (Silver.lowercase (Cursor.byteAt text next)))

def groupStep (recurse : Reader) (text : Source) (position : Nat) (names : Environment)
    (maskFirst maskAfter : Nat) : Result :=
  let first := skip text (position + 1)
  if first > text.length then invalid
  else if Cursor.byteAt text first = 43 ∨ Cursor.byteAt text first = 45
  then unaryStep recurse text first names maskFirst maskAfter
  else compoundStep recurse text names (recurse text first names maskFirst maskAfter true) maskFirst maskAfter

def readStep (recurse : Reader) (text : Source) (position : Nat) (names : Environment)
    (maskFirst maskAfter : Nat) (allowSign : Bool) : Result :=
  let first := skip text position
  if first = 0 ∨ first > text.length then invalid
  else if Cursor.byteAt text first = 40 then groupStep recurse text first names maskFirst maskAfter
  else atomResult text first names maskFirst maskAfter allowSign

def readFuel : Nat → Reader
  | 0 => fun _ _ _ _ _ _ => invalid
  | fuel + 1 => readStep (readFuel fuel)

structure ScalarCalls where
  checked : Int → Int → Integer.CheckResult
  negate : Integer.Interval → Integer.CheckResult
  add : Integer.Interval → Integer.Interval → Integer.CheckResult
  subtract : Integer.Interval → Integer.Interval → Integer.CheckResult
  multiply : Integer.Interval → Integer.Interval → Integer.CheckResult
  divide : Integer.Interval → Integer.Interval → Integer.CheckResult
  modulo : Integer.Interval → Integer.Interval → Integer.CheckResult
  remainder : Integer.Interval → Integer.Interval → Integer.CheckResult
  normalize : Integer.Interval → Integer.Interval

def scalarModel : ScalarCalls where
  checked a b := Integer.checked ⟨a, b⟩
  negate := Integer.checkedNegate
  add := Integer.checkedAdd
  subtract := Integer.checkedSubtract
  multiply := Integer.checkedMultiply
  divide := Integer.checkedDivide
  modulo := Integer.checkedModulo
  remainder := Integer.checkedRemainder
  normalize := Integer.Interval.normalize

abbrev ArraysReader := Source → Nat → Environment → Nat → Nat → Bool →
  optParam ArrayBindings.Metadata [] → optParam ArrayBindings.Initials [] → optParam Bool false → Result

def arrayAtomStep (recurse : Reader) (text : Source) (position : Nat) (names : Environment)
    (maskFirst maskAfter target : Nat) (arrays : ArrayBindings.Metadata)
    (initials : ArrayBindings.Initials) (elaborating : Bool) : Result :=
  let opened := symbol text position 40
  if opened = 0 then invalid else
    let subscript := recurse text opened names maskFirst maskAfter true
    let closed := symbol text subscript.after 41
    if closed ≤ position ∨ subscript.operands = maxOperands ∨
        ArrayBindings.contains (ArrayBindings.binding arrays target) subscript.bounds = false then invalid
    else ⟨closed, ArrayBindings.readBounds arrays initials elaborating target subscript.bounds,
      subscript.operands + 1, false⟩

def arraysAtomStep (recurse : Reader) (text : Source) (position : Nat) (names : Environment)
    (maskFirst maskAfter : Nat) (allowSign : Bool) (arrays : ArrayBindings.Metadata)
    (initials : ArrayBindings.Initials) (elaborating : Bool) : Result :=
  let first := skip text position
  let after := nameAfter text first
  let index := lookup text names first after
  let target := ArrayBindings.lookup text arrays first after
  if first = 0 ∨ first > text.length then invalid
  else if Cursor.byteAt text first = 43 ∨ Cursor.byteAt text first = 45 then
    if !allowSign then invalid else
      literalResult (ScalarLiteral.read text (skip text (first + 1))) (Cursor.byteAt text first == 45)
  else
    let number := ScalarLiteral.read text first
    if number.after ≠ 0 then literalResult number false
    else if after = 0 then invalid
    else if maskFirst ≠ 0 ∧ Named.equalName text maskFirst maskAfter first after = true then invalid
    else if index ≠ 0 then ⟨after, (binding names index).bounds.normalize, 1, (binding names index).isStatic⟩
    else if target = 0 then invalid
    else arrayAtomStep recurse text after names maskFirst maskAfter target arrays initials elaborating

def arraysUnaryStep (recurse : ArraysReader) (text : Source) (position : Nat) (names : Environment)
    (maskFirst maskAfter : Nat) (arrays : ArrayBindings.Metadata)
    (initials : ArrayBindings.Initials) (elaborating : Bool) : Result :=
  unaryStep (fun text position names maskFirst maskAfter allowSign =>
    recurse text position names maskFirst maskAfter allowSign arrays initials elaborating)
    text position names maskFirst maskAfter

def arraysCompoundStep (recurse : ArraysReader) (text : Source) (names : Environment)
    (left : Result) (maskFirst maskAfter : Nat) (arrays : ArrayBindings.Metadata)
    (initials : ArrayBindings.Initials) (elaborating : Bool) : Result :=
  compoundStep (fun text position names maskFirst maskAfter allowSign =>
    recurse text position names maskFirst maskAfter allowSign arrays initials elaborating)
    text names left maskFirst maskAfter

def arraysGroupStep (recurse : ArraysReader) (text : Source) (position : Nat) (names : Environment)
    (maskFirst maskAfter : Nat) (arrays : ArrayBindings.Metadata)
    (initials : ArrayBindings.Initials) (elaborating : Bool) : Result :=
  let first := skip text (position + 1)
  if first > text.length then invalid
  else if Cursor.byteAt text first = 43 ∨ Cursor.byteAt text first = 45
  then arraysUnaryStep (@recurse) text first names maskFirst maskAfter arrays initials elaborating
  else arraysCompoundStep (@recurse) text names
    (recurse text first names maskFirst maskAfter true arrays initials elaborating) maskFirst maskAfter arrays initials elaborating

def arraysReadStep (recurse : ArraysReader) (text : Source) (position : Nat) (names : Environment)
    (maskFirst maskAfter : Nat) (allowSign : Bool) (arrays : ArrayBindings.Metadata)
    (initials : ArrayBindings.Initials) (elaborating : Bool) : Result :=
  let first := skip text position
  if first = 0 ∨ first > text.length then invalid
  else if Cursor.byteAt text first = 40 then
    arraysGroupStep (@recurse) text first names maskFirst maskAfter arrays initials elaborating
  else arraysAtomStep (fun text position names maskFirst maskAfter allowSign =>
    recurse text position names maskFirst maskAfter allowSign)
    text first names maskFirst maskAfter allowSign arrays initials elaborating

def arraysReadFuel : Nat → ArraysReader
  | 0 => fun _ _ _ _ _ _ _ _ _ => invalid
  | fuel + 1 => fun text position names maskFirst maskAfter allowSign arrays initials elaborating =>
      match arrays with
      | [] => readFuel (fuel + 1) text position names maskFirst maskAfter allowSign
      | _ :: _ => arraysReadStep (@arraysReadFuel fuel) text position names maskFirst maskAfter allowSign arrays initials elaborating

structure Calls where
  lookupModel : Source → Environment → Nat → Nat → Nat → Nat
  lookup : Source → Environment → Nat → Nat → Nat
  skip : Source → Nat → Nat
  symbol : Source → Nat → Nat → Nat
  nameAfter : Source → Nat → Nat
  binaryAfter : Source → Nat → Nat
  literalResult : ScalarLiteral.Result → Bool → Result
  unaryResult : Result → Bool → Result
  binaryResult : Result → Result → Nat → Result
  closeResult : Source → Result → Result
  readArrayAtom : Source → Nat → Environment → Nat → Nat → Nat → ArrayBindings.Metadata → ArrayBindings.Initials → Bool → Result
  readAtom : ArraysReader
  readUnary : Source → Nat → Environment → Nat → Nat → optParam ArrayBindings.Metadata [] → optParam ArrayBindings.Initials [] → optParam Bool false → Result
  readCompound : Source → Nat → Environment → Result → Nat → Nat → optParam ArrayBindings.Metadata [] → optParam ArrayBindings.Initials [] → optParam Bool false → Result
  readGroup : Source → Nat → Environment → Nat → Nat → optParam ArrayBindings.Metadata [] → optParam ArrayBindings.Initials [] → optParam Bool false → Result
  readExpression : ArraysReader
  arrays : ArrayBindings.Native.Calls
  scalars : ScalarCalls
  integerLiteral : Source → Nat → ScalarLiteral.Result
  trivia : Source → Nat → Nat
  identifier : Source → Nat → Nat
  equalName : Source → Nat → Nat → Nat → Nat → Bool
  nameIs : Source → Nat → Nat → Source → Bool
  lowercase : Nat → Nat

def modelCalls : Calls where
  lookupModel := lookupFrom
  lookup := ScalarExpression.lookup
  skip := ScalarExpression.skip
  symbol := ScalarExpression.symbol
  nameAfter := ScalarExpression.nameAfter
  binaryAfter := ScalarExpression.binaryAfter
  literalResult := Native.literalResult
  unaryResult := Native.unaryResult
  binaryResult := Native.binaryResult
  closeResult := Native.closeResult
  readArrayAtom := arrayAtomStep (fun text position names maskFirst maskAfter allowSign => read text position names maskFirst maskAfter allowSign)
  readAtom := arraysAtomStep (fun text position names maskFirst maskAfter allowSign => read text position names maskFirst maskAfter allowSign)
  readUnary := arraysUnaryStep (@read)
  readCompound text _ names left maskFirst maskAfter := arraysCompoundStep (@read) text names left maskFirst maskAfter
  readGroup := arraysGroupStep (@read)
  readExpression := @read
  arrays := ArrayBindings.Native.modelCalls
  scalars := scalarModel
  integerLiteral := ScalarLiteral.read
  trivia := Cursor.triviaPosition
  identifier := Named.identifierEnd
  equalName := Named.equalName
  nameIs := Named.nameIs
  lowercase := Silver.lowercase

theorem literal_correspondence (names : Environment) (number : ScalarLiteral.Result) (negative : Bool) :
    literalResult number negative = summarize names (literal number negative) := by
  unfold literalResult literal
  dsimp only
  by_cases zero : number.after = 0
  · simp [zero, summarize]
  · simp only [zero, false_or, ↓reduceIte, summarize, leaves, maxOperands,
      show ¬ 64 < 1 by decide, or_self, Integer.Expr.infer, Integer.accepted, isStatic]
    cases checked : (Integer.checked (Integer.Interval.singleton (signedValue number.value negative))).safe <;>
      simp

end Silver.ScalarExpression.Native
