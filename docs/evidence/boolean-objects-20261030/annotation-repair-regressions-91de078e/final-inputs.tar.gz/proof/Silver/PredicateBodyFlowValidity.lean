module

public import Silver.PredicateBodyFlow
public import Silver.PredicateBodyProperties
public import Silver.PredicateConditionFlowValidity

@[expose] public section

namespace Silver.Predicate
open Compose

namespace ScalarMetadata

theorem FlowReady.replace {names declarations flow}
    (ready : FlowReady names declarations flow)
    (index : Nat) (bounds : Integer.Interval) (positive : 0 < index)
    (bounded : index ≤ names.length) (mutable : (ScalarExpression.binding names index).mutable = true)
    (typed : bounds.Bounded) (nonempty : bounds.isEmpty = false)
    (included : ∀ value, bounds.Contains value → (ScalarExpression.binding names index).declaredBounds.Contains value) :
    FlowReady names declarations (flow.replace index bounds) := by
  have active : index ≤ flow.count := by rw [ready.compatible.count]; exact bounded
  have model := ActiveFlow.replace_model flow index bounds positive active
  refine ⟨?_, ?_, ?_, ?_⟩
  · apply overlayCompatible_of_preserved ready.compatible
      ((ActiveFlow.replace_count ..).trans ready.compatible.count)
    intro other otherPositive otherBound immutable declared
    have different : other ≠ index := by
      intro same
      subst other
      rw [mutable] at immutable
      contradiction
    rw [model]
    exact ite_eq_right different
  · rw [model]
    exact Integer.Ranges.put_bounded ready.bounded typed
  · intro other target found
    rw [model]
    by_cases same : other = index
    · subst other
      have bindingFound : flowBounds names index =
          some (ScalarExpression.binding names index).declaredBounds := by
        rw [flowBounds_active names index positive bounded, mutable]
        rfl
      rw [bindingFound] at found
      cases found
      refine ⟨bounds, by simp only [Integer.put, ↓reduceIte], ?_⟩
      exact included
    · obtain ⟨incoming, present, subset⟩ := ready.contained other target found
      exact ⟨incoming, by simpa only [Integer.put, same, ↓reduceIte] using present, subset⟩
  · intro other value isMutable found
    rw [model] at found
    change Integer.put flow.model.scalars index (some bounds) other = some value at found
    by_cases same : other = index
    · subst other
      simp only [Integer.put, ↓reduceIte, Option.some.injEq] at found
      subst value
      exact nonempty
    · apply ready.mutableNonempty other value isMutable
      simpa only [Integer.put, same, ↓reduceIte] using found

end ScalarMetadata

def BodyScan.FlowReady (context : ParseContext) (scan : BodyScan) : Prop :=
  ScalarMetadata.FlowReady context.scalarNames context.declarationCount scan.facts

theorem invalidBody_flowReady {context scan} (ready : BodyScan.FlowReady context scan) :
    (invalidBody scan).FlowReady context := ready.withPath _

theorem bodyToken_flowReady {context scan} (ready : BodyScan.FlowReady context scan)
    (text : Source) (token : ShellToken) : (bodyToken text scan token).FlowReady context := ready

theorem bodyTokens_flowReady {context scan} (ready : BodyScan.FlowReady context scan)
    (text : Source) (tokens : List ShellToken) : (bodyTokens text scan tokens).FlowReady context := by
  simpa only [BodyScan.FlowReady, bodyTokens_facts] using ready

private theorem true_of_not_neg {value : Bool} (known : ¬(!value) = true) : value = true := by
  cases value <;> simp_all

theorem scalarAssignment_flowReady (text : Source) (context : ParseContext) (scan : BodyScan)
    (_base : ScalarMetadata.ContextReady context.scalarNames context.declarationCount context.elaborating)
    (ready : scan.FlowReady context) : (scalarAssignmentBody text context scan).FlowReady context := by
  unfold scalarAssignmentBody
  dsimp only
  split
  · exact invalidBody_flowReady ready
  · rename_i good
    have nonzero : scalarTarget text context scan.position ≠ 0 := fun bad => good (Or.inl bad)
    have targetBound : scalarTarget text context scan.position ≤ context.scalarNames.length :=
      ScalarExpression.lookup_bound ..
    have mutable : (ScalarExpression.binding context.scalarNames (scalarTarget text context scan.position)).mutable = true :=
      true_of_not_neg (fun bad => good (Or.inr (Or.inl bad)))
    have nonempty : (readScalarInFlow text context (scalarAssignmentStart text scan) scan.facts).bounds.isEmpty = false :=
      Bool.eq_false_iff.mpr (fun bad => good (Or.inr (Or.inr (Or.inr (Or.inl bad)))))
    have low : ¬ (readScalarInFlow text context (scalarAssignmentStart text scan) scan.facts).bounds.lower <
        (ScalarExpression.binding context.scalarNames (scalarTarget text context scan.position)).declaredBounds.lower :=
      fun bad => good (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl bad)))))
    have high : ¬ (readScalarInFlow text context (scalarAssignmentStart text scan) scan.facts).bounds.upper >
        (ScalarExpression.binding context.scalarNames (scalarTarget text context scan.position)).declaredBounds.upper :=
      fun bad => good (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr bad)))))
    have positive : (readScalarInFlow text context (scalarAssignmentStart text scan) scan.facts).after ≠ 0 := by
      intro zero
      exact good (Or.inr (Or.inr (Or.inl (by omega))))
    obtain ⟨expression, parsed⟩ := ScalarExpression.read_sound
      (Compose.Expressions.model_fixed_valid text _ ":=" false (Compose.Expressions.model_name_valid text _)) positive
    apply ScalarMetadata.FlowReady.replace ready _ _ (Nat.pos_of_ne_zero nonzero) targetBound mutable
      (Integer.Expr.infer_bounded parsed.inferred) nonempty
    intro value within
    rcases within with ⟨lo, hi⟩
    dsimp only [scalarAssignmentStart, readScalarInFlow] at low high
    constructor <;> omega

theorem basicRaw_flowReady (text : Source) (context : ParseContext) (scan : BodyScan)
    (base : ScalarMetadata.ContextReady context.scalarNames context.declarationCount context.elaborating)
    (ready : scan.FlowReady context) : (basicRaw text context scan).FlowReady context := by
  unfold basicRaw
  cases basicKind text context scan with
  | null => exact ready
  | output =>
      try dsimp only
      split
      · exact invalidBody_flowReady ready
      · exact ready
  | put =>
      try dsimp only
      split
      · exact invalidBody_flowReady ready
      · exact ready
  | reject => exact ready.withPath _
  | scalarAssignment => exact scalarAssignment_flowReady text context scan base ready
  | arrayAssignment =>
      unfold arrayAssignmentBody
      dsimp only
      split
      · exact invalidBody_flowReady ready
      · exact ready
  | booleanAssignment =>
      unfold booleanAssignmentBody
      dsimp only
      split
      · exact invalidBody_flowReady ready
      · exact ready
  | assignment =>
      try dsimp only
      split
      · exact invalidBody_flowReady ready
      · exact ready

theorem basic_flowReady (text : Source) (context : ParseContext) (scan : BodyScan)
    (base : ScalarMetadata.ContextReady context.scalarNames context.declarationCount context.elaborating)
    (ready : scan.FlowReady context) : (basicBody text context scan).FlowReady context := by
  unfold basicBody
  split
  · exact invalidBody_flowReady ready
  · try dsimp only
    split
    · exact invalidBody_flowReady ready
    · exact bodyToken_flowReady (basicRaw_flowReady text context scan base ready) text _

theorem branchStart_flowReady (text : Source) (context : ParseContext) (scan : BodyScan) (keyword : String)
    (base : ScalarMetadata.ContextReady context.scalarNames context.declarationCount context.elaborating)
    (ready : scan.FlowReady context) :
    (branchStart text context scan keyword).1.FlowReady context ∧
      ScalarMetadata.FlowReady context.scalarNames context.declarationCount (branchStart text context scan keyword).2 := by
  exact condition_flowReady text context (bodyToken text scan (.word keyword)).position scan.facts base ready

end Silver.Predicate
