"""Rerun the corrected fixture with unchanged producer policy and CPU affinity."""
import os
import unittest
CPUS = sorted(os.sched_getaffinity(0))[:2]
os.sched_setaffinity(0, CPUS)
print("Focused test worker CPU affinity:", sorted(os.sched_getaffinity(0)), flush=True)
from tests import test_boolean_objects
def load_tests(loader, existing, pattern):
    return unittest.TestSuite([test_boolean_objects.BooleanObjectTests(
        "test_native_boolean_hiding_and_loop_scope_restoration")])
