from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
mode,case=sys.argv[1:]
repo=Path('/home/canto/src/github.com/berkeleynerd/silver')
cmd=['python3',str(repo/'scripts/dev.py'),'tool','--task','#119','--jobs','1','--reason','Isolated current-library fixed-dependency '+mode+' '+case+'; backend disabled, no proof or admission claim','--workspace',str(root)]
inputs=[root/'managed.py',root/'run_phase1.py',root/'plan.json',root/'library-prerequisites.json',root/'naming.adc',root/'library-object-paths.txt',root/'library-options-phase1.json',*sorted((root/'library-src').glob('*'))]
if case!='library':
    inputs += [root/case/n for n in ('main.adb','invocation-phase1.json','options-phase1.json','object-paths.txt')]
if mode=='probe':
    inputs += [root/'raw_snapshot_v2.py',*[root/case/n for n in ('probe.py','probe.gdb','invocation.json','options.json')],*sorted((root/'library-obj').glob('*.ali')),*sorted((root/case/'obj').glob('*.ali'))]
inputs += [repo/'.tools/linux-x86_64/alire/cache/releases/gnatprove_16.1.0_82528bef/libexec/spark/bin/gnat2why']
for p in inputs:cmd += ['--input',str(p)]
cmd += ['--','python3']+([str(root/'run_phase1.py'),case] if mode=='phase1' else [str(root/case/'probe.py')])
raise SystemExit(subprocess.call(cmd,cwd=repo))
