# Proposed fixed API dependency measurements

Prepared only; no subprocess/toolchain run by this lane.

The six library files are copied byte-for-byte from the current shared checkout and hash-checked equal to the integration checkout. They are **not** the old dynamic-256 fixture libraries, which lack Put and the newer Input_Is_Valid postcondition. Existing pinned producer, target/runtime environment, proof options, no-inlining/no-unrolling settings and false-backend fallback are preserved.

Execution order for the root's managed runner, once the source frontier is accepted:

1. Run the four structured commands in library-prerequisites.json in order; retain logs/status. They produce globals ALIs only.
2. For each case, run invocation-phase1.json; retain logs/status.
3. Run its probe.py under the managed workspace/worker lease. The successful reader is copied unchanged from the Standard experiment. It stops before the backend or before table Free. A before_backend stop is a complete sole-Main VC boundary, not proof completion. No solver may be launched.
4. Compare every before/after Standard state with the retained fixed baseline. Preserve mismatches rather than normalizing them away.
5. Retain complete graphs/counters. The intended envelope sums post-Standard deltas; witness Main work and overlapping dependencies are intentionally overcounted. Imported Close_Theory growth remains separately charged by the global module/close allowance.

The query/reject witnesses isolate a direct API root and do not claim membership in the current whole-program argument-shell grammar. They use existing expression/statement forms and the same SPARK compilation mode. First_Or_Default's specification itself marks Input_Is_Valid; that overlap is expected and conservatively paid twice if separate closures are summed.

No all-order or complete-capacity claim is made by preparing these inputs. Library bodies are not measured by the five Main probes; their phase1 run is a prerequisite, not a body Why-allocation measurement.
