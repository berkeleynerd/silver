from pathlib import Path
import json,os,subprocess,sys,time
root=Path(__file__).resolve().parent
case=sys.argv[1]
plans=json.loads((root/'library-prerequisites.json').read_text()) if case=='library' else [json.loads((root/case/'invocation-phase1.json').read_text())]
rows=[]
for i,p in enumerate(plans):
    dest=root/'library-obj' if case=='library' else root/case
    log=dest/(p.get('name','main.adb')+'.phase1.log')
    if log.exists(): raise SystemExit('Refusing to overwrite retained phase1 log: '+str(log))
    env=dict(os.environ); env.update(p['environment'])
    start=time.monotonic()
    with log.open('w') as output:
        proc=subprocess.run(p['argv'],cwd=p['cwd'],env=env,stdout=output,stderr=subprocess.STDOUT,timeout=45)
    row=dict(name=p.get('name','main.adb'),argv=p['argv'],cwd=p['cwd'],exit=proc.returncode,seconds=time.monotonic()-start,log=str(log))
    rows.append(row)
    (dest/'phase1-result.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if proc.returncode: print(log.read_text()); raise SystemExit(proc.returncode)
