procedure Main is
pragma SPARK_Mode(On);
I:Integer range -1..2:=0;A:array(0..1)of Boolean:=(True,False);
begin
for J in -1..2 loop I:=J;if I>=0 and then I<=1 then A(I):=not A(I);end if;end loop;
end Main;
