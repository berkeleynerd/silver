procedure Main is
pragma SPARK_Mode(On);
N:Integer range 0..1:=0;
A:array(0..1)of Boolean:=(N=0,N=1);
Flag:Boolean:=False;
begin
for I in 0..1 loop
 Flag:=(A(I)=False) xor (A((1 - I))/=True);
 if Flag=A(I) then A(I):=False;else A((1 - I)):=True;end if;
end loop;
end Main;
