procedure Main is
pragma SPARK_Mode(On);
S:String:="ab";C:Character:=S(1);A:array(0..1)of Boolean:=(S="ab",S(1)=C);B:constant array(1..2)of Boolean:=(A(0),A(1));Flag:Boolean:=B(1) and B(2);
begin
S:="cd";C:=S(2);A(0):=(C='d') and then (S(1)='c');if Flag then A(1):=False;end if;
end Main;
