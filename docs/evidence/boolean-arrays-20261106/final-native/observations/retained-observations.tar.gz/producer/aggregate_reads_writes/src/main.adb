procedure Main is
pragma SPARK_Mode(On);
A:array(0..1)of Boolean:=(True,False);B:constant array(-1..-1)of Boolean:=(-1=>A(0));Flag:Boolean:=B(-1);
begin
A(1):=Flag;A(0):=not A(1);for I in 0..1 loop A(I):=not A(I);end loop;
end Main;
