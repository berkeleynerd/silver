#!/usr/bin/env python3
"""Check, proof-compile, audit and execute the two new manifest samples."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

base=Path(__file__).resolve().parent
root=base.parents[1]
sys.path.insert(0,str(root))
from scripts.check_evidence import audit_reports
from tests.test_samples import SupportedSampleTests

binary=root/'.silver/linux-x86_64/compiler/bin/silver'
manifest=json.loads((root/'samples/manifest.json').read_text())
names={'rosetta_sieve_of_eratosthenes.adb','rosetta_elementary_cellular_automaton.adb'}
cases=[case for case in manifest['samples'] if case['source'] in names]
assert len(cases)==2
policy=SupportedSampleTests()
records=[]
for case in cases:
 source=root/'samples'/case['source']
 source_bytes=source.read_bytes()
 destination=base/'sample-observations'/source.stem
 destination.mkdir(parents=True,exist_ok=True)
 record={'source':str(source),'source_bytes':len(source_bytes),
         'source_sha256':hashlib.sha256(source_bytes).hexdigest(),
         'compiler_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'phases':[]}
 for action in ('check','compile'):
  started=time.monotonic()
  result=subprocess.run([str(binary),action,str(source)],cwd=root,capture_output=True,text=True,timeout=240)
  (destination/(action+'.log')).write_text(result.stdout+result.stderr)
  record['phases'].append({'action':action,'returncode':result.returncode,'duration_seconds':time.monotonic()-started})
  print(json.dumps({'sample':case['source'],**record['phases'][-1]}),flush=True)
  assert result.returncode==0,result.stdout+result.stderr
 match=re.search(r'^Executable: (.+)$',result.stdout,re.MULTILINE)
 assert match,result.stdout
 executable=Path(match.group(1))
 if not executable.is_absolute():executable=root/executable
 workspace=executable.parent.parent
 snapshots=[p for p in workspace.rglob('*.adb') if p.read_bytes()==source_bytes]
 assert len(snapshots)==1,snapshots
 reports=list(workspace.rglob('gnatprove.sarif'))
 assert len(reports)==1,reports
 policy.assert_application_proof_policy(reports[0],output=True)
 record['audit']=audit_reports(reports[0].parent,{snapshots[0].stem,'silver_io','silver_output_libc','silver_arguments','silver_runtime'},
    {'silver_output_libc','silver_runtime'},application_kind='assigned',indexed_main=True)
 execution=subprocess.run([str(executable)],cwd=root,capture_output=True,timeout=10)
 (destination/'stdout').write_bytes(execution.stdout)
 (destination/'stderr').write_bytes(execution.stderr)
 expected=case['expected']
 assert (execution.returncode,execution.stdout,execution.stderr)==(expected['exit_status'],expected['stdout'].encode(),expected['stderr'].encode())
 record['execution']={'returncode':execution.returncode,'stdout_bytes':len(execution.stdout),'stderr_bytes':len(execution.stderr)}
 record['executable_sha256']=hashlib.sha256(executable.read_bytes()).hexdigest()
 record['workspace']=str(workspace)
 shutil.copytree(workspace,destination/'workspace',dirs_exist_ok=True)
 (destination/'observation.json').write_text(json.dumps(record,indent=2)+'\n')
 records.append(record)
 print(json.dumps({'sample':case['source'],'audit':record['audit'],'execution':record['execution']}),flush=True)
 shutil.rmtree(workspace)
(base/'sample-observations.json').write_text(json.dumps(records,indent=2)+'\n')
