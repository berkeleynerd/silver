#!/usr/bin/env python3
"""Run the four bounded discovery probes through the managed native tool route."""
import json
from pathlib import Path
import subprocess
import sys


root = Path(__file__).resolve().parents[2]
fixtures = Path(__file__).resolve().parent
inventory = json.loads((fixtures / "inventory.json").read_text())
cache = fixtures / "cache"
cache.mkdir(exist_ok=True)
results = []
for case in inventory["cases"]:
    fixture = fixtures / case
    command = [
        sys.executable, "scripts/dev.py", "tool", "--task", "#297 producer probes",
        "--jobs", "4", "--reason",
        "Bounded Boolean-array producer corroboration; serialized within four native workers",
        "--workspace", str(fixture / "obj"),
        "--input", str(fixture / "probe.gpr"),
        "--input", str(fixture / "src"),
        "--", "gnatprove", "-P", str(fixture / "probe.gpr"),
        "--subdirs=explore/boolean-arrays", "--mode=all", "--report=all",
        "--warnings=continue", "--checks-as-errors=on", "--level=2", "--prover=cvc5,z3,altergo",
        "--timeout=30", "--no-loop-unrolling", f"--memcached-server=file:{cache}",
    ]
    completed = subprocess.run(command, cwd=root, text=True, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT)
    (fixture / "managed.log").write_text(completed.stdout)
    print(completed.stdout, flush=True)
    results.append({"case": case, "returncode": completed.returncode, "command": command})
    (fixtures / "run-results.json").write_text(json.dumps(results, indent=2) + "\n")
sys.exit(1 if any(result["returncode"] for result in results) else 0)
