#!/usr/bin/env python3
"""Inventory raw probe reports without turning samples into universal evidence."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re


fixtures = Path(__file__).resolve().parent
inventory = json.loads((fixtures / "inventory.json").read_text())


def identity(path):
    return {"path": str(path), "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


observations = []
for case in inventory["cases"]:
    fixture = fixtures / case
    reports = fixture / "obj/explore/boolean-arrays/gnatprove"
    spark = reports / "main.spark"
    data = json.loads(spark.read_text())
    records = data.get("proof", []) + data.get("flow", [])
    log = (fixture / "managed.log").read_text()
    match = re.search(r"Managed run: (\S+) \(([^\n]+)\)", log)
    if match is None:
        raise RuntimeError(f"Missing managed run identity: {case}")
    events = [json.loads(line) for line in (Path(match[2]) / "events.jsonl").read_text().splitlines()]
    start = next(event for event in events if event["event"] == "started")
    finish = next(event for event in reversed(events) if event["event"] == "finished")
    observations.append({
        "case": case, "run_id": match[1], "host": start["host"],
        "workers": start["workers"], "outcome": finish["outcome"],
        "duration_seconds": finish["duration_seconds"],
        "inputs": [identity(fixture / "probe.gpr"), identity(fixture / "src/main.adb")],
        "reports": [identity(path) for path in sorted(reports.glob("*"))
                    if path.is_file() and path.suffix in (".spark", ".sarif")],
        "proof_count": len(data.get("proof", [])), "flow_count": len(data.get("flow", [])),
        "rules": dict(sorted(Counter(record.get("rule", "") for record in records).items())),
        "severities": dict(sorted(Counter(record.get("severity", "") for record in records).items())),
        "diagnostics": [record for record in records if record.get("severity") != "info"],
        "entities": data.get("entities", []),
    })
result = {"purpose": inventory["purpose"], "observations": observations}
target = fixtures / "observations.json"
target.write_text(json.dumps(result, indent=2) + "\n")
print(target)
