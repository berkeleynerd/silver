#!/usr/bin/env python3
"""Collect retained bounded evidence without presenting it as a full audit."""
import json
from pathlib import Path

base=Path(__file__).resolve().parent
root=base.parents[1]
registry=Path('/home/canto/src/github.com/berkeleynerd/silver/.git/silver-runs/linux-x86_64/d140f139bb2e1ef1/runs')
checks=[
 ('Boolean_Array_After', '20261106T193001-49b33d4345e5',21),
 ('Lemma_Parser_State_Equality','20261106T193211-8660851a1154',2),
 ('Array_Declaration_At actual post2100','20261106T193707-8db6f1a92157',4),
 ('Boolean_Initializer_After','20261106T193934-65a47892c441',11),
 ('Boolean_Array_Values_At','20261106T194221-0a4c2a4941b8',57),
 ('repaired incremental native build','20261106T200556-dc4f1e19f053',None),
 ('seven admission methods and native catalogue','20261106T200636-c636c88f4e9f',None),
 ('parent frame unit compile','20261106T200816-9d01da6c8ea6',None),
]
records=[]
for label,id,count in checks:
 events=[json.loads(line) for line in (registry/id/'events.jsonl').read_text().splitlines()]
 start=next(e for e in events if e['event']=='started')
 finish=next(e for e in reversed(events) if e['event']=='finished')
 records.append({'label':label,'run_id':id,'native_checks':count,'outcome':finish['outcome'],
   'duration_seconds':finish['duration_seconds'],'workers':start['workers'],
   'events':str(registry/id/'events.jsonl'),'native_log':str(registry/id/'native.log')})
full_id='20261106T201636-d09ed16a345c'
full_events=[json.loads(line) for line in (registry/full_id/'events.jsonl').read_text().splitlines()]
full_finish=next((event for event in reversed(full_events) if event['event']=='finished'),None)
full_native={'run_id':full_id,'outcome':full_finish['outcome'] if full_finish else 'still_running',
 'complete_success':bool(full_finish and full_finish['outcome']=='success'),
 'confirmed_failed_completed_check':json.loads((base/'declaration-session-diagnosis/exact-check.json').read_text()),
 'scope':'Frozen25e6-native-equivalent source. The2178assertion is not established by the successful focused2100post check. Full run remains separate from unvalidated ghost-only candidate and final integrated checkpoint.'}
result={'scope':'Bounded native helper/build/admission/producer/layout evidence. Complete compiler GNATprove audit, final integrated regressions, Lean/source/axiom assurance and independent final review remain root-owned obligations.',
 'selected_model_effort':'GPT-6.1 Sol / Extra High per original assignment; runtime confirmation and token/cost evidence unavailable',
 'focused_evidence_native_equivalent':'25e6fe06a3','frozen_full_audit_validation_head':'a224e481b209df375f21a137530ffaa8fe6c964d',
 'current_validation_head':'2d3facce0ce5b8ad32128b6b8bb702a5f6c375c9',
 'failed_fieldwise_candidate':{'head':'d05d2bb3794b179d0317ad82cc9fbec4da1623a7',
   'output_source_sha256':'43f9efc9f9010366f37e3fd8ae782cf4b0ed329c98bcf3ab1d67fc3ce981ed36',
   'scope':'Failed focused required Position equality; later assertion/bridge pass assumes failed assertion. Not integrated.',
   'evidence':json.loads((base/'fieldwise-focus-failure.json').read_text())},
 'unvalidated_inline_candidate':{'head':'af55339df701d0857a7b074f8af4e0acfac7c880',
   'output_source_sha256':'c58386025a9a80771bdafc6a898cc21970d21fe888ddbc38d777c0eec15c22ef',
   'scope':'Only Inline_For_Proof annotation on existing expression model; all bodies/contracts/equalities unchanged. Original assertion/post, model safety and whole-routine checks pending.'},
 'frozen_full_native_audit':full_native,
 'native_identity':json.loads((base/'native-source-identity.json').read_text()),
 'checks':records,'producer_probes':json.loads((base/'observations.json').read_text()),
 'layout_comparison':json.loads((base/'layout-comparison.json').read_text()),
 'test_snapshot':json.loads((base/'test-snapshot.json').read_text()),
 'application_window_applicability':json.loads((base/'application-window-applicability.json').read_text()),
 'application_window':{name:json.loads((base/name).read_text()) for name in ['sample-observations.json','stack-observations.json'] if (base/name).exists()},
 'prior_runs':[
  {'run_id':'20261106T174859-3c4e45f871bc','scope':'old frozen4091a00a39 retained incremental proof','outcome':'interrupted by parent instruction after~6014s during Declaration_At; preserved sessions/cache and two failed completed helpers, both subsequently repaired and checked'},
  {'run_id':'20261106T193310-5815fc79b0fe','outcome':'interrupted after103s; line-only filter traversed unrelated helpers, no proof failure observed'},
  {'run_id':'20261106T193504-5749d3bf8b59','outcome':'success3checks at2103, model-call preconditions only; not declaration-post evidence'}]}
(base/'native-evidence-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(base/'native-evidence-summary.json')
