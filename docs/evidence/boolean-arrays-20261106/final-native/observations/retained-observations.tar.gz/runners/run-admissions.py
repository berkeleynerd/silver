#!/usr/bin/env python3
"""Run frozen parent Boolean-array admission tests against this validation binary."""
import hashlib
import importlib.util
from pathlib import Path
import sys
import json
import shutil
import subprocess
import tempfile
import unittest
base=Path(__file__).resolve().parent
root=base.parents[1]
sys.path.insert(0,str(root))
tempfile.tempdir=str(base/'admission-work')
source=base/'test_boolean_arrays.snapshot.py'
print('Frozen parent test SHA256:',hashlib.sha256(source.read_bytes()).hexdigest(),flush=True)
spec=importlib.util.spec_from_file_location('boolean_array_admission_snapshot',source)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
mode=sys.argv[1] if len(sys.argv)>1 else 'admission'
if mode not in ('admission','native'):raise ValueError(mode)
if mode=='admission':
 result=subprocess.run([str(root/'.silver/linux-x86_64/compiler/bin/silver'),'catalogue'],cwd=root,capture_output=True,text=True,check=True)
 actual=json.loads(result.stdout)
 assert actual==json.loads((base/'catalogue.snapshot.json').read_text()),'native/generated catalogue mismatch'
 print('Native catalogue matches frozen parent generated catalogue:',len(actual['constructs']),'constructs',flush=True)
if mode=='native':
 original_compile=module.BooleanArrayTests.compile
 def retained_compile(self, source, kind):
  executable,data=original_compile(self,source,kind)
  workspace=executable.parent.parent
  destination=base/'native-observations'/self._testMethodName
  def retain():
   shutil.copytree(workspace,destination,dirs_exist_ok=True)
   record={'kind':kind,'source_sha256':hashlib.sha256(source).hexdigest(),
           'compiler_sha256':hashlib.sha256((root/'.silver/linux-x86_64/compiler/bin/silver').read_bytes()).hexdigest(),
           'executable_sha256':hashlib.sha256(executable.read_bytes()).hexdigest(),
           'workspace':str(workspace),'retained_workspace':str(destination)}
   (destination/'observation.json').write_text(json.dumps(record,indent=2)+'\n')
   print(json.dumps(record),flush=True)
  self.addCleanup(retain)
  return executable,data
 module.BooleanArrayTests.compile=retained_compile
names=[name for name in unittest.defaultTestLoader.getTestCaseNames(module.BooleanArrayTests) if name.startswith('test_native_')==(mode=='native')]
suite=unittest.TestSuite(module.BooleanArrayTests(name) for name in names)
result=unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(not result.wasSuccessful())
