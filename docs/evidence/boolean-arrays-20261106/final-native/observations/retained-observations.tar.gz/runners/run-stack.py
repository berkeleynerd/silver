#!/usr/bin/env python3
"""Refresh three existing concrete 8 MiB observations, without a universal claim."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

base=Path(__file__).resolve().parent
root=base.parents[1]
sys.path.insert(0,str(root))
from scripts.check_evidence import audit_reports
from tests.test_samples import SupportedSampleTests
binary=root/'.silver/linux-x86_64/compiler/bin/silver'
policy=SupportedSampleTests()
results=[]
for name in ('counted','foreach-singleton','counted-slice'):
 source=base/'stack-fixtures'/(name+'.adb')
 destination=base/'stack-observations'/name
 destination.mkdir(parents=True,exist_ok=True)
 process=subprocess.run([sys.executable,str(base/'stack-observer.snapshot.py'),str(binary),str(source),str(destination)],cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=240)
 (destination/'managed-observation.log').write_text(process.stdout)
 print(process.stdout,flush=True)
 assert process.returncode==0,process.stdout
 record=json.loads((destination/'observation.json').read_text())
 workspace=Path(record['workspace'])
 assert (workspace/'main.adb').read_bytes()==source.read_bytes()
 reports=list(workspace.rglob('gnatprove.sarif'))
 assert len(reports)==1,reports
 policy.assert_application_proof_policy(reports[0],output=True)
 record['audit']=audit_reports(reports[0].parent,{'main','silver_io','silver_output_libc','silver_arguments','silver_runtime'},
    {'silver_output_libc','silver_runtime'},application_kind='static',indexed_main=True)
 expected=b'8192\nx\n' if name=='counted-slice' else b'8192\n'
 assert (destination/'execute.log').read_bytes()==expected
 record['expected_execute_log_sha256']=hashlib.sha256(expected).hexdigest()
 shutil.copytree(workspace,destination/'workspace',dirs_exist_ok=True)
 record['retained_workspace']=str(destination/'workspace')
 (destination/'observation.json').write_text(json.dumps(record,indent=2)+'\n')
 results.append(record)
 print(json.dumps({'case':name,'audit':record['audit']}),flush=True)
 shutil.rmtree(workspace)
(base/'stack-observations.json').write_text(json.dumps(results,indent=2)+'\n')
