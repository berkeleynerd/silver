set pagination off
set python print-stack full
set confirm off
set auto-load off
set debuginfod enabled off
set startup-with-shell off
set disable-randomization off
unset environment LD_LIBRARY_PATH
set language c
python
import gdb,json
exec(open('/tmp/silver-producer-numeric-fields-20261018/numeric_reader.py').read())
snapshots=[]
class CounterBreakpoint(gdb.Breakpoint):
    def __init__(self,spec,phase,halt):
        super().__init__(spec,internal=True)
        self.phase,self.halt=phase,halt
    def stop(self):
        row=snapshot(self.phase)
        from pathlib import Path
        Path('/tmp/silver-producer-numeric-fields-20261018/put_line','numeric-'+self.phase+'.json').write_text(json.dumps(row,sort_keys=True)+'\n')
        brief={k:row[k] for k in ('phase','nodes','maximum_decimal_image_length','maximum_digit_length')}
        brief.update(numeric_fields=len(row['numeric_fields']),uints=len(row['uints']),ureals=len(row['ureals']))
        snapshots.append(brief)
        print('NUMERIC_SNAPSHOT '+json.dumps(brief,sort_keys=True))
        return self.halt
CounterBreakpoint('gnat2why__driver__translate_standard_package','before_standard',False)
CounterBreakpoint('gnat2why__driver__translate_cunit','after_standard',False)
CounterBreakpoint('why__gen__names__free','before_symbol_free',True)
class BackendGuard(gdb.Breakpoint):
    def __init__(self):
        super().__init__('gnat2why__driver__run_gnatwhy3',internal=True)
        self.count=0
    def stop(self):
        self.count+=1
        print('FALSE_BACKEND_CALL '+str(self.count))
        return self.count>=63
BackendGuard()
class CollectionGuard(gdb.Breakpoint):
    def stop(self):
        print('UNEXPECTED_RESULT_COLLECTION')
        return True
CollectionGuard('gnat2why__driver__collect_one_result',internal=True)
end
run
python
print('NUMERIC_FINAL '+json.dumps(snapshots,sort_keys=True))
end
quit
