set pagination off
set auto-load off
set debuginfod enabled off
set language c
ptype /o uintp__uint_entry
ptype /o urealp__ureal_entry
info variables uintp__uints__
info variables uintp__udigits__
info variables urealp__ureals__
python
import gdb,json
nt=gdb.lookup_type('why__atree__why_node')
print('WHY_NUMERIC_LAYOUT '+json.dumps([[f.name,f.bitpos//8,f.type.sizeof,str(f.type)] for f in nt.fields() if ('uint' in str(f.type) or 'ureal' in str(f.type))],sort_keys=True))
end
quit
