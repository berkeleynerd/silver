"""Read stopped-inferior memory only: Why numeric fields and their raw tables."""
import gdb,json,re,sys
sys.set_int_max_str_digits(0)
UINT_LOW=-2100000000
BASE=32768
BIAS=UINT_LOW+BASE
DIRECT_FIRST=UINT_LOW+1
DIRECT_LAST=BIAS+(BASE-1)**2

def fields(name):
    return {f.name:(f.bitpos//8,f.type.sizeof) for f in gdb.lookup_type(name).strip_typedefs().fields()}

def numeric_layout():
    layout={}
    for name in ('uintp__uint_entry','urealp__ureal_entry','why__atree__node_tables__vector','why__atree__node_tables__elements_type'):
        layout[name]=fields(name)
    assert layout['uintp__uint_entry']=={'length':(0,4),'loc':(4,4)}
    assert layout['urealp__ureal_entry']=={'num':(0,4),'den':(4,4),'rbase':(8,4),'negative':(12,1)}
    assert layout['why__atree__node_tables__vector']['elements']==(8,8)
    assert layout['why__atree__node_tables__vector']['last']==(16,4)
    assert layout['why__atree__node_tables__elements_type']['ea'][0]==8
    nt=gdb.lookup_type('why__atree__why_node')
    kf=next(f for f in nt.fields() if f.name=='kind')
    assert (kf.bitpos,kf.type.sizeof)==(0,1)
    layout['kinds']={f.enumval:f.name for f in kf.type.fields()}
    nums={}
    for f in nt.fields():
        if str(f.type) not in ('uintp__uint','urealp__ureal'):continue
        m=re.fullmatch(r'k(\d+)_(.*)',f.name)
        assert m and f.bitpos%8==0 and f.type.sizeof==4
        nums.setdefault(int(m.group(1)),[]).append((f.name,f.bitpos//8,str(f.type)))
    assert sum(map(len,nums.values()))==8
    layout['numeric_fields']=nums
    for prefix,expected_first,expected_size in [('uintp__uints',-699999999,8),('uintp__udigits',0,4),('urealp__ureals',-599999998,16)]:
        pt=gdb.parse_and_eval('&'+prefix+'__table').type.target().strip_typedefs()
        low,high=pt.target().range()
        assert pt.sizeof==8 and low==expected_first and pt.target().target().sizeof==expected_size
        layout[prefix]={'first':low,'last_type':high,'element_size':expected_size}
    return layout

def snapshot(phase):
    layout=numeric_layout();inf=gdb.selected_inferior()
    def raw(addr,n):return bytes(inf.read_memory(addr,n))
    def read(addr,n,signed=False):return int.from_bytes(raw(addr,n),'little',signed=signed)
    def sym(name):return int(gdb.parse_and_eval('&'+name))
    tables={}
    for prefix in ('uintp__uints','uintp__udigits','urealp__ureals'):
        spec=layout[prefix]
        ptr=read(sym(prefix+'__table'),8)
        first=spec['first'];last=read(sym(prefix+'__last_val'),4,True)
        assert first-1<=last<first+2000000,(prefix,first,last)
        tables[prefix]={'address':ptr,'first':first,'last':last,'length':read(sym(prefix+'__length'),4,True),'element_size':spec['element_size']}
    uints={};ureals={}
    def uint(code):
        if code in uints:return
        if DIRECT_FIRST<=code<=DIRECT_LAST:
            value=code-BIAS
            row={'code':code,'representation':'direct','value':str(value)}
        else:
            assert code!=UINT_LOW,('No_Uint',code)
            t=tables['uintp__uints'];assert t['first']<=code<=t['last'],code
            addr=t['address']+(code-t['first'])*8
            entry=raw(addr,8);n=read(addr,4,True);loc=read(addr+4,4,True)
            dt=tables['uintp__udigits'];assert 1<=n<=2000000 and 0<=loc<=loc+n-1<=dt['last']
            digits_raw=raw(dt['address']+loc*4,n*4)
            digits=[int.from_bytes(digits_raw[i*4:i*4+4],'little',signed=True) for i in range(n)]
            assert 0<abs(digits[0])<BASE and all(0<=d<BASE for d in digits[1:]),digits
            value=abs(digits[0])
            for d in digits[1:]:value=value*BASE+d
            if digits[0]<0:value=-value
            row={'code':code,'representation':'table','length':n,'loc':loc,'entry_hex':entry.hex(),'digits_hex':digits_raw.hex(),'digits':digits,'value':str(value)}
        row['decimal_image_length']=len(row['value'])
        uints[code]=row
    def ureal(code):
        if code in ureals:return
        t=tables['urealp__ureals'];assert t['first']<=code<=t['last'],code
        addr=t['address']+(code-t['first'])*16
        row={'code':code,'entry_hex':raw(addr,16).hex(),'num':read(addr,4,True),'den':read(addr+4,4,True),'rbase':read(addr+8,4,True),'negative':read(addr+12,1)}
        assert row['negative'] in (0,1) and row['rbase']>=0
        uint(row['num']);uint(row['den']);ureals[code]=row
    nt=sym('why__atree__node_table');np=read(nt+8,8);last=read(nt+16,4)
    assert last<2000000
    rows=[]
    for i in range(last+1):
        addr=read(np+8+i*8,8);assert addr
        kind=read(addr,1)
        for name,off,typ in layout['numeric_fields'].get(kind,[]):
            code=read(addr+off,4,True)
            rows.append({'node':i,'kind':layout['kinds'][kind],'field':name,'type':typ,'code':code})
            (uint if typ=='uintp__uint' else ureal)(code)
    result={'phase':phase,'nodes':last,'numeric_fields':rows,'uints':uints,'ureals':ureals,'tables':tables,'layout':layout,'method':'DWARF offsets and raw read_memory only; no inferior calls'}
    result['maximum_decimal_image_length']=max((x['decimal_image_length'] for x in uints.values()),default=0)
    result['maximum_digit_length']=max((x.get('length',0) for x in uints.values()),default=0)
    return result
