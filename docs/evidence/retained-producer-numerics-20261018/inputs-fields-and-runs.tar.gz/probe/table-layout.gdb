set pagination off
set auto-load off
set debuginfod enabled off
set language c
info variables uints
info variables udigits
info variables ureals
info types uints
info types ureals
info address uintp__uints__table
info address uintp__uints__p
info address uintp__udigits__table
info address uintp__udigits__p
info address urealp__ureals__table
info address urealp__ureals__p
quit
