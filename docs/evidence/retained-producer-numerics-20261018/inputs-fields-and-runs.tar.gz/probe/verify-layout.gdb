set pagination off
set auto-load off
set debuginfod enabled off
set language c
python
import gdb,json
layout={}
for t in ['uintp__uint_entry','urealp__ureal_entry','why__atree__node_tables__vector','why__atree__node_tables__elements_type']:
    layout[t]=[[f.name,f.bitpos//8,f.type.sizeof,str(f.type)] for f in gdb.lookup_type(t).strip_typedefs().fields()]
for p in ['uintp__uints','uintp__udigits','urealp__ureals']:
    pt=gdb.parse_and_eval('&'+p+'__table').type.target().strip_typedefs()
    layout[p]={'pointer_size':pt.sizeof,'target':str(pt.target()),'range':pt.target().range(),'element':str(pt.target().target()),'element_size':pt.target().target().sizeof}
    for v in ['last_val','min','max','length']:
        q=gdb.parse_and_eval('&'+p+'__'+v)
        layout[p][v]=str(q.type)
print('VERIFIED_NUMERIC_LAYOUT '+json.dumps(layout,sort_keys=True))
end
quit
