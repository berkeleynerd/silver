# Source terminal handoff — 2026-11-13

Complete source assurance is **outstanding**. The authorized complete run failed a Lean module with exit 137 and was then controlled-stopped for host memory pressure. No generated-candidate integration or dependent regression suite may follow this checkpoint.

## Scope and identities

- Source worktree: `tmp/scalar-procedures-source-semantic-370`, HEAD `623a3ce1d41e48e0f3340d3deb6dc968b550fd94`.
- Native parser SHA-256: `619f4fb8e2b0f318dac7c6278d5f644198816ce7733959ed71ca03917546b2b8`.
- Managed start: 1,104 governed input files, 997 project modules and 40 generated candidates. Exact input/tool identities are retained in the managed events and shared input packet; terminal source/primary comparisons are in `resource-failed-complete-152103/terminal-verification.json`.
- Platform: Linux x86_64, Lean 4.34.1. Selected routine role: GPT-6.1 Sol High; live model/effort and cost were not independently exposed. Harness goal read as null; CLI memory was not updated.
- No handwritten proof, source, tooling, test, root-document, GitHub or generated-candidate edits/commits were made in this role. The five parent-owned dirty files remain untouched. All cache objects were preserved; no clean, replay, cache deletion, domain weakening or retry occurred.

## Independently successful aggregate

`20261113T122134-87078e539c6a`, original exec 78804, actually exited 0; retention exec 41620 actually exited 0. The target was `Silver.OutputBodyCertificate`, with automatic 8 Lake workers and 22 Lean threads while native used 14 workers. Four changed chunks passed before the aggregate. Build took 10,511.530 s; fresh audit took 48.859 s; total 10,651.965 s. The audit covered 16 imported modules and 51,101 declarations, with only `propext`, `Classical.choice` and `Quot.sound` as foundations.

`aggregate-success-122134/` retains the successful evidence, generated inputs and 144 artifact files totaling 438,406,605 bytes. Terminal verification rehashes these retained files and separately reports differences, if any, against the current workspace. Focused full-domain gates 115847 and 120538 remain retained and were accepted by the lead. These successes do not establish complete source assurance.

## Failed complete run and controlled stop

`20261113T152103-cead6d46c85e`, runner PID 139421, original exec 38029, ran with automatic 8 Lake workers / 22 Lean threads. Build started at 15:22:25 UTC. It completed 312 new module builds, including the repaired ComposeContractSourceCandidate and ComposeDeclarationSourceCandidate, before termination. Their existing cache artifacts and a hash inventory of 5,861 compiled files remain in the original workspace. They have no fresh complete module/axiom audit.

The complete log records `Silver.FunctionSourceParts.DeclarationLoopFunctionLocals` failing after 452 s with **Lean exit 137**. Source RSS had reached 55.66 GiB and available memory about 1.5 GiB. Kernel evidence records a global OOM killing a Lean process at 17:22:30 UTC, with about 13.4 GB anonymous RSS. Kernel PID 8906 cannot be directly mapped to the disappeared inner source PID 168232; this limitation is explicit. The kernel event time coincides with the module exit 137 and observed exhausted headroom.

Lake continued allocating after the failed module. The source owner urgently notified the lead, but the lead agent was completed and queued messages did not trigger a new turn. The native monitor independently confirmed critical headroom. To protect its productive run and preserve caches, the source owner sent SIGINT only to verified source process group 139414 at 17:25:17 UTC. No native process was signaled.

Original exec 38029 actually exited **130**. Managed final state is **interrupted / KeyboardInterrupt**, after the independently preserved module failure 137. Build interruption elapsed 7,375.741 s; managed duration 7,450.004 s. Monitor exec 92011 actually exited 0. Retention exec 53844 actually exited 0. This is a failed complete checkpoint followed by a controlled stop, not a successful checkpoint or merely an unexplained interruption. No complete audit ran.

`resource-failed-complete-152103/` retains exact captured input bytes, generated inputs, tool identities, logs/events, completed-module list, cache hashes and failure summary. Its `incident/` directory retains the kernel, capacity, continuous-monitor, process-scope and controlled-stop evidence with a hash manifest. Its `terminal-verification.json` verifies source process-group exit and source lease release; native continues independently under run `20261113T121730-28547dbc0d87`, original exec 43916.

## Required next work

The lead must perform an **Astra Max memory/capacity diagnosis before any further expensive source attempt**. Determine whether measured concurrent module demand alone exceeded host headroom, whether the failing module has an independent memory problem, and what current worker/thread or scheduling allocation fits the actual host and concurrent work. Use retained process/resource evidence first, then the smallest managed focused check needed to distinguish those hypotheses over the full declared domain. Preserve all successful objects and assurance obligations. Any resource reduction must be justified by the observed constraint in that run; do not launch another unchanged complete attempt blindly.

The next complete cached source/provenance checkpoint remains mandatory after the diagnosis and any necessary focused success. No candidate parity/copy/commit, integration or full regression suite was attempted. Conditional postproof integration remains closed because source complete assurance failed. The native monitor received the terminal classification and explicit source lease release. The final child result supplies the lead's handoff; queued messages alone do not resume the completed lead.
