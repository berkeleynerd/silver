# Complete native checkpoint after qualified-selector repair — 2026-11-13

Owner-authorized #370/#29/#375/#390 delivery PR #371. Native validation/monitoring only. Root owns implementation, tests, docs and GitHub. Native HEAD at launch `51371ef82f4af511a1e22f02d614081fcf44459e`; source commit `c1bbdc8` integrates reviewed `7c98a02`. Exact `src/silver_output_profile.adb` SHA-256 `619f4fb8e2b0f318dac7c6278d5f644198816ce7733959ed71ca03917546b2b8`. The proof-only changes after the native commit do not change native input bytes.

Managed run `20261113T121730-28547dbc0d87`, dev.py PID 70823, original exec session 43916. Started at 12:17:29 UTC, launcher 70822. Ordinary full/all/all, level 2, 30 seconds, CVC5/Z3/Alt-Ergo. Reserve 14 native workers beside 8 Lean workers on the 22-CPU Linux host; no cold/clean mode or cache/session removal. Exact command and actual exit will be retained by `launch.py`; monitoring retains live process counts, RSS, CPU ticks, host available RAM, fresh-report progress and input equality.

Entry evidence: whole-helper/callee/caller ghost equality gate `092540-3c74bc914df8` (17 entities, 190 proof / 33 flow); qualified-validity gate `114106-f670a38c8f83` (20 entities, 274 proof / 50 flow). Both are actual success and independently reviewed by the root. Qualified validity repair README and exact source SHA independently rechecked before launch. Auditor repair faa9f with 5 passing policy tests is root-owned evidence. These focused successes do not establish complete acceptance.

`prior-retention-check.json` reverified every original failed Nov 10 input/report copy (2595/81) and interrupted Nov 13 input/report copy (2595/77). Existing warm cache and sessions remain intact. Retained records keep their failed/interrupted classifications.

Final status: FAILED, actual exit 1 at 17:58:24 UTC; strict complete obligation and completed-provenance audits fail. Exact inputs/reports, failed assertion, retained successful checks, prior-fragment comparison, process/lease release and next work are in [HANDOFF.md](HANDOFF.md). Source complete also failed; no integration or full suite followed.

Selected routine monitoring model/effort: Sol High by parent request; actual live model/effort and token/cost telemetry not independently exposed. Native elapsed time and process evidence are measured separately. No CLI memory update, GitHub write, tracked edit, commit or test run by this thread.
