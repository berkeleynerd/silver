Adds bounded Main-local scalar procedures with explicit `in`, `out` and `in out` modes, source-written leading output initialization, positional nonaliasing calls and range-checked copy-back. The motivating sample is Return multiple values. This also fixes #29 by validating required Rosetta cached pages before replacing generated output.

**Draft: the complete native and Lean checkpoints failed; focused diagnosis is underway. Procedures are not yet claimed supported.** Implementation remains `51371ef82f`; subsequent commits are documentation/evidence only.

Latest Linux results:

- Complete native `20261113T121730-28547dbc0d87` exited 1 after 5h41m. Its 78 unit reports contain 17,729 proved proof records, one unproved array-declaration assertion, and 1,715 flow records. All three canonical solvers timed out on that assertion. Strict complete obligation and completed-provenance audits fail. New qualified-selector and procedure-update helper records passed.
- Output-source certificate `20261113T122134-87078e539c6a` passed its fresh 51,101-declaration / 16-import audit. Complete Lean `20261113T152103-cead6d46c85e` then completed 312 new module builds before `DeclarationLoopFunctionLocals` exited 137 during memory exhaustion with eight concurrent jobs. A controlled source-only stop followed; actual wrapper exit 130. No complete module/axiom audit ran. Successful objects, exact inputs and failure evidence are preserved.
- Native and source Astra Max roles now diagnose the unchanged assertion and isolated Lean module before another complete attempt. No proof-budget, contract, declared-domain or Oracle weakening is selected.
- The #390 repair retains independent review and successful full-domain native/model/source-shape focused gates, build, admission controls and compiled array/argument regression. Those results are not complete assurance. The [repair packet](docs/evidence/scalar-procedures-20261109/qualified-validity-repair-20261113/README.md) preserves exact evidence.
- No final full-suite execution has occurred. The inventory is 691 unittest IDs, including nine shared-binding methods under a second module identity. #29 and #372 retain their successful scoped implementation checks.

Remaining: resolve the focused failures; pass complete native and Lean/source/module/axiom/provenance audits; execute full regression/sample coverage; obtain final independent acceptance; promote Rosetta and reconcile delivery records. #375 and #390 remain inside this delivery. Published Rosetta support remains 83 tasks.

Owner authorization: PR #369 / `195b61a559`, explicitly resumed on 2026-11-13. Separate worca/milestone-24 streams are preserved.

Refs #370. Refs #29. Refs #372. Refs #375. Refs #390.
