# Native final-run pause handoff — 2026-11-11 03:35 UTC

Owner requested an evening pause after already running background tasks finish.
This native task is finished and stopped. No repairs, retries, additional proof
jobs, regression runs, cache changes or settings changes were launched. Root owns
session memory, issue/publication records and the final pause acknowledgment.

Canonical Linux x86_64 native run `20261110T181302-a4553e500d15` actually **failed**
with exit 1 at `2026-11-11T03:27:05.661638+00:00`, after 33,241.304 managed seconds
(about 9h14m), using its original 14-worker reservation, level 2, all-mode/all-report,
CVC5/Z3/Alt-Ergo and timeout 30. All managed reservations were zero after exit.
The inherited exec session 1714 was unavailable in the resumed monitor context;
actual managed failure state, return code and captured native log agree.

Exactly one proof obligation remains unresolved: `Procedure_Updates` static
postcondition at `src/silver_output_profile.adb:5412:20`, saying the result equals
`Procedure_Updates_Model (Text, Context, Scan.Facts, Scan, Catalog, First, Last,
Call_First, Call_After)`. Its check originates at line 5409:28. All three canonical
provers timed out on its unresolved branch. The entity has 30/31 proved checks.
The GNAT summary contains 19,428 total checks: 1,712 flow, 17,715 proved proof,
and one unproved proof. These totals do not constitute full native assurance.

`collect-final.py failure` ran exactly once after actual exit. `final-result.json`
retains actual run metadata and hashes. All 2,595 current, prepared, launch and
retained-copy native inputs agree at primary HEAD `c27f3ebab5fde0ac3d647fe0b36ca0a5362698a0`.
`actual-exit-packet/inputs/` retains those exact bytes; `actual-exit-packet/reports/`
retains 78 SPARK reports plus SARIF, summary and initial proof-inputs (81 files).
`actual-exit-run-status.json`, `prove-full.log` and `collection.log` are preserved.

The mandatory strict source/obligation/coverage audit rejects the unresolved
postcondition. The mandatory strict provenance audit fails because ordinary
`proof-provenance.json` was not written after GNATprove exited 1. No provenance
success was fabricated. `complete_native_success` remains false.

A separate **diagnostic** continuation through every unchanged ordinary auditor
requirement completed without a structural exception: 1,050,711 requirements,
78 units, 1,230 owned entities, 1,712 flow and 17,716 proof records including the
unproved record. It does not turn any failed requirement into assurance. See
`enumerate-failed-audit.py` and `failed-audit-enumeration.json`. In addition to the
unproved post/SARIF, failed invocation and corresponding total mismatch, this
found two rejected operator-reassociation advisory records for
`silver_procedure_bindings.ads:61:39`, in the `silver_output_profile` and
`silver_procedure_bindings` reports. The source is absent from their current
reviewed source whitelist. `failure-details.json` retains both exact advisory
records and the exact failed proof tree. Source policy, coverage and all other
conditions were traversed; no strict audit success is claimed.

After explicit owner resume, read this packet, the current governing documents,
source lifecycle handoff and managed status before choosing work. Diagnose the
named `Procedure_Updates` equality under unchanged complete domains/contracts and
canonical budgets; independently review the two advisory classifications against
their source and semantic proof changes. Preserve current failed inputs, proof
sessions/cache and prior focused successes. Make no blind full-run retry. Any
repair needs the ordinary owned implementation/review/obligation/provenance
workflow, including complete native and separately owned Lean/source assurance
before delivery. Application regressions remain unrun by this task.

Monitoring/evidence task selected Sol High; runtime model/effort was not
independently confirmed. Resumed monitoring ran approximately 23:58–03:35 UTC;
native managed time is recorded above. Token/cost measurements are unavailable.
No tracked file was edited by this monitoring subthread.
