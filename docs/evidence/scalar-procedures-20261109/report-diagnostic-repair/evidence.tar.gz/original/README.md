# Report diagnostic-message repair — #370

Implementation owner: native-tuning subthread. Owned tracked files are exactly
`src/silver_library_reports.adb`, `scripts/check_evidence.py`,
`tests/test_evidence.py`, and `docs/trusted-boundary.md`. Their prior uncommitted
index-hiding work is preserved in `before/`. Other tracked and scratch work is
unmodified by this stream. Commit `cf2882170d` contains exactly these four files;
no publication occurred.

Current source SHA-256:
`95d4758ea69276203ccfea127b73837701278c2770a996d30e5d6833af1a09b1`.
The successful helper and caller evidence applies to these exact committed bytes.
The report worker reservation is released and ownership returns to integration.

The repair factors the repeated diagnostic-message choice into a shared text
predicate, its raw counterpart, and a complete raw/text congruence lemma. Full
domains, original policy choices, existing assertions and complete caller
contracts remain. Four exact Hide_Info target names are added to the existing
source policy and existing tests; no proof budget or application policy changes.

The first helper attempt exposed a concrete abstraction mismatch: empty default
strings became distinct generated array terms. `empty-default-context.json`
retains the terms and their unconstrained literal-definition axioms. The refined
helpers explicitly pass the existing `Atom_Empty` constant and use two exact
initializer lemmas plus the existing output lemma. No defaults elsewhere change.
`explicit-empty.patch` records the complete refinement; regenerated terms in
`explicit-empty-context.json` use the same `atom_empty` actual.
The successful mixed-helper postcondition has two leaves proved by every prover:
maximum recorded times were 0.235494 s for Z3, 0.433939 s for CVC5 and 0.311 s
for Alt-Ergo. The previous hard leaf timed out at 30 s in Z3/Alt-Ergo and returned
unknown in CVC5. These are obligation-level observations; whole-run time also
includes frontend work and is not a controlled performance benchmark.

| Managed run | Input / scope | Actual result |
| --- | --- | --- |
| `20261110T124642-9b74ca9f8cbe` | Initial extraction build, source `070b0ee0` | Passed |
| `20261110T124717-bc958ce112bc` | Existing exact annotation-policy tests | All three methods passed |
| `20261110T124853-cd6e71459ff8` | All three complete new helpers, canonical compiler policy | Failed after 229.980 s: only mixed equality postcondition unresolved; exact 165-file packet in `failed-124853/` |
| `20261110T130008-678c87acfbef` | Refined extraction build, source `95d4758e` | Passed |
| `20261110T130301-47f2c90a6790` | All three complete new helpers, canonical compiler policy | Passed after 272.296 s; all 26 proof and 5 flow checks, all three entities in `all` mode; exact 171-file packet in `passed-130301/` |
| `20261110T130958-9ca30fc7ebf9` | Complete Record_Policy, Raw_Record_Policy, Record_OK and Mixed_Record_Congruence | Passed after 1806.953 s; all 360 proof and 7 flow checks, all four entities in `all` mode; exact 176-file packet in `passed-130958/` |

Every focused proof uses the compiler's canonical logical options: all flow/
proof, all reports, warnings/checks as errors, level 2, CVC5/Z3/Alt-Ergo and
timeout 30 seconds. Only unit/line coverage is focused. Native platform is
Linux x86_64. Exploratory output is
`.silver/linux-x86_64/compiler/obj/explore/procedure-diagnostic-message/`.
There is no audited full-success manifest from these focused runs.

All three helper entities have complete selected coverage and no skipped,
assumed, failed or selected warning/error records. The source policy and Python
tests are unchanged after the first passing policy test run; the refinement only
changes the Ada helper arguments and ghost calls. Native source-policy preflight
also passed on the refined bytes. Existing build and proof evidence remains
distinguished from final complete assurance.

The four policy/caller entities also have complete selected coverage, no failed
proof/flow checks and no skipped or assumed work. Their three unchanged
operator-reassociation advisories satisfy the existing exact compiler policy at
`scripts/check_evidence.py:531`; original function/statement/column identities
match the retained failed-run source. No warning policy was changed. Combined
selected coverage is **386 proof and 12 flow checks across seven complete
entities**. `final-audit.json` records these checks, exact current owned-file
hashes, the unchanged canonical options and the approved advisory identities.
Both original caller postconditions and the diagnostics assertion are discharged.

`independent-review/` retains the source owner's original full-function expansion
review and final explicit-empty refinement review. The reviewer independently
reconstructed exact refined bytes and checked all 171 retained successful helper
artifacts. No material semantic/domain issue was found. The report file has no
direct existing Lean model, source certificate or pin; native runtime/text/raw
contracts carry its source correspondence. Final integrated Lean input capture
must still include the exact selected report/auditor bytes. Parser source
bindings and the final whole-project native/Lean checkpoints remain required.

Handoff: the focused report repair is committed and complete. Preserve its
successful evidence during remaining parser/source integration. Root owns the
final complete native audit, integrated Lean capture/audit, remaining regressions,
capability status and publication. No report-specific Lean change is needed.
The live harness goal was null at entry and final audit. CLI memory was not
updated; root owns durable task memory and issue handoff. Unrelated dirty session
memory and the old untracked proof draft remain untouched.
