# Explicit-empty refinement review and source handoff — #370

Read-only independent review, 2026-11-10, approximately 13:12–13:17 UTC.
Source-role selection remains historical Astra Max; live model/effort is not
independently exposed. No material semantic, contract, or domain issue found.

The reviewed native report source is SHA-256
`95d4758ea69276203ccfea127b73837701278c2770a996d30e5d6833af1a09b1`.
It refines the earlier reviewed `070b0ee0` extraction. `check_explicit_empty.py`
reconstructs this complete file from that earlier candidate using exactly the
four explicit classifier arguments, one explanatory comment, and replacement of
one bundled ghost call by three existing ghost calls. The reconstructed bytes
match both the retained successful input and the frozen primary source exactly.
No contract, default declaration, surrounding branch, accessor, literal policy,
domain, or proof budget changed. Results are in `explicit-empty-review.json`.

`Atom_Empty` is the existing `constant String := ""` at source line31, with
bounds1..0 and length0. Its Ada value and bounds match every replaced empty
default. It satisfies the unchanged `Call_Name'Length <= 4096` precondition.
The four changed text/raw calls preserve the separate False and True choices
for `Unused_Formal`; none introduces an additional field, entity or source
lookup. `Initializer_Message` and its raw counterpart choose their ordinary
prefix/suffix when this string's length is0, exactly as before. Reading this
constant has no effect or mutable-state dependency.

The ghost lemma now invokes `Mixed_Initializer_Message` twice, once with the
existing False default and once with explicit True, both with explicit
`Call_Name => Atom_Empty`, followed by `Mixed_Output_Message`. Their contracts
supply exactly the three classifier equalities formerly obtained from
`Mixed_Test_Congruence`. Its two other conclusions about positive numbers and
nonempty strings are unused by this message clause. All ten remaining lemma
calls have their original full domains; the lemma's own Pre/Post are unchanged.

The native owner's retained AST observations distinguish an encoding problem
from an Ada semantic difference. Earlier empty defaults produced separate
unconstrained underlying map terms with identical null bounds. Once classifier
bodies were hidden, syntactic argument identity was unavailable at that proof
boundary. The refined definitions and mixed calls all pass the same `atom_empty`
logical term. The context JSON hashes and six relevant call observations are
retained in this review's JSON. This review does not claim a general verifier
defect or expand the repair to defaults elsewhere.

Canonical native run `20261110T130301-47f2c90a6790` actually succeeded at
13:07:36UTC in272.296seconds under the unchanged 30-second compiler policy.
The retained summary records all three complete entities in SPARK `all` mode:

| Entity | Proof | Flow |
| --- | ---: | ---: |
| `Diagnostic_Message` | 11 | 2 |
| `Raw_Diagnostic_Message` | 2 | 2 |
| `Mixed_Diagnostic_Message` | 13 | 1 |

All skip/assume and selected warning/error lists are empty. Independently
rechecked all171 manifest files,12,236,508bytes, in primary
`tmp/report-diagnostic-message/passed-130301`; sizes and SHA-256 hashes match.
The prior `124853` run remains failed. Build `130008` also passed. Complete
changed-policy/caller run `130958-9ca30fc7ebf9` remains active at this review;
the helper success is not promoted to caller or complete native assurance.
In particular, actual `Record_OK` eager-accessor sites await that caller result.

The original exact-expansion result applies directly to070b0ee0. The reviewed
bounded delta and Ada empty-string equivalence extend its semantic conclusion
to95d4758e; a new literal token-identity claim for the old implicit defaults is
not made.

The earlier verified source-binding inventory remains applicable: these report
functions have no direct Lean model, source certificate, or reviewed token pin.
Source-written native runtime/text/raw contracts and complete native coverage
and provenance establish this correspondence. No tracked Lean change or source
proof run is necessary for this refinement. Final source integration must still
synchronize exactly95d4758e (or a later explicitly selected report version), the
auditor, and relevant tooling before whole-input capture and the final complete
Lean audit. All existing guarantees and final validation remain required.
