# Independent review of diagnostic-message extraction — #370

Reviewed 2026-11-10, approximately 12:45–12:51 UTC, by the source subthread.
Selected source/review role was Astra Max; the live backend/model setting is not
independently exposed. This is an independent source/contract review of the
native-tuning subthread's concrete candidate, not a successful native or Lean
proof run.

**No material semantic, full-domain, or contract blocker found.** Proceeding to
the selected complete-helper checks is justified. Native verification of the
three new helpers and all affected complete callers remains required. The
parent owns final complete native/regression assurance and publication.

## Exact target and independent extraction check

Original retained report source:
`../scalar-procedures-native-tuning/report-reassessment-094033/src/silver_library_reports.adb`,
SHA-256 `ad110f6eb0cb74ff24490a1f811aa2c180bb76b21491dad7576d15ab9f8ce080`.
Candidate in the same packet, `candidate.adb`, SHA-256
`070b0ee0037450da0f1bf2a64cd37231f55040be2d941f3b0ace46f1247a812d`.
The native implementation owner confirmed the primary source matches that exact
candidate and froze it for validation.

`check_extraction.py` independently reads the complete original and candidate
functions, reads each extracted helper's actual expression and each caller's
actual argument list, substitutes the arguments, and requires exact restoration
of the complete original token sequence. For `Record_OK` only, its one newly
added proof-local `Hide_Info` statement is removed for this comparison. It does
not normalize away executable operators, branches, parameters, literals or
contracts. All three checks passed:

| Complete original function | Tokens | Extracted expression tokens |
| --- | ---: | ---: |
| `Record_Policy` | 1,560 | 277 |
| `Record_OK` | 1,811 | 277 |
| `Raw_Record_Policy` | 1,594 | 277 |

`exact-extraction.json` records the exact arguments and results. This confirms
the extraction substitutions and the surrounding unchanged expression, not Ada
evaluation safety by itself; eager argument evaluation was reviewed separately.

## Eager argument evaluation and complete domains

The helper call evaluates its rule, nested message field, and entity identity
before entering its body. The former expression could skip some of those
lookups when an earlier rule comparison was false. Actual declarations in the
retained source establish the following coverage:

| Runtime/model operation | Declared precondition | Caller coverage |
| --- | --- | --- |
| `Field` / `Field_Spec` (936 / 769) | `Text'First = 1` and `Text'Length <= Max_Report_Length` | Exactly `Record_OK` / `Record_Policy` precondition |
| `Referenced_Entity` / `Referenced_Entity_Spec` (1360 / 1347) | Same text condition | Same; no required valid span or entity table |
| `Entity_Name` / `Entity_Name_Spec` (1285 / 1255) | Same text condition | Same; no source-membership or metadata-validity premise |
| `Diagnostic_Message` (candidate 1650) | Same text condition | Directly from each text caller |
| Raw field/reference/entity functions | No additional precondition | Arbitrary raw sequence and span remain permitted |

The runtime lookups use only their inputs and local computation. Their bodies
retain internal validity checks before indexing or slicing: `Field` handles an
arbitrary object span, `Referenced_Entity` checks the argument before slicing,
and `Entity_Name` retains its source-name guards. `Missing`, `Malformed`, empty
and arbitrary typed spans remain in scope. The extraction introduces no source
membership, positive-position, `Kind`, `Name`, or metadata invariant premise.

The new text helper's constituent message classifiers all accept the same text
condition. `Initializer_Message` additionally requires `Call_Name'Length <=
4096`; both direct uses have its unchanged empty default. The source-name
substring inside `Procedure_Output_Message` retains its own existing guard and
is reached under the same Boolean branch as before. The full domains of source
strings and typed function/procedure metadata are unchanged.

Ada may choose an argument evaluation order and may now perform an extra bounded
lookup for a rejected rule. Pure argument evaluation with the above precondition
coverage preserves the return value; timing equivalence is not claimed. The
selected complete native caller checks must discharge the actual newly generated
preconditions/runtime obligations, rather than relying on the token comparison.

## New mixed congruence lemma

`Mixed_Diagnostic_Message` has only the existing text precondition and two
`Mixed_Field` premises, one for each rule/message span. Those are exactly the
preconditions of its eight calls:

- Three `Mixed_String_Congruence` calls equate the rule classifications.
- `Mixed_Test_Congruence` exports both initializer forms and the output-message
  equality. Its other two test equalities are harmless additional conclusions.
- `Mixed_Procedure_Output_Message` exports the procedure-specific classifier
  equality for the same arbitrary source and typed procedure metadata.
- Three `Mixed_String_Congruence` calls equate the literal message choices.

`Kind`, `Name`, `Source`, `Functions` and `Procedures` are shared unchanged by
both sides. The local-subprogram decision therefore needs no new premise.
The enclosing `Record_Observation_Agreement` supplies both field relations and
the exact raw/text entity identity used when invoking this lemma. The original
complete `Mixed_Record_Congruence` precondition and postcondition are unchanged.
The removed eight inline calls have all moved into the new lemma; the message
choices occur only in the existing `Main_Diagnostics` branch. Termination and
initialization equalities and the final diagnostics assertion remain present.

The six hidden classifier bodies retain their exact exported contracts. The new
message bodies are hidden only from their caller, where equality is established
through identical arguments or the new proved lemma. No assumed result,
suppressed obligation, narrower domain or weaker contract was introduced.

## Source-correspondence impact and owned next change

The current Lean proof tree contains no report-policy model and does not embed
`silver_library_reports.adb`. `SOURCE_BINDINGS`, `CERTIFICATE_ROOTS`,
`AuthoritativeSource` and `SourceCertificates` confirm that this file has no
existing Lean token certificate or reviewed source-shape pin.
`source-impact.json` records the complete proof-text search and checked input
identities. A report-specific Lean pin/model/certificate update is therefore
not an actual dependency of this extraction. Do not claim such a proof exists
or introduce an assumed whole-report equality to simulate one.

Report implementation/model correspondence is supplied by its source-written
SPARK contracts: `Record_OK` to `Record_Policy`, and the raw/text policy
congruence to its byte observation relation. Those contracts are retained and
need complete fresh native verification, coverage and source provenance on the
selected report bytes. `check_lean.py` separately captures every `src/*.ads` and
`src/*.adb`, so the final report/auditor bytes must still be synchronized before
the complete Lean run for exact whole-input applicability. Changed capture
identity does not by itself require rebuilding unrelated successful objects.

The separate parser candidate strengthens `Lemma_Parser_State_Equality` to
`Post => Left = Right and then Same_Parser_State (Left, Right)`. The only direct
Lean helper-header expectation is in
`proof/Silver/ComposeArrayDeclarationSource.lean:59`. The prepared
`parser-equality-header.provisional.patch` changes that exact checked contract;
it leaves all body semantics and Static-erased evaluation unchanged. The patch
is **not applied** pending the full native helper/caller outcomes and final
source selection. Scope's source is frozen at SHA-256
`336cba3eac92dc2833336ec4b181ac6f614e86cd2cec3600c401304c235296cb`.
The old output pin remains untouched. Later parser repairs may change this
plan; scope has not selected or applied its tentative `Body_Of` contract idea.

## Validation state at this review

The native owner reports build `124642` and all three policy-test methods in
`124717` passed. New-helper run `124853-cd6e71459ff8` is active with twelve
workers and the canonical 30-second compiler policy. Scope's parser helper
run `124550-040b6b213722` has ten workers. Neither active run is called a success
here. No source proof job, primary source edit, tracked Lean edit or output pin
change was made by this review. Accepted model `094508` and baseline certificate
`073635` remain preserved; final complete assurance remains outstanding.
