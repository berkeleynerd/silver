# Report-caller reassessment after run 094033

The next justified source experiment is a **diagnostic-message composition
boundary**, rather than another broad hiding retry. A concrete uncompiled draft
is in `candidate.adb`; `candidate.patch` contains the complete proposed Ada change.
No tracked file was edited and no compiler/prover job was run by this subthread.

## Exact retained failure

Run `20261110T094033-8bb409307103` exited 1 after 2590.032695097 seconds at
2026-11-10 10:23:46 UTC. Its exact effective command used eight workers, all
flow/proof, warnings/checks as errors, level 2, CVC5/Z3/Alt-Ergo, 100000 normalized
steps, timeout 0 and memlimit 1000. The final events and log are under `run/`.

Twenty source/configuration/report/session/AST files, totaling 34,899,463 bytes,
were copied here. `manifest.json` records their original paths, hashes and mtimes.
The retained source is SHA-256
`ad110f6eb0cb74ff24490a1f811aa2c180bb76b21491dad7576d15ab9f8ce080`;
the integration source still matched at the final comparison.

The three reported failures remain:

| Source obligation | Current session evidence |
| --- | --- |
| Record_OK postcondition, 1774:27 | `def'vc.348`: all three step limits exhausted; counterexample timeout |
| Mixed_Record_Congruence assertion, 4400:13 | Main_Diagnostics-only equality; all three step limits exhausted |
| Mixed_Record_Congruence postcondition, 4244:16 | Remains unresolved; counterexample timeout |

The mixed session's two current unresolved leaves are `def'vc.447` and
`def'vc.491`. `context-and-leaves.json` excludes obsolete attempts and records
the exact current results. These are resource-exhaustion outcomes, not confirmed
counterexamples. The separately asserted raw/text termination and initialization
policy equalities are proved. The source-level diagnostics assertion gives a
definite branch for the mixed failure. The retained pre-split AST does not expose
the formula of Record_OK's numbered leaf, so assigning its failure to that branch
remains a hypothesis.

## What the evidence rules out, and what remains uncertain

Generated final caller theories confirm that the previous annotations took
effect: both initialization-index definition imports are absent from the mixed
caller; the text index definition is absent from Record_OK. Both callers also
hide initializer/procedure-output classifier bodies as intended. Output_Message
and Raw_Output_Message bodies remain visible where applicable. The persistent
failure therefore cannot be explained as a failure to apply the index hiding.

The complete Main_Diagnostics branch is token-identical across runtime,
text-model and raw-model versions after substituting documented runtime/spec
accessors and proven raw/text counterparts: 505 normalized tokens.
`normalized-complete-diagnostics.json` records the comparison. The nested message
choice is likewise identical at 277 normalized tokens; its three original source
fragments and `normalized-message-clause.json` are retained. This comparison is
a diagnostic extraction, not a proof of the substitutions or source assurance.

No missing message equality or omitted branch was found. Existing contracts
supply every required connection:

| Atom | Evidence-producing call |
| --- | --- |
| Rule equals UNUSED_VARIABLE, INEFFECTIVE, DEAD_CODE | Three Mixed_String_Congruence calls |
| Initializer message, both Boolean choices; output message | One Mixed_Test_Congruence call |
| Source-declared procedure output advisory | Mixed_Procedure_Output_Message |
| Unused assignment, no effect, unreachable literal messages | Three Mixed_String_Congruence calls |
| Entity identity | Record_Observation_Agreement; identical shared Name in proposed helper |
| Kind, Source and metadata | Identical arguments, requiring no additional premise |

The prior independent packet retains successful complete helper evidence. This
review does not reclassify any current caller as proved. The evidence supports
isolating composition of these facts from recursive field/entity/record context;
it does not establish which SMT transformation or axiom triggered exhaustion.

## Exact proposed repair

1. Extract only the existing three-way diagnostic-message choice into the
   non-ghost expression function `Diagnostic_Message(Text, Rule, Message, Kind,
   Name, Source, Functions, Procedures)`. Its sole precondition is the existing
   Text origin/length condition. It preserves every List_Kind, Entity_Kind,
   Source string and typed metadata value. Record_Policy and Record_OK call the
   same function with their corresponding spec/runtime field and entity results.
2. Extract the identical raw clause into ghost `Raw_Diagnostic_Message`, with
   no extra precondition, and use it in Raw_Record_Policy.
3. Add ghost `Mixed_Diagnostic_Message`. Its precondition is Text validity plus
   Mixed_Field for the rule and message spans. Its postcondition is the exact
   raw/text diagnostic-message equality. Its body contains the eight calls in
   the table above. The only expression bodies hidden there are the six
   initializer/output/procedure-output classifiers whose equalities those calls
   already supply. No facts are assumed.
4. In Mixed_Record_Congruence, move those eight message-specific calls into the
   new lemma and invoke it inside the existing Main_Diagnostics branch. Keep
   both proved termination/initialization assertions, the diagnostics assertion,
   and the complete postcondition. Locally hide the two new message bodies in
   that caller. Locally hide Diagnostic_Message in Record_OK, where equal input
   arguments give its result equality directly.

This is a small semantic boundary around a repeated policy clause, not a new
report architecture. It retains all existing record fields, literal spellings,
metadata handling, branches and contracts. Runtime structure changes through
expression extraction: helper arguments are evaluated before the call, including
some pure lookups previously reached conditionally. Their existing preconditions
must be checked; equivalence is not being asserted from an uncompiled draft.

The proposed source is SHA-256
`070b0ee0037450da0f1bf2a64cd37231f55040be2d941f3b0ace46f1247a812d`.
`make-candidate.py` reconstructs it from the retained source and extracted clauses.
The draft intentionally does not edit the source-policy allowlist, tests, trusted
boundary or Lean adapters. Implementing it also requires adding the four exact
allowed target names `diagnostic_message`, `raw_diagnostic_message`,
`output_message`, `raw_output_message` with matching policy tests/documentation.
Existing suppression/assumption exclusions stay intact.

## Whole-helper validation plan

After source review and integration, first run the existing exact annotation
policy tests and a build. Then use a separate managed exploration directory and
the established trial options to check **every line of Diagnostic_Message,
Raw_Diagnostic_Message and Mixed_Diagnostic_Message**, including declarations,
preconditions, calls and bodies. Do not select only the new lemma's postcondition.
This first stage isolates the new composition argument without paying for both
large callers again. Inspect all selected flow/proof records and actual exit.

If the new helpers pass, select every line of those helpers plus Record_Policy,
Raw_Record_Policy, Record_OK and Mixed_Record_Congruence, preserving all source
inputs and recording the explicit worker share around the parser's reservation.
The two existing policy assertions and diagnostics assertion remain required.
Check generated final theories for the intended body abstraction and audit the
selected obligation inventory against the candidate; a successful process exit
alone is insufficient. Unchanged established helper evidence may be retained.

If the small helper fails, diagnose its exact leaf before returning to whole
callers. If it passes but a caller fails, the message equality has been isolated
and the remaining header/tail or other branch can be examined without guessing
at missing classifier semantics. No broad budget increase is proposed.

The mandatory final canonical native audit and actual-source correspondence
remain outstanding. The subsequent independent source inventory found no
existing Lean binding, model, pin or certificate for this report file: its
runtime/text/raw correspondence is carried by the source-written SPARK contracts
above. No new report certificate is required or claimed. Final Lean input
capture still must synchronize these report/auditor bytes; separate parser
source bindings remain required. See the independent source review in
`../../scalar-procedures-source-semantic-370/tmp/report-diagnostic-review-20261110/`.
The separately identified compiler/application budget mismatch is not repaired
or waived by this draft.
