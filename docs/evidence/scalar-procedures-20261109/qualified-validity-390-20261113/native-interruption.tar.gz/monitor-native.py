"""Read-only native monitoring, with a scratch-only append-only observation log."""
import datetime
import json
from pathlib import Path
import re
import subprocess
import sys

packet = Path(__file__).resolve().parent
root = packet.parents[1]
text = (packet / "prove-full.log").read_text()
status = json.loads(subprocess.check_output(
    [sys.executable, "scripts/dev.py", "runs", "status", "--limit", "1"],
    cwd=root, text=True))
observation = {
    "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "log_bytes": len(text),
    "spark_files": len(list((root / ".silver/linux-x86_64/compiler/obj/gnatprove").glob("*.spark"))),
    "active": [{key: item[key] for key in ("run_id", "kind", "workers")}
               for item in status["runs"] if item["active"]],
    "reserved_workers": status["reserved_workers"],
    "noninfo_log_heading_counts": {
        key: len(re.findall(r"(?m)^\s*" + key + ":", text))
        for key in ("warning", "low", "medium", "high", "error")},
    "mem_available_kib": int(re.search(
        r"MemAvailable:\s+(\d+)", Path("/proc/meminfo").read_text())[1]),
    "last_log_lines": text.splitlines()[-5:],
}
if "--compare-inputs" in sys.argv:
    sys.path.insert(0, str(root / "scripts"))
    from platforms import native_layout
    from proof_provenance import input_hashes
    manifest = json.loads((packet / "launch-input-manifest.json").read_text())
    observation["native_inputs_match_launch"] = (
        input_hashes(native_layout(root)) == manifest["inputs_sha256"])
with (packet / "monitoring.jsonl").open("a") as stream:
    stream.write(json.dumps(observation) + "\n")
print(json.dumps(observation, indent=2))
