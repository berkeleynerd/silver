"""Capture exact current native inputs without changing proof/build state."""
from pathlib import Path
import datetime,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/"scripts"))
from platforms import native_layout
from proof_provenance import input_hashes
packet=Path(__file__).resolve().parent
host=native_layout(ROOT)
phase=sys.argv[1]
if phase not in {"prepared","launch"}:raise SystemExit("invalid phase")
inputs=input_hashes(host)
original=json.loads((ROOT/"tmp/final-native-20261110/launch-input-manifest.json").read_text())["inputs_sha256"]
record={"captured_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"root":str(ROOT),"head":subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip(),"native_host":host.key,"inputs_sha256":inputs,"input_count":len(inputs),"changed_since_failed_run":{name:{"old":original.get(name),"current":value} for name,value in inputs.items() if original.get(name)!=value},"removed_since_failed_run":[name for name in original if name not in inputs],"proof_options":["-U","--mode=all","--report=all","--warnings=error","--checks-as-errors=on","--level=2","--prover=cvc5,z3,altergo","--timeout=30"],"resource_plan":{"native_workers":14,"lean_workers":8,"available_cpus":22,"lean_threads":"default22; not an OS cap"},"model_setting":"Routine final-native monitoring selected Sol High; live runtime setting not independently confirmed."}
if phase=="launch":
 prepared=json.loads((packet/"prepared-input-manifest.json").read_text())
 if inputs!=prepared["inputs_sha256"]:raise SystemExit("native inputs changed since preparation")
 record["inputs_match_preparation"]=True
(packet/(phase+"-input-manifest.json")).write_text(json.dumps(record,indent=2)+"\n")
status=subprocess.check_output([sys.executable,"scripts/dev.py","runs","status","--limit","8"],cwd=ROOT,text=True)
(packet/(phase+"-run-status.json")).write_text(status)
print(json.dumps({key:record[key] for key in ["captured_at","head","native_host","input_count","changed_since_failed_run"]},indent=2))
