"""Run the reviewed complete native checkpoint, retaining actual wrapper exit."""
from pathlib import Path
import datetime,json,os,subprocess,time
packet=Path(__file__).resolve().parent
root=packet.parents[1]
command=["python3","scripts/dev.py","prove","--full","--jobs","14","--task","#370","--reason","Repair reviewed Procedure_Updates model equality and two advisory origins after actual whole-helper/callee/caller focused success; final ghost model gate passed. Preserve original failed packet, ordinary sessions and normal native cache; no cold or clean mode. Coordinate 14 native workers with at most 8 Lean workers."]
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
(packet/"command.json").write_text(json.dumps({"command":command,"started_at":now(),"launcher_pid":os.getpid()},indent=2)+"\n")
start=time.monotonic()
with (packet/"prove-full.log").open("w") as log:
 process=subprocess.Popen(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 (packet/"process.json").write_text(json.dumps({"pid":process.pid,"launcher_pid":os.getpid(),"started_at":now()},indent=2)+"\n")
 code=process.wait()
result={"returncode":code,"finished_at":now(),"elapsed_seconds":time.monotonic()-start}
(packet/"exit.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result))
raise SystemExit(code)
