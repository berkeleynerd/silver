"""Retain exact final native inputs/reports and perform fresh ordinary audits."""
from __future__ import annotations

import datetime
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
from check_evidence import audit_sources
from platforms import native_layout
from proof_provenance import digest, input_hashes, validate_provenance


def main() -> None:
    state = sys.argv[1]
    if state not in {"success", "failure", "interrupted"}:
        raise SystemExit("state must describe the actual observed command exit")
    host = native_layout(ROOT)
    packet = Path(__file__).resolve().parent
    prepared = json.loads((packet / "prepared-input-manifest.json").read_text())
    launched = json.loads((packet / "launch-input-manifest.json").read_text())
    current = input_hashes(host)
    run_id = re.search(r"Managed run: (\S+)", (packet / "prove-full.log").read_text())[1]
    status = json.loads(subprocess.check_output(
        [sys.executable, "scripts/dev.py", "runs", "status", "--limit", "0"],
        cwd=ROOT, text=True))
    run = next(item for item in status["runs"] if item["run_id"] == run_id)
    if run["active"]:
        raise SystemExit("Refusing final collection while native run remains active")
    evidence = packet / "actual-exit-packet"
    evidence.mkdir(exist_ok=False)
    copied = {}
    for name, expected in launched["inputs_sha256"].items():
        source = ROOT / name
        destination = evidence / "inputs" / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        actual = digest(destination)
        copied[name] = {"sha256": actual, "matches_launch": actual == expected}
    reports = host.compiler / "obj/gnatprove"
    report_copies = {}
    for source in sorted(reports.iterdir()):
        if source.is_file() and (source.suffix == ".spark" or source.name in {
            "gnatprove.sarif", "gnatprove.out", "proof-provenance.json", "proof-inputs.json"
        }):
            destination = evidence / "reports" / source.name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
            report_copies[source.name] = digest(destination)
    result = {
        "collected_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "observed_command_state": state,
        "managed_run": run,
        "current_head": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "current_inputs_match_preparation": current == prepared["inputs_sha256"],
        "current_inputs_match_launch": current == launched["inputs_sha256"],
        "retained_input_copies": copied,
        "retained_report_hashes": report_copies,
        "fresh_provenance_audit": None,
        "fresh_source_obligation_coverage_audit": None,
        "audit_errors": [],
        "qualification": "Native full obligations, source policy/coverage and exact provenance only; complete Lean actual-source correspondence is separately owned.",
    }
    manifest = None
    try:
        manifest = validate_provenance(host, reports)
        result["fresh_provenance_audit"] = {
            "passed": True,
            "input_count": len(manifest["inputs_sha256"]),
            "initial_state": manifest["initial_state"],
            "mode": manifest["mode"],
            "command": manifest["command"],
            "report_count": len(manifest["reports_sha256"]),
        }
    except Exception as error:
        result["audit_errors"].append("provenance: " + str(error))
    try:
        result["fresh_source_obligation_coverage_audit"] = audit_sources(
            ROOT / "src", reports, host.generated,
            effective_command=manifest["command"] if manifest else None)
    except Exception as error:
        result["audit_errors"].append("source/obligation/coverage: " + str(error))
    result["complete_native_success"] = (
        state == "success" and run["state"] == "success"
        and result["current_inputs_match_launch"]
        and all(item["matches_launch"] for item in copied.values())
        and not result["audit_errors"]
    )
    (packet / "actual-exit-run-status.json").write_text(json.dumps(status, indent=2) + "\n")
    (packet / "final-result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in (
        "complete_native_success", "managed_run", "current_inputs_match_launch",
        "fresh_provenance_audit", "fresh_source_obligation_coverage_audit", "audit_errors"
    )}, indent=2))


if __name__ == "__main__":
    main()
