# Native repair handoff — #370 — 2026-11-13

Bounded native work is complete. Source-only commit `71ce4bfc23da83b267ec1a1087d91bb7f6460dd4` (Refs #370) adds the independently reviewed 21 Static ghost lines to `src/silver_output_profile.adb`; final SHA-256 `0bd0f4f21ae9faef7b3a4ab3bf64388b43cd1d7bf2780a40a4b353fc33b49a08`. Tracked native worktree is clean; all existing untracked `tmp/` evidence remains. Primary integration, complete native/Lean/provenance checks, regressions, issue updates and durable session memory belong to root and its designated final-native/source agents. No GitHub write or CLI-memory update was performed here. Live harness goal was null at handoff; this subthread did not alter it.

## Repair and review

`Same_Body` compares the complete Body_Scan discriminant and every component through the already verified flow identity. `Lemma_Body_Equality` proves logical identity from raw equality and re-exports raw equality. Procedure_Updates calls this Static lemma on exactly the two model terms in its unchanged loop invariant. Original runtime statements, model, contracts, failure paths, variant and all input domains remain unchanged, including Count=0 and arbitrary failure states. No assumption, suppression, budget increase or narrower domain was added.

Independent critical review is `/home/canto/src/github.com/berkeleynerd/silver/tmp/procedures-repair-review-20261113/native-equality-candidate-review.md`, tied to this exact source and retained patch. Selected author/reviewer settings were Astra Max; actual runtime settings and token/cost telemetry are not independently exposed. Native tool times below are measured separately from unavailable total agent/team cost.

## Actual verification

Canonical focused managed run **20261113T092540-3c74bc914df8** finished with actual native-tool phase exit 0 and wrapper exit 0 at **09:49:26.951 UTC**. Wrapper elapsed **1429.381 seconds**; managed elapsed **1425.235 seconds**. Eight native workers were reserved to leave fourteen for concurrent Lean work on the actual 22-CPU Linux x86_64 host. The reservation is released. The successful exploratory summary's returncode is null; the actual phase-end event and wrapper both explicitly record zero.

All **190 proof checks and 33 flow checks pass across 17 complete entities**, all in all mode:

| Entity/group | Proof | Flow |
| --- | ---: | ---: |
| Same_Body (including Logical_Equal VC_INLINE_CHECK) | 1 | 2 |
| Lemma_Body_Equality | 4 | 1 |
| Procedure_Updates | 36 | 3 |
| Procedure_Updates_Model | 13 | 2 |
| Procedure_Update_Step | 17 | 2 |
| Procedure_Call_Body, direct caller | 17 | 2 |
| Existing equality predicates/bridges and invalid/token helpers | 102 | 21 |

Every prior 180 proof and 30 flow identity remains after exact source-line mapping. The ten new proof and three new flow checks all pass. All 94 existing warning records match after mapping. No missing entities/sessions, assumptions, skipped flow/proof, suppression, justification or analysis stop appears. Every declared input domain was retained; whole declarations and bodies, not only a leaf or postcondition line, were selected.

The original failing raw postcondition is proved. Its first branch reports CVC5 Valid at **32.8704 seconds**, Alt-Ergo Valid at **32.9147 seconds**, and Z3 Timeout at **30 seconds**. These are actual producer measurements under the unchanged configured `--timeout=30`, level 2, CVC5/Z3/Alt-Ergo, all mode, all reports, warnings/checks as errors. No higher timeout was requested. This success does not establish a unique timeout cause or adequate margin for the final run; complete native success must be observed separately.

## Evidence and continuity

The exact packet is `identity-trial/`:

- `audit.json`, `summary.json`, `selected-checks.json`, and `repaired-postcondition.json` retain all selected checks and audit results.
- `retained/` holds 64 report/session/generated-context/command files totaling 61,269,544 bytes, freshly verified against `retained-manifest.json`.
- `input-bytes/` retains all 2,595 prepared native project inputs (5,300,647 bytes), checked against current bytes and `prepared.json`; `selection-identity.json` separately records source/selector/command hashes.
- `scope.json` and `whole-entities.lines` identify complete selected entities. No previous native proof session was seeded into this fresh separate `explore/native-repair-20261113` output.
- `collection-attempt1.json` retains the scratch collector's initial mistaken comparison of managed summary null versus wrapper zero; the corrected collector checks the actual native phase-end event. No proof retry or source change resulted.

Original failed full run 181302, its 2,595-input packet, caches and sessions remain untouched in primary. `failed-vc-export/` contains the exact isolated export of its unresolved leaf and a one-step diagnostic attempt; diagnostic exit zero is not proof success. The old focused warm success is separately recorded in `prior-focused-comparison.json` and is not promoted to final assurance. Native worktree captured its older auditor identity unchanged; the final primary audit must use root's reviewed advisory classifier fix faa9f17415. The selected output-profile report retains its known procedure-binding advisory; the separate binding-unit advisory remains preserved in the original full-run packet.

## Next authorized work

Root's final-native agent owns cherry-pick/build/full native assurance using the preserved primary cache. The source agent owns the corresponding Same_Body/lemma helper headers and bodies, complete-domain semantic checks, Static call/source-tree erasure and final source certificate/pin refresh. Those changes must be reviewed with the source, not only repinned. The native source bytes are final for this bounded handoff; no further native edits or runs are planned here. Focused success alone is not capability completion or complete assurance.
