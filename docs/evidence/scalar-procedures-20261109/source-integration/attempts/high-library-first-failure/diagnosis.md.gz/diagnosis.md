# First high declaration-library focused attempt

Run 20261110T071602-835249eac4a0 exited 1 at 2026-11-10 07:50 UTC. All completed dependencies remain retained. The only reported module failure is ComposeEquations: interpreted_declarations omitted procedures from its capacity bound and termination measure after declarationAt began appending procedure declarations. The model count theorem already includes procedures.

Repair the measure and its two bound projections to count ProcedureBindings.maxProcedures and state.procedures.items.length. No theorem statement, native source, input domain or obligation changes. Integrate separately accepted outer/String semantic commits and their immutable completed objects, then repeat the same high-library focused target with normal rehash and fresh audit.
