from pathlib import Path
import subprocess
root=Path(__file__).resolve().parent.parent
prefix=b'with Silver_IO;procedure Main is pragma SPARK_Mode(On);subtype Den is Integer range 0..1;'
procedure=b'procedure P(N:in Den;B:out Boolean)is begin B:=N>0 and then (1/N)=1;end P;'
forms={'prefix_in':procedure,'body_in':procedure.replace(b'begin B:=',b'begin B:=False;B:='),'prefix_inout':procedure.replace(b'N:in Den',b'N:in out Den')}
for name,p in forms.items():
 f=root/'tmp/prefix-refinement'/(name+'.adb'); f.write_bytes(prefix+p+b'begin null;end Main;')
 r=subprocess.run([str(root/'.silver/linux-x86_64/compiler/bin/silver'),'check',str(f)],capture_output=True,text=True)
 print(name,r.returncode,r.stdout.strip())
 expected=2 if name=='prefix_in' else 0
 if r.returncode!=expected: raise SystemExit(1)
