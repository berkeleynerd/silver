with Silver_IO;
procedure Main is
   pragma SPARK_Mode (On);
   subtype Small is Integer range -100 .. 100;
   subtype Wide is Integer range -200 .. 200;
   function Identity (Value : in Small) return Small is
   begin
      return Value;
   end Identity;
   procedure Sum_And_Diff
     (Left : in Small; Right : in Small; Sum : out Wide; Difference : out Wide) is
   begin
      Sum := (Left + Right);
      Difference := (Left - Right);
   end Sum_And_Diff;
   procedure Update
     (Value : in out Small; Flag : in out Boolean; Previous : out Small) is
   begin
      Previous := Value;
      if Value < 100 then
         Value := (Value + 1);
      end if;
      Flag := not Flag;
   end Update;
   procedure Compose (Value : in Small; Result : out Wide; Changed : out Boolean) is
      Temporary : Wide := 0;
      Input : Small := 0;
   begin
      Result := 0;
      Changed := False;
      Input := Identity (Value);
      Sum_And_Diff (Input, 1, Result, Temporary);
      Changed := True;
   end Compose;
   procedure Unused (Value : in Small; Result : out Small) is
   begin
      Result := 0;
      if Value >= 1 then
         Result := (100 / Value);
      end if;
   end Unused;
   X : Small := 7;
   Y : Small := 0;
   Sum : Wide := 0;
   Difference : Wide := 0;
   Flag : Boolean := False;
begin
   Sum_And_Diff (7, 3, Sum, Difference);
   Update (X, Flag, Y);
   if Sum = 10 and then Difference = 4 and then X = 8 and then Y = 7 and then Flag then
      Compose (X, Sum, Flag);
      if Sum = 9 and then Flag then
         Silver_IO.Put_Line ("procedure probes ok");
      else
         Silver_IO.Put_Line ("wrong composition");
      end if;
   else
      Silver_IO.Put_Line ("wrong scalar result");
   end if;
end Main;
