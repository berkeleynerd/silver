with Silver_IO;
procedure Main is
   pragma SPARK_Mode (On);
   procedure Unused (Input : in Integer; Result : out Integer) is
   begin
      Result := Input + 1;
   end Unused;
begin
   Silver_IO.Put_Line ("unused procedure");
end Main;
