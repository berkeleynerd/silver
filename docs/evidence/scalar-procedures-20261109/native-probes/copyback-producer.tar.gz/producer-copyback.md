# Scalar procedure copyback check multiplicity

Pinned SPARK producer revision:
`42554fc241fcd1fdf08d3a2feccb3f86912acbc0`.

For the #370 grammar, a writable actual is a bare mutable scalar name of
Standard.Integer, an admitted static Integer subtype, or Standard.Boolean.
There are no predicate aspects, relaxed initialization, aggregates, component
paths, access types, tagged types, overlays, exceptions, or no-return paths.

The producer route supports **at most one extra scalar range-check record per
writable actual occurrence**, in addition to its copy-in expression obligations:

1. `gnat2why-expr.adb`, `Compute_Call_Args`, 4393–4590: scalar out actuals
   use a term-only input conversion (4527–4550); in/inout inputs are transformed
   once against the formal expected type (4579–4585).
2. The mutable formal loop at 4733–4774 adds one ordinary store per mutable
   scalar actual. Exceptional copyback paths are outside this grammar.
3. `Compute_Store`, 8311–8355, calls `Reconstruct_Actual_From_Item` once with
   `No_Checks => False`, then uses the ordinary assignment route.
4. `Reconstruct_Actual_From_Item`, 14919–15064, has one
   `Insert_Checked_Conversion` in the scalar `Regular` branch (14944–14971),
   with the actual's declared type as destination. Its final conversion uses
   `EW_Pterm`; the comment states all necessary checks have been inserted.
5. `New_Assignment`, 12286ff: the bare identifier skips `Shift_Rvalue`; the
   final conversion uses `EW_Pterm` (12368–12386), and the `Regular` branch is
   a direct assignment (12432–12442). These add no second range check.
6. `why-gen-expr.adb`, `Insert_Checked_Conversion`, 1518–1657, enters the
   scalar case once and invokes `Insert_Scalar_Conversion` once. The overload
   at 2399–2474 determines at most one range type/check kind. The overload at
   2476ff uses `Range_Check_Applied`: the range check at step 3 (2750–2768)
   prevents another at step 5 (2804–2823). The admitted nonmodular branch of
   `Do_Range_Check` (2352–2389) creates one `New_VC_Call`.

Standard.Boolean may omit the check. The same loop and gate arguments hold for
unused declared procedures because their bodies retain all coverage; this
multiplicity argument does not establish obligation success. Required complete
proof discharge, report auditing, source correspondence and provenance remain
separate checks. Mechanism probes in the adjacent evidence archive include a
deliberately failing narrow copyback (formal -200..200 to actual -10..10).

The capacity record may therefore add `floor(4096 / 2) * 2048` bytes for writable
copyback records: every bare writable actual occurrence requires its identifier
byte and a following comma or closing-parenthesis byte, so there are at most
2048 such occurrences. The 2048-byte per-record serialized allowance comes from
the existing selected producer report envelope. This deliberately overcounts
the jointly constrained source budget and does not claim a tight maximum.
