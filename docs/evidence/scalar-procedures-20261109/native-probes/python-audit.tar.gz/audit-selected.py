import json,sys
from pathlib import Path
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root))
from scripts.check_evidence import audit_reports
result=audit_reports(root/'tmp/procedure-probes/selected/obj/explore/procedures/gnatprove',
 {'main','silver_io','silver_output_libc','silver_arguments','silver_runtime'},
 {'silver_output_libc','silver_runtime'},application_kind='assigned',
 application_functions=('Identity',),
 application_procedures={'Sum_And_Diff':('Sum','Difference'),'Update':('Previous',),'Compose':('Result','Changed'),'Unused':('Result',)},indexed_main=True)
print(json.dumps(result,sort_keys=True))
