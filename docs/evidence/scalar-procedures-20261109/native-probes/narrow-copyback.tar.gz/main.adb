with Silver_IO;
procedure Main is
   pragma SPARK_Mode (On);
   subtype Wide is Integer range -200 .. 200;
   subtype Narrow is Integer range -10 .. 10;
   procedure Set_Value (Result : out Wide) is
   begin
      Result := 0;
      Result := 100;
   end Set_Value;
   Value : Narrow := 0;
begin
   Set_Value (Value);
   Silver_IO.Put_Line ("unreachable copyback");
end Main;
