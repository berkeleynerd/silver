# Pinned producer initialization route

Inspection of SPARK commit `42554fc241fcd1fdf08d3a2feccb3f86912acbc0`, native
procedure work for #370, 2026-11-09. This is a producer-source argument under
Silver's existing trusted-tool assumptions, not a proof of the producer.

`flow-control_flow_graph.adb:8467-8477` visits every formal of each analyzed
subprogram, including unused local procedures under the selected `-U` and
`--no-inlining` recipe. `Create_Initial_And_Final_Vertices` at 1506-1635 maps
E_Out_Parameter to Mode_Out, uses the keyed initial/final vertex set to avoid
duplicate construction, and creates one pair for each flattened scalar.
Integer/Boolean scalars have no composite/discriminant/bound/tag components.

`flow-control_flow_graph-utility.adb:905-978` initializes vertex attributes
from Null_Attributes. At 923-928 the source out formal's initial vertex is
uninitialized: it is neither Mode_In/Mode_In_Out, a constant/loop parameter,
nor an entity outside the analyzed files. The excluded discriminant/bound/tag
branches cannot change that. At 965-970 its final vertex is exported and
explicitly uses the singleton formal. `flow_types.ads:68` defines exported
modes as Mode_In_Out through Mode_Out; Null_Attributes sets Is_Global false.

`flow-analysis.adb:3240-3397` processes each initially uninitialized source
scalar, scans for any use preceding initialization, and places its entire
object in Local_OK if safe. The mandatory source-written prefix precedes every
ordinary statement and no prefix expression reads any output; the admitted
body preserves initialization. Local_NOK is therefore empty for that formal.
The exported final vertex is retained when collecting Used, even when there
is no ordinary read of the output. The final set loop visits each element of
Local_OK minus Local_NOK once and emits its local success because Used contains
it. At 2760-2794, Emit_Info_Message_Local excludes explicitly initialized
E_Variable declarations, internal entities and function-result objects; none
is a source out formal. Its ordinary Proved_Msg branch at 3035-3057 emits exact
`initialization of "Name" proved`, rule UNINITIALIZED, severity info. No author
relaxed-initialization aspect is admitted. Closed finite procedure bodies have
no exception-only/no-return paths that trigger the early omission branch.

Thus each admitted out formal contributes exactly one successful record.
Ordinary locals with explicit initializers are skipped, while in/inout formals
start initialized. This supports both the exact pooled-formal witness and an
at-most-one-per-formal storage allowance. It does not replace source-derived
prefix correctness, complete procedure coverage or the audit of every emitted
runtime/proof obligation.
