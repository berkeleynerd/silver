from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import time

base = Path(__file__).resolve().parent
command = json.loads((base / "command.json").read_text())
command["started_at"] = datetime.now(timezone.utc).isoformat()
(base / "command.json").write_text(json.dumps(command, indent=2) + "\n")
start = time.monotonic()
with (base / "proof.log").open("w") as output:
    proc = subprocess.Popen(command["command"], stdout=output, stderr=subprocess.STDOUT,
                            start_new_session=True)
    (base / "process.json").write_text(json.dumps({"pid": proc.pid,
        "pgid": os.getpgid(proc.pid), "started_at": command["started_at"]}, indent=2) + "\n")
    code = proc.wait()
result = dict(command, returncode=code, elapsed_seconds=time.monotonic()-start,
              finished_at=datetime.now(timezone.utc).isoformat())
(base / "exit.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
raise SystemExit(code)
