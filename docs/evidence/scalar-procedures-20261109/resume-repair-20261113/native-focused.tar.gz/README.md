# Procedure_Updates native repair — #370 — 2026-11-13

Owner resumed the existing scalar procedure task. Own only output-profile source and necessary bounded ghost helpers in the native worktree. No #373 work. Selected role Astra Max; runtime model/effort not independently exposed; token/cost measurements unavailable.

Initial tracked status clean at 0d3d93ac258c9b7c6e491ec395164dbfc356f028; existing untracked tmp evidence preserved. Linux x86_64, 22 CPU pool, 62 GiB host memory. Procedure output source SHA256735f4bbb8cd0f9ecf816e17df3242113417f9ddeeafdf4bcb8ae2ecc25d41758 matches failed canonical full run20261110T181302-a4553e500d15 at primary c27f3ebab5. Original session/cache/2595input packet left intact.

## Diagnosis and next focused check

The final full run has exactly one failed Procedure_Updates Static postcondition at5412:20 (check5409:28), 30/31 proved proof checks. Its complete entity Why3 session has one unresolved split leaf def'vc.233, with all three canonical solvers timing out at30seconds; successful leaves and failed records preserved. Earlier focused warm success is not final assurance.

Before choosing a patch, export the exact failed generated context/session in an isolated copy using pinned gnatwhy3 and debug-save-vcs, one-step CVC5 only. This is read-only diagnosis of the retained failed VC, not whole-subprogram assurance or a prover-budget increase. Determine whether the model unfolding and record/array equality facts needed by the first residual leaf are present. Next repair must preserve all runtime behavior, full domains, exact model equality and all existing obligations. Validate the entire repaired routine plus complete changed helper contracts/callees/callers under canonical all-mode,level2,timeout30,CVC5/Z3/Alt-Ergo before any complete checkpoint. Native will reserve8workers while Lean source checks need14; explicit concurrent-work reason applies, not a habitual cap. Root owns whole native/Lean/regression integration and advisory policy.

## Selected hypothesis after exact export

Diagnostic run20261113T092111-08fcb8975ded completed in12.624wrapper seconds. Exit0 only reflects export; original postcondition still false and new one-step CVC5 attempt reports unrecognized answer. Full333331-byte SMT retains all return paths; no single failing return or counterexample is established. Model unfolding is present. `bool_eq5` expands raw Body_Scan equality through discriminants, fields and quantified Scalar_Flow/array equality; the loop invariant repeats that raw equality.

Candidate: introduce full-domain Static Same_Body with checked Logical_Equal over every Body_Scan component; introduce a proved raw-equality-to-logical-identity lemma using existing Lemma_Flow_Equality; call it on the existing two model expressions immediately after the loop invariants. Retain original raw equality invariant, all contracts/runtime statements/guards/domains. This gives first-class identity between invariant model outputs before return proofs, reducing contextual array transitivity. It is a hypothesis pending independent review and complete focused proof, not a declared root cause.

Whole-entity focused scope is `identity-trial/scope.json`,17complete entities including new logical predicate/bridge, all existing equality dependencies, update model/step/routine, invalid/token helpers and direct call-body caller. Source snapshot and original21line patch retained. This gate uses fresh `explore/native-repair-20261113` output (no old reports/sessions overwritten) and canonical budgets,8workers for concurrent Lean14. No runtime/source-domain/contract alteration.

## Independent static review and retained inputs

Critical reviewer found no material static issue with exact0bd0f4f2 candidate. Review: `/home/canto/src/github.com/berkeleynerd/silver/tmp/procedures-repair-review-20261113/native-equality-candidate-review.md`, with exact input manifest. Complete Body_Scan fields and discriminant, nested flow fields, zero-count/null-array domain, original equality invariant and static erasure were examined. Actual helper/routine/caller proof and Lean source integration remain required.

Run20261113T092540-3c74bc914df8 launched8workers on the new separate output. `identity-trial/prepared.json` binds2595input hashes; all corresponding bytes were captured and checked under `identity-trial/input-bytes` (5,300,647bytes). Primary source differs only in unrelated catalogue/report implementation plus later auditor/docs integration; actual output parser and dependency bindings match the retained baseline. Focused tooling identity is the native worktree's recorded identity, not root's later auditor fix.

Historical `call-prefix` run002858 exited0 on95d84db1f8 and proves the whole Procedure_Updates contract in retained log. Its complete routine block is byte-identical to failed final735f4bbb; surrounding source/context differs. `prior-focused-comparison.json` records this continuity without promoting prior evidence to final assurance.

## Actual focused result — 2026-11-13 09:49 UTC

Run20261113T092540-3c74bc914df8 finished with actual native-tool phase exit0 at09:49:25.978UTC and wrapper exit0 at09:49:26.951UTC; managed state success and reservation released. Wrapper1429.381seconds; managed1425.235seconds. The ordinary tool-summary returncode is null, while the actual phase-end event and wrapper both record0. The collector's first assertion incorrectly compared summary null with wrapper0; `collection-attempt1.json` preserves that scratch-only collection error and corrected actual-event comparison. No proof/source/run was retried.

All17selected entities are in all mode. All190proof and33flow checks pass, including Same_Body's native VC_INLINE_CHECK (Logical_Equal), complete Lemma_Body_Equality4proof/1flow, complete Procedure_Updates36proof/3flow, model13proof/2flow, step17proof/2flow and direct Procedure_Call_Body17proof/2flow. Every original180proof and30flow identity remains after exact source-line mapping, with only10new proof/3new flow checks. All94warning records match exactly after mapping. No missing entities/sessions, assumptions, skipped proof/flow, suppression, justification, or analysis stop occurs.

`identity-trial/audit.json`, `summary.json` and `selected-checks.json` contain the verified result. The64file61,269,544byte report/session/context packet is retained under `retained/` with a verified SHA256 manifest; all2595prepared/current/retained native project inputs match. Selectors/command/source are separately retained and hashed. Native worktree's older auditor identity is captured unchanged; final parent audit must use the approved advisory classifier update. Existing failed full and earlier warm successes remain intact.

The formerly failing postcondition is now proved. Its first branch reports CVC5 Valid at32.8704seconds and Alt-Ergo Valid at32.9147seconds; Z3 still times out at30seconds. These are the producer's measured times under the unchanged nominal `--timeout=30`/level2/all3 configuration, not an increased requested budget. No clean success or assurance from wall-clock margin is inferred. Remaining branches have proved attempts too. The successful focused result does not prove a unique cause of the earlier failure or replace the required complete native/provenance and Lean/source checkpoint. Full integration still needs its actual final result.
