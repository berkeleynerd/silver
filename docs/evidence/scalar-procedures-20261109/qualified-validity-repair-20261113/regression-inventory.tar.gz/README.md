# Final delivery inventory — 2026-11-13

Read-only routine inventory for #370/#29/#375/#390 delivery in draft PR371. Only this scratch directory was written; no test methods, builds, compilation, proofs, GitHub writes or tracked edits. Selected role Sol High; live model/effort not independently exposed. CLI memory not updated. Root integrated source623a3ce as primary51371ef82f during inventory. No successor work.

## Final regression command and inventory

`final-test-inventory.json`: discovery on primary51371ef82f found **691 occurrences/691 distinct IDs**, 56 test files, 57 module identities, no duplicates or failed imports. Discovery executes no test methods/setup. Prior import-side-effect review remains applicable: only tests/test_scalar_procedures.py changed among its captured scripts/tests. Current SHA a277542428d89fa12fcda20bd170497e99213aab54943de166726cc1e88a433c. One added ID, none removed:

`test_scalar_procedures.ScalarProcedureTests.test_qualified_validity_selector_is_not_a_writable_variable_read`

Procedure module now has25 methods. Existing methods also contain reviewed type-hiding, real/range-alias and compiled-array changes, so unchanged IDs alone never establish old execution applicability. Separate test_shared_bindings and tests.test_shared_bindings identities retain9 IDs each.

From `/home/canto/src/github.com/berkeleynerd/silver/tmp/scalar-procedures-370`, after ALL native/Lean reservations/artifact leases release and final compiler/generated/test inputs are stable:

```sh
python3 -B scripts/dev.py runs status
python3 -B scripts/dev.py test --task '#370' --jobs 22 --reason 'Final complete scalar-procedure delivery regression and sample suite on stable reviewed inputs; application GNATprove uses -j0, so reserve the entire released 22-worker host pool.'
```

Exact argv/cwd and conditional post-Rosetta rerun: `regression-command.json`. Recheck actual CPU capacity before using22. Root says native monitor is starting14workers; do not overlap tests. Explicit22 prevents silently taking a remaining share. unittest is serial but applications invoke GNATprove-j0; --jobs is a ledger reservation, not a nested-job cap. No affinity/TMPDIR wrapper needed; existing platform/Lean tests cover symlinked TMPDIR. test_samples.test_manifest_samples covers the exact Return multiple values admission, proof, build, execution and declared output inventory; retain actual reports/output.

**No final #370 all-tests execution exists.** Snapshot `managed-state.json` lists only #298 failed20261108T021923-5ef7f9b81de7 and #355 successful20261109T144553-8abe96c6e3ad as all-tests runs. Neither establishes current#370 regression completion. Prefer one full691-ID run. If it fails, preserve failure and obtain development.md's independent final-inventory applicability review plus all failed/affected reruns, or rerun the full suite. This exception only composes tests; full native/Lean/source audits remain mandatory.

## Issue status and evidence

All five issues OPEN; live bodies/comments retained in `issue-snapshot.json`.

| Issue | Established | Remaining |
| --- | --- | --- |
| #370 | Integrated native/proof/catalogue/samples and reviewed focused repairs, primary51371ef82f | Complete native audit, actual-source/Lean facade/module/axiom/provenance checkpoint, generated parity,691-ID regression/sample coverage, final independent acceptance, synchronized delivery records/Rosetta/closeout |
| #375 | Nine-file out/source expectations3958b2c66d from9247bbaf73 reviewed; focused092831 passed | Affected dependent source checks and complete authoritative final source/facade audit |
| #390 | Nativec1bbdc8/source51371ef82f; unchanged complete domains; native114106/model115847/admission115938/compiled120228/final focus120538 passed | Complete final native/source/Lean/regression validation and delivery disposition |
| #372 | Catalogue09d7990836 integrated: function/return/out, regenerated catalogue/assertion, focused build/native33-check success | Final combined acceptance and closeout; no new implementation |
| #29 | Repair791b122423 integrated/published; retained12-test230606 success; no refresh repair source change pending | Combined closeout; later support/render metadata changes need affected12-test rerun |

Run prefix: `/home/canto/src/github.com/berkeleynerd/silver/.git/silver-runs/linux-x86_64/78cde64c3e47f2cb/runs/`.

- `20261113T114106-f670a38c8f83/`: native20whole entities,274proof+50selected flow,494whole-unit flow; canonical policy,11workers. Packet `tmp/scalar-procedures-native-370/tmp/qualified-validity-repair-390/README.md`.
- `20261113T115847-e8f3df6741c0/`: full-domain scanner/model/caller focus,156actual modules/16,839declarations,20workers22threads.
- `20261113T115822-82e3985a07a9/`: matching compiler build success.
- `20261113T115938-18cbc675c0be/`: four focused admission methods success.
- `20261113T120228-1c2d0b4be837/`: changed compiled-array/argument fixture success with actual proof/build/execution.
- `20261113T120538-fed77dcce3b5/`: **SUCCESS**, finished12:14:42UTC; ProcedureNameActualsApart/ProcedureNameSourceCandidate,169actual modules,22workers22threads;544.014s total,503.752s build/7.360s audit, clean_build=false, no replay. Immutable retained lean-focused.log/evidence.json in run directory. This shape gate does not include complete output certificates.

Final source author packet `tmp/scalar-procedures-source-semantic-370/tmp/qualified-validity-repair-390/README.md`; independent repair review `tmp/procedures-final-review-1113/review-procedures-qualified-validity-repair-390.md`.

Earlier full native181302 FAILED, complete Lean214613 FAILED. Nov13 native095455/source aggregate110403 deliberately INTERRUPTED for#390; neither is complete acceptance. Source095546 separately interrupted for unconfirmed lifecycle cause. Successful chunks101154 belong to old0bd0 source: reuse matching objects after actual dependency invalidation, not old source-completion claims. Native stop packet `tmp/scalar-procedures-370/tmp/final-native-20261113/STOP-HANDOFF.md`; source stop packet `tmp/scalar-procedures-source-semantic-370/tmp/source-integration-resume-20261113/MONITOR-STOP-HANDOFF.md`. Old753/996-module/40-candidate totals are historical; capture current inventories after added selector module.

Primary sparse checkout omits committed docs/evidence locally. Read with `git show HEAD:docs/evidence/scalar-procedures-20261109/<packet>/README.md`, particularly resume-repair-20261113, qualified-validity-390-20261113, final-attempts-20261111. Missing local files do not mean missing committed evidence.

## Remaining checklist

1. Preserve final native/proof/tool/test/sample inputs and successful caches. Finish assigned complete native/source checkpoints with actual manifests, complete obligation discharge, full-domain source/caller integration, facade/module/axiom/provenance audit and generated-only parity. Review diagnostics, not exit status alone.
2. Cover691-ID final suite with matching compiler after proof reservations release. Record implementation target separately from later docs commits. Independent critical delta acceptance must account for final#375/#390 completion and material findings.
3. Update docs/scalar-procedures.md with `tmp/scalar-procedures-delivery-prep-370/completion-record-template.md`, actual evidence/resources/cache scope/review; reconcile pending summaries and preserve failed/focused history. Update language.md, docs/assurance.md procedure and application-policy sections, capacity record, trusted-boundary, README, roadmap capability/milestone, dated session memory together. Catalogue/sample fields already integrated; no hand-generated catalogue edits or domain/Oracle/capacity weakening.
4. At actual acceptance, apply/review `tmp/scalar-procedures-delivery-prep-370/rosetta-promotion.patch`: only scalar-procedures supported identifier, assess.js current-language update, only Return multiple values reassessed. Update rosetta/assessment-scalar-procedures-20261109.md with actual sample/assurance/review evidence; preserve retrieval/historical review provenance. Run ordinary `python3 rosetta/refresh.py --render`; review/stage source metadata, rosetta.md, progression.md and affected silver.md pages together. Prior83→84 Stage1/rank59/44-stage preview is conditional; verify actual render. Preserve broader procedures and other remaining constructs.
5. If support/render metadata follows full-suite success, rerun affected12test_rosetta.py methods using command JSON plus links/consistency/whitespace checks. No unchanged native/source rerun for docs/metadata alone.
6. Root owns issue/board/PR closeout: appropriate Fixes#370/#375/#390/#372/#29 only at actual completion. Reconcile#11 Return multiple values remaining-task list/mapping while broad stage stays open; refresh actual Stage fields after render, preserving#9/#10 closed/Stage1 and arrays#12 scope/status. Update draft PR371 description to exact final behavior/evidence. This inventory authorizes no merge.

Avoidable repeat work: no reimplementation of#29/#372, no duplicate matching helper/model/admission/compiled successes, no clean/cold reset, no rerun merely for a fresh directory or optional record fields. Complete validation remains outstanding. #373 is selected successor but none is started here; preserve separate worca work.
