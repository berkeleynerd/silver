from pathlib import Path
from collections import Counter
import datetime, hashlib, json
root = Path(__file__).resolve().parents[2]
out = root / "tmp/qualified-validity-repair-390"
result = json.loads((out / "result.json").read_text())
expected = "619f4fb8e2b0f318dac7c6278d5f644198816ce7733959ed71ca03917546b2b8"
assert result["source_sha256"] == result["source_sha256_after"] == expected
assert hashlib.sha256((root / "src/silver_output_profile.adb").read_bytes()).hexdigest() == expected
started = datetime.datetime.fromisoformat(result["started_at"]).timestamp()
report = root / ".silver/linux-x86_64/compiler/obj/explore/qualified-validity-repair-390/gnatprove/silver_output_profile.spark"
assert report.stat().st_mtime > started, "Seeded/stale report cannot establish current evidence"
x = json.loads(report.read_text())
entities = {int(k): v for k, v in x["entities"].items()}
selected = json.loads((out / "whole-entities.json").read_text())
names = {e["name"] for e in selected}
selected_ids = {i for i, e in entities.items() if e["name"].split(".")[-1] in names}
assert len(selected_ids) == len(names), (len(selected_ids), len(names))
counts = []
unresolved = []
for e in selected:
    ids = {i for i in selected_ids if entities[i]["name"].split(".")[-1] == e["name"]}
    proof = [c for c in x["proof"] if c.get("entity") in ids]
    flow = [c for c in x["flow"] if c.get("entity") in ids]
    bad = [c for c in proof + flow if c.get("severity") != "info" or c.get("suppressed")]
    unresolved.extend(bad)
    counts.append(dict(e, proof_checks=len(proof), flow_checks=len(flow), proof_rules=dict(Counter(c["rule"] for c in proof)), flow_rules=dict(Counter(c["rule"] for c in flow)), unresolved=len(bad)))
extra = [c for c in x["proof"] if c.get("entity") not in selected_ids]
assert not extra, "Unexpected nonselected proof checks require inspection"
audit = {"source_sha256": expected, "result_returncode": result["returncode"], "report": str(report), "report_sha256": hashlib.sha256(report.read_bytes()).hexdigest(), "report_mtime": datetime.datetime.fromtimestamp(report.stat().st_mtime,datetime.timezone.utc).isoformat(), "entity_count": len(counts), "proof_checks": sum(c["proof_checks"] for c in counts), "flow_checks": sum(c["flow_checks"] for c in counts), "all_unit_flow_records": len(x["flow"]), "unresolved_selected_obligations": unresolved, "pragma_assume": x["pragma_assume"], "skip_flow_proof": x["skip_flow_proof"], "skip_proof": x["skip_proof"], "warning_records": x["warn_error"], "entities": counts, "qualification": "Focused whole-entity native report inspection. Not a complete compiler assurance audit or Lean/source proof."}
(out / "focused-report-audit.json").write_text(json.dumps(audit,indent=2)+"\n")
print(json.dumps({k:v for k,v in audit.items() if k not in ["warning_records","entities","unresolved_selected_obligations"]},indent=2))
assert not unresolved, "Unresolved selected obligation"
assert not x["pragma_assume"] and not x["skip_flow_proof"] and not x["skip_proof"], "Unexpected proof suppression"
