# Native #390 repair evidence

Candidate: `7c98a02f3a4e8dbf7ec2dfb72d9d86f904f8a4c0`; `src/silver_output_profile.adb` SHA-256 `619f4fb8e2b0f318dac7c6278d5f644198816ce7733959ed71ca03917546b2b8`.

Owner-authorized bounded delivery repair under #390/#370/#29 / PR #371. No language, contract, precondition, type or interface change. Only the owned native worktree source was edited; primary/source worktrees and existing tmp evidence were untouched.

The scanner preserves each ordinary identifier step. After existing literal/attribute skips, it conditionally reads `.` followed by exactly `Input_Is_Valid`, with normal token case/boundary/trivia rules. A preceding contiguous dot prevents the second byte of `..` from hiding an upper-bound variable; the first byte cannot match the selector because the next byte is the second dot. Only this selected operation is admitted by the preceding actual-expression parser; unrelated selected names remain rejected there. No arbitrary-selector skip was added.

All declared helper domains are preserved: source length 1..4096, source first index 1, arbitrary source bytes allowed by the original Pre, zero/failure cursors, empty/reversed scan spans and any valid target name. `First > 1` guards the new `Text (First - 1)` access; the existing scan guards establish the current byte bounds. Both numeric/literal/attribute paths and generic identifier comparison remain byte-for-byte unchanged.

Whole-query skipping was rejected during design before running proofs because it jumps over generic identifier trace endpoints. Position-based qualifier lookbehind was rejected because it breaks the existing trivia-idempotence argument. The final conditional-expression shape preserves the existing typed source AST. Source/native authors and lead coordinated this exact shape before proof execution.

## Focused validation

Managed run `20261113T114106-f670a38c8f83` completed successfully at 2026-11-13 11:57:50 UTC, exit 0 with no failure keys. The fresh source-matching report proves 274 proof checks and 50 flow checks across all 20 selected entities. All 494 whole-unit flow records are also successful; GNAT aggregate is 768 checks. No assumptions or skipped proof/flow are present. Managed elapsed time was 1,002.546 s, including 997.132 s native tool time (wrapper 1,004.986 s). Canonical mode all, level 2, 30 seconds, CVC5/Z3/Alt-Ergo, warnings/error and checks-as-errors; no suppression or narrowed domains. Eleven native workers reserve half of the 22-CPU Linux host for concurrent eleven-worker Lean work. `command.json` is exact command; `native.log` streams diagnostics; `result.json`, `focused-report-audit.json` and `summary.json` retain the completed outcome and independent selected-obligation counts. The native `.spark` and summary report are copied beside them; their original isolated explore output is also retained.

The separate `explore/qualified-validity-repair-390` output was seeded with a reflink/copy of retained successful `explore/native-repair-20261113` sessions (run `092540`); the original output and normal managed proof cache were left untouched. Current reports are regenerated; this is neither a cold-run claim nor an audited complete success manifest. `session-seed.json` records the copy.

The selector includes every line from each listed helper's first declaration through its full body. `whole-entities.json` and `whole-entities.lines` are the exact covering selectors; they are explicitly included as managed run inputs.

| Helper | Whole source lines |
| --- | --- |
| `Skip_At` | 348–363 |
| `Name_After` | 364–381 |
| `Fixed_After` | 382–396 |
| `Match_Token` | 397–427 |
| `Take_Token` | 428–450 |
| `Invalid_Body` | 2701–2722 |
| `Body_Token` | 3018–3037 |
| `Lemma_Body_Equality` | 3262–3271 |
| `Actual_Name_Step` | 5132–5186 |
| `Actual_Name_Free_Model` | 5187–5201 |
| `Actual_Name_Free` | 5202–5236 |
| `Procedure_Target_Actual` | 5237–5280 |
| `Procedure_Actual_After` | 5281–5296 |
| `Procedure_Actuals_Model` | 5297–5320 |
| `Procedure_Actuals_After` | 5321–5357 |
| `Procedure_Update_Step` | 5358–5397 |
| `Procedure_Updates_Model` | 5398–5423 |
| `Procedure_Updates` | 5424–5470 |
| `Procedure_Callee_At` | 5471–5489 |
| `Procedure_Call_Body` | 5490–5516 |

## Round reporting

Selected role: GPT-6 Astra / Max; runtime model/effort not independently exposed. Token and cost telemetry unavailable. Host: Linux 7.0.14 x86_64. Design/candidate start captured at 2026-11-13T11:35:13.264060+00:00; managed tool durations are retained in `summary.json`. Live harness goal was null. No CLI memory was updated.

Outstanding: corresponding Lean/source proof result, root-owned regressions and independent review, integration and complete native/source/Lean checkpoints. The native source-only commit does not close #390 or #370.
