The final independent integration review of implementation `4553fd6a11` found an admission defect in #370. This is part of the current procedure delivery in PR #371, not deferred successor work.

`Actual_Name_Step` in `src/silver_output_profile.adb:5168-5179` treats the selector of `Silver_Arguments.Input_Is_Valid` as a read of a local writable object named `Input_Is_Valid`. `Procedure_Update_Step` applies that lexical scan to other actuals. The two names denote different entities: the qualified library query does not read the local object. language.md explicitly preserves qualified operations despite local operation-name hiding, and its procedure alias rule uses binding/read identity. `ScalarProcedureSyntax.conditionMentions` likewise treats `.inputValid` as no scalar-variable read.

The lead confirmed the exact reviewer fixture with the compiler built at 2026-11-13 09:53:54 UTC from parser SHA-256 `0bd0f4f21ae9faef7b3a4ab3bf64388b43cd1d7bf2780a40a4b353fc33b49a08` (binary SHA-256 `7b6a9a719020022df8e7b0d2a19216fc491f76ea614c7eeb3f61e76d8ee4ced5`):

- Qualified query with the colliding local writable name: rejected, exit 2; expected admitted.
- Control changing only the local writable binding to `Saved_Validity`: accepted, exit 0.
- Bare local-variable read aliased with its writable actual: rejected, exit 2, as required.

These were read-only `silver check` probes, with no compile, proof or test-suite run. The exact source is:

```ada
with Silver_IO;
with Silver_Arguments;
procedure Main is
   pragma SPARK_Mode (On);
   Input : constant String := Silver_Arguments.First_Or_Default ("old");
   procedure Copy_Flag (Value : in Boolean; Result : out Boolean) is
   begin
      Result := Value;
   end Copy_Flag;
   Input_Is_Valid : Boolean := False;
begin
   if Silver_Arguments.Input_Is_Valid then
      Copy_Flag (Silver_Arguments.Input_Is_Valid, Input_Is_Valid);
      if Input_Is_Valid then
         Silver_IO.Put_Line ("valid");
      end if;
   else
      Silver_Arguments.Reject;
   end if;
end Main;
```

The affected qualified-expression category is the admitted validity query; output/reject/initializer operations are not admitted input actuals. Cover both writable scalar kinds/modes, actual ordering, nested Boolean use and case/trivia without broadening alias rules. Attribute designators and quoted/numeric literal contents already have separate handling.

Completion criteria:

- Recognize the qualified validity operation as syntax during alias scanning (or an equally bounded correct solution), while preserving rejection of real variable read/write aliases.
- Update and independently review the native full-domain helper/caller contracts, matching Lean scanner/tree/raw-source equations and semantic/source bridges. Do not narrow domains, add an assumption, change the Oracle or silently change the language.
- Add discriminating positive qualified-collision and negative real-alias regressions, with existing name/literal/attribute controls retained.
- Pass focused complete-helper contracts before a new complete native and actual-source/Lean checkpoint, then final regression coverage and delivery acceptance.
- Retain the confirmed reproducer, review report and controlled-stop records for now-outdated final attempts; preserve useful caches and keep failed/interrupted outcomes labelled accurately.

Review evidence currently in `tmp/procedures-final-review-1113/`; lead confirmation in the integration worktree's `tmp/qualified-validity-confirmation-20261113/result.json`. Durable retention will be added to PR #371. Selected independent reviewer: GPT-6 Astra / Max; runtime settings not independently exposed.

Refs #370; PR #371.
