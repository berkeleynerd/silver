with Silver_IO;
with Silver_Arguments;
procedure Main is
   pragma SPARK_Mode (On);
   Input : constant String := Silver_Arguments.First_Or_Default ("old");
   procedure Copy_Flag (Value : in Boolean; Result : out Boolean) is
   begin
      Result := Value;
   end Copy_Flag;
   Saved_Validity : Boolean := False;
begin
   if Silver_Arguments.Input_Is_Valid then
      Copy_Flag (Silver_Arguments.Input_Is_Valid, Saved_Validity);
      if Saved_Validity then
         Silver_IO.Put_Line ("valid");
      end if;
   else
      Silver_Arguments.Reject;
   end if;
end Main;
