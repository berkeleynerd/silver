Published the confirmed #390 finding, independent integration review, exact admission probes, regression controls and stopped-checkpoint evidence in `be6d89fed9` on draft PR #371.

The native and source aggregate attempts were deliberately interrupted because a parser correction is required; complete acceptance is not claimed. Successful source chunks and all useful caches remain preserved. [Retained packet](https://github.com/berkeleynerd/silver/tree/be6d89fed9/docs/evidence/scalar-procedures-20261109/qualified-validity-390-20261113).

The bounded native candidate is a nine-line selector recognition change, with complete contracts and domains unchanged. It preserves ordinary identifier traversal and contiguous `..` range handling. Native complete-helper/caller checks, matching Lean model/raw-source proofs and independent repair review are in progress. Regression coverage now includes both kinds/modes/orders, nested and case/trivia query forms, real aliases, a valid String-slice upper-bound alias pair, and the compiled array/argument composition. The rediscovered final inventory is 691 test IDs; no final suite success is claimed.

#390 and #375 remain internal to this delivery. Next is focused repair acceptance, then a stable complete native/source checkpoint and final regressions. Separate worca/#373 work is preserved.
