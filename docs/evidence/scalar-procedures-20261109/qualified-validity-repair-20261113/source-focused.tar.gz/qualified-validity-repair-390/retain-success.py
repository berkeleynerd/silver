"""Retain an actually completed source run without changing its proof workspace."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

packet = Path(__file__).resolve().parent
root = packet.parents[1]
sys.path.insert(0, str(root))
from scripts import check_lean

parser = argparse.ArgumentParser()
parser.add_argument("run_id")
parser.add_argument("destination")
parser.add_argument("--actual-exit", type=int, required=True)
parser.add_argument("--completion-basis", choices=["original-exec", "managed-final-success"],
                    default="original-exec",
                    help="Record whether the original exec exit was observed or durable managed completion was used")
parser.add_argument("--artifact-module", action="append", default=[])
parser.add_argument("--allow-primary-proof-delta", action="store_true",
                    help="Retain focused repair evidence before the nine reviewed proof files are cherry-picked")
args = parser.parse_args()
assert args.actual_exit == 0


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


status = json.loads(subprocess.check_output(
    [sys.executable, "scripts/dev.py", "runs", "status", "--task", "#390", "--limit", "0"],
    cwd=root, text=True))
run = next(item for item in status["runs"] if item["run_id"] == args.run_id)
assert run["state"] == "success" and not run["active"], run
workspace = (root / ".silver/linux-x86_64/proof").resolve()
for active in status["runs"]:
    if not active["active"]:
        continue
    for resource in active["resources"]:
        resolved = Path(resource).resolve()
        assert not (workspace == resolved or workspace in resolved.parents or resolved in workspace.parents)
run_dir = Path(run["directory"])
stem = "lean" if run["scope"] == "complete" else "lean-focused"
evidence_path = run_dir / (stem + "-evidence.json")
if not evidence_path.exists():
    stem = "lean" if (run_dir / "lean-evidence.json").exists() else "lean-focused"
    evidence_path = run_dir / (stem + "-evidence.json")
evidence = json.loads(evidence_path.read_text())
assert evidence["run_id"] == args.run_id and evidence["axiom_audit"] == "passed"
assert all(phase["exit_code"] == 0 for phase in evidence["phases"])
log_path = run_dir / ("lean-proof.log" if stem == "lean" else "lean-focused.log")
detailed_provenance = "log_sha256" in evidence
if detailed_provenance:
    assert sha(log_path) == evidence["log_sha256"]
start_event = json.loads((run_dir / "events.jsonl").read_text().splitlines()[0])
audit_text = log_path.read_text().split("Lean phase audit started at", 1)[1]
audit = re.search(r"Silver axiom audit passed:\s*(\d+)", audit_text)
assert audit
sources, inputs = check_lean.capture_shared_inputs()
if evidence["scope"] == "complete":
    assert set(evidence["modules"]) == set(sources)
current = {str(path.relative_to(root)): hashlib.sha256(data).hexdigest()
           for path, data in inputs.items()}
assert current == start_event["inputs"]["sources"]
assert hashlib.sha256(json.dumps(current, sort_keys=True).encode()).hexdigest() == evidence["inputs_digest_sha256"]
if detailed_provenance:
    assert current == evidence["inputs_sha256"]
host = check_lean.native_layout()
workspace_sources, workspace_hashes = check_lean.capture_workspace_inputs(host)
assert sources.keys() == workspace_sources.keys()
artifact_snapshot = check_lean.compiled_artifacts(host)
if detailed_provenance:
    assert workspace_hashes == evidence["workspace_inputs_sha256"]
    assert artifact_snapshot == evidence["artifacts_sha256"]
for relative, expected in evidence["tools_sha256"].items():
    assert sha(root / relative) == expected, relative
primary = root.parent / "scalar-procedures-370"
primary_mismatches = {}
for relative, expected in current.items():
    actual = sha(primary / relative) if (primary / relative).exists() else None
    if actual != expected:
        primary_mismatches[relative] = {"source_sha256": expected, "primary_sha256": actual}
allowed_delta = {"proof/Silver/" + name + ".lean" for name in [
    "ProcedureNameScanner", "ProcedureNameNative", "ProcedureNameTraceTraversal",
    "ProcedureNameSelectors", "ProcedureNamePunctuation", "ProcedureNameCompoundTokens",
    "ProcedureNameIndexedReadings", "ProcedureNameValidityReading", "ReviewedOutputShape"]}
assert not primary_mismatches or (args.allow_primary_proof_delta and
    evidence["scope"] != "complete" and set(primary_mismatches) <= allowed_delta), primary_mismatches
for relative, expected in evidence["tools_sha256"].items():
    assert sha(primary / relative) == expected, relative
primary_modules = set(check_lean.project_sources(primary / "proof"))
assert primary_modules == set(sources) or (args.allow_primary_proof_delta and
    primary_modules | {"Silver.ProcedureNameSelectors"} == set(sources))

destination = packet / args.destination
destination.mkdir(exist_ok=False)
for path in [evidence_path, log_path, run_dir / "events.jsonl"]:
    shutil.copy2(path, destination / path.name)
(destination / "managed-record.json").write_text(json.dumps(run, indent=2) + "\n")
for relative in check_lean.CANDIDATES:
    target = destination / "generated" / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(workspace / relative, target)
    assert sha(target) == workspace_hashes[str(relative)]

artifacts = {}
for module in args.artifact_module:
    assert module in evidence["modules"], module
    relative = Path(*module.split("."))
    for area in ["lib/lean", "ir"]:
        directory = workspace / ".lake/build" / area / relative.parent
        for path in directory.glob(relative.name + ".*"):
            if not path.is_file():
                continue
            key = str(path.relative_to(workspace))
            digest = sha(path)
            expected = evidence.get("artifacts_sha256", {}).get(key)
            assert expected is None or digest == expected, key
            target = destination / "artifacts" / key
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
            assert sha(target) == digest
            artifacts[key] = {"sha256": digest, "bytes": path.stat().st_size,
                              "audited_artifact": expected is not None}
(destination / "post-success-workspace-hashes.json").write_text(json.dumps(workspace_hashes, indent=2) + "\n")
(destination / "post-success-artifact-hashes.json").write_text(json.dumps(artifact_snapshot, indent=2) + "\n")
(destination / "retained-artifacts.json").write_text(json.dumps(artifacts, indent=2) + "\n")
summary = {key: evidence[key] for key in ["run_id", "host", "scope", "targets", "lean_version",
    "lake_workers", "threads_per_process", "phases", "elapsed_seconds", "inputs_digest_sha256",
    "clean_build", "kernel_recheck"]}
summary.update({"utc": datetime.now(timezone.utc).isoformat(),
    "actual_exec_exit": args.actual_exit if args.completion_basis == "original-exec" else None,
    "completion_basis": args.completion_basis, "managed_success_verified": True,
    "captured_inputs": len(current), "project_module_inventory": len(sources),
    "actual_modules": len(evidence["modules"]), "fresh_declarations": int(audit.group(1)),
    "shared_inputs_and_tools_match": True,
    "detailed_run_provenance": detailed_provenance,
    "artifact_hash_basis": "matched run provenance" if detailed_provenance else "post-success snapshot; original run used standard focused integrity checks",
    "primary_inputs_and_tools_match": not primary_mismatches,
    "primary_pending_reviewed_proof_delta": primary_mismatches,
    "source_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
    "primary_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=primary, text=True).strip(),
    "retained_artifact_files": len(artifacts),
    "retained_artifact_bytes": sum(item["bytes"] for item in artifacts.values())})
(destination / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
