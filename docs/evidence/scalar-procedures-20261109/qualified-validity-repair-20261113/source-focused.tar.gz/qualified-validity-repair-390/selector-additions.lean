/-- Exact one-byte dot token at a fixed lexical cursor. -/
theorem fixedDot_after {text : Source} {position : Nat}
    (positive : position ≠ 0) (within : position ≤ text.length)
    (fixed : skipAt text position = position) (dot : Cursor.byteAt text position = 46) :
    fixedAfter text position "." false = position + 1 := by
  have trivia : Cursor.triviaPosition text position = position := by
    simpa only [skipAt, positive, ↓reduceIte] using fixed
  simp [fixedAfter, positive, trivia, fixedAt, Fin.forall_fin_succ, dot, lowercase,
    show 1 ≤ text.length + 1 - position by omega]

/-- The first range dot cannot consume a selector, because the second dot is
not the initial byte of the required word token. -/
theorem fixedValidity_dot_rejected {text : Source} {position : Nat}
    (bounded : position ≤ text.length + 1) (fixed : skipAt text position = position)
    (dot : Cursor.byteAt text position = 46) :
    fixedAfter text position "input_is_valid" true = 0 := by
  by_contra accepted
  obtain ⟨_, _, matched, _⟩ := fixedAfter_fields bounded accepted
  simp only [fixedAt, Bool.and_eq_true, decide_eq_true_eq] at matched
  have first := matched.1.2 ⟨0, by decide⟩
  simp [fixed, dot, lowercase] at first

/-- The package token ends with a letter, so its following trivia cannot
satisfy the native range exclusion. This holds for arbitrary ASCII case. -/
theorem validityPrefix_previous {text : Source} {position : Nat}
    (bounded : position ≤ text.length + 1)
    (accepted : fixedAfter text position "silver_arguments" true ≠ 0) :
    1 < fixedAfter text position "silver_arguments" true ∧
      Cursor.byteAt text (fixedAfter text position "silver_arguments" true - 1) ≠ 46 := by
  obtain ⟨positive, _, matched, after⟩ := fixedAfter_fields bounded accepted
  have finalByte := matched
  simp only [fixedAt, Bool.and_eq_true, decide_eq_true_eq] at finalByte
  have last := finalByte.1.2 ⟨15, by decide⟩
  change lowercase (Cursor.byteAt text (skipAt text position + 15)) = 115 at last
  change fixedAfter text position "silver_arguments" true = skipAt text position + 16 at after
  refine ⟨by omega, ?_⟩
  rw [after, show skipAt text position + 16 - 1 = skipAt text position + 15 by omega]
  intro dot
  simp [dot, lowercase] at last

/-- The complete selector branch at a cursor after an earlier non-dot byte.
The fixed token parser supplies the exact word boundary and trivia behavior. -/
theorem validitySelector_step {text : Source} {position limit targetFirst targetAfter : Nat}
    (bounded : position ≤ text.length + 1) (positive : 1 < position)
    (previous : Cursor.byteAt text (position - 1) ≠ 46)
    (accepted : fixedAfter text (fixedAfter text position "." false) "input_is_valid" true ≠ 0)
    (finishBound : fixedAfter text (fixedAfter text position "." false) "input_is_valid" true ≤ limit) :
    actualNameStep text position limit targetFirst targetAfter =
      ⟨fixedAfter text (fixedAfter text position "." false) "input_is_valid" true, true⟩ := by
  have dotPositive := Compose.Expressions.model_fixed_input_nonzero text _ "input_is_valid" true accepted
  have dotBound := fixedAfter_result_bound text position "." false (by decide)
  obtain ⟨_, within, matched, dotAfter⟩ := fixedAfter_fields bounded dotPositive
  have firstByte := matched
  simp only [fixedAt, Bool.and_eq_true, decide_eq_true_eq] at firstByte
  have first := firstByte.1.2 ⟨0, by decide⟩
  have dot : Cursor.byteAt text (skipAt text position) = 46 :=
    lowercase_symbol (by decide) (by simpa using first)
  change skipAt text position + 1 ≤ text.length + 1 at within
  change fixedAfter text position "." false = skipAt text position + 1 at dotAfter
  have start := ScalarExpression.skip_bounds text position bounded
  change position ≤ skipAt text position ∧ skipAt text position ≤ text.length + 1 at start
  have advance := Compose.Expressions.model_fixed_advances text _ "input_is_valid" true dotBound (by decide) accepted
  have noRange := skipAt_previous_not_dot (by omega) bounded (by omega) previous
  have same := fixedAfter_skipped bounded "." false
  have step := actualNameStep_validitySelector (targetFirst := targetFirst) (targetAfter := targetAfter)
    (position := position) rfl (by omega) (by omega) (by omega) dot (by omega) noRange
    (by rw [same]; omega) (by rw [same]; exact finishBound)
  simpa only [same] using step

theorem ActualNameFreeTrace.validitySelector {text : Source} {position limit targetFirst targetAfter : Nat}
    (trace : ActualNameFreeTrace text limit targetFirst targetAfter position)
    (bounded : position ≤ text.length + 1) (positive : 1 < position)
    (previous : Cursor.byteAt text (position - 1) ≠ 46)
    (accepted : fixedAfter text (fixedAfter text position "." false) "input_is_valid" true ≠ 0)
    (finishBound : fixedAfter text (fixedAfter text position "." false) "input_is_valid" true ≤ limit) :
    ActualNameFreeTrace text limit targetFirst targetAfter
      (fixedAfter text (fixedAfter text position "." false) "input_is_valid" true) := by
  have step := validitySelector_step (targetFirst := targetFirst) (targetAfter := targetAfter)
    bounded positive previous accepted finishBound
  have dotPositive := Compose.Expressions.model_fixed_input_nonzero text _ "input_is_valid" true accepted
  have dotAdvance := Compose.Expressions.model_fixed_advances text position "." false bounded (by decide) dotPositive
  have dotBound := fixedAfter_result_bound text position "." false (by decide)
  have callAdvance := Compose.Expressions.model_fixed_advances text _ "input_is_valid" true dotBound (by decide) accepted
  cases trace with
  | done => omega
  | step _ _ _ _ rest => simpa only [step] using rest

/-- Constructive admission for every well-tokenized qualified query whose
writable target has the selector's length, hence including its exact spelling.
There is no already-successful lexical trace hypothesis. -/
theorem actualNameFree_qualifiedValidity {text : Source} {position targetFirst targetAfter : Nat}
    (bounded : position ≤ text.length + 1)
    (accepted : fixedAfter text
      (fixedAfter text (fixedAfter text position "silver_arguments" true) "." false)
      "input_is_valid" true ≠ 0)
    (targetLength : targetAfter - targetFirst = 14) :
    actualNameFree text position
      (fixedAfter text (fixedAfter text (fixedAfter text position "silver_arguments" true) "." false)
        "input_is_valid" true) targetFirst targetAfter = true := by
  let prefix := fixedAfter text position "silver_arguments" true
  let finish := fixedAfter text (fixedAfter text prefix "." false) "input_is_valid" true
  have dotPositive := Compose.Expressions.model_fixed_input_nonzero text _ "input_is_valid" true accepted
  have prefixPositive := Compose.Expressions.model_fixed_input_nonzero text _ "." false dotPositive
  have prefixBound := fixedAfter_result_bound text position "silver_arguments" true (by decide)
  have dotBound := fixedAfter_result_bound text prefix "." false (by decide)
  have finishBound := fixedAfter_result_bound text (fixedAfter text prefix "." false) "input_is_valid" true (by decide)
  have dotAdvance := Compose.Expressions.model_fixed_advances text prefix "." false prefixBound (by decide) dotPositive
  have callAdvance := Compose.Expressions.model_fixed_advances text _ "input_is_valid" true dotBound (by decide) accepted
  have prefixFacts := validityPrefix_previous bounded prefixPositive
  have selectorStep := validitySelector_step (targetFirst := targetFirst) (targetAfter := targetAfter)
    (limit := finish) prefixBound prefixFacts.1 prefixFacts.2 accepted (Nat.le_refl _)
  have afterPrefix : ActualNameFreeTrace text finish targetFirst targetAfter prefix :=
    .step (by dsimp only [prefix] at *; omega) (by dsimp only [finish] at *; omega)
      (by simpa only [selectorStep] using accepted) (by simp only [selectorStep])
      (by simpa only [selectorStep] using (ActualNameFreeTrace.done accepted :
        ActualNameFreeTrace text finish targetFirst targetAfter finish))
  obtain ⟨firstPositive, _, _, prefixAfter⟩ := fixedAfter_fields bounded prefixPositive
  obtain ⟨bytes, identifier⟩ := fixedIdentifier_source bounded (by decide) prefixPositive
  have first := ScalarExpression.skip_bounds text position bounded
  change position ≤ skipAt text position ∧ skipAt text position ≤ text.length + 1 at first
  have positionPositive := Compose.Expressions.model_fixed_input_nonzero text position "silver_arguments" true prefixPositive
  have prefixAdvance := (Named.identifier_bounds identifier).2.2.1
  have firstStep := actualNameStep_identifier (targetFirst := targetFirst) (targetAfter := targetAfter)
    (after := finish) rfl positionPositive firstPositive (by dsimp only [prefix, finish] at *; omega)
    identifier (by dsimp only [prefix, finish] at *; omega)
  have different : Named.equalName text (skipAt text position) prefix targetFirst targetAfter = false := by
    have length : prefix - skipAt text position = 16 := by
      change prefix = skipAt text position + 16 at prefixAfter
      omega
    simp [Named.equalName, length, targetLength]
  have whole : ActualNameFreeTrace text finish targetFirst targetAfter position :=
    .step positionPositive (by dsimp only [prefix, finish] at *; omega)
      (by simpa only [firstStep] using prefixPositive) (by simp only [firstStep, different, Bool.not_false])
      (by simpa only [firstStep] using afterPrefix)
  exact whole.complete finishBound bounded

end Silver.Predicate
