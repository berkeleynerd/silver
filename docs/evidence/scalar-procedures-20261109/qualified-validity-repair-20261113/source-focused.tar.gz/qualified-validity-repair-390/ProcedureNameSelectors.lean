module

public import Silver.ProcedureNameIdentifierWords
public import Silver.ComposeBounds

@[expose] public section

/-! Only the validity selector is skipped. Its preceding dot is distinguished
from both bytes of a contiguous range delimiter; ordinary identifiers keep the
same scanner equation over arbitrary metadata and source prefixes. -/
namespace Silver.Predicate
open Compose

/-- The exact dot branch, including failed, truncated and out-of-range selector
lookahead. No successful expression or name-resolution premise is required. -/
theorem actualNameStep_dot {text : Source} {position first limit targetFirst targetAfter : Nat}
    (skipped : skipAt text position = first) (positive : position ≠ 0)
    (before : position < limit) (firstBefore : first < limit)
    (dot : Cursor.byteAt text first = 46) :
    actualNameStep text position limit targetFirst targetAfter =
      let selectorAfter := if first > 1 ∧ Cursor.byteAt text (first - 1) ≠ 46
        then fixedAfter text (fixedAfter text first "." false) "input_is_valid" true else 0
      if selectorAfter > first ∧ selectorAfter ≤ limit then ⟨selectorAfter, true⟩
      else ⟨first + 1, true⟩ := by
  have noNumber : (ScalarLiteral.read text first).after = 0 := by
    simp [ScalarLiteral.read, ScalarLiteral.mantissa, ScalarLiteral.numeral,
      ScalarLiteral.digitsTail, ScalarLiteral.digitValue, dot, ScalarLiteral.invalid,
      Guarded.invalidDecimal]
  have noName : nameAfter text first = 0 := by
    simp [nameAfter, Named.identifierEnd, Named.letter, dot]
  simp [actualNameStep, skipped, positive, Nat.not_le.mpr before,
    Nat.not_le.mpr firstBefore, dot, characterLiteralAfter, noNumber, noName]

theorem actualNameStep_plainDot {text : Source} {position first limit targetFirst targetAfter : Nat}
    (skipped : skipAt text position = first) (positive : position ≠ 0)
    (before : position < limit) (firstBefore : first < limit)
    (dot : Cursor.byteAt text first = 46)
    (plain : first ≤ 1 ∨ Cursor.byteAt text (first - 1) = 46 ∨
      fixedAfter text (fixedAfter text first "." false) "input_is_valid" true = 0) :
    actualNameStep text position limit targetFirst targetAfter = ⟨first + 1, true⟩ := by
  rw [actualNameStep_dot skipped positive before firstBefore dot]
  rcases plain with small | previous | missing
  · simp [show ¬first > 1 by omega]
  · simp [previous]
  · simp [missing]

theorem ActualNameFreeTrace.plainDot {text : Source} {position first limit targetFirst targetAfter : Nat}
    (trace : ActualNameFreeTrace text limit targetFirst targetAfter position)
    (before : position < limit) (skipped : skipAt text position = first)
    (firstBefore : first < limit) (dot : Cursor.byteAt text first = 46)
    (plain : first ≤ 1 ∨ Cursor.byteAt text (first - 1) = 46 ∨
      fixedAfter text (fixedAfter text first "." false) "input_is_valid" true = 0) :
    ActualNameFreeTrace text limit targetFirst targetAfter (first + 1) := by
  cases trace with
  | done => omega
  | step positive _ _ _ rest =>
      simpa only [actualNameStep_plainDot skipped positive before firstBefore dot plain] using rest

/-- A dot followed by the exact word token consumes the selector without a
spelling comparison. The previous-byte guard excludes a range's second dot. -/
theorem actualNameStep_validitySelector {text : Source} {position first limit targetFirst targetAfter : Nat}
    (skipped : skipAt text position = first) (positive : position ≠ 0)
    (before : position < limit) (firstBefore : first < limit)
    (dot : Cursor.byteAt text first = 46) (notFirst : first > 1)
    (previous : Cursor.byteAt text (first - 1) ≠ 46)
    (advance : first < fixedAfter text (fixedAfter text first "." false) "input_is_valid" true)
    (bounded : fixedAfter text (fixedAfter text first "." false) "input_is_valid" true ≤ limit) :
    actualNameStep text position limit targetFirst targetAfter =
      ⟨fixedAfter text (fixedAfter text first "." false) "input_is_valid" true, true⟩ := by
  rw [actualNameStep_dot skipped positive before firstBefore dot]
  simp only [notFirst, previous, and_self, ↓reduceIte, advance, bounded]

private theorem commentPosition_lineEnd {text : Source} {position : Nat}
    (positive : 1 ≤ position) (bounded : position ≤ text.length + 1)
    (within : Cursor.commentPosition text position ≤ text.length) :
    lineEnd (Cursor.byteAt text (Cursor.commentPosition text position)) = true := by
  rw [Cursor.commentPosition_equation text position positive bounded] at within ⊢
  split
  · rename_i stopped
    rcases stopped with atEnd | line
    · omega
    · exact line
  · exact commentPosition_lineEnd (by omega) (by omega) within
termination_by text.length + 1 - position

/-- If trivia advances to a byte in the source, the byte immediately before
that byte is whitespace. In particular, comments cannot manufacture the range
exclusion at the dot of a qualified operation. -/
private theorem triviaPosition_previous {text : Source} {position : Nat}
    (positive : 1 ≤ position) (bounded : position ≤ text.length + 1)
    (within : Cursor.triviaPosition text position ≤ text.length)
    (advance : position < Cursor.triviaPosition text position) :
    whitespace (Cursor.byteAt text (Cursor.triviaPosition text position - 1)) = true := by
  rw [Cursor.triviaPosition_equation text position positive bounded] at within advance ⊢
  split
  · omega
  · split
    · rename_i space
      have next := Cursor.triviaPosition_bounds text (position + 1) (by omega) (by omega)
      by_cases same : Cursor.triviaPosition text (position + 1) = position + 1
      · simpa only [same, Nat.add_sub_cancel] using space
      · exact triviaPosition_previous (by omega) (by omega) within (by omega)
    · split
      · rename_i comment
        have commentBound := Cursor.commentPosition_bounds text (position + 2) (by omega) (by omega)
        have next := Cursor.triviaPosition_bounds text (Cursor.commentPosition text (position + 2))
          (by omega) commentBound.2
        have line := commentPosition_lineEnd (by omega) (by omega) (by omega)
        have space : whitespace (Cursor.byteAt text (Cursor.commentPosition text (position + 2))) = true := by
          simp only [lineEnd, Bool.or_eq_true, beq_iff_eq] at line
          rcases line with line | line <;> simp [whitespace, line]
        have strict : Cursor.commentPosition text (position + 2) <
            Cursor.triviaPosition text (Cursor.commentPosition text (position + 2)) := by
          rw [Cursor.triviaPosition_equation text _ (by omega) commentBound.2]
          have further := Cursor.triviaPosition_bounds text
            (Cursor.commentPosition text (position + 2) + 1) (by omega) (by omega)
          simp only [show ¬Cursor.commentPosition text (position + 2) > text.length by omega,
            space, ↓reduceIte]
          omega
        exact triviaPosition_previous (by omega) commentBound.2 within strict
      · omega
termination_by text.length + 1 - position

/-- A known non-dot preceding a cursor stays non-dot across arbitrary valid
trivia, including comments, when another source byte remains. -/
theorem skipAt_previous_not_dot {text : Source} {position : Nat}
    (positive : 1 ≤ position) (bounded : position ≤ text.length + 1)
    (within : skipAt text position ≤ text.length)
    (previous : Cursor.byteAt text (position - 1) ≠ 46) :
    Cursor.byteAt text (skipAt text position - 1) ≠ 46 := by
  have start := Cursor.triviaPosition_bounds text position positive bounded
  have nonzero : position ≠ 0 := by omega
  simp only [skipAt, nonzero, ↓reduceIte] at within ⊢
  by_cases same : Cursor.triviaPosition text position = position
  · simpa only [same] using previous
  · have space := triviaPosition_previous positive bounded within (by omega)
    intro dot
    simp [dot, whitespace] at space

end Silver.Predicate
