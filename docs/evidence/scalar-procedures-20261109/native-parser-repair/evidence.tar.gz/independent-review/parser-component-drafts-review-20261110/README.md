# Independent review of two unselected parser drafts — #370

2026-11-10, approximately13:49–13:56UTC. Project-selected review category is
Astra Max; the live model/effort is not independently exposed. This review made
no tracked edits, native-input changes or proof runs. Both drafts remain
unselected. **No material semantic or full-domain issue found.** Proof success
and final source acceptance remain pending selection and validation.

Both drafts are based on
`336cba3eac92dc2833336ec4b181ac6f614e86cd2cec3600c401304c235296cb`.

| Draft | Full candidate SHA-256 | Patch SHA-256 |
| --- | --- | --- |
| `procedure-body-draft` | `9c0c102c1447c9cced1c37f99350396e442e3b7977859ef550a1832d8c4b02ec` | `31dac2caa46282d0c6ec3c48678932032f5df946000b85e9b6cf0a4b58865208` |
| `chain-join-draft` | `c1165a155ccaa2f61c32c73b59c25db17f4ed76f28a8fac91eddafad761f5c29` | `ce8dde74eff16da477dafbb8aad7495017cfce54e0dd4f4e40c6122ecdcda5ac` |

`manifest.json` records input identities. Reversing each exact patch recovers
the entire common base hash, and immutable candidate/patch/input copies are
retained in the adjacent draft directories. The live native source was still
`56edb5ec920312d2fcece638d3095e5164c4a67315c393e659140d1f807ce04d`.
After its active run ends, apply selected **rebased patches**, never either old
complete candidate over the named-return source.

## Body_Of contract and removed caller assertion

The runtime body and its raw `Body_Of_Model` equality are unchanged. The new
count/pointwise facts follow directly from the existing assignment
`Result.Facts := Initial_Flow (Context_Of (Scan))` and `Initial_Flow`'s complete
postcondition. Neither function has a new precondition. Arbitrary typed
`Scan_Result` values, invalid parser states, arbitrary interval values, and
Count=0 remain admitted. `Body_Environment` preserves the scalar count for
every environment, and the null1..0 value range makes the pointwise condition
vacuous without an index access.

The removed caller formula is recovered exactly: `Context_Of` ignores the
scan's Assigned/Output flags, and Procedure_Body_At changes only
`Declaration_Count` in the resulting context. Its Scalar_Names and their bounds
therefore match the new helper postcondition. This relocates the same guarantee
to a stronger full-domain helper boundary; it must not be treated as permission
to drop a failed check without proving that helper contract and every affected
caller. Full native gates are Body_Of (including the new indexed contract), its
unchanged Initial_Flow dependency with applicable evidence, and complete
Function_Body_At, Procedure_Body_At and Read_Statements. All other caller
obligations remain required.

Required Lean changes **if selected**:

1. `proof/Silver/PredicateAdapterEnvironment.lean`, `Wrappers.bodySpec`: retain
   the original model-equality conjunct and source-check both additional
   count/pointwise conjuncts exactly. Existing model equations, refinement
   meaning and count theorem remain valid; do not add stronger model premises.
   `PredicateBodySourceCandidate.candidate_adapterWrappers` automatically checks
   the updated complete spec through its existing `Checked` structure.
2. `proof/Silver/ProcedureDeclarationBodyNative.lean`: remove the now-absent
   `.staticInitialFlow scan context` wrapper from the ordinary body tree. Its
   accepted generic erasure theorem already establishes unchanged evaluation;
   the complete renderer must match the selected actual body.
3. If retiring the now-unused exact assertion constructor, also remove its
   isolated definition/renderer/guards/erasure controls in
   `ProcedureDeclarationSyntax.lean` in that same bounded change. This is not
   needed to change the runtime model, and no generic pragma skipping may
   replace it. Recheck the applicable model/tree/guard targets after the change;
   preserve and reuse earlier matching model artifacts.

## Componentwise join contract and ghost identity lemma

`Join_Into` retains its equal-count Pre, raw Joined equality and unchanged
runtime implementation. Its new postconditions expose exactly its existing
computation: unchanged discriminant, the path join, and each interval join.
They use `Left'Old`, not the already mutated Left. No validity, reachability,
nonempty-flow or canonical-interval premise is introduced.

The new lemma's premise covers every Scalar_Flow component. Count equality fixes
all Values bounds to1..Count, so the pointwise premise covers the complete array,
including fixed bounds1..0 for Count=0. `Paths.Join` and `Scalars.Join` are total
on these typed values; empty/noncanonical intervals retain the exact existing
normalization semantics. The Joined contract supplies the same components for
Model. Same_Path, Same_Interval and Same_Values then establish Same_Flow; equal
record fields and identically bounded arrays establish the retained raw equality.

There is no circular desired-equality premise: the call to Lemma_Flow_Equality
is only for `Model`, defined as Joined(Before,Right), and that same Joined value.
It does not assume Result=Joined. The immediate pre-join snapshot and all caller
assertions remain; only the failed raw-equality bridge call is replaced. The new
lemma and the replacement are Ghost=>Static, preserving runtime behavior.
Its proof may still need explicit count/bounds/transitivity steps for GNATprove;
this review makes no solver-success prediction.

Required Lean changes **if selected**:

1. `proof/Silver/PredicateFlowSourceBridge.lean`, `joinIntoHeader`: retain the
   rendered old-value Joined equality and append the exact new conjuncts. The
   existing interpreted join model and full-domain equal-count interface remain
   unchanged, since their original guarantee is retained.
2. Check the new lemma's entire Ghost/Global/Pre/Post header. The smallest
   existing route is a `lemmaJoinIdentityHeader` and corresponding
   `procedureHeader "lemma_join_identity" "is"` field in
   `FlowSourceBridge.Checked`. `PredicateFlowSourceCandidate.native_flow_checked`
   already constructs every field and propagates the result through
   `NativeSourceChecks.Checked.flow` to the authoritative source check.
   No new import or facade module is needed. Grouping it instead with the existing
   equality lemmas in NativeSourceChecks/NativeShapeCandidate/SourceCandidate
   is possible but would require additional explicit fields and assembly edits;
   that larger route is not necessary.
3. No new typed runtime node or whole-chain model law is needed. The native
   worker's unchanged complete Static postcondition still links Read_Chain_Into
   to its checked recursive model. The new ghost helper requires complete native
   proof, exact Ghost/header checks, and final source inclusion; a matching pin
   alone is insufficient.

Native gates are complete Join_Into and Lemma_Join_Identity, applicable unchanged
Joined/flow-equality dependencies, then full Read_Chain_Into, Conditional_Body
and Alternative_Body. Count=0 and all arbitrary flow values allowed by the Pre
must remain in every checked domain. Existing assertions and raw/logical
postconditions are retained; every new index/precondition obligation is required.

## Shared final integration

Both changes require a matched ReviewedOutputShape and complete output-source
certificate refresh on the final selected bytes, then the complete source,
module and axiom audit. The separately strengthened parser-state equality lemma
still requires the pending ComposeArrayDeclarationSource header update. Source
pins remain untouched while native candidates are unsettled. No guarantee,
annotation policy, proof budget or source domain is weakened by this review.

The report repair is separately complete at primary commit
`cf2882170d83f063b67cb02a9ddeebcbd20d377f`:386proof/12flow checks across7complete
entities, with the three existing classified arithmetic advisories. Its source
is95d4758e and auditor SHA-256 is
`bed6337ae6b7fa65dff44296a7fbf632eafb326fa832dbcb70335ddca46e54bd`;
live files match that commit. Final integrated capture still awaits the selected
parser/source batch; report success does not complete the capability by itself.
