# Callable metadata append — independent source and domain review

**No material semantic or full-domain defect found in candidate `80fea55e`.**
The two generic lemmas state consequences of the actual `Append` expressions and
`Valid_Metadata` definitions. Each caller's existing precondition supplies every
new premise, including on its early-failure paths. The draft remains unselected
and unproved at this review; the null bodies are not accepted assumptions.

Review by `/root/scalar_procedures_source`, 2026-11-10, from approximately
15:26 to 15:34 UTC. Project-selected critical-review setting: Astra Max; live
model/effort is not independently exposed. Token/cost measures unavailable.
The bounded authorization permits only read-only review and semantic-worktree
`tmp/` evidence. No tracked/native files changed, and no proof job was started.

Base SHA-256:
`aa1f3722bedf706e3aa7906e418d68ef5087570bd2b3522c17f5bc2d9072a453`.
Candidate SHA-256:
`80fea55eaec8379b901c6995fe3bbee1d13a9397bd5b9ad60324caadef3750b8`.
Patch SHA-256:
`693ef80d5663999e690381fc4320833bf63f61559e038d9f0c65306ca6b33e78`.

`check_delta.py` independently verifies the exact unified patch and reconstructs
the entire base by removing only the two new lemma definitions and their two
calls. It also checks that each lemma's metadata/signature arguments are the
exact token-normalized arguments of the caller's unchanged return-time `Append`.
The candidate, base, patch, supplied input record, complete new definitions,
native dependency snapshots and precise Lean input hashes are retained here.
See `review.json`; live native source still matched the base at 15:31 UTC.

## Generic lemma argument and complete domain

Both actual `Append` expressions increment `Environment.Count` and replace
`Items (old Count + 1)`. They leave `Parameter_Count` and the entire `Parameters`
array unchanged. Capacity ensures the increment and array update are in range.
To establish the complete returned `Valid_Metadata` conjunction:

1. Every active formal is the same formal as before, so its positive name span
   and nonempty interval follow from the old metadata validity.
2. Each old active signature is unchanged and refers to the unchanged parameter
   count, so its complete old validity remains true.
3. The one new active signature is `Item`. Every predicate required for this
   signature appears explicitly in the new lemma precondition. For functions,
   this includes the nonempty `Result_Bounds`; the procedure predicate has no
   result-kind or result-bounds fields.

The proof does not require a nonempty old signature table. At `Count = 0`, the
old signature quantifier is empty and slot 1 is replaced, whatever it previously
contained. Every inactive signature slot may contain arbitrary representable
values. Slots after the new active end are unchanged and still excluded from the
validity quantifier. Inactive formal slots are likewise arbitrary and unchanged.
The final capacity slot (`old Count = Max_* - 1`) is covered.

`Item.Formal_First` may identify any nonempty segment within the active formal
prefix; the generic lemma does not demand a suffix, distinct names, disjoint
formal ranges, ordered signature ranges, or a freshly constructed environment.
The function lemma admits both `Integer_Kind` and `Boolean_Kind` with every
nonempty representable result interval. In particular it does not add a Boolean
`0 .. 1` restriction. Both active formal kinds and all existing nonempty formal
bounds remain admitted. Procedure formal modes may be Input, Output or
Input_Output in any mixture, including all-Input; the metadata predicate imposes
no writable-mode requirement, and neither does the lemma.

When `Parameter_Count = 0`, no signature can satisfy the existing metadata
signature clauses `0 < Formal_First <= Parameter_Count` and `Count > 0`.
The lemma preserves that existing validity definition; it does not exclude any
otherwise valid appended signature. This is distinct from the allowed old
signature-table `Count = 0` with an already populated formal table.

## Caller premises and evaluation order

For either caller, let `P` be `Frame.<catalog>.Parameter_Count` and `F` its
corresponding first-parameter field. The unchanged caller precondition gives
`1 <= F <= P`, hence `N = P - F + 1` satisfies `1 <= N <= P <= Max_Formals`.
Thus the aggregate's count is representable and positive, and the lemma's
segment bound is equality, `N <= P - F + 1`. Native `Max_Formals = 4096 / 7`,
so no machine-integer overflow is involved in this arithmetic.

The caller's `Valid_State (Text, Frame)` contains the exact catalog validity
needed by the corresponding lemma. Its other existing conjuncts directly give
the text domain, catalog capacity, `First > 0`, `Valid_Name_State (First, After)`,
and, for functions, nonempty `Result_Type.Bounds`. No new fact about
`Result_Type.After` or its kind is needed. The new arguments use `Frame` exactly
as the final append does; they do not substitute the different `Outer` catalog.

Each call occurs after the unchanged `Locals` constant initializer and before
the existing `Locals.Position = 0` guard. All its premises already follow from
entry preconditions, so it is sound even if `Locals` is invalid, or the incoming
frame/outer position is zero. It requires no successful body, canonical state,
fresh frame, or metadata relationship beyond the existing caller precondition.
The arguments are input-only, and each helper is `Ghost => Static, Global => null`.
No runtime expression, return aggregate, executable order, caller contract or
input domain changes. Complete native verification must still discharge the
new argument-safety/precondition checks on every path.

## Exact Lean integration recommendation

Unlike the ordinary Boolean loop wrapper, both callable body implementations
have fully rendered typed command trees. Their two syntax types are separate;
updating only `ProcedureDeclarationSyntax.lean` would miss the function body.
The smallest explicit route is:

| Existing file | Required local change if this exact candidate is selected |
| --- | --- |
| `FunctionDeclarationNative.lean` | Add one precisely named Static-call constructor to its `Command`, accepting `Expr .source`, `Expr .metadata`, `Expr .signature` and a continuation. Insert it into `functionBodyBody` immediately after `.beginBody` and before the first guard, using the existing return signature expression. |
| `ProcedureDeclarationSyntax.lean` | Add the corresponding exact procedure-lemma constructor, accepting `Expr .source`, `Expr .procedures`, `Expr .procedureSignature` and a continuation. |
| `ProcedureDeclarationBodyNative.lean` | Insert that node at the matching body-entry site, using the existing procedure return signature. Also carry forward the separately selected removal of the old `.staticInitialFlow scan context` node from this body tree. |
| `FunctionDeclarationSource.lean` | Add the complete function-lemma header expectation and a field of `SourceChecks.Checked` using `Silver.SourceBridge.procedureHeader "lemma_function_metadata_append" "is" tokens`. |
| `ProcedureDeclarationHighSource.lean` | Add the complete procedure-lemma header expectation and corresponding `HighSourceChecks.Checked` field with `procedureHeader "lemma_procedure_metadata_append" "is" tokens`. |
| `FunctionSourceParts/DeclarationOrdinaryFunctionBodyAt.lean` and `ProcedureDeclarationHighSourceParts/Body.lean` | Recheck the changed ordinary body against its full rendered tree; add each new header check in the existing fragment module. |
| `FunctionSourceCandidate.lean` and `ProcedureDeclarationHighSourceCandidate.lean` | Populate the new checked-header fields from those fragment theorems. |

Use the exact declarations in `helper-definitions.adb.txt`, including argument
modes/types, `Ghost => Static`, `Global => null`, every Pre clause and the full
Post. These inline definitions end their headers at `is`; they have no separate
forward spec. The existing `headers` lists use `functionHeader`, so do not insert
these procedures there. Separate fields avoid renumbering all existing header
fragments. The existing unique procedure extractor rejects duplicate matching
definitions.

Each new command renderer must spell only its fixed lemma name and all three
typed argument renderings, commas, parentheses and semicolon, then the exact
continuation. Its evaluator returns the continuation's evaluation without
evaluating ghost arguments. Extend `scoped` to check all arguments and the
continuation in the same scope; the calls introduce no binder. Extend
`wellFormed` with the existing argument-value and recursive well-formedness
checks, including the signature aggregate. Do not introduce arbitrary procedure
names, raw token payloads or a generic ghost/pragma skipping rule.

Prove each erasure equation for arbitrary linked `Calls`, `Locals`, arguments
and continuation (definitionally `rfl` under this design), and retain positive
and malformed/missing-binding/continuation controls. The complete native helper
and caller proofs discharge the contracts; the erasure theorem does not prove
or assume the helper's validity Post. The exact checked Static header supplies
the same runtime-erasure route already used for the parser-equality helper.
No new runtime `Function`/`Calls` member, metadata operation, whole-body law, or
strengthened `BodyDomain`/`OrdinaryEquations`/`HighEquations` premise is needed.

The existing function and procedure `body_denotation` and model equations should
retain their statements because the new nodes erase. They must be rechecked,
not presumed compiled. Batch the focused `FunctionDeclarationModelSource` and
`ProcedureDeclarationModelSource` targets when authorized and resources are free.
`FunctionSourceChecks` and `ProcedureDeclarationHighSourceChecks` transport the
strengthened records through their existing authoritative-source equality;
their top-level consumer structures do not need duplicate lemma fields.
Keeping the new fragment theorems in the existing modules avoids new facade
imports. Final selected combined bytes still require the matched full output
certificate/pin and complete source/adapters/facade validation, together with
all previously recorded parser-header changes.

## Evidence boundary and handoff

The earlier whole-nine-helper run `143914-1c2a2b56bc13` passed 227 proof and 15
flow checks on base `aa1f3722`; it does not cover these new lemmas. The seven-caller
run `145720-331c1a61ff8d` was still active with 22 workers at 15:31 UTC. Keep its
base source frozen until it finishes. The supplied failure diagnosis is an
interim decoded-Why3-shape report, not a final `.spark` result reviewed here.

After native selection, both complete new lemmas and relevant Append/validity
dependencies need canonical checks, followed by both complete body callers with
all old and new obligations. Retain the other caller outcomes from the current
batch and final complete assurance. No solver-success prediction or claim that
the two helper posts alone complete #370 is made. The semantic tracked tree
remains clean at `9f79c8d2df`; harness goal was null on resumption; CLI memory was
not updated.
