# Boolean array early-return bridges — independent source review

Reviewed 2026-11-10, completed approximately 14:30 UTC, by
`/root/scalar_procedures_source`. Selected review category: Astra Max, as recorded
in the prior assignment and repository policy. Live model/effort is not
independently exposed. Total elapsed time, tokens and cost are unavailable across
the context handoff. This is a bounded read-only review; only semantic-worktree
`tmp/` evidence was written. No tracked file or native input was edited, and no
proof job was launched.

**No material semantic or full-domain issue found in this exact draft.** Native
verification of the complete changed helper, all old and new obligations, and
affected callers remains required. This review neither identifies the branch
responsible for the previous unresolved postcondition nor predicts solver success.

Base SHA-256:
`56edb5ec920312d2fcece638d3095e5164c4a67315c393e659140d1f807ce04d`.
Candidate SHA-256:
`82491d2020d98787e9e8d67a1da17d2f93adbb97e93a76312c2fa0f57b314fe7`.
`check_delta.py` independently reconstructs the whole candidate by expanding only
the three one-line early returns, then checks the supplied unified patch byte for
byte. Immutable base/candidate/patch/input copies and `review.json` are retained
here. The native live source still matched the base at 14:29 UTC.

The three sites add the existing `Ghost => Static, Global => null`
`Lemma_Parser_State_Equality`, with `Invalid_State` and the model evaluated at the
original immutable input arguments. Its premise is `Same_Parser_State`; its
complete strengthened post exports both raw Ada equality and that same logical
relation. The lemma itself already passed whole-subprogram canonical run
`124550-040b6b213722`. No new equality law or trusted premise is introduced.

Let `M0` denote the model at those original arguments. The new premises follow
over the complete unchanged declared domain:

1. **Entry, candidate line 2157.** `Current` was initialized to `Position` and
   has not changed. When it is zero, the model's first branch returns
   `Invalid_State`. This branch precedes `Parsed = Length`, including
   `Parsed = Length = 0`. Thus the premise is reflexive logical state equality.
2. **Initializer failure, line 2193.** The loop runs only with
   `Parsed_Count < Length`, and its current position is nonzero. `Before` copies
   the current `Result`. The initializer's existing complete Static refinement
   makes `Value_After = 0` the same failure selected by the recursive model.
   Consequently the current model, also saved as `Tail`, is `Invalid_State`.
   The loop retains both raw equality and `Same_Parser_State` between `M0` and
   that current model. The symmetry of the explicit fieldwise logical relation
   supplies the requested `Same_Parser_State (Invalid_State, M0)` orientation.
3. **Missing comma, line 2216.** Before any mutation, the existing assertion
   establishes `Tail = Model (Next_State, Next_Position, Next_Parsed)` (with the
   unchanged other arguments). `Next_Parsed` is the old count plus one; the
   actual increment makes the executable count equal to it. The branch guard
   therefore selects the same `Take_Token (Text, Value_After, Comma)` expression
   in `Next_Position` and the actual assignment to `Current`. `Take_Token` has
   no global state, and these inputs do not change. On the early-return branch,
   `Current = 0` hence `Next_Position = 0`; the recursive model's first branch
   yields `Invalid_State`. Combining this with the saved pre-mutation `Tail`
   equation and entry-to-current model invariant supplies the same premise.
   **This reasoning does not use any assertion after the early return**, nor
   does it need the post-mutation `Result = Next_State` assertion.

All model calls added as lemma arguments use the original valid inputs, so their
preconditions are exactly covered by the wrapper's unchanged precondition. No
assumption that the incoming parser states are initial/empty/successful is used.
Arbitrary permitted metadata, stored values, mask states and capacity endpoints
remain admitted. At nonzero position with `Parsed = Length`, the unchanged normal
return handles completion. There are no new runtime values, executable calls,
state writes, branches, altered loop invariants, contract weakenings or domain
restrictions; the only additions are erased Static lemma calls.

`ComposeBooleanArraySource.lean` checks the unchanged recursive model body and
complete model/executable headers. Its existing correspondence route relies on
the native wrapper's complete Static postcondition. This local proof-only change
needs no new Lean runtime command constructor or model equation. Final selected
combined native bytes still require `OutputBodyCertificate`, the matched
`ReviewedOutputShape` pin, and complete source/adapters/facade validation. The
separate strengthened parser-equality header still requires the pending exact
`ComposeArrayDeclarationSource.lean` expectation update; it remains unapplied.

For context, canonical named-return run `131635-d495beb427bd` failed with 58/59
proof checks and 2/2 flow checks, retaining the unresolved raw model equality.
Diagnostic `142102-d98c8587a63d` ended at 14:25:30; it was partial diagnostic
evidence, not assurance. At this review's 14:29 status capture, diagnostic
`142725-9349059da1ed` was active on the unchanged base with all 22 workers.
Preserve that frozen input; any later validation must recheck managed state.
Harness goal was null on resumption. CLI memory was not updated.
