# Final parser Short_Or symmetry — bounded source review

**No material semantic or full-domain issue found.** The new Short_Or ghost
block is exactly the existing Short_And block with `When_False` replaced by
`When_True`. Runtime operations, all existing assertions, and complete contracts
remain unchanged. This is source review, not a claim of native proof success.

Reviewed by `/root/scalar_procedures_source`, approximately 16:15–16:19 UTC,
2026-11-10. Selected source role: Astra Max; live model/effort is not independently
exposed. Token/cost measurements unavailable. Only this scratch directory was
written; no tracked/native inputs changed and no proof jobs were launched.

Exact combined candidate SHA-256:
`ffdc4fa654056aae2c1b4d59fd1bb2b2dfae0077895158b91a1634d34ca63137`.
Previously reviewed metadata candidate:
`80fea55eaec8379b901c6995fe3bbee1d13a9397bd5b9ad60324caadef3750b8`.
Short_Or-only patch SHA-256:
`fae1ac368f053f82d0b5a4fca13d6dcfd2aca20b4067f1ec9376234036b36b7d`.

`review.json` records exact patch and input hashes. Independent extraction
verified the two blocks' exact symmetry and reconstructed the entire metadata
candidate by replacing only the new Short_Or block with the old unchanged
`Join_Into` statement. Both supplied patches match independently generated
unified diffs. Complete immutable input copies are retained here.

The new `Join_Input` is a Static constant copying `Result.When_True` immediately
before the unchanged join. Its raw equality to that input establishes the
existing `Lemma_Flow_Equality` premise. The branch already establishes
`Same_Flow (Result.When_True, Before.When_True)`, so the new snapshot-to-Before
cut follows. No runtime operation intervenes between the snapshot and join.

`Join_Into`'s complete strengthened Post gives unchanged count, the exact path
join of its old input and Right, and every joined interval value. The old input
is precisely `Join_Input`; these are all the existing `Lemma_Join_Identity`
premises. That proved lemma exports both logical and raw equality to
`Joined (Join_Input, Right.When_True)`. Substituting the established snapshot
identity yields the added Same_Flow cut against `Before.When_True` and the
retained original raw assertion. There is no assumed whole-chain law or
assumption of the desired post-join equality.

The argument covers every count and flow admitted by the unchanged caller Pre.
`Result`, `Before`, `Right` and the snapshot share `Active_Count`; each flow's
values have bounds `1 .. Count`. At Count 0 these are identical null ranges
`1 .. 0`, all pointwise premises are vacuous, and no element is accessed by the
new proof block. No positive-count, reachable-path, nonempty/canonical-interval
or fresh-state premise is added. Existing arbitrary path/interval cases and
exact normalization in the total join operations are preserved.

The Short_Or runtime sequence remains join of When_True, assignment of
`Right.When_False` into When_False, and the existing later cursor update.
The added declaration is Ghost Static, both lemma calls are Ghost Static and
Global null, and both added assertions are Static. The enclosing declare block
introduces no executable data or changed runtime call order. All pre-existing
checks remain and every new call/discriminant/argument obligation must pass in
the complete native caller gate.

**Additional Lean impact is limited to the final selected source bytes.**
`PredicateNativeWorkers.Checked` retains the unchanged complete `Read_Chain_Into`
headers and exact Static `Condition_Tail` refinement. `PredicateNativeSourceChecks`
checks the unchanged recursive model body. This worker's ordinary loop body is
connected by its verified native Static postcondition; it has no separately
rendered command tree requiring a new node for this local proof block.

The already pending complete `Join_Into` header strengthening and exact
`Lemma_Join_Identity` header/Checked field in `PredicateFlowSourceBridge` serve
both branch calls. No second header field, generic ghost skipping, new model
equation or stronger domain is needed. The existing generic
`PredicateFlowSourceCandidate.native_flow_checked` transports that strengthened
record. Full native contract verification and actual source correspondence
remain mandatory.

The metadata source-proof patch
`f61067df472fb095a3a1e902a82e70a7054c0a601bdb8b0e937378688d9bdc95`
remains applicable unchanged: exact reconstruction shows that its two native
helper definitions, body calls and headers are untouched by this new delta.
Its original artifact remains uncompiled and unmodified. This review extends
its input applicability to the combined candidate; final output certificate,
matched pin and complete source/adapters/facade checks must use the final
selected combined bytes, not the earlier metadata-only hash.

Final retained caller summary `145720-331c1a61ff8d` confirms actual failure on
`aa1f3722`: 397/400 proof and 20/20 flow, with the two metadata postconditions
and only the Short_Or raw assertion unresolved. The run ended at 16:13:22 UTC;
no managed job was active in the 16:17 capture. The report's 186 retained files
were not individually re-audited in this bounded source review; its summary
and hash are retained. Next validation remains both complete new metadata
helpers/dependencies, then all three complete failed callers, preserving every
old and new obligation and final assurance. Harness goal was null on resumption;
CLI memory was not updated.

After this disposition, scope selected the exact `ffdc4fa6` combined source and
reported helper/dependency run `161846-7016360b9ba9` active with 22 workers.
It selects both complete metadata lemmas and both Append/Valid_Metadata
definitions. Those native inputs are frozen; the `f61067df` source-proof patch
remains unapplied. This status update is the scope handoff, not a new proof
result independently reviewed here.
