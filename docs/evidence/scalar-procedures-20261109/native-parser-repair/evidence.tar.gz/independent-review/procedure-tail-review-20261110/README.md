# Procedure append lemma at successful return — bounded reassessment

**No semantic or full-domain blocker found in `735f4bbb`.** Moving the already
proved Static call is a reasonable smallest experiment in proof-context
placement. The retained metadata leaf already contains the lemma fact, so this
is not a missing-fact repair or an established explanation of either timeout.
The proposal remains scratch, pending the current run's actual outcome and
selection by scope.

Reviewed by `/root/scalar_procedures_source`, approximately 16:46–16:51 UTC on
2026-11-10. Selected source role remains Astra Max; actual live settings and
token/cost measures are unavailable. Only this directory was written. No
tracked/native edits or proof jobs; existing drafts and successful evidence
remain untouched.

Base native SHA-256:
`ffdc4fa654056aae2c1b4d59fd1bb2b2dfae0077895158b91a1634d34ca63137`.
Candidate SHA-256:
`735f4bbb8cd0f9ecf816e17df3242113417f9ddeeafdf4bcb8ae2ecc25d41758`.
Native patch SHA-256:
`0d8c782e00a1eeafe01869525f4c03d1f26685c89702ea0939b66e20aff85e2a`.
Whole-file comparison independently confirms that removing the old/new call
from each respective source yields identical bytes; only its indentation and
location differ. The supplied patch exactly matches the independent unified
diff. `review.json` retains identities, diagnostic input hashes and run status.

The helper's arguments remain `Text`, `Frame.Procedures` and the exact original
suffix signature. These input parameters are immutable and unshadowed at the
new location. If `P = Frame.Procedures.Parameter_Count` and
`F = Frame.First_Procedure_Parameter`, the unchanged entry Pre still gives
`1 <= F <= P`, so `P - F + 1` is positive, representable, and satisfies the
exact segment bound. The original Pre also supplies catalog validity/capacity
and the positive valid name span. No body-success fact is needed to establish
these premises; they therefore hold on every path reaching the relocated call.

Early failure paths still return the identical `Invalid_State` and retain all
their validity obligations. They perform no metadata append and need no append
lemma call. Successful paths use the same verified lemma immediately before
the same return aggregate. No old runtime statement, guard, assertion, caller
Pre/Post or callee contract is removed or weakened. No runtime behavior changes
because the input-only call and its arguments are Ghost Static with Global null.
Generated call-obligation contexts change and must be checked at the new site.
Count-zero catalogs, arbitrary inactive slots, all formal kinds/modes/bounds,
and every other case in the earlier complete-domain review remain covered.

The retained completed-entity observations are **interim**, not final `.spark`
outcomes. The function body root is marked proved. The procedure's current
unproved roots are `def'vc.125` and `def'vc.197`; their `.0` descendants must not
be counted as additional independent required obligations. The decoded shape
for 125 targets `Valid_Environment` under the not-Initialized path; its full
125.0 shape also carries the earlier append-validity fact. The 197 target is
appended procedure metadata validity, and its 197.0 context already contains
the append-validity lemma fact.

Moving this fact after body processing tests whether removing it from earlier
obligation contexts and introducing it beside the final append changes solver
behavior. It adds no new mathematical information at the return. These decoded
shapes do not establish a unique cause, quantify search interference, or prove
that the final target and premise use congruent internal terms. If the final
gate confirms the residuals and scope selects this candidate, the next check is
the complete changed `Procedure_Body_At` under the same canonical policy. Compare
both earlier residuals, every original check, and the relocated call checks.
Another failure calls for examination of the new exact contexts; a blind repeat
is not justified by this review.

## Exact relocation in the retained source-proof draft

`source-relocation.patch` changes only
`proof/Silver/ProcedureDeclarationBodyNative.lean` **after** the existing
`f61067df` draft has been applied. It is not a direct patch against semantic
HEAD. Its exact source base SHA-256 is
`f40d57b8b458b49cee3210d390648eb74e11c77fb43397fe1a488db4b9862610`;
the relocated candidate SHA-256 is
`208ba6d55a24d4a7a8bd4e9cc98b0fc49368e7f87c5d763aaa8dbf8a6da0e983`.
Patch SHA-256:
`dc2becd308e02f021195f0ce4488a4b88a942fef66d1112629a034c24bac8bbb`.
Both complete source-file copies are retained here. Read-only
`git apply --check --whitespace=error` against the retained draft passes.

Remove the existing four-line `.staticProcedureMetadataAppend` wrapper from
immediately after the outer `.beginBody`, before the Locals failure guard.
Insert that identical wrapper after the final rejection guard and immediately
before `.returned <| .update .subtypes`. All its variables remain in scope;
none is newly bound. The renderer, erased evaluator, generic erasure theorem,
guard controls, exact helper header field and candidate wiring stay unchanged.
The ordinary-body source fragment automatically refers to the relocated tree.
The function body tree remains unchanged. No new proof framework, model law or
domain premise is required.

This relocation and the original source draft remain uncompiled and unapplied.
After native selection, the existing focused
`Silver.ProcedureDeclarationModelSource` target covers the changed body/model
route. The complete ordinary-body source check and final matched output
certificate/pin must use the selected relocated native bytes; neither text
checking nor the prior pin establishes that correspondence.

At 16:48 UTC, run `161846-7016360b9ba9` was successful and current caller run
`162446-2d6a4b3e4d0d` remained active with 22 workers on frozen `ffdc4fa6`.
Keep the completed six-helper success and every successful caller; the helper
definitions and dependencies are unchanged by this move, so no separate repeat
of their successful focused gate is justified. Final provenance and complete
assurance still need the selected whole-source inputs. Harness goal was null
on resumption; CLI memory was not updated.
