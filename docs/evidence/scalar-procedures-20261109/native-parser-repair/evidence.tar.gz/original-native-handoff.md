# Parser contract repairs — #370

This native subthread owns only `src/silver_output_profile.adb` in
`tmp/scalar-procedures-native-370` and the adjacent scratch/evidence. The source is committed as
`0d3d93ac258c9b7c6e491ec395164dbfc356f028`, changing only the owned Ada file. Its SHA-256 is
`735f4bbb8cd0f9ecf816e17df3242113417f9ddeeafdf4bcb8ae2ecc25d41758`.
All focused gates below have completed; final integration remains pending. Parent integration owns final
source correspondence, complete assurance, publication and capability status.

The project-selected native proof and independent source-review role is Astra Max;
live model/effort is not independently exposed. Native wrapper timings below
are measured per run and are not total team cost. Token/cost totals are unavailable.

The repairs preserve executable behavior, all existing raw model contracts and
full declared input domains. They add no assumptions, suppressions, weaker
contracts, new annotation-policy exceptions or solver-budget changes.

## Changes

1. The already-proved parser-state equality lemma retains its original raw
   equality conclusion and also re-exports its logical equality premise.
   `Boolean_Array_Values_At` calls this lemma at all three existing invalid
   returns and at its normal return. The latter names the same delta aggregate
   as a constant extended return object and retains its checked validity cut.
   The loop, input domain, early-return conditions and returned values remain.
2. `Body_Of` additionally exports the count and pointwise interval facts already
   established by its call to `Initial_Flow`. Its runtime body and raw-model
   equality are unchanged. The unsuccessful duplicate caller assertion is
   removed from `Procedure_Body_At`; the full fact is now proved at the helper
   boundary. This includes arbitrary `Scan_Result` values and `Count = 0`.
3. `Join_Into` retains its equal-count precondition, raw joined-result contract
   and runtime loop, while exporting unchanged count, joined path and pointwise
   joined intervals. The new static ghost `Lemma_Join_Identity` proves both
   logical and raw joined-flow equality from these component facts. It replaces
   only the unsuccessful reverse-equality bridge after the existing immediate
   pre-join snapshot in `Read_Chain_Into`. Original caller assertions remain.

The source owner's independent reviews are in the semantic worktree at
`tmp/parser-component-drafts-review-20261110` and
`tmp/boolean-early-bridges-review-20261110`. The reviews cover full domains,
null arrays, model equations, unchanged execution and exact source-proof impacts;
they do not predict solver success. The combined patch is `candidate.patch`.

## Actual validation

All runs are native Linux x86_64. The logical native options are the canonical
compiler `PROOF_OPTIONS`: all flow/proof checks, all reports, warnings and checks
as errors, level 2, CVC5/Z3/Alt-Ergo, timeout 30 seconds. Only unit/line coverage
is focused. Normal retained sessions are reused; no clean or full-audit result
is claimed.

`143914-1c2a2b56bc13` actually exited 0 at 14:51:44 UTC on 2026-11-10 after
751.032 wrapper seconds. It selected the entire declarations and bodies of all
nine helpers and relevant dependencies: 314 source lines, 22 worker reservation.

| Complete entity | Proof | Flow |
| --- | ---: | ---: |
| Boolean_Array_Values_At | 65 | 2 |
| Lemma_Parser_State_Equality | 1 | 1 |
| Initial_Flow | 12 | 3 |
| Body_Of | 5 | 3 |
| Joined | 36 | 2 |
| Join_Into | 17 | 1 |
| Lemma_Condition_Equality | 66 | 1 |
| Lemma_Flow_Equality | 8 | 1 |
| Lemma_Join_Identity | 17 | 1 |
| **Total passed** | **227** | **15** |

All nine entities are in `all` mode, every selected obligation passes and the
skip/pragma-assume fields are empty. The Boolean coverage comparison retains
all 59 previous proof checks and both flow checks, adding six proved call
preconditions. All 90 existing warning records match after source-line mapping;
the warning policy is unchanged. `helper-gate/` retains the exact 194-file,
37,697,046-byte packet, verified manifest, full native report, selected coverage,
source inputs, sessions, generated contexts, mode and warning audits.

`145720-331c1a61ff8d` actually exited 1 at 16:13:22 UTC after 4,562.169
wrapper seconds. It covered all seven complete affected callers with 546 selected
lines and 22 workers on `aa1f3722`. The final report has **397/400 proof checks
and all 20 flow checks passing**. All 309 original proof identities remain,
all seven entities are in all mode, all 90 warnings match, and no skip/assume
record occurs. The verified 186-file, 109,959,668-byte packet is in `caller-gate`.

Array_Declaration_At (57 proof), Read_Statements (6), Conditional_Body (36) and
Alternative_Body (38) pass completely. The two body callers each pass 25/26;
Read_Chain_Into passes 210/211. Its repaired Short_And branch and all bridge
premises pass. The three remaining obligations are the function/procedure
appended-metadata validity posts at lines 6568/6662 and the raw equality at
4427 in the previously unchanged Short_Or branch. The latter's current leaf 740
has three canonical timeout attempts. The failure remains failed and retained.

## Final selected repair and helper success

`final-parser-draft` holds the selected exact `ffdc4fa6` source and patch. It
adds the independently reviewed generic metadata append lemmas and their two
body-entry calls, then mirrors the successful pre-join snapshot/identity block
from Short_And.When_False into Short_Or.When_True. All original assertions,
contracts, runtime operations and order are preserved. The native metadata
review covers arbitrary inactive slots, zero old signatures, all permitted
formal modes/kinds and nonempty result intervals. The symmetry review independently
verifies the two blocks differ only by the flow field name and includes the
zero-count/null-array case.

Both reviews are in the semantic worktree: `tmp/metadata-append-review-20261110`
and `tmp/final-parser-symmetry-review-20261110`. The exact nine-file Lean draft
is `tmp/metadata-append-source-draft-20261110/source-proof.patch`, SHA-256
`f61067df472fb095a3a1e902a82e70a7054c0a601bdb8b0e937378688d9bdc95`.
It remains unapplied and uncompiled; distinct typed call nodes, their erasure
and guards, and complete new lemma headers are required. The symmetric native
join block needs no additional node/header beyond the pending join checks.

Helper/dependency run **161846-7016360b9ba9** actually exited 0 at 16:23:10 UTC
after 264.457 seconds on final `ffdc4fa6`, under the same canonical policy and
22-worker reservation. It selected 80 lines across three units and passed all
**45 proof checks and eight flow checks** across six complete entities:

| Complete entity | Proof | Flow |
| --- | ---: | ---: |
| Lemma_Function_Metadata_Append | 5 | 1 |
| Lemma_Procedure_Metadata_Append | 5 | 1 |
| Functions.Valid_Metadata | 15 | 2 |
| Functions.Append | 3 | 1 |
| Procedures.Valid_Metadata | 14 | 2 |
| Procedures.Append | 3 | 1 |

All entities are in all mode and all skip/assume fields are empty. The verified
171-file, 6,585,288-byte packet and final summary are under
`final-parser-draft/helpers-gate`. All 90 earlier profile warning records remain
after exact line mapping. Four new arithmetic-spelling advisories match every
field of the existing strict operator-reassociation classifier and source-origin
pair; no warning-policy change or safety-obligation waiver was made. The final
complete native/SARIF/provenance audit remains required.

Final caller run **162446-2d6a4b3e4d0d** actually exited 1 at 17:34:19 UTC
after 4,173.129 wrapper seconds, with 22 workers on `ffdc4fa6`. Complete
Function_Body_At passes 28/28 proof and 2/2 flow; Read_Chain_Into passes 222/222
proof and 4/4 flow. Procedure_Body_At passes 26/28 proof and 2/2 flow. Its
remaining obligations are the Read_Body Valid_Environment precondition at
6744 and the appended Procedures.Valid_Metadata post at 6713; both report
time limits. Every prior 263 proof and eight flow identity remains. All three
entities are in all mode, no assumption/skip record occurs, and all 94 warning
records exactly match the successful same-source helper packet. The verified
166-file, 48,625,702-byte packet is in `final-parser-draft/callers-gate`.

## Selected procedure-only context experiment

The next source `735f4bbb` moves only the existing four-line Static procedure
metadata lemma call from entry to immediately before the successful return.
Arguments, helper contracts, runtime statements and guards are identical. The
proved metadata fact already appears in both previous residual contexts, so
this is a context-placement experiment, not a missing-fact repair or an
established explanation of the timeouts. Independent full-domain/soundness
review is in semantic `tmp/procedure-tail-review-20261110/README.md`; its
source-tree relocation patch remains unapplied/uncompiled.

The managed diagnosis for `162446` records the exact remaining failures and
this hypothesis. Run **173934-c9e374d30353** actually exited 0 at **17:50:04 UTC**
after **629.796 wrapper seconds**, checking the complete 73-line
Procedure_Body_At on `735f4bbb` with the same canonical policy, 22 workers and
original warm workspace. **All 28 proof and two flow checks pass**, including
both prior residuals. Every previous identity remains; there are no missing or
extra checks, the entity is in all mode, and no skip/assume record occurs.
Explicit mapping covers the four relocated call lines and their nine-column
indentation increase. All 94 warning records match exactly after that mapping,
including unchanged imported-header warnings. The exact 156-file,
13,648,174-byte packet and verified audit are under
`final-parser-draft/procedure-tail-draft/caller-gate`.

`retained-success-continuity.json` combines this result with the four earlier
complete callers, now-passing function and chain, and both complete helper
gates: **687 proof and 43 flow checks across 22 distinct complete entities**.
Every selected source fragment from an earlier passing gate is byte-identical
in final `735f4bbb`; both binding dependency units are unchanged in full.
This is an aggregate of focused evidence at the listed inputs, not a single
whole-source validation or final provenance/Lean assurance. Earlier failed runs
remain failed and retained. No successful expensive gate was repeated merely
to obtain another record. The repaired proof placement succeeded on this run;
that outcome alone does not establish a unique cause for the previous timeouts.

## Diagnostic lineage and remaining assurance

The previous named-return attempt `131635-d495beb427bd` remains failed:
58/59 Boolean proof checks and both flow checks passed, with the raw model
postcondition timing out in all three canonical solver attempts. Its entire
packet and every previous failure remain retained.

Three deliberately partial native selector diagnostics did not select the raw
static leaf. Their interruption/failure outcomes are retained, without an
assurance claim. Managed custom diagnostic `143601-fa03fb3247ae` then used the
byte-identical retained whole-entity compiler context, its matching completed
Why3 session and exact idle native configuration to export the remaining raw
equality VC in 40.6 seconds. The original source and assurance workspace were
unchanged. Its custom exit 0 is not proof success: the JSON obligation result is
false, and its new one-step solver attempt reports an unrecognized answer.
The exact SMT, source hashes, command, result and final manifest are in
`../raw-model-direct-diagnostic/`. The goal contains all return paths; its
normal path explicitly contains the equality lemma result. It does not identify
a uniquely failing branch or a counterexample.

After successful complete caller verification, final source work must check the
strengthened parser-equality and Body_Of headers, the strengthened Join_Into
header and new ghost lemma header, and the procedure body tree without the
removed static assertion. The final output certificate and source-shape pin
must match the complete selected source together with those semantic checks.
Complete native/Lean/module/axiom auditing and final regressions still belong to
the parent delivery. These focused results do not establish capability support.

## Final native handoff — 2026-11-10 17:53 UTC

Native commit `0d3d93ac258c9b7c6e491ec395164dbfc356f028` references #370 without closing the
parent issue. It is based on native `51752014fc9aa806611f41a121a30750eba5256d`;
the parent parser source at `cf2882170d83f063b67cb02a9ddeebcbd20d377f` is
byte-identical to that base, so this is a source-only cherry-pick handoff.
The reviewed final input is `735f4bbb`; no source changed after the passing run.
Tracked native status is clean; untracked scratch `tmp/` remains preserved.
The live managed pool has no reservations or active runs. Harness goal is null.
No publication, issue closure, capability-support claim or CLI-memory update
was performed by this bounded subthread.

Parent integration must apply the selected metadata source draft and its
procedure-tail relocation, the previously pending parser/Body_Of/join header
and model changes, and matched final source certificate/pin checks. Focused
Lean/source checks, the complete native and Lean audits, regressions, issue
status, durable session memory and publication remain parent-owned.

This continuation retained the completed failed three-caller run, selected the
already reviewed procedure-only context experiment, and discharged both
remaining procedure obligations in one whole-caller run. Selected proof/review
role remains Astra Max from the bounded briefing; live model/effort and token/cost
measurements are unavailable. The native wrapper measured 629.796 seconds
(627.813 managed-run seconds); this is not total team elapsed time. One scratch
audit implementation incorrectly assumed warning origins were all in the body
file; correcting it preserved every imported-header record and required exact
full-record equality. No production-policy change or repeated proof run resulted.
