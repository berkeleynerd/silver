# Completed parser trial and next focused check — 2026-11-10

Run `20261110T093356-8e860ccf93b3` exited **1** at 11:08:16 UTC after
5,661.074 wrapper seconds. Native Linux source SHA256 is
`8e5048af07da44e4155366f510b069126c8c97241427b904dfc1a8edefb40ea4`.
Its 12-worker reservation is released. The actual command, final reports,
three Why3 sessions, source/generated inputs and managed events are retained
under `retained/`; all 165 files (56,750,714 bytes) match `retained-manifest.json`.
The failed source remains applied and unchanged; no new proof run or commit began.

The selected role carried forward was Astra Max for unresolved proof diagnosis.
Live model/effort, tokens and cost were not independently exposed. The present
continuation resumed around 10:55 UTC; solver elapsed time above includes work
before that continuation and is not model reasoning time. The live harness goal
is null. No CLI-memory update or full-assurance claim was made.

## Complete selected coverage

All **281 prior proof identities and eight flow identities** remain, preserving
multiplicity after source-line and indentation mapping. There are 20 additional
proof checks. `summary.json`, `selected-checks.json` and `changed-outcomes.json`
record the exact comparison.

| Complete helper | Proof checks passed | Flow checks passed |
| --- | ---: | ---: |
| Boolean_Array_Values_At | 58 / 59 | 2 / 2 |
| Procedure_Body_At | 22 / 30 | 2 / 2 |
| Read_Chain_Into | 207 / 212 | 4 / 4 |
| Total | 287 / 301 | 8 / 8 |

The 90 warning records are exactly unchanged after source-location mapping;
see `warnings-comparison.json`. No `pragma_assume`, `skip_proof` or
`skip_flow_proof` entries occur. This is a failed focused run, not a complete
compiler audit. The normal integrated warning/source/provenance checks remain.

## Exact residuals and regression accounting

Boolean's only failed grouped check is the Static raw model postcondition,
display line **2144** (canonical check location 2133:28). The returned-position
leaf now passes. The new Valid_State cut, its precondition, and both equality
lemma call preconditions pass. The failed raw equality remains a combined-path
postcondition; the report does not isolate a unique failing return branch.

Procedure has eight failures:

- **6640:76**: the new pointwise assertion's Context.Scalar_Names.Items index check.
- **6642:39**: Body_Tail precondition, scalar-environment validity.
- **6647:18, 6649:57**: Take_Token cursor upper bounds.
- **6652:30**: Equal_Name's `Left_First < Left_After`.
- **6659:28**: Hide_Name's `After > First`.
- **6664:24**: Name_Is's source upper bound.
- **6613:16**: the final Procedures.Valid_Metadata postcondition component.

The assertion's main count/pointwise goal passes, but its index check does not;
that is not complete assertion success. The formerly failed Read_Body precondition
at current **6644** reports proved. Seven previously passing original checks
regressed, in addition to the new index check.

Chain has five failures:

- **4359:25**: the added Lemma_Flow_Equality call's raw equality premise,
  `Result.When_False = Joined (Join_Input, Right.When_False)`.
- **4395:44**: the raw conditional-aggregate equality.
- **4401:44**: Tail equality to the recursive Condition_Tail model.
- **4403:44**: Same_Condition for Tail and the current-state recursive model.
- Display **3769**, canonical **3767:28**: the final raw Condition_Tail postcondition.

The original joined-flow assertion at current **4365** reports proved, but it
follows the unresolved new bridge premise. It cannot be accepted as an independent
closure. The immediate snapshot/initializer bridge and Same_Flow-to-Before check
pass; the post-call raw-to-logical bridge itself remains unproved. Four original
checks regressed, in addition to that new premise. The candidate did not solve
the helper.

Every residual exhausts production steps in CVC5 and Alt-Ergo; Z3 exhausts steps
except for the chain final postcondition, where it reaches the configured memory
limit. Some counterexample-only attempts time out. There is no reported
counterexample. See `unresolved-prover-attempts.json`. Generic suggested loop
invariants in the text log do not identify a demonstrated missing semantic premise.

## Smallest next candidate

Do not repeat this three-helper batch unchanged or keep adding cuts in its large
callers. The exact one-line **scratch-only** candidate is
`next-candidate/parser-equality-export.patch`; its full candidate source SHA256 is
`336cba3eac92dc2833336ec4b181ac6f614e86cd2cec3600c401304c235296cb`.
It changes the existing parser equality lemma's postcondition from `Left = Right`
to `Left = Right and then Same_Parser_State (Left, Right)`.

This preservation fact follows from the unchanged Same_Parser_State precondition,
read-only input parameters, Global => null and null body. It retains the raw
equality guarantee, full Parser_State domain and executable behavior. It makes
logical identity explicit at the procedure-call boundary, where reconstructing
the caller's returned aggregate otherwise relies on the raw record equality.
The existing call precondition already passed; therefore this is a modular-export
experiment, not a claim to have found a missing semantic premise or a uniquely
failing normal-return branch. Solver improvement is untested.

The smallest ordered validation is:

1. Check the **complete Lemma_Parser_State_Equality** declaration/body (10 lines)
   at unchanged production settings, using `next-candidate/helper.lines`.
2. Only after helper success, check both **complete direct callers**,
   Boolean_Array_Values_At and Array_Declaration_At (204 lines), using
   `next-candidate/affected-callers.lines`. Compare every original obligation.
3. Coordinate the real helper-header/source correspondence changes with the lead;
   final capability assurance still requires the complete native/Lean checkpoint.

No candidate is applied or run automatically. Recheck live worker allocations
before any launch. The whole Boolean caller can still fail on other return paths;
if so, retain that exact outcome before choosing a named-return-object alternative.

For the other helpers, final evidence favors moving export obligations into small
callees over more caller assertions: Body_Of could expose the already implied
initial-flow count/pointwise guarantees, and Join_Into could export its complete
componentwise join facts before any logical/raw bridge. These are **unselected
design directions**, with complete helper/caller and source-correspondence work
required. A reverse Same_Flow-to-raw bridge alone does not discharge the current
post-Join_Into raw-to-logical premise; do not revive the withdrawn reorder patch.
