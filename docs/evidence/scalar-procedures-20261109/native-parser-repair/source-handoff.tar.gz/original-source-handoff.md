# Final scalar-procedure source integration — #370

Current implementation: `daccf8e2f84bafb81cd4c8f73c4c397d3bf01551` on `proof/scalar-procedures-source-semantic-370`.
This source-only commit follows required adapter/facade commit `58101b848f` and
initial-flow syntax commit `9f79c8d2df`. The primary proof tree at `09d96c837d`
was byte-equivalent to the source base `ad0922976f`; no older commit replay is needed.
No publication occurred. Parent owns the final native/regression assurance and delivery.

## Exact selected inputs and implementation

Parser `735f4bbb8cd0f9ecf816e17df3242113417f9ddeeafdf4bcb8ae2ecc25d41758`,
report `95d4758ea69276203ccfea127b73837701278c2770a996d30e5d6833af1a09b1`,
auditor `bed6337ae6b7fa65dff44296a7fbf632eafb326fa832dbcb70335ddca46e54bd`.
The pin was prepared against the existing matched baseline before source replacement;
`output-pin-735f4bbb/manifest.json` records its old/new hashes and token counts.
`input-sync-manifest.json` inventories 148 primary source/script/catalogue/native-generated
files. Five tracked parent-owned files and three absent native-generated files were copied;
these native changes are not included in the proof-only commit. Existing baseline bytes
remain under `before-sync/`.

Applied the exact nine-file metadata patch `f61067df`, then procedure-tail relocation
`dc2becd3`, and the parser equality header patch. Added complete Body_Of, Join_Into and
Lemma_Join_Identity expectations. The old Body_Of model equality, typed join renderer,
full input domains and original native guarantees remain. The two exact Static-call
constructors erase only their fixed native calls; generic erasure and twelve positive/
negative renderer/scope/precedence controls per constructor are checked. No generic
pragma skipping, new runtime Calls law, assumed helper equation or narrowed domain.

All six changed complete helper headers match independent token extraction in
`header-token-crosscheck.json`; that mismatch check is not a substitute for Lean
source correspondence. Final concrete source checks remain pending the pipeline below.

## Focused gate and retained failure

Run `20261110T180634-ee26708d1474` failed only the two new exact rendering controls,
because kernel reduction stopped at opaque Nat.repr. Its exact syntax inputs, logs
and managed failure record are retained in `failed-model-180634/`; no successful
evidence file exists for that failed run. The repair adds the established
`import all Init.Data.Repr` to both syntax modules without changing any proposition.

Run `20261110T180854-2aee6adef6a2` ACTUAL EXIT 0 on linux-x86_64, Lean 4.34.1,
22 managed workers and 22 threads per process. Build 164.793 s, fresh audit 9.378 s,
finished 2026-11-10 18:12:15 UTC. Audited 59,461 declarations across 490
actual project modules. Targets: ProcedureDeclarationModelSource and
ComposeArrayDeclarationSource. The closure excludes ReviewedOutputShape and
OutputBodyCertificate. All 1101 captured shared input hashes matched
current bytes after success. Exact logs/evidence are retained in `model-success-180854/`.
No clean build or independent kernel replay was requested.

`facade-static-inventory.json` finds all 994 project modules reachable (including
meta imports); full actual-import and axiom audit remains required.

## Remaining complete validation

1. Parent integrated 58101b848f, 9f79c8d2df and daccf8e2f8 as a124a883b8,
   3323f47d9d and bfe82aeb81. The primary proof tree exactly matches the source tree.
2. `primary-input-alignment.json` confirms all 1,101 captured shared input hashes,
   the 994-module inventory and both tool hashes match primary bfe82aeb81 and
   successful model inputs. No mismatches.
3. Managed eight output-line chunks, then output aggregator; eight workers and
   default 22 threads alongside the native 14-worker run. All eight chunks changed
   on final selected bytes (`output-chunk-delta.json`). Preserve accepted baseline
   073635 and model caches. The aggregator has an observed baseline peak of 30.56 GiB;
   do not overlap broad source checks with it.
4. Complete Lean/source/adapters/facade build and fresh module/axiom/provenance audit.

Native peer was notified only after actual focused success and released reservation.
It launched canonical full run `20261110T181302-a4553e500d15` at 14 workers, with
2,595 unchanged native hashes; its result is independent and pending.

Source role selected Astra Max per project policy; live backend/effort and token/cost
measurements are not independently exposed. Harness goal was null at resume.
CLI memory has not been updated. #373 is authorized NEXT after #370 delivery;
its docs-only main commit does not change this task's scope.

## Active certificate stage

Eight-chunk run `20261110T181505-9a359fa38440`, session 71423, log
`output-chunks.log`. Actual runner settings: eight Lake workers and 22 threads
per Lean process; build started 18:15:54 UTC. Native run181302 holds the other
14 workers. Inputs are frozen. All eight chunks started; no completed chunk or
certificate assurance is claimed yet.

The pending checked-in generated-candidate delta is ten files: OutputSpecCertificate,
OutputBodyCertificate and OutputBodyLines0..7. `generated-candidate-delta.json`
records this inventory. Parent explicitly requested refresh/commit after successful
source validation; all generated candidate bytes remain unchanged in the repository
until that validation. The managed runner independently regenerates its workspace.
