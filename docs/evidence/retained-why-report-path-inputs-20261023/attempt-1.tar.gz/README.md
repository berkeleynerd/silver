# Terminal pathname provider evidence

2026-10-23 UTC; Linux x86_64 retained inputs; #119 / #153. The
[author note](../../research/retained-why-report-path-inputs.md) refines the
accepted terminal theorem to a separately named diagnostic-path operand.
Author base: `9396a98fe6`. Independent review is pending at this author freeze.

The focused check passed **555 checks in 7.107644 seconds**. It pins 27 provider
files, 31 complete source members and 61 strict source ranges; reads the five
current J12 input/process records; and joins 21 complete library members to
each case's 81 ordered-input roles. It runs no predecessor checker, compiler,
solver, proof, target-native executable, capture or source fetch.

Run from the repository root with:

```sh
python3 docs/evidence/retained-why-report-path-inputs-20261023/check.py
```

Files:

* `inputs.json`: exact retained file/archive identities, including accepted
  terminal, warning, callback, request, startup and protocol providers.
* `source-ranges.json` and `source-witnesses.md`: exact member identities,
  strict range identities and readable excerpts. No out-of-range clipping.
* `library-projection.json`: 21 exact library identities and absence of raw
  virtual-filename directives/recognized raw location attributes.
* `projection.json`: actual configuration names, byte lengths, decoded input
  maxima, all-prefix request bounds, and symbolic P_diag/M exports.
* `result.json` and `check-attempt-1.log`: the single successful focused run.
* `attempts.json`: preparation failure and successful-check accounting.

The all-prefix exports are F=775/802/841/853/829 in
Put_Line/Put/First_Or_Default/Is_Message/Input_Is_Valid order,
`P_diag=max(F,R+24)` and `M=R+72`. R remains actual configuration input.
Actual R, raw-stat P_stat and actual standard/channel guards are null.
This is neither an all-path storage theorem nor whole-process capacity or
admission evidence. Source reasoning supplies origin closure; identity and
arithmetic checks alone do not prove that closure. Existing source/native
correspondence, intact canonical proxy protocol and trusted physical runtime
services remain requirements. One global e<=2, two save-entering callbacks and
three saves are preserved.

The first source-pin preparation requested putenv.c lines 31–57, but the exact
retained member ends at 55. Its strict range assertion failed before emitting
`source-ranges.json` or running the focused checker. Inspection confirmed
the complete relevant implementation ends at 55; preparation was repeated
with 31–55. Provider inputs and theorem arithmetic were unchanged. No
successful checker run was repeated.

Selected author: GPT-6 Astra / Extra High. Runtime confirmation and token/cost
telemetry are unavailable. Preparation began 18:35:09 UTC and the first passing
check finished before 19:00:21 UTC; these wall-clock bounds include inherited
preparation and context handoff and do not measure model efficiency. Reviewer
settings, findings and final acceptance belong to the independent report.
No GitHub, shared-record, harness-state or CLI-memory write was made.
