"""Retain driver-only and static-default evidence for #119. No compilation."""
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess

ROOT = Path(__file__).resolve().parent
CASE = ROOT / "capture"
CASE.mkdir()  # Never overwrite an earlier capture.
TOOL = Path("/home/canto/src/github.com/berkeleynerd/silver/.tools/linux-x86_64/alire/toolchains/gnat_native_16.1.0_9f74f58a")
GCC = TOOL / "bin/gcc"
GNAT1 = TOOL / "libexec/gcc/x86_64-pc-linux-gnu/16.1.0/gnat1"
OBJDUMP = TOOL / "bin/objdump"
RUNTIME = TOOL / "lib/gcc/x86_64-pc-linux-gnu/16.1.0"
(CASE / "temp").mkdir()
(CASE / "obj").mkdir()
(CASE / "main.adb").write_text("procedure Main is\n   pragma SPARK_Mode (On);\nbegin\n   null;\nend Main;\n")
(CASE / "config.adc").write_text('pragma Source_File_Name_Project\n   (Spec_File_Name => "*.ads",\n    Dot_Replacement => "-",\n    Casing => Lowercase);\npragma Source_File_Name_Project\n   (Body_File_Name => "*.adb",\n    Dot_Replacement => "-",\n    Casing => Lowercase);\n')
(CASE / "mapping").write_text(f"main%b\nmain.adb\n{CASE / 'main.adb'}\n")
environment = {
    "PATH": f"{TOOL / 'bin'}:/usr/bin:/bin",
    "LC_ALL": "C", "LANG": "C", "TERM": "dumb",
    "TMPDIR": str(CASE / "temp"),
    "ADA_INCLUDE_PATH": str(RUNTIME / "adainclude"),
    "ADA_OBJECTS_PATH": str(RUNTIME / "adalib"),
}
commands = []

def run(label, args):
    result = subprocess.run([str(x) for x in args], cwd=CASE / "obj",
                            env=environment, capture_output=True)
    (CASE / f"{label}.stdout").write_bytes(result.stdout)
    (CASE / f"{label}.stderr").write_bytes(result.stderr)
    commands.append({"label": label, "argv": [str(x) for x in args],
                     "cwd": str(CASE / "obj"), "returncode": result.returncode})
    result.check_returncode()
    return result.stdout.decode()

native_args = ["-c", "-x", "ada", "-gnatA", "-gnat2022", "-gnata", "-gnato",
               "-gnatx", "-Wno-free-nonheap-object",
               f"-gnatec={CASE / 'config.adc'}", f"-gnatem={CASE / 'mapping'}",
               str(CASE / "main.adb")]
run("driver-expansion", [GCC, "-###", *native_args])
run("search-dirs", [GCC, "-print-search-dirs"])
run("specs", [GCC, "-print-file-name=specs"])
run("selected-gnat1", [GCC, "-print-prog-name=gnat1"])
run("selected-as", [GCC, "-print-prog-name=as"])

# Read constant unconstrained-String arguments in the installed Sdefault
# wrappers. This is static ELF/ABI evidence, not execution or source identity.
raw = GNAT1.read_bytes()
assert raw[:6] == b"\x7fELF\x02\x01"
phoff = struct.unpack_from("<Q", raw, 32)[0]
phentsize, phnum = struct.unpack_from("<HH", raw, 54)
segments = [struct.unpack_from("<IIQQQQQQ", raw, phoff+i*phentsize)
            for i in range(phnum)]

def at(address, count):
    for kind, flags, off, vaddr, _, filesz, memsz, align in segments:
        if kind == 1 and vaddr <= address and address + count <= vaddr + filesz:
            return raw[off+address-vaddr:off+address-vaddr+count]
    raise ValueError((address, count))

def ada_string(address, bounds):
    low, high = struct.unpack("<ii", at(bounds, 8))
    assert low == 1 and high >= 0
    return {"data_address": address, "bounds_address": bounds,
            "bounds": [low, high], "text": at(address, high).decode("ascii")}

defaults = {}
for name in ("search_dir_prefix", "include_dir_default_name", "object_dir_default_name"):
    disassembly = run("sdefault-"+name,
                      [OBJDUMP, "-d", "--disassemble=sdefault__"+name, GNAT1])
    regs = {reg: int(value, 16) for value, reg in
            re.findall(r"mov\s+\$0x([0-9a-f]+),%(e[cds]i|e[cd]x)", disassembly)}
    assert set(regs) == {"edi", "esi", "edx", "ecx"}
    assert "<osint__relocate_path@@Base>" in disassembly
    prefix = ada_string(regs["edi"], regs["esi"])
    path = ada_string(regs["edx"], regs["ecx"])
    assert path["text"].startswith(prefix["text"])
    relocated = str(TOOL) + "/" + path["text"][len(prefix["text"]):]
    defaults[name] = {"compiled_prefix": prefix, "compiled_path": path,
                      "relocated": relocated}

search = Path(defaults["search_dir_prefix"]["relocated"])
probes = {str(search / name): (search / name).exists()
          for name in ("ada_source_path", "ada_object_path")}
result = {
    "environment": environment, "commands": commands,
    "native_arguments_excluding_driver": native_args,
    "installed_defaults": defaults, "default_search_file_exists": probes,
    "identities": [{"path": str(p), "bytes": p.stat().st_size,
                    "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
                   for p in (GCC, GNAT1, OBJDUMP)],
    "compiler_frontend_or_assembler_executed": False,
    "source_derived_relocation_argument_required": True,
}
(CASE / "result.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps({"driver_queries": 5, "static_default_wrappers": 3,
                  "default_search_file_exists": probes,
                  "environment_entries": len(environment)}))
