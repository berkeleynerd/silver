#!/usr/bin/env python3
"""One fresh indexed-null GPR build under the proposed retained-tool options."""
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import time

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/canto/src/github.com/berkeleynerd/silver')
GNAT = REPO / '.tools/linux-x86_64/alire/toolchains/gnat_native_16.1.0_9f74f58a'
GPR = REPO / '.tools/linux-x86_64/alire/toolchains/gprbuild_26.0.1_e3f27f25'
ORIGINAL = REPO / 'tmp/indexed-main-discovery/.silver/linux-x86_64/program-RibQE3'


def identity(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


assert not (ROOT / 'result.json').exists(), 'preserve an existing capture'
work = ROOT / ('w' * (len(str(ORIGINAL)) - len(str(ROOT)) - 1))
work.mkdir()
assert len(str(work)) == len(str(ORIGINAL))
(ROOT / 'temporary').mkdir()
sources = [ORIGINAL / 'program.gpr', REPO / 'samples/null.adb']
tools = [GPR / 'bin/gprbuild', GPR / 'bin/gprconfig', GPR / 'libexec/gprbuild/gprbind',
         GNAT / 'bin/gcc', GNAT / 'bin/gnatbind', GNAT / 'libexec/gcc/x86_64-pc-linux-gnu/16.1.0/gnat1',
         GNAT / 'x86_64-pc-linux-gnu/bin/as', GNAT / 'x86_64-pc-linux-gnu/bin/ld']
before = {str(p): identity(p) for p in sources + tools}
(work / 'program.gpr').write_bytes(sources[0].read_bytes())
(work / 'main.adb').write_bytes(sources[1].read_bytes())
environment = {'PATH': str(GNAT / 'bin') + ':' + str(GPR / 'bin') + ':/usr/bin:/bin',
               'LC_ALL': 'C', 'TMPDIR': str(ROOT / 'temporary')}
command = [str(GPR / 'bin/gprbuild'), '-P', str(work / 'program.gpr'), '-p',
           '-cargs:Ada', '-gnatx', '-Wno-free-nonheap-object',
           '-largs', '-fno-lto', '-fno-use-linker-plugin']
(ROOT / 'invocation.json').write_text(json.dumps(dict(argv=command, cwd=str(work),
    environment=environment, input_identities=before,
    scope='one fresh indexed null native build; proposed options; exact inherited environment'),
    indent=2, sort_keys=True) + '\n')
started = time.monotonic()
run = subprocess.run(command, cwd=work, env=environment, capture_output=True)
elapsed = time.monotonic() - started
(ROOT / 'stdout').write_bytes(run.stdout)
(ROOT / 'stderr').write_bytes(run.stderr)
after = {str(p): identity(p) for p in sources + tools}
generated = {str(p.relative_to(work)): identity(p) for p in sorted(work.rglob('*')) if p.is_file()}
result = dict(host=platform.platform(), returncode=run.returncode, duration_seconds=elapsed,
              retained_inputs_unchanged=before == after, generated=generated,
              stdout=identity(ROOT / 'stdout'), stderr=identity(ROOT / 'stderr'),
              scope='one GPR native build, including compiler/binder/linker; no prover or program execution')
(ROOT / 'result.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, sort_keys=True), flush=True)
assert run.returncode == 0 and before == after and 'bin/main' in generated
