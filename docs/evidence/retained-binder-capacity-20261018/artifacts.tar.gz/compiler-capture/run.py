#!/usr/bin/env python3
"""Compile the fixed indexed binder source once with the proposed options."""
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import time

ROOT = Path(__file__).resolve().parent
INSTALL = Path('/home/canto/src/github.com/berkeleynerd/silver/tmp/indexed-main-discovery')
GNAT = INSTALL / '.tools/linux-x86_64/alire/toolchains/gnat_native_16.1.0_9f74f58a'
ORIGINAL = INSTALL / '.silver/linux-x86_64/program-RibQE3/obj'
SUPPORT = GNAT / 'lib/gcc/x86_64-pc-linux-gnu/16.1.0/adainclude'


def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


assert not (ROOT / 'result.json').exists(), 'Preserve the existing capture'
output = ROOT / ('w' * (len(str(ORIGINAL))-len(str(ROOT))-1))
output.mkdir()
assert len(str(output)) == len(str(ORIGINAL))
(ROOT / 'temporary').mkdir()
files = [ORIGINAL / 'b__main~1.ads', ORIGINAL / 'b__main~1.adb', ORIGINAL / 'b__main~1.o']
files += [SUPPORT / n for n in ('system.ads', 's-parame.ads', 's-secsta.ads', 's-stoele.ads')]
files += [GNAT / 'bin/gcc', GNAT / 'libexec/gcc/x86_64-pc-linux-gnu/16.1.0/gnat1',
          GNAT / 'bin/as', GNAT / 'x86_64-pc-linux-gnu/bin/as']
before = {str(p): identity(p) for p in files}
for name in ('b__main~1.ads', 'b__main~1.adb'):
    (output / name).write_bytes((ORIGINAL / name).read_bytes())
command = [str(GNAT / 'bin/gcc'), '-c', '-x', 'ada', '-gnatA',
           '-c', '-gnatA', '-gnatWb', '-gnatiw', '-gnatws',
           '-Wno-free-nonheap-object', '-mtune=generic', '-march=x86-64',
           'b__main~1.adb', '-o', 'b__main~1.o']
environment = {'PATH': str(GNAT / 'bin') + ':/usr/bin:/bin',
               'LC_ALL': 'C', 'TMPDIR': str(ROOT / 'temporary')}
(ROOT / 'invocation.json').write_text(json.dumps(
    {'argv': command, 'cwd': str(output), 'environment': environment,
     'input_identities': before, 'source_fullname_bytes': len(str(output / 'b__main~1.adb')),
     'scope': 'proposed indexed binder compiler descriptor; copied source bytes with injectively renamed same-length full paths'},
    indent=2, sort_keys=True) + '\n')
dry = subprocess.run(command + ['-###'], cwd=output, env=environment, capture_output=True)
(ROOT / 'dryrun.stdout').write_bytes(dry.stdout)
(ROOT / 'dryrun.stderr').write_bytes(dry.stderr)
assert dry.returncode == 0
started = time.monotonic()
run = subprocess.run(command, cwd=output, env=environment, capture_output=True)
elapsed = time.monotonic() - started
(ROOT / 'stdout').write_bytes(run.stdout)
(ROOT / 'stderr').write_bytes(run.stderr)
unchanged = all(identity(Path(p)) == value for p,value in before.items())
generated = {p.name: identity(p) for p in output.iterdir() if p.is_file()}
result = {'host': platform.platform(), 'returncode': run.returncode,
          'duration_seconds': elapsed, 'retained_inputs_unchanged': unchanged,
          'generated': generated, 'dryrun_returncode': dry.returncode,
          'object_hash_equal_baseline': (identity(output / 'b__main~1.o') == identity(ORIGINAL / 'b__main~1.o'))
                                      if (output / 'b__main~1.o').exists() else None,
          'stdout': identity(ROOT / 'stdout'), 'stderr': identity(ROOT / 'stderr'),
          'scope': 'one compiler/assembler execution plus driver-only selection query; no binder, linker or proof run'}
(ROOT / 'result.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, sort_keys=True), flush=True)
assert run.returncode == 0 and unchanged and 'b__main~1.o' in generated
assert not run.stdout and not run.stderr
