#!/usr/bin/env python3
"""Capture one selected GPR configuration without compiling a project."""
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import time

ROOT = Path(__file__).resolve().parent
INSTALL = Path('/home/canto/src/github.com/berkeleynerd/silver/tmp/indexed-main-discovery')
GNAT = INSTALL / '.tools/linux-x86_64/alire/toolchains/gnat_native_16.1.0_9f74f58a'
GPR = INSTALL / '.tools/linux-x86_64/alire/toolchains/gprbuild_26.0.1_e3f27f25'
KNOWLEDGE = GPR / 'share/gprconfig'


def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


assert not (ROOT / 'result.json').exists(), 'Preserve the existing capture'
(ROOT / 'temporary').mkdir()
files = sorted(p for p in KNOWLEDGE.rglob('*') if p.is_file())
files += [GPR / 'bin/gprconfig', GNAT / 'bin/gnatls', GNAT / 'bin/gcc']
before = {str(p): identity(p) for p in files}
command = [str(GPR / 'bin/gprconfig'), '--batch', '-v',
           '--target=x86_64-pc-linux-gnu',
           '--config=Ada,16.1,default,' + str(GNAT / 'bin') + ',GNAT',
           '-o', str(ROOT / 'selected.cgpr')]
environment = {'PATH': str(GNAT / 'bin') + ':' + str(GPR / 'bin'),
               'LC_ALL': 'C', 'TMPDIR': str(ROOT / 'temporary')}
(ROOT / 'invocation.json').write_text(json.dumps(
    {'argv': command, 'cwd': str(ROOT), 'environment': environment,
     'input_identities': before,
     'scope': 'selected controlled native/default configuration; not historical GPR configuration'},
    indent=2, sort_keys=True) + '\n')
started = time.monotonic()
run = subprocess.run(command, cwd=ROOT, env=environment, capture_output=True)
elapsed = time.monotonic() - started
(ROOT / 'stdout').write_bytes(run.stdout)
(ROOT / 'stderr').write_bytes(run.stderr)
unchanged = all(identity(Path(p)) == value for p,value in before.items())
result = {'host': platform.platform(), 'returncode': run.returncode,
          'duration_seconds': elapsed, 'retained_inputs_unchanged': unchanged,
          'knowledge_files': len(files)-3,
          'configuration': identity(ROOT / 'selected.cgpr') if (ROOT / 'selected.cgpr').exists() else None,
          'stdout': identity(ROOT / 'stdout'), 'stderr': identity(ROOT / 'stderr'),
          'scope': 'one gprconfig selection and metadata discovery; no project build, binder, assembler, linker or proof run'}
(ROOT / 'result.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, sort_keys=True), flush=True)
assert run.returncode == 0 and unchanged and result['configuration']
