#!/usr/bin/env python3
"""Capture fixed Gprbind initialization through its expected usage rejection."""
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import time

ROOT = Path(__file__).resolve().parent
INSTALL = Path('/home/canto/src/github.com/berkeleynerd/silver/tmp/indexed-main-discovery')
GNAT = INSTALL / '.tools/linux-x86_64/alire/toolchains/gnat_native_16.1.0_9f74f58a'
GPR = INSTALL / '.tools/linux-x86_64/alire/toolchains/gprbuild_26.0.1_e3f27f25'
SOURCE = Path('/tmp/silver-retained-gpr-source-20261017/gprbuild-bdfb879cf03643ec8e48a09ce07b08c4a6ff0263')


def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


assert not (ROOT / 'result.json').exists(), 'Preserve the existing diagnostic'
cwd = ROOT / ('w' * (113-len(str(ROOT))-1))
cwd.mkdir()
assert len(str(cwd)) == 113
binary = GPR / 'libexec/gprbuild/gprbind'
files = [binary, SOURCE / 'src/gprbind.adb']
files += [SOURCE / 'gpr/src' / n for n in ('gpr.adb', 'gpr-cset.adb', 'gpr-osint.adb', 'gpr-util.adb', 'gpr-tempdir.adb')]
before = {str(p): identity(p) for p in files}
command = [str(binary)]
environment = {'PATH': str(GNAT / 'bin') + ':/usr/bin:/bin', 'LC_ALL': 'C', 'TMPDIR': '/tmp'}
(ROOT / 'invocation.json').write_text(json.dumps({'argv': command, 'cwd': str(cwd), 'environment': environment,
    'input_identities': before, 'scope': 'no arguments: expected usage rejection after library/program initialization; no binder or compiler'}, indent=2, sort_keys=True)+'\n')
started = time.monotonic()
run = subprocess.run(command, cwd=cwd, env=environment, capture_output=True)
elapsed = time.monotonic()-started
(ROOT / 'stdout').write_bytes(run.stdout)
(ROOT / 'stderr').write_bytes(run.stderr)
unchanged = all(identity(Path(p)) == row for p,row in before.items())
result = {'host': platform.platform(), 'returncode': run.returncode, 'duration_seconds': elapsed,
    'expected_usage_rejection': run.returncode != 0 and b'incorrect invocation' in run.stderr,
    'retained_inputs_unchanged': unchanged, 'working_directory_files': sorted(p.name for p in cwd.iterdir()),
    'stdout': identity(ROOT / 'stdout'), 'stderr': identity(ROOT / 'stderr'),
    'scope': 'initialization diagnostic; expected usage rejection is not a compilation or validation failure'}
(ROOT / 'result.json').write_text(json.dumps(result, indent=2, sort_keys=True)+'\n')
print(json.dumps(result, sort_keys=True), flush=True)
assert result['expected_usage_rejection'] and unchanged and not run.stdout and not result['working_directory_files']
