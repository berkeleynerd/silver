#!/usr/bin/env python3
"""One controlled binder-only capture; all retained inputs remain read-only."""
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import time

ROOT = Path(__file__).resolve().parent
PACKET = Path('/home/canto/src/github.com/berkeleynerd/silver/tmp/retained-binder-capacity/docs/evidence/retained-binder-capacity-20261018')
INSTALL = Path('/home/canto/src/github.com/berkeleynerd/silver/tmp/indexed-main-discovery')
GNAT = INSTALL / '.tools/linux-x86_64/alire/toolchains/gnat_native_16.1.0_9f74f58a'
BINDER = GNAT / 'bin/gnatbind'
ORIGINAL_OBJ = INSTALL / '.silver/linux-x86_64/program-RibQE3/obj'
MANIFEST = json.loads((PACKET / 'manifest.json').read_text())


def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


assert not (ROOT / 'result.json').exists(), 'Preserve the existing capture'
output = ROOT / 'output'
output.mkdir()
temp_root = ROOT / 'temporary'
temp_root.mkdir()
temporary = temp_root / ('GPR.' + str(os.getpid()))
temporary.mkdir()
mapping = temporary / 'GNAT-TEMP-000001.TMP'
objects_path = temporary / 'GNAT-TEMP-000002.TMP'
object_list = temporary / 'GNAT-TEMP-000003.TMP'
mapping.write_bytes(b'')
objects_path.write_text(str(ORIGINAL_OBJ) + '/\n')
inputs = {row['original_path']: {'bytes': row['bytes'], 'sha256': row['sha256']}
          for name, row in MANIFEST['archives']['artifacts.tar.gz']['members'].items()
          if name.startswith(('closure/', 'compiler-support/'))}
for name in ('b__main~1.ads', 'b__main~1.adb'):
    path = ORIGINAL_OBJ / name
    inputs[str(path)] = identity(path)
inputs[str(BINDER)] = identity(BINDER)
assert all(identity(Path(p)) == expected for p, expected in inputs.items())
command = [str(BINDER), '-o', 'b__main~1.adb', str(ORIGINAL_OBJ / 'main~1.ali'),
           '-x', '-F=' + str(mapping), '-O=' + str(object_list)]
environment = {'PATH': str(GNAT / 'bin') + ':/usr/bin:/bin',
               'LC_ALL': 'C', 'TMPDIR': str(temp_root),
               'ADA_PRJ_OBJECTS_FILE': str(objects_path)}
(ROOT / 'invocation.json').write_text(json.dumps(
    {'argv': command, 'cwd': str(output), 'environment': environment,
     'input_identities': inputs,
     'temporary_input_files': {str(p): {'identity': identity(p), 'text': p.read_text()}
                               for p in (mapping, objects_path)},
     'scope': 'selected controlled descriptor; no reconstruction of historical GPR child environment or initial exchange'},
    indent=2, sort_keys=True) + '\n')
started = time.time()
run = subprocess.run(command, cwd=output, env=environment, capture_output=True)
elapsed = time.time() - started
(ROOT / 'stdout').write_bytes(run.stdout)
(ROOT / 'stderr').write_bytes(run.stderr)
unchanged = all(identity(Path(p)) == expected for p, expected in inputs.items())
generated = {p.name: identity(p) for p in output.iterdir() if p.is_file()}
matches = {name: identity(output / name) == identity(ORIGINAL_OBJ / name)
           for name in ('b__main~1.ads', 'b__main~1.adb') if (output / name).exists()}
result = {'host': platform.platform(), 'returncode': run.returncode,
          'duration_seconds': elapsed, 'retained_inputs_unchanged': unchanged,
          'generated': generated, 'matches_original_indexed_source': matches,
          'object_list': {'identity': identity(object_list), 'text': object_list.read_text()}
                         if object_list.exists() else None,
          'temporary_root_bytes': len(str(temp_root)),
          'selected_argument_bytes_with_terminators': sum(len(a) + 1 for a in command[1:]),
          'selected_argument_count': len(command) - 1,
          'stdout_bytes': len(run.stdout), 'stderr_bytes': len(run.stderr),
          'scope': 'one fresh binder process only; no GPR driver, compiler, assembler, linker or proof run'}
(ROOT / 'result.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, sort_keys=True), flush=True)
assert run.returncode == 0 and unchanged and all(matches.values()) and len(matches) == 2
assert not run.stdout and not run.stderr
