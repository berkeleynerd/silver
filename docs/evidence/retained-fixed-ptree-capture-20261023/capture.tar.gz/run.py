from pathlib import Path
import json,subprocess,hashlib,time,os,signal
ROOT=Path(__file__).parent;plan=json.loads((ROOT/'plan.json').read_text())
def identity(path):
    data=Path(path).read_bytes();return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
for path,expected in plan['file_identities'].items():
    assert identity(path)==expected,path
for path,expected in plan['working_configuration_copies'].items():assert identity(path)==expected,path
results=[]
for i,case in enumerate(plan['cases']):
    assert identity(Path(case['cwd'])/case['argv'][-1])==case['input']
    out=Path(case['cwd'])/'capture';out.mkdir()
    script='''set pagination off
set confirm off
set auto-load off
set debuginfod enabled off
set startup-with-shell off
set disable-randomization off
set language c
python
import gdb,json
root='/tmp/silver-fixed-ptree-20261023'
plan=json.load(open(root+'/plan.json'))
case=plan['cases'][CASE_INDEX]
gdb.execute('unset environment')
for k,v in case['environment'].items():gdb.execute('set environment '+k+'='+v)
end
starti
python
exec(open(root+'/probe.py').read())
end
continue
python
finish_capture()
end
kill
quit
'''.replace('CASE_INDEX',str(i))
    (out/'probe.gdb').write_text(script)
    gdbroot=Path(plan['gdbroot'])
    env={'PATH':'/usr/bin:/bin','LC_ALL':'C','LD_LIBRARY_PATH':str(gdbroot/'usr/lib/x86_64-linux-gnu'),'DEBUGINFOD_URLS':''}
    cmd=[str(gdbroot/'usr/bin/gdb'),'-nx','-q','-batch','-x',str(out/'probe.gdb'),'--args',*case['argv']]
    start=time.monotonic();p=subprocess.Popen(cmd,cwd=case['cwd'],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True)
    timeout=False
    try:log,_=p.communicate(timeout=90)
    except subprocess.TimeoutExpired:
        timeout=True;os.killpg(p.pid,signal.SIGTERM);log,_=p.communicate(timeout=10)
    (out/'debugger.log').write_text(log)
    summary=json.loads((out/'summary.json').read_text()) if (out/'summary.json').exists() else {}
    result={'case':case['name'],'returncode':p.returncode,'elapsed_seconds':time.monotonic()-start,'timeout':timeout,'summary':summary,'command':cmd,'debugger_environment':env}
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');results.append(result)
    (ROOT/'result.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(result),flush=True)
    if p.returncode or timeout or not summary.get('completed'):
        print(log,flush=True);raise SystemExit(1)
for path,expected in plan['file_identities'].items():assert identity(path)==expected,path
print('Five new Ptree captures complete; no typing, connection, server or solver execution after the cut.')
