"""Run the retained stack observer on three exact source fixtures."""
from pathlib import Path
import json
import subprocess
import sys

root = Path(sys.argv[1]).resolve()
assets = root / 'tmp/review-stack'
sys.path.insert(0, str(root))
from scripts.check_evidence import audit_reports

binary = root / '.silver/linux-x86_64/compiler/bin/silver'
results = assets / 'results'
results.mkdir(exist_ok=True)
for name in ('counted', 'foreach-singleton', 'counted-slice'):
    source = assets / (name + '.adb')
    destination = results / name
    subprocess.run([sys.executable, str(assets / 'observe.py'), str(binary),
                    str(source), str(destination)], check=True)
    record = json.loads((destination / 'observation.json').read_text())
    assert [item['name'] for item in record['observations']] == ['check', 'compile', 'execute']
    workspace = Path(record['workspace'])
    assert (workspace / 'main.adb').read_bytes() == source.read_bytes()
    expected = b'8192\nx\n' if name == 'counted-slice' else b'8192\n'
    assert (destination / 'execute.log').read_bytes() == expected
    audit_reports(workspace / 'obj/gnatprove',
                  {'main', 'silver_io', 'silver_output_libc', 'silver_arguments', 'silver_runtime'},
                  {'silver_output_libc', 'silver_runtime'}, application_kind='static', indexed_main=True)
    print(name + ': same-source and independent report audit passed', flush=True)
