#!/usr/bin/env python3
"""Read Silver evidence from the checkout, retained tarballs and ext4 images."""
import argparse
import collections
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

EXPORT = Path(__file__).resolve().parent
ROOT = Path('/Volumes/EXTERNAL/Users/rebecca/src/github.com/berkeleynerd/silver')
STORE = Path('/Volumes/EXTERNAL/Users/rebecca/Library/Application Support/com.docker.sandboxes/sandboxes/sandboxd/containerd/root')
IMAGE = STORE / 'com.docker.volume.driver.v1.block/images/silver-m4pro-docker.img'
DEBUGFS_HOME = EXPORT / 'tools/e2fsprogs/1.47.4'
RETAINED = ROOT / 'tmp/sandbox-archive-20261119'
P = '001c50dce1bcf3ad2d174b4426f684fe78cb2e64'
BASE = 'a03c7987bbba29569db2709820bd26ced20bed40'
EVIDENCE = 'docs/evidence/named-scalar-arguments-392-20261117/'
RECORDS = EXPORT / 'records'
LEAN = EXPORT / 'lean'
VOL = '/volumes/silver-recovery-370-20261115/_data'
UPPER = VOL + '/named-392-lean-overlays/named-source-392/upper'
LOWER = '/agent-work/silver-worktrees/procedures-lean-370/.silver/linux-aarch64/proof'
NATIVE = VOL + '/named-392-native-artifacts'
PR_RUNS = '/agent-work/silver-review/runs/pr402-9b5b2d99aa/checkout/.git/silver-runs/linux-aarch64/e513549bff0f5897/runs'
LOCAL_RUNS = ROOT / '.git/silver-runs/linux-aarch64/e513549bff0f5897/runs'
PR_IDS = [
    '20261118T173931-305d1781f71e', '20261118T173536-c2d8662ad230',
    '20261118T173513-f3c45b223d1e', '20261118T173927-90b8193aa993',
]
LEAN_ID = '20261117T064945-d458c99ae977'
NATIVE_IDS = ['20261117T034048-8c22c1e6a33d', '20261117T055412-08a00820e2ef']


def put(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def dump_json(path, data):
    put(path, (json.dumps(data, indent=2, sort_keys=True) + '\n').encode())


def git(*args, cwd=ROOT):
    return subprocess.check_output(['git', '-C', str(cwd), *args])


def gitfile(name):
    return git('show', P + ':' + name)


def debugfs(commands, image=IMAGE):
    env = dict(os.environ, DYLD_LIBRARY_PATH=f'{DEBUGFS_HOME}/lib:/opt/homebrew/opt/gettext/lib')
    if isinstance(commands, str):
        args = ['-R', commands]
    else:
        cmds = EXPORT / 'tools/debugfs-read-commands.txt'
        cmds.write_text('\n'.join(commands) + '\n')
        args = ['-f', str(cmds)]
    return subprocess.run(
        [str(DEBUGFS_HOME / 'sbin/debugfs'), *args, str(image)], env=env,
        capture_output=True, check=True,
    )


def image_file(path):
    result = debugfs(f'cat {path}')
    messages = result.stderr.decode().splitlines()[1:]
    if messages:
        raise OSError(f'{path}: {messages}')
    return result.stdout


def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def compare(roots, hashes):
    entries = []
    for key, expected in hashes.items():
        path = roots(key)
        item = {'path': key, 'resolved': str(path), 'expected': expected}
        try:
            item['actual'] = sha(path)
            item['status'] = 'matching' if item['actual'] == expected else 'changed'
        except FileNotFoundError:
            item['status'] = 'missing'
        except OSError as error:
            item.update(status='unreadable', error=str(error))
        entries.append(item)
    return {'counts': dict(collections.Counter(x['status'] for x in entries)), 'entries': entries}


def copy_archive_files(archive, dest, allow):
    with tarfile.open(RETAINED / archive, 'r:gz') as tar:
        for member in tar:
            path = Path(member.name)
            if member.isfile() and not path.is_absolute() and '..' not in path.parts and allow(member.name):
                put(dest / path, tar.extractfile(member).read())


def preserve_layers():
    for source, dest, log in [
        (LOWER, LEAN / 'layers/lower', LEAN / 'lower-read.log'),
        (UPPER, LEAN / 'layers', LEAN / 'upper-read.log'),
    ]:
        if log.exists():
            continue
        dest.mkdir(parents=True, exist_ok=True)
        result = debugfs(f'rdump {source} {dest}')
        put(log, result.stdout + result.stderr)


def overlay_metadata(upper):
    directories = [upper] + sorted(p for p in upper.rglob('*') if p.is_dir() and not p.is_symlink())
    paths = [upper] + sorted(upper.rglob('*'))
    def in_image(path):
        suffix = path.relative_to(upper).as_posix()
        return UPPER if suffix == '.' else UPPER + '/' + suffix
    commands = [f'ls -p {in_image(p)}' for p in directories]
    commands += [f'ea_list {in_image(p)}' for p in paths]
    raw = debugfs(commands)
    # Keep overlay attributes and special entries in a compact record, including
    # device whiteouts that rdump cannot materialize as an unprivileged user.
    attributes, whiteouts, special = {}, [], []
    name = ''
    for line in raw.stdout.decode(errors='replace').splitlines():
        if line.startswith('debugfs: '):
            _, action, name = line.split(' ', 2)
        elif line.lstrip().startswith(('trusted.overlay.', 'user.overlay.')):
            attributes.setdefault(name, []).append(line.strip())
        elif line.startswith('/') and line.count('/') >= 6:
            parts = line.split('/')
            if parts[1] == '0' or parts[5] in ('.', '..'):
                continue
            kind = int(parts[2], 8) & 0o170000
            if kind not in (0o040000, 0o100000, 0o120000):
                full = name + '/' + parts[5]
                info = debugfs(f'stat {full}').stdout.decode(errors='replace')
                special.append({'path': full, 'stat': info})
                if kind == 0o020000 and re.search(r'\b0[0]*:0[0]*\b', info):
                    whiteouts.append(full)
    for path, attrs in attributes.items():
        if any(re.search(r'\.whiteout\b', attr) for attr in attrs):
            whiteouts.append(path)
    metadata = {'opaque_or_other_overlay_attributes': attributes, 'whiteouts': whiteouts, 'special_entries': special,
                'uninterpreted_debugfs_messages': raw.stderr.decode(errors='replace').splitlines()[1:]}
    dump_json(LEAN / 'overlay-metadata.json', metadata)
    return metadata


def lean():
    committed = LEAN / 'reference'
    for name in ['final-run/evidence.json', 'final-run/launcher.json', 'final-run/summary.json',
                 'final-run/verification.json', 'final-run/managed-events.jsonl.gz',
                 'disk-assessment/disk-artifact-inventory.json']:
        put(committed / name, gitfile(EVIDENCE + 'complete-lean/' + name))
    put(committed / 'setup.md', gitfile(EVIDENCE + 'setup/README.md'))
    reference = json.loads((committed / 'final-run/evidence.json').read_bytes())
    source = ROOT / 'tmp/named-source-392/.silver/linux-aarch64'
    for filename in ['lean-proof.log', 'lean-evidence.json', 'lean-focused.log', 'lean-focused-evidence.json']:
        p = source / filename
        if p.is_file():
            put(LEAN / 'adjacent' / filename, p.read_bytes())
    if (source / 'src').is_symlink():
        (LEAN / 'adjacent/src').symlink_to(os.readlink(source / 'src'))
    if (LOCAL_RUNS / LEAN_ID).is_dir():
        shutil.copytree(LOCAL_RUNS / LEAN_ID, LEAN / 'managed-run' / LEAN_ID, symlinks=True)
    preserve_layers()
    lower = LEAN / 'layers/lower/proof'
    upper = LEAN / 'layers/upper'
    metadata = overlay_metadata(upper)
    merged = LEAN / 'proof'
    shutil.copytree(lower, merged, symlinks=True, copy_function=os.link)
    for name in metadata['whiteouts']:
        target = merged / name.removeprefix(UPPER + '/')
        if target.is_dir() and not target.is_symlink():
            shutil.rmtree(target)
        else:
            target.unlink(missing_ok=True)
    for directory, dirs, files in os.walk(upper):
        parent = Path(directory)
        rel = parent.relative_to(upper)
        dest = merged / rel
        if dest.is_symlink() or (dest.exists() and not dest.is_dir()):
            dest.unlink()
        attrs = metadata['opaque_or_other_overlay_attributes'].get(UPPER + '/' + rel.as_posix(), [])
        if any('.opaque' in a and re.search(r'=\s*"y"', a) for a in attrs) and dest.exists():
            shutil.rmtree(dest)
        dest.mkdir(parents=True, exist_ok=True)
        for filename in files + [name for name in dirs if (parent / name).is_symlink()]:
            p = parent / filename
            if UPPER + '/' + p.relative_to(upper).as_posix() in metadata['whiteouts']:
                continue
            target = dest / filename
            if target.is_dir() and not target.is_symlink():
                shutil.rmtree(target)
            else:
                target.unlink(missing_ok=True)
            if p.is_symlink():
                target.symlink_to(os.readlink(p))
            else:
                os.link(p, target)
    layers = {'merged_snapshot_view': merged, 'lower': lower, 'upper': upper,
              'empty_host_mount_stub': source / 'proof'}
    results = {}
    for label, directory in layers.items():
        results[label] = {
            'workspace_inputs': compare(lambda key: directory / key, reference['workspace_inputs_sha256']),
            'artifacts': compare(lambda key: directory / key, reference['artifacts_sha256']),
        }
    dump_json(LEAN / 'hash-comparison.json', results)
    dump_json(LEAN / 'paths.json', {
        'original_worktree': str(source.parent.parent),
        'merged_mount_at_collection': 'absent; host directory is empty',
        'source_checkout_head': git('rev-parse', 'HEAD', cwd=source.parent.parent).decode().strip(),
        'lower_original': '/home/agent/silver-worktrees/procedures-lean-370/.silver/linux-aarch64/proof',
        'upper_original': '/home/agent/silver-workspaces/recovery-volume/named-392-lean-overlays/named-source-392/upper',
        'work_original': '/home/agent/silver-workspaces/recovery-volume/named-392-lean-overlays/named-source-392/work',
        'image': str(IMAGE), 'lower_in_image': LOWER, 'upper_in_image': UPPER,
        'mount_kind': 'Linux overlay; offline view built within export using retained layers',
        'adjacent_src_target': os.readlink(source / 'src'),
        'cache_marker_sha256': sha(merged / '.silver-cache-tools.json'),
        'lean_proof_log_matches_manifest': sha(LEAN / 'adjacent/lean-proof.log') == reference['log_sha256'],
        'symlinks_in_merged_view': {p.relative_to(merged).as_posix(): os.readlink(p)
                                    for p in merged.rglob('*') if p.is_symlink()},
    })
    for label, comparisons in results.items():
        print(label, {key: x['counts'] for key, x in comparisons.items()}, flush=True)


def native():
    dest = RECORDS / 'native-392'
    paths = ['README.md', 'proof-provenance.json', 'original-terminal-exits.json',
             'managed-runs.json', 'proof-inputs.json', 'initial-state.json', 'audit-verification.json']
    for name in paths:
        put(dest / 'committed' / name, gitfile(EVIDENCE + 'complete-native/' + name))
    for name in ['README.md', 'native-cache.json', 'native-suite-lean-tools.json']:
        put(dest / 'committed/setup' / name, gitfile(EVIDENCE + 'setup/' + name))
    d = json.loads((dest / 'committed/proof-provenance.json').read_bytes())
    work = ROOT / 'tmp/named-native-392'
    paths = {}
    for name in d['inputs_sha256']:
        existing = work / name
        if name.startswith('.silver/linux-aarch64/'):
            image_path = NATIVE + '/' + name.removeprefix('.silver/linux-aarch64/')
            try:
                put(dest / 'supporting-inputs' / name, image_file(image_path))
                paths[name] = {'recorded_path': str(existing), 'ext4_path': image_path,
                               'export_path': 'supporting-inputs/' + name}
            except OSError as error:
                paths[name] = {'recorded_path': str(existing), 'ext4_path': image_path, 'error': str(error)}
        elif name.startswith('.tools/') and existing.is_file():
            put(dest / 'supporting-inputs' / name, existing.read_bytes())
            paths[name] = {'recorded_path': str(existing), 'export_path': 'supporting-inputs/' + name}
    inputs_original = compare(lambda key: work / key, d['inputs_sha256'])
    inputs_recovered = compare(lambda key: dest / paths[key]['export_path']
                               if key in paths and 'export_path' in paths[key] else work / key, d['inputs_sha256'])
    tool_paths = {v['path']: v['sha256'] for v in d['tools'].values()}
    tools = compare(Path, tool_paths)
    dump_json(dest / 'hash-comparison.json', {'inputs_at_recorded_host_paths': inputs_original,
              'inputs_with_readonly_bind_recovery': inputs_recovered, 'tools_at_recorded_paths': tools})
    dump_json(dest / 'supporting-input-path-map.json', paths)
    for run_id in NATIVE_IDS:
        for name in ['lease', 'native.log', 'events.jsonl']:
            p = LOCAL_RUNS / run_id / name
            if p.is_file():
                put(dest / 'managed-runs' / run_id / name, p.read_bytes())
    overlay = NATIVE + '/image-tools'
    dirs = ['', '/bin', '/libexec', '/libexec/spark', '/libexec/spark/bin']
    layout = {}
    for tail in dirs:
        p = overlay + tail
        for line in debugfs(f'ls -p {p}').stdout.decode().splitlines():
            fields = line.split('/')
            if len(fields) < 7 or fields[5] in ('.', '..') or not fields[5]:
                continue
            name = p + '/' + fields[5]
            kind = int(fields[2], 8) & 0o170000
            item = {'kind': {0o040000: 'directory', 0o100000: 'file', 0o120000: 'symlink'}.get(kind, str(kind))}
            if kind == 0o120000:
                s = debugfs(f'stat {name}').stdout.decode()
                target = re.search(r'Fast link dest: "(.*)"', s)
                item['target'] = target[1] if target else image_file(name).decode()
            if kind == 0o100000 and name.endswith('/bin/gnatprove'):
                item['sha256'] = hashlib.sha256(image_file(name)).hexdigest()
            layout[name.removeprefix(overlay + '/')] = item
    config = (dest / 'supporting-inputs/.silver/linux-aarch64/generated/silver_image_config.ads').read_text()
    vendor_path, vendor_hash = re.findall(r':= "([^"]+)";', config)
    vendor = compare(lambda key: Path(key), {vendor_path: vendor_hash})
    adapter_target = layout['libexec/spark/bin/gnatwhy3']['target']
    adapter_path = NATIVE + '/' + adapter_target.split('/.silver/linux-aarch64/', 1)[1]
    adapter_hash = hashlib.sha256(image_file(adapter_path)).hexdigest()
    dump_json(dest / 'image-overlay.json', {'original': str(work / '.silver/linux-aarch64/image-tools'),
              'ext4_image_path': overlay, 'layout': layout, 'vendor_binding': vendor,
              'adapter_target_ext4_path': adapter_path, 'adapter_target_sha256': adapter_hash,
              'compiler_copy_matches_vendor_gnatprove': layout['bin/gnatprove']['sha256'] == d['tools']['gnatprove']['sha256']})
    print('native', inputs_original['counts'], inputs_recovered['counts'], tools['counts'], flush=True)


def delivery():
    copy_archive_files('review-and-run-records.tar.gz', RECORDS / 'workflow-packet',
                       lambda name: name.startswith('runs/dev400-a03c7987bb/'))
    pipeline_files = {'develop-criteria.md', 'develop-criteria-doc.md', 'develop-checks.md',
                      'develop-checks-doc.md', 'develop-notes.md', 'develop-notes-checked.md',
                      'develop-change.md', 'develop-scope.md', 'develop-published.md',
                      'develop-result.json', 'silverDevelopCheck-verdict.json',
                      'develop-check-failed.md', 'develop-pr.md'}
    copy_archive_files('worca-state.tar.gz', RECORDS / 'worca-packet',
                       lambda name: '/18-11-26-develop-issue-400-' in name
                       and Path(name).name in pipeline_files)
    for run_id in PR_IDS:
        for name in ['lease', 'native.log', 'events.jsonl']:
            put(RECORDS / 'managed-runs-403' / run_id / name, image_file(f'{PR_RUNS}/{run_id}/{name}'))
    for name in ['README.md', 'inputs.sha256', 'probes.tar.gz', 'render.txt']:
        path = 'docs/evidence/bounded-string-building-400-20261118/' + name
        put(RECORDS / 'committed-pr403' / path, gitfile(path))
    dump_json(RECORDS / 'provenance.json', {
        'repository': str(ROOT),
        'local_main': git('rev-parse', 'HEAD').decode().strip(),
        'published_main': BASE, 'published_main_tree': git('rev-parse', BASE + '^{tree}').decode().strip(),
        'pr_head': P, 'pr_tree': git('rev-parse', P + '^{tree}').decode().strip(),
        'managed_run_source_image': str(IMAGE), 'managed_run_image_prefix': PR_RUNS,
        'workflow_packet_source': str(RETAINED / 'review-and-run-records.tar.gz'),
        'worca_packet_source': str(RETAINED / 'worca-state.tar.gz'),
    })


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('section', choices=['delivery', 'lean', 'native'])
    args = ap.parse_args()
    {'delivery': delivery, 'lean': lean, 'native': native}[args.section]()
