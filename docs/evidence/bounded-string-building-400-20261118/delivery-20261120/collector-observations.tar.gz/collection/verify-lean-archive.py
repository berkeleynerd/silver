#!/usr/bin/env python3
"""Verify recorded workspace hashes from the transfer archive itself."""
import collections
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

root = Path(__file__).resolve().parent
archive = root / 'lean-392-cache.tar.zst'
manifest = json.loads((root / 'lean/reference/final-run/evidence.json').read_bytes())
groups = {name: {'proof/' + path: digest for path, digest in manifest[name].items()}
          for name in ['workspace_inputs_sha256', 'artifacts_sha256']}
expected = set().union(*(group.keys() for group in groups.values()))
digests = {}
links = {}
with subprocess.Popen(['zstd', '-dc', str(archive)], stdout=subprocess.PIPE) as proc:
    with tarfile.open(fileobj=proc.stdout, mode='r|') as tar:
        for member in tar:
            if member.isfile():
                digests[member.name] = hashlib.file_digest(tar.extractfile(member), 'sha256').hexdigest()
            elif member.islnk():
                links[member.name] = member.linkname
    proc.stdout.read()
    assert proc.wait() == 0
for name in expected & links.keys():
    target = links[name]
    visited = {name}
    while target in links:
        assert target not in visited, (name, 'link cycle')
        visited.add(target)
        target = links[target]
    if target in digests:
        digests[name] = digests[target]
result = {}
for kind, group in groups.items():
    comparisons = collections.defaultdict(list)
    for path, digest in group.items():
        actual = digests.get(path)
        comparisons['matching' if actual == digest else 'missing' if actual is None else 'changed'].append(path)
    result[kind] = {status: len(comparisons[status]) for status in ('matching', 'missing', 'changed')}
    result[kind]['missing_paths'] = comparisons['missing']
    result[kind]['changed_paths'] = comparisons['changed']
(root / 'lean-archive-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(result)
assert all(not group['missing'] and not group['changed'] for group in result.values())
