#!/usr/bin/env python3
"""Extract #400 pipeline identity and two evidence excerpts from retained state."""
import hashlib
import json
from pathlib import Path
import tarfile

from collect import RECORDS, RETAINED, dump_json, put

archive = RETAINED / 'worca-state.tar.gz'
transcript_id = '01a1efcf-4e3d-7a63-a8f8-0763d8badf02.jsonl'
with tarfile.open(archive, 'r|gz') as tar:
    for member in tar:
        if not member.isfile():
            continue
        if '/18-11-26-develop-issue-400-' in member.name:
            name = Path(member.name).name
            if name == 'run.json':
                obj = json.load(tar.extractfile(member))
                keys = ['pipelineId', 'runRootMode', 'isWorkspace', 'members']
                dump_json(RECORDS / 'worca-packet' / Path(member.name).parent / 'run-identity.json',
                          {key: obj.get(key) for key in keys})
            elif name == 'results.json':
                put(RECORDS / 'worca-packet' / member.name, tar.extractfile(member).read())
        if member.name.endswith(transcript_id):
            raw = tar.extractfile(member).read()
            rows = raw.splitlines()
            excerpts = RECORDS / 'worca-packet/retained-criteria-tool-output'
            for line, name in [(151, 'filtered-original-events.jsonl'),
                               (158, 'historical-after-run-input-comparison.txt')]:
                item = json.loads(rows[line - 1])['payload']['item']
                put(excerpts / name, item['aggregated_output'].encode())
            dump_json(excerpts / 'excerpt-sources.json', {
                'source_archive': str(archive), 'member': member.name,
                'member_sha256': hashlib.sha256(raw).hexdigest(),
                'lines': [151, 158], 'field': 'payload.item.aggregated_output',
                'note': 'Contemporaneous Worca check excerpts. The source transcript is excluded.',
            })
