#!/usr/bin/env python3
"""Read the recorded ARM Python executable from its offline EROFS image."""
import hashlib
import json
import os
import subprocess

from collect import EXPORT, RECORDS, STORE, dump_json, put

PATH = '/usr/bin/python3.14'
IMAGE = STORE / 'io.containerd.snapshotter.v1.erofs/snapshots/70/layer.erofs'
TOOL = EXPORT / 'tools/erofs-utils/1.9.4/bin/dump.erofs'

native = RECORDS / 'native-392'
manifest = json.loads((native / 'committed/proof-provenance.json').read_bytes())
expected = next(tool['sha256'] for tool in manifest['tools'].values() if tool['path'] == PATH)
data = subprocess.check_output([str(TOOL), f'--path={PATH}', '--cat', str(IMAGE)],
                              env=dict(os.environ, DYLD_LIBRARY_PATH='/opt/homebrew/opt/lz4/lib:/opt/homebrew/opt/xz/lib'))
actual = hashlib.sha256(data).hexdigest()
assert data.startswith(b'\x7fELF') and int.from_bytes(data[18:20], 'little') == 183
output = RECORDS / 'arm-tools/usr/bin/python3.14'
put(output, data)
record = {'status': 'matching' if actual == expected else 'changed',
          'recorded_path': PATH, 'expected_sha256': expected, 'actual_sha256': actual,
          'export_path': str(output.relative_to(RECORDS)), 'erofs_image': str(IMAGE),
          'architecture': 'Linux aarch64 ELF'}
dump_json(RECORDS / 'arm-python.json', record)
comparison_path = native / 'hash-comparison.json'
comparison = json.loads(comparison_path.read_bytes())
direct = comparison['tools_at_recorded_paths']
mapped = [entry for entry in direct['entries'] if entry['path'] != PATH] + [record]
from collections import Counter
comparison['tools_with_readonly_image_recovery'] = {
    'counts': dict(Counter(entry['status'] for entry in mapped)), 'entries': mapped,
}
dump_json(comparison_path, comparison)
print('Python recovered', record['status'], actual)
