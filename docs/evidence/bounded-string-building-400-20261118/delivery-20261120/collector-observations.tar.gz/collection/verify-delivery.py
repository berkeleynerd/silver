#!/usr/bin/env python3
"""Cross-check the retrieved #400 delivery records without running Silver."""
import collections
import hashlib
import json
from pathlib import Path
import subprocess
import zlib

from collect import (BASE, EXPORT, IMAGE, P, PR_IDS, PR_RUNS, RECORDS,
                     ROOT, compare, debugfs, dump_json, git, image_file, put)

GIT_PREFIX = PR_RUNS.split('/silver-runs/', 1)[0]
CHECKOUT = GIT_PREFIX.removesuffix("/.git")
RECORDED_CHECKOUT = "/home/agent/silver-review/runs/pr402-9b5b2d99aa/checkout"
CHECKED = '7d5967240779a46f73d1c29746d77e530f81f906'
WORKFLOW = RECORDS / 'workflow-packet/runs/dev400-a03c7987bb/artifacts/checks-1'


def hash_git_blobs(names):
    """Read named blobs from the published PR tree without updating the index."""
    result = {}
    with subprocess.Popen(['git', '-C', str(ROOT), 'cat-file', '--batch'],
                          stdin=subprocess.PIPE, stdout=subprocess.PIPE) as process:
        for name in names:
            process.stdin.write(f'{P}:{name}\n'.encode())
            process.stdin.flush()
            header = process.stdout.readline().decode().split()
            if header[-1] == 'missing':
                result[name] = None
                continue
            _, kind, size = header
            assert kind == 'blob'
            result[name] = hashlib.sha256(process.stdout.read(int(size))).hexdigest()
            assert process.stdout.read(1) == b'\n'
        process.stdin.close()
        assert process.wait() == 0
    return result


def read_events(path):
    return [json.loads(x) for x in path.read_bytes().splitlines()]


def get_event(events, name):
    return next(r for r in events if r['event'] == name)


def main():
    original = RECORDS / 'managed-runs-403'
    runs, inventories = [], []
    names = ['suite.log', 'test_samples.py.log', 'test_string_characters.py.log', 'test_rosetta.py.log']
    for run, name in zip(PR_IDS, names):
        directory = original / run
        events = read_events(directory / 'events.jsonl')
        source_log = (directory / 'native.log').read_bytes()
        workflow_log = (WORKFLOW / name).read_bytes()
        assert workflow_log.split(b'\n', 1)[1] == source_log
        inventories.append(get_event(events, 'prepared')['inputs']['inputs_sha256'])
        runs.append({
            'run_id': run, 'workflow_log': name, 'start': get_event(events, 'started'),
            'command': get_event(events, 'command'), 'finish': get_event(events, 'finished'),
            'test_phase_exit': [x for x in events if x['event'] == 'phase-end' and x.get('phase') == 'test'],
            'original_log_trailer': source_log.decode(errors='replace').splitlines()[-3:],
            'log_sha256': hashlib.sha256(source_log).hexdigest(),
            'workflow_log_is_original_with_managed_run_banner': True,
        })
    assert all(inventory == inventories[0] for inventory in inventories)
    full = inventories[0]
    repository = {key.removeprefix(RECORDED_CHECKOUT + '/'): value
                  for key, value in full.items()
                  if key.startswith(RECORDED_CHECKOUT + '/') and '/.silver/' not in key}
    local_hashes = hash_git_blobs(repository)
    verified = [{'path': key, 'expected': value, 'pr_blob_sha256': local_hashes[key],
                 'status': ('matching' if local_hashes[key] == value else
                            'missing' if local_hashes[key] is None else 'changed')}
                for key, value in sorted(repository.items())]
    support = {}
    for name, expected in full.items():
        if name.startswith(RECORDED_CHECKOUT + '/.silver/'):
            relative = name.removeprefix(RECORDED_CHECKOUT + '/')
            location = CHECKOUT + '/' + relative
            try:
                data = image_file(location)
            except OSError:
                support[name] = {'status': 'missing', 'expected_sha256': expected, 'ext4_path': location}
                continue
            output = original / 'supporting-inputs' / relative
            put(output, data)
            actual = hashlib.sha256(data).hexdigest()
            support[name] = {'status': 'matching' if actual == expected else 'changed',
                             'expected_sha256': expected, 'actual_sha256': actual,
                             'ext4_path': location, 'export_path': str(output.relative_to(RECORDS))}
        elif not name.startswith(RECORDED_CHECKOUT + '/'):
            python_record = RECORDS / 'arm-python.json'
            support[name] = (json.loads(python_record.read_bytes()) if python_record.is_file()
                             else {'status': 'missing', 'expected_sha256': expected})
    fetch = image_file(GIT_PREFIX + '/FETCH_HEAD')
    assert fetch.split()[0].decode() == CHECKED
    put(original / 'checked-identity/FETCH_HEAD', fetch)
    history = image_file(GIT_PREFIX + '/logs/HEAD')
    put(original / 'checked-identity/HEAD-reflog-excerpt',
        b''.join(x + b'\n' for x in history.splitlines() if CHECKED.encode() in x))
    pack_path = GIT_PREFIX + '/objects/pack/pack-a0e78c583698d7593efbf2e69cb95a3ea9040581.pack'
    pack = image_file(pack_path)
    assert pack[:4] == b'PACK'
    first = pack[12]
    assert (first >> 4) & 0x07 == 1
    start = 13
    last = first
    while last & 0x80:
        last = pack[start]
        start += 1
    commit = zlib.decompress(pack[start:])
    assert hashlib.sha1(f'commit {len(commit)}\0'.encode() + commit).hexdigest() == CHECKED
    tree = git('rev-parse', P + '^{tree}').decode().strip()
    assert commit.startswith(f'tree {tree}\nparent {BASE}\n'.encode())
    put(original / 'checked-identity/commit.txt', commit)
    dump_json(original / 'checked-identity/verification.json',
              {'checked_commit': CHECKED, 'pr_commit': P, 'published_main_at_check': BASE,
               'shared_tree': tree, 'pack_source': pack_path,
               'pack_sha256': hashlib.sha256(pack).hexdigest()})
    dump_json(original / 'input-inventory-comparison.json', {
        'same_inventory_in_all_four_runs': True, 'total_entries': len(full),
        'repository_counts': dict(collections.Counter(x['status'] for x in verified)),
        'repository_entries': verified, 'supporting_inputs': support,
        'comparison_kind': 'read-only recovery comparison with Git blobs and the retained image',
        'historical_postflight': 'no postflight record found in original managed run or workflow packet',
    })
    dump_json(original / 'run-summary.json', {'runs': runs, 'invoking_stack_limit': 'not recorded'})
    print(len(full), dict(collections.Counter(x['status'] for x in verified)),
          {k.rsplit('/', 1)[-1]: x['status'] for k, x in support.items()}, flush=True)


if __name__ == '__main__':
    main()
