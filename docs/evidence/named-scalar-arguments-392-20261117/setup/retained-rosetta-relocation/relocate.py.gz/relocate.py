from pathlib import Path
import hashlib, json, os, shutil, stat, subprocess, sys
from datetime import datetime, timezone

base = Path('/home/agent/silver-workspaces/recovery-volume')
source = base / 'rosetta'
destination = Path('/Volumes/EXTERNAL/Users/rebecca/src/github.com/berkeleynerd/silver/tmp/retained-source-checkouts-392/rosetta')
backing = base / 'rosetta-relocated-backing-392'
record = Path(__file__).resolve().parent / 'retained-rosetta-relocation-392'
record.mkdir(exist_ok=True)

def run(*args):
    return subprocess.check_output(args, text=True).strip()

def save(name, value):
    (record / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def git_state(path):
    return {'head': run('git', '-C', str(path), 'rev-parse', 'HEAD'),
            'status': run('git', '-C', str(path), 'status', '--porcelain=v1', '--untracked-files=all')}

def inventory(path):
    result = {}
    def walk(current):
        for entry in sorted(os.scandir(current), key=lambda e: e.name):
            p = Path(entry.path)
            s = p.lstat()
            item = {'mode': stat.S_IMODE(s.st_mode), 'uid': s.st_uid, 'gid': s.st_gid}
            if stat.S_ISLNK(s.st_mode):
                item.update(kind='symlink', target=os.readlink(p))
            elif stat.S_ISDIR(s.st_mode):
                item.update(kind='directory')
            elif stat.S_ISREG(s.st_mode):
                with p.open('rb') as f:
                    item.update(kind='file', size=s.st_size,
                                sha256=hashlib.file_digest(f, 'sha256').hexdigest())
            else:
                raise RuntimeError('Unexpected special file: ' + str(p))
            result[str(p.relative_to(path))] = item
            if item['kind'] == 'directory':
                walk(p)
    walk(path)
    return result

def assert_inactive():
    assert source.is_dir() and not source.is_mount()
    assert not (source / '.silver').exists() and not (source / '.tools').exists()
    target = str(source)
    assert target not in Path('/proc/self/mountinfo').read_text()
    references = []
    for process in Path('/proc').iterdir():
        if not process.name.isdigit() or int(process.name) == os.getpid():
            continue
        try:
            command = (process / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
            if target in command:
                references.append((process.name, 'command', command))
            paths = [process / 'cwd', process / 'root'] + list((process / 'fd').iterdir())
            for p in paths:
                try:
                    linked = os.readlink(p)
                    if linked == target or linked.startswith(target + '/'):
                        references.append((process.name, str(p), linked))
                except OSError:
                    pass
        except (OSError, ProcessLookupError):
            pass
    assert not references, references
    sys.path.insert(0, str(Path.cwd()))
    from scripts.platforms import native_layout
    from scripts.run_history import status
    active = [r for r in status(native_layout(Path.cwd()))['runs'] if r['active']]
    assert all(target not in json.dumps(row) for row in active)
    return {'active_run_ids': [r['run_id'] for r in active], 'process_references': references,
            'no_mount_reference': True, 'no_root_tools_or_artifacts': True}

phase = sys.argv[1]
if phase == 'copy':
    assert not destination.exists() and not backing.exists()
    checks = assert_inactive()
    state = git_state(source)
    before = inventory(source)
    save('source-inventory.json', before)
    destination.mkdir(parents=True)
    subprocess.run(['cp', '-a', str(source) + '/.', str(destination)], check=True)
    assert inventory(source) == before, 'Original changed during copy'
    assert inventory(destination) == before, 'Copy differs'
    assert git_state(source) == state == git_state(destination)
    facts = {'source': str(source), 'destination': str(destination), 'backing': str(backing),
             'utc': datetime.now(timezone.utc).isoformat(), 'git': state,
             'entries': len(before), 'regular_files': sum(v['kind'] == 'file' for v in before.values()),
             'regular_bytes': sum(v.get('size', 0) for v in before.values()),
             'copied_and_verified': True, 'reference_checks': checks}
    save('copy-verification.json', facts)
    print(json.dumps(facts, indent=2))
elif phase == 'mount':
    facts = json.loads((record / 'copy-verification.json').read_text())
    before = json.loads((record / 'source-inventory.json').read_text())
    assert_inactive()
    assert not backing.exists()
    assert inventory(source) == before == inventory(destination)
    assert git_state(source) == facts['git'] == git_state(destination)
    source.rename(backing)
    source.mkdir()
    try:
        subprocess.run(['sudo', 'mount', '--bind', str(destination), str(source)], check=True)
    except BaseException:
        source.rmdir()
        backing.rename(source)
        raise
    assert source.is_mount()
    assert inventory(source) == before == inventory(backing)
    assert git_state(source) == facts['git']
    facts.update(mounted=True, original_path_preserved=True, post_mount_verified=True,
                 mount=run('findmnt', '-n', '-o', 'TARGET,SOURCE,FSTYPE', '--target', str(source)),
                 utc=datetime.now(timezone.utc).isoformat())
    save('mount-verification.json', facts)
    print(json.dumps(facts, indent=2))
elif phase == 'reclaim':
    facts = json.loads((record / 'mount-verification.json').read_text())
    before = json.loads((record / 'source-inventory.json').read_text())
    assert source.is_mount() and backing.is_dir() and not backing.is_mount()
    assert inventory(source) == before == inventory(destination) == inventory(backing)
    assert git_state(source) == facts['git']
    assert source.stat().st_dev == destination.stat().st_dev != backing.stat().st_dev
    shutil.rmtree(backing)
    facts.update(verified_old_backing_removed=True, native_disk_free_bytes=shutil.disk_usage(base).free,
                 utc=datetime.now(timezone.utc).isoformat())
    save('relocation-result.json', facts)
    print(json.dumps(facts, indent=2))
else:
    raise RuntimeError('Unknown phase')
