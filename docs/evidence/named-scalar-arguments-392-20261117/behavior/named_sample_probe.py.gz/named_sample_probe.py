from pathlib import Path
import json,sys,re,subprocess,gzip,hashlib,os
probe_root=Path(__file__).resolve().parents[1]
os.chdir(probe_root)
sys.path.insert(0,str(probe_root))
from tests.test_silver import ROOT,HOST,invoke
from scripts.check_evidence import audit_reports
source=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
data=source.read_bytes()
compilation=invoke('compile',source)
(out/'compile.log').write_text(compilation.stdout)
assert compilation.returncode==0,compilation.stdout
match=re.search(r'^Executable: (.+)$',compilation.stdout,re.M);assert match
exe=Path(match[1]);exe=exe if exe.is_absolute() else ROOT/exe
workspace=exe.parent.parent
assert (workspace/'main.adb').read_bytes()==data
reports=workspace/'obj/gnatprove'
counts=audit_reports(reports,{'main','silver_io','silver_output_libc','silver_arguments','silver_runtime'}, {'silver_output_libc','silver_runtime'},application_kind='assigned',application_functions=('Subtract',),application_formals={'Subtract':(('Left','in'),('Right','in'))},indexed_main=True)
r=subprocess.run([str(exe)],capture_output=True,timeout=10)
expected=b'Positional: 2\nNamed, reordered: 2\nMixed: 2\nReversed values:-2\n'
assert (r.returncode,r.stdout,r.stderr)==(0,expected,b''),(r.returncode,r.stdout,r.stderr)
assert source.read_bytes()==data
(out/'main.adb').write_bytes(data)
(out/'stdout.txt').write_bytes(r.stdout)
for f in reports.iterdir():
 if f.suffix in ('.spark','.sarif') or f.name=='gnatprove.out':(out/(f.name+'.gz')).write_bytes(gzip.compress(f.read_bytes(),mtime=0))
summary={'source_sha256':hashlib.sha256(data).hexdigest(),'compiler_sha256':hashlib.sha256((HOST.compiler/'bin/silver').read_bytes()).hexdigest(),'native_source_sha256':hashlib.sha256((ROOT/'src/silver_output_profile.adb').read_bytes()).hexdigest(),'exit_status':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode(),'counts':counts,'workspace':str(workspace),'reports':{f.name:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for f in reports.iterdir() if f.suffix in ('.spark','.sarif')}}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
