#!/usr/bin/env python3
"""Freeze final #392 suite inputs or collect its one real managed run.

Never launches tests, builds or proofs. Freeze performs discovery only. Run this
script with the same Python and 16 MiB invoking-shell soft stack as dev.py test.
The --root must be the final, updated named-native-392 worktree, not this script's
integration worktree. Scratch evidence stays beside this script by default.
"""
from pathlib import Path
import argparse
import collections
import datetime
import hashlib
import json
import os
import re
import resource
import shutil
import subprocess
import sys
import tarfile
import unittest

EXPECTED_SKIPS = {
    'test_counted_bound_review.CountedBoundReviewTests.test_maximal_nested_loops_keep_filter_scratch_out_of_frames':
        '8 MiB stack evidence is native Linux x86-64',
    'test_output_integrity.OutputIntegrityTests.test_large_argument_vector_with_eight_mib_stack':
        'the retained 8 MiB / 190,000-argument regression is Linux x86-64',
}
STACK = 16 * 1024 * 1024
EXPECTED_COMMAND = ['-m', 'unittest', 'discover', '-s', 'tests', '-v']


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def discovery():
    loader = unittest.TestLoader()
    suite = loader.discover('tests')
    def flatten(current):
        for item in current:
            if isinstance(item, unittest.TestSuite):
                yield from flatten(item)
            else:
                yield item
    items = list(flatten(suite))
    require(not loader.errors, 'Discovery errors: ' + repr(loader.errors))
    ids = [test.id() for test in items]  # Preserve every character, including tests.
    skips = {}
    for test in items:
        method = getattr(test, test._testMethodName)
        if getattr(type(test), '__unittest_skip__', False):
            skips[test.id()] = getattr(type(test), '__unittest_skip_why__', '')
        elif getattr(method, '__unittest_skip__', False):
            skips[test.id()] = getattr(method, '__unittest_skip_why__', '')
    require(len(ids) == len(set(ids)) == 715, 'Expected exactly 715 distinct IDs')
    require(skips == EXPECTED_SKIPS, 'Unexpected platform skip inventory')
    return ids, skips


def runner_inputs(root, host, hash_paths):
    # Mirror scripts/dev.py's test selected-input construction exactly.
    selected = [root / 'scripts', Path(sys.executable).resolve()]
    selected += [root / name for name in ('tests', 'src', 'proof', 'samples', 'catalogue')
                 if (root / name).exists()]
    selected += [root / 'rosetta' / name for name in ('refresh.py', 'manifest.json', 'coverage.json')
                 if (root / 'rosetta' / name).exists()]
    selected += [path for path in (host.compiler / 'bin/silver', root / 'silver.gpr',
                                  root / 'alire.toml', host.generated, host.context)
                 if path.exists()]
    return hash_paths(selected)


def review_inputs(root, hash_paths):
    # Additional review/delivery inputs beyond the runner's three Rosetta inputs.
    selected = [root / 'rosetta.md', root / 'rosetta/assess.js',
                root / 'rosetta/progression.md',
                root / 'rosetta/assessment-named-scalar-arguments-20261117.md']
    selected += sorted((root / 'rosetta').rglob('silver.md'))
    return hash_paths(selected)


def successful_run(host, run_id, kind, status):
    rows = [row for row in status(host)['runs'] if row['run_id'] == run_id]
    require(len(rows) == 1, 'Missing/ambiguous prerequisite run ' + run_id)
    row = rows[0]
    require(row['kind'] == kind and not row['active'] and row['state'] == 'success',
            'Prerequisite run is not completed successfully: ' + run_id)
    require(row.get('finish', {}).get('outcome') == 'success',
            'No real successful prerequisite terminal event: ' + run_id)
    return row


def freeze(args, root, packet, host, api):
    require(not (packet / 'frozen-inputs.json').exists(), 'Freeze exists; retain it, do not overwrite')
    require(resource.getrlimit(resource.RLIMIT_STACK)[0] == STACK,
            'Set invoking shell soft stack with ulimit -S -s 16384 before freeze')
    actual_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
    require(actual_head == args.head, 'Final checkout HEAD differs from --head')
    tracked_status = subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all',
        '--', 'scripts', 'tests', 'src', 'proof', 'samples', 'catalogue', 'rosetta',
        'rosetta.md', 'silver.gpr', 'alire.toml'], text=True)
    require(not tracked_status, 'Suite/review inputs must be committed and frozen:\n' + tracked_status)
    current = api['status'](host)
    require(not any(row['active'] for row in current['runs']), 'Managed leases remain active')
    prerequisites = {
        'native': successful_run(host, args.native_run, 'prove', api['status']),
        'build': successful_run(host, args.build_run, 'build', api['status']),
        'lean': successful_run(host, args.lean_run, 'lean', api['status']),
    }
    require(prerequisites['native']['inputs'].get('mode') == 'full', 'Native run is not full')
    require(prerequisites['lean']['scope'] == 'complete', 'Lean run is not complete')
    require((host.compiler / 'bin/silver').is_file(), 'Missing actual compiler binary')
    require((host.compiler / 'bin/silver_image_adapter').is_file(), 'Missing Image adapter binary')
    coverage = json.loads((root / 'rosetta/coverage.json').read_text())
    require('named-scalar-arguments' in coverage['supported'], 'Final Rosetta promotion not frozen yet')
    ids, skips = discovery()
    samples = json.loads((root / 'samples/manifest.json').read_text())['samples']
    case_count = sum(1 + len(sample.get('argument_cases', [])) for sample in samples)
    require(len(samples) == 86 and case_count == 149, 'Unexpected final sample inventory')
    native_manifest = host.compiler / 'obj/gnatprove/proof-provenance.json'
    native = json.loads(native_manifest.read_text())
    native_inputs = api['input_hashes'](host)
    require(native['inputs_sha256'] == native_inputs, 'Native manifest inputs no longer match checkout')
    packet.mkdir(parents=True, exist_ok=True)
    record = dict(schema=1, frozen_utc=utc(), root=str(root), head=actual_head,
        python=str(Path(sys.executable).resolve()), stack_limits=list(resource.getrlimit(resource.RLIMIT_STACK)),
        collector_sha256=digest(__file__), prerequisites=prerequisites,
        runner_inputs_sha256=runner_inputs(root, host, api['hash_paths']),
        review_inputs_sha256=review_inputs(root, api['hash_paths']),
        native_inputs_sha256=native_inputs, native_manifest_sha256=digest(native_manifest),
        binaries_sha256={str(path): digest(path) for path in
                         (host.compiler / 'bin/silver', host.compiler / 'bin/silver_image_adapter')},
        count=len(ids), tests=ids, expected_skips=skips,
        inventory_sha256=hashlib.sha256(('\n'.join(ids) + '\n').encode()).hexdigest(),
        samples=dict(sources=len(samples), execution_cases=case_count))
    write_json(packet / 'frozen-inputs.json', record)
    print(json.dumps({k: record[k] for k in ('head', 'count', 'inventory_sha256', 'samples')}, indent=2))


def exact_outcomes(log, frozen):
    expected = set(frozen['tests'])
    outcomes, unknown, duplicates = {}, [], []
    pending = None
    for line in log.splitlines():
        start = re.match(r'^test\w* \(([^)]+)\)(.*)$', line)
        if start:
            identifier = start[1]  # Never strip or normalize module prefixes.
            if identifier not in expected:
                unknown.append(line)
                pending = None
            else:
                if identifier in outcomes:
                    duplicates.append(identifier)
                outcomes[identifier] = dict(status='unresolved', start=line)
                pending = identifier
        result = re.search(r'(?:\.\.\. |^)(ok|skipped .+|FAIL|ERROR|expected failure|unexpected success)$', line)
        if result and pending:
            outcomes[pending].update(status=result[1], result_line=line)
            pending = None
    summaries = re.findall(r'^Ran (\d+) tests? in ([\d.]+)s$', log, re.MULTILINE)
    conclusions = re.findall(r'^(?:OK(?: \([^\n]*\))?|FAILED \([^\n]*\))$', log, re.MULTILINE)
    require(not unknown and not duplicates, 'Unknown or duplicate test starts: ' + repr((unknown, duplicates)))
    require(set(outcomes) == expected, 'Missing exact IDs: ' + repr(sorted(expected - outcomes.keys())))
    require(len(summaries) == 1 and int(summaries[0][0]) == frozen['count'] == 715,
            'Expected one complete 715-test unittest summary')
    require(conclusions == ['OK (skipped=2)'], 'Unexpected unittest conclusion: ' + repr(conclusions))
    expected_skips = {name: 'skipped ' + repr(reason) for name, reason in frozen['expected_skips'].items()}
    skips = {name: row['status'] for name, row in outcomes.items() if row['status'].startswith('skipped ')}
    require(skips == expected_skips, 'Unexpected exact skipped IDs/reasons')
    require(all(row['status'] == 'ok' or name in skips for name, row in outcomes.items()),
            'Failed, errored or unresolved outcomes remain')
    require(sum(row['status'] == 'ok' for row in outcomes.values()) == 713, 'Expected 713 actual ok results')
    return dict(count=715, passed=713, skipped=skips, seconds=float(summaries[0][1]),
                conclusion=conclusions[0], outcomes=outcomes)


def collect(args, root, packet, host, api):
    frozen_path = packet / 'frozen-inputs.json'
    frozen = json.loads(frozen_path.read_text())
    require(frozen['root'] == str(root), 'Frozen checkout differs from --root')
    require(re.fullmatch(r'\d{8}T\d{6}-[0-9a-f]{12}', args.run_id), 'Invalid run ID')
    original = api['registry'](host) / 'runs' / args.run_id
    destination = packet / ('collection-' + args.run_id)
    require(not destination.exists(), 'Collection exists; retain original evidence, do not overwrite')
    destination.mkdir(parents=True)
    try:
        originals = {}
        sources = {'events.jsonl': original / 'events.jsonl', 'native.log': original / 'native.log',
                   'frozen-inputs.json': frozen_path, 'collect.py': Path(__file__).resolve(),
                   'native-proof-provenance.json': host.compiler / 'obj/gnatprove/proof-provenance.json'}
        if args.terminal_log:
            sources['external-terminal.log'] = args.terminal_log.resolve()
        for name, source in sources.items():
            before = digest(source)
            shutil.copyfile(source, destination / name)
            require(before == digest(source) == digest(destination / name), 'Unstable original: ' + str(source))
            originals[name] = dict(original=str(source), sha256=before)
        write_json(destination / 'originals.json', originals)
        require(digest(__file__) == frozen['collector_sha256'], 'Collector changed since freeze')
        require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == frozen['head'],
                'Checkout HEAD changed since freeze')
        require(runner_inputs(root, host, api['hash_paths']) == frozen['runner_inputs_sha256'],
                'Suite inputs differ from frozen snapshot')
        require(review_inputs(root, api['hash_paths']) == frozen['review_inputs_sha256'],
                'Rosetta review/render inputs differ from frozen snapshot')
        require(api['input_hashes'](host) == frozen['native_inputs_sha256'], 'Native inputs changed')
        require(digest(host.compiler / 'obj/gnatprove/proof-provenance.json') == frozen['native_manifest_sha256'],
                'Native proof manifest changed')
        require(all(digest(name) == sha for name, sha in frozen['binaries_sha256'].items()), 'Compiler/adapter changed')
        lines = (destination / 'events.jsonl').read_text().splitlines(keepends=True)
        require(lines and all(line.endswith('\n') for line in lines), 'Incomplete managed journal')
        events = [json.loads(line) for line in lines]
        started = events[0]
        require(started['event'] == 'started' and started['run_id'] == args.run_id and started['kind'] == 'test',
                'Journal is not the selected real managed suite')
        require(started['worktree']['resolved'] == str(root) and started['task'] == '#392-suite',
                'Managed suite ran in another worktree/task')
        prepared = [event for event in events if event['event'] == 'prepared']
        require(len(prepared) == 1 and prepared[0]['inputs']['scope'] == ['all-tests']
                and prepared[0]['inputs']['arguments'] == []
                and prepared[0]['inputs']['inputs_sha256'] == frozen['runner_inputs_sha256'],
                'Managed captured inputs or all-tests scope differ from frozen snapshot')
        commands = [event for event in events if event['event'] == 'command']
        require(len(commands) == 1 and commands[0]['command'][1:] == EXPECTED_COMMAND
                and Path(commands[0]['command'][0]).resolve() == Path(frozen['python'])
                and commands[0]['cwd'] == str(root), 'Suite command had filters or changed interpreter/cwd')
        endings = [event for event in events if event['event'] == 'phase-end' and event.get('phase') == 'test']
        require(len(endings) == 1 and endings[0].get('returncode') == 0, 'No real successful unittest phase event')
        terminal = [event for event in events if event['event'] == 'finished']
        require(len(terminal) == 1 and events[-1] == terminal[0]
                and terminal[0]['outcome'] == 'success' and terminal[0].get('returncode') in (None, 0),
                'No real successful managed terminal event')
        successful_run(host, args.run_id, 'test', api['status'])
        result = exact_outcomes((destination / 'native.log').read_text(), frozen)
        result.update(verified_utc=utc(), run_id=args.run_id, root=str(root), head=frozen['head'],
                      scope='one complete managed invocation', input_bindings_verified=True)
        write_json(destination / 'exact-outcomes.json', result)
        files = sorted(path for path in destination.iterdir() if path.is_file())
        hashes = {path.name: digest(path) for path in files}
        archive = destination / 'suite-evidence.tar.gz'
        with tarfile.open(archive, 'w:gz') as stream:
            for path in files:
                stream.add(path, arcname=path.name, recursive=False)
        with tarfile.open(archive, 'r:gz') as stream:
            require(stream.getnames() == list(hashes), 'Archive member inventory mismatch')
            for name, sha in hashes.items():
                require(hashlib.sha256(stream.extractfile(name).read()).hexdigest() == sha,
                        'Archive member hash mismatch: ' + name)
        verification = dict(accepted=True, archive_sha256=digest(archive), members_sha256=hashes,
                            run_id=args.run_id, count=715, passed=713, skipped=2, head=frozen['head'])
        write_json(destination / 'archive-verification.json', verification)
        print(json.dumps(verification, indent=2))
    except Exception as error:
        write_json(destination / 'collector-failure.json', dict(accepted=False, error=str(error), utc=utc()))
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--packet', type=Path, default=Path(__file__).resolve().parent)
    actions = parser.add_subparsers(dest='action', required=True)
    freezing = actions.add_parser('freeze')
    freezing.add_argument('--head', required=True)
    freezing.add_argument('--native-run', required=True)
    freezing.add_argument('--build-run', required=True)
    freezing.add_argument('--lean-run', required=True)
    collecting = actions.add_parser('collect')
    collecting.add_argument('--run-id', required=True)
    collecting.add_argument('--terminal-log', type=Path)
    args = parser.parse_args()
    root, packet = args.root.resolve(), args.packet.resolve()
    require(root.is_dir(), 'Missing --root')
    os.chdir(root)
    sys.path.insert(0, str(root))
    from scripts.dev import hash_paths
    from scripts.platforms import native_layout
    from scripts.proof_provenance import input_hashes
    from scripts.run_history import registry, status
    host = native_layout(root)
    api = dict(hash_paths=hash_paths, input_hashes=input_hashes, registry=registry, status=status)
    (freeze if args.action == 'freeze' else collect)(args, root, packet, host, api)


if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, ValueError, subprocess.CalledProcessError) as error:
        raise SystemExit('suite collector: ' + str(error))
