module

public import Silver.ComposeContracts
public import Silver.ComposeArrayElaboration
public import Silver.ComposeStateBounds
public import Silver.PredicateNativeRanges

@[expose] public section

namespace Silver.Compose.Expressions

variable {domain : StateDomain}

/-- A single initialized-value update preserves the native parser invariant.
The native ordered metadata invariant is retained; source compactness is unnecessary. -/
theorem model_putArray_valid {text : Source} {state : ParserState} {value : Int}
    (valid : ValidState text state) (room : state.arrayNames.used < ArrayBindings.maxElements)
    (safe : Integer.InRange value) : ValidState text (putArrayValue state value) := by
  rcases valid with ⟨position, names, dynamic, target, capacity, scalarNames,
    ⟨metadata, used, initials, allocated⟩, subtypes⟩
  refine ⟨position, names, dynamic, target, capacity, scalarNames, ⟨metadata,
    by dsimp only [putArrayValue]; omega, ?_, ?_⟩, subtypes⟩
  · exact putInitial_valid initials (by omega) safe
  · intro item present
    have prior := allocated item present
    dsimp only [putArrayValue]
    omega

theorem ArrayValuesDomain.room {text source result position length parsed}
    (valid : ArrayValuesDomain text source result position length parsed domain)
    (remaining : parsed < length) : result.arrayNames.used < ArrayBindings.maxElements := by
  have used := valid.used
  have capacity := valid.capacity
  have sourceBound := valid.sourceValid.2.2.2.2.2.2.1.2.1
  omega

theorem ArrayValuesDomain.next {text source result position length parsed value following}
    (valid : ArrayValuesDomain text source result position length parsed domain)
    (remaining : parsed < length) (safe : Integer.InRange value)
    (positionValid : ValidCursor text following) :
    ArrayValuesDomain text source (putArrayValue result value) following length (parsed + 1) domain where
  sourceContext := valid.sourceContext
  resultContext := NativeState.transportScalar valid.resultContext
    (model_putArray_valid valid.resultValid (valid.room remaining) safe) rfl rfl
  positionValid := positionValid
  parsedBound := by omega
  capacity := valid.capacity
  used := by dsimp only [putArrayValue]; have same := valid.used; omega

theorem model_arrayScalar_valid (text : Source) (position : Nat)
    (names : ScalarExpression.Environment) (arrays : ArrayBindings.Metadata)
    (initials : ArrayBindings.Initials) (elaborating : Bool)
    (bound : ValidCursor text position) :
    ValidCursor text (ScalarExpression.read text position names 0 0 true arrays initials elaborating).after ∧
      (ScalarExpression.read text position names 0 0 true arrays initials elaborating).bounds.Bounded := by
  by_cases zero : (ScalarExpression.read text position names 0 0 true arrays initials elaborating).after = 0
  · rw [ScalarExpression.read_arrays_zero zero]
    exact ⟨Nat.zero_le _, Integer.Interval.empty_bounded⟩
  · obtain ⟨expression, reading⟩ := ScalarExpression.read_sound bound zero
    exact ⟨reading.cursorBounds.2.2, Integer.Expr.infer_bounded reading.inferred⟩

structure ArrayPartsBounds (text : Source) (parts : ArrayDeclarationParts) : Prop where
  first : ValidCursor text parts.first
  after : ValidCursor text parts.after
  lowerStart : ValidCursor text (fixedAfter text parts.arrayAfter "(" false)
  lowerAfter : ValidCursor text parts.lower.after
  lowerBounds : parts.lower.bounds.Bounded
  upperStart : ValidCursor text (fixedAfter text parts.lower.after ".." false)
  upperAfter : ValidCursor text parts.upper.after
  upperBounds : parts.upper.bounds.Bounded
  typeFirst : ValidCursor text parts.typeFirst
  typeAfter : ValidCursor text parts.typeAfter
  componentBounds : parts.componentBounds.Bounded
  position : ValidCursor text parts.position

private theorem scalarType_nameSpan (text : Source) (state : ParserState) (position : Nat)
    (bound : ValidCursor text position) (nonzero : (scalarTypeAt text state position).after ≠ 0) :
    ValidName text position (scalarTypeAt text state position).after := by
  have parsed := scalarTypeAt_sound text state position nonzero
  have span : 0 < skipAt text position ∧
      skipAt text position < (scalarTypeAt text state position).after := by
    generalize resultEq : scalarTypeAt text state position = result at parsed ⊢
    cases parsed <;> dsimp only <;> constructor <;> omega
  have skipped := skipAt_advances text position bound (by omega)
  have positive : position ≠ 0 := by
    intro zero
    simp [zero, skipAt] at span
  exact ⟨by omega, by omega, scalarTypeAt_position_valid text state position⟩


theorem model_arrayParts_valid (text : Source) (state : ParserState)
    (position : ValidCursor text state.position)
    (subtypes : IntegerSubtypes.ValidEnvironment text state.subtypeNames) :
    ArrayPartsBounds text (arrayDeclarationParts text state) := by
  have first := model_skip_valid text state.position position
  have after := model_name_valid text (declarationFirst text state)
  have colon : ValidCursor text (declarationColonAfter text state) := model_fixed_valid text _ ":" false after
  have constant : ValidCursor text (declarationConstantAfter text state) := model_fixed_valid text _ "constant" true colon
  have selected : ValidCursor text (if declarationConstantAfter text state ≠ 0 then
      declarationConstantAfter text state else declarationColonAfter text state) := by split <;> assumption
  have array := model_fixed_valid text _ "array" true selected
  have lowerStart := model_fixed_valid text _ "(" false array
  have lower := model_arrayScalar_valid text _ state.scalarNames state.arrayNames.names state.arrayNames.values true lowerStart
  have upperStart := model_fixed_valid text _ ".." false lower.1
  have upper := model_arrayScalar_valid text _ state.scalarNames state.arrayNames.names state.arrayNames.values true upperStart
  have close := model_fixed_valid text _ ")" false upper.1
  have ofAfter := model_fixed_valid text _ "of" true close
  have typeFirst := model_skip_valid text _ ofAfter
  have typeAfterBound (boolean : Bool) (cursor : Nat) :
      ValidCursor text ((if boolean then
        (⟨fixedAfter text cursor "boolean" true, Integer.Interval.full⟩ : ScalarConstraintResult)
        else scalarTypeAt text state cursor).after) := by
    split
    · exact fixedAfter_result_bound text cursor "boolean" true (by decide)
    · exact scalarTypeAt_position_valid text state cursor
  have typeAfter : ValidCursor text (arrayDeclarationParts text state).typeAfter :=
    typeAfterBound _ _
  have componentBound (boolean : Bool) (cursor : Nat) :
      (if boolean then
        (⟨fixedAfter text cursor "boolean" true, Integer.Interval.full⟩ : ScalarConstraintResult)
        else scalarTypeAt text state cursor).bounds.Bounded := by
    split
    · exact Integer.Interval.full_bounded
    · exact scalarTypeAt_bounded text state cursor subtypes
  have components : (arrayDeclarationParts text state).componentBounds.Bounded :=
    componentBound _ _
  have position : ValidCursor text (arrayDeclarationParts text state).position :=
    fixedAfter_result_bound text _ "(" false (by decide)
  exact ⟨first, after, lowerStart, lower.1, lower.2, upperStart, upper.1, upper.2,
    typeFirst, typeAfter, components, position⟩

theorem model_arrayParts_typeName (text : Source) (state : ParserState)
    (position : ValidCursor text state.position)
    (subtypes : IntegerSubtypes.ValidEnvironment text state.subtypeNames)
    (present : (arrayDeclarationParts text state).position ≠ 0) :
    ValidName text (arrayDeclarationParts text state).typeFirst
      (arrayDeclarationParts text state).typeAfter := by
  let parts := arrayDeclarationParts text state
  have bounds := model_arrayParts_valid text state position subtypes
  have typePositive : parts.typeAfter ≠ 0 := by
    exact model_fixed_input_nonzero text _ ":=" false
      (model_fixed_input_nonzero text _ "(" false present)
  cases kind : parts.isBoolean with
  | true =>
    have same : parts.typeAfter = fixedAfter text parts.typeFirst "boolean" true := by
      change (if parts.isBoolean then
        (⟨fixedAfter text parts.typeFirst "boolean" true, Integer.Interval.full⟩ : ScalarConstraintResult)
        else scalarTypeAt text state parts.typeFirst).after = _
      rw [kind]
      rfl
    have nonzero := same ▸ typePositive
    have firstPositive := model_fixed_input_nonzero text _ "boolean" true nonzero
    have advance := model_fixed_advances text _ "boolean" true bounds.typeFirst (by decide) nonzero
    change ValidName text parts.typeFirst parts.typeAfter
    rw [same]
    exact ⟨Nat.pos_of_ne_zero firstPositive, advance, same ▸ bounds.typeAfter⟩
  | false =>
    have same : parts.typeAfter = (scalarTypeAt text state parts.typeFirst).after := by
      change (if parts.isBoolean then
        (⟨fixedAfter text parts.typeFirst "boolean" true, Integer.Interval.full⟩ : ScalarConstraintResult)
        else scalarTypeAt text state parts.typeFirst).after = _
      rw [kind]
      rfl
    change ValidName text parts.typeFirst parts.typeAfter
    rw [same]
    exact scalarType_nameSpan text state parts.typeFirst bounds.typeFirst (same ▸ typePositive)

/-- Native validity is preserved by every recursive aggregate step, including
rejected readings. This does not assume source-level compact allocation. -/
theorem model_arrayValues_valid (text : Source) (source result : ParserState)
    (position length parsed : Nat) (componentBounds : Integer.Interval)
    (context : ArrayValuesDomain text source result position length parsed domain) :
    ValidState text (arrayValuesModel text source result position length parsed componentBounds) := by
  rw [arrayValuesModel]
  by_cases zero : position = 0
  · simp only [zero, ↓reduceIte]
    exact model_invalid_state_valid text
  · simp only [zero, ↓reduceIte]
    by_cases remaining : parsed < length
    · simp only [remaining, ↓reduceDIte]
      generalize valueEq : ScalarExpression.read text position source.scalarNames
        (arrays := source.arrayNames.names) (initials := source.arrayNames.values)
        (elaborating := true) = value
      by_cases bad : value.after = 0 ∨ value.bounds.isEmpty = true ∨ value.bounds.lower ≠ value.bounds.upper ∨
          value.bounds.lower < componentBounds.lower ∨ componentBounds.upper < value.bounds.upper
      · simp only [bad, ↓reduceIte]
        exact model_invalid_state_valid text
      · simp only [bad, ↓reduceIte]
        have present : (ScalarExpression.read text position source.scalarNames
            (arrays := source.arrayNames.names) (initials := source.arrayNames.values)
            (elaborating := true)).after ≠ 0 := by rw [valueEq]; intro missing; exact bad (Or.inl missing)
        obtain ⟨expression, raw⟩ := ScalarExpression.read_sound context.positionValid present
        have reading : ScalarExpression.At text source.scalarNames position expression value
            (arrays := source.arrayNames.names) (initials := source.arrayNames.values)
            (elaborating := true) := by rw [← valueEq]; exact raw
        have bounds := Integer.Expr.infer_bounded reading.inferred
        have nextPosition : ValidCursor text
            (if parsed + 1 < length then fixedAfter text value.after "," false else value.after) := by
          split
          · exact model_fixed_valid text value.after "," false reading.cursorBounds.2.2
          · exact reading.cursorBounds.2.2
        exact model_arrayValues_valid text source (putArrayValue result value.bounds.lower)
          _ length (parsed + 1) componentBounds (context.next remaining bounds.1 nextPosition)
    · simp only [remaining, ↓reduceDIte]
      exact ⟨context.positionValid, context.resultValid.2⟩
termination_by length - parsed
decreasing_by omega

theorem model_booleanInitializer_bound (text : Source) (valid : ValidText text)
    (state : ParserState) (position maskFirst maskAfter : Nat)
    (names : ValidNames text state.names) (bounded : ValidCursor text position) :
    ValidCursor text (booleanInitializerAfter text state position maskFirst maskAfter) :=
  Predicate.Native.condition_bound text _ position _ valid names bounded

theorem model_booleanArrayValues_valid (text : Source) (valid : ValidText text) (source result : ParserState)
    (position length parsed maskFirst maskAfter : Nat)
    (context : ArrayValuesDomain text source result position length parsed domain) :
    ValidState text (booleanArrayValuesModel text source result position length parsed maskFirst maskAfter) := by
  rw [booleanArrayValuesModel]
  by_cases zero : position = 0
  · simp only [zero, ↓reduceIte]
    exact model_invalid_state_valid text
  · simp only [zero, ↓reduceIte]
    by_cases remaining : parsed < length
    · simp only [remaining, ↓reduceDIte]
      by_cases failed : booleanInitializerAfter text source position maskFirst maskAfter = 0
      · simp only [failed, ↓reduceIte]
        exact model_invalid_state_valid text
      · simp only [failed, ↓reduceIte]
        have valueBound := model_booleanInitializer_bound text valid source position maskFirst maskAfter
          context.sourceValid.2.1 context.positionValid
        have nextPosition : ValidCursor text
            (if parsed + 1 < length then fixedAfter text
              (booleanInitializerAfter text source position maskFirst maskAfter) "," false
             else booleanInitializerAfter text source position maskFirst maskAfter) := by
          split
          · exact fixedAfter_result_bound text _ "," false (by decide)
          · exact valueBound
        exact model_booleanArrayValues_valid text valid source (putArrayValue result 0)
          _ length (parsed + 1) maskFirst maskAfter
          (context.next remaining (by decide +kernel) nextPosition)
    · simp only [remaining, ↓reduceDIte]
      exact ⟨context.positionValid, context.resultValid.2⟩
termination_by length - parsed
decreasing_by omega

end Silver.Compose.Expressions
