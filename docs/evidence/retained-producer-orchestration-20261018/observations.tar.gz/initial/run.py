#!/usr/bin/env python3
"""One isolated indexed-null producer invocation with the proposed GCC option."""
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import time

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/canto/src/github.com/berkeleynerd/silver')
IMAGE = REPO / '.silver/linux-x86_64/image-tools'
GNAT = REPO / '.tools/linux-x86_64/alire/toolchains/gnat_native_16.1.0_9f74f58a'
GPR = REPO / '.tools/linux-x86_64/alire/toolchains/gprbuild_26.0.1_e3f27f25'
ORIGINAL = REPO / 'tmp/indexed-main-discovery/.silver/linux-x86_64/program-RibQE3'


def identity(path):
    data = path.read_bytes()
    return dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


assert not (ROOT / 'result.json').exists(), 'preserve previous capture'
work = ROOT / ('w' * (len(str(ORIGINAL)) - len(str(ROOT)) - 1))
work.mkdir()
(ROOT / 'temporary').mkdir()
sources = [ORIGINAL / 'program.gpr', REPO / 'samples/null.adb']
tools = [IMAGE / 'bin/gnatprove', IMAGE / 'libexec/spark/bin/gcc',
         IMAGE / 'libexec/spark/bin/gnat2why', IMAGE / 'libexec/spark/bin/gprbuild',
         IMAGE / 'libexec/spark/bin/why3server', IMAGE / 'libexec/spark/bin/spark_report',
         IMAGE / 'libexec/spark/libexec/gcc/x86_64-pc-linux-gnu/16.1.0/gnat1']
before = {str(p): identity(p) for p in sources + tools}
(work / 'program.gpr').write_bytes(sources[0].read_bytes())
(work / 'main.adb').write_bytes(sources[1].read_bytes())
environment = {'PATH': str(GNAT / 'bin') + ':' + str(GPR / 'bin') + ':/usr/bin:/bin',
               'LC_ALL': 'C', 'TMPDIR': str(ROOT / 'temporary')}
argv = [str(IMAGE / 'bin/gnatprove'), '-P', str(work / 'program.gpr'),
        '-U', '--mode=all', '--report=all', '--warnings=error', '--checks-as-errors=on',
        '--level=2', '--prover=cvc5,z3,altergo', '--steps=100000', '--timeout=0',
        '--memlimit=1000', '-j0', '--no-loop-unrolling', '-cargs', '-Wno-free-nonheap-object']
(ROOT / 'invocation.json').write_text(json.dumps(dict(argv=argv, cwd=str(work),
    environment=environment, input_identities=before,
    scope='one indexed-null producer; exact source/project/options; no Main VC'),
    indent=2, sort_keys=True) + '\n')
started = time.monotonic()
run = subprocess.run(argv, cwd=work, env=environment, capture_output=True, timeout=60)
elapsed = time.monotonic() - started
(ROOT / 'stdout').write_bytes(run.stdout)
(ROOT / 'stderr').write_bytes(run.stderr)
after = {str(p): identity(p) for p in sources + tools}
generated = {str(p.relative_to(work)): identity(p) for p in sorted(work.rglob('*')) if p.is_file()}
result = dict(host=platform.platform(), returncode=run.returncode, duration_seconds=elapsed,
              retained_inputs_unchanged=before == after, generated=generated,
              stdout=identity(ROOT / 'stdout'), stderr=identity(ROOT / 'stderr'),
              scope='one GNATprove null invocation; not a compiler audit or whole-capacity proof')
(ROOT / 'result.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, sort_keys=True), flush=True)
assert run.returncode == 0 and before == after and 'obj/gnatprove/main~1.spark' in generated
