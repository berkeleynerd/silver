	.arch armv8.5-a
	.build_version macos,  28, 0
	.text
	.globl _a
	.zerofill __DATA,__common,_a,2147483647,0
	.globl _b
	.zerofill __DATA,__common,_b,2147483647,0
	.globl _c
	.zerofill __DATA,__common,_c,2147483647,0
	.text
	.align	2
	.globl _main
_main:
LFB0:
	adrp	x0, _a@PAGE
	add	x0, x0, _a@PAGEOFF;
	mov	w1, 1
	strb	w1, [x0]
	adrp	x0, _b@PAGE
	add	x0, x0, _b@PAGEOFF;
	mov	w1, 2
	strb	w1, [x0]
	adrp	x0, _c@PAGE
	add	x0, x0, _c@PAGEOFF;
	mov	w1, 3
	strb	w1, [x0]
	adrp	x0, _a@PAGE
	add	x0, x0, _a@PAGEOFF;
	ldrsb	w0, [x0]
	mov	w1, w0
	adrp	x0, _b@PAGE
	add	x0, x0, _b@PAGEOFF;
	ldrsb	w0, [x0]
	add	w0, w1, w0
	adrp	x1, _c@PAGE
	add	x1, x1, _c@PAGEOFF;
	ldrsb	w1, [x1]
	add	w0, w0, w1
	ret
LFE0:
	.section __TEXT,__eh_frame,coalesced,no_toc+strip_static_syms+live_support
EH_frame1:
	.set L$set$0,LECIE1-LSCIE1
	.long L$set$0
LSCIE1:
	.long	0
	.byte	0x3
	.ascii "zR\0"
	.uleb128 0x1
	.sleb128 -8
	.uleb128 0x1e
	.uleb128 0x1
	.byte	0x10
	.byte	0xc
	.uleb128 0x1f
	.uleb128 0
	.align	3
LECIE1:
LSFDE1:
	.set L$set$1,LEFDE1-LASFDE1
	.long L$set$1
LASFDE1:
	.long	LASFDE1-EH_frame1
	.quad	LFB0-.
	.set L$set$2,LFE0-LFB0
	.quad L$set$2
	.uleb128 0
	.align	3
LEFDE1:
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.subsections_via_symbols
