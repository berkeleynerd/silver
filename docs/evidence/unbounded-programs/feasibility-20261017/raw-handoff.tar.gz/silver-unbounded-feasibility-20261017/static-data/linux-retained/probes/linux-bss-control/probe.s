	.file	"probe.c"
	.text
	.globl	a
	.bss
	.align 16
	.type	a, @object
	.size	a, 16
a:
	.zero	16
	.globl	b
	.align 16
	.type	b, @object
	.size	b, 16
b:
	.zero	16
	.globl	c
	.align 16
	.type	c, @object
	.size	c, 16
c:
	.zero	16
	.text
	.globl	main
	.type	main, @function
main:
.LFB0:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movb	$1, a(%rip)
	movb	$2, b(%rip)
	movb	$3, c(%rip)
	movzbl	a(%rip), %eax
	movsbl	%al, %edx
	movzbl	b(%rip), %eax
	movsbl	%al, %eax
	addl	%eax, %edx
	movzbl	c(%rip), %eax
	movsbl	%al, %eax
	addl	%edx, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE0:
	.size	main, .-main
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
