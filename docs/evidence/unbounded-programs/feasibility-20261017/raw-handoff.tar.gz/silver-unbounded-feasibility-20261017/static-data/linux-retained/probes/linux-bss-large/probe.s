	.file	"probe.c"
	.text
	.globl	a
	.section	.lbss,"awl",@nobits
	.align 32
	.type	a, @object
	.size	a, 2147483647
a:
	.zero	2147483647
	.globl	b
	.align 32
	.type	b, @object
	.size	b, 2147483647
b:
	.zero	2147483647
	.globl	c
	.align 32
	.type	c, @object
	.size	c, 2147483647
c:
	.zero	2147483647
	.text
	.globl	main
	.type	main, @function
main:
.LFB0:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
.L3:
	leaq	.L3(%rip), %rax
	movabsq	$_GLOBAL_OFFSET_TABLE_-.L3, %r11
	addq	%r11, %rax
	movabsq	$a@GOTOFF, %rdx
	movb	$1, (%rax,%rdx)
	movabsq	$b@GOTOFF, %rdx
	movb	$2, (%rax,%rdx)
	movabsq	$c@GOTOFF, %rdx
	movb	$3, (%rax,%rdx)
	movabsq	$a@GOTOFF, %rdx
	movzbl	(%rax,%rdx), %edx
	movsbl	%dl, %ecx
	movabsq	$b@GOTOFF, %rdx
	movzbl	(%rax,%rdx), %edx
	movsbl	%dl, %edx
	addl	%edx, %ecx
	movabsq	$c@GOTOFF, %rdx
	movzbl	(%rax,%rdx), %eax
	movsbl	%al, %eax
	addl	%ecx, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE0:
	.size	main, .-main
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
