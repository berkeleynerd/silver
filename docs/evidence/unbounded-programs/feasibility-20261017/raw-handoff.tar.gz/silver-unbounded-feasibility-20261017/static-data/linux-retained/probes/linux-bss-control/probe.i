# 0 "probe.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3
# 0 "<command-line>" 2
# 1 "probe.c"
char a[16];
char b[16];
char c[16];
int main(void) { a[0] = 1; b[0] = 2; c[0] = 3; return a[0] + b[0] + c[0]; }
