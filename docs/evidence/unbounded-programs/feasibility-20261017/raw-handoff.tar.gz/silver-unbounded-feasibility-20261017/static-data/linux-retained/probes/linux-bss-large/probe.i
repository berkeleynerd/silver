# 0 "probe.c"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3
# 0 "<command-line>" 2
# 1 "probe.c"
char a[2147483647];
char b[2147483647];
char c[2147483647];
int main(void) { a[0] = 1; b[0] = 2; c[0] = 3; return a[0] + b[0] + c[0]; }
