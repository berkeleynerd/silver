from pathlib import Path
import json,subprocess
p=Path('/tmp/silver-unbounded-feasibility-20261017');merge=json.loads((p/'authorization-merge.json').read_text())['mergeCommit']['oid'];project='PVT_kwHOAd-1yc4BnN6o';field='PVTSSF_lAHOAd-1yc4BnN6ozhlzigQ'
def api(*a):return json.loads(subprocess.check_output(['gh','api',*a],text=True))
def gql(q,**v):
 a=['graphql','-f','query='+q]
 for k,x in v.items():a+=['-f',k+'='+str(x)]
 return api(*a)
records=[]
for n,parent in [(107,91),(108,93)]:
 x=api(f'repos/berkeleynerd/silver/issues/{n}');assert 'Research' in x['title'];assert x['comments']==0
 payload=p/f'subissue-{n}.json';payload.write_text(json.dumps({'sub_issue_id':x['id']}));api(f'repos/berkeleynerd/silver/issues/{parent}/sub_issues','--method','POST','--input',str(payload))
 item=gql('mutation($p:ID!,$c:ID!){addProjectV2ItemById(input:{projectId:$p,contentId:$c}){item{id}}}',p=project,c=x['node_id'])['data']['addProjectV2ItemById']['item']['id']
 gql('mutation($p:ID!,$i:ID!,$f:ID!,$s:String!){updateProjectV2ItemFieldValue(input:{projectId:$p,itemId:$i,fieldId:$f,value:{singleSelectOptionId:$s}}){projectV2Item{id}}}',p=project,i=item,f=field,s='7b3386fc')
 body=f'Research-only work claimed after owner authorization reached main through PR #106, merge `{merge}`. Branch `codex/unbounded-feasibility-research`; isolated worktree `tmp/unbounded-planning-corrections`. This session owns the research and publication; implementation of #{parent} and #88–#94 remains unauthorized/Backlog. Pinned-source inspection and retained evidence precede targeted guarded probes. No full proof/test/Lean checkpoint is planned.'
 payload=p/f'claim-{n}.json';payload.write_text(json.dumps({'body':body}));comment=api(f'repos/berkeleynerd/silver/issues/{n}/comments','--method','POST','--input',str(payload));records.append({'number':n,'parent':parent,'node':x['node_id'],'item':item,'claim':comment['html_url']})
 parentbody=f'The owner separately authorized research under #{n}, recorded on main at `{merge}` (PR #106). That child is In progress. This parent remains open/Backlog: no implementation or adoption is authorized.'
 payload=p/f'parent-claim-{parent}.json';payload.write_text(json.dumps({'body':parentbody}));api(f'repos/berkeleynerd/silver/issues/{parent}/comments','--method','POST','--input',str(payload));print(n,'claimed under',parent,flush=True)
(p/'research-issues.json').write_text(json.dumps(records,indent=2)+'\n')
