Record the owner's research-only proceed for the unresolved source-capacity (#91) and near-Integer'Last static-data/build feasibility (#93) questions before claiming the research. Publication and independent review are included; implementation of #88–#94 and adoption of new language rules remain unauthorized.

Independent review checked the authorization boundary and unchanged historical memory. Documentation-only change; whitespace check passed. Research subissues will track this authorized work separately from the Backlog implementation packages.
