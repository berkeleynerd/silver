# Frontend representation research: ownership and assurance analysis

Date: 2026-10-17. Research work package: #113. Read-only policy analysis against
authorization commit `63561234c989d7d8d759ed124d425d06974e9f32`, published through
PR #114 at main merge `b8e618c54592f66461b2a08023795f31c16a7d39`.

## Finding

A replacement representation can be investigated without amending the Oracle.
A production design must identify who owns each changed executable body.
Existing GNAT is a trusted external dependency; that fact does not exempt a
Silver-owned frontend modification from SPARK verification. The research must
not count a private Silver-maintained C++ or non-SPARK Ada fork as an available
compliant route merely by putting it in an external directory or Alire package.

## Controlling text

- `oracle.md:24`: “The Silver compiler and all Silver-owned runtime and library
  implementation code must be implemented exclusively in SPARK and verified to
  both Bronze and Silver levels.” Features beyond the application profile are
  allowed for this implementation code.
- `oracle.md:25`: GNAT, GNATprove, Alire and existing operating-system/runtime
  libraries “remain trusted external dependencies”; the same clause repeats that
  the verified-SPARK requirement applies to all Silver compiler/owned code and
  “Silver-owned wrappers receive no exemption.”
- `docs/trusted-boundary.md:3–7`: these are assumptions about “existing external
  tools and libraries, not permission to introduce unverified Silver
  implementation bodies.” This is supporting interpretation, not an additional
  exception to the Oracle.
- `oracle.md:27–28`: Lean must connect formal models to actual SPARK implementation
  and authoritative source; Lean supplements GNATprove and cannot replace the
  Bronze/Silver verification of owned implementation bodies.
- `oracle.md:11`: admitted, proved and compiled source must be the same source;
  hidden annotated replacements are forbidden, selected library sources must
  correspond and external dependencies/assumptions must be documented.
- `oracle.md:3,7,9,12–14`: inherited meaning, automatic source-derived assurance,
  all compositions and complete obligations survive the representation change.
- `oracle.md:22–23`: Alire manages the toolchain, Linux is primary, major/minor
  versions match across supported Linux/macOS with patch differences allowed;
  independent native macOS validation does not block Linux completion.
- `oracle.md:16` and `development.md:99–105`: an actual Oracle change requires
  explicit owner approval; routine authorized implementation does not need
  another permission ceremony.

## Routes under the unchanged Oracle

| Route | Policy status | Required evidence / remaining condition |
| --- | --- | --- |
| Select an unmodified externally maintained GNAT/GNATprove release that already supports the intended representation | Fits the existing named external-tool category. The Oracle does not pin GNAT to a numbered version. This is a policy conclusion, not a claim that a suitable release exists or has been adopted. | Establish availability and exact source/binary/producer identities, Alire integration and platform versions; re-establish all changed frontend/producer/consumer premises and universal language assurance. Production adoption is outside current research authorization. |
| Obtain a change accepted, integrated and maintained by the existing GNAT/GNATprove upstream, then consume that unmodified upstream tool | A possible external dependency route. Do not treat anticipated upstream acceptance as an available tool. | Establish the actual upstream acceptance and maintenance, exact integrated version and absence of a privately maintained Silver delta. A proposed patch, repository relocation or package label alone establishes none of these. Noncanonical vendor/fork maintenance whose external status is unclear remains an explicit ownership question. |
| Implement the required owned components in SPARK, with complete Bronze/Silver verification and Lean correspondence | Allowed in principle by the implementation clause, including SPARK features beyond the application profile. No feasibility claim follows from this policy permission. | Inventory every changed executable body and interface, including glue/callers. Existing external symbols can have documented import-only SPARK bindings; all owned transformation, storage, arithmetic and interface bodies require verification. Any necessary Silver-owned C++ or SPARK-off body defeats this route. Lean verification of a C++ model does not satisfy the language requirement. |
| Maintain a private Silver GNAT/GNATprove fork with unverified Ada/C++ representation changes | Does not fit the unchanged policy merely because GNAT is named as trusted. | It would need either a genuinely established external ownership route, an implementation satisfying the SPARK rule, or an explicitly approved amendment. No such amendment is currently authorized. |

These categories concern maintenance and execution responsibility, not copyright
assignment or where an archive is hosted. The policy text does not provide a
mechanical legal test for when a Silver-originated patch becomes a wholly
externally maintained dependency. Integration into and continued ownership by
the existing upstream is the concrete route to investigate. Until that evidence
exists, report it as conditional. Do not claim that authoring a research patch,
submitting it upstream, or publishing it through Alire has already transferred
maintenance responsibility.

## The actual-source and producer requirements

An internal representation change is not automatically a new authoring language
or a violation of same-source compilation. Existing GNAT already transforms its
input. The relevant question is whether the authoritative Ada/SPARK bytes remain
the input admitted, proved and compiled, and whether both physical producer
paths preserve the stipulated meaning and obligations. A transformed author
source, or an annotated substitute used only for proof, cannot stand in for
that source.

The existing Image adapter is a useful narrow precedent, not a general exemption:
`docs/trusted-boundary.md:229–238` describes the original external producer and
its selected support-tool paths; `docs/assurance.md:148–195` requires the precise
producer schemas, actual insertion offsets, recovery of original bytes, semantic
validity and the actual consumer interpretation. Matching, transformation and
source correspondence remain proved in Silver-owned SPARK/Lean. In particular,
`docs/assurance.md:190–195` says separate model theorems, hashes or examples do
not individually establish composition.

For a new frontend representation, the investigation therefore must cover both
GNAT code generation and GNATprove's producer/consumer route, not only a wider
character-pool type or a successful Ada compile. The currently documented tool
contract (`docs/assurance.md:584–607`) includes faithful completed parsing,
complete obligation generation, automatic completion for every admitted schema,
same-source build completion and preservation/realization of execution. The
new design must account for affected terms of that contract. General external
solver assumptions do not excuse newly Silver-owned bodies or omitted producer
arguments.

The full-coverage boundary is explicit at `docs/assurance.md:854–866`:
specification-only coverage is limited to approved external import declarations
and the exact existing vendor ghost instance; every owned body and proof helper
requires full coverage. Calling an external allocator through an import-only
binding does not exempt new owned storage-management logic or changed compiler
callers.

## Research and disposition

`development.md:22–26` allows intermediate builds and experiments without a proof
gate. That permits proportionate isolated feasibility experiments within #113;
it does not make a research prototype a supported or policy-compliant compiler.
The 2026-10-17 authorization (`docs/session-memory.md:3–39`) explicitly excludes
production changes, pin adoption and Oracle amendments.

If candidate inspection finds no suitable external version and the concrete
wider/deferred design necessarily requires privately maintained non-SPARK
frontend changes, the precise stop is: **the demonstrated design has no verified
ownership/implementation route under the current Oracle and authorization**.
The next decision would concern obtaining externally maintained support,
undertaking a feasible fully SPARK-owned route, selecting a separately justified
language scope alternative, or explicitly changing the policy. Do not infer an
Oracle amendment just because a tool version changes, and do not silently
classify owned changes as external to avoid the clause. The owner must decide an
actual policy exception; no such decision is needed to complete this research
and publish the stop.

## Evidence scope

Read-only inspection of the exact policy and assurance documents named above.
No compiler/proof changes, new tool installation, native experiment or proof run
was needed for this policy conclusion. Candidate availability, frontend
mechanics and producer provenance belong to the parallel evidence streams.
