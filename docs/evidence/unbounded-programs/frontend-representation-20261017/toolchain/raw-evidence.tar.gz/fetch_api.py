import concurrent.futures
import base64
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def fetch(pair):
    name, path = pair
    command = ['gh', 'api', path]
    result = subprocess.run(command, capture_output=True)
    destination = ROOT / (name + '.json')
    destination.write_bytes(result.stdout)
    record = {
        'queried_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'url': 'https://api.github.com/' + path,
        'command': command, 'exit': result.returncode,
        'bytes': len(result.stdout),
        'sha256': hashlib.sha256(result.stdout).hexdigest(),
        'stderr': result.stderr.decode(errors='replace'),
    }
    (ROOT / (name + '.retrieval.json')).write_text(json.dumps(record, indent=2) + '\n')
    try:
        body = json.loads(result.stdout)
        if isinstance(body, dict):
            if body.get('type') == 'file' and body.get('encoding') == 'base64':
                raw = base64.b64decode(body['content'])
                blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
                if blob != body['sha']:
                    raise ValueError('Git blob hash mismatch')
                (ROOT / (name + '.source')).write_bytes(raw)
            summary = {key: body[key] for key in
                       ['full_name', 'default_branch', 'sha', 'object', 'message', 'tag_name']
                       if key in body}
        else:
            summary = {'entries': len(body), 'first': body[:3]}
    except ValueError:
        summary = {'parse_error': True}
    return {'name': name, 'exit': result.returncode, 'summary': summary}

if __name__ == '__main__':
    pairs = [argument.split('=', 1) for argument in sys.argv[1:]]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        for result in executor.map(fetch, pairs):
            print(json.dumps(result))
