import datetime
import hashlib
import io
import json
from pathlib import Path
import tarfile
import urllib.request

root = Path(__file__).resolve().parent
pin = '42554fc241fcd1fdf08d3a2feccb3f86912acbc0'
url = f'https://codeload.github.com/AdaCore/spark2014/tar.gz/{pin}'
raw = urllib.request.urlopen(url, timeout=60).read()
(root / 'spark-fsf16.tar.gz').write_bytes(raw)
tree = json.loads((root / 'spark-fsf16-tree.json').read_text())
assert not tree['truncated']
selected = {e['path']: e for e in tree['tree'] if e['type'] == 'blob'
            and (e['path'].startswith(('src/', 'gnat2why/'))
                 or e['path'] in ('Makefile', 'spark2014vsn.ads', 'spark2014vsn.adb'))}
manifest = []
with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
    for member in archive:
        name = member.name.split('/', 1)[-1]
        if name not in selected:
            continue
        assert member.isfile(), name
        data = archive.extractfile(member).read()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert blob == selected[name]['sha'], name
        target = root / 'spark-source' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        manifest.append({'path': name, 'bytes': len(data), 'git_blob': blob,
                         'sha256': hashlib.sha256(data).hexdigest()})
assert set(selected) == {e['path'] for e in manifest}
record = {'url': url, 'retrieved_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'pin': pin, 'archive_bytes': len(raw), 'archive_sha256': hashlib.sha256(raw).hexdigest(),
          'inventory_truncated': tree['truncated'], 'selected_files': len(manifest),
          'selection': 'src/**, gnat2why/** and Makefile/spark2014vsn.ads/adb',
          'files': sorted(manifest, key=lambda e: e['path'])}
(root / 'spark-source-manifest.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: v for k, v in record.items() if k != 'files'}))
