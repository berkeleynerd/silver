"""GDB script: observe installed gnat1 from exec to the pre-Main boundary."""
import gdb
import hashlib
import json
from pathlib import Path

ROOT = Path('/tmp/silver-native-rtl-setup-20261018')
CAPTURE = ROOT / 'capture'
PLAN = json.loads((ROOT / 'invocation.json').read_text())
inferior = gdb.selected_inferior()
proc = Path('/proc') / str(inferior.pid)
executable = (proc / 'exe').resolve()
assert str(executable) == PLAN['gnat1']
assert hashlib.sha256(executable.read_bytes()).hexdigest() == PLAN['gnat1_sha256']
frontend_environment = dict(item.decode().split('=', 1) for item in
                            (proc / 'environ').read_bytes().split(b'\0') if item)
frontend_argv = [item.decode() for item in (proc / 'cmdline').read_bytes().split(b'\0') if item]
assert all(frontend_environment.get(k) == v for k, v in PLAN['environment'].items())
assert 'LD_LIBRARY_PATH' not in frontend_environment
assert len(inferior.threads()) == 1
(CAPTURE / 'frontend-exec.json').write_text(json.dumps({
    'executable': str(executable), 'environment': frontend_environment,
    'argv': frontend_argv, 'pc': hex(int(gdb.parse_and_eval('$pc'))),
    'threads': len(inferior.threads()), 'pid': inferior.pid,
}, indent=2) + '\n')

