with Silver_IO;
with Silver_Arguments;
procedure Main is
   pragma SPARK_Mode (On);
   Name : constant String := Silver_Arguments.First_Or_Default ("world");
   subtype Small is Integer range 0 .. 9;
   Spare : constant Integer := 4;
   Fixed : constant array (1 .. 2) of Integer := (4, 5);
   Idle : Integer := 5;
   Twice : Small := 1;
   Probe : Integer := 6;
   Sink : Integer := 0;
   Flag : Boolean := False;
   Mark : Boolean := True;
   Text : String := "abc";
   Cells : array (1 .. 3) of Integer := (1, 2, 3);
   Marks : array (1 .. 2) of Boolean := (False, False);
   Letter : Character := 'x';
begin
   Twice := 2;
   if Probe > 0 then
      null;
   end if;
   Sink := 7;
   Sink := 8;
   if False then
      Sink := 9;
   end if;
   Flag := Flag;
   Mark := not Mark;
   for I in 1 .. 3 loop
      null;
   end loop;
   for I in 1 .. Twice loop
      Cells (1) := 0;
   end loop;
   for E of Fixed loop
      null;
   end loop;
   Marks (1) := True;
   Text := "xyz";
   Letter := 'y';
   if Silver_Arguments.Input_Is_Valid
     and then Name'Length <= 4088
   then
      Silver_IO.Put_Line ("Hello, " & Name & "!");
   else
      Silver_Arguments.Reject;
   end if;
end Main;
