with Silver_IO;
with Silver_Arguments;
procedure Main is
   pragma SPARK_Mode (On);
   Input : constant String := Silver_Arguments.First_Or_Default ("old");
   procedure P (N : in Integer; X : out Integer) is
   begin
      X := N;
   end P;
begin
   if Silver_Arguments.Input_Is_Valid and then Input'Length <= 100 then
      Silver_IO.Put_Line (Input);
   else
      Silver_Arguments.Reject;
   end if;
end Main;
