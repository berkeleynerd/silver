with Silver_IO;
procedure Main is
   pragma SPARK_Mode (On);
   procedure Copy (Source : in Integer; Target : out Integer) is
   begin
      Target := Source;
   end Copy;
   A : Integer := 5;
   B : Integer := 0;
begin
   Copy (A, B);
   Silver_IO.Put_Line (Integer'Image (A));
   Silver_IO.Put_Line (Integer'Image (B));
end Main;
