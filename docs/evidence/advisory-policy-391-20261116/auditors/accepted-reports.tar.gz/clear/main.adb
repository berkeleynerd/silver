with Silver_IO;
procedure Main is
   pragma SPARK_Mode (On);
   procedure Clear (Value : out Integer) is
   begin
      Value := 0;
   end Clear;
   X : Integer := 7;
begin
   Clear (X);
   Silver_IO.Put_Line (Integer'Image (X));
end Main;
