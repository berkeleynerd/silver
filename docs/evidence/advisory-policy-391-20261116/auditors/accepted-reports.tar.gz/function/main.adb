with Silver_IO;
procedure Main is
   pragma SPARK_Mode (On);
   function Zero (N : in Integer) return Integer is
   begin
      if N > 0 then
         null;
      end if;
      return N;
   end Zero;
   R : Integer := 1;
begin
   R := Zero (R);
   Silver_IO.Put_Line (Integer'Image (R));
end Main;
