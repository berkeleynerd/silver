from pathlib import Path
import datetime, json, os, resource, signal, subprocess, sys, threading, time

ROOT = Path(__file__).resolve().parents[3]
PACKET = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts.platforms import native_layout
from scripts.proof_provenance import input_hashes

STACK = 16 * 1024 * 1024
GUARD_KIB = 1536 * 1024
resource.setrlimit(resource.RLIMIT_STACK, (STACK, resource.getrlimit(resource.RLIMIT_STACK)[1]))
host = native_layout(root=ROOT)
frozen = input_hashes(host)
commands = [('mixed-report', [sys.executable, 'scripts/dev.py', 'tool', '--task', '#391-native-correspondence', '--reason', 'Whole Mixed_Report complete contract after independent Astra Max diagnosis: two local policy-body abstraction annotations reuse already proved Mixed_Object equality; unchanged contracts/domains/runtime, all 12 workers available after Lean release; 16 MiB stack and canonical proof settings', '--'] + ['gnatprove', '-P', '../../../silver.gpr', '--subdirs=explore/advisory-policy-391-20261116', '-u', 'silver_library_reports.adb', '--limit-lines=../../../tmp/advisory-policy-391-20261116/mixed-report/whole-subprogram.lines', '--mode=all', '--report=all', '--warnings=error', '--checks-as-errors=on', '--level=2', '--prover=cvc5,z3,altergo', '--timeout=30', '-XSILVER_HOST=linux-aarch64'])]
metadata = {'launch_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
            'root': str(ROOT), 'platform': list(os.uname()), 'stack_limits': list(resource.getrlimit(resource.RLIMIT_STACK)),
            'cpus': len(os.sched_getaffinity(0)), 'guard_minimum_available_kib': GUARD_KIB,
            'inputs_sha256': frozen, 'stages': []}
(PACKET / 'launcher.json').write_text(json.dumps(metadata, indent=2) + '\n')

def resources(pid):
    processes = {}
    for p in Path('/proc').iterdir():
        if not p.name.isdecimal():
            continue
        try:
            fields = (p / 'stat').read_text().rsplit(')', 1)[1].split()
            status = (p / 'status').read_text().splitlines()
            rss = next((int(line.split()[1]) for line in status if line.startswith('VmRSS:')), 0)
            processes[int(p.name)] = (int(fields[1]), rss)
        except (OSError, ValueError, IndexError):
            continue
    descendants = {pid}
    while True:
        more = {p for p, (parent, _) in processes.items() if parent in descendants}
        if more <= descendants:
            break
        descendants |= more
    mem = dict((line.split(':', 1)[0], int(line.split()[1])) for line in Path('/proc/meminfo').read_text().splitlines())
    return {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'process_count': len(descendants & processes.keys()),
            'process_tree_rss_kib': sum(processes[p][1] for p in descendants if p in processes),
            'available_kib': mem['MemAvailable'], 'swap_total_kib': mem['SwapTotal']}

for stage, command in commands:
    if input_hashes(host) != frozen:
        raise RuntimeError('native input bytes changed before ' + stage)
    record = {'stage': stage, 'command': command, 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    start = time.monotonic()
    process = subprocess.Popen(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               text=True, bufsize=1, start_new_session=True)
    record['pid'] = process.pid
    stopped = threading.Event()
    guarded = []
    def sample():
        with (PACKET / (stage + '-resources.jsonl')).open('w') as out:
            while not stopped.is_set():
                row = resources(process.pid)
                out.write(json.dumps(row) + '\n'); out.flush()
                if row['available_kib'] < GUARD_KIB and process.poll() is None and not guarded:
                    guarded.append(row)
                    print('RESOURCE GUARD: host headroom below 1.5 GiB; retaining interrupted evidence', flush=True)
                    try:
                        os.killpg(process.pid, signal.SIGINT)
                    except ProcessLookupError:
                        pass
                stopped.wait(5)
    sampler = threading.Thread(target=sample)
    sampler.start()
    with (PACKET / (stage + '-terminal.log')).open('w') as out:
        for line in process.stdout:
            out.write(line); out.flush()
            if line.startswith(('Managed run:', 'Phase ', 'Success:', 'Full GNATprove evidence:', 'development command:', 'ERROR:', 'Traceback')) or 'might fail' in line:
                print(line, end='', flush=True)
    status = process.wait()
    stopped.set(); sampler.join()
    record.update(returncode=status, duration_seconds=time.monotonic() - start,
                  finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), guard_fired=guarded,
                  inputs_stable=input_hashes(host) == frozen)
    metadata['stages'].append(record)
    (PACKET / 'launcher.json').write_text(json.dumps(metadata, indent=2) + '\n')
    print(json.dumps({k: record[k] for k in ['stage', 'returncode', 'duration_seconds', 'guard_fired', 'inputs_stable']}), flush=True)
    if status or guarded or not record['inputs_stable']:
        sys.exit(status or 130)
print('Whole Mixed_Report focused run finished; complete validation awaits integration.', flush=True)
