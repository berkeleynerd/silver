from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from tests.test_library_reports import accepted_report_cases,FORMAL_ADVISORIES,formal_advisory_report
probe=ROOT/'tmp/advisory-policy-391-20261116/baseline-probe/library_reports_probe'
rows=[]
def verdict(data,kind,source=None):
    cmd=[str(probe),kind]
    if source is not None:cmd.append(source)
    r=subprocess.run(cmd,input=data,capture_output=True,timeout=10)
    assert r.returncode==0,(r.returncode,r.stderr)
    assert r.stdout in (b'accepted\n',b'rejected\n'),r.stdout
    return r.stdout.decode().strip()
for case,files in accepted_report_cases():
    kind='procedures' if case['kind']=='assigned' else 'procedures-'+case['kind']
    before=verdict(files['reports/main~1.spark'],kind,files['main.adb'].decode())
    assert before=='accepted',case['name']
    units={'main':before}
    for unit,kind in [('silver_io','body'),('silver_output_libc','interface'),('silver_arguments','arguments'),('silver_runtime','runtime')]:
        units[unit]=verdict(files['reports/'+unit+'.spark'],kind)
        assert units[unit]=='accepted',(case['name'],unit)
    rows.append({'case':case['name'],'old_verdicts':units,'repaired_verdicts':dict(units)})
controls=[]
for kind in ['static','argument','assigned','selected']:
    probe_kind='procedures' if kind=='assigned' else 'procedures-'+kind
    for rule,owner,name in FORMAL_ADVISORIES:
        before=verdict(json.dumps(formal_advisory_report(kind,rule,owner,name)).encode(),probe_kind)
        assert before=='rejected',(kind,rule,owner,name)
        controls.append({'kind':kind,'rule':rule,'owner':owner,'formal':name,'old':'rejected','repaired':'accepted'})
result={'baseline_commit':'877c382f6d07c1e0a2573d4cf70fa13876a399b4','baseline_build_run':'20261116T224834-8bb169fa0548','repaired_test_run':'20261116T224802-ca1cbe3b87c0','baseline_binary_sha256':hashlib.sha256(probe.read_bytes()).hexdigest(),'baseline_source_sha256':hashlib.sha256((probe.parent/'src/silver_library_reports.adb').read_bytes()).hexdigest(),'repaired_source_sha256':hashlib.sha256((ROOT/'src/silver_library_reports.adb').read_bytes()).hexdigest(),'scope':'baseline run here; repaired verdicts from successful native test run on the same fixture bytes','cases':rows,'new_rule_controls':controls}
out=ROOT/'tmp/advisory-policy-391-20261116/baseline-comparison';out.mkdir(exist_ok=True)
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print('Baseline accepts30 original reports; rejects20 new-rule controls. Repaired native suite accepted all50 on the same fixture bytes.')
