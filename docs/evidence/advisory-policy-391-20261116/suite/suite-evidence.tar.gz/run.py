"""One final managed suite invocation; execute only after the lead's GO."""
from pathlib import Path
import argparse
import collections
import datetime
import hashlib
import json
import os
import re
import resource
import signal
import subprocess
import sys
import threading
import time

ROOT = Path(__file__).resolve().parents[2]
PACKET = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from scripts.platforms import native_layout
from scripts.proof_provenance import input_hashes, validate_provenance

STACK = 16 * 1024 * 1024
GUARD_KIB = 1536 * 1024


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_json(name, data):
    (PACKET / name).write_text(json.dumps(data, indent=2) + '\n')


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def resources(pid):
    processes = {}
    for directory in Path('/proc').iterdir():
        if not directory.name.isdecimal():
            continue
        try:
            fields = (directory / 'stat').read_text().rsplit(')', 1)[1].split()
            lines = (directory / 'status').read_text().splitlines()
            rss = next((int(line.split()[1]) for line in lines
                        if line.startswith('VmRSS:')), 0)
            processes[int(directory.name)] = (int(fields[1]), rss)
        except (OSError, ValueError, IndexError):
            continue
    descendants = {pid}
    while True:
        more = {child for child, (parent, _) in processes.items() if parent in descendants}
        if more <= descendants:
            break
        descendants |= more
    memory = {line.split(':', 1)[0]: int(line.split()[1])
              for line in Path('/proc/meminfo').read_text().splitlines()}
    return dict(utc=utc(), process_count=len(descendants & processes.keys()),
                process_tree_rss_kib=sum(processes[p][1] for p in descendants if p in processes),
                available_kib=memory['MemAvailable'], swap_total_kib=memory['SwapTotal'])


def run_status(name):
    result = subprocess.run([sys.executable, 'scripts/dev.py', 'runs', 'status', '--limit', '5'],
                            cwd=ROOT, capture_output=True, text=True, check=True)
    (PACKET / name).write_text(result.stdout)
    return json.loads(result.stdout)


def frozen_mismatches(frozen):
    return {name: dict(expected=expected,
                       actual=digest(ROOT / name) if (ROOT / name).is_file() else None)
            for name, expected in frozen.items()
            if not (ROOT / name).is_file() or digest(ROOT / name) != expected}


def parse_results(log, inventory, coverage):
    expected = set(inventory['tests'])
    outcomes = {}
    pending = None
    for line in log.splitlines():
        match = re.match(r'^test\w* \(([^)]+)\)(.*)$', line)
        if match:
            identifier = match[1].removeprefix('tests.')
            if identifier in expected:
                pending = identifier
                outcomes.setdefault(identifier, dict(status='unresolved', start=line))
        result = re.search(r'(?:\.\.\. |^)(ok|skipped .+|FAIL|ERROR|expected failure|unexpected success)$', line)
        if result and pending:
            status = result[1]
            outcomes[pending]['status'] = status
            outcomes[pending]['result_line'] = line
            if status == 'ok' or status.startswith('skipped '):
                pending = None
    summaries = re.findall(r'^Ran (\d+) tests? in ([\d.]+)s$', log, flags=re.MULTILINE)
    conclusions = re.findall(r'^(?:OK(?: \([^\n]*\))?|FAILED \([^\n]*\))$', log,
                             flags=re.MULTILINE)
    summary = dict(expected_methods=inventory['count'], observed_methods=len(outcomes),
                   actual_count=int(summaries[-1][0]) if summaries else None,
                   test_seconds=float(summaries[-1][1]) if summaries else None,
                   conclusion=conclusions[-1] if conclusions else None,
                   statuses=dict(collections.Counter(item['status'] for item in outcomes.values())),
                   missing_methods=sorted(expected - outcomes.keys()), methods=outcomes)
    summary['coverage'] = {
        'basis': 'Actual method outcomes on frozen reviewed test code and retained fixture/sample inventories; no test instrumentation or replacement runner.',
        'full_route': {
            'planned_fixtures': coverage['full_route']['fixtures'],
            'planned_execution_cases': coverage['full_route']['execution_cases'],
            'method_outcomes': {name: outcomes.get(name, {}).get('status', 'missing')
                                for name in coverage['full_route']['methods']},
        },
        'samples': dict(coverage['samples'],
                        method_outcome=outcomes.get('test_samples.SupportedSampleTests.test_manifest_samples', {})
                                               .get('status', 'missing')),
    }
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--lean-run-id', required=True)
    args = parser.parse_args()
    if (PACKET / 'launcher.json').exists():
        raise RuntimeError('This packet already has a launch record; retain it, do not rerun here')
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    if head != args.expected_head:
        raise RuntimeError(f'Unexpected integration HEAD: {head}')
    frozen_record = json.loads((PACKET / 'frozen-inputs.json').read_text())
    frozen = frozen_record['files']
    mismatch = frozen_mismatches(frozen)
    if mismatch:
        write_json('preflight-input-mismatch.json', mismatch)
        raise RuntimeError('Governed suite inputs changed from the lead-frozen manifest')
    inventory = json.loads((PACKET / 'suite-inventory.json').read_text())
    coverage = json.loads((PACKET / 'coverage-plan.json').read_text())
    status = run_status('preflight-runs.json')
    lean = next((row for row in status['runs'] if row['run_id'] == args.lean_run_id), None)
    if not lean or lean['kind'] != 'lean' or lean['scope'] != 'complete' or lean['state'] != 'success':
        raise RuntimeError('The named complete Lean run has not succeeded')
    if status['reserved_workers'] or any(row['active'] for row in status['runs']):
        raise RuntimeError('A managed reservation remains active; keep the suite held')
    if resources(os.getpid())['available_kib'] < GUARD_KIB:
        raise RuntimeError('Insufficient host memory headroom before suite launch')
    resource.setrlimit(resource.RLIMIT_STACK, (STACK, resource.getrlimit(resource.RLIMIT_STACK)[1]))
    host = native_layout(root=ROOT)
    native_inputs = input_hashes(host)
    provenance = validate_provenance(host, host.compiler / 'obj/gnatprove')
    native_manifest_path = host.compiler / 'obj/gnatprove/proof-provenance.json'
    (PACKET / 'native-proof-provenance.json').write_bytes(native_manifest_path.read_bytes())
    binaries = {str(path.relative_to(ROOT)): digest(path)
                for path in [host.compiler / 'bin/silver', host.compiler / 'bin/silver_image_adapter']}
    reason = (f'One complete final suite on {head}, frozen implementation {frozen_record["head"]}: '
              f'complete Lean {args.lean_run_id} and native proof/build passed; all 699 discovered methods '
              'including 88 unchanged full-route twins with 196 execution cases and manifest samples. '
              'Original integration binary/cache, all available managed workers after Lean release, '
              '16 MiB stack and 1.5 GiB host-headroom guard. No focused rerun or rebuild.')
    command = [sys.executable, 'scripts/dev.py', 'test', '--task', '#391-suite', '--reason', reason]
    metadata = dict(launch_head=head, implementation_head=frozen_record['head'], root=str(ROOT),
                    platform=list(os.uname()), cpus=len(os.sched_getaffinity(0)),
                    stack_limits=list(resource.getrlimit(resource.RLIMIT_STACK)),
                    guard_minimum_available_kib=GUARD_KIB, lean_run_id=args.lean_run_id,
                    command=command, inventory_methods=inventory['count'],
                    frozen_input_count=len(frozen), native_inputs_sha256=native_inputs,
                    binary_sha256=binaries, native_proof_mode=provenance['mode'],
                    native_proof_manifest_sha256=digest(native_manifest_path),
                    started_at=utc(), status='starting')
    write_json('launcher.json', metadata)
    start = time.monotonic()
    child = subprocess.Popen(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, bufsize=1, start_new_session=True)
    metadata.update(pid=child.pid, status='running')
    write_json('launcher.json', metadata)
    stopped = threading.Event()
    guarded = []

    def sample():
        with (PACKET / 'resources.jsonl').open('w') as stream:
            while not stopped.is_set():
                row = resources(child.pid)
                stream.write(json.dumps(row) + '\n')
                stream.flush()
                if row['available_kib'] < GUARD_KIB and child.poll() is None and not guarded:
                    guarded.append(row)
                    print('RESOURCE GUARD: host headroom below 1.5 GiB; retaining interrupted evidence', flush=True)
                    try:
                        os.killpg(child.pid, signal.SIGINT)
                    except ProcessLookupError:
                        pass
                stopped.wait(5)

    sampler = threading.Thread(target=sample)
    sampler.start()
    with (PACKET / 'terminal.log').open('w') as stream:
        for line in child.stdout:
            stream.write(line)
            stream.flush()
            if (line.startswith(('Managed run:', 'Ran ', 'OK', 'FAILED', 'ERROR:', 'FAIL:',
                                 'Traceback', 'development command:'))
                    or re.search(r'\.\.\. (?:FAIL|ERROR|skipped .+)$', line)):
                print(line, end='', flush=True)
    result = child.wait()
    stopped.set()
    sampler.join()
    log = (PACKET / 'terminal.log').read_text()
    outcomes = parse_results(log, inventory, coverage)
    write_json('test-outcomes.json', outcomes)
    mismatch = frozen_mismatches(frozen)
    after_binaries = {name: digest(ROOT / name) for name in binaries}
    native_stable = input_hashes(host) == native_inputs
    metadata.update(status='finished', returncode=result, finished_at=utc(),
                    duration_seconds=time.monotonic() - start, guard_fired=guarded,
                    frozen_input_mismatches=mismatch, native_inputs_stable=native_stable,
                    binary_sha256_after=after_binaries, binary_inputs_stable=after_binaries == binaries,
                    actual_count=outcomes['actual_count'], conclusion=outcomes['conclusion'])
    write_json('launcher.json', metadata)
    run_status('postflight-runs.json')
    print(json.dumps({key: metadata[key] for key in ['returncode', 'duration_seconds',
          'guard_fired', 'native_inputs_stable', 'binary_inputs_stable', 'actual_count', 'conclusion']}), flush=True)
    if result or guarded or mismatch or not native_stable or after_binaries != binaries:
        raise SystemExit(result or 130)
    if outcomes['actual_count'] != inventory['count'] or outcomes['missing_methods']:
        raise SystemExit('Suite finished but retained inventory/outcome reconciliation is incomplete')


if __name__ == '__main__':
    main()
