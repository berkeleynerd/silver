"""Closed scalar functions, full formal domains and assignment-only calls."""
from pathlib import Path
import tempfile
import unittest

from tests import test_shared_bindings as shared

program = shared.program
IDENTITY = b'function Id(X:in Integer)return Integer is begin return X;end Id;'
BOOLEAN = b'function Flip(B:in Boolean)return Boolean is begin return not B;end Flip;'

# A valid argument shell accepts the default, empty and printable inputs. Invalid
# arity and non-printable input must reject before any application output.
ARGUMENT_SILENT_RUNS = (
    ((), b'', 0), ((b'',), b'', 0), ((b'valid',), b'', 0),
    ((b'one', b'two'), b'', 1), ((b'\x01',), b'', 1),
)
ARGUMENT_OK_RUNS = (
    ((), b'ok\n', 0), ((b'',), b'ok\n', 0), ((b'valid',), b'ok\n', 0),
    ((b'one', b'two'), b'', 1), ((b'\x01',), b'', 1),
)
ARGUMENT_ECHO_RUNS = (
    ((), b'old\n', 0), ((b'',), b'\n', 0), ((b'valid',), b'valid\n', 0),
    ((b'one', b'two'), b'', 1), ((b'\x01',), b'', 1),
)


class ScalarFunctionTests(unittest.TestCase):
    check = shared.SharedBindingsTests.check
    check_full_route = shared.SharedBindingsTests.check_full_route
    compile = shared.SharedBindingsTests.compile
    run_program = shared.SharedBindingsTests.run_program

    def setUp(self) -> None:
        temporary = tempfile.TemporaryDirectory(prefix='silver scalar functions-')
        self.addCleanup(temporary.cleanup)
        self.source = Path(temporary.name).resolve() / 'functions.adb'

    def test_typed_terminal_returns_and_assignment_calls(self) -> None:
        cases = (
            (IDENTITY + b'R:Integer:=0;', b'R:=id(7);R:=Id(R);', ('Id',)),
            (BOOLEAN + b'R:Boolean:=False;', b'R:=fLIP(True);R:=Flip(R);', ('Flip',)),
            (b'subtype Small is Integer range -2..2;'
             b'function Id(X:in Small)return Small is begin return X;end Id;'
             b'R:Small:=0;', b'R:=Id((-2));R:=Id(2);', ('Id',)),
            (b'function Select_Value(X:in Integer;B:in Boolean)return Integer is '
             b'R:Integer:=0;begin if B then R:=X;end if;return R;end Select_Value;'
             b'R:Integer:=0;', b'R:=Select_Value(7,1<2);', ('Select_Value',)),
        )
        for declarations, body, functions in cases:
            with self.subTest(declarations=declarations):
                self.check_full_route(program(declarations, body),
                                      kind='assigned', functions=functions)

    def test_formal_syntax_and_closing_names(self) -> None:
        for declaration in (
            b'function F return Integer is begin return 0;end F;',
            b'function F()return Integer is begin return 0;end F;',
            b'function F(X:in Integer;)return Integer is begin return X;end F;',
            b'function F(X:Integer)return Integer is begin return X;end F;',
            b'function F(X,Y:in Integer)return Integer is begin return X;end F;',
            b'function F(X:out Integer)return Integer is begin return X;end F;',
            b'function F(X:in out Integer)return Integer is begin return X;end F;',
            b'function F(X:in Integer:=0)return Integer is begin return X;end F;',
            b'function F(X:in Integer range 0..1)return Integer is begin return X;end F;',
            b'function F(X:in Integer)return Integer range 0..1 is begin return 0;end F;',
            b'function F(X:in Integer)return Integer is begin return X;end Other;',
            b'function F(X:in Integer;x:in Integer)return Integer is begin return X;end F;',
            b'function F(X:in Integer)return Integer;',
            b'function F(X:in Integer)return Integer is(X);',
        ):
            with self.subTest(declaration=declaration):
                self.check(program(declaration, b'null;'), 2)

    def test_return_must_be_single_terminal_and_typed(self) -> None:
        for body in (
            b'null;', b'return;', b'if X=0 then return 0;else return X;end if;',
            b'return X;null;', b'return X;return X;',
            b'for I in 1..2 loop return X;end loop;return X;',
            b'return True;', b'return "x";',
        ):
            with self.subTest(body=body):
                declaration = b'function F(X:in Integer)return Integer is begin ' + body + b'end F;'
                self.check(program(declaration, b'null;'), 2)

    def test_actual_arity_kinds_and_positional_association(self) -> None:
        declarations = (IDENTITY + BOOLEAN
                        + b'function Pair(X:in Integer;Y:in Integer)return Integer is '
                          b'begin return X;end Pair;R:Integer:=0;B:Boolean:=False;')
        for body in (
            b'R:=Id();', b'R:=Id(1,2);', b'R:=Id(1,);', b'R:=Pair(1 2);',
            b'R:=Id(X=>1);',
            b'R:=Id(True);', b'B:=Flip(1);', b'R:=Flip(True);',
            b'B:=Id(1);', b'R:=Id;', b'Id(1);',
        ):
            with self.subTest(body=body):
                self.check(program(declarations, body), 2)

    def test_calls_are_whole_scalar_assignment_rhs_only(self) -> None:
        declarations = IDENTITY + BOOLEAN + (
            b'R:Integer:=0;B:Boolean:=False;A:array(1..1)of Integer:=(1=>0);')
        for body in (
            b'R:=(Id(1));', b'R:=(Id(1)+1);', b'R:=Id(Id(1));',
            b'if Flip(True) then null;end if;',
            b'if Id(1)=1 then null;end if;', b'B:=not Flip(True);',
            b"Silver_IO.Put_Line(Integer'Image(Id(1)));",
            b'A(1):=Id(1);', b'for I in 1..Id(2) loop null;end loop;',
        ):
            with self.subTest(body=body):
                self.check(program(declarations, body), 2)
        for initializer in (b'R:Integer:=Id(1);', b'B:Boolean:=Flip(True);'):
            self.check(program(IDENTITY + BOOLEAN + initializer, b'null;'), 2)
        self.check(program(IDENTITY + b'function F(X:in Integer)return Integer is '
                           b'begin return Id(X);end F;', b'null;'), 2)

    def test_full_formal_domain_is_checked_even_if_unused(self) -> None:
        unsafe = b'function F(X:in Integer)return Integer is begin return (X+1);end F;'
        self.check(program(unsafe, b'null;'), 2)
        self.check(program(unsafe + b'R:Integer:=0;', b'R:=F(0);'), 2)
        bounded = (b'subtype Small is Integer range 0..9;'
                   b'function F(X:in Small)return Integer is begin return (X+1);end F;')
        self.check_full_route(program(bounded, b'null;'), kind='static', functions=('F',))
        self.check(program(IDENTITY.replace(b'return X;', b'return (1/X);'), b'null;'), 2)

    def test_actual_and_result_ranges_use_declared_subtypes(self) -> None:
        declaration = (b'subtype Small is Integer range 0..9;'
                       b'function F(X:in Small)return Small is begin return 0;end F;')
        for actual, status in ((b'0', 0), (b'9', 0), (b'(-1)', 2), (b'10', 2)):
            with self.subTest(actual=actual):
                self.check_full_route(program(declaration + b'R:Small:=0;', b'R:=F(' + actual + b');'),
                                      status, kind='assigned', functions=('F',))
        self.check(program(declaration + b'R:Integer range 0..8:=0;', b'R:=F(0);'), 2)
        self.check(program(IDENTITY + b'R:Integer range 0..9:=0;', b'R:=Id(0);'), 2)
        self.check(program(declaration.replace(b'return 0;', b'return 10;'), b'null;'), 2)
        self.check_full_route(program(declaration + b'R:Small:=0;N:Integer:=0;',
                                     b'if N>=0 and then N<=9 then R:=F(N);end if;'),
                              kind='assigned', functions=('F',))
        self.check(program(declaration + b'R:Small:=0;N:Integer:=0;',
                           b'R:=1;R:=F(R);N:=(1/R);'), 2)

    def test_nonempty_actuals_and_returns_even_in_empty_loops(self) -> None:
        self.check(program(IDENTITY + b'R:Integer:=0;',
                           b'for I in 2..1 loop R:=Id(I);end loop;'), 2)
        declaration = (b'subtype Small is Integer range 0..9;'
                       b'function F(X:in Small)return Small is begin return X;end F;'
                       b'R:Small:=0;')
        self.check(program(declaration, b'if 1=0 then R:=F(10);end if;'), 2)

    def test_actuals_share_incoming_state_without_cross_argument_refinement(self) -> None:
        declarations = (b'function F(B:in Boolean;X:in Integer)return Integer is '
                        b'begin return X;end F;N:Integer range 0..1:=0;R:Integer:=0;')
        self.check(program(declarations, b'R:=F(N/=0,(1/N));'), 2)
        self.check_full_route(program(declarations, b'if N/=0 then R:=F(True,(1/N));end if;'),
                              kind='assigned', functions=('F',))

    def test_boolean_result_carries_no_argument_or_input_facts(self) -> None:
        declarations = (b'function Nonzero(X:in Integer)return Boolean is '
                        b'begin return X/=0;end Nonzero;'
                        b'N:Integer range 0..1:=0;R:Integer:=0;B:Boolean:=False;')
        self.check(program(declarations, b'B:=Nonzero(N);if B then R:=(1/N);end if;'), 2)
        self.check_full_route(program(BOOLEAN + b'B:Boolean:=False;',
                                     b'B:=Flip(not Silver_Arguments.Input_Is_Valid);'
                                     b'if B then Silver_IO.Put_Line("ok");else '
                                     b'Silver_Arguments.Reject;end if;', arguments=True),
                              kind='selected', functions=('Flip',), runs=ARGUMENT_OK_RUNS)
        # The helper's outer real guard above permits it; a stored call result
        # alone must not discharge the shell's input requirement.
        source = (b'with Silver_IO;with Silver_Arguments;procedure Main is pragma SPARK_Mode(On);'
                  b'Input:constant String:=Silver_Arguments.First_Or_Default("");' + BOOLEAN +
                  b'B:Boolean:=False;begin B:=Flip(not Silver_Arguments.Input_Is_Valid);'
                  b'if B then Silver_IO.Put_Line("ok");else Silver_Arguments.Reject;end if;end Main;')
        self.check(source, 2)

    def test_boolean_actuals_use_caller_string_and_character_facts(self) -> None:
        declarations = (BOOLEAN + b'R:Boolean:=False;S:String:="ab";'
                        b"C:Character:='a';")
        self.check_full_route(program(declarations,
                                     b'R:=Flip(S="ab");R:=Flip(C=S(1));'
                                     b"R:=Flip(S'Length=2 and then S(2)='b');"),
                              kind='assigned', functions=('Flip',))
        self.check_full_route(program(BOOLEAN + b'R:Boolean:=False;',
                                     b'R:=Flip(Input="old");', arguments=True),
                              kind='selected', functions=('Flip',), runs=ARGUMENT_SILENT_RUNS)
        # Each actual still needs its own established String index bounds.
        self.check(program(declarations, b"R:=Flip(S(3)='b');"), 2)

    def test_function_names_hide_predefined_names_in_later_closed_frames(self) -> None:
        named_true = IDENTITY.replace(b'Id', b'True')
        named_boolean = IDENTITY.replace(b'Id', b'Boolean')
        result = b'function F(X:in Integer)return Boolean is begin return '
        self.check_full_route(program(named_true + result + b'False;end F;', b'null;'),
                              kind='static', functions=('True', 'F'))
        self.check(program(named_true + result + b'True;end F;', b'null;'), 2)
        self.check(program(named_boolean + BOOLEAN, b'null;'), 2)

    def test_earlier_calls_and_recursion_rejection(self) -> None:
        wrapper = (b'function Twice(X:in Integer)return Integer is R:Integer:=0;'
                   b'begin R:=Id(X);R:=Id(R);return R;end Twice;')
        self.check_full_route(program(IDENTITY + wrapper + b'R:Integer:=0;', b'R:=Twice(7);'),
                              kind='assigned', functions=('Id', 'Twice'))
        self.check(program(wrapper + IDENTITY, b'null;'), 2)
        self_call = (b'function F(X:in Integer)return Integer is R:Integer:=0;'
                     b'begin R:=F(X);return R;end F;')
        self.check(program(self_call, b'null;'), 2)
        mutual = self_call.replace(b'R:=F(X)', b'R:=G(X)') + self_call.replace(b'function F', b'function G').replace(b'end F', b'end G')
        self.check(program(mutual, b'null;'), 2)

    def test_local_initializers_are_independent_exact_snapshots(self) -> None:
        body = (b'function F(X:in Integer)return Integer is A:Integer:=7;'
                b'K:constant Integer:=A;begin A:=X;return K;end F;')
        self.check_full_route(program(body, b'null;'), kind='assigned', functions=('F',))
        for locals_ in (b'A:Integer:=X;', b'B:Boolean:=X=0;', b'A:Integer:=Outer;',
                        b'A:Integer:=Id(0);', b'X:Integer:=0;',
                        b'subtype S is Integer range 0..9;A:S:=0;'):
            with self.subTest(locals=locals_):
                self.check(program(b'Outer:Integer:=0;' + IDENTITY +
                                   b'function F(X:in Integer)return Integer is ' + locals_ +
                                   b'begin return X;end F;', b'null;'), 2)

    def test_functions_cannot_capture_or_perform_effects(self) -> None:
        prefix = b'Outer:Integer:=0;function F(X:in Integer)return Integer is '
        for locals_, body in (
            (b'', b'return Outer;'), (b'', b'Outer:=X;return X;'),
            (b'', b'Silver_IO.Put_Line("bad");return X;'),
            (b'', b'if "a"="a" then null;end if;return X;'),
            (b'S:String:="x";', b'return X;'),
            (b"C:Character:='a';", b'return X;'),
            (b'A:array(1..1)of Integer:=(1=>0);', b'return X;'),
            (b'A:array(1..1)of Boolean:=(1=>True);', b'return X;'),
            (IDENTITY, b'return X;'),
        ):
            with self.subTest(locals=locals_, body=body):
                self.check(program(prefix + locals_ + b'begin ' + body + b'end F;', b'null;'), 2)
        for body in (b'Silver_Arguments.Reject;return X;',
                     b'if Silver_Arguments.Input_Is_Valid then null;end if;return X;'):
            self.check(program(prefix + b'begin ' + body + b'end F;', b'null;', arguments=True), 2)

    def test_formals_are_immutable_and_guard_refinable(self) -> None:
        self.check(program(IDENTITY.replace(b'return X;', b'X:=0;return X;'), b'null;'), 2)
        declaration = (b'function F(X:in Integer)return Integer is R:Integer:=0;begin '
                       b'if X>0 then for I in 1..2 loop R:=(1/X);end loop;end if;'
                       b'return R;end F;')
        self.check_full_route(program(declaration, b'null;'), kind='assigned', functions=('F',))
        self.check(program(declaration.replace(b'X>0', b'X/=0'), b'null;'), 2)

    def test_hiding_and_duplicate_names(self) -> None:
        self.check(program(IDENTITY + IDENTITY, b'null;'), 2)
        self.check(program(IDENTITY + b'Id:Integer:=0;', b'null;'), 2)
        self.check(program(b'Id:Integer:=0;' + IDENTITY, b'null;'), 2)
        self.check(program(IDENTITY + b'R:Integer:=0;',
                           b'for Id in 1..2 loop R:=Id(0);end loop;'), 2)
        wrapper = (b'function F(Id:in Integer)return Integer is R:Integer:=0;'
                   b'begin R:=Id(0);return R;end F;')
        self.check(program(IDENTITY + wrapper, b'null;'), 2)
        self.check(program(b'Integer:String:="x";' + IDENTITY, b'null;'), 2)
        self.check(program(b'Boolean:Integer:=0;' + BOOLEAN, b'null;'), 2)

    def test_existing_array_actuals_and_nested_loops(self) -> None:
        declarations = (IDENTITY + BOOLEAN + b'R:Integer:=0;B:Boolean:=False;'
                        b'A:array(1..2)of Integer:=(4,5);Flags:array(1..2)of Boolean:=(True,False);')
        self.check_full_route(program(declarations, b'for I in 1..2 loop for J in 1..2 loop '
                                     b'R:=Id(A(I));B:=Flip(Flags(J));end loop;end loop;'),
                              kind='assigned', functions=('Id', 'Flip'))

    def test_local_hiding_is_independent_of_return_arithmetic(self) -> None:
        # C-1's original programs reject their returns, not their local names.
        cases = (
            (b'A:array(0..1)of Boolean:=(True,False);', b'A', b'1',
             b'1', b"if A(0) then Silver_IO.Put_Line(Integer'Image(R));end if;", b' 1\n'),
            (b'K:Integer:=2;', b'K', b'1',
             b'K', b"Silver_IO.Put_Line(Integer'Image(R));", b' 1\n'),
            (b'S:constant String:="ab";', b'S', b'1', b'1',
             b"Silver_IO.Put_Line(S);Silver_IO.Put_Line(Integer'Image(R));", b'ab\n 1\n'),
        )
        for outer, local, value, actual, output, expected_output in cases:
            declarations = (outer + b'function F(X:in Integer)return Integer is '
                            + local + b':Integer:=' + value + b';begin return ')
            suffix = (b';end F;R:Integer:=0;begin R:=F(' + actual + b');'
                      + output + b'end Main;')
            prefix = b'with Silver_IO;procedure Main is pragma SPARK_Mode(On);'
            for result, status in ((local, 0), (local + b'+X', 2),
                                   (b'(' + local + b'+X)', 2)):
                with self.subTest(local=local, result=result):
                    # Grouping fixes the syntax, but not full-Integer overflow.
                    self.check_full_route(prefix + declarations + result + suffix, status,
                                          kind='assigned', functions=('F',),
                                          runs=(((), expected_output, 0),))

    def test_source_wide_operator_budget_spans_functions(self) -> None:
        for count, status in ((63, 0), (64, 2)):
            functions = b'subtype Small is Integer range 0..9;' + b''.join(
                b'function F' + str(i).encode() + b'(X:in Small)return Integer is '
                b'begin return (X+1);end F' + str(i).encode() + b';'
                for i in range(2))
            # Two operators in the functions plus the rest in Main. Separate
            # assignments keep each expression below its operand budget.
            body = b'R:=(R+0);' * (count - 2)
            with self.subTest(count=count):
                self.check_full_route(program(functions + b'R:Integer range 0..1:=0;', body),
                                      status, kind='assigned', functions=('F0', 'F1'))

    def test_dense_formals_and_complete_source_bound(self) -> None:
        formals = b';'.join(b'P' + str(i).encode() + b':in Integer' for i in range(150))
        declaration = b'function F(' + formals + b')return Integer is begin return P149;end F;'
        source = program(declaration, b'null;')
        self.assertLess(len(source), 4096)
        padded = source + b' ' * (4096 - len(source))
        self.check_full_route(padded, kind='static', functions=('F',))
        self.check(padded + b' ', 2)

    def test_dense_locals_and_function_list(self) -> None:
        locals_ = b''.join(b'L' + str(i).encode() + b':T:=0;' for i in range(250))
        declaration = (b'subtype T is Integer range 0..9;'
                       b'function F(X:in Integer)return Integer is ' + locals_ +
                       b'begin return X;end F;')
        self.assertLess(len(program(declaration, b'null;')), 4096)
        self.check_full_route(program(declaration, b'null;'), kind='static', functions=('F',))
        functions = b''
        count = 0
        while True:
            name = b'F' + str(count).encode()
            candidate = functions + (b'function ' + name + b'(X:in Integer)return Integer is '
                                     b'begin return X;end ' + name + b';')
            if len(program(candidate, b'null;')) > 4096:
                break
            functions = candidate
            count += 1
        self.assertGreater(count, 30)
        self.check_full_route(program(functions, b'null;'), kind='static',
                              functions=tuple(f'F{i}' for i in range(count)))

    def test_native_ordered_calls_snapshot_and_full_unused_coverage(self) -> None:
        declarations = (b'subtype Small is Integer range 0..9;'
                        b'function Next_Value(X:in Small)return Integer is begin return (X+1);end Next_Value;'
                        b'function Wrapper(X:in Small;B:in Boolean)return Integer is R:Integer:=0;'
                        b'begin if B then R:=Next_Value(X);'
                        b'for I in 1..X loop for J in 1..I loop '
                        b'R:=Next_Value(J);end loop;end loop;end if;return R;end Wrapper;'
                        b'function Unused(X:in Integer)return Integer is R:Integer:=0;'
                        b'begin if X>0 then R:=(10/X);end if;return R;end Unused;'
                        b'function Zero(X:in Integer;B:in Boolean)return Integer is Spare:Integer:=7;'
                        b'C:constant Integer:=Spare;'
                        b'begin return 0;end Zero;'
                        b'R:Integer:=0;')
        executable, report = self.compile(program(declarations,
            b'R:=wRAPPER(9,True);Silver_IO.Put_Line(Integer\'Image(R));'),
            'assigned', functions=('Next_Value', 'Wrapper', 'Unused', 'Zero'))
        self.run_program(executable, b' 10\n')
        self.assertTrue(any(item.get('rule') == 'SUBPROGRAM_TERMINATION'
                            for item in report['flow']))
        self.assertTrue(any(item.get('rule') == 'VC_DIVISION_CHECK'
                            for item in report['proof']))

    def test_native_boolean_and_integer_self_actuals(self) -> None:
        declarations = (b'subtype Small is Integer range 1..10;'
                        + IDENTITY.replace(b'Integer', b'Small') + BOOLEAN
                        + b'R:Small:=7;B:Boolean:=False;')
        executable, _ = self.compile(program(declarations,
            b'for I in 1..3 loop R:=Id(R);end loop;'
            b'B:=Flip(B);if B then Silver_IO.Put_Line(Integer\'Image(R));end if;'),
            'assigned', functions=('Id', 'Flip'))
        self.run_program(executable, b' 7\n')

    def test_native_unused_function_without_main_output(self) -> None:
        declarations = (b'subtype Small is Integer range 1..10;'
                        b'function Unused(X:in Small)return Integer is '
                        b'begin return (100/X);end Unused;')
        # This remains the output-capable shell and its warnings policy.
        executable, report = self.compile(program(declarations, b'null;'),
                                          'static', functions=('Unused',))
        entity = next(int(key) for key, item in report['entities'].items()
                      if item['name'] == 'Main.Unused')
        for section, rule in (('flow', 'SUBPROGRAM_TERMINATION'),
                              ('proof', 'VC_DIVISION_CHECK')):
            self.assertTrue(any(item.get('entity') == entity and item.get('rule') == rule
                                for item in report[section]), (section, report))
        self.run_program(executable, b'')

    def test_native_hiding_and_argument_shell(self) -> None:
        declarations = (
            b'A:array(0..1)of Boolean:=(True,False);K:Integer:=2;S:constant String:="ab";'
            b'function Formal_String(S:in Integer)return Integer is begin return S;end Formal_String;'
            b'function Formal_Integer(K:in Integer)return Integer is begin return K;end Formal_Integer;'
            b'function Main(Main:in Integer)return Integer is begin return Main;end Main;'
            b'function Local_Integer(X:in Integer)return Integer is K:Integer:=1;'
            b'begin return K;end Local_Integer;'
            b'function Local_String(X:in Integer)return Integer is S:Integer:=3;'
            b'begin return S;end Local_String;'
            b'function Local_Array(X:in Integer)return Integer is A:Integer:=4;'
            b'begin return A;end Local_Array;'
            b'function Local_Name(X:in Integer)return Integer is Local_Name:Integer:=5;'
            b'begin return Local_Name;end Local_Name;'
            b'function Flag(Integer:in Boolean)return Boolean is begin return Integer;end Flag;'
            b'R:Integer:=0;B:Boolean:=False;')
        body = (b'Silver_IO.Put_Line(Input);'
                b"R:=Formal_String(6);Silver_IO.Put_Line(Integer'Image(R));"
                b"R:=Formal_Integer(K);Silver_IO.Put_Line(Integer'Image(R));"
                b"R:=Main(R);Silver_IO.Put_Line(Integer'Image(R));"
                b"R:=Local_Integer(0);Silver_IO.Put_Line(Integer'Image(R));"
                b"R:=Local_String(0);Silver_IO.Put_Line(Integer'Image(R));"
                b"R:=Local_Array(0);Silver_IO.Put_Line(Integer'Image(R));"
                b"R:=Local_Name(0);Silver_IO.Put_Line(Integer'Image(R));"
                b'B:=Flag(True);if B and then A(0) then Silver_IO.Put_Line(S);'
                b"Silver_IO.Put_Line(Integer'Image(K));end if;")
        executable, _ = self.compile(program(declarations, body, arguments=True),
            'selected', functions=('Formal_String', 'Formal_Integer', 'Main',
                                   'Local_Integer', 'Local_String', 'Local_Array', 'Local_Name', 'Flag'))
        suffix = b' 6\n 2\n 2\n 1\n 3\n 4\n 5\nab\n 2\n'
        self.run_program(executable, b'old\n' + suffix)
        self.run_program(executable, b'valid\n' + suffix, (b'valid',))
        self.run_program(executable, b'', (b'one', b'two'), 1)
