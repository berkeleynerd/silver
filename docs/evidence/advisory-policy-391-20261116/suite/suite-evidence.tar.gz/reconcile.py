"""Reconcile the one original suite log using its exact unittest IDs.

The live launcher's parser normalizes `tests.` away. The frozen inventory has
nine imported test IDs where that prefix is meaningful, so retain the original
launcher and its result and perform this exact-ID reconciliation separately.
No test or native command is executed here.
"""
from pathlib import Path
import collections
import json
import re

PACKET = Path(__file__).resolve().parent


def reconcile():
    inventory = json.loads((PACKET / 'suite-inventory.json').read_text())
    coverage = json.loads((PACKET / 'coverage-plan.json').read_text())
    log = (PACKET / 'terminal.log').read_text()
    expected = set(inventory['tests'])
    outcomes = {}
    pending = None
    unrecognized = []
    duplicate_starts = []
    for line in log.splitlines():
        start = re.match(r'^test\w* \(([^)]+)\)(.*)$', line)
        if start:
            identifier = start[1]
            if identifier not in expected:
                unrecognized.append(line)
                pending = None
            else:
                if identifier in outcomes:
                    duplicate_starts.append(identifier)
                pending = identifier
                outcomes[identifier] = dict(status='unresolved', start=line)
        result = re.search(r'(?:\.\.\. |^)(ok|skipped .+|FAIL|ERROR|expected failure|unexpected success)$', line)
        if result and pending:
            status = result[1]
            outcomes[pending].update(status=status, result_line=line)
            if status == 'ok' or status.startswith('skipped '):
                pending = None
    summaries = re.findall(r'^Ran (\d+) tests? in ([\d.]+)s$', log, flags=re.MULTILINE)
    conclusions = re.findall(r'^(?:OK(?: \([^\n]*\))?|FAILED \([^\n]*\))$', log,
                             flags=re.MULTILINE)
    skipped = {name: row['status'] for name, row in outcomes.items()
               if row['status'].startswith('skipped ')}
    full_methods = {name: outcomes.get(name, {}).get('status', 'missing')
                    for name in coverage['full_route']['methods']}
    sample_status = outcomes.get('test_samples.SupportedSampleTests.test_manifest_samples', {}).get(
        'status', 'missing')
    result = dict(expected_methods=inventory['count'], observed_methods=len(outcomes),
                  actual_count=int(summaries[-1][0]) if summaries else None,
                  test_seconds=float(summaries[-1][1]) if summaries else None,
                  conclusion=conclusions[-1] if conclusions else None,
                  passed=sum(row['status'] == 'ok' for row in outcomes.values()),
                  skipped=skipped, statuses=dict(collections.Counter(row['status'] for row in outcomes.values())),
                  missing_methods=sorted(expected - outcomes.keys()),
                  unrecognized_starts=unrecognized, duplicate_starts=duplicate_starts,
                  methods=outcomes,
                  full_route=dict(coverage['full_route'], method_outcomes=full_methods,
                                  all_covering_methods_passed=all(s == 'ok' for s in full_methods.values())),
                  samples=dict(coverage['samples'], method_outcome=sample_status),
                  basis='Exact test IDs and outcomes from the single original terminal.log, reconciled with the frozen discovery and reviewed fixture/sample inventories. This script executes no tests.')
    (PACKET / 'exact-test-outcomes.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ['actual_count', 'observed_methods', 'passed',
          'skipped', 'conclusion', 'missing_methods', 'unrecognized_starts', 'duplicate_starts']}, indent=2))


if __name__ == '__main__':
    reconcile()
