from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
source=Path('/tmp/silver-producer-fixed-deps-plan-20261018')
case=root/sys.argv[1]
repo=Path('/home/canto/src/github.com/berkeleynerd/silver')
cmd=['python3',str(repo/'scripts/dev.py'),'tool','--task','#119','--jobs','1','--reason','Fixed library producer representation measurement '+case.name+'; existing exact-source ALIs, false backend, no solvers','--workspace',str(root),'--workspace',str(source)]
inputs=[root/'managed.py',root/'plan.json',root/'raw_snapshot_v2.py',source/'naming.adc',*[case/n for n in ('probe.py','probe.gdb','invocation.json','options.json','object-paths.txt')],*sorted((source/'library-src').glob('*')),*sorted((source/'library-obj').glob('*.ali'))]
inputs += [repo/'.tools/linux-x86_64/alire/cache/releases/gnatprove_16.1.0_82528bef/libexec/spark/bin/gnat2why']
for p in inputs: cmd+=['--input',str(p)]
cmd+=['--','python3',str(case/'probe.py')]
raise SystemExit(subprocess.call(cmd,cwd=repo))
