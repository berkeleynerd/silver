import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/home/canto/src/github.com/berkeleynerd/silver/tmp/retained-tool-capacity')
OUT = Path(__file__).resolve().parent
CASES = {
    'null': 'procedure Main is\n   pragma SPARK_Mode (On);\nbegin\n   null;\nend Main;\n',
    'literal': 'with Silver_IO;\nprocedure Main is\n   pragma SPARK_Mode (On);\nbegin\n   Silver_IO.Put ("a");\nend Main;\n',
    'long_name': 'with Silver_IO;\nprocedure Main is\n   pragma SPARK_Mode (On);\n   ' + 'N' * 2500 + ' : String := "a";\nbegin\n   null;\nend Main;\n',
}
FILES = ['silver_io.ads', 'silver_io.adb', 'silver_runtime.ads',
         'silver_output_libc.ads', 'silver_arguments.ads', 'silver_arguments.adb']
results = []
for case, source in CASES.items():
    for variant, extra in [('baseline', []), ('proposed', ['-gnatx', '-Wno-free-nonheap-object'])]:
        work = OUT / (case + '-' + variant)
        work.mkdir()
        src = work / 'src'
        src.mkdir()
        (src / 'main.adb').write_text(source)
        if case != 'null':
            for name in FILES:
                shutil.copyfile(ROOT / 'src' / name, src / name)
        switches = ['-gnat2022', '-gnata', '-gnato']
        default = ', '.join('"' + flag + '"' for flag in switches)
        specific = ', '.join('"' + flag + '"' for flag in switches + extra)
        project = ('project Probe is\n   for Source_Dirs use ("src");\n'
                   '   for Object_Dir use "obj";\n   for Exec_Dir use "bin";\n'
                   '   for Main use ("main.adb");\n   package Compiler is\n'
                   '      for Default_Switches ("Ada") use (' + default + ');\n'
                   '      for Switches ("main.adb") use (' + specific + ');\n'
                   '   end Compiler;\nend Probe;\n')
        (work / 'probe.gpr').write_text(project)
        command = ['gprbuild', '-P', str(work / 'probe.gpr'), '-p', '-j1', '-v']
        build = subprocess.run(command, cwd=work, capture_output=True)
        (work / 'build.stdout').write_bytes(build.stdout)
        (work / 'build.stderr').write_bytes(build.stderr)
        if build.returncode:
            raise RuntimeError((case, variant, build.stderr.decode(), build.stdout.decode()))
        run = subprocess.run([str(work / 'bin' / 'main')], capture_output=True)
        (work / 'run.stdout').write_bytes(run.stdout)
        (work / 'run.stderr').write_bytes(run.stderr)
        assert run.returncode == 0 and run.stdout == (b'a' if case == 'literal' else b'')
        assert run.stderr == b''
        ali = (work / 'obj' / 'main.ali').read_bytes()
        lines = ali.split(b'\n')
        xrefs = sum(line.startswith(b'X ') for line in lines)
        options = [line.decode() for line in lines if line.startswith(b'A ')]
        if variant == 'proposed':
            assert xrefs == 0
            assert 'A -gnatx' in options and 'A -Wno-free-nonheap-object' in options
        else:
            assert xrefs > 0
        result = dict(case=case,variant=variant,command=command,
                      source_bytes=len(source.encode()),
                      source_sha256=hashlib.sha256(source.encode()).hexdigest(),
                      build_exit=build.returncode,run_exit=run.returncode,
                      stdout=run.stdout.decode(),ali_bytes=len(ali),
                      longest_ali_record_including_lf=max(map(len,lines))+1,
                      xref_headers=xrefs,stored_switch_records=options,
                      compiler=shutil.which('gcc'),gprbuild=shutil.which('gprbuild'))
        results.append(result)
        print(json.dumps(result), flush=True)
(OUT / 'result.json').write_text(json.dumps(results, indent=2) + '\n')
