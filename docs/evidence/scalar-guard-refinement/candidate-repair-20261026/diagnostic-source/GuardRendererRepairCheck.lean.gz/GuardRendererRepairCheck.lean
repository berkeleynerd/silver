module
import Silver.PredicateBodyExpressions
import all Init.Data.Repr

set_option maxRecDepth 100000
set_option maxHeartbeats 10000000
namespace Silver.Predicate.BodyNative
example : readContractBody.render =
    (Source.lexLine "(if Statement_Body (Text, Context, Scan).Position = 0 then Invalid_Body (Statement_Body (Text, Context, Scan)) else Body_Tail_Model (Text, Context, Statement_Body (Text, Context, Scan), Stop))").getD [] := by
  simp only [readContractBody, ModelExpr.render.eq_def, ModelExpr.renderElse.eq_def,
    ScanExpr.render, Test.render, StopRef.render]
  decide +kernel
end Silver.Predicate.BodyNative
