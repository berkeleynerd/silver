module
import Silver.PredicateSourceRequirements
import all Init.Data.Repr

set_option maxRecDepth 100000
set_option maxHeartbeats 10000000

namespace Silver.Predicate.SourceChecks
open Silver.SourceBridge

example : functionHeader "read_body" ";" SourceShape.bodyTokens =
    some body_read_body_spec_header := by
  unfold body_read_body_spec_header
  simp only [BodyNative.readContractBody, BodyNative.ModelExpr.render.eq_def,
    BodyNative.ModelExpr.renderElse.eq_def, BodyNative.ScanExpr.render,
    BodyNative.Test.render, BodyNative.StopRef.render]
  decide +kernel

example : functionHeader "valid_flow" "is" SourceShape.bodyTokens =
    some ((Source.lexLine
      "(Context : Body_Context; Facts : Scalar_Flow) return Boolean").getD []) := by
  decide +kernel

example : functionHeader "included" "is" SourceShape.bodyTokens =
    some ((Source.lexLine
      "(Value, Bounds : Scalars.Interval) return Boolean").getD []) := by
  decide +kernel

end Silver.Predicate.SourceChecks
