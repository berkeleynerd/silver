from pathlib import Path
import hashlib
import json
import sys
import time
import unittest

root = Path(__file__).resolve().parents[2]
author = root / 'tmp/scalar-guards-native-author'
sys.path.insert(0, str(author))
from tests import test_silver, test_scalar_guards

test_silver.SILVER = root / 'tmp/guard-frame-check/bin/silver'
case_count = 0
old_check = test_scalar_guards.ScalarGuardTests.check
def counted(self, source, expected=0):
    global case_count
    case_count += 1
    return old_check(self, source, expected)
test_scalar_guards.ScalarGuardTests.check = counted
names = sorted(n for n in dir(test_scalar_guards.ScalarGuardTests)
               if n.startswith('test_admission_'))
suite = unittest.TestSuite(test_scalar_guards.ScalarGuardTests(n) for n in names)
start = time.time()
result = unittest.TextTestRunner(verbosity=2).run(suite)
summary = {'tests': result.testsRun, 'cases': case_count,
           'failures': len(result.failures), 'errors': len(result.errors),
           'elapsed_seconds': time.time() - start,
           'executable_sha256': hashlib.sha256(test_silver.SILVER.read_bytes()).hexdigest(),
           'source_sha256': hashlib.sha256((root / 'tmp/guard-frame-check/src/silver_output_profile.adb').read_bytes()).hexdigest(),
           'scope': 'Exploratory admission-only tests against scratch executable; no application proof/build execution.'}
(root / 'tmp/guard-frame-check/admission-summary.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps(summary, indent=2))
sys.exit(not result.wasSuccessful())
