# Feature-local guard parser frame review — 2026-10-26

Selected reviewer: GPT-6 Astra, Extra High, as assigned. Runtime model/effort
and token/cost measurements are not independently exposed. Read-only review
elapsed time was not measured separately; first review checkpoint was recorded
at 03:17:48 UTC. No compiler, proof,
application, admission, or shape runner was launched. Inline Python only read
assembly/stack-usage records, followed call edges, and evaluated finite arithmetic.

## Exact inputs and scope

- Root scratch `tmp/guard-frame-check/primary-accounting-draft.md`.
- Root scratch `tmp/guard-frame-check/src/silver_output_profile.adb`, `.s`/`.su`
  under its `obj/`, scalar-expression source/assembly, lexical/name/literal/
  interval helper assembly and `.su`, and generated binder `b__silver.adb`.
- Canonical evidence `docs/evidence/scalar-guard-refinement/native-frames-20261026`;
  its frame run is `20261026T024531-a4f281e0e8cc`, Linux x86_64.
- Canonical and frame-copy `silver_output_profile.adb` both hash
  `1558f2100a5b9fd4b7b307bdb6538e259c3af078441ce06a707328601935d283`.
  Compiler switches in the frame probe: `-gnat2022 -gnata -gnato -g`.

This reviews the feature-local parser, not report processing, process-wide
resource sufficiency, or deferred #119. Any later source change needs an exact
applicability check; calling a change Static-only is not itself that check.
Shape successes are observations, not a universal bound.

## Confirmed primary accounting and correction

The draft's paired wrapper/body fixed sums match emitted `.su`: Primary 336,
Relation 576, Condition 304, Chain 464, Read_Body 304, Body_Tail 416,
Statement_Body 256, Loop_Body 29184, Conditional_Body 416, Alternative_Body 368.
The emitted dynamic objects have padded upper bounds
`S(B)=8B+48` for Body_Scan, `F(B)=8B+32` for Scalar_Flow, and
`C(B)=16B+48` for Condition_Result. Counts are active counts, not Max_Bindings.

`Read_Chain_Into` has two dynamic Condition_Result allocations at assembly
lines 21928 and 21965. One is Right and one is the runtime Loop_Entry capture.
The Static invariant is erased, but the runtime cursor comparison retains the
whole discriminated record. Thus `32B+96` is required before fixed chain frames.
Pure Boolean grouping forwards the input/output flow buffers; its recursive
increment is `304+576+336=1216`, without an active-vector allocation per group.

Correction: the scalar-expression recursive maximum is **1456**, not 1440:
`Read_Expression 448 + Read_Group 480 + Read_Compound 528`. The unary route is
`448+480+512=1440`; the pure nested-group route is `448+480=928`. Read_Atom does
not recurse. Read_Group evaluates the left Read_Expression before entering
Read_Compound, so those two sibling computations are not both live. The draft's
**1600 per group still covers all these routes**. This follows both source
lines 193–279 and emitted calls at scalar-expression assembly lines 6143,
6171, 6188, 6657 and 6686.

The enlarged coefficients cover these conservative retained-frame bundles:

- Loop: parent Read_Body + Body_Tail + Statement_Body = 976 fixed and at most
  two S(B) objects; Loop_Body contributes 29184 fixed plus S(B)+S(B+1).
  Total at most `30360+32B`, below `31000+32B`.
- Choice owner: both the conditional and terminal alternative, plus the parent
  three-frame body route, cost at most `2112+80B`, below `3500+96B`. An elsif
  retains fewer frames than this charged bundle. Alternative_Body allocates its
  three local vectors even in the terminal else/end case; omitting them is wrong.
- Chain: Condition + Chain + Relation + Primary fixed frames plus the two
  Condition_Result buffers cost `1776+32B`, below `2000+32B`.

These are conservative bundles; some frames cannot simultaneously have their
largest allocations. The remaining proof obligation is an explicit assignment
of each live recursive frame to a unique charged syntactic owner, including
mixed scalar/Boolean reparsing. Increasing coefficients alone is not that proof.

## Source-byte charge and arithmetic

For successfully admitted source, `12D+22L+12I+6C+2P <= 4096` is a conservative
syntactic charge: D counts scalar declarations, L complete for loops, I if/elsif
owners, C short-circuit links, P grouping pairs. A plain if uses at least 15 token
bytes excluding its statements; an elsif uses 12; loop tokens alone use 22.
Separators only increase these costs. Relation cores need at least three bytes
independent of grouping/link tokens. Active scalar count is at most D+L.
These charges must be applied to disjoint token occurrences, not count the same
minimal relation core in two owners.

Re-evaluating the draft envelope on integral counts gives maximum **7,400,560**
bytes at D=0,L=186,B=186,I=C=0,P=2 (the draft's 7,404,479 is not the integer
maximum). This is 988,048 bytes below 8 MiB. This arithmetic is conditional on
the frame-owner coverage and 524288-byte nonrecursive allowance.

The complete-program charge does **not** prove safe rejection of malformed
prefixes. A useful tighter route is available: repeated immediately nested
`for a in 0..0 loop ` headers require 19 bytes. There must be separation after
for, the identifier, in, the high scalar, and loop; scalar literals reject an
identifier continuation (`silver_scalar_literals.adb:235–246`). Parenthesizing
an operand cannot make it shorter. Actual ancestor counts are D+k, so sum them
rather than charging the deepest B to every loop ancestor. This materially
improves a rejection-prefix bound. I have not completed the combined malformed
loop/choice/chain/group optimization, so no universal rejection claim is made.

## Root and leaf allowance

The direct deep-body entry route from Output_Profile.Accepts has fixed sum
17808 + 35856 + 53520 + 35840 = 143024 bytes before the body-parser frames.
A read-only assembly-call-graph extraction, grouping public contract wrappers
with wrapped statements and excluding the recursive groups charged above,
found the largest project acyclic route 363680 bytes:
Accepts → Read_Form → Scan_Step → Step → Read_Declarations → Declaration_At →
String_Declaration_At → Add_Binding. The largest uncharged body leaf was
Basic_Body → Read_String_In_Flow → expression helpers, 13952 fixed bytes.
Body_Of → Context_Of → Body_Environment reaches 50848 fixed bytes transiently.
These observations support the scale of a 524288 allowance, but do not certify
it: assembly grouping is an exploratory extraction, runtime/library callees
and small dynamic nonrecursive objects still need explicit coverage. The
allowance also cannot silently include arbitrary callers before Accepts.

## Secondary-stack retention: actual release sites

Assembly facts differ from a reading that every source block is reclaimed:

- Body_Tail marks at assembly 26073 immediately before Statement_Body and
  releases via finalizer 25862 after copying that result into its primary local
  (call site 26104ff). Each completed iteration reclaims its whole child subtree.
  Therefore sibling iterations do not accumulate secondary storage.
- Conditional_Body marks at 28953 and releases through finalizer 28719 only
  around the Then_Keyword Body_Token assignment. It does **not** release all
  secondary results produced by that conditional or its first statement.
- Read_Body, Loop_Body, and Alternative_Body have no secondary mark/release.
  Their callee results and their own result allocations remain until a caller
  mark releases them. Read_Body's first Statement_Body result therefore survives
  throughout Body_Tail; elseif arms can accumulate results before that release.
- Read_Statements marks at 30292 and releases through finalizer 30247.
  Read_Form also marks/releases around its scan steps and scope. Match_Token
  reclaims its temporary Spelling result locally.
- Initial_Flow returns a secondary F(B), and Body_Of returns a secondary S(B).
  Body_Token and Invalid_Body each allocate one secondary S(B). Procedure-based
  condition parsing has no secondary vector-return allocation.

A useful payload-only upper bound can be obtained without relying on early
releases: count *all* flow/body allocations in one successfully parsed body.
Use at most 4 S(B) per basic statement (output has two parentheses, semicolon,
and final return), 6 per loop (five local/wrapper returns and its inner
Read_Body/Body_Tail return), 9 per if (including both arm/tail boundaries and a
terminal alternative), 4 per elsif, and 3 at the root (Body_Of, Initial_Flow,
top Body_Tail). Counting a temporary that is actually released only overbounds.
For N basics, L loops, J ifs, E elsifs this gives

`S(B) * (4N + 6L + 9J + 4E + 3)`.

The token debit `12D+22L+15J+12E+5N <= 4096`, with conservative
`B=D+L`, bounds the count factor by `0.8*(4096-12B)+3`.
Its maximum over 0<=B<=341 is **2,320,464 payload bytes** at B=168.
This is a conservative feature-local successful-parse retention bound, conditional
on the allocation-site count above and allocator rounding of at most 16 bytes.
It is independent of the primary bound: adding it to primary stack usage or
assuming it fits in the primary 8 MiB limit would be incorrect without the
runtime's allocation model.

The generated binder declares a library-level default secondary-stack pool and
assigns `System.Parameters.Runtime_Default_Sec_Stack_Size`; the provided assembly
only calls the external GNAT ss_allocate/ss_mark/ss_release implementation. It
does not establish chunk growth, metadata overhead, available heap, or failure
behavior. No runtime source from .tools was inspected. Thus this review closes
retained *object payload* accounting much further than the draft, but does not
claim complete secondary allocator resource sufficiency.

## Result

The enlarged primary coefficients survive this review, with the scalar-route
and integer-optimization corrections above. The draft is not yet a complete
universal 4096-byte/8-MiB certificate: owner assignment, nonrecursive/runtime
allowance, malformed-prefix accounting, and secondary allocator assumptions
remain explicit obligations. The successful-parse secondary payload envelope
and exact release-site findings can be integrated now without rerunning shapes.
