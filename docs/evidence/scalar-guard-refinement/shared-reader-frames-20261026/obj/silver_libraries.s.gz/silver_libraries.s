	.file	"silver_libraries.adb"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_libraries.adb"
	.align 2
	.globl	silver_libraries__unit_kindH
	.type	silver_libraries__unit_kindH, @function
silver_libraries__unit_kindH:
.LFB2:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	movq	-8(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L2
	movl	%edx, %ecx
	subl	%eax, %ecx
	leal	1(%rcx), %r11d
	jmp	.L3
.L2:
	movl	$0, %r11d
.L3:
	movslq	%eax, %r9
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	leal	-1(%rax), %r10d
	movl	$0, %esi
	movl	$0, %ecx
	movl	$0, %edx
.L11:
	testl	%edx, %edx
	jg	.L10
	movslq	%edx, %rax
	leaq	0(,%rax,4), %rdi
	leaq	unit_kindP.11(%rip), %rax
	movl	(%rdi,%rax), %eax
	cmpl	%eax, %r11d
	jl	.L10
	movq	-16(%rbp), %rax
	movslq	%edx, %rdi
	leaq	0(,%rdi,4), %r8
	leaq	unit_kindP.11(%rip), %rdi
	movl	(%r8,%rdi), %edi
	addl	%r10d, %edi
	movslq	%edi, %rdi
	subq	%r9, %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %r8d
	movslq	%edx, %rax
	leaq	unit_kindT1.10(%rip), %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %eax
	imull	%r8d, %eax
	leal	(%rsi,%rax), %edi
	movslq	%edi, %rax
	imulq	$1321528399, %rax, %rax
	shrq	$32, %rax
	movl	%eax, %esi
	sarl	$2, %esi
	movl	%edi, %eax
	sarl	$31, %eax
	subl	%eax, %esi
	movl	%esi, %eax
	addl	%eax, %eax
	addl	%esi, %eax
	sall	$2, %eax
	addl	%esi, %eax
	movl	%edi, %esi
	subl	%eax, %esi
	movslq	%edx, %rax
	leaq	unit_kindT2.9(%rip), %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %eax
	imull	%r8d, %eax
	leal	(%rcx,%rax), %edi
	movslq	%edi, %rax
	imulq	$1321528399, %rax, %rax
	shrq	$32, %rax
	movl	%eax, %ecx
	sarl	$2, %ecx
	movl	%edi, %eax
	sarl	$31, %eax
	subl	%eax, %ecx
	movl	%ecx, %eax
	addl	%eax, %eax
	addl	%ecx, %eax
	sall	$2, %eax
	addl	%ecx, %eax
	movl	%edi, %ecx
	subl	%eax, %ecx
	addl	$1, %edx
	jmp	.L11
.L10:
	movslq	%esi, %rax
	leaq	unit_kindG.8(%rip), %rdx
	movzbl	(%rax,%rdx), %eax
	movzbl	%al, %edx
	movslq	%ecx, %rax
	leaq	unit_kindG.8(%rip), %rcx
	movzbl	(%rax,%rcx), %eax
	movzbl	%al, %eax
	leal	(%rdx,%rax), %ecx
	movslq	%ecx, %rax
	imulq	$715827883, %rax, %rax
	shrq	$32, %rax
	movq	%rax, %rdx
	movl	%ecx, %eax
	sarl	$31, %eax
	subl	%eax, %edx
	movl	%edx, %eax
	addl	%eax, %eax
	addl	%edx, %eax
	addl	%eax, %eax
	movl	%ecx, %edx
	subl	%eax, %edx
	movl	%edx, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	silver_libraries__unit_kindH, .-silver_libraries__unit_kindH
	.align 2
	.globl	silver_libraries__Tbuffer_arrayBIP
	.type	silver_libraries__Tbuffer_arrayBIP, @function
silver_libraries__Tbuffer_arrayBIP:
.LFB3:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.size	silver_libraries__Tbuffer_arrayBIP, .-silver_libraries__Tbuffer_arrayBIP
	.align 2
	.globl	silver_libraries__Tlength_arrayBIP
	.type	silver_libraries__Tlength_arrayBIP, @function
silver_libraries__Tlength_arrayBIP:
.LFB4:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	silver_libraries__Tlength_arrayBIP, .-silver_libraries__Tlength_arrayBIP
	.align 2
	.globl	silver_libraries__source_setIP
	.type	silver_libraries__source_setIP, @function
silver_libraries__source_setIP:
.LFB5:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE5:
	.size	silver_libraries__source_setIP, .-silver_libraries__source_setIP
	.align 2
	.globl	silver_libraries__Tevidence_arrayBIP
	.type	silver_libraries__Tevidence_arrayBIP, @function
silver_libraries__Tevidence_arrayBIP:
.LFB6:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE6:
	.size	silver_libraries__Tevidence_arrayBIP, .-silver_libraries__Tevidence_arrayBIP
	.align 2
	.globl	silver_libraries__complete
	.type	silver_libraries__complete, @function
silver_libraries__complete:
.LFB7:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_libraries.ads"
	.loc 1 20 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -24(%rbp)
	.loc 1 21 7
	movl	$1, %ecx
.LBB4:
	.loc 1 21 15 discriminator 1
	movb	$0, -1(%rbp)
.L24:
	.loc 1 21 59 discriminator 2
	movzbl	-1(%rbp), %edx
	movq	-24(%rbp), %rax
	addq	$24576, %rdx
	movl	(%rax,%rdx,4), %eax
	.loc 1 21 7 discriminator 2
	testl	%eax, %eax
	jg	.L22
	.loc 1 21 7 is_stmt 0 discriminator 3
	movl	$0, %ecx
.LBE4:
	.loc 1 21 7 discriminator 6
	jmp	.L25
.L22:
.LBB5:
	.loc 1 21 7 discriminator 4
	cmpb	$5, -1(%rbp)
	je	.L25
	.loc 1 21 7 discriminator 5
	addb	$1, -1(%rbp)
	jmp	.L24
.L25:
.LBE5:
	.loc 1 21 7 discriminator 7
	movl	%ecx, %eax
	.loc 1 20 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE7:
	.size	silver_libraries__complete, .-silver_libraries__complete
	.section	.rodata
.LC12:
	.ascii	"silver_libraries.ads"
	.zero	1
	.text
	.align 2
	.globl	silver_libraries__same_bytes
	.type	silver_libraries__same_bytes, @function
silver_libraries__same_bytes:
.LFB8:
	.loc 1 22 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -40(%rbp)
	movq	%rsi, -48(%rbp)
	.loc 1 23 20
	movq	-48(%rbp), %rax
	leaq	98304(%rax), %rcx
	movq	-40(%rbp), %rax
	addq	$98304, %rax
	movl	$24, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcmp@PLT
	.loc 1 24 7
	testl	%eax, %eax
	jne	.L27
	.loc 1 24 17 discriminator 1
	movl	$1, %ebx
.LBB6:
	.loc 1 24 25 discriminator 2
	movb	$0, -17(%rbp)
.L34:
.LBB7:
	.loc 1 25 30
	movzbl	-17(%rbp), %edx
	movq	-40(%rbp), %rax
	addq	$24576, %rdx
	movl	(%rax,%rdx,4), %eax
	testl	%eax, %eax
	jle	.L28
	.loc 1 25 30 is_stmt 0 discriminator 1
	movzbl	-17(%rbp), %edx
	movq	-40(%rbp), %rax
	addq	$24576, %rdx
	movl	(%rax,%rdx,4), %eax
	cmpl	$16384, %eax
	jle	.L28
	.loc 1 25 30 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$25, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L28:
	.loc 1 25 13 is_stmt 1 discriminator 3
	movzbl	-17(%rbp), %edx
	movq	-40(%rbp), %rax
	addq	$24576, %rdx
	movl	(%rax,%rdx,4), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovns	%eax, %edx
	movslq	%edx, %rcx
	.loc 1 25 78 discriminator 3
	movzbl	-17(%rbp), %esi
	movq	-48(%rbp), %rdx
	addq	$24576, %rsi
	movl	(%rdx,%rsi,4), %edx
	testl	%edx, %edx
	jle	.L29
	.loc 1 25 78 is_stmt 0 discriminator 4
	movzbl	-17(%rbp), %esi
	movq	-48(%rbp), %rdx
	addq	$24576, %rsi
	movl	(%rdx,%rsi,4), %edx
	cmpl	$16384, %edx
	jle	.L29
	.loc 1 25 78 discriminator 5
	leaq	.LC12(%rip), %rax
	movl	$25, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L29:
	.loc 1 25 61 is_stmt 1 discriminator 6
	movzbl	-17(%rbp), %esi
	movq	-48(%rbp), %rdx
	addq	$24576, %rsi
	movl	(%rdx,%rsi,4), %edx
	.loc 1 24 17 discriminator 3
	testl	%eax, %eax
	jg	.L30
	.loc 1 25 54 discriminator 8
	testl	%edx, %edx
	jle	.L31
.L30:
	.loc 1 25 54 is_stmt 0 discriminator 10
	movl	$0, %esi
	testl	%eax, %eax
	cmovns	%eax, %esi
	movl	$0, %eax
	testl	%edx, %edx
	cmovns	%edx, %eax
	cmpl	%eax, %esi
	jne	.L32
	.loc 1 25 54 discriminator 11
	movzbl	-17(%rbp), %eax
	salq	$14, %rax
	movq	%rax, %rdx
	movq	-48(%rbp), %rax
	leaq	(%rdx,%rax), %rsi
	movzbl	-17(%rbp), %eax
	salq	$14, %rax
	movq	%rax, %rdx
	movq	-40(%rbp), %rax
	addq	%rdx, %rax
	movq	%rcx, %rdx
	movq	%rax, %rdi
	call	memcmp@PLT
	.loc 1 25 54 discriminator 12
	testl	%eax, %eax
	je	.L31
.L32:
	.loc 1 24 17 is_stmt 1 discriminator 4
	movl	$0, %ebx
	jmp	.L33
.L31:
.LBE7:
	.loc 1 24 17 is_stmt 0 discriminator 5
	cmpb	$5, -17(%rbp)
	je	.L33
	.loc 1 24 17 discriminator 6
	addb	$1, -17(%rbp)
	jmp	.L34
.L33:
.LBE6:
	.loc 1 24 7 is_stmt 1 discriminator 7
	testb	%bl, %bl
	je	.L27
	.loc 1 24 7 is_stmt 0 discriminator 8
	movl	$1, %eax
	jmp	.L35
.L27:
	.loc 1 24 7 discriminator 9
	movl	$0, %eax
.L35:
	.loc 1 22 4 is_stmt 1
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE8:
	.size	silver_libraries__same_bytes, .-silver_libraries__same_bytes
	.align 2
	.globl	silver_libraries__valid_directory
	.type	silver_libraries__valid_directory, @function
silver_libraries__valid_directory:
.LFB9:
	.loc 1 26 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r12
	pushq	%rbx
	subq	$16, %rsp
	.cfi_offset 12, -24
	.cfi_offset 3, -32
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -32(%rbp)
	movq	%rdx, -24(%rbp)
	.loc 1 26 4
	movq	-24(%rbp), %rax
	movl	(%rax), %ebx
	movq	-24(%rbp), %rax
	movl	4(%rax), %r12d
.LBB8:
	.loc 1 28 7
	cmpl	$1, %ebx
	jne	.L38
	.loc 1 27 51
	movq	-32(%rbp), %rdx
	movq	-24(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_platform__valid_path@PLT
	.loc 1 27 27 discriminator 1
	testb	%al, %al
	je	.L38
	.loc 1 28 33 discriminator 1
	movslq	%ebx, %rax
	leaq	4072(%rax), %rdx
	movslq	%r12d, %rax
	.loc 1 28 7 discriminator 1
	cmpq	%rax, %rdx
	jl	.L38
	.loc 1 28 7 is_stmt 0 discriminator 2
	movl	$1, %eax
	jmp	.L39
.L38:
	.loc 1 28 7 discriminator 3
	movl	$0, %eax
.L39:
.LBE8:
	.loc 1 26 4 is_stmt 1
	addq	$16, %rsp
	popq	%rbx
	popq	%r12
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE9:
	.size	silver_libraries__valid_directory, .-silver_libraries__valid_directory
	.align 2
	.type	silver_libraries__bound_to_compiler__B170s__L171s__B174s___finalizer.0, @function
silver_libraries__bound_to_compiler__B170s__L171s__B174s___finalizer.0:
.LFB11:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE11:
	.size	silver_libraries__bound_to_compiler__B170s__L171s__B174s___finalizer.0, .-silver_libraries__bound_to_compiler__B170s__L171s__B174s___finalizer.0
	.align 2
	.globl	silver_libraries__bound_to_compiler
	.type	silver_libraries__bound_to_compiler, @function
silver_libraries__bound_to_compiler:
.LFB10:
	.loc 1 38 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA10
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB0:
	subq	$72, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -104(%rbp)
	.loc 1 38 4
	leaq	16(%rbp), %rax
	.loc 1 38 4 is_stmt 0 discriminator 1
	movq	%rax, -72(%rbp)
	.loc 1 39 7 is_stmt 1
	movb	$1, -105(%rbp)
.LBB9:
	.loc 1 39 15 discriminator 1
	movb	$0, -49(%rbp)
.L55:
.LBB10:
	.loc 1 40 33
	movzbl	-49(%rbp), %edx
	movq	-104(%rbp), %rax
	addq	$24576, %rdx
	movl	(%rax,%rdx,4), %eax
	testl	%eax, %eax
	jle	.L44
	.loc 1 40 33 is_stmt 0 discriminator 1
	movzbl	-49(%rbp), %edx
	movq	-104(%rbp), %rax
	addq	$24576, %rdx
	movl	(%rax,%rdx,4), %eax
	cmpl	$16384, %eax
	jle	.L44
	.loc 1 40 33 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$40, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L44:
	.loc 1 40 16 is_stmt 1 discriminator 3
	movzbl	-49(%rbp), %edx
	movq	-104(%rbp), %rax
	addq	$24576, %rdx
	movl	(%rax,%rdx,4), %ebx
.LEHE0:
	movl	$0, %eax
	testl	%ebx, %ebx
	cmovns	%ebx, %eax
	movslq	%eax, %r12
	leaq	-96(%rbp), %rax
	movq	%rax, %rdi
.LEHB1:
	call	system__secondary_stack__ss_mark@PLT
.LBB11:
	.loc 1 40 62 discriminator 4
	movzbl	-49(%rbp), %eax
	movl	%eax, %edi
	call	silver_libraries__expected_source
.LEHE1:
	.loc 1 40 60 discriminator 5
	testl	%ebx, %ebx
	jg	.L45
	.loc 1 40 60 is_stmt 0 discriminator 7
	movq	%rdx, %rcx
	movl	4(%rcx), %esi
	movq	%rdx, %rcx
	movl	(%rcx), %ecx
	cmpl	%ecx, %esi
	jl	.L46
.L45:
	.loc 1 40 60 discriminator 9
	movl	$0, %ecx
	testl	%ebx, %ebx
	cmovns	%ebx, %ecx
	movslq	%ecx, %rcx
	movq	%rdx, %rsi
	movl	4(%rsi), %edi
	movq	%rdx, %rsi
	movl	(%rsi), %esi
	cmpl	%esi, %edi
	jl	.L47
	.loc 1 40 60 discriminator 10
	movq	%rdx, %rsi
	movl	4(%rsi), %esi
	movslq	%esi, %rdi
	movq	%rdx, %rsi
	movl	(%rsi), %esi
	movslq	%esi, %rsi
	subq	%rsi, %rdi
	leaq	1(%rdi), %rsi
	jmp	.L48
.L47:
	.loc 1 40 60 discriminator 11
	movl	$0, %esi
.L48:
	.loc 1 40 60 discriminator 12
	cmpq	%rcx, %rsi
	jne	.L49
	.loc 1 40 60 discriminator 13
	movq	%rax, %rcx
	movzbl	-49(%rbp), %eax
	salq	$14, %rax
	movq	%rax, %rdx
	movq	-104(%rbp), %rax
	addq	%rdx, %rax
	movq	%r12, %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcmp@PLT
	.loc 1 40 60 discriminator 14
	testl	%eax, %eax
	je	.L46
.L49:
	.loc 1 40 60 discriminator 15
	movl	$1, %r15d
	jmp	.L50
.L46:
	.loc 1 40 60 discriminator 16
	movl	$0, %r15d
.L50:
	.loc 1 39 0 is_stmt 1 discriminator 3
	movl	$1, %ebx
.L58:
	.loc 1 39 0 is_stmt 0 discriminator 4
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
.LEHB2:
	call	silver_libraries__bound_to_compiler__B170s__L171s__B174s___finalizer.0
.LEHE2:
	.loc 1 39 0 discriminator 5
	cmpl	$1, %ebx
	jne	.L51
	.loc 1 39 0 discriminator 7
	movl	$1, %eax
.L60:
	.loc 1 39 0 discriminator 8
	cmpl	$1, %eax
	jne	.L52
	.loc 1 39 0 discriminator 9
	nop
.LBE11:
	.loc 1 39 7 is_stmt 1 discriminator 10
	testb	%r15b, %r15b
	je	.L53
	.loc 1 39 7 is_stmt 0 discriminator 11
	movb	$0, -105(%rbp)
.LBE10:
.LBE9:
	.loc 1 39 7 discriminator 14
	jmp	.L56
.L53:
.LBB14:
	.loc 1 39 7 discriminator 12
	cmpb	$5, -49(%rbp)
	je	.L56
	.loc 1 39 7 discriminator 13
	addb	$1, -49(%rbp)
	jmp	.L55
.L56:
.LBE14:
	.loc 1 39 7 discriminator 15
	movzbl	-105(%rbp), %eax
	jmp	.L63
.L61:
	movq	%rax, %r14
	movl	$0, %ebx
.LBB15:
.LBB13:
.LBB12:
	.loc 1 39 7 discriminator 16
	jmp	.L58
.L51:
	movq	%r14, %r13
	jmp	.L59
.L62:
	movq	%rax, %r13
.L59:
	movl	$0, %eax
	jmp	.L60
.L52:
	movq	%r13, %rax
	movq	%rax, %rdi
.LEHB3:
	call	_Unwind_Resume@PLT
.L63:
.LBE12:
.LBE13:
.LBE15:
	.loc 1 38 4 is_stmt 1
	addq	$72, %rsp
.LEHE3:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE10:
	.section	.gcc_except_table,"a",@progbits
.LLSDA10:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE10-.LLSDACSB10
.LLSDACSB10:
	.uleb128 .LEHB0-.LFB10
	.uleb128 .LEHE0-.LEHB0
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB1-.LFB10
	.uleb128 .LEHE1-.LEHB1
	.uleb128 .L61-.LFB10
	.uleb128 0
	.uleb128 .LEHB2-.LFB10
	.uleb128 .LEHE2-.LEHB2
	.uleb128 .L62-.LFB10
	.uleb128 0
	.uleb128 .LEHB3-.LFB10
	.uleb128 .LEHE3-.LEHB3
	.uleb128 0
	.uleb128 0
.LLSDACSE10:
	.text
	.size	silver_libraries__bound_to_compiler, .-silver_libraries__bound_to_compiler
	.section	.rodata
.LC13:
	.ascii	"silver_libraries.adb"
	.zero	1
	.text
	.align 2
	.type	silver_libraries__file_name___wrapped_statements.1, @function
silver_libraries__file_name___wrapped_statements.1:
.LFB13:
	.file 2 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_libraries.adb"
	.loc 2 13 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	subq	$16, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	movq	%r10, %rax
	movq	%r10, -24(%rbp)
	.loc 2 14 12
	movzbl	(%rax), %edx
	cmpb	$5, %dl
	jbe	.L65
	.loc 2 14 12 is_stmt 0 discriminator 1
	leaq	.LC13(%rip), %rax
	movl	$14, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L65:
	.loc 2 14 12 discriminator 2
	movzbl	(%rax), %edx
	cmpb	$5, %dl
	jbe	.L66
	.loc 2 14 12 discriminator 3
	leaq	.LC13(%rip), %rax
	movl	$14, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L66:
	.loc 2 14 7 is_stmt 1 discriminator 4
	movzbl	(%rax), %eax
	cmpb	$4, %al
	je	.L67
	cmpb	$4, %al
	ja	.L68
	cmpb	$3, %al
	je	.L69
	cmpb	$3, %al
	ja	.L68
	cmpb	$2, %al
	je	.L70
	cmpb	$2, %al
	ja	.L68
	testb	%al, %al
	je	.L71
	cmpb	$1, %al
	je	.L72
	jmp	.L68
.L71:
	.loc 2 15 34
	movl	$4, %esi
	movl	$24, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 15 34 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$13, 4(%rax)
	movabsq	$7592913276874025331, %rcx
	movq	%rcx, 8(%rax)
	movabsq	$8314877664098344818, %rcx
	movq	%rcx, 13(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L73
.L72:
	.loc 2 16 35 is_stmt 1
	movl	$4, %esi
	movl	$24, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 16 35 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$13, 4(%rax)
	movabsq	$7592913276874025331, %rcx
	movq	%rcx, 8(%rax)
	movabsq	$7089898565453569906, %rcx
	movq	%rcx, 13(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L73
.L70:
	.loc 2 17 36 is_stmt 1
	movl	$4, %esi
	movl	$32, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 17 36 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$22, 4(%rax)
	movabsq	$8025258841101592947, %rsi
	movabsq	$7596551625258333301, %rdi
	movq	%rsi, 8(%rax)
	movq	%rdi, 16(%rax)
	movabsq	$8314877663896562028, %rcx
	movq	%rcx, 22(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L73
.L69:
	.loc 2 18 41 is_stmt 1
	movl	$4, %esi
	movl	$28, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 18 41 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$20, 4(%rax)
	movabsq	$7016452524570601843, %rsi
	movabsq	$8319395793567311730, %rdi
	movq	%rsi, 8(%rax)
	movq	%rdi, 16(%rax)
	movl	$1935958318, 24(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L73
.L67:
	.loc 2 19 42 is_stmt 1
	movl	$4, %esi
	movl	$28, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 19 42 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$20, 4(%rax)
	movabsq	$7016452524570601843, %rsi
	movabsq	$8319395793567311730, %rdi
	movq	%rsi, 8(%rax)
	movq	%rdi, 16(%rax)
	movl	$1650745646, 24(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L73
.L68:
	.loc 2 20 35 is_stmt 1
	movl	$4, %esi
	movl	$28, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 20 35 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$18, 4(%rax)
	movabsq	$8241431623215376755, %rsi
	movabsq	$7002645991202778741, %rdi
	movq	%rsi, 8(%rax)
	movq	%rdi, 16(%rax)
	movw	$29540, 24(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
.L73:
	.loc 2 13 4 is_stmt 1
	movq	%r12, %rax
	movq	%r13, %rdx
	addq	$16, %rsp
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE13:
	.size	silver_libraries__file_name___wrapped_statements.1, .-silver_libraries__file_name___wrapped_statements.1
	.section	.rodata
	.align 8
.LC14:
	.ascii	"failed postcondition from silver_libraries.ads:31"
	.align 8
.LC15:
	.ascii	"failed postcondition from silver_libraries.ads:32"
	.align 8
.LC16:
	.ascii	"failed postcondition from silver_libraries.ads:33"
	.align 8
.LC0:
	.long	1
	.long	49
	.text
	.align 2
	.globl	silver_libraries__file_name
	.type	silver_libraries__file_name, @function
silver_libraries__file_name:
.LFB12:
	.loc 2 13 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$264, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movb	%dil, -145(%rbp)
	.loc 2 13 4
	leaq	16(%rbp), %rax
	.loc 2 13 4 is_stmt 0 discriminator 1
	movq	%rax, -136(%rbp)
	movzbl	-145(%rbp), %eax
	movb	%al, -144(%rbp)
.LBB16:
	leaq	-144(%rbp), %rax
	movq	%rax, %r10
	call	silver_libraries__file_name___wrapped_statements.1
	.loc 2 13 4 discriminator 2
	movq	%rax, %r8
	movq	%rdx, %r9
	movq	%r9, %rax
	movl	(%rax), %ecx
	movq	%r9, %rax
	movl	4(%rax), %esi
	cmpl	%ecx, %esi
	.loc 2 13 4 discriminator 5
	cmpl	%ecx, %esi
	.loc 2 13 4 discriminator 8
	cmpl	%ecx, %esi
	.loc 2 13 4 discriminator 11
	cmpl	%ecx, %esi
	jl	.L81
	.loc 2 13 4 discriminator 12
	testl	%ecx, %ecx
	jg	.L81
	.loc 2 13 4 discriminator 13
	leaq	.LC13(%rip), %rax
	movl	$13, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L81:
.LBB17:
	.loc 1 31 19 is_stmt 1
	cmpl	$1, %ecx
	je	.L82
.LBB18:
	.loc 1 31 19 is_stmt 0 discriminator 1
	leaq	.LC14(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L82:
.LBE18:
	.loc 1 31 19 discriminator 2
	cmpl	%ecx, %esi
	jl	.L83
	.loc 1 32 46 is_stmt 1
	movl	%esi, %eax
	movl	%ecx, %edx
	subl	%edx, %eax
	addl	$1, %eax
	cmpl	$12, %eax
	jle	.L83
	.loc 1 32 46 is_stmt 0 discriminator 1
	cmpl	%ecx, %esi
	jl	.L84
	.loc 1 32 46 discriminator 2
	movl	%esi, %eax
	movl	%ecx, %edx
	subl	%edx, %eax
	addl	$1, %eax
	cmpl	$22, %eax
	jle	.L84
.L83:
.LBB19:
	.loc 1 31 19 is_stmt 1 discriminator 3
	leaq	.LC15(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L84:
.LBE19:
	.loc 1 33 23
	movl	$1, %r12d
	movq	%r8, %rax
	movq	%rax, -304(%rbp)
	movl	%ecx, -120(%rbp)
	movl	%esi, -116(%rbp)
	leaq	-120(%rbp), %rax
	movq	%rax, -296(%rbp)
	movq	-296(%rbp), %rax
	movl	(%rax), %edi
	movq	%r8, %rax
	movq	%rax, -288(%rbp)
	movl	%ecx, -112(%rbp)
	movl	%esi, -108(%rbp)
	leaq	-112(%rbp), %rax
	movq	%rax, -280(%rbp)
	movq	-280(%rbp), %rax
	movl	4(%rax), %ebx
	cmpl	%ebx, %edi
	jg	.L85
.L90:
.LBB20:
.LBB21:
	.loc 1 33 23 is_stmt 0 discriminator 2
	movq	%r8, %rax
	movq	%rax, -272(%rbp)
	movl	%ecx, -104(%rbp)
	movl	%esi, -100(%rbp)
	leaq	-104(%rbp), %rax
	movq	%rax, -264(%rbp)
	movq	-264(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edi
	jl	.L86
	.loc 1 33 23 discriminator 3
	movq	%r8, %rax
	movq	%rax, -256(%rbp)
	movl	%ecx, -96(%rbp)
	movl	%esi, -92(%rbp)
	leaq	-96(%rbp), %rax
	movq	%rax, -248(%rbp)
	movq	-248(%rbp), %rax
	movl	4(%rax), %eax
	cmpl	%eax, %edi
	jle	.L87
.L86:
	.loc 1 33 23 discriminator 4
	leaq	.LC12(%rip), %rax
	movl	$33, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L87:
	.loc 1 33 31 is_stmt 1 discriminator 5
	movq	%r8, %rax
	movq	%rax, -240(%rbp)
	movl	%ecx, -88(%rbp)
	movl	%esi, -84(%rbp)
	leaq	-88(%rbp), %rax
	movq	%rax, -232(%rbp)
	movq	-240(%rbp), %r11
	movq	%r8, %rax
	movq	%rax, -224(%rbp)
	movl	%ecx, -80(%rbp)
	movl	%esi, -76(%rbp)
	leaq	-80(%rbp), %rax
	movq	%rax, -216(%rbp)
	movq	-216(%rbp), %rax
	movl	(%rax), %eax
	movslq	%eax, %rdx
	movslq	%edi, %r10
	movq	%r10, %rax
	subq	%rdx, %rax
	addq	%r11, %rax
	movq	%rax, -56(%rbp)
	.loc 1 33 64 discriminator 5
	movq	%r8, %rax
	movq	%rax, -208(%rbp)
	movl	%ecx, -72(%rbp)
	movl	%esi, -68(%rbp)
	leaq	-72(%rbp), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %r11
	movq	%r8, %rax
	movq	%rax, -192(%rbp)
	movl	%ecx, -64(%rbp)
	movl	%esi, -60(%rbp)
	leaq	-64(%rbp), %rax
	movq	%rax, -184(%rbp)
	movq	-184(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%r10, %rdx
	subq	%rax, %rdx
	movzbl	(%r11,%rdx), %eax
	.loc 1 33 23 discriminator 6
	testb	%al, %al
	jne	.L88
	.loc 1 33 23 is_stmt 0 discriminator 7
	movl	$0, %r12d
	jmp	.L85
.L88:
.LBE21:
	.loc 1 33 23 discriminator 8
	cmpl	%ebx, %edi
	je	.L85
	.loc 1 33 23 discriminator 9
	addl	$1, %edi
	jmp	.L90
.L85:
.LBE20:
	.loc 1 33 23 discriminator 10
	movl	%r12d, %eax
	xorl	$1, %eax
	.loc 1 31 19 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L91
.LBB22:
	.loc 1 31 19 is_stmt 0 discriminator 5
	leaq	.LC16(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L91:
.LBE22:
.LBE17:
	.loc 2 13 4 is_stmt 1 discriminator 14
	movq	%r8, %rax
	movq	%r9, %rdx
.LBE16:
	.loc 2 13 4 is_stmt 0
	addq	$264, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE12:
	.size	silver_libraries__file_name, .-silver_libraries__file_name
	.align 2
	.type	silver_libraries__expected_source___wrapped_statements.2, @function
silver_libraries__expected_source___wrapped_statements.2:
.LFB15:
	.loc 2 22 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%r10, %rax
	movq	%r10, -40(%rbp)
	.loc 2 26 12
	movzbl	(%rax), %edx
	cmpb	$5, %dl
	jbe	.L94
	.loc 2 26 12 is_stmt 0 discriminator 1
	leaq	.LC13(%rip), %rax
	movl	$26, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L94:
	.loc 2 26 7 is_stmt 1 discriminator 2
	movzbl	(%rax), %eax
	cmpb	$4, %al
	je	.L95
	cmpb	$4, %al
	ja	.L96
	cmpb	$3, %al
	je	.L97
	cmpb	$3, %al
	ja	.L96
	cmpb	$2, %al
	je	.L98
	cmpb	$2, %al
	ja	.L96
	testb	%al, %al
	je	.L99
	cmpb	$1, %al
	je	.L100
	jmp	.L96
.L99:
.LBB23:
	.loc 2 28 13
	movl	$4, %esi
	movl	$2232, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rbx
	.loc 2 28 13 is_stmt 0 discriminator 1
	movq	%rbx, %rax
	movl	$1, (%rax)
	movl	$2222, 4(%rax)
	addq	$8, %rax
	leaq	silver_library_sources__io_specification(%rip), %rcx
	movl	$2222, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	movq	%rbx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rbx, %rax
	movq	%rax, %r13
	jmp	.L101
.L100:
.LBE23:
.LBB24:
	.loc 2 30 13 is_stmt 1
	movl	$4, %esi
	movl	$3368, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rbx
	.loc 2 30 13 is_stmt 0 discriminator 1
	movq	%rbx, %rax
	movl	$1, (%rax)
	movl	$3358, 4(%rax)
	addq	$8, %rax
	leaq	silver_library_sources__io_implementation(%rip), %rcx
	movl	$3358, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	movq	%rbx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rbx, %rax
	movq	%rax, %r13
	jmp	.L101
.L98:
.LBE24:
.LBB25:
	.loc 2 32 13 is_stmt 1
	movl	$4, %esi
	movl	$1540, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rbx
	.loc 2 32 13 is_stmt 0 discriminator 1
	movq	%rbx, %rax
	movl	$1, (%rax)
	movl	$1532, 4(%rax)
	addq	$8, %rax
	leaq	silver_library_sources__imported_interface(%rip), %rcx
	movl	$1532, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	movq	%rbx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rbx, %rax
	movq	%rax, %r13
	jmp	.L101
.L97:
.LBE25:
.LBB26:
	.loc 2 34 13 is_stmt 1
	movl	$4, %esi
	movl	$1140, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rbx
	.loc 2 34 13 is_stmt 0 discriminator 1
	movq	%rbx, %rax
	movl	$1, (%rax)
	movl	$1129, 4(%rax)
	addq	$8, %rax
	leaq	silver_library_sources__arguments_specification(%rip), %rcx
	movl	$1129, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	movq	%rbx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rbx, %rax
	movq	%rax, %r13
	jmp	.L101
.L95:
.LBE26:
.LBB27:
	.loc 2 36 13 is_stmt 1
	movl	$4, %esi
	movl	$1348, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rbx
	.loc 2 36 13 is_stmt 0 discriminator 1
	movq	%rbx, %rax
	movl	$1, (%rax)
	movl	$1339, 4(%rax)
	addq	$8, %rax
	leaq	silver_library_sources__arguments_implementation(%rip), %rcx
	movl	$1339, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	movq	%rbx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rbx, %rax
	movq	%rax, %r13
	jmp	.L101
.L96:
.LBE27:
.LBB28:
	.loc 2 38 13 is_stmt 1
	movl	$4, %esi
	movl	$1020, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rbx
	.loc 2 38 13 is_stmt 0 discriminator 1
	movq	%rbx, %rax
	movl	$1, (%rax)
	movl	$1010, 4(%rax)
	addq	$8, %rax
	leaq	silver_library_sources__runtime_interface(%rip), %rcx
	movl	$1010, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	movq	%rbx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rbx, %rax
	movq	%rax, %r13
.L101:
.LBE28:
	.loc 2 40 8 is_stmt 1
	movq	%r12, %rax
	movq	%r13, %rdx
	addq	$24, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE15:
	.size	silver_libraries__expected_source___wrapped_statements.2, .-silver_libraries__expected_source___wrapped_statements.2
	.section	.rodata
	.align 8
.LC17:
	.ascii	"failed postcondition from silver_libraries.ads:36"
	.align 8
.LC18:
	.ascii	"failed postcondition from silver_libraries.ads:37"
	.text
	.align 2
	.globl	silver_libraries__expected_source
	.type	silver_libraries__expected_source, @function
silver_libraries__expected_source:
.LFB14:
	.loc 2 22 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movb	%dil, -65(%rbp)
	.loc 2 22 4
	leaq	16(%rbp), %rax
	.loc 2 22 4 is_stmt 0 discriminator 1
	movq	%rax, -56(%rbp)
	movzbl	-65(%rbp), %eax
	movb	%al, -64(%rbp)
.LBB29:
	leaq	-64(%rbp), %rax
	movq	%rax, %r10
	call	silver_libraries__expected_source___wrapped_statements.2
	.loc 2 22 4 discriminator 2
	movq	%rax, %rcx
	movq	%rdx, %rbx
	movq	%rbx, %rax
	movl	(%rax), %eax
	movq	%rbx, %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	.loc 2 22 4 discriminator 5
	cmpl	%eax, %edx
	.loc 2 22 4 discriminator 8
	cmpl	%eax, %edx
	.loc 2 22 4 discriminator 11
	cmpl	%eax, %edx
	jl	.L109
	.loc 2 22 4 discriminator 12
	testl	%eax, %eax
	jg	.L109
	.loc 2 22 4 discriminator 13
	leaq	.LC13(%rip), %rax
	movl	$22, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L109:
	.loc 1 36 19 is_stmt 1
	cmpl	$1, %eax
	je	.L110
.LBB30:
	.loc 1 36 19 is_stmt 0 discriminator 1
	leaq	.LC17(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L110:
.LBE30:
	.loc 1 36 19 discriminator 2
	cmpl	%eax, %edx
	jl	.L111
	.loc 1 37 52 is_stmt 1
	movl	%edx, %esi
	movl	%eax, %edi
	subl	%edi, %esi
	addl	$1, %esi
	testl	%esi, %esi
	jle	.L111
	.loc 1 37 52 is_stmt 0 discriminator 1
	cmpl	%eax, %edx
	jl	.L112
	.loc 1 37 52 discriminator 2
	movl	%edx, %esi
	movl	%eax, %edx
	movl	%esi, %eax
	subl	%edx, %eax
	addl	$1, %eax
	cmpl	$16384, %eax
	jle	.L112
.L111:
.LBB31:
	.loc 1 36 19 is_stmt 1 discriminator 3
	leaq	.LC18(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L112:
.LBE31:
	.loc 2 22 4 discriminator 14
	movq	%rcx, %rax
	movq	%rbx, %rdx
.LBE29:
	.loc 2 22 4 is_stmt 0
	addq	$40, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE14:
	.size	silver_libraries__expected_source, .-silver_libraries__expected_source
	.section	.rodata
	.align 8
.LC19:
	.ascii	"failed precondition from silver_libraries.ads:69"
	.align 8
.LC20:
	.ascii	"failed precondition from silver_libraries.ads:70"
.LC21:
	.ascii	"silver_io.spark"
.LC22:
	.ascii	"silver_output_libc.spark"
.LC23:
	.ascii	"silver_arguments.spark"
.LC24:
	.ascii	"silver_runtime.spark"
.LC25:
	.ascii	"/obj/gnatprove/"
	.align 8
.LC1:
	.long	1
	.long	48
	.align 8
.LC2:
	.zero	8
	.align 8
.LC3:
	.long	1
	.long	15
	.align 8
.LC4:
	.long	1
	.long	24
	.align 8
.LC5:
	.long	1
	.long	22
	.align 8
.LC6:
	.long	1
	.long	20
	.align 8
.LC7:
	.long	1
	.long	262144
	.text
	.align 2
	.globl	silver_libraries__check_proof_evidence
	.type	silver_libraries__check_proof_evidence, @function
silver_libraries__check_proof_evidence:
.LFB16:
	.loc 2 42 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$262392, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -262320(%rbp)
	movq	%rdx, -262312(%rbp)
	.loc 2 42 4
	movq	-262312(%rbp), %rax
	movl	(%rax), %edi
	movl	%edi, -262328(%rbp)
	movq	-262312(%rbp), %rax
	movl	4(%rax), %ebx
	cmpl	%edi, %ebx
	jl	.L115
	.loc 2 42 4 is_stmt 0 discriminator 1
	movl	%ebx, %eax
	subl	%edi, %eax
	addl	$1, %eax
	movl	%eax, -262324(%rbp)
	jmp	.L116
.L115:
	.loc 2 42 4 discriminator 2
	movl	$0, -262324(%rbp)
.L116:
.LBB32:
	.loc 2 42 4 discriminator 3
	movl	-262328(%rbp), %eax
	cmpl	%eax, %ebx
	.loc 2 42 4 discriminator 6
	cmpl	%eax, %ebx
	.loc 2 42 4 discriminator 9
	cmpl	%eax, %ebx
	.loc 1 69 18 is_stmt 1
	movq	-262320(%rbp), %rdx
	movq	-262312(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_libraries__valid_directory
	.loc 1 69 18 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L123
.LBB33:
	.loc 1 69 18 discriminator 2
	leaq	.LC19(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L123:
.LBE33:
	.loc 1 70 39 is_stmt 1
	movslq	-262328(%rbp), %rax
	leaq	4050(%rax), %rdx
	movslq	%ebx, %rax
	.loc 1 69 18 discriminator 3
	cmpq	%rax, %rdx
	jge	.L124
.LBB34:
	.loc 1 69 18 is_stmt 0 discriminator 4
	leaq	.LC20(%rip), %rax
	movq	%rax, -262432(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -262424(%rbp)
	movq	-262432(%rbp), %rcx
	movq	-262424(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L124:
.LBE34:
	.loc 2 47 15 is_stmt 1
	movb	$0, -145(%rbp)
.LBB35:
	.loc 2 51 11 discriminator 1
	movb	$0, -49(%rbp)
.L146:
.LBB36:
	.loc 2 57 10
	movq	%rsp, %rax
	movq	%rax, %rbx
	.loc 2 59 16
	movl	$0, %r12d
	leaq	.LC2(%rip), %r13
	cmpb	$2, -49(%rbp)
	je	.L125
	cmpb	$2, -49(%rbp)
	ja	.L126
	cmpb	$0, -49(%rbp)
	je	.L127
	cmpb	$1, -49(%rbp)
	je	.L128
	jmp	.L126
.L127:
	.loc 2 60 62
	leaq	.LC21(%rip), %r12
	leaq	.LC3(%rip), %r13
	.loc 2 59 16 discriminator 1
	jmp	.L129
.L128:
	.loc 2 61 68
	leaq	.LC22(%rip), %r12
	leaq	.LC4(%rip), %r13
	.loc 2 59 16 discriminator 2
	jmp	.L129
.L125:
	.loc 2 62 64
	leaq	.LC23(%rip), %r12
	leaq	.LC5(%rip), %r13
	.loc 2 59 16 discriminator 3
	jmp	.L129
.L126:
	.loc 2 63 67
	leaq	.LC24(%rip), %r12
	leaq	.LC6(%rip), %r13
	.loc 2 59 16 discriminator 4
	nop
.L129:
	.loc 2 58 69
	movl	-262324(%rbp), %eax
	leal	15(%rax), %ecx
	movq	%r13, %rax
	movl	4(%rax), %edx
	movq	%r13, %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L130
	.loc 2 58 69 is_stmt 0 discriminator 1
	movq	%r13, %rax
	movl	4(%rax), %edx
	movq	%r13, %rax
	movl	(%rax), %eax
	subl	%eax, %edx
	leal	1(%rdx), %eax
	jmp	.L131
.L130:
	.loc 2 58 69 discriminator 2
	movl	$0, %eax
.L131:
	.loc 2 58 69 discriminator 3
	addl	%eax, %ecx
	cmpl	$0, -262324(%rbp)
	je	.L132
	.loc 2 58 69 discriminator 4
	movl	-262328(%rbp), %eax
	movl	%eax, -56(%rbp)
	jmp	.L133
.L132:
	.loc 2 58 69 discriminator 5
	movl	$1, -56(%rbp)
.L133:
	.loc 2 58 69 discriminator 6
	leal	-1(%rcx), %edx
	movl	$0, %esi
	movl	-56(%rbp), %eax
	addl	%edx, %eax
	jno	.L134
	movl	$1, %esi
.L134:
	.loc 2 58 69 discriminator 7
	movl	%esi, %eax
	testl	%eax, %eax
	je	.L136
	.loc 2 58 69 discriminator 8
	leaq	.LC13(%rip), %rax
	movl	$58, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L136:
	.loc 2 58 69 discriminator 10
	leal	-1(%rcx), %edx
	movl	-56(%rbp), %eax
	addl	%edx, %eax
	.loc 2 58 69 discriminator 11
	movl	%eax, -60(%rbp)
	.loc 2 58 69 discriminator 12
	movl	-56(%rbp), %eax
	cltq
	movq	%rax, -72(%rbp)
	movl	-60(%rbp), %eax
	cltq
	movq	%rax, -80(%rbp)
	testl	%ecx, %ecx
	jle	.L139
	.loc 2 58 69 discriminator 13
	cmpl	$0, -56(%rbp)
	jg	.L139
	.loc 2 58 69 discriminator 14
	leaq	.LC13(%rip), %rax
	movl	$58, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L139:
	.loc 2 58 69 discriminator 15
	movl	-60(%rbp), %eax
	movslq	%eax, %rdx
	movl	-56(%rbp), %eax
	cltq
	subq	%rax, %rdx
	addq	$1, %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %ecx
	movl	$0, %edx
	divq	%rcx
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	movq	%rax, -88(%rbp)
.LBB37:
	.loc 2 58 69 discriminator 16
	leaq	.LC25(%rip), %rax
	movq	%rax, -262416(%rbp)
	leaq	.LC3(%rip), %rax
	movq	%rax, -262408(%rbp)
	movq	-88(%rbp), %rax
	movq	%rax, -262400(%rbp)
	movl	-56(%rbp), %eax
	movl	%eax, -144(%rbp)
	movl	-60(%rbp), %eax
	movl	%eax, -140(%rbp)
	leaq	-144(%rbp), %rax
	movq	%rax, -262392(%rbp)
	movq	-262320(%rbp), %rax
	movq	-262312(%rbp), %rdx
	movq	-262400(%rbp), %r9
	movq	-262392(%rbp), %r10
	movq	%r9, %rdi
	movq	%r10, %rsi
	pushq	%r13
	pushq	%r12
	movq	-262416(%rbp), %r8
	movq	-262408(%rbp), %r9
	movq	%rdx, %rcx
	movq	%rax, %rdx
	call	system__concat_3__str_concat_3@PLT
	addq	$16, %rsp
.LBE37:
	.loc 2 58 13 is_stmt 1 discriminator 17
	movl	-56(%rbp), %eax
	cltq
	movq	%rax, -96(%rbp)
	movl	-60(%rbp), %eax
	cltq
	movq	%rax, -104(%rbp)
	movq	-88(%rbp), %rax
	movq	%rax, -112(%rbp)
.LBB38:
	.loc 2 66 33
	leaq	-262304(%rbp), %rax
	movq	%rax, -262384(%rbp)
	leaq	.LC7(%rip), %rax
	movq	%rax, -262376(%rbp)
	movq	-88(%rbp), %rax
	movq	%rax, -262368(%rbp)
	movl	-56(%rbp), %eax
	movl	%eax, -136(%rbp)
	movl	-60(%rbp), %eax
	movl	%eax, -132(%rbp)
	leaq	-136(%rbp), %rax
	movq	%rax, -262360(%rbp)
	movq	-262368(%rbp), %rsi
	movq	-262360(%rbp), %rdi
	movq	%rsi, %rax
	movq	%rdi, %rsi
	movq	-262384(%rbp), %rdx
	movq	-262376(%rbp), %rcx
	movq	%rax, %rdi
	call	silver_report_reader__read_report@PLT
	.loc 2 66 33 is_stmt 0 discriminator 1
	movl	%eax, -116(%rbp)
	movq	%rax, %rdx
	shrq	$32, %rdx
	andb	$-1, %dh
	movb	%dl, -117(%rbp)
	shrq	$40, %rax
	andb	$-1, %ah
	movb	%al, -118(%rbp)
.LBE38:
	.loc 2 67 16 is_stmt 1
	movzbl	-118(%rbp), %eax
	xorl	$1, %eax
	.loc 2 67 13
	testb	%al, %al
	jne	.L140
	.loc 2 67 33 discriminator 1
	cmpb	$0, -117(%rbp)
	jne	.L140
	.loc 2 74 85
	movl	-116(%rbp), %eax
	.loc 2 74 82
	testl	%eax, %eax
	jle	.L141
	.loc 2 74 82 is_stmt 0 discriminator 1
	cmpl	$262144, %eax
	jle	.L141
	.loc 2 74 82 discriminator 2
	leaq	.LC13(%rip), %rax
	movl	$74, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L141:
	.loc 2 74 47 is_stmt 1 discriminator 3
	leaq	-262304(%rbp), %rdx
	movq	%rdx, -262352(%rbp)
	movl	$1, -128(%rbp)
	movl	%eax, -124(%rbp)
	leaq	-128(%rbp), %rax
	movq	%rax, -262344(%rbp)
	movzbl	-49(%rbp), %eax
	movq	-262352(%rbp), %rdx
	movq	-262344(%rbp), %rcx
	movq	%rdx, %rsi
	movl	%eax, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver_library_reports__complete_runtime_proof@PLT
	.loc 2 74 47 is_stmt 0 discriminator 4
	movb	%al, -119(%rbp)
	.loc 2 78 16 is_stmt 1
	movzbl	-119(%rbp), %eax
	xorl	$1, %eax
	.loc 2 78 13
	testb	%al, %al
	jne	.L150
	.loc 2 81 13
	movq	%rbx, %rsp
.LBE36:
	.loc 2 51 11 discriminator 2
	cmpb	$3, -49(%rbp)
	jne	.L143
	jmp	.L149
.L150:
.LBB39:
	.loc 2 79 16
	nop
.L140:
	.loc 2 81 13 discriminator 1
	movq	%rbx, %rsp
	jmp	.L147
.L143:
.LBE39:
	.loc 2 51 11 discriminator 3
	addb	$1, -49(%rbp)
	.loc 2 82 15
	jmp	.L146
.L149:
.LBE35:
	.loc 2 85 15
	movb	$1, -145(%rbp)
	.loc 2 86 8
	nop
.L147:
.LBE32:
	.loc 2 86 8 is_stmt 0 discriminator 2
	movzbl	-145(%rbp), %eax
	.loc 2 86 8
	leaq	-40(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE16:
	.size	silver_libraries__check_proof_evidence, .-silver_libraries__check_proof_evidence
	.align 2
	.type	silver_libraries__same_sources__L_3__B144b___finalizer.3, @function
silver_libraries__same_sources__L_3__B144b___finalizer.3:
.LFB18:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE18:
	.size	silver_libraries__same_sources__L_3__B144b___finalizer.3, .-silver_libraries__same_sources__L_3__B144b___finalizer.3
	.section	.rodata
	.align 8
.LC26:
	.ascii	"failed precondition from silver_libraries.ads:81"
.LC27:
	.ascii	"/"
	.align 8
.LC8:
	.long	1
	.long	1
	.align 8
.LC9:
	.long	1
	.long	16384
	.text
	.align 2
	.globl	silver_libraries__same_sources
	.type	silver_libraries__same_sources, @function
silver_libraries__same_sources:
.LFB17:
	.loc 2 88 4 is_stmt 1
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA17
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB4:
	subq	$16600, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -16544(%rbp)
	movq	%rbx, -16536(%rbp)
	movq	%rdx, -16552(%rbp)
	.loc 2 88 4
	leaq	16(%rbp), %rax
	.loc 2 88 4 is_stmt 0 discriminator 1
	movq	%rax, -120(%rbp)
	movq	-16536(%rbp), %rax
	movl	(%rax), %ebx
	movl	%ebx, -16560(%rbp)
	movq	-16536(%rbp), %rax
	movl	4(%rax), %eax
	cmpl	%ebx, %eax
	jl	.L154
	.loc 2 88 4 discriminator 2
	movl	%eax, %edx
	subl	%ebx, %edx
	leal	1(%rdx), %ecx
	movl	%ecx, -16556(%rbp)
	jmp	.L155
.L154:
	.loc 2 88 4 discriminator 3
	movl	$0, -16556(%rbp)
.L155:
.LBB40:
	.loc 2 88 4 discriminator 4
	movl	-16560(%rbp), %edi
	cmpl	%edi, %eax
	.loc 2 88 4 discriminator 7
	cmpl	%edi, %eax
	.loc 2 88 4 discriminator 10
	cmpl	%edi, %eax
	.loc 1 81 18 is_stmt 1
	movq	-16544(%rbp), %rdx
	movq	-16536(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_libraries__valid_directory
	.loc 1 81 18 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L162
.LBB41:
	.loc 1 81 18 discriminator 2
	leaq	.LC26(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L162:
.LBE41:
	.loc 1 81 55 is_stmt 1 discriminator 3
	movq	-16552(%rbp), %rax
	movq	%rax, %rdi
	call	silver_libraries__complete
	.loc 1 81 55 is_stmt 0 discriminator 4
	xorl	$1, %eax
	.loc 1 81 18 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L163
.LBB42:
	.loc 1 81 18 is_stmt 0 discriminator 5
	leaq	.LC26(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.LEHE4:
.L163:
.LBE42:
.LBB43:
	.loc 2 97 11 is_stmt 1 discriminator 1
	movb	$0, -54(%rbp)
.L180:
	leaq	-144(%rbp), %rax
	movq	%rax, %rdi
.LEHB5:
	call	system__secondary_stack__ss_mark@PLT
.LBB44:
.LBB45:
	.loc 2 103 39
	movzbl	-54(%rbp), %eax
	movl	%eax, %edi
	call	silver_libraries__file_name
	.loc 2 103 39 is_stmt 0 discriminator 1
	movq	%rax, %r12
	movq	%rdx, %r13
	.loc 2 103 37 is_stmt 1 discriminator 1
	movl	-16556(%rbp), %eax
	leal	1(%rax), %ecx
	movq	%r13, %rax
	movl	4(%rax), %edx
	movq	%r13, %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L164
	.loc 2 103 37 is_stmt 0 discriminator 2
	movq	%r13, %rax
	movl	4(%rax), %edx
	movq	%r13, %rax
	movl	(%rax), %eax
	subl	%eax, %edx
	leal	1(%rdx), %eax
	jmp	.L165
.L164:
	.loc 2 103 37 discriminator 3
	movl	$0, %eax
.L165:
	.loc 2 103 37 discriminator 4
	addl	%ecx, %eax
	cmpl	$0, -16556(%rbp)
	je	.L166
	.loc 2 103 37 discriminator 5
	movl	-16560(%rbp), %ecx
	movl	%ecx, -60(%rbp)
	jmp	.L167
.L166:
	.loc 2 103 37 discriminator 6
	movl	$1, -60(%rbp)
.L167:
	.loc 2 103 37 discriminator 7
	leal	-1(%rax), %edx
	movl	-60(%rbp), %eax
	addl	%edx, %eax
	movl	%eax, -64(%rbp)
	movl	-60(%rbp), %eax
	cltq
	movq	%rax, -72(%rbp)
	movl	-64(%rbp), %eax
	cltq
	movq	%rax, -80(%rbp)
	movl	-64(%rbp), %eax
	movslq	%eax, %rdx
	movl	-60(%rbp), %eax
	cltq
	subq	%rax, %rdx
	leaq	1(%rdx), %rax
	movl	$1, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_allocate@PLT
	.loc 2 103 37 discriminator 8
	movq	%rax, %rbx
	movq	%rbx, -88(%rbp)
.LBB46:
	leaq	.LC27(%rip), %rax
	movq	%rax, -16624(%rbp)
	leaq	.LC8(%rip), %rax
	movq	%rax, -16616(%rbp)
	movq	%rbx, -16608(%rbp)
	movl	-60(%rbp), %eax
	movl	%eax, -104(%rbp)
	movl	-64(%rbp), %eax
	movl	%eax, -100(%rbp)
	leaq	-104(%rbp), %rax
	movq	%rax, -16600(%rbp)
	movq	-16544(%rbp), %rax
	movq	-16536(%rbp), %rdx
	movq	-16608(%rbp), %r9
	movq	-16600(%rbp), %r10
	movq	%r9, %rdi
	movq	%r10, %rsi
	pushq	%r13
	pushq	%r12
	movq	-16624(%rbp), %r8
	movq	-16616(%rbp), %r9
	movq	%rdx, %rcx
	movq	%rax, %rdx
	.cfi_escape 0x2e,0x10
	call	system__concat_3__str_concat_3@PLT
	addq	$16, %rsp
.LBE46:
.LBB47:
	.loc 2 103 10 is_stmt 1 discriminator 9
	leaq	-16528(%rbp), %rax
	movq	%rax, -16592(%rbp)
	leaq	.LC9(%rip), %rax
	movq	%rax, -16584(%rbp)
	movq	%rbx, -16576(%rbp)
	movl	-60(%rbp), %eax
	movl	%eax, -96(%rbp)
	movl	-64(%rbp), %eax
	movl	%eax, -92(%rbp)
	leaq	-96(%rbp), %rax
	movq	%rax, -16568(%rbp)
	movq	-16576(%rbp), %rbx
	movq	-16568(%rbp), %rsi
	movq	%rbx, %rax
	movq	-16592(%rbp), %rdx
	movq	-16584(%rbp), %rcx
	movq	%rax, %rdi
	.cfi_escape 0x2e,0
	call	silver_platform__read_file@PLT
.LEHE5:
	.loc 2 103 10 is_stmt 0 discriminator 10
	movl	%eax, -52(%rbp)
	movq	%rax, %rdx
	shrq	$32, %rdx
	andb	$-1, %dh
	movb	%dl, -53(%rbp)
	shrq	$40, %rax
	andb	$-1, %ah
	movb	%al, -105(%rbp)
.LBE47:
	.loc 2 103 0 is_stmt 1 discriminator 11
	movl	$1, %ebx
.L184:
	.loc 2 103 0 is_stmt 0 discriminator 12
	leaq	-144(%rbp), %rax
	movq	%rax, %r10
.LEHB6:
	call	silver_libraries__same_sources__L_3__B144b___finalizer.3
.LEHE6:
	.loc 2 103 0 discriminator 13
	cmpl	$1, %ebx
	jne	.L168
	.loc 2 103 0 discriminator 15
	movl	$1, %eax
.L186:
	.loc 2 103 0 discriminator 16
	cmpl	$1, %eax
	jne	.L169
	.loc 2 103 0 discriminator 17
	nop
.LBE45:
	.loc 2 104 13 is_stmt 1
	movzbl	-105(%rbp), %eax
	xorl	$1, %eax
	.loc 2 104 10
	testb	%al, %al
	jne	.L170
	.loc 2 104 25 discriminator 1
	cmpb	$0, -53(%rbp)
	jne	.L170
	.loc 2 104 55 discriminator 2
	movzbl	-54(%rbp), %edx
	movq	-16552(%rbp), %rax
	addq	$24576, %rdx
.LEHB7:
	movl	(%rax,%rdx,4), %eax
	.loc 2 104 42 discriminator 3
	cmpl	%eax, -52(%rbp)
	jne	.L170
	.loc 2 105 35
	movl	-52(%rbp), %ecx
	.loc 2 105 32
	testl	%ecx, %ecx
	jle	.L171
	.loc 2 105 32 is_stmt 0 discriminator 1
	cmpl	$16384, %ecx
	jle	.L171
	.loc 2 105 32 discriminator 2
	leaq	.LC13(%rip), %rax
	movl	$105, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L171:
	.loc 2 105 20 is_stmt 1 discriminator 3
	movl	$0, %eax
	testl	%ecx, %ecx
	cmovns	%ecx, %eax
	movslq	%eax, %rsi
	.loc 2 105 69 discriminator 3
	movzbl	-54(%rbp), %eax
	movq	-16552(%rbp), %rdx
	addq	$24576, %rax
	movl	(%rdx,%rax,4), %eax
	.loc 2 105 69 is_stmt 0 discriminator 4
	testl	%eax, %eax
	jle	.L172
	.loc 2 105 69 discriminator 5
	movzbl	-54(%rbp), %eax
	movq	-16552(%rbp), %rdx
	addq	$24576, %rax
	movl	(%rdx,%rax,4), %eax
	.loc 2 105 69 discriminator 6
	cmpl	$16384, %eax
	jle	.L172
	.loc 2 105 69 discriminator 7
	leaq	.LC13(%rip), %rax
	movl	$105, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L172:
	.loc 2 105 52 is_stmt 1 discriminator 8
	movzbl	-54(%rbp), %eax
	movq	-16552(%rbp), %rdx
	addq	$24576, %rax
	movl	(%rdx,%rax,4), %eax
	.loc 2 105 41 discriminator 9
	testl	%ecx, %ecx
	jg	.L173
	.loc 2 105 41 is_stmt 0 discriminator 10
	testl	%eax, %eax
	jle	.L174
.L173:
	.loc 2 105 41 discriminator 12
	movl	$0, %edx
	testl	%ecx, %ecx
	cmovs	%edx, %ecx
	movl	$0, %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	cmpl	%eax, %ecx
	jne	.L175
	.loc 2 105 41 discriminator 13
	movzbl	-54(%rbp), %eax
	salq	$14, %rax
	movq	%rax, %rdx
	movq	-16552(%rbp), %rax
	addq	%rdx, %rax
	leaq	-16528(%rbp), %rcx
	movq	%rsi, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcmp@PLT
	.loc 2 105 41 discriminator 14
	testl	%eax, %eax
	je	.L174
.L175:
	.loc 2 105 41 discriminator 15
	movl	$1, %eax
	jmp	.L176
.L174:
	.loc 2 105 41 discriminator 16
	movl	$0, %eax
.L176:
	.loc 2 105 12 is_stmt 1 discriminator 17
	testb	%al, %al
	je	.L177
.L170:
	.loc 2 107 21
	movb	$0, -105(%rbp)
	.loc 2 108 13
	jmp	.L181
.L177:
.LBE44:
	.loc 2 97 11 discriminator 2
	cmpb	$5, -54(%rbp)
	je	.L190
	.loc 2 97 11 is_stmt 0 discriminator 3
	addb	$1, -54(%rbp)
	.loc 2 112 15 is_stmt 1
	jmp	.L180
.L190:
.LBE43:
	.loc 2 113 8
	nop
.L181:
.LBE40:
	.loc 2 113 8 is_stmt 0 discriminator 2
	movzbl	-105(%rbp), %eax
	.loc 2 113 8 discriminator 4
	jmp	.L189
.L187:
	movq	%rax, -16640(%rbp)
	movl	$0, %ebx
.LBB51:
.LBB50:
.LBB49:
.LBB48:
	.loc 2 103 10 is_stmt 1 discriminator 18
	jmp	.L184
.L168:
	movq	-16640(%rbp), %rax
	movq	%rax, -16632(%rbp)
	jmp	.L185
.L188:
	movq	%rax, -16632(%rbp)
.L185:
	movl	$0, %eax
	jmp	.L186
.L169:
	movq	-16632(%rbp), %rax
	movq	%rax, %rdi
	call	_Unwind_Resume@PLT
.L189:
.LBE48:
.LBE49:
.LBE50:
.LBE51:
	.loc 2 113 8
	leaq	-40(%rbp), %rsp
.LEHE7:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE17:
	.section	.gcc_except_table
.LLSDA17:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE17-.LLSDACSB17
.LLSDACSB17:
	.uleb128 .LEHB4-.LFB17
	.uleb128 .LEHE4-.LEHB4
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB5-.LFB17
	.uleb128 .LEHE5-.LEHB5
	.uleb128 .L187-.LFB17
	.uleb128 0
	.uleb128 .LEHB6-.LFB17
	.uleb128 .LEHE6-.LEHB6
	.uleb128 .L188-.LFB17
	.uleb128 0
	.uleb128 .LEHB7-.LFB17
	.uleb128 .LEHE7-.LEHB7
	.uleb128 0
	.uleb128 0
.LLSDACSE17:
	.text
	.size	silver_libraries__same_sources, .-silver_libraries__same_sources
	.align 2
	.type	silver_libraries__capture_and_snapshot___wrapped_statements__L_4__B212b___finalizer.5, @function
silver_libraries__capture_and_snapshot___wrapped_statements__L_4__B212b___finalizer.5:
.LFB21:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	addq	$48, %rax
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE21:
	.size	silver_libraries__capture_and_snapshot___wrapped_statements__L_4__B212b___finalizer.5, .-silver_libraries__capture_and_snapshot___wrapped_statements__L_4__B212b___finalizer.5
	.section	.rodata
	.align 8
.LC28:
	.ascii	"Loop_Invariant failed at silver_libraries.adb:134"
	.align 8
.LC29:
	.ascii	"/home/canto/src/github.com/berkeleynerd/silver/src/"
	.align 8
.LC10:
	.long	1
	.long	50
	.align 8
.LC11:
	.long	1
	.long	51
	.text
	.align 2
	.type	silver_libraries__capture_and_snapshot___wrapped_statements.4, @function
silver_libraries__capture_and_snapshot___wrapped_statements.4:
.LFB20:
	.loc 2 115 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA20
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB8:
	subq	$424, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %r13
	movq	%r10, -248(%rbp)
	.loc 2 115 4
	leaq	16(%rbp), %rax
	.loc 2 115 4 is_stmt 0 discriminator 1
	movq	%rax, -168(%rbp)
	movl	20(%r13), %eax
	movl	%eax, -428(%rbp)
	movl	16(%r13), %edx
	movl	20(%r13), %eax
	cmpl	%eax, %edx
	jl	.L194
	.loc 2 115 4 discriminator 2
	movl	16(%r13), %edx
	movl	20(%r13), %eax
	subl	%eax, %edx
	leal	1(%rdx), %eax
	movl	%eax, -252(%rbp)
	jmp	.L195
.L194:
	.loc 2 115 4 discriminator 3
	movl	$0, -252(%rbp)
.L195:
.LBB52:
	.loc 2 121 28 is_stmt 1
	movq	8(%r13), %rax
	movq	%rax, %rcx
	movl	$98304, %eax
	movq	%rax, %rdx
	movl	$0, %esi
	movq	%rcx, %rdi
	call	memset@PLT
	.loc 2 121 18 discriminator 1
	movq	8(%r13), %rax
	movl	$0, 98304(%rax)
	movq	8(%r13), %rax
	movl	$0, 98308(%rax)
	movq	8(%r13), %rax
	movl	$0, 98312(%rax)
	movq	8(%r13), %rax
	movl	$0, 98316(%rax)
	movq	8(%r13), %rax
	movl	$0, 98320(%rax)
	movq	8(%r13), %rax
	movl	$0, 98324(%rax)
	.loc 2 128 15
	movl	$0, %eax
	movb	%al, 24(%r13)
	.loc 2 129 14
	leaq	silver_libraries__library_directory(%rip), %r14
	leaq	.LC10(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_libraries__valid_directory
	.loc 2 129 14 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 129 7 is_stmt 1 discriminator 1
	testb	%al, %al
	jne	.L251
.LBB53:
	.loc 2 132 11 discriminator 1
	movb	$0, -54(%rbp)
.L230:
.LBB54:
	.loc 2 134 13
	movl	$1, %ecx
.LBB55:
	.loc 2 134 21 discriminator 1
	movb	$0, -55(%rbp)
.L200:
	.loc 2 134 13 discriminator 2
	movzbl	-55(%rbp), %eax
	cmpb	-54(%rbp), %al
	jnb	.L198
	.loc 2 134 95 discriminator 3
	movzbl	-55(%rbp), %eax
	movq	8(%r13), %rdx
	addq	$24576, %rax
	movl	(%rdx,%rax,4), %eax
	.loc 2 134 46 discriminator 3
	testl	%eax, %eax
	jg	.L198
	.loc 2 134 13 discriminator 4
	movl	$0, %ecx
	jmp	.L199
.L198:
	.loc 2 134 13 is_stmt 0 discriminator 5
	cmpb	$5, -55(%rbp)
	je	.L199
	.loc 2 134 13 discriminator 6
	addb	$1, -55(%rbp)
	jmp	.L200
.L199:
.LBE55:
	.loc 2 134 13 discriminator 7
	movl	%ecx, %eax
	xorl	$1, %eax
	testb	%al, %al
	je	.L201
.LBB56:
	.loc 2 134 13 discriminator 8
	leaq	.LC28(%rip), %rax
	movq	%rax, -400(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -392(%rbp)
	movq	-400(%rbp), %rbx
	movq	-392(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.LEHE8:
.L201:
	leaq	-192(%rbp), %rax
	movq	%rax, %rdi
.LEHB9:
	call	system__secondary_stack__ss_mark@PLT
.LBE56:
.LBB57:
	.loc 2 140 47 is_stmt 1
	movzbl	-54(%rbp), %eax
	movl	%eax, %edi
	call	silver_libraries__file_name
	.loc 2 140 47 is_stmt 0 discriminator 1
	movq	%rax, %r14
	movq	%rdx, %r15
	.loc 2 140 45 is_stmt 1 discriminator 1
	movq	%r15, %rax
	movl	4(%rax), %edx
	movq	%r15, %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L202
	.loc 2 140 45 is_stmt 0 discriminator 2
	movq	%r15, %rax
	movl	4(%rax), %edx
	movq	%r15, %rax
	movl	(%rax), %eax
	subl	%eax, %edx
	leal	1(%rdx), %eax
	jmp	.L203
.L202:
	.loc 2 140 45 discriminator 3
	movl	$0, %eax
.L203:
	.loc 2 140 45 discriminator 4
	addl	$51, %eax
	movl	%eax, -64(%rbp)
	movl	-64(%rbp), %eax
	cltq
	movq	%rax, -72(%rbp)
	movl	-64(%rbp), %eax
	cltq
	movl	$1, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_allocate@PLT
	.loc 2 140 45 discriminator 5
	movq	%rax, %rbx
	movq	%rbx, -80(%rbp)
.LBB58:
	leaq	.LC29(%rip), %rax
	movq	%rax, -384(%rbp)
	leaq	.LC11(%rip), %rax
	movq	%rax, -376(%rbp)
	movq	%rbx, -368(%rbp)
	movl	$1, -152(%rbp)
	movl	-64(%rbp), %eax
	movl	%eax, -148(%rbp)
	leaq	-152(%rbp), %rax
	movq	%rax, -360(%rbp)
	movq	-368(%rbp), %rax
	movq	-360(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rax
	movq	%r14, %r8
	movq	%r15, %r9
	movq	-384(%rbp), %rdx
	movq	-376(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	system__concat_2__str_concat_2@PLT
.LBE58:
.LBB59:
	.loc 2 140 10 is_stmt 1 discriminator 6
	movzbl	-54(%rbp), %eax
	movq	8(%r13), %rdx
	salq	$14, %rax
	addq	%rdx, %rax
	movq	%rax, -352(%rbp)
	leaq	.LC9(%rip), %rax
	movq	%rax, -344(%rbp)
	movq	%rbx, -336(%rbp)
	movl	$1, -144(%rbp)
	movl	-64(%rbp), %eax
	movl	%eax, -140(%rbp)
	leaq	-144(%rbp), %rax
	movq	%rax, -328(%rbp)
	movq	-336(%rbp), %rax
	movq	-328(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rax
	movq	-352(%rbp), %rdx
	movq	-344(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_platform__read_file@PLT
.LEHE9:
	movq	%rax, %rdx
	.loc 2 140 10 is_stmt 0 discriminator 7
	movl	%edx, -52(%rbp)
	movq	%rdx, %rax
	shrq	$32, %rax
	andb	$-1, %ah
	movb	%al, -53(%rbp)
	movq	%rdx, %rax
	shrq	$40, %rax
	andb	$-1, %ah
	movb	%al, 24(%r13)
.LBE59:
	.loc 2 140 0 is_stmt 1 discriminator 8
	movl	$1, %ebx
.L233:
	.loc 2 140 0 is_stmt 0 discriminator 9
	leaq	-240(%rbp), %rax
	movq	%rax, %r10
.LEHB10:
	call	silver_libraries__capture_and_snapshot___wrapped_statements__L_4__B212b___finalizer.5
.LEHE10:
	.loc 2 140 0 discriminator 10
	cmpl	$1, %ebx
	jne	.L204
	.loc 2 140 0 discriminator 12
	movl	$1, %eax
.L235:
	.loc 2 140 0 discriminator 13
	cmpl	$1, %eax
	jne	.L205
	.loc 2 140 0 discriminator 14
	nop
	leaq	-216(%rbp), %rax
	movq	%rax, %rdi
.LEHB11:
	call	system__secondary_stack__ss_mark@PLT
.LBE57:
.LBB60:
	.loc 2 142 13 is_stmt 1
	movzbl	24(%r13), %eax
	xorl	$1, %eax
	.loc 2 143 12
	testb	%al, %al
	jne	.L206
	.loc 2 142 25 discriminator 1
	cmpb	$0, -53(%rbp)
	jne	.L206
	.loc 2 142 42 discriminator 2
	cmpl	$0, -52(%rbp)
	je	.L206
	.loc 2 143 47 discriminator 1
	movl	-52(%rbp), %r12d
	.loc 2 143 44 discriminator 1
	testl	%r12d, %r12d
	jle	.L207
	.loc 2 143 44 is_stmt 0 discriminator 2
	cmpl	$16384, %r12d
	jle	.L207
	.loc 2 143 44 discriminator 3
	leaq	.LC13(%rip), %rax
	movl	$143, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L207:
	.loc 2 143 27 is_stmt 1 discriminator 4
	movl	$0, %eax
	testl	%r12d, %r12d
	cmovns	%r12d, %eax
	movslq	%eax, %r14
	.loc 2 143 56 discriminator 4
	movzbl	-54(%rbp), %eax
	movl	%eax, %edi
	call	silver_libraries__expected_source
.LEHE11:
	movq	%rax, %rcx
	movq	%rdx, %rbx
	.loc 2 143 53 discriminator 5
	testl	%r12d, %r12d
	jg	.L208
	.loc 2 143 53 is_stmt 0 discriminator 6
	movq	%rbx, %rax
	movl	4(%rax), %edx
	movq	%rbx, %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L209
.L208:
	.loc 2 143 53 discriminator 8
	movl	$0, %eax
	testl	%r12d, %r12d
	cmovns	%r12d, %eax
	movslq	%eax, %rsi
	movq	%rbx, %rax
	movl	4(%rax), %edx
	movq	%rbx, %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L210
	.loc 2 143 53 discriminator 9
	movq	%rbx, %rax
	movl	4(%rax), %eax
	movslq	%eax, %rdx
	movq	%rbx, %rax
	movl	(%rax), %eax
	cltq
	subq	%rax, %rdx
	leaq	1(%rdx), %rax
	jmp	.L211
.L210:
	.loc 2 143 53 discriminator 10
	movl	$0, %eax
.L211:
	.loc 2 143 53 discriminator 11
	cmpq	%rsi, %rax
	jne	.L212
	.loc 2 143 53 discriminator 12
	movzbl	-54(%rbp), %eax
	movq	8(%r13), %rdx
	salq	$14, %rax
	addq	%rdx, %rax
	movq	%r14, %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcmp@PLT
	.loc 2 143 53 discriminator 13
	testl	%eax, %eax
	je	.L209
.L212:
	.loc 2 143 53 discriminator 14
	movl	$1, %eax
	jmp	.L213
.L209:
	.loc 2 143 53 discriminator 15
	movl	$0, %eax
.L213:
	.loc 2 143 12 is_stmt 1 discriminator 16
	testb	%al, %al
	je	.L214
.L206:
	.loc 2 143 12 is_stmt 0 discriminator 17
	movb	$1, -253(%rbp)
	jmp	.L215
.L214:
	.loc 2 143 12 discriminator 18
	movb	$0, -253(%rbp)
.L215:
	.loc 2 143 0 is_stmt 1 discriminator 19
	movl	$1, %ebx
.L237:
	.loc 2 143 0 is_stmt 0 discriminator 20
	leaq	-240(%rbp), %rax
	movq	%rax, %r10
.LEHB12:
	call	silver_libraries__capture_and_snapshot___wrapped_statements__L_4__B229b___finalizer.6
.LEHE12:
	.loc 2 143 0 discriminator 21
	cmpl	$1, %ebx
	jne	.L216
	.loc 2 143 0 discriminator 23
	movl	$1, %eax
.L239:
	.loc 2 143 0 discriminator 24
	cmpl	$1, %eax
	jne	.L217
	.loc 2 143 0 discriminator 25
	nop
.LBE60:
	.loc 2 142 10 is_stmt 1 discriminator 3
	cmpb	$0, -253(%rbp)
	je	.L218
	.loc 2 145 21
	movl	$0, %eax
	movb	%al, 24(%r13)
	.loc 2 146 29
	movq	8(%r13), %rax
	movl	$0, 98304(%rax)
	movq	8(%r13), %rax
	movl	$0, 98308(%rax)
	movq	8(%r13), %rax
	movl	$0, 98312(%rax)
	movq	8(%r13), %rax
	movl	$0, 98316(%rax)
	movq	8(%r13), %rax
	movl	$0, 98320(%rax)
	movq	8(%r13), %rax
	movl	$0, 98324(%rax)
	.loc 2 147 13
	jmp	.L250
.L218:
	.loc 2 149 36
	cmpl	$0, -52(%rbp)
	js	.L219
	.loc 2 149 36 is_stmt 0 discriminator 1
	cmpl	$16384, -52(%rbp)
	jle	.L220
.L219:
	.loc 2 149 36 discriminator 2
	leaq	.LC13(%rip), %rax
	movl	$149, %esi
	movq	%rax, %rdi
.LEHB13:
	call	__gnat_rcheck_CE_Range_Check@PLT
.L220:
	.loc 2 149 33 is_stmt 1 discriminator 3
	movzbl	-54(%rbp), %eax
	movq	8(%r13), %rcx
	leaq	24576(%rax), %rdx
	movl	-52(%rbp), %eax
	movl	%eax, (%rcx,%rdx,4)
.LEHE13:
	leaq	-240(%rbp), %rax
	movq	%rax, %rdi
.LEHB14:
	call	system__secondary_stack__ss_mark@PLT
.LBB61:
	.loc 2 154 40
	movzbl	-54(%rbp), %eax
	movl	%eax, %edi
	call	silver_libraries__file_name
	.loc 2 154 40 is_stmt 0 discriminator 1
	movq	%rax, %r14
	movq	%rdx, %r15
	.loc 2 154 38 is_stmt 1 discriminator 1
	movl	-252(%rbp), %eax
	leal	1(%rax), %ecx
	movq	%r15, %rax
	movl	4(%rax), %edx
	movq	%r15, %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L221
	.loc 2 154 38 is_stmt 0 discriminator 2
	movq	%r15, %rax
	movl	4(%rax), %edx
	movq	%r15, %rax
	movl	(%rax), %eax
	subl	%eax, %edx
	leal	1(%rdx), %eax
	jmp	.L222
.L221:
	.loc 2 154 38 discriminator 3
	movl	$0, %eax
.L222:
	.loc 2 154 38 discriminator 4
	addl	%ecx, %eax
	cmpl	$0, -252(%rbp)
	je	.L223
	.loc 2 154 38 discriminator 5
	movl	-428(%rbp), %ebx
	movl	%ebx, -60(%rbp)
	jmp	.L224
.L223:
	.loc 2 154 38 discriminator 6
	movl	$1, -60(%rbp)
.L224:
	.loc 2 154 38 discriminator 7
	leal	-1(%rax), %edx
	movl	-60(%rbp), %eax
	addl	%edx, %eax
	movl	%eax, -84(%rbp)
	movl	-60(%rbp), %eax
	cltq
	movq	%rax, -96(%rbp)
	movl	-84(%rbp), %eax
	cltq
	movq	%rax, -104(%rbp)
	movl	-84(%rbp), %eax
	movslq	%eax, %rdx
	movl	-60(%rbp), %eax
	cltq
	subq	%rax, %rdx
	leaq	1(%rdx), %rax
	movl	$1, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_allocate@PLT
	.loc 2 154 38 discriminator 8
	movq	%rax, %rbx
	movq	%rbx, -112(%rbp)
.LBB62:
	leaq	.LC27(%rip), %rax
	movq	%rax, -320(%rbp)
	leaq	.LC8(%rip), %rax
	movq	%rax, -312(%rbp)
	movq	%rbx, -304(%rbp)
	movl	-60(%rbp), %eax
	movl	%eax, -136(%rbp)
	movl	-84(%rbp), %eax
	movl	%eax, -132(%rbp)
	leaq	-136(%rbp), %rax
	movq	%rax, -296(%rbp)
	movq	0(%r13), %rax
	movq	8(%rax), %rdx
	movq	(%rax), %rax
	movq	-304(%rbp), %r9
	movq	-296(%rbp), %r10
	movq	%r9, %rdi
	movq	%r10, %rsi
	pushq	%r15
	pushq	%r14
	movq	-320(%rbp), %r8
	movq	-312(%rbp), %r9
	movq	%rdx, %rcx
	movq	%rax, %rdx
	.cfi_escape 0x2e,0x10
	call	system__concat_3__str_concat_3@PLT
	addq	$16, %rsp
.LBE62:
	.loc 2 155 56 is_stmt 1
	movzbl	-54(%rbp), %eax
	movq	8(%r13), %rdx
	addq	$24576, %rax
	.cfi_escape 0x2e,0
	movl	(%rdx,%rax,4), %ecx
	.loc 2 155 46 discriminator 1
	testl	%ecx, %ecx
	jle	.L225
	.loc 2 155 46 is_stmt 0 discriminator 2
	cmpl	$16384, %ecx
	jle	.L225
	.loc 2 155 46 discriminator 3
	leaq	.LC13(%rip), %rax
	movl	$155, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L225:
	.loc 2 154 10 is_stmt 1 discriminator 9
	movzbl	-54(%rbp), %eax
	movq	8(%r13), %rdx
	salq	$14, %rax
	addq	%rdx, %rax
	movq	%rax, -288(%rbp)
	movl	$1, -128(%rbp)
	movl	%ecx, -124(%rbp)
	leaq	-128(%rbp), %rax
	movq	%rax, -280(%rbp)
	movq	%rbx, -272(%rbp)
	movl	-60(%rbp), %eax
	movl	%eax, -120(%rbp)
	movl	-84(%rbp), %eax
	movl	%eax, -116(%rbp)
	leaq	-120(%rbp), %rax
	movq	%rax, -264(%rbp)
	movq	-272(%rbp), %rax
	movq	-264(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rax
	movq	-288(%rbp), %rdx
	movq	-280(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_platform__write_file@PLT
.LEHE14:
	.loc 2 154 10 is_stmt 0 discriminator 10
	movb	%al, 24(%r13)
	.loc 2 154 0 is_stmt 1 discriminator 10
	movl	$1, %ebx
.L241:
	.loc 2 154 0 is_stmt 0 discriminator 11
	leaq	-240(%rbp), %rax
	movq	%rax, %r10
.LEHB15:
	call	silver_libraries__capture_and_snapshot___wrapped_statements__L_4__B239b___finalizer.7
.LEHE15:
	.loc 2 154 0 discriminator 12
	cmpl	$1, %ebx
	jne	.L226
	.loc 2 154 0 discriminator 14
	movl	$1, %eax
.L243:
	.loc 2 154 0 discriminator 15
	cmpl	$1, %eax
	jne	.L227
	.loc 2 154 0 discriminator 16
	nop
.LBE61:
	.loc 2 156 13 is_stmt 1
	movzbl	24(%r13), %eax
	xorl	$1, %eax
	.loc 2 156 10
	testb	%al, %al
	je	.L228
	.loc 2 157 29
	movq	8(%r13), %rax
	movl	$0, 98304(%rax)
	movq	8(%r13), %rax
	movl	$0, 98308(%rax)
	movq	8(%r13), %rax
	movl	$0, 98312(%rax)
	movq	8(%r13), %rax
	movl	$0, 98316(%rax)
	movq	8(%r13), %rax
	movl	$0, 98320(%rax)
	movq	8(%r13), %rax
	movl	$0, 98324(%rax)
	.loc 2 158 13
	jmp	.L250
.L228:
.LBE54:
	.loc 2 132 11 discriminator 2
	cmpb	$5, -54(%rbp)
	je	.L229
	.loc 2 132 11 is_stmt 0 discriminator 3
	addb	$1, -54(%rbp)
	.loc 2 163 15 is_stmt 1
	jmp	.L230
.L229:
.LBE53:
	.loc 2 164 7
	movq	0(%r13), %rax
	movq	8(%r13), %rdx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
.LEHB16:
	call	silver_libraries__same_sources
	.loc 2 164 7 is_stmt 0 discriminator 1
	movb	%al, 24(%r13)
	.loc 2 165 10 is_stmt 1
	movzbl	24(%r13), %eax
	xorl	$1, %eax
	.loc 2 165 7
	testb	%al, %al
	je	.L252
	.loc 2 166 26
	movq	8(%r13), %rax
	movl	$0, 98304(%rax)
	movq	8(%r13), %rax
	movl	$0, 98308(%rax)
	movq	8(%r13), %rax
	movl	$0, 98312(%rax)
	movq	8(%r13), %rax
	movl	$0, 98316(%rax)
	movq	8(%r13), %rax
	movl	$0, 98320(%rax)
	movq	8(%r13), %rax
	movl	$0, 98324(%rax)
	.loc 2 168 8
	jmp	.L252
.L244:
	movq	%rax, -440(%rbp)
	movl	$0, %ebx
.LBB67:
.LBB66:
.LBB63:
	.loc 2 140 10 discriminator 15
	jmp	.L233
.L204:
	movq	-440(%rbp), %rax
	movq	%rax, -408(%rbp)
	jmp	.L234
.L245:
	movq	%rax, -408(%rbp)
.L234:
	movl	$0, %eax
	jmp	.L235
.L205:
	movq	-408(%rbp), %rax
	movq	%rax, %rdi
	call	_Unwind_Resume@PLT
.L246:
	movq	%rax, -448(%rbp)
	movl	$0, %ebx
.LBE63:
.LBB64:
	.loc 2 143 12 discriminator 26
	jmp	.L237
.L216:
	movq	-448(%rbp), %rax
	movq	%rax, -416(%rbp)
	jmp	.L238
.L247:
	movq	%rax, -416(%rbp)
.L238:
	movl	$0, %eax
	jmp	.L239
.L217:
	movq	-416(%rbp), %rax
	movq	%rax, %rdi
	call	_Unwind_Resume@PLT
.L248:
	movq	%rax, -456(%rbp)
	movl	$0, %ebx
.LBE64:
.LBB65:
	.loc 2 154 10 discriminator 17
	jmp	.L241
.L226:
	movq	-456(%rbp), %rax
	movq	%rax, -424(%rbp)
	jmp	.L242
.L249:
	movq	%rax, -424(%rbp)
.L242:
	movl	$0, %eax
	jmp	.L243
.L227:
	movq	-424(%rbp), %rax
	movq	%rax, %rdi
	call	_Unwind_Resume@PLT
.L251:
.LBE65:
.LBE66:
.LBE67:
	.loc 2 130 10
	nop
	jmp	.L250
.L252:
	.loc 2 168 8
	nop
.L250:
.LBE52:
	leaq	-40(%rbp), %rsp
.LEHE16:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE20:
	.section	.gcc_except_table
.LLSDA20:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE20-.LLSDACSB20
.LLSDACSB20:
	.uleb128 .LEHB8-.LFB20
	.uleb128 .LEHE8-.LEHB8
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB9-.LFB20
	.uleb128 .LEHE9-.LEHB9
	.uleb128 .L244-.LFB20
	.uleb128 0
	.uleb128 .LEHB10-.LFB20
	.uleb128 .LEHE10-.LEHB10
	.uleb128 .L245-.LFB20
	.uleb128 0
	.uleb128 .LEHB11-.LFB20
	.uleb128 .LEHE11-.LEHB11
	.uleb128 .L246-.LFB20
	.uleb128 0
	.uleb128 .LEHB12-.LFB20
	.uleb128 .LEHE12-.LEHB12
	.uleb128 .L247-.LFB20
	.uleb128 0
	.uleb128 .LEHB13-.LFB20
	.uleb128 .LEHE13-.LEHB13
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB14-.LFB20
	.uleb128 .LEHE14-.LEHB14
	.uleb128 .L248-.LFB20
	.uleb128 0
	.uleb128 .LEHB15-.LFB20
	.uleb128 .LEHE15-.LEHB15
	.uleb128 .L249-.LFB20
	.uleb128 0
	.uleb128 .LEHB16-.LFB20
	.uleb128 .LEHE16-.LEHB16
	.uleb128 0
	.uleb128 0
.LLSDACSE20:
	.text
	.size	silver_libraries__capture_and_snapshot___wrapped_statements.4, .-silver_libraries__capture_and_snapshot___wrapped_statements.4
	.section	.rodata
	.align 8
.LC30:
	.ascii	"failed precondition from silver_libraries.ads:93"
	.align 8
.LC31:
	.ascii	"failed postcondition from silver_libraries.ads:94"
	.text
	.align 2
	.globl	silver_libraries__capture_and_snapshot
	.type	silver_libraries__capture_and_snapshot, @function
silver_libraries__capture_and_snapshot:
.LFB19:
	.loc 2 115 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA19
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB17:
	subq	$104, %rsp
.LEHE17:
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -112(%rbp)
	movq	%rbx, -104(%rbp)
	movq	%rdx, -120(%rbp)
	.loc 2 115 4
	leaq	16(%rbp), %rdx
	.loc 2 115 4 is_stmt 0 discriminator 1
	leaq	-112(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -96(%rbp)
	movq	-120(%rbp), %rax
	movq	%rax, -88(%rbp)
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -76(%rbp)
	movq	-104(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -80(%rbp)
.LBB68:
	movl	-80(%rbp), %edx
	movl	-76(%rbp), %eax
	cmpl	%eax, %edx
	.loc 2 115 4 discriminator 4
	movl	-80(%rbp), %edx
	movl	-76(%rbp), %eax
	cmpl	%eax, %edx
	.loc 2 115 4 discriminator 7
	movl	-80(%rbp), %edx
	movl	-76(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 93 18 is_stmt 1
	movq	-112(%rbp), %rdx
	movq	-104(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
.LEHB18:
	call	silver_libraries__valid_directory
	.loc 1 93 18 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L260
.LBB69:
	.loc 1 93 18 discriminator 2
	leaq	.LC30(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L260:
.LBE69:
	.loc 2 115 4 is_stmt 1 discriminator 10
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
	call	silver_libraries__capture_and_snapshot___wrapped_statements.4
	.loc 1 94 31
	movq	-88(%rbp), %rax
	movq	%rax, %rdi
	call	silver_libraries__complete
	.loc 1 94 50 discriminator 1
	movzbl	-72(%rbp), %edx
	.loc 1 94 31 discriminator 1
	cmpb	%dl, %al
	je	.L269
.LBB70:
	.loc 1 94 31 is_stmt 0 discriminator 2
	leaq	.LC31(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.LEHE18:
.L269:
.LBE70:
	.loc 2 115 4 is_stmt 1 discriminator 11
	nop
.LBE68:
	.loc 2 115 4 is_stmt 0 discriminator 12
	movzbl	-72(%rbp), %eax
	movb	%al, -121(%rbp)
	movl	$0, %eax
.L265:
	cmpl	$1, %eax
	je	.L262
	.loc 2 115 4 discriminator 13
	movzbl	-121(%rbp), %eax
	jmp	.L268
.L266:
	movq	%rax, -136(%rbp)
	movl	$1, %eax
	jmp	.L265
.L262:
	movq	-136(%rbp), %rax
	movq	%rax, %rdi
.LEHB19:
	call	_Unwind_Resume@PLT
.L268:
	.loc 2 115 4
	addq	$104, %rsp
.LEHE19:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE19:
	.section	.gcc_except_table
.LLSDA19:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE19-.LLSDACSB19
.LLSDACSB19:
	.uleb128 .LEHB17-.LFB19
	.uleb128 .LEHE17-.LEHB17
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB18-.LFB19
	.uleb128 .LEHE18-.LEHB18
	.uleb128 .L266-.LFB19
	.uleb128 0
	.uleb128 .LEHB19-.LFB19
	.uleb128 .LEHE19-.LEHB19
	.uleb128 0
	.uleb128 0
.LLSDACSE19:
	.text
	.size	silver_libraries__capture_and_snapshot, .-silver_libraries__capture_and_snapshot
	.align 2
	.type	silver_libraries__capture_and_snapshot___wrapped_statements__L_4__B229b___finalizer.6, @function
silver_libraries__capture_and_snapshot___wrapped_statements__L_4__B229b___finalizer.6:
.LFB22:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	addq	$24, %rax
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE22:
	.size	silver_libraries__capture_and_snapshot___wrapped_statements__L_4__B229b___finalizer.6, .-silver_libraries__capture_and_snapshot___wrapped_statements__L_4__B229b___finalizer.6
	.align 2
	.type	silver_libraries__capture_and_snapshot___wrapped_statements__L_4__B239b___finalizer.7, @function
silver_libraries__capture_and_snapshot___wrapped_statements__L_4__B239b___finalizer.7:
.LFB23:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE23:
	.size	silver_libraries__capture_and_snapshot___wrapped_statements__L_4__B239b___finalizer.7, .-silver_libraries__capture_and_snapshot___wrapped_statements__L_4__B239b___finalizer.7
	.globl	silver_libraries_E
	.data
	.align 2
	.type	silver_libraries_E, @object
	.size	silver_libraries_E, 2
silver_libraries_E:
	.zero	2
	.globl	silver_libraries__max_source_length
	.section	.rodata
	.align 4
	.type	silver_libraries__max_source_length, @object
	.size	silver_libraries__max_source_length, 4
silver_libraries__max_source_length:
	.long	16384
	.globl	silver_libraries__unit_kindS
	.align 32
	.type	silver_libraries__unit_kindS, @object
	.size	silver_libraries__unit_kindS, 115
silver_libraries__unit_kindS:
	.ascii	"IO_SPECIFICATIONIO_IMPLEMENTATIONIMPORTED_INTERFACEARGUMENTS"
	.ascii	"_SPECIFICATIONARGUMENTS_IMPLEMENTATIONRUNTIME_INTERFACE"
	.globl	silver_libraries__unit_kindN
	.align 8
	.type	silver_libraries__unit_kindN, @object
	.size	silver_libraries__unit_kindN, 8
silver_libraries__unit_kindN:
	.byte	1
	.byte	17
	.byte	34
	.byte	52
	.byte	75
	.byte	99
	.byte	116
	.zero	1
	.globl	silver_libraries__library_directory
	.align 32
	.type	silver_libraries__library_directory, @object
	.size	silver_libraries__library_directory, 50
silver_libraries__library_directory:
	.ascii	"/home/canto/src/github.com/berkeleynerd/silver/src"
	.align 4
	.type	unit_kindP.11, @object
	.size	unit_kindP.11, 4
unit_kindP.11:
	.long	14
	.type	unit_kindT1.10, @object
	.size	unit_kindT1.10, 1
unit_kindT1.10:
	.byte	3
	.type	unit_kindT2.9, @object
	.size	unit_kindT2.9, 1
unit_kindT2.9:
	.byte	8
	.align 16
	.type	unit_kindG.8, @object
	.size	unit_kindG.8, 16
unit_kindG.8:
	.byte	0
	.byte	0
	.byte	5
	.byte	1
	.byte	0
	.byte	0
	.byte	2
	.byte	0
	.byte	0
	.byte	1
	.byte	4
	.byte	0
	.byte	0
	.zero	3
	.text
.Letext0:
	.file 3 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_library_reports.ads"
	.file 4 "<built-in>"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x7a0
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x19
	.long	.LASF70
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.long	.LLRL9
	.quad	0
	.long	.Ldebug_line0
	.uleb128 0xf
	.long	.LASF28
	.byte	0x1
	.byte	0x7
	.long	0x4d
	.uleb128 0x9
	.byte	0x3
	.quad	silver_libraries__max_source_length
	.uleb128 0x1a
	.sleb128 2147483647
	.long	.LASF71
	.long	0x52
	.uleb128 0x10
	.long	0x3f
	.uleb128 0xa
	.byte	0x4
	.byte	0x5
	.long	.LASF2
	.uleb128 0xd
	.long	.LASF10
	.long	0x6f
	.long	0x6f
	.uleb128 0xe
	.long	0x52
	.sleb128 16384
	.byte	0
	.uleb128 0xa
	.byte	0x1
	.byte	0x8
	.long	.LASF3
	.uleb128 0x11
	.sleb128 16384
	.long	.LASF26
	.long	0x52
	.uleb128 0x12
	.long	.LASF15
	.byte	0x1
	.byte	0x8
	.long	0xb2
	.uleb128 0x4
	.long	.LASF4
	.byte	0
	.uleb128 0x4
	.long	.LASF5
	.byte	0x1
	.uleb128 0x4
	.long	.LASF6
	.byte	0x2
	.uleb128 0x4
	.long	.LASF7
	.byte	0x3
	.uleb128 0x4
	.long	.LASF8
	.byte	0x4
	.uleb128 0x4
	.long	.LASF9
	.byte	0x5
	.byte	0
	.uleb128 0x10
	.long	0x82
	.uleb128 0xd
	.long	.LASF11
	.long	0x59
	.long	0xca
	.uleb128 0x13
	.long	0x82
	.byte	0
	.uleb128 0xd
	.long	.LASF12
	.long	0x76
	.long	0xdd
	.uleb128 0x13
	.long	0x82
	.byte	0
	.uleb128 0x1b
	.long	.LASF42
	.long	0x18018
	.byte	0x1
	.byte	0xf
	.byte	0x9
	.long	0x10b
	.uleb128 0x1c
	.long	.LASF13
	.byte	0x1
	.byte	0x10
	.byte	0x7
	.long	0xb7
	.byte	0
	.uleb128 0x1d
	.long	.LASF14
	.byte	0x1
	.byte	0x11
	.byte	0x7
	.long	0xca
	.long	0x18000
	.byte	0
	.uleb128 0x12
	.long	.LASF16
	.byte	0x3
	.byte	0xa
	.long	0x12f
	.uleb128 0x4
	.long	.LASF17
	.byte	0
	.uleb128 0x4
	.long	.LASF18
	.byte	0x1
	.uleb128 0x4
	.long	.LASF19
	.byte	0x2
	.uleb128 0x4
	.long	.LASF20
	.byte	0x3
	.byte	0
	.uleb128 0xa
	.byte	0x1
	.byte	0x2
	.long	.LASF21
	.uleb128 0x14
	.long	.LASF24
	.uleb128 0xa
	.byte	0x1
	.byte	0x7
	.long	.LASF22
	.uleb128 0x5
	.long	0x6f
	.long	0x152
	.uleb128 0xe
	.long	0x52
	.sleb128 50
	.byte	0
	.uleb128 0xb
	.long	0x142
	.uleb128 0xa
	.byte	0x8
	.byte	0x7
	.long	.LASF23
	.uleb128 0x14
	.long	.LASF25
	.uleb128 0x11
	.sleb128 2147483647
	.long	.LASF27
	.long	0x52
	.uleb128 0xf
	.long	.LASF29
	.byte	0x2
	.byte	0xb
	.long	0x152
	.uleb128 0x9
	.byte	0x3
	.quad	silver_libraries__library_directory
	.uleb128 0x1e
	.long	.LASF72
	.byte	0x1
	.byte	0x2
	.byte	0x6
	.uleb128 0x1f
	.byte	0x2
	.byte	0x9
	.byte	0x4
	.long	0x186
	.uleb128 0x6
	.long	.LASF46
	.byte	0x2
	.byte	0x73
	.long	0x12f
	.quad	.LFB19
	.quad	.LFE19-.LFB19
	.uleb128 0x1
	.byte	0x9c
	.long	0x30e
	.uleb128 0x2
	.long	.LASF30
	.byte	0x56
	.byte	0x7
	.long	0x360
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x2
	.long	.LASF31
	.byte	0x56
	.byte	0x1b
	.long	0x389
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x2
	.long	.LASF32
	.byte	0x56
	.byte	0x35
	.long	0x12f
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x8
	.quad	.LBB68
	.quad	.LBE68-.LBB68
	.uleb128 0x20
	.long	.LASF73
	.quad	.LFB20
	.quad	.LFE20-.LFB20
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -264
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x8
	.quad	.LBB52
	.quad	.LBE52-.LBB52
	.uleb128 0x1
	.long	.LASF33
	.byte	0x2
	.byte	0x76
	.byte	0x7
	.long	0x163
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x1
	.long	.LASF34
	.byte	0x2
	.byte	0x77
	.byte	0x7
	.long	0x12f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -69
	.uleb128 0x7
	.long	.LLRL6
	.uleb128 0x1
	.long	.LASF35
	.byte	0x2
	.byte	0x84
	.byte	0xb
	.long	0x82
	.uleb128 0x3
	.byte	0x91
	.sleb128 -70
	.uleb128 0x21
	.quad	.LBB55
	.quad	.LBE55-.LBB55
	.long	0x284
	.uleb128 0x1
	.long	.LASF36
	.byte	0x2
	.byte	0x86
	.byte	0x15
	.long	0x82
	.uleb128 0x3
	.byte	0x91
	.sleb128 -71
	.byte	0
	.uleb128 0x22
	.long	.LLRL7
	.long	0x2c0
	.uleb128 0x3
	.long	.LASF37
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x5
	.long	0x6f
	.long	0x2ad
	.uleb128 0x23
	.long	0x52
	.long	0x28d
	.byte	0
	.uleb128 0x3
	.long	.LASF38
	.long	0x2ba
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x9
	.long	0x29a
	.byte	0
	.uleb128 0x7
	.long	.LLRL8
	.uleb128 0x3
	.long	.LASF39
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x3
	.long	.LASF40
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -100
	.uleb128 0x5
	.long	0x6f
	.long	0x2f6
	.uleb128 0xc
	.long	0x52
	.long	0x2c5
	.long	0x2d2
	.byte	0
	.uleb128 0x3
	.long	.LASF41
	.long	0x303
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x9
	.long	0x2df
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x24
	.long	.LASF43
	.byte	0x10
	.byte	0x4
	.byte	0
	.long	0x351
	.uleb128 0x15
	.long	.LASF44
	.long	0x324
	.byte	0
	.uleb128 0x16
	.long	0x365
	.uleb128 0x25
	.byte	0x8
	.byte	0x4
	.byte	0
	.long	0x346
	.uleb128 0x17
	.string	"LB0"
	.long	0x3f
	.byte	0
	.uleb128 0x17
	.string	"UB0"
	.long	0x3f
	.byte	0x4
	.byte	0
	.uleb128 0x15
	.long	.LASF45
	.long	0x384
	.byte	0x8
	.byte	0
	.uleb128 0xb
	.long	0x30e
	.uleb128 0xb
	.long	0x30e
	.uleb128 0xb
	.long	0x30e
	.uleb128 0xb
	.long	0x30e
	.uleb128 0x5
	.long	0x6f
	.long	0x384
	.uleb128 0x26
	.long	0x52
	.uleb128 0x6
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x94
	.byte	0x4
	.uleb128 0x8
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x23
	.uleb128 0x4
	.byte	0x94
	.byte	0x4
	.byte	0
	.uleb128 0x16
	.long	0x329
	.uleb128 0x9
	.long	0xdd
	.uleb128 0x6
	.long	.LASF47
	.byte	0x2
	.byte	0x58
	.long	0x12f
	.quad	.LFB17
	.quad	.LFE17-.LFB17
	.uleb128 0x1
	.byte	0x9c
	.long	0x475
	.uleb128 0x2
	.long	.LASF30
	.byte	0x4c
	.byte	0x7
	.long	0x35b
	.uleb128 0x4
	.byte	0x91
	.sleb128 -16560
	.uleb128 0x2
	.long	.LASF48
	.byte	0x4c
	.byte	0x1b
	.long	0x389
	.uleb128 0x4
	.byte	0x91
	.sleb128 -16568
	.uleb128 0x2
	.long	.LASF32
	.byte	0x4c
	.byte	0x32
	.long	0x12f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -121
	.uleb128 0x7
	.long	.LLRL3
	.uleb128 0x1
	.long	.LASF49
	.byte	0x2
	.byte	0x5b
	.byte	0x7
	.long	0x59
	.uleb128 0x4
	.byte	0x91
	.sleb128 -16544
	.uleb128 0x1
	.long	.LASF33
	.byte	0x2
	.byte	0x5c
	.byte	0x7
	.long	0x163
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x1
	.long	.LASF34
	.byte	0x2
	.byte	0x5d
	.byte	0x7
	.long	0x12f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -69
	.uleb128 0x7
	.long	.LLRL4
	.uleb128 0x1
	.long	.LASF35
	.byte	0x2
	.byte	0x61
	.byte	0xb
	.long	0x82
	.uleb128 0x3
	.byte	0x91
	.sleb128 -70
	.uleb128 0x7
	.long	.LLRL5
	.uleb128 0x3
	.long	.LASF50
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x3
	.long	.LASF51
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x5
	.long	0x6f
	.long	0x45f
	.uleb128 0xc
	.long	0x52
	.long	0x42e
	.long	0x43b
	.byte	0
	.uleb128 0x3
	.long	.LASF52
	.long	0x46c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -104
	.uleb128 0x9
	.long	0x448
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF53
	.byte	0x2
	.byte	0x2a
	.long	0x12f
	.quad	.LFB16
	.quad	.LFE16-.LFB16
	.uleb128 0x1
	.byte	0x9c
	.long	0x5be
	.uleb128 0x2
	.long	.LASF30
	.byte	0x3b
	.byte	0x24
	.long	0x356
	.uleb128 0x4
	.byte	0x91
	.sleb128 -262336
	.uleb128 0x2
	.long	.LASF32
	.byte	0x3b
	.byte	0x38
	.long	0x12f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -161
	.uleb128 0x8
	.quad	.LBB32
	.quad	.LBE32-.LBB32
	.uleb128 0x5
	.long	0x6f
	.long	0x4d8
	.uleb128 0xe
	.long	0x52
	.sleb128 262144
	.byte	0
	.uleb128 0x1
	.long	.LASF54
	.byte	0x2
	.byte	0x2b
	.byte	0x7
	.long	0x4c6
	.uleb128 0x4
	.byte	0x91
	.sleb128 -262320
	.uleb128 0x1
	.long	.LASF33
	.byte	0x2
	.byte	0x2c
	.byte	0x7
	.long	0x163
	.uleb128 0x3
	.byte	0x91
	.sleb128 -132
	.uleb128 0x1
	.long	.LASF34
	.byte	0x2
	.byte	0x2d
	.byte	0x7
	.long	0x12f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -133
	.uleb128 0x1
	.long	.LASF55
	.byte	0x2
	.byte	0x2d
	.byte	0x11
	.long	0x12f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -134
	.uleb128 0x8
	.quad	.LBB35
	.quad	.LBE35-.LBB35
	.uleb128 0x1
	.long	.LASF35
	.byte	0x2
	.byte	0x33
	.byte	0xb
	.long	0x10b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -65
	.uleb128 0x7
	.long	.LLRL2
	.uleb128 0x3
	.long	.LASF56
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x3
	.long	.LASF57
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x5
	.long	0x6f
	.long	0x570
	.uleb128 0xc
	.long	0x52
	.long	0x53f
	.long	0x54c
	.byte	0
	.uleb128 0x3
	.long	.LASF58
	.long	0x559
	.uleb128 0x4
	.byte	0x91
	.sleb128 -104
	.byte	0x6
	.uleb128 0x5
	.long	0x6f
	.long	0x595
	.uleb128 0xc
	.long	0x52
	.long	0x53f
	.long	0x54c
	.byte	0
	.uleb128 0x1
	.long	.LASF59
	.byte	0x2
	.byte	0x3a
	.byte	0xd
	.long	0x5a5
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x9
	.long	0x57e
	.uleb128 0x1
	.long	.LASF60
	.byte	0x2
	.byte	0x40
	.byte	0xd
	.long	0x12f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -135
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF61
	.byte	0x2
	.byte	0x16
	.long	0x30e
	.quad	.LFB14
	.quad	.LFE14-.LFB14
	.uleb128 0x1
	.byte	0x9c
	.long	0x611
	.uleb128 0x2
	.long	.LASF35
	.byte	0x22
	.byte	0x1e
	.long	0xb2
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x18
	.long	.LASF63
	.long	0x30e
	.quad	.LFB15
	.quad	.LFE15-.LFB15
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -56
	.byte	0x6
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0
	.uleb128 0x6
	.long	.LASF62
	.byte	0x2
	.byte	0xd
	.long	0x30e
	.quad	.LFB12
	.quad	.LFE12-.LFB12
	.uleb128 0x1
	.byte	0x9c
	.long	0x686
	.uleb128 0x2
	.long	.LASF35
	.byte	0x1d
	.byte	0x18
	.long	0xb2
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0x18
	.long	.LASF64
	.long	0x30e
	.quad	.LFB13
	.quad	.LFE13-.LFB13
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -40
	.byte	0x6
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.uleb128 0x8
	.quad	.LBB21
	.quad	.LBE21-.LBB21
	.uleb128 0x27
	.string	"T8b"
	.byte	0x1
	.byte	0x21
	.byte	0x1f
	.long	0x686
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.byte	0
	.byte	0
	.uleb128 0x9
	.long	0x6f
	.uleb128 0x6
	.long	.LASF65
	.byte	0x1
	.byte	0x26
	.long	0x12f
	.quad	.LFB10
	.quad	.LFE10-.LFB10
	.uleb128 0x1
	.byte	0x9c
	.long	0x6d2
	.uleb128 0x2
	.long	.LASF31
	.byte	0x26
	.byte	0x20
	.long	0x389
	.uleb128 0x3
	.byte	0x91
	.sleb128 -120
	.uleb128 0x7
	.long	.LLRL1
	.uleb128 0x1
	.long	.LASF35
	.byte	0x1
	.byte	0x27
	.byte	0xf
	.long	0x82
	.uleb128 0x3
	.byte	0x91
	.sleb128 -65
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF66
	.byte	0x1
	.byte	0x1a
	.long	0x12f
	.quad	.LFB9
	.quad	.LFE9-.LFB9
	.uleb128 0x1
	.byte	0x9c
	.long	0x702
	.uleb128 0x2
	.long	.LASF30
	.byte	0x1a
	.byte	0x1e
	.long	0x351
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.byte	0
	.uleb128 0x6
	.long	.LASF67
	.byte	0x1
	.byte	0x16
	.long	0x12f
	.quad	.LFB8
	.quad	.LFE8-.LFB8
	.uleb128 0x1
	.byte	0x9c
	.long	0x761
	.uleb128 0x2
	.long	.LASF68
	.byte	0x16
	.byte	0x19
	.long	0x389
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x2
	.long	.LASF69
	.byte	0x16
	.byte	0x1f
	.long	0x389
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x8
	.quad	.LBB6
	.quad	.LBE6-.LBB6
	.uleb128 0x1
	.long	.LASF35
	.byte	0x1
	.byte	0x18
	.byte	0x19
	.long	0x82
	.uleb128 0x2
	.byte	0x91
	.sleb128 -33
	.byte	0
	.byte	0
	.uleb128 0x28
	.long	.LASF74
	.byte	0x1
	.byte	0x14
	.byte	0x4
	.long	0x12f
	.quad	.LFB7
	.quad	.LFE7-.LFB7
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x2
	.long	.LASF31
	.byte	0x14
	.byte	0x17
	.long	0x389
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x7
	.long	.LLRL0
	.uleb128 0x1
	.long	.LASF35
	.byte	0x1
	.byte	0x15
	.byte	0xf
	.long	0x82
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x28
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x1c
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x55
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x10
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3e
	.uleb128 0x21
	.sleb128 7
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x2f
	.uleb128 0x21
	.sleb128 5
	.byte	0
	.byte	0
	.uleb128 0x14
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x3e
	.uleb128 0x21
	.sleb128 5
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x15
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x16
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x17
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x18
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x19
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x55
	.uleb128 0x17
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x1a
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1b
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0x6
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1c
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x1d
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0x6
	.byte	0
	.byte	0
	.uleb128 0x1e
	.uleb128 0x1e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x1f
	.uleb128 0x3a
	.byte	0
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x18
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x20
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x21
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x22
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x55
	.uleb128 0x17
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x23
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x24
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x25
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x26
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x18
	.uleb128 0x2f
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x27
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x28
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x5c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.LFE9-.Ltext0
	.quad	.LFB10
	.quad	.LFE16-.LFB10
	.quad	.LFB17
	.quad	.LFE17-.LFB17
	.quad	.LFB20
	.quad	.LFE19-.LFB20
	.quad	0
	.quad	0
	.section	.debug_rnglists,"",@progbits
.Ldebug_ranges0:
	.long	.Ldebug_ranges3-.Ldebug_ranges2
.Ldebug_ranges2:
	.value	0x5
	.byte	0x8
	.byte	0
	.long	0
.LLRL0:
	.byte	0x5
	.quad	.LBB4
	.byte	0x4
	.uleb128 .LBB4-.LBB4
	.uleb128 .LBE4-.LBB4
	.byte	0x4
	.uleb128 .LBB5-.LBB4
	.uleb128 .LBE5-.LBB4
	.byte	0
.LLRL1:
	.byte	0x5
	.quad	.LBB9
	.byte	0x4
	.uleb128 .LBB9-.LBB9
	.uleb128 .LBE9-.LBB9
	.byte	0x4
	.uleb128 .LBB14-.LBB9
	.uleb128 .LBE14-.LBB9
	.byte	0x4
	.uleb128 .LBB15-.LBB9
	.uleb128 .LBE15-.LBB9
	.byte	0
.LLRL2:
	.byte	0x5
	.quad	.LBB36
	.byte	0x4
	.uleb128 .LBB36-.LBB36
	.uleb128 .LBE36-.LBB36
	.byte	0x4
	.uleb128 .LBB39-.LBB36
	.uleb128 .LBE39-.LBB36
	.byte	0
.LLRL3:
	.byte	0x5
	.quad	.LBB40
	.byte	0x4
	.uleb128 .LBB40-.LBB40
	.uleb128 .LBE40-.LBB40
	.byte	0x4
	.uleb128 .LBB51-.LBB40
	.uleb128 .LBE51-.LBB40
	.byte	0
.LLRL4:
	.byte	0x5
	.quad	.LBB43
	.byte	0x4
	.uleb128 .LBB43-.LBB43
	.uleb128 .LBE43-.LBB43
	.byte	0x4
	.uleb128 .LBB50-.LBB43
	.uleb128 .LBE50-.LBB43
	.byte	0
.LLRL5:
	.byte	0x5
	.quad	.LBB45
	.byte	0x4
	.uleb128 .LBB45-.LBB45
	.uleb128 .LBE45-.LBB45
	.byte	0x4
	.uleb128 .LBB48-.LBB45
	.uleb128 .LBE48-.LBB45
	.byte	0
.LLRL6:
	.byte	0x5
	.quad	.LBB53
	.byte	0x4
	.uleb128 .LBB53-.LBB53
	.uleb128 .LBE53-.LBB53
	.byte	0x4
	.uleb128 .LBB67-.LBB53
	.uleb128 .LBE67-.LBB53
	.byte	0
.LLRL7:
	.byte	0x5
	.quad	.LBB57
	.byte	0x4
	.uleb128 .LBB57-.LBB57
	.uleb128 .LBE57-.LBB57
	.byte	0x4
	.uleb128 .LBB63-.LBB57
	.uleb128 .LBE63-.LBB57
	.byte	0
.LLRL8:
	.byte	0x5
	.quad	.LBB61
	.byte	0x4
	.uleb128 .LBB61-.LBB61
	.uleb128 .LBE61-.LBB61
	.byte	0x4
	.uleb128 .LBB65-.LBB61
	.uleb128 .LBE65-.LBB61
	.byte	0
.LLRL9:
	.byte	0x7
	.quad	.Ltext0
	.uleb128 .LFE9-.Ltext0
	.byte	0x7
	.quad	.LFB10
	.uleb128 .LFE16-.LFB10
	.byte	0x7
	.quad	.LFB17
	.uleb128 .LFE17-.LFB17
	.byte	0x7
	.quad	.LFB20
	.uleb128 .LFE19-.LFB20
	.byte	0
.Ldebug_ranges3:
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF35:
	.string	"kind"
.LASF44:
	.string	"P_ARRAY"
.LASF56:
	.string	"L100b"
.LASF40:
	.string	"silver_libraries__capture_and_snapshot___wrapped_statements__L_4__B239b__TA250bP1___U"
.LASF2:
	.string	"integer"
.LASF53:
	.string	"silver_libraries__check_proof_evidence"
.LASF61:
	.string	"silver_libraries__expected_source"
.LASF27:
	.string	"natural"
.LASF72:
	.string	"silver_platform"
.LASF21:
	.string	"boolean"
.LASF19:
	.string	"silver_library_reports__arguments_body"
.LASF22:
	.string	"system__storage_elements__storage_element"
.LASF51:
	.string	"silver_libraries__same_sources__L_3__B144b__TA155bP1___U"
.LASF23:
	.string	"system__address"
.LASF12:
	.string	"silver_libraries__length_array"
.LASF34:
	.string	"too_long"
.LASF50:
	.string	"L153b"
.LASF65:
	.string	"silver_libraries__bound_to_compiler"
.LASF30:
	.string	"directory"
.LASF74:
	.string	"silver_libraries__complete"
.LASF47:
	.string	"silver_libraries__same_sources"
.LASF57:
	.string	"silver_libraries__check_proof_evidence__B_2__TTS101bSP1___U"
.LASF25:
	.string	"system__storage_elements__Tstorage_offsetB"
.LASF63:
	.string	"silver_libraries__expected_source___wrapped_statements"
.LASF43:
	.string	"string"
.LASF36:
	.string	"earlier"
.LASF16:
	.string	"silver_library_reports__report_kind"
.LASF24:
	.string	"system__parameters__Tsize_typeB"
.LASF62:
	.string	"silver_libraries__file_name"
.LASF3:
	.string	"character"
.LASF59:
	.string	"name"
.LASF45:
	.string	"P_BOUNDS"
.LASF17:
	.string	"silver_library_reports__library_body"
.LASF15:
	.string	"silver_libraries__unit_kind"
.LASF14:
	.string	"lengths"
.LASF69:
	.string	"right"
.LASF46:
	.string	"silver_libraries__capture_and_snapshot"
.LASF38:
	.string	"S220b"
.LASF54:
	.string	"report"
.LASF29:
	.string	"silver_libraries__library_directory"
.LASF55:
	.string	"read_success"
.LASF48:
	.string	"expected"
.LASF33:
	.string	"last"
.LASF5:
	.string	"silver_libraries__io_implementation"
.LASF49:
	.string	"observed"
.LASF68:
	.string	"left"
.LASF26:
	.string	"silver_libraries__source_length"
.LASF70:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF31:
	.string	"sources"
.LASF20:
	.string	"silver_library_reports__runtime_interface"
.LASF41:
	.string	"S249b"
.LASF9:
	.string	"silver_libraries__runtime_interface"
.LASF28:
	.string	"silver_libraries__max_source_length"
.LASF71:
	.string	"positive"
.LASF67:
	.string	"silver_libraries__same_bytes"
.LASF73:
	.string	"silver_libraries__capture_and_snapshot___wrapped_statements"
.LASF13:
	.string	"bytes"
.LASF58:
	.string	"S101b"
.LASF4:
	.string	"silver_libraries__io_specification"
.LASF6:
	.string	"silver_libraries__imported_interface"
.LASF18:
	.string	"silver_library_reports__imported_interface"
.LASF64:
	.string	"silver_libraries__file_name___wrapped_statements"
.LASF11:
	.string	"silver_libraries__buffer_array"
.LASF37:
	.string	"silver_libraries__capture_and_snapshot___wrapped_statements__L_4__B212b__TA221bP1___U"
.LASF7:
	.string	"silver_libraries__arguments_specification"
.LASF66:
	.string	"silver_libraries__valid_directory"
.LASF10:
	.string	"silver_libraries__source_buffer"
.LASF60:
	.string	"accepted"
.LASF32:
	.string	"success"
.LASF42:
	.string	"silver_libraries__source_set"
.LASF39:
	.string	"L248b"
.LASF8:
	.string	"silver_libraries__arguments_implementation"
.LASF52:
	.string	"S154b"
	.section	.debug_line_str,"MS",@progbits,1
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_libraries.adb"
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
	.hidden	DW.ref.__gnat_personality_v0
	.weak	DW.ref.__gnat_personality_v0
	.section	.data.rel.local.DW.ref.__gnat_personality_v0,"awG",@progbits,DW.ref.__gnat_personality_v0,comdat
	.align 8
	.type	DW.ref.__gnat_personality_v0, @object
	.size	DW.ref.__gnat_personality_v0, 8
DW.ref.__gnat_personality_v0:
	.quad	__gnat_personality_v0
	.globl	__gnat_personality_v0
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
