	.file	"silver_report_projection_types.ads"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_report_projection_types.ads"
	.align 2
	.globl	silver_report_projection_types__position_kindH
	.type	silver_report_projection_types__position_kindH, @function
silver_report_projection_types__position_kindH:
.LFB1:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	movq	-8(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L2
	movl	%edx, %ecx
	subl	%eax, %ecx
	leal	1(%rcx), %r11d
	jmp	.L3
.L2:
	movl	$0, %r11d
.L3:
	movslq	%eax, %r9
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	leal	-1(%rax), %r10d
	movl	$0, %ecx
	movl	$0, %edx
	movl	$0, %eax
.L11:
	cmpl	$1, %eax
	jg	.L10
	movslq	%eax, %rsi
	leaq	0(,%rsi,4), %rdi
	leaq	position_kindP.19(%rip), %rsi
	movl	(%rdi,%rsi), %esi
	cmpl	%esi, %r11d
	jl	.L10
	movq	-16(%rbp), %rsi
	movslq	%eax, %rdi
	leaq	0(,%rdi,4), %r8
	leaq	position_kindP.19(%rip), %rdi
	movl	(%r8,%rdi), %edi
	addl	%r10d, %edi
	movslq	%edi, %rdi
	subq	%r9, %rdi
	movzbl	(%rsi,%rdi), %esi
	movzbl	%sil, %r8d
	movslq	%eax, %rsi
	leaq	position_kindT1.18(%rip), %rdi
	movzbl	(%rsi,%rdi), %esi
	movzbl	%sil, %esi
	imull	%r8d, %esi
	leal	(%rcx,%rsi), %edi
	movslq	%edi, %rcx
	imulq	$2021161081, %rcx, %rcx
	shrq	$32, %rcx
	sarl	$3, %ecx
	movl	%edi, %esi
	sarl	$31, %esi
	subl	%esi, %ecx
	movl	%ecx, %esi
	sall	$4, %esi
	addl	%ecx, %esi
	movl	%edi, %ecx
	subl	%esi, %ecx
	movslq	%eax, %rsi
	leaq	position_kindT2.17(%rip), %rdi
	movzbl	(%rsi,%rdi), %esi
	movzbl	%sil, %esi
	imull	%r8d, %esi
	leal	(%rdx,%rsi), %edi
	movslq	%edi, %rdx
	imulq	$2021161081, %rdx, %rdx
	shrq	$32, %rdx
	sarl	$3, %edx
	movl	%edi, %esi
	sarl	$31, %esi
	subl	%esi, %edx
	movl	%edx, %esi
	sall	$4, %esi
	addl	%edx, %esi
	movl	%edi, %edx
	subl	%esi, %edx
	addl	$1, %eax
	jmp	.L11
.L10:
	movslq	%ecx, %rax
	leaq	position_kindG.16(%rip), %rcx
	movzbl	(%rax,%rcx), %ecx
	movslq	%edx, %rax
	leaq	position_kindG.16(%rip), %rdx
	movzbl	(%rax,%rdx), %eax
	addl	%ecx, %eax
	movzbl	%al, %eax
	andl	$7, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1:
	.size	silver_report_projection_types__position_kindH, .-silver_report_projection_types__position_kindH
	.align 2
	.globl	silver_report_projection_types__role_kindH
	.type	silver_report_projection_types__role_kindH, @function
silver_report_projection_types__role_kindH:
.LFB2:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	movq	-8(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L14
	movl	%edx, %ecx
	subl	%eax, %ecx
	leal	1(%rcx), %r11d
	jmp	.L15
.L14:
	movl	$0, %r11d
.L15:
	movslq	%eax, %r9
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	leal	-1(%rax), %r10d
	movl	$0, %ecx
	movl	$0, %edx
	movl	$0, %eax
.L23:
	testl	%eax, %eax
	jg	.L22
	movslq	%eax, %rsi
	leaq	0(,%rsi,4), %rdi
	leaq	role_kindP.15(%rip), %rsi
	movl	(%rdi,%rsi), %esi
	cmpl	%esi, %r11d
	jl	.L22
	movq	-16(%rbp), %rsi
	movslq	%eax, %rdi
	leaq	0(,%rdi,4), %r8
	leaq	role_kindP.15(%rip), %rdi
	movl	(%r8,%rdi), %edi
	addl	%r10d, %edi
	movslq	%edi, %rdi
	subq	%r9, %rdi
	movzbl	(%rsi,%rdi), %esi
	movzbl	%sil, %r8d
	movslq	%eax, %rsi
	leaq	role_kindT1.14(%rip), %rdi
	movzbl	(%rsi,%rdi), %esi
	movzbl	%sil, %esi
	imull	%r8d, %esi
	leal	(%rcx,%rsi), %edi
	movslq	%edi, %rcx
	imulq	$954437177, %rcx, %rcx
	shrq	$32, %rcx
	sarl	%ecx
	movl	%edi, %esi
	sarl	$31, %esi
	subl	%esi, %ecx
	movl	%ecx, %esi
	sall	$3, %esi
	addl	%ecx, %esi
	movl	%edi, %ecx
	subl	%esi, %ecx
	movslq	%eax, %rsi
	leaq	role_kindT2.13(%rip), %rdi
	movzbl	(%rsi,%rdi), %esi
	movzbl	%sil, %esi
	imull	%r8d, %esi
	leal	(%rdx,%rsi), %edi
	movslq	%edi, %rdx
	imulq	$954437177, %rdx, %rdx
	shrq	$32, %rdx
	sarl	%edx
	movl	%edi, %esi
	sarl	$31, %esi
	subl	%esi, %edx
	movl	%edx, %esi
	sall	$3, %esi
	addl	%edx, %esi
	movl	%edi, %edx
	subl	%esi, %edx
	addl	$1, %eax
	jmp	.L23
.L22:
	movslq	%ecx, %rax
	leaq	role_kindG.12(%rip), %rcx
	movzbl	(%rax,%rcx), %ecx
	movslq	%edx, %rax
	leaq	role_kindG.12(%rip), %rdx
	movzbl	(%rax,%rdx), %eax
	addl	%ecx, %eax
	movzbl	%al, %eax
	andl	$3, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	silver_report_projection_types__role_kindH, .-silver_report_projection_types__role_kindH
	.align 2
	.globl	silver_report_projection_types__key_kindH
	.type	silver_report_projection_types__key_kindH, @function
silver_report_projection_types__key_kindH:
.LFB3:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	movq	-8(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L26
	movl	%edx, %ecx
	subl	%eax, %ecx
	leal	1(%rcx), %r11d
	jmp	.L27
.L26:
	movl	$0, %r11d
.L27:
	movslq	%eax, %r9
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	leal	-1(%rax), %r10d
	movl	$0, %esi
	movl	$0, %ecx
	movl	$0, %edx
.L35:
	testl	%edx, %edx
	jg	.L34
	movslq	%edx, %rax
	leaq	0(,%rax,4), %rdi
	leaq	key_kindP.11(%rip), %rax
	movl	(%rdi,%rax), %eax
	cmpl	%eax, %r11d
	jl	.L34
	movq	-16(%rbp), %rax
	movslq	%edx, %rdi
	leaq	0(,%rdi,4), %r8
	leaq	key_kindP.11(%rip), %rdi
	movl	(%r8,%rdi), %edi
	addl	%r10d, %edi
	movslq	%edi, %rdi
	subq	%r9, %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %r8d
	movslq	%edx, %rax
	leaq	key_kindT1.10(%rip), %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %eax
	imull	%r8d, %eax
	leal	(%rsi,%rax), %edi
	movslq	%edi, %rax
	imulq	$780903145, %rax, %rax
	shrq	$32, %rax
	movl	%eax, %esi
	sarl	%esi
	movl	%edi, %eax
	sarl	$31, %eax
	subl	%eax, %esi
	movl	%esi, %eax
	sall	$2, %eax
	addl	%esi, %eax
	addl	%eax, %eax
	addl	%esi, %eax
	movl	%edi, %esi
	subl	%eax, %esi
	movslq	%edx, %rax
	leaq	key_kindT2.9(%rip), %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %eax
	imull	%r8d, %eax
	leal	(%rcx,%rax), %edi
	movslq	%edi, %rax
	imulq	$780903145, %rax, %rax
	shrq	$32, %rax
	movl	%eax, %ecx
	sarl	%ecx
	movl	%edi, %eax
	sarl	$31, %eax
	subl	%eax, %ecx
	movl	%ecx, %eax
	sall	$2, %eax
	addl	%ecx, %eax
	addl	%eax, %eax
	addl	%ecx, %eax
	movl	%edi, %ecx
	subl	%eax, %ecx
	addl	$1, %edx
	jmp	.L35
.L34:
	movslq	%esi, %rax
	leaq	key_kindG.8(%rip), %rdx
	movzbl	(%rax,%rdx), %esi
	movslq	%ecx, %rax
	leaq	key_kindG.8(%rip), %rdx
	movzbl	(%rax,%rdx), %eax
	addl	%esi, %eax
	movzbl	%al, %eax
	andl	$3, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.size	silver_report_projection_types__key_kindH, .-silver_report_projection_types__key_kindH
	.align 2
	.globl	silver_report_projection_types__lexical_modeH
	.type	silver_report_projection_types__lexical_modeH, @function
silver_report_projection_types__lexical_modeH:
.LFB4:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	movq	-8(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L38
	movl	%edx, %ecx
	subl	%eax, %ecx
	leal	1(%rcx), %r11d
	jmp	.L39
.L38:
	movl	$0, %r11d
.L39:
	movslq	%eax, %r9
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	leal	-1(%rax), %r10d
	movl	$0, %ecx
	movl	$0, %edx
	movl	$0, %eax
.L47:
	testl	%eax, %eax
	jg	.L46
	movslq	%eax, %rsi
	leaq	0(,%rsi,4), %rdi
	leaq	lexical_modeP.7(%rip), %rsi
	movl	(%rdi,%rsi), %esi
	cmpl	%esi, %r11d
	jl	.L46
	movq	-16(%rbp), %rsi
	movslq	%eax, %rdi
	leaq	0(,%rdi,4), %r8
	leaq	lexical_modeP.7(%rip), %rdi
	movl	(%r8,%rdi), %edi
	addl	%r10d, %edi
	movslq	%edi, %rdi
	subq	%r9, %rdi
	movzbl	(%rsi,%rdi), %esi
	movzbl	%sil, %r8d
	movslq	%eax, %rsi
	leaq	lexical_modeT1.6(%rip), %rdi
	movzbl	(%rsi,%rdi), %esi
	movzbl	%sil, %esi
	imull	%r8d, %esi
	addl	%ecx, %esi
	movslq	%esi, %rcx
	imulq	$-2004318071, %rcx, %rcx
	shrq	$32, %rcx
	addl	%esi, %ecx
	sarl	$3, %ecx
	movl	%esi, %edi
	sarl	$31, %edi
	subl	%edi, %ecx
	movl	%ecx, %edi
	sall	$4, %edi
	subl	%ecx, %edi
	movl	%esi, %ecx
	subl	%edi, %ecx
	movslq	%eax, %rsi
	leaq	lexical_modeT2.5(%rip), %rdi
	movzbl	(%rsi,%rdi), %esi
	movzbl	%sil, %esi
	imull	%r8d, %esi
	addl	%edx, %esi
	movslq	%esi, %rdx
	imulq	$-2004318071, %rdx, %rdx
	shrq	$32, %rdx
	addl	%esi, %edx
	sarl	$3, %edx
	movl	%esi, %edi
	sarl	$31, %edi
	subl	%edi, %edx
	movl	%edx, %edi
	sall	$4, %edi
	subl	%edx, %edi
	movl	%esi, %edx
	subl	%edi, %edx
	addl	$1, %eax
	jmp	.L47
.L46:
	movslq	%ecx, %rax
	leaq	lexical_modeG.4(%rip), %rcx
	movzbl	(%rax,%rcx), %eax
	movzbl	%al, %ecx
	movslq	%edx, %rax
	leaq	lexical_modeG.4(%rip), %rdx
	movzbl	(%rax,%rdx), %eax
	movzbl	%al, %eax
	addl	%eax, %ecx
	movslq	%ecx, %rax
	imulq	$715827883, %rax, %rax
	shrq	$32, %rax
	movq	%rax, %rdx
	movl	%ecx, %eax
	sarl	$31, %eax
	subl	%eax, %edx
	movl	%edx, %eax
	addl	%eax, %eax
	addl	%edx, %eax
	addl	%eax, %eax
	subl	%eax, %ecx
	movl	%ecx, %edx
	movl	%edx, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	silver_report_projection_types__lexical_modeH, .-silver_report_projection_types__lexical_modeH
	.align 2
	.globl	silver_report_projection_types__number_positionH
	.type	silver_report_projection_types__number_positionH, @function
silver_report_projection_types__number_positionH:
.LFB5:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	movq	-8(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L50
	movl	%edx, %ecx
	subl	%eax, %ecx
	leal	1(%rcx), %r11d
	jmp	.L51
.L50:
	movl	$0, %r11d
.L51:
	movslq	%eax, %r9
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	leal	-1(%rax), %r10d
	movl	$0, %esi
	movl	$0, %ecx
	movl	$0, %eax
.L59:
	cmpl	$1, %eax
	jg	.L58
	movslq	%eax, %rdx
	leaq	0(,%rdx,4), %rdi
	leaq	number_positionP.3(%rip), %rdx
	movl	(%rdi,%rdx), %edx
	cmpl	%edx, %r11d
	jl	.L58
	movq	-16(%rbp), %rdx
	movslq	%eax, %rdi
	leaq	0(,%rdi,4), %r8
	leaq	number_positionP.3(%rip), %rdi
	movl	(%r8,%rdi), %edi
	addl	%r10d, %edi
	movslq	%edi, %rdi
	subq	%r9, %rdi
	movzbl	(%rdx,%rdi), %edx
	movzbl	%dl, %r8d
	movslq	%eax, %rdx
	leaq	number_positionT1.2(%rip), %rdi
	movzbl	(%rdx,%rdi), %edx
	movzbl	%dl, %edx
	imull	%r8d, %edx
	leal	(%rsi,%rdx), %edi
	movslq	%edi, %rdx
	imulq	$1717986919, %rdx, %rdx
	shrq	$32, %rdx
	movl	%edx, %esi
	sarl	$3, %esi
	movl	%edi, %edx
	sarl	$31, %edx
	subl	%edx, %esi
	movl	%esi, %edx
	sall	$2, %edx
	addl	%esi, %edx
	sall	$2, %edx
	movl	%edi, %esi
	subl	%edx, %esi
	movslq	%eax, %rdx
	leaq	number_positionT2.1(%rip), %rdi
	movzbl	(%rdx,%rdi), %edx
	movzbl	%dl, %edx
	imull	%r8d, %edx
	leal	(%rcx,%rdx), %edi
	movslq	%edi, %rdx
	imulq	$1717986919, %rdx, %rdx
	shrq	$32, %rdx
	movl	%edx, %ecx
	sarl	$3, %ecx
	movl	%edi, %edx
	sarl	$31, %edx
	subl	%edx, %ecx
	movl	%ecx, %edx
	sall	$2, %edx
	addl	%ecx, %edx
	sall	$2, %edx
	movl	%edi, %ecx
	subl	%edx, %ecx
	addl	$1, %eax
	jmp	.L59
.L58:
	movslq	%esi, %rax
	leaq	number_positionG.0(%rip), %rdx
	movzbl	(%rax,%rdx), %esi
	movslq	%ecx, %rax
	leaq	number_positionG.0(%rip), %rdx
	movzbl	(%rax,%rdx), %eax
	addl	%esi, %eax
	movzbl	%al, %eax
	andl	$7, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE5:
	.size	silver_report_projection_types__number_positionH, .-silver_report_projection_types__number_positionH
	.align 2
	.globl	silver_report_projection_types__frameIP
	.type	silver_report_projection_types__frameIP, @function
silver_report_projection_types__frameIP:
.LFB6:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movb	$0, -10(%rbp)
	movb	$0, -9(%rbp)
	movb	$0, -8(%rbp)
	movb	$0, -7(%rbp)
	movb	$1, -6(%rbp)
	movl	-10(%rbp), %eax
	movl	%eax, -5(%rbp)
	movzbl	-6(%rbp), %eax
	movb	%al, -1(%rbp)
	movl	$0, %eax
	movl	-5(%rbp), %edx
	movl	%edx, %edx
	movabsq	$-4294967296, %rcx
	andq	%rcx, %rax
	orq	%rdx, %rax
	movzbl	-1(%rbp), %edx
	movzbl	%dl, %edx
	salq	$32, %rdx
	movabsq	$-1095216660481, %rcx
	andq	%rcx, %rax
	orq	%rdx, %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE6:
	.size	silver_report_projection_types__frameIP, .-silver_report_projection_types__frameIP
	.align 2
	.globl	silver_report_projection_types__TframesBIP
	.type	silver_report_projection_types__TframesBIP, @function
silver_report_projection_types__TframesBIP:
.LFB7:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$16, %rsp
	.cfi_offset 14, -24
	.cfi_offset 13, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -48(%rbp)
	movq	%rdx, -40(%rbp)
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	movslq	%eax, %r14
	movq	-40(%rbp), %rax
	movl	4(%rax), %edx
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	movq	-40(%rbp), %rax
	movl	4(%rax), %edx
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L66
	movq	-40(%rbp), %rax
	movl	4(%rax), %eax
	movslq	%eax, %rdx
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	cltq
	subq	%rax, %rdx
	leaq	1(%rdx), %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rcx, %rax
	movq	%rbx, %rdx
	shldq	$2, %rax, %rdx
	salq	$2, %rax
	addq	%rcx, %rax
	adcq	%rbx, %rdx
	shldq	$3, %rax, %rdx
	salq	$3, %rax
.L66:
	movq	-40(%rbp), %rax
	movl	4(%rax), %edx
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	movq	-40(%rbp), %rax
	movl	(%rax), %r12d
	movq	-40(%rbp), %rax
	movl	4(%rax), %r13d
	cmpl	%r13d, %r12d
	jg	.L71
.L70:
	movq	-48(%rbp), %rcx
	movslq	%r12d, %rax
	subq	%r14, %rax
	movq	%rax, %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	leaq	(%rcx,%rax), %rbx
	call	silver_report_projection_types__frameIP
	movb	%al, (%rbx)
	movzbl	%ah, %edx
	movb	%dl, 1(%rbx)
	movq	%rax, %rdx
	shrq	$16, %rdx
	andb	$-1, %dh
	movb	%dl, 2(%rbx)
	movq	%rax, %rdx
	shrq	$24, %rdx
	andb	$-1, %dh
	movb	%dl, 3(%rbx)
	shrq	$32, %rax
	andb	$-1, %ah
	movb	%al, 4(%rbx)
	cmpl	%r13d, %r12d
	je	.L71
	addl	$1, %r12d
	jmp	.L70
.L71:
	addq	$16, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE7:
	.size	silver_report_projection_types__TframesBIP, .-silver_report_projection_types__TframesBIP
	.section	.rodata
	.align 8
.LC0:
	.long	1
	.long	64
	.text
	.align 2
	.globl	silver_report_projection_types__stateIP
	.type	silver_report_projection_types__stateIP, @function
silver_report_projection_types__stateIP:
.LFB8:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rcx
	movq	%rcx, %rax
	leaq	.LC0(%rip), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_report_projection_types__TframesBIP
	movq	-8(%rbp), %rax
	movl	$0, 320(%rax)
	movq	-8(%rbp), %rax
	movb	$0, 324(%rax)
	movq	-8(%rbp), %rax
	movb	$2, 325(%rax)
	movq	-8(%rbp), %rax
	movb	$0, 326(%rax)
	movq	-8(%rbp), %rax
	movl	$1, 328(%rax)
	movq	-8(%rbp), %rax
	movl	$0, 332(%rax)
	movq	-8(%rbp), %rax
	movb	$0, 336(%rax)
	movq	-8(%rbp), %rax
	movabsq	$2314885530818453536, %rdx
	movq	%rdx, 337(%rax)
	movw	$8224, 345(%rax)
	movq	-8(%rbp), %rax
	movl	$0, 348(%rax)
	movq	-8(%rbp), %rax
	movb	$0, 352(%rax)
	movq	-8(%rbp), %rax
	movb	$1, 353(%rax)
	movq	-8(%rbp), %rax
	movb	$0, 354(%rax)
	movq	-8(%rbp), %rax
	movb	$0, 355(%rax)
	movq	-8(%rbp), %rax
	movb	$0, 356(%rax)
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE8:
	.size	silver_report_projection_types__stateIP, .-silver_report_projection_types__stateIP
	.align 2
	.globl	silver_report_projection_types__transitionIP
	.type	silver_report_projection_types__transitionIP, @function
silver_report_projection_types__transitionIP:
.LFB9:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	silver_report_projection_types__stateIP
	movq	-8(%rbp), %rax
	movw	$8224, 360(%rax)
	movq	-8(%rbp), %rax
	movl	$0, 364(%rax)
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE9:
	.size	silver_report_projection_types__transitionIP, .-silver_report_projection_types__transitionIP
	.align 2
	.globl	silver_report_projection_types___elabs
	.type	silver_report_projection_types___elabs, @function
silver_report_projection_types___elabs:
.LFB0:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_report_projection_types.ads"
	.loc 1 2 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	.loc 1 42 38
	leaq	silver_report_projection_types__initial_state(%rip), %rax
	leaq	.LC0(%rip), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_report_projection_types__TframesBIP
	.loc 1 42 38 is_stmt 0 discriminator 1
	movl	$0, 320+silver_report_projection_types__initial_state(%rip)
	movb	$0, 324+silver_report_projection_types__initial_state(%rip)
	movb	$2, 325+silver_report_projection_types__initial_state(%rip)
	movb	$0, 326+silver_report_projection_types__initial_state(%rip)
	movl	$1, 328+silver_report_projection_types__initial_state(%rip)
	movl	$0, 332+silver_report_projection_types__initial_state(%rip)
	movb	$0, 336+silver_report_projection_types__initial_state(%rip)
	movabsq	$2314885530818453536, %rax
	movq	%rax, 337+silver_report_projection_types__initial_state(%rip)
	movw	$8224, 345+silver_report_projection_types__initial_state(%rip)
	movl	$0, 348+silver_report_projection_types__initial_state(%rip)
	movb	$0, 352+silver_report_projection_types__initial_state(%rip)
	movb	$1, 353+silver_report_projection_types__initial_state(%rip)
	movb	$0, 354+silver_report_projection_types__initial_state(%rip)
	movb	$0, 355+silver_report_projection_types__initial_state(%rip)
	movb	$0, 356+silver_report_projection_types__initial_state(%rip)
	.loc 1 51 5 is_stmt 1
	nop
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE0:
	.size	silver_report_projection_types___elabs, .-silver_report_projection_types___elabs
	.globl	silver_report_projection_types_E
	.data
	.align 2
	.type	silver_report_projection_types_E, @object
	.size	silver_report_projection_types_E, 2
silver_report_projection_types_E:
	.zero	2
	.globl	silver_report_projection_types__max_depth
	.section	.rodata
	.align 4
	.type	silver_report_projection_types__max_depth, @object
	.size	silver_report_projection_types__max_depth, 4
silver_report_projection_types__max_depth:
	.long	64
	.globl	silver_report_projection_types__container_kindS
	.align 16
	.type	silver_report_projection_types__container_kindS, @object
	.size	silver_report_projection_types__container_kindS, 31
silver_report_projection_types__container_kindS:
	.ascii	"OBJECT_CONTAINERARRAY_CONTAINER"
	.globl	silver_report_projection_types__container_kindN
	.align 4
	.type	silver_report_projection_types__container_kindN, @object
	.size	silver_report_projection_types__container_kindN, 4
silver_report_projection_types__container_kindN:
	.byte	1
	.byte	17
	.byte	32
	.zero	1
	.globl	silver_report_projection_types__position_kindS
	.align 32
	.type	silver_report_projection_types__position_kindS, @object
	.size	silver_report_projection_types__position_kindS, 84
silver_report_projection_types__position_kindS:
	.ascii	"FIRST_KEYNEXT_KEYCOLONOBJECT_VALUEOBJECT_SEPARATORFIRST_ITEM"
	.ascii	"NEXT_ITEMARRAY_SEPARATOR"
	.globl	silver_report_projection_types__position_kindN
	.align 16
	.type	silver_report_projection_types__position_kindN, @object
	.size	silver_report_projection_types__position_kindN, 16
silver_report_projection_types__position_kindN:
	.byte	1
	.byte	10
	.byte	18
	.byte	23
	.byte	35
	.byte	51
	.byte	61
	.byte	70
	.byte	85
	.zero	7
	.globl	silver_report_projection_types__role_kindS
	.align 32
	.type	silver_report_projection_types__role_kindS, @object
	.size	silver_report_projection_types__role_kindS, 41
silver_report_projection_types__role_kindS:
	.ascii	"ORDINARYROOT_OBJECTCHECK_LISTCHECK_RECORD"
	.globl	silver_report_projection_types__role_kindN
	.align 8
	.type	silver_report_projection_types__role_kindN, @object
	.size	silver_report_projection_types__role_kindN, 8
silver_report_projection_types__role_kindN:
	.byte	1
	.byte	9
	.byte	20
	.byte	30
	.byte	42
	.zero	3
	.globl	silver_report_projection_types__key_kindS
	.align 32
	.type	silver_report_projection_types__key_kindS, @object
	.size	silver_report_projection_types__key_kindS, 34
silver_report_projection_types__key_kindS:
	.ascii	"OTHER_KEYFLOW_KEYPROOF_KEYTREE_KEY"
	.globl	silver_report_projection_types__key_kindN
	.align 8
	.type	silver_report_projection_types__key_kindN, @object
	.size	silver_report_projection_types__key_kindN, 8
silver_report_projection_types__key_kindN:
	.byte	1
	.byte	10
	.byte	18
	.byte	27
	.byte	35
	.zero	3
	.globl	silver_report_projection_types__lexical_modeS
	.align 32
	.type	silver_report_projection_types__lexical_modeS, @object
	.size	silver_report_projection_types__lexical_modeS, 68
silver_report_projection_types__lexical_modeS:
	.ascii	"BETWEEN_TOKENSIN_STRINGAFTER_ESCAPEUNICODE_ESCAPEIN_NUMBERIN"
	.ascii	"_LITERAL"
	.globl	silver_report_projection_types__lexical_modeN
	.align 8
	.type	silver_report_projection_types__lexical_modeN, @object
	.size	silver_report_projection_types__lexical_modeN, 8
silver_report_projection_types__lexical_modeN:
	.byte	1
	.byte	15
	.byte	24
	.byte	36
	.byte	50
	.byte	59
	.byte	69
	.zero	1
	.globl	silver_report_projection_types__number_positionS
	.align 32
	.type	silver_report_projection_types__number_positionS, @object
	.size	silver_report_projection_types__number_positionS, 107
silver_report_projection_types__number_positionS:
	.ascii	"AFTER_MINUSAFTER_ZEROINTEGER_DIGITSAFTER_DOTFRACTION_DIGITSA"
	.ascii	"FTER_EXPONENTAFTER_EXPONENT_SIGNEXPONENT_DIGITS"
	.globl	silver_report_projection_types__number_positionN
	.align 16
	.type	silver_report_projection_types__number_positionN, @object
	.size	silver_report_projection_types__number_positionN, 16
silver_report_projection_types__number_positionN:
	.byte	1
	.byte	12
	.byte	22
	.byte	36
	.byte	45
	.byte	60
	.byte	74
	.byte	93
	.byte	108
	.zero	7
	.globl	silver_report_projection_types__literal_kindS
	.align 32
	.type	silver_report_projection_types__literal_kindS, @object
	.size	silver_report_projection_types__literal_kindS, 37
silver_report_projection_types__literal_kindS:
	.ascii	"TRUE_LITERALFALSE_LITERALNULL_LITERAL"
	.globl	silver_report_projection_types__literal_kindN
	.align 4
	.type	silver_report_projection_types__literal_kindN, @object
	.size	silver_report_projection_types__literal_kindN, 4
silver_report_projection_types__literal_kindN:
	.byte	1
	.byte	13
	.byte	26
	.byte	38
	.globl	silver_report_projection_types__initial_state
	.bss
	.align 32
	.type	silver_report_projection_types__initial_state, @object
	.size	silver_report_projection_types__initial_state, 360
silver_report_projection_types__initial_state:
	.zero	360
	.section	.rodata
	.align 8
	.type	position_kindP.19, @object
	.size	position_kindP.19, 8
position_kindP.19:
	.long	1
	.long	8
	.align 2
	.type	position_kindT1.18, @object
	.size	position_kindT1.18, 2
position_kindT1.18:
	.byte	16
	.byte	1
	.align 2
	.type	position_kindT2.17, @object
	.size	position_kindT2.17, 2
position_kindT2.17:
	.byte	15
	.byte	8
	.align 16
	.type	position_kindG.16, @object
	.size	position_kindG.16, 17
position_kindG.16:
	.byte	0
	.byte	0
	.byte	2
	.byte	0
	.byte	0
	.byte	6
	.byte	0
	.byte	3
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	1
	.byte	4
	.byte	7
	.byte	0
	.byte	0
	.align 4
	.type	role_kindP.15, @object
	.size	role_kindP.15, 4
role_kindP.15:
	.long	8
	.type	role_kindT1.14, @object
	.size	role_kindT1.14, 1
role_kindT1.14:
	.byte	4
	.type	role_kindT2.13, @object
	.size	role_kindT2.13, 1
role_kindT2.13:
	.byte	6
	.align 16
	.type	role_kindG.12, @object
	.size	role_kindG.12, 16
role_kindG.12:
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.byte	0
	.byte	1
	.zero	7
	.align 4
	.type	key_kindP.11, @object
	.size	key_kindP.11, 4
key_kindP.11:
	.long	1
	.type	key_kindT1.10, @object
	.size	key_kindT1.10, 1
key_kindT1.10:
	.byte	3
	.type	key_kindT2.9, @object
	.size	key_kindT2.9, 1
key_kindT2.9:
	.byte	9
	.align 16
	.type	key_kindG.8, @object
	.size	key_kindG.8, 16
key_kindG.8:
	.byte	0
	.byte	0
	.byte	0
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.byte	3
	.zero	5
	.align 4
	.type	lexical_modeP.7, @object
	.size	lexical_modeP.7, 4
lexical_modeP.7:
	.long	4
	.type	lexical_modeT1.6, @object
	.size	lexical_modeT1.6, 1
lexical_modeT1.6:
	.byte	5
	.type	lexical_modeT2.5, @object
	.size	lexical_modeT2.5, 1
lexical_modeT2.5:
	.byte	1
	.align 16
	.type	lexical_modeG.4, @object
	.size	lexical_modeG.4, 16
lexical_modeG.4:
	.byte	0
	.byte	5
	.byte	0
	.byte	4
	.byte	0
	.byte	0
	.byte	0
	.byte	3
	.byte	0
	.byte	2
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.zero	1
	.align 8
	.type	number_positionP.3, @object
	.size	number_positionP.3, 8
number_positionP.3:
	.long	7
	.long	15
	.align 2
	.type	number_positionT1.2, @object
	.size	number_positionT1.2, 2
number_positionT1.2:
	.byte	16
	.byte	10
	.align 2
	.type	number_positionT2.1, @object
	.size	number_positionT2.1, 2
number_positionT2.1:
	.byte	3
	.byte	7
	.align 16
	.type	number_positionG.0, @object
	.size	number_positionG.0, 20
number_positionG.0:
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.byte	5
	.byte	3
	.byte	0
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	6
	.byte	1
	.byte	0
	.byte	0
	.byte	6
	.byte	0
	.text
.Letext0:
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x312
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x9
	.long	.LASF72
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.quad	.Ltext0
	.quad	.Letext0-.Ltext0
	.long	.Ldebug_line0
	.uleb128 0x6
	.long	.LASF70
	.byte	0x3
	.long	0x50
	.uleb128 0x9
	.byte	0x3
	.quad	silver_report_projection_types__max_depth
	.uleb128 0xa
	.sleb128 2147483647
	.long	.LASF73
	.long	0x55
	.uleb128 0xb
	.long	0x42
	.uleb128 0x5
	.byte	0x4
	.byte	0x5
	.long	.LASF50
	.uleb128 0x7
	.sleb128 64
	.long	.LASF24
	.long	0x55
	.uleb128 0x3
	.long	.LASF4
	.byte	0x5
	.long	0x7e
	.uleb128 0x1
	.long	.LASF2
	.byte	0
	.uleb128 0x1
	.long	.LASF3
	.byte	0x1
	.byte	0
	.uleb128 0x3
	.long	.LASF5
	.byte	0x6
	.long	0xb9
	.uleb128 0x1
	.long	.LASF6
	.byte	0
	.uleb128 0x1
	.long	.LASF7
	.byte	0x1
	.uleb128 0x1
	.long	.LASF8
	.byte	0x2
	.uleb128 0x1
	.long	.LASF9
	.byte	0x3
	.uleb128 0x1
	.long	.LASF10
	.byte	0x4
	.uleb128 0x1
	.long	.LASF11
	.byte	0x5
	.uleb128 0x1
	.long	.LASF12
	.byte	0x6
	.uleb128 0x1
	.long	.LASF13
	.byte	0x7
	.byte	0
	.uleb128 0x3
	.long	.LASF14
	.byte	0x9
	.long	0xdc
	.uleb128 0x1
	.long	.LASF15
	.byte	0
	.uleb128 0x1
	.long	.LASF16
	.byte	0x1
	.uleb128 0x1
	.long	.LASF17
	.byte	0x2
	.uleb128 0x1
	.long	.LASF18
	.byte	0x3
	.byte	0
	.uleb128 0x3
	.long	.LASF19
	.byte	0xa
	.long	0xff
	.uleb128 0x1
	.long	.LASF20
	.byte	0
	.uleb128 0x1
	.long	.LASF21
	.byte	0x1
	.uleb128 0x1
	.long	.LASF22
	.byte	0x2
	.uleb128 0x1
	.long	.LASF23
	.byte	0x3
	.byte	0
	.uleb128 0x7
	.sleb128 11
	.long	.LASF25
	.long	0x55
	.uleb128 0x3
	.long	.LASF26
	.byte	0x13
	.long	0x138
	.uleb128 0x1
	.long	.LASF27
	.byte	0
	.uleb128 0x1
	.long	.LASF28
	.byte	0x1
	.uleb128 0x1
	.long	.LASF29
	.byte	0x2
	.uleb128 0x1
	.long	.LASF30
	.byte	0x3
	.uleb128 0x1
	.long	.LASF31
	.byte	0x4
	.uleb128 0x1
	.long	.LASF32
	.byte	0x5
	.byte	0
	.uleb128 0x3
	.long	.LASF33
	.byte	0x16
	.long	0x173
	.uleb128 0x1
	.long	.LASF34
	.byte	0
	.uleb128 0x1
	.long	.LASF35
	.byte	0x1
	.uleb128 0x1
	.long	.LASF36
	.byte	0x2
	.uleb128 0x1
	.long	.LASF37
	.byte	0x3
	.uleb128 0x1
	.long	.LASF38
	.byte	0x4
	.uleb128 0x1
	.long	.LASF39
	.byte	0x5
	.uleb128 0x1
	.long	.LASF40
	.byte	0x6
	.uleb128 0x1
	.long	.LASF41
	.byte	0x7
	.byte	0
	.uleb128 0x3
	.long	.LASF42
	.byte	0x19
	.long	0x190
	.uleb128 0x1
	.long	.LASF43
	.byte	0
	.uleb128 0x1
	.long	.LASF44
	.byte	0x1
	.uleb128 0x1
	.long	.LASF45
	.byte	0x2
	.byte	0
	.uleb128 0xc
	.long	.LASF52
	.byte	0x5
	.byte	0x1
	.byte	0xb
	.byte	0x9
	.long	0x1d7
	.uleb128 0x4
	.long	.LASF46
	.byte	0xc
	.long	0x67
	.byte	0
	.uleb128 0x4
	.long	.LASF47
	.byte	0xd
	.long	0x7e
	.byte	0x1
	.uleb128 0x4
	.long	.LASF48
	.byte	0xe
	.long	0xb9
	.byte	0x2
	.uleb128 0xd
	.string	"key"
	.byte	0x1
	.byte	0xf
	.byte	0x7
	.long	0xdc
	.byte	0x3
	.uleb128 0x4
	.long	.LASF49
	.byte	0x10
	.long	0x1d7
	.byte	0x4
	.byte	0
	.uleb128 0x5
	.byte	0x1
	.byte	0x2
	.long	.LASF51
	.uleb128 0xe
	.long	.LASF74
	.long	0x190
	.long	0x1f3
	.uleb128 0x8
	.long	0x55
	.sleb128 64
	.byte	0
	.uleb128 0xf
	.long	.LASF53
	.value	0x168
	.byte	0x1
	.byte	0x1b
	.byte	0x9
	.long	0x2e0
	.uleb128 0x4
	.long	.LASF54
	.byte	0x1c
	.long	0x1de
	.byte	0
	.uleb128 0x2
	.long	.LASF55
	.byte	0x1d
	.byte	0x7
	.long	0x5c
	.value	0x140
	.uleb128 0x2
	.long	.LASF56
	.byte	0x1e
	.byte	0x7
	.long	0x109
	.value	0x144
	.uleb128 0x2
	.long	.LASF57
	.byte	0x1f
	.byte	0x7
	.long	0x138
	.value	0x145
	.uleb128 0x2
	.long	.LASF58
	.byte	0x20
	.byte	0x7
	.long	0x173
	.value	0x146
	.uleb128 0x2
	.long	.LASF59
	.byte	0x21
	.byte	0x7
	.long	0x24d
	.value	0x148
	.uleb128 0x10
	.sleb128 5
	.long	0x55
	.uleb128 0x2
	.long	.LASF60
	.byte	0x22
	.byte	0x7
	.long	0x260
	.value	0x14c
	.uleb128 0x11
	.sleb128 0
	.sleb128 4
	.long	0x55
	.uleb128 0x2
	.long	.LASF61
	.byte	0x23
	.byte	0x7
	.long	0x1d7
	.value	0x150
	.uleb128 0x12
	.long	0x2e0
	.long	0x284
	.uleb128 0x8
	.long	0x55
	.sleb128 10
	.byte	0
	.uleb128 0x2
	.long	.LASF62
	.byte	0x24
	.byte	0x7
	.long	0x274
	.value	0x151
	.uleb128 0x2
	.long	.LASF63
	.byte	0x25
	.byte	0x7
	.long	0xff
	.value	0x15c
	.uleb128 0x2
	.long	.LASF64
	.byte	0x26
	.byte	0x7
	.long	0x1d7
	.value	0x160
	.uleb128 0x2
	.long	.LASF65
	.byte	0x27
	.byte	0x7
	.long	0x1d7
	.value	0x161
	.uleb128 0x2
	.long	.LASF66
	.byte	0x28
	.byte	0x7
	.long	0x1d7
	.value	0x162
	.uleb128 0x2
	.long	.LASF67
	.byte	0x28
	.byte	0x10
	.long	0x1d7
	.value	0x163
	.uleb128 0x2
	.long	.LASF68
	.byte	0x28
	.byte	0x1a
	.long	0x1d7
	.value	0x164
	.byte	0
	.uleb128 0x5
	.byte	0x1
	.byte	0x8
	.long	.LASF69
	.uleb128 0x6
	.long	.LASF71
	.byte	0x2a
	.long	0x1f3
	.uleb128 0x9
	.byte	0x3
	.quad	silver_report_projection_types__initial_state
	.uleb128 0x13
	.long	.LASF75
	.byte	0x1
	.byte	0x2
	.byte	0x1
	.quad	.LFB0
	.quad	.LFE0-.LFB0
	.uleb128 0x1
	.byte	0x9c
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x28
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x1c
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0x5
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3e
	.uleb128 0x21
	.sleb128 7
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 7
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0x5
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0xd
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x2c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.Letext0-.Ltext0
	.quad	0
	.quad	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF6:
	.string	"silver_report_projection_types__first_key"
.LASF35:
	.string	"silver_report_projection_types__after_zero"
.LASF31:
	.string	"silver_report_projection_types__in_number"
.LASF69:
	.string	"character"
.LASF44:
	.string	"silver_report_projection_types__false_literal"
.LASF21:
	.string	"silver_report_projection_types__flow_key"
.LASF40:
	.string	"silver_report_projection_types__after_exponent_sign"
.LASF52:
	.string	"silver_report_projection_types__frame"
.LASF7:
	.string	"silver_report_projection_types__next_key"
.LASF73:
	.string	"positive"
.LASF66:
	.string	"started"
.LASF58:
	.string	"literal"
.LASF22:
	.string	"silver_report_projection_types__proof_key"
.LASF63:
	.string	"name_length"
.LASF54:
	.string	"stack"
.LASF2:
	.string	"silver_report_projection_types__object_container"
.LASF53:
	.string	"silver_report_projection_types__state"
.LASF29:
	.string	"silver_report_projection_types__after_escape"
.LASF57:
	.string	"number"
.LASF10:
	.string	"silver_report_projection_types__object_separator"
.LASF19:
	.string	"silver_report_projection_types__key_kind"
.LASF49:
	.string	"keep"
.LASF41:
	.string	"silver_report_projection_types__exponent_digits"
.LASF34:
	.string	"silver_report_projection_types__after_minus"
.LASF70:
	.string	"silver_report_projection_types__max_depth"
.LASF67:
	.string	"finished"
.LASF24:
	.string	"silver_report_projection_types__depth_range"
.LASF33:
	.string	"silver_report_projection_types__number_position"
.LASF11:
	.string	"silver_report_projection_types__first_item"
.LASF38:
	.string	"silver_report_projection_types__fraction_digits"
.LASF23:
	.string	"silver_report_projection_types__tree_key"
.LASF13:
	.string	"silver_report_projection_types__array_separator"
.LASF25:
	.string	"silver_report_projection_types__key_length"
.LASF16:
	.string	"silver_report_projection_types__root_object"
.LASF74:
	.string	"silver_report_projection_types__frames"
.LASF28:
	.string	"silver_report_projection_types__in_string"
.LASF26:
	.string	"silver_report_projection_types__lexical_mode"
.LASF47:
	.string	"position"
.LASF30:
	.string	"silver_report_projection_types__unicode_escape"
.LASF8:
	.string	"silver_report_projection_types__colon"
.LASF55:
	.string	"depth"
.LASF20:
	.string	"silver_report_projection_types__other_key"
.LASF3:
	.string	"silver_report_projection_types__array_container"
.LASF43:
	.string	"silver_report_projection_types__true_literal"
.LASF56:
	.string	"mode"
.LASF15:
	.string	"silver_report_projection_types__ordinary"
.LASF59:
	.string	"literal_position"
.LASF4:
	.string	"silver_report_projection_types__container_kind"
.LASF71:
	.string	"silver_report_projection_types__initial_state"
.LASF9:
	.string	"silver_report_projection_types__object_value"
.LASF37:
	.string	"silver_report_projection_types__after_dot"
.LASF39:
	.string	"silver_report_projection_types__after_exponent"
.LASF75:
	.string	"silver_report_projection_types___elabs"
.LASF18:
	.string	"silver_report_projection_types__check_record"
.LASF27:
	.string	"silver_report_projection_types__between_tokens"
.LASF68:
	.string	"failed"
.LASF46:
	.string	"container"
.LASF42:
	.string	"silver_report_projection_types__literal_kind"
.LASF12:
	.string	"silver_report_projection_types__next_item"
.LASF48:
	.string	"role"
.LASF50:
	.string	"integer"
.LASF65:
	.string	"token_keep"
.LASF36:
	.string	"silver_report_projection_types__integer_digits"
.LASF32:
	.string	"silver_report_projection_types__in_literal"
.LASF5:
	.string	"silver_report_projection_types__position_kind"
.LASF64:
	.string	"name_escaped"
.LASF14:
	.string	"silver_report_projection_types__role_kind"
.LASF17:
	.string	"silver_report_projection_types__check_list"
.LASF72:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF51:
	.string	"boolean"
.LASF61:
	.string	"string_is_key"
.LASF62:
	.string	"name"
.LASF60:
	.string	"unicode_left"
.LASF45:
	.string	"silver_report_projection_types__null_literal"
	.section	.debug_line_str,"MS",@progbits,1
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_report_projection_types.ads"
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
