	.file	"silver_library_reports.adb"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_library_reports.adb"
	.align 2
	.globl	silver_library_reports__report_kindH
	.type	silver_library_reports__report_kindH, @function
silver_library_reports__report_kindH:
.LFB2:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	movq	-8(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L2
	movl	%edx, %ecx
	subl	%eax, %ecx
	leal	1(%rcx), %r11d
	jmp	.L3
.L2:
	movl	$0, %r11d
.L3:
	movslq	%eax, %r9
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	leal	-1(%rax), %r10d
	movl	$0, %esi
	movl	$0, %ecx
	movl	$0, %eax
.L11:
	testl	%eax, %eax
	jg	.L10
	movslq	%eax, %rdx
	leaq	0(,%rdx,4), %rdi
	leaq	report_kindP.19(%rip), %rdx
	movl	(%rdi,%rdx), %edx
	cmpl	%edx, %r11d
	jl	.L10
	movq	-16(%rbp), %rdx
	movslq	%eax, %rdi
	leaq	0(,%rdi,4), %r8
	leaq	report_kindP.19(%rip), %rdi
	movl	(%r8,%rdi), %edi
	addl	%r10d, %edi
	movslq	%edi, %rdi
	subq	%r9, %rdi
	movzbl	(%rdx,%rdi), %edx
	movzbl	%dl, %r8d
	movslq	%eax, %rdx
	leaq	report_kindT1.18(%rip), %rdi
	movzbl	(%rdx,%rdi), %edx
	movzbl	%dl, %edx
	imull	%r8d, %edx
	leal	(%rsi,%rdx), %edi
	movslq	%edi, %rdx
	imulq	$715827883, %rdx, %rdx
	shrq	$32, %rdx
	movl	%edx, %esi
	sarl	%esi
	movl	%edi, %edx
	sarl	$31, %edx
	subl	%edx, %esi
	movl	%esi, %edx
	addl	%edx, %edx
	addl	%esi, %edx
	sall	$2, %edx
	movl	%edi, %esi
	subl	%edx, %esi
	movslq	%eax, %rdx
	leaq	report_kindT2.17(%rip), %rdi
	movzbl	(%rdx,%rdi), %edx
	movzbl	%dl, %edx
	imull	%r8d, %edx
	leal	(%rcx,%rdx), %edi
	movslq	%edi, %rdx
	imulq	$715827883, %rdx, %rdx
	shrq	$32, %rdx
	movl	%edx, %ecx
	sarl	%ecx
	movl	%edi, %edx
	sarl	$31, %edx
	subl	%edx, %ecx
	movl	%ecx, %edx
	addl	%edx, %edx
	addl	%ecx, %edx
	sall	$2, %edx
	movl	%edi, %ecx
	subl	%edx, %ecx
	addl	$1, %eax
	jmp	.L11
.L10:
	movslq	%esi, %rax
	leaq	report_kindG.16(%rip), %rdx
	movzbl	(%rax,%rdx), %esi
	movslq	%ecx, %rax
	leaq	report_kindG.16(%rip), %rdx
	movzbl	(%rax,%rdx), %eax
	addl	%esi, %eax
	movzbl	%al, %eax
	andl	$3, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	silver_library_reports__report_kindH, .-silver_library_reports__report_kindH
	.align 2
	.type	silver_library_reports__audit_kindH, @function
silver_library_reports__audit_kindH:
.LFB3:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	movq	-8(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L14
	movl	%edx, %ecx
	subl	%eax, %ecx
	leal	1(%rcx), %r11d
	jmp	.L15
.L14:
	movl	$0, %r11d
.L15:
	movslq	%eax, %r9
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	leal	-1(%rax), %r10d
	movl	$0, %ecx
	movl	$0, %edx
	movl	$0, %eax
.L23:
	cmpl	$4, %eax
	jg	.L22
	movslq	%eax, %rsi
	leaq	0(,%rsi,4), %rdi
	leaq	audit_kindP.15(%rip), %rsi
	movl	(%rdi,%rsi), %esi
	cmpl	%esi, %r11d
	jl	.L22
	movq	-16(%rbp), %rsi
	movslq	%eax, %rdi
	leaq	0(,%rdi,4), %r8
	leaq	audit_kindP.15(%rip), %rdi
	movl	(%r8,%rdi), %edi
	addl	%r10d, %edi
	movslq	%edi, %rdi
	subq	%r9, %rdi
	movzbl	(%rsi,%rdi), %esi
	movzbl	%sil, %edi
	movslq	%eax, %rsi
	leaq	audit_kindT1.14(%rip), %r8
	movzbl	(%rsi,%r8), %esi
	movzbl	%sil, %esi
	imull	%edi, %esi
	addl	%ecx, %esi
	movslq	%esi, %rcx
	imulq	$1126548799, %rcx, %rcx
	shrq	$32, %rcx
	sarl	$4, %ecx
	movl	%esi, %r8d
	sarl	$31, %r8d
	subl	%r8d, %ecx
	imull	$61, %ecx, %r8d
	movl	%esi, %ecx
	subl	%r8d, %ecx
	movslq	%eax, %rsi
	leaq	audit_kindT2.13(%rip), %r8
	movzbl	(%rsi,%r8), %esi
	movzbl	%sil, %esi
	imull	%edi, %esi
	addl	%edx, %esi
	movslq	%esi, %rdx
	imulq	$1126548799, %rdx, %rdx
	shrq	$32, %rdx
	sarl	$4, %edx
	movl	%esi, %edi
	sarl	$31, %edi
	subl	%edi, %edx
	imull	$61, %edx, %edi
	subl	%edi, %esi
	movl	%esi, %edx
	addl	$1, %eax
	jmp	.L23
.L22:
	movslq	%ecx, %rax
	leaq	audit_kindG.12(%rip), %rcx
	movzbl	(%rax,%rcx), %eax
	movzbl	%al, %ecx
	movslq	%edx, %rax
	leaq	audit_kindG.12(%rip), %rdx
	movzbl	(%rax,%rdx), %eax
	movzbl	%al, %eax
	addl	%ecx, %eax
	movslq	%eax, %rdx
	imulq	$-2004318071, %rdx, %rdx
	shrq	$32, %rdx
	addl	%eax, %edx
	sarl	$4, %edx
	movl	%eax, %ecx
	sarl	$31, %ecx
	subl	%ecx, %edx
	imull	$30, %edx, %ecx
	subl	%ecx, %eax
	movl	%eax, %edx
	movl	%edx, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.size	silver_library_reports__audit_kindH, .-silver_library_reports__audit_kindH
	.align 2
	.globl	silver_library_reports__spanIP
	.type	silver_library_reports__spanIP, @function
silver_library_reports__spanIP:
.LFB4:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movl	$0, -8(%rbp)
	movl	$0, -4(%rbp)
	movq	-8(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	silver_library_reports__spanIP, .-silver_library_reports__spanIP
	.align 2
	.globl	silver_library_reports__TnestingBIP
	.type	silver_library_reports__TnestingBIP, @function
silver_library_reports__TnestingBIP:
.LFB5:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE5:
	.size	silver_library_reports__TnestingBIP, .-silver_library_reports__TnestingBIP
	.section	.rodata
	.align 8
.LC38:
	.ascii	"failed precondition from silver_library_reports.adb:161"
.LC39:
	.ascii	"silver_library_reports.adb"
	.zero	1
	.align 8
.LC0:
	.long	1
	.long	55
	.text
	.align 2
	.globl	silver_library_reports__pushed
	.type	silver_library_reports__pushed, @function
silver_library_reports__pushed:
.LFB6:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_library_reports.adb"
	.loc 1 160 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -88(%rbp)
	movq	%rsi, -96(%rbp)
	movl	%edx, -100(%rbp)
	movb	%cl, -101(%rbp)
	.loc 1 161 34
	cmpl	$64, -100(%rbp)
	jle	.L29
.LBB6:
	.loc 1 161 34 is_stmt 0 discriminator 1
	leaq	.LC38(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L29:
.LBE6:
	.loc 1 166 14 is_stmt 1
	movq	-96(%rbp), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rbx
	movq	%rcx, -80(%rbp)
	movq	%rbx, -72(%rbp)
	movq	16(%rax), %rcx
	movq	24(%rax), %rbx
	movq	%rcx, -64(%rbp)
	movq	%rbx, -56(%rbp)
	movq	32(%rax), %rcx
	movq	40(%rax), %rbx
	movq	%rcx, -48(%rbp)
	movq	%rbx, -40(%rbp)
	movq	56(%rax), %rdx
	movq	48(%rax), %rax
	movq	%rax, -32(%rbp)
	movq	%rdx, -24(%rbp)
	.loc 1 166 32
	cmpl	$0, -100(%rbp)
	jle	.L30
	.loc 1 166 32 is_stmt 0 discriminator 1
	cmpl	$64, -100(%rbp)
	jle	.L31
.L30:
	.loc 1 166 32 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$166, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L31:
	.loc 1 166 32 discriminator 3
	movl	-100(%rbp), %eax
	cltq
	movzbl	-101(%rbp), %edx
	movb	%dl, -81(%rbp,%rax)
	.loc 1 166 7 is_stmt 1 discriminator 4
	movq	-88(%rbp), %rax
	movq	-80(%rbp), %rcx
	movq	-72(%rbp), %rbx
	movq	%rcx, (%rax)
	movq	%rbx, 8(%rax)
	movq	-64(%rbp), %rcx
	movq	-56(%rbp), %rbx
	movq	%rcx, 16(%rax)
	movq	%rbx, 24(%rax)
	movq	-48(%rbp), %rcx
	movq	-40(%rbp), %rbx
	movq	%rcx, 32(%rax)
	movq	%rbx, 40(%rax)
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rbx
	movq	%rcx, 48(%rax)
	movq	%rbx, 56(%rax)
	.loc 1 167 8
	movq	-88(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE6:
	.size	silver_library_reports__pushed, .-silver_library_reports__pushed
	.align 2
	.type	___ghost_silver_library_reports__skip_space__F168b, @function
___ghost_silver_library_reports__skip_space__F168b:
.LFB8:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%r10, %rax
	movq	%r10, -24(%rbp)
	movl	24(%rax), %r9d
	movl	20(%rax), %r8d
	movl	20(%rax), %ecx
	movl	24(%rax), %edx
	cmpl	%edx, %ecx
	jl	.L34
	movl	20(%rax), %edx
	movslq	%edx, %rdx
	movq	%rdx, %rcx
	movq	%rdx, %rbx
	sarq	$63, %rbx
	movl	24(%rax), %edx
	movslq	%edx, %rdx
	movq	%rdx, %rsi
	movq	%rdx, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rcx
	sbbq	%rdi, %rbx
	addq	$1, %rcx
	adcq	$0, %rbx
	jmp	.L35
.L34:
	movl	$0, %ecx
	movl	$0, %ebx
.L35:
	movl	16(%rax), %edx
	cmpl	%ecx, %edx
	jg	.L36
	movl	16(%rax), %edx
	cmpl	%edx, %r9d
	jg	.L37
	movl	16(%rax), %edx
	cmpl	%edx, %r8d
	jge	.L38
.L37:
	leaq	.LC39(%rip), %rax
	movl	$351, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L38:
	movq	8(%rax), %rdx
	movq	(%rdx), %rdx
	movl	16(%rax), %ecx
	movslq	%ecx, %rcx
	movq	(%rax), %rax
	subq	%rax, %rcx
	movzbl	(%rdx,%rcx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_library_reports__space
	testb	%al, %al
	je	.L36
	movl	$1, %eax
	jmp	.L39
.L36:
	movl	$0, %eax
.L39:
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE8:
	.size	___ghost_silver_library_reports__skip_space__F168b, .-___ghost_silver_library_reports__skip_space__F168b
	.section	.rodata
	.align 8
.LC40:
	.ascii	"failed precondition from silver_library_reports.adb:346"
	.align 8
.LC41:
	.ascii	"failed precondition from silver_library_reports.adb:347"
	.align 8
.LC42:
	.ascii	"Loop_Invariant failed at silver_library_reports.adb:352"
	.align 8
.LC43:
	.ascii	"Loop_Variant failed at silver_library_reports.adb:355"
	.align 8
.LC1:
	.long	1
	.long	53
	.text
	.align 2
	.type	silver_library_reports__skip_space, @function
silver_library_reports__skip_space:
.LFB7:
	.loc 1 345 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$120, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -112(%rbp)
	movq	%rbx, -104(%rbp)
	movl	%edx, -116(%rbp)
	.loc 1 345 4
	leaq	16(%rbp), %rdx
	.loc 1 345 4 is_stmt 0 discriminator 1
	leaq	-112(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -88(%rbp)
	movl	-116(%rbp), %eax
	movl	%eax, -80(%rbp)
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -72(%rbp)
	movq	-104(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -76(%rbp)
	movl	-76(%rbp), %edx
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jl	.L42
	.loc 1 345 4 discriminator 2
	movl	-76(%rbp), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movl	-72(%rbp), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %r14
	movq	%rdx, %r15
	jmp	.L43
.L42:
	.loc 1 345 4 discriminator 3
	movl	$0, %r14d
	movl	$0, %r15d
.L43:
.LBB8:
	.loc 1 345 4 discriminator 4
	movl	-72(%rbp), %eax
	cltq
	movq	%rax, -96(%rbp)
	movl	-76(%rbp), %edx
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 345 4 discriminator 7
	movl	-76(%rbp), %edx
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 345 4 discriminator 10
	movl	-76(%rbp), %edx
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 346 18 is_stmt 1
	movl	-72(%rbp), %eax
	cmpl	$1, %eax
	je	.L50
.LBB9:
	.loc 1 346 18 is_stmt 0 discriminator 1
	leaq	.LC40(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L50:
.LBE9:
	.loc 1 346 54 is_stmt 1 discriminator 2
	movl	-72(%rbp), %eax
	cltq
	leaq	16777215(%rax), %rdx
	movl	-76(%rbp), %eax
	cltq
	.loc 1 346 18 discriminator 2
	cmpq	%rax, %rdx
	jge	.L51
.LBB10:
	.loc 1 346 18 is_stmt 0 discriminator 3
	leaq	.LC40(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L51:
.LBE10:
	.loc 1 346 18 discriminator 4
	movl	-80(%rbp), %eax
	testl	%eax, %eax
	jle	.L52
	.loc 1 347 46 is_stmt 1
	movl	%r14d, %eax
	cmpl	$2147483647, %eax
	jne	.L53
	.loc 1 347 46 is_stmt 0 discriminator 1
	leaq	.LC39(%rip), %rax
	movl	$347, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L53:
	.loc 1 347 46 discriminator 3
	movl	%r14d, %eax
	leal	1(%rax), %edx
	.loc 1 347 26 is_stmt 1 discriminator 4
	movl	-80(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L54
.L52:
.LBB11:
	.loc 1 346 18 discriminator 5
	leaq	.LC41(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L54:
.LBE11:
	.loc 1 352 53
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
	call	___ghost_silver_library_reports__skip_space__F168b
	.loc 1 352 53 is_stmt 0 discriminator 1
	testb	%al, %al
	je	.L67
.LBB12:
	.loc 1 352 53 discriminator 2
	movl	-80(%rbp), %r12d
	.loc 1 351 70 is_stmt 1
	movl	$0, %ebx
.L64:
.LBB13:
	.loc 1 352 33 discriminator 3
	movl	-80(%rbp), %eax
	cmpl	%r12d, %eax
	jl	.L56
	.loc 1 352 80 discriminator 4
	movl	%r14d, %eax
	cmpl	$2147483647, %eax
	jne	.L57
	.loc 1 352 80 is_stmt 0 discriminator 5
	leaq	.LC39(%rip), %rax
	movl	$352, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L57:
	.loc 1 352 80 discriminator 7
	movl	%r14d, %eax
	leal	1(%rax), %edx
	.loc 1 352 42 is_stmt 1 discriminator 8
	movl	-80(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L58
.L56:
.LBB14:
	.loc 1 352 33 discriminator 9
	leaq	.LC42(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L58:
.LBE14:
	.loc 1 355 10
	testb	%bl, %bl
	je	.L59
	.loc 1 355 44 discriminator 1
	movl	-120(%rbp), %eax
	movl	%eax, -124(%rbp)
.L59:
	.loc 1 355 44 is_stmt 0 discriminator 2
	movl	-80(%rbp), %eax
	movl	%eax, -120(%rbp)
	.loc 1 355 10 is_stmt 1 discriminator 2
	testb	%bl, %bl
	je	.L60
	.loc 1 355 44 discriminator 3
	movl	-124(%rbp), %ecx
	cmpl	%ecx, %eax
	jg	.L61
.LBB15:
	.loc 1 355 44 is_stmt 0 discriminator 4
	leaq	.LC43(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rcx
	movq	-136(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L60:
.LBE15:
	.loc 1 355 10 is_stmt 1 discriminator 5
	movl	$1, %ebx
.L61:
	.loc 1 356 31
	movl	-80(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L62
	.loc 1 356 31 is_stmt 0 discriminator 1
	cmpl	$16777217, %eax
	jle	.L63
.L62:
	.loc 1 356 31 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$356, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L63:
	.loc 1 356 19 is_stmt 1 discriminator 3
	movl	%eax, -80(%rbp)
	.loc 1 352 53 discriminator 10
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
	call	___ghost_silver_library_reports__skip_space__F168b
	.loc 1 352 53 is_stmt 0 discriminator 11
	xorl	$1, %eax
	testb	%al, %al
	jne	.L67
.LBE13:
	.loc 1 357 15 is_stmt 1
	jmp	.L64
.L67:
.LBE12:
	.loc 1 358 8
	nop
.LBE8:
	.loc 1 358 8 is_stmt 0 discriminator 1
	movl	-80(%rbp), %eax
	.loc 1 358 8
	addq	$120, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE7:
	.size	silver_library_reports__skip_space, .-silver_library_reports__skip_space
	.section	.rodata
	.align 8
.LC44:
	.ascii	"failed precondition from silver_library_reports.adb:364"
	.align 8
.LC45:
	.ascii	"failed precondition from silver_library_reports.adb:365"
	.text
	.align 2
	.type	silver_library_reports__value_end, @function
silver_library_reports__value_end:
.LFB9:
	.loc 1 363 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$200, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -160(%rbp)
	movq	%rbx, -152(%rbp)
	movl	%edx, -164(%rbp)
	.loc 1 363 4
	movq	-152(%rbp), %rax
	movl	(%rax), %ebx
	movq	-152(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%ebx, %r12d
	jl	.L69
	.loc 1 363 4 is_stmt 0 discriminator 1
	movslq	%r12d, %rax
	cqto
	movslq	%ebx, %rcx
	movq	%rcx, %rsi
	movq	%rcx, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L70
.L69:
	.loc 1 363 4 discriminator 2
	movl	$0, %eax
	movl	$0, %edx
.L70:
.LBB16:
	.loc 1 363 4 discriminator 3
	movslq	%ebx, %r13
	cmpl	%ebx, %r12d
	.loc 1 363 4 discriminator 6
	cmpl	%ebx, %r12d
	.loc 1 363 4 discriminator 9
	cmpl	%ebx, %r12d
	.loc 1 364 18 is_stmt 1
	cmpl	$1, %ebx
	je	.L77
.LBB17:
	.loc 1 364 18 is_stmt 0 discriminator 1
	leaq	.LC44(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L77:
.LBE17:
	.loc 1 364 54 is_stmt 1 discriminator 2
	movslq	%ebx, %rcx
	leaq	16777215(%rcx), %rsi
	movslq	%r12d, %rcx
	.loc 1 364 18 discriminator 2
	cmpq	%rcx, %rsi
	jge	.L78
.LBB18:
	.loc 1 364 18 is_stmt 0 discriminator 3
	leaq	.LC44(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L78:
.LBE18:
	.loc 1 364 18 discriminator 4
	cmpl	$0, -164(%rbp)
	jle	.L79
	.loc 1 365 43 is_stmt 1
	movl	%eax, %ecx
	cmpl	$2147483647, %ecx
	jne	.L80
	.loc 1 365 43 is_stmt 0 discriminator 1
	leaq	.LC39(%rip), %rax
	movl	$365, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L80:
	.loc 1 365 43 discriminator 3
	movl	%eax, %ecx
	addl	$1, %ecx
	.loc 1 365 23 is_stmt 1 discriminator 4
	cmpl	-164(%rbp), %ecx
	jge	.L81
.L79:
.LBB19:
	.loc 1 364 18 discriminator 5
	leaq	.LC45(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L81:
.LBE19:
	.loc 1 368 7
	movabsq	$2314885530818453536, %rsi
	movq	%rsi, %rdi
	movq	%rsi, -144(%rbp)
	movq	%rdi, -136(%rbp)
	movq	%rsi, -128(%rbp)
	movq	%rdi, -120(%rbp)
	movq	%rsi, -112(%rbp)
	movq	%rdi, -104(%rbp)
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	.loc 1 369 7
	movl	$0, -52(%rbp)
	.loc 1 370 7
	movb	$0, -53(%rbp)
	.loc 1 371 7
	movb	$0, -54(%rbp)
	.loc 1 372 45
	movl	%eax, %ecx
	.loc 1 373 9
	cmpl	%ecx, -164(%rbp)
	jg	.L82
	.loc 1 373 19 discriminator 1
	cmpl	-164(%rbp), %ebx
	jg	.L83
	.loc 1 373 19 is_stmt 0 discriminator 2
	cmpl	-164(%rbp), %r12d
	jge	.L84
.L83:
	.loc 1 373 19 discriminator 3
	leaq	.LC39(%rip), %rax
	movl	$373, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L84:
	.loc 1 373 32 is_stmt 1 discriminator 4
	movq	-160(%rbp), %rcx
	movl	-164(%rbp), %esi
	movslq	%esi, %rsi
	subq	%r13, %rsi
	movzbl	(%rcx,%rsi), %ecx
	.loc 1 373 32 is_stmt 0 discriminator 5
	cmpb	$123, %cl
	sete	%cl
	.loc 1 373 9 is_stmt 1 discriminator 5
	testb	%cl, %cl
	jne	.L85
	.loc 1 373 46 discriminator 6
	cmpl	-164(%rbp), %ebx
	jg	.L86
	.loc 1 373 46 is_stmt 0 discriminator 7
	cmpl	-164(%rbp), %r12d
	jge	.L87
.L86:
	.loc 1 373 46 discriminator 8
	leaq	.LC39(%rip), %rax
	movl	$373, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L87:
	.loc 1 373 59 is_stmt 1 discriminator 9
	movq	-160(%rbp), %rcx
	movl	-164(%rbp), %esi
	movslq	%esi, %rsi
	subq	%r13, %rsi
	movzbl	(%rcx,%rsi), %ecx
	.loc 1 373 59 is_stmt 0 discriminator 10
	cmpb	$91, %cl
	sete	%cl
	.loc 1 373 38 is_stmt 1 discriminator 10
	testb	%cl, %cl
	je	.L82
.L85:
	.loc 1 373 9 discriminator 11
	movl	$1, %ecx
	jmp	.L88
.L82:
	.loc 1 373 9 is_stmt 0 discriminator 12
	movl	$0, %ecx
.L88:
	.loc 1 372 7 is_stmt 1 discriminator 1
	movb	%cl, -61(%rbp)
	.loc 1 375 16
	movl	%eax, %ecx
	.loc 1 375 7
	cmpl	%ecx, -164(%rbp)
	jle	.L89
	.loc 1 376 10
	movl	$0, %eax
	jmp	.L154
.L89:
	.loc 1 378 11
	movl	-164(%rbp), %ecx
	movl	%ecx, -68(%rbp)
	movl	%eax, -72(%rbp)
	movl	-68(%rbp), %eax
	cmpl	-72(%rbp), %eax
	jg	.L91
.LBB20:
	.loc 1 378 11 is_stmt 0 discriminator 1
	movl	-68(%rbp), %eax
	movl	%eax, -60(%rbp)
.L153:
.LBB21:
	.loc 1 382 10 is_stmt 1
	cmpb	$0, -53(%rbp)
	je	.L92
	.loc 1 383 13
	cmpb	$0, -54(%rbp)
	je	.L93
	.loc 1 387 24
	movb	$0, -54(%rbp)
	jmp	.L94
.L93:
	.loc 1 388 19
	cmpl	-60(%rbp), %ebx
	jg	.L95
	.loc 1 388 19 is_stmt 0 discriminator 1
	cmpl	-60(%rbp), %r12d
	jge	.L96
.L95:
	.loc 1 388 19 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$388, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L96:
	.loc 1 388 28 is_stmt 1 discriminator 3
	movq	-160(%rbp), %rax
	movl	-60(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 388 13 discriminator 4
	cmpb	$92, %al
	jne	.L97
	.loc 1 392 24
	movb	$1, -54(%rbp)
	jmp	.L94
.L97:
	.loc 1 393 19
	cmpl	-60(%rbp), %ebx
	jg	.L98
	.loc 1 393 19 is_stmt 0 discriminator 1
	cmpl	-60(%rbp), %r12d
	jge	.L99
.L98:
	.loc 1 393 19 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$393, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L99:
	.loc 1 393 28 is_stmt 1 discriminator 3
	movq	-160(%rbp), %rax
	movl	-60(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 393 13 discriminator 4
	cmpb	$34, %al
	jne	.L94
	.loc 1 394 23
	movb	$0, -53(%rbp)
	.loc 1 395 19
	movzbl	-61(%rbp), %eax
	xorl	$1, %eax
	.loc 1 395 16
	testb	%al, %al
	je	.L94
	.loc 1 396 26
	cmpl	$0, -60(%rbp)
	js	.L100
	.loc 1 396 26 is_stmt 0 discriminator 1
	cmpl	$16777217, -60(%rbp)
	jle	.L101
.L100:
	.loc 1 396 26 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$396, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L101:
	.loc 1 396 19 is_stmt 1 discriminator 3
	movl	-60(%rbp), %eax
	jmp	.L154
.L92:
	.loc 1 406 16
	cmpl	-60(%rbp), %ebx
	jg	.L102
	.loc 1 406 16 is_stmt 0 discriminator 1
	cmpl	-60(%rbp), %r12d
	jge	.L103
.L102:
	.loc 1 406 16 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$406, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L103:
	.loc 1 406 25 is_stmt 1 discriminator 3
	movq	-160(%rbp), %rax
	movl	-60(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 406 10 discriminator 4
	cmpb	$34, %al
	jne	.L104
	.loc 1 410 20
	movb	$1, -53(%rbp)
	jmp	.L94
.L104:
	.loc 1 411 16
	cmpl	-60(%rbp), %ebx
	jg	.L105
	.loc 1 411 16 is_stmt 0 discriminator 1
	cmpl	-60(%rbp), %r12d
	jge	.L106
.L105:
	.loc 1 411 16 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$411, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L106:
	.loc 1 411 25 is_stmt 1 discriminator 3
	movq	-160(%rbp), %rax
	movl	-60(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 411 25 is_stmt 0 discriminator 4
	cmpb	$123, %al
	sete	%al
	.loc 1 411 10 is_stmt 1 discriminator 4
	testb	%al, %al
	jne	.L107
	.loc 1 411 39 discriminator 5
	cmpl	-60(%rbp), %ebx
	jg	.L108
	.loc 1 411 39 is_stmt 0 discriminator 6
	cmpl	-60(%rbp), %r12d
	jge	.L109
.L108:
	.loc 1 411 39 discriminator 7
	leaq	.LC39(%rip), %rax
	movl	$411, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L109:
	.loc 1 411 48 is_stmt 1 discriminator 8
	movq	-160(%rbp), %rax
	movl	-60(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 411 48 is_stmt 0 discriminator 9
	cmpb	$91, %al
	sete	%al
	.loc 1 411 31 is_stmt 1 discriminator 9
	testb	%al, %al
	je	.L110
.L107:
	.loc 1 412 13
	cmpl	$64, -52(%rbp)
	jne	.L111
	.loc 1 413 16
	movl	$0, %eax
	jmp	.L154
.L111:
	.loc 1 419 28
	movl	-52(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L112
	.loc 1 419 28 is_stmt 0 discriminator 1
	cmpl	$64, %eax
	jle	.L113
.L112:
	.loc 1 419 28 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$419, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L113:
	.loc 1 419 19 is_stmt 1 discriminator 3
	movl	%eax, -52(%rbp)
	.loc 1 420 44
	cmpl	-60(%rbp), %ebx
	jg	.L114
	.loc 1 420 44 is_stmt 0 discriminator 1
	cmpl	-60(%rbp), %r12d
	jge	.L115
.L114:
	.loc 1 420 44 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$420, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L115:
	.loc 1 420 37 is_stmt 1 discriminator 3
	cmpl	$0, -52(%rbp)
	jg	.L116
	.loc 1 420 37 is_stmt 0 discriminator 4
	leaq	.LC39(%rip), %rax
	movl	$420, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L116:
	.loc 1 420 22 is_stmt 1 discriminator 5
	movq	-160(%rbp), %rax
	movl	-60(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %edx
	.loc 1 420 22 is_stmt 0 discriminator 6
	leaq	-240(%rbp), %rax
	movsbl	%dl, %ecx
	movl	-52(%rbp), %edx
	leaq	-144(%rbp), %rsi
	movq	%rax, %rdi
	call	silver_library_reports__pushed
	movq	-240(%rbp), %rax
	movq	-232(%rbp), %rdx
	movq	%rax, -144(%rbp)
	movq	%rdx, -136(%rbp)
	movq	-224(%rbp), %rax
	movq	-216(%rbp), %rdx
	movq	%rax, -128(%rbp)
	movq	%rdx, -120(%rbp)
	movq	-208(%rbp), %rax
	movq	-200(%rbp), %rdx
	movq	%rax, -112(%rbp)
	movq	%rdx, -104(%rbp)
	movq	-192(%rbp), %rax
	movq	-184(%rbp), %rdx
	movq	%rax, -96(%rbp)
	movq	%rdx, -88(%rbp)
	.loc 1 420 19 is_stmt 1 discriminator 7
	jmp	.L94
.L110:
	.loc 1 421 16
	cmpl	-60(%rbp), %ebx
	jg	.L117
	.loc 1 421 16 is_stmt 0 discriminator 1
	cmpl	-60(%rbp), %r12d
	jge	.L118
.L117:
	.loc 1 421 16 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$421, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L118:
	.loc 1 421 25 is_stmt 1 discriminator 3
	movq	-160(%rbp), %rax
	movl	-60(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 421 25 is_stmt 0 discriminator 4
	cmpb	$125, %al
	sete	%al
	.loc 1 421 10 is_stmt 1 discriminator 4
	testb	%al, %al
	jne	.L119
	.loc 1 421 39 discriminator 5
	cmpl	-60(%rbp), %ebx
	jg	.L120
	.loc 1 421 39 is_stmt 0 discriminator 6
	cmpl	-60(%rbp), %r12d
	jge	.L121
.L120:
	.loc 1 421 39 discriminator 7
	leaq	.LC39(%rip), %rax
	movl	$421, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L121:
	.loc 1 421 48 is_stmt 1 discriminator 8
	movq	-160(%rbp), %rax
	movl	-60(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 421 48 is_stmt 0 discriminator 9
	cmpb	$93, %al
	sete	%al
	.loc 1 421 31 is_stmt 1 discriminator 9
	testb	%al, %al
	je	.L122
.L119:
	.loc 1 422 13
	cmpl	$0, -52(%rbp)
	jne	.L123
	.loc 1 423 16
	movl	-60(%rbp), %eax
	cmpl	-164(%rbp), %eax
	jle	.L124
	.loc 1 423 38 discriminator 1
	movzbl	-61(%rbp), %eax
	xorl	$1, %eax
	.loc 1 423 29 discriminator 1
	testb	%al, %al
	je	.L124
	.loc 1 424 28
	cmpl	$-2147483648, -60(%rbp)
	jne	.L125
	.loc 1 424 28 is_stmt 0 discriminator 1
	leaq	.LC39(%rip), %rax
	movl	$424, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L125:
	.loc 1 424 28 discriminator 3
	movl	-60(%rbp), %eax
	subl	$1, %eax
	.loc 1 424 28 discriminator 4
	testl	%eax, %eax
	js	.L126
	.loc 1 424 28 discriminator 5
	cmpl	$16777217, %eax
	jle	.L155
.L126:
	.loc 1 424 28 discriminator 6
	leaq	.LC39(%rip), %rax
	movl	$424, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L124:
	.loc 1 426 16 is_stmt 1
	movl	$0, %eax
	jmp	.L154
.L123:
	.loc 1 428 17
	cmpl	-60(%rbp), %ebx
	jg	.L128
	.loc 1 428 17 is_stmt 0 discriminator 1
	cmpl	-60(%rbp), %r12d
	jge	.L129
.L128:
	.loc 1 428 17 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$428, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L129:
	.loc 1 428 26 is_stmt 1 discriminator 3
	movq	-160(%rbp), %rax
	movl	-60(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 428 26 is_stmt 0 discriminator 4
	cmpb	$125, %al
	sete	%al
	.loc 1 428 13 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L130
	.loc 1 428 41 discriminator 5
	cmpl	$0, -52(%rbp)
	jle	.L131
	.loc 1 428 41 is_stmt 0 discriminator 6
	cmpl	$64, -52(%rbp)
	jle	.L132
.L131:
	.loc 1 428 41 discriminator 7
	leaq	.LC39(%rip), %rax
	movl	$428, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L132:
	.loc 1 428 55 is_stmt 1 discriminator 8
	movl	-52(%rbp), %eax
	cltq
	movzbl	-145(%rbp,%rax), %eax
	.loc 1 428 55 is_stmt 0 discriminator 9
	cmpb	$123, %al
	setne	%al
	.loc 1 428 32 is_stmt 1 discriminator 9
	testb	%al, %al
	jne	.L133
.L130:
	.loc 1 429 24
	cmpl	-60(%rbp), %ebx
	jg	.L134
	.loc 1 429 24 is_stmt 0 discriminator 1
	cmpl	-60(%rbp), %r12d
	jge	.L135
.L134:
	.loc 1 429 24 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$429, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L135:
	.loc 1 429 33 is_stmt 1 discriminator 3
	movq	-160(%rbp), %rax
	movl	-60(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 429 33 is_stmt 0 discriminator 4
	cmpb	$93, %al
	sete	%al
	.loc 1 429 15 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L136
	.loc 1 429 48 discriminator 5
	cmpl	$0, -52(%rbp)
	jle	.L137
	.loc 1 429 48 is_stmt 0 discriminator 6
	cmpl	$64, -52(%rbp)
	jle	.L138
.L137:
	.loc 1 429 48 discriminator 7
	leaq	.LC39(%rip), %rax
	movl	$429, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L138:
	.loc 1 429 62 is_stmt 1 discriminator 8
	movl	-52(%rbp), %eax
	cltq
	movzbl	-145(%rbp,%rax), %eax
	.loc 1 429 62 is_stmt 0 discriminator 9
	cmpb	$91, %al
	setne	%al
	.loc 1 429 39 is_stmt 1 discriminator 9
	testb	%al, %al
	je	.L136
.L133:
	.loc 1 431 16
	movl	$0, %eax
	jmp	.L154
.L136:
	.loc 1 438 28
	movl	-52(%rbp), %eax
	subl	$1, %eax
	testl	%eax, %eax
	js	.L139
	.loc 1 438 28 is_stmt 0 discriminator 1
	cmpl	$64, %eax
	jle	.L140
.L139:
	.loc 1 438 28 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$438, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L140:
	.loc 1 438 19 is_stmt 1 discriminator 3
	movl	%eax, -52(%rbp)
	.loc 1 439 13
	cmpl	$0, -52(%rbp)
	jne	.L94
	.loc 1 440 23
	cmpl	$0, -60(%rbp)
	js	.L142
	.loc 1 440 23 is_stmt 0 discriminator 1
	cmpl	$16777217, -60(%rbp)
	jle	.L143
.L142:
	.loc 1 440 23 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$440, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L143:
	.loc 1 440 16 is_stmt 1 discriminator 3
	movl	-60(%rbp), %eax
	jmp	.L154
.L122:
	.loc 1 442 16
	movzbl	-61(%rbp), %eax
	xorl	$1, %eax
	.loc 1 442 10
	testb	%al, %al
	je	.L94
	.loc 1 442 40 discriminator 1
	cmpl	-60(%rbp), %ebx
	jg	.L144
	.loc 1 442 40 is_stmt 0 discriminator 2
	cmpl	-60(%rbp), %r12d
	jge	.L145
.L144:
	.loc 1 442 40 discriminator 3
	leaq	.LC39(%rip), %rax
	movl	$442, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L145:
	.loc 1 442 49 is_stmt 1 discriminator 4
	movq	-160(%rbp), %rax
	movl	-60(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 442 49 is_stmt 0 discriminator 5
	cmpb	$44, %al
	sete	%al
	.loc 1 442 30 is_stmt 1 discriminator 5
	testb	%al, %al
	jne	.L146
	.loc 1 442 70 discriminator 6
	cmpl	-60(%rbp), %ebx
	jg	.L147
	.loc 1 442 70 is_stmt 0 discriminator 7
	cmpl	-60(%rbp), %r12d
	jge	.L148
.L147:
	.loc 1 442 70 discriminator 8
	leaq	.LC39(%rip), %rax
	movl	$442, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L148:
	.loc 1 442 63 is_stmt 1 discriminator 9
	movq	-160(%rbp), %rax
	movl	-60(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 442 63 is_stmt 0 discriminator 10
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_library_reports__space
	.loc 1 442 55 is_stmt 1 discriminator 11
	testb	%al, %al
	je	.L94
.L146:
	.loc 1 443 13
	movl	-60(%rbp), %eax
	cmpl	-164(%rbp), %eax
	jle	.L149
	.loc 1 444 25
	cmpl	$-2147483648, -60(%rbp)
	jne	.L150
	.loc 1 444 25 is_stmt 0 discriminator 1
	leaq	.LC39(%rip), %rax
	movl	$444, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L150:
	.loc 1 444 25 discriminator 3
	movl	-60(%rbp), %eax
	subl	$1, %eax
	.loc 1 444 25 discriminator 4
	testl	%eax, %eax
	js	.L151
	.loc 1 444 25 discriminator 5
	cmpl	$16777217, %eax
	jle	.L156
.L151:
	.loc 1 444 25 discriminator 6
	leaq	.LC39(%rip), %rax
	movl	$444, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L149:
	.loc 1 446 13 is_stmt 1
	movl	$0, %eax
	jmp	.L154
.L94:
.LBE21:
	.loc 1 378 11 discriminator 2
	movl	-60(%rbp), %eax
	cmpl	-72(%rbp), %eax
	je	.L91
	.loc 1 378 11 is_stmt 0 discriminator 3
	addl	$1, -60(%rbp)
	.loc 1 455 15 is_stmt 1
	jmp	.L153
.L91:
.LBE20:
	.loc 1 456 7
	movl	$0, %eax
	jmp	.L154
.L155:
.LBB23:
.LBB22:
	.loc 1 424 19 discriminator 7
	nop
	jmp	.L154
.L156:
	.loc 1 444 16 discriminator 7
	nop
.L154:
.LBE22:
.LBE23:
.LBE16:
	.loc 1 457 8
	addq	$200, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE9:
	.size	silver_library_reports__value_end, .-silver_library_reports__value_end
	.section	.rodata
	.align 8
.LC46:
	.ascii	"failed precondition from silver_library_reports.adb:461"
	.text
	.align 2
	.globl	silver_library_reports__string_equal
	.type	silver_library_reports__string_equal, @function
silver_library_reports__string_equal:
.LFB10:
	.loc 1 463 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$48, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r9
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r9, %rdi
	movq	%rsi, -48(%rbp)
	movq	%rdi, -40(%rbp)
	movq	%rdx, -56(%rbp)
	movq	%rcx, %rax
	movq	%r8, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -80(%rbp)
	movq	%rdx, -72(%rbp)
	.loc 1 463 4
	movq	-40(%rbp), %rax
	movl	(%rax), %ebx
	movq	-40(%rbp), %rax
	movl	4(%rax), %r12d
.LBB24:
	.loc 1 461 18
	cmpl	$1, %ebx
	je	.L158
.LBB25:
	.loc 1 461 18 is_stmt 0 discriminator 1
	leaq	.LC46(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L158:
.LBE25:
	.loc 1 461 54 is_stmt 1 discriminator 2
	movslq	%ebx, %rax
	leaq	16777215(%rax), %rdx
	movslq	%r12d, %rax
	.loc 1 461 18 discriminator 2
	cmpq	%rax, %rdx
	jge	.L159
.LBB26:
	.loc 1 461 18 is_stmt 0 discriminator 3
	leaq	.LC46(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L159:
.LBE26:
	.loc 1 465 7 is_stmt 1
	movq	-56(%rbp), %rdx
	movq	-48(%rbp), %rcx
	movq	-40(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__valid
	.loc 1 467 7
	testb	%al, %al
	je	.L160
	.loc 1 465 45 discriminator 2
	movl	-52(%rbp), %edx
	movl	-56(%rbp), %eax
	subl	%eax, %edx
	.loc 1 465 26 discriminator 2
	testl	%edx, %edx
	jle	.L160
	.loc 1 466 16
	movl	-56(%rbp), %eax
	cmpl	%eax, %ebx
	jg	.L161
	.loc 1 466 16 is_stmt 0 discriminator 1
	movl	-56(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L162
.L161:
	.loc 1 466 16 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$466, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L162:
	.loc 1 466 34 is_stmt 1 discriminator 3
	movq	-48(%rbp), %rax
	movq	-40(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-56(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$34, %al
	sete	%al
	.loc 1 466 7 discriminator 3
	testb	%al, %al
	je	.L160
	.loc 1 466 49 discriminator 4
	movl	-52(%rbp), %eax
	cmpl	%eax, %ebx
	jg	.L163
	.loc 1 466 49 is_stmt 0 discriminator 5
	movl	-52(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L164
.L163:
	.loc 1 466 49 discriminator 6
	leaq	.LC39(%rip), %rax
	movl	$466, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L164:
	.loc 1 466 66 is_stmt 1 discriminator 7
	movq	-48(%rbp), %rax
	movq	-40(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-52(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$34, %al
	sete	%al
	.loc 1 466 40 discriminator 7
	testb	%al, %al
	je	.L160
	.loc 1 467 16 discriminator 1
	cmpl	%ebx, %r12d
	.loc 1 467 16 is_stmt 0 discriminator 4
	cmpl	%ebx, %r12d
	.loc 1 467 16 discriminator 7
	cmpl	%ebx, %r12d
	.loc 1 467 37 is_stmt 1 discriminator 10
	movl	-52(%rbp), %edx
	.loc 1 467 33 discriminator 10
	movl	-56(%rbp), %eax
	addl	$1, %eax
	.loc 1 467 37 discriminator 10
	cmpl	%eax, %edx
	jle	.L171
	.loc 1 467 33 discriminator 11
	movl	-56(%rbp), %eax
	addl	$1, %eax
	.loc 1 467 37 discriminator 11
	cmpl	%eax, %ebx
	jg	.L172
	.loc 1 467 50 discriminator 12
	movl	-52(%rbp), %eax
	subl	$1, %eax
	.loc 1 467 37 discriminator 12
	cmpl	%eax, %r12d
	jge	.L171
.L172:
	.loc 1 467 37 is_stmt 0 discriminator 13
	leaq	.LC39(%rip), %rax
	movl	$467, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L171:
	.loc 1 467 16 is_stmt 1 discriminator 14
	movl	-52(%rbp), %edx
	.loc 1 467 33 discriminator 14
	movl	-56(%rbp), %eax
	addl	$1, %eax
	.loc 1 467 16 discriminator 14
	cmpl	%eax, %edx
	.loc 1 467 16 is_stmt 0 discriminator 17
	movl	-52(%rbp), %edx
	.loc 1 467 33 is_stmt 1 discriminator 17
	movl	-56(%rbp), %eax
	addl	$1, %eax
	.loc 1 467 16 discriminator 17
	cmpl	%eax, %edx
	.loc 1 467 16 is_stmt 0 discriminator 20
	movl	-52(%rbp), %edx
	.loc 1 467 33 is_stmt 1 discriminator 20
	movl	-56(%rbp), %eax
	addl	$1, %eax
	.loc 1 467 16 discriminator 20
	cmpl	%eax, %edx
	jle	.L177
	.loc 1 467 50 discriminator 21
	movl	-52(%rbp), %eax
	subl	$1, %eax
	movslq	%eax, %rdx
	.loc 1 467 33 discriminator 21
	movl	-56(%rbp), %eax
	addl	$1, %eax
	cltq
	.loc 1 467 16 discriminator 21
	subq	%rax, %rdx
	addq	$1, %rdx
	jmp	.L178
.L177:
	.loc 1 467 16 is_stmt 0 discriminator 22
	movl	$0, %edx
.L178:
	.loc 1 467 55 is_stmt 1 discriminator 23
	movl	-52(%rbp), %ecx
	.loc 1 467 33 discriminator 23
	movl	-56(%rbp), %eax
	addl	$1, %eax
	.loc 1 467 55 discriminator 23
	cmpl	%eax, %ecx
	jg	.L179
	.loc 1 467 55 is_stmt 0 discriminator 24
	movq	-72(%rbp), %rax
	movl	4(%rax), %ecx
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %ecx
	jl	.L180
.L179:
	.loc 1 467 55 discriminator 25
	movl	-52(%rbp), %ecx
	.loc 1 467 33 is_stmt 1 discriminator 25
	movl	-56(%rbp), %eax
	addl	$1, %eax
	.loc 1 467 55 discriminator 25
	cmpl	%eax, %ecx
	jle	.L181
	.loc 1 467 50 discriminator 26
	movl	-52(%rbp), %eax
	subl	$1, %eax
	movslq	%eax, %rcx
	.loc 1 467 33 discriminator 26
	movl	-56(%rbp), %eax
	addl	$1, %eax
	cltq
	.loc 1 467 55 discriminator 26
	subq	%rax, %rcx
	addq	$1, %rcx
	jmp	.L182
.L181:
	.loc 1 467 55 is_stmt 0 discriminator 27
	movl	$0, %ecx
.L182:
	.loc 1 467 55 discriminator 28
	movq	-72(%rbp), %rax
	movl	4(%rax), %esi
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %esi
	jl	.L183
	.loc 1 467 55 discriminator 29
	movq	-72(%rbp), %rax
	movl	4(%rax), %eax
	movslq	%eax, %rsi
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	cltq
	subq	%rax, %rsi
	leaq	1(%rsi), %rax
	jmp	.L184
.L183:
	.loc 1 467 55 discriminator 30
	movl	$0, %eax
.L184:
	.loc 1 467 55 discriminator 31
	cmpq	%rax, %rcx
	jne	.L185
	.loc 1 467 55 discriminator 32
	movq	-80(%rbp), %rax
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	.loc 1 467 33 is_stmt 1 discriminator 32
	movl	-56(%rbp), %edi
	addl	$1, %edi
	movslq	%edi, %rdi
	.loc 1 467 55 discriminator 32
	subq	%rcx, %rdi
	leaq	(%rsi,%rdi), %rcx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcmp@PLT
	.loc 1 467 55 is_stmt 0 discriminator 33
	testl	%eax, %eax
	jne	.L185
.L180:
	.loc 1 467 55 discriminator 34
	movl	$1, %eax
	jmp	.L186
.L185:
	.loc 1 467 55 discriminator 35
	movl	$0, %eax
.L186:
	.loc 1 467 7 is_stmt 1 discriminator 36
	testb	%al, %al
	je	.L160
	.loc 1 467 7 is_stmt 0 discriminator 37
	movl	$1, %eax
	jmp	.L187
.L160:
	.loc 1 467 7 discriminator 38
	movl	$0, %eax
.L187:
.LBE24:
	.loc 1 463 4 is_stmt 1
	addq	$48, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE10:
	.size	silver_library_reports__string_equal, .-silver_library_reports__string_equal
	.align 2
	.globl	silver_library_reports__memberIP
	.type	silver_library_reports__memberIP, @function
silver_library_reports__memberIP:
.LFB11:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	-8(%rbp), %rax
	movb	$0, (%rax)
	movq	-8(%rbp), %rax
	movl	$0, 4(%rax)
	movq	-8(%rbp), %rax
	movl	$0, 8(%rax)
	movq	-8(%rbp), %rax
	movl	$0, 12(%rax)
	movq	-8(%rbp), %rax
	movl	$0, 16(%rax)
	movq	-8(%rbp), %rax
	movl	$0, 20(%rax)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE11:
	.size	silver_library_reports__memberIP, .-silver_library_reports__memberIP
	.section	.rodata
	.align 8
.LC47:
	.ascii	"failed precondition from silver_library_reports.adb:610"
	.align 8
.LC48:
	.ascii	"failed precondition from silver_library_reports.adb:611"
	.align 8
.LC49:
	.ascii	"failed precondition from silver_library_reports.adb:612"
	.text
	.align 2
	.type	silver_library_reports__read_member, @function
silver_library_reports__read_member:
.LFB12:
	.loc 1 608 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$136, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -88(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -112(%rbp)
	movq	%rdx, -104(%rbp)
	movq	%rcx, -96(%rbp)
	movl	%r8d, -116(%rbp)
	.loc 1 608 4
	movq	-104(%rbp), %rax
	movl	(%rax), %ebx
	movq	-104(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%ebx, %r12d
	jl	.L192
	.loc 1 608 4 is_stmt 0 discriminator 1
	movslq	%r12d, %rax
	cqto
	movslq	%ebx, %rcx
	movq	%rcx, %rsi
	movq	%rcx, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %r14
	movq	%rdx, %r15
	jmp	.L193
.L192:
	.loc 1 608 4 discriminator 2
	movl	$0, %r14d
	movl	$0, %r15d
.L193:
.LBB27:
	.loc 1 608 4 discriminator 3
	movslq	%ebx, %r13
	cmpl	%ebx, %r12d
	.loc 1 608 4 discriminator 6
	cmpl	%ebx, %r12d
	.loc 1 608 4 discriminator 9
	cmpl	%ebx, %r12d
	.loc 1 610 18 is_stmt 1
	cmpl	$1, %ebx
	je	.L200
.LBB28:
	.loc 1 610 18 is_stmt 0 discriminator 1
	leaq	.LC47(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L200:
.LBE28:
	.loc 1 610 54 is_stmt 1 discriminator 2
	movslq	%ebx, %rax
	leaq	16777215(%rax), %rdx
	movslq	%r12d, %rax
	.loc 1 610 18 discriminator 2
	cmpq	%rax, %rdx
	jge	.L201
.LBB29:
	.loc 1 610 18 is_stmt 0 discriminator 3
	leaq	.LC47(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L201:
.LBE29:
	.loc 1 611 17 is_stmt 1
	movq	-96(%rbp), %rdx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__valid
	.loc 1 611 17 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 1 610 18 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L202
.LBB30:
	.loc 1 610 18 is_stmt 0 discriminator 5
	leaq	.LC48(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L202:
.LBE30:
	.loc 1 612 26 is_stmt 1
	movl	-96(%rbp), %eax
	.loc 1 610 18 discriminator 6
	cmpl	%eax, -116(%rbp)
	jle	.L203
	.loc 1 612 61 discriminator 1
	movl	%r14d, %eax
	cmpl	$2147483647, %eax
	jne	.L204
	.loc 1 612 61 is_stmt 0 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$612, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L204:
	.loc 1 612 61 discriminator 4
	movl	%r14d, %eax
	addl	$1, %eax
	.loc 1 612 26 is_stmt 1 discriminator 5
	cmpl	-116(%rbp), %eax
	jge	.L205
.L203:
.LBB31:
	.loc 1 610 18 discriminator 7
	leaq	.LC49(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L205:
.LBE31:
	.loc 1 615 7
	movl	-116(%rbp), %eax
	movl	%eax, -52(%rbp)
	.loc 1 618 7
	movl	-52(%rbp), %edx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__skip_space
	.loc 1 618 7 is_stmt 0 discriminator 1
	movl	%eax, -52(%rbp)
	.loc 1 619 12 is_stmt 1
	movl	-92(%rbp), %eax
	.loc 1 619 7
	cmpl	%eax, -52(%rbp)
	jne	.L206
	.loc 1 619 31 discriminator 1
	movq	-88(%rbp), %rax
	movb	$1, (%rax)
	movq	-88(%rbp), %rax
	movl	$0, 4(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 8(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 12(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 16(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 20(%rax)
	jmp	.L207
.L206:
	.loc 1 620 12
	movl	-92(%rbp), %eax
	.loc 1 620 7
	cmpl	%eax, -52(%rbp)
	jge	.L208
	.loc 1 620 35 discriminator 1
	cmpl	-52(%rbp), %ebx
	jg	.L209
	.loc 1 620 35 is_stmt 0 discriminator 2
	cmpl	-52(%rbp), %r12d
	jge	.L210
.L209:
	.loc 1 620 35 discriminator 3
	leaq	.LC39(%rip), %rax
	movl	$620, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L210:
	.loc 1 620 44 is_stmt 1 discriminator 4
	movq	-112(%rbp), %rax
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	cmpb	$34, %al
	setne	%al
	.loc 1 620 27 discriminator 4
	testb	%al, %al
	je	.L211
.L208:
	.loc 1 620 56 discriminator 5
	movq	-88(%rbp), %rax
	movb	$0, (%rax)
	movq	-88(%rbp), %rax
	movl	$0, 4(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 8(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 12(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 16(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 20(%rax)
	jmp	.L207
.L211:
	.loc 1 621 12
	movl	-52(%rbp), %edx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__value_end
	.loc 1 621 12 is_stmt 0 discriminator 1
	movl	%eax, -56(%rbp)
	.loc 1 622 7 is_stmt 1
	cmpl	$0, -56(%rbp)
	je	.L212
	.loc 1 622 26 discriminator 1
	movl	-92(%rbp), %eax
	.loc 1 622 16 discriminator 1
	cmpl	%eax, -56(%rbp)
	jl	.L213
.L212:
	.loc 1 622 46 discriminator 2
	movq	-88(%rbp), %rax
	movb	$0, (%rax)
	movq	-88(%rbp), %rax
	movl	$0, 4(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 8(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 12(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 16(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 20(%rax)
	jmp	.L207
.L213:
	.loc 1 623 14
	movl	-56(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L214
	.loc 1 623 14 is_stmt 0 discriminator 1
	cmpl	$16777217, %eax
	jle	.L215
.L214:
	.loc 1 623 14 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$623, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L215:
	.loc 1 623 9 is_stmt 1 discriminator 3
	movl	%eax, -60(%rbp)
	.loc 1 624 7
	movl	-60(%rbp), %edx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__skip_space
	.loc 1 624 7 is_stmt 0 discriminator 1
	movl	%eax, -60(%rbp)
	.loc 1 625 12 is_stmt 1
	movl	-92(%rbp), %eax
	.loc 1 625 7
	cmpl	%eax, -60(%rbp)
	jge	.L216
	.loc 1 625 35 discriminator 1
	cmpl	-60(%rbp), %ebx
	jg	.L217
	.loc 1 625 35 is_stmt 0 discriminator 2
	cmpl	-60(%rbp), %r12d
	jge	.L218
.L217:
	.loc 1 625 35 discriminator 3
	leaq	.LC39(%rip), %rax
	movl	$625, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L218:
	.loc 1 625 44 is_stmt 1 discriminator 4
	movq	-112(%rbp), %rax
	movl	-60(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	cmpb	$58, %al
	setne	%al
	.loc 1 625 27 discriminator 4
	testb	%al, %al
	je	.L219
.L216:
	.loc 1 625 56 discriminator 5
	movq	-88(%rbp), %rax
	movb	$0, (%rax)
	movq	-88(%rbp), %rax
	movl	$0, 4(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 8(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 12(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 16(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 20(%rax)
	jmp	.L207
.L219:
	.loc 1 626 14
	movl	-60(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L220
	.loc 1 626 14 is_stmt 0 discriminator 1
	cmpl	$16777217, %eax
	jle	.L221
.L220:
	.loc 1 626 14 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$626, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L221:
	.loc 1 626 9 is_stmt 1 discriminator 3
	movl	%eax, -60(%rbp)
	.loc 1 627 7
	movl	-60(%rbp), %edx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__skip_space
	.loc 1 627 7 is_stmt 0 discriminator 1
	movl	%eax, -60(%rbp)
	.loc 1 628 12 is_stmt 1
	movl	-60(%rbp), %edx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__value_end
	.loc 1 628 12 is_stmt 0 discriminator 1
	movl	%eax, -64(%rbp)
	.loc 1 629 7 is_stmt 1
	cmpl	$0, -64(%rbp)
	je	.L222
	.loc 1 629 26 discriminator 1
	movl	-92(%rbp), %eax
	.loc 1 629 16 discriminator 1
	cmpl	%eax, -64(%rbp)
	jl	.L223
.L222:
	.loc 1 629 46 discriminator 2
	movq	-88(%rbp), %rax
	movb	$0, (%rax)
	movq	-88(%rbp), %rax
	movl	$0, 4(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 8(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 12(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 16(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 20(%rax)
	jmp	.L207
.L223:
	.loc 1 630 14
	movl	-64(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L224
	.loc 1 630 14 is_stmt 0 discriminator 1
	cmpl	$16777217, %eax
	jle	.L225
.L224:
	.loc 1 630 14 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$630, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L225:
	.loc 1 630 9 is_stmt 1 discriminator 3
	movl	%eax, -68(%rbp)
	.loc 1 631 7
	movl	-68(%rbp), %edx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__skip_space
	.loc 1 631 7 is_stmt 0 discriminator 1
	movl	%eax, -68(%rbp)
	.loc 1 632 12 is_stmt 1
	movl	-92(%rbp), %eax
	.loc 1 632 7
	cmpl	%eax, -68(%rbp)
	jne	.L226
	.loc 1 632 31 discriminator 1
	movq	-88(%rbp), %rax
	movb	$2, (%rax)
	movq	-88(%rbp), %rax
	movl	-52(%rbp), %edx
	movl	%edx, 4(%rax)
	movq	-88(%rbp), %rax
	movl	-56(%rbp), %edx
	movl	%edx, 8(%rax)
	movq	-88(%rbp), %rax
	movl	-60(%rbp), %edx
	movl	%edx, 12(%rax)
	movq	-88(%rbp), %rax
	movl	-64(%rbp), %edx
	movl	%edx, 16(%rax)
	movq	-88(%rbp), %rax
	movl	-68(%rbp), %edx
	movl	%edx, 20(%rax)
	jmp	.L207
.L226:
	.loc 1 633 12
	movl	-92(%rbp), %eax
	.loc 1 633 7
	cmpl	%eax, -68(%rbp)
	jge	.L227
	.loc 1 633 35 discriminator 1
	cmpl	-68(%rbp), %ebx
	jg	.L228
	.loc 1 633 35 is_stmt 0 discriminator 2
	cmpl	-68(%rbp), %r12d
	jge	.L229
.L228:
	.loc 1 633 35 discriminator 3
	leaq	.LC39(%rip), %rax
	movl	$633, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L229:
	.loc 1 633 44 is_stmt 1 discriminator 4
	movq	-112(%rbp), %rax
	movl	-68(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	cmpb	$44, %al
	setne	%al
	.loc 1 633 27 discriminator 4
	testb	%al, %al
	je	.L230
.L227:
	.loc 1 633 56 discriminator 5
	movq	-88(%rbp), %rax
	movb	$0, (%rax)
	movq	-88(%rbp), %rax
	movl	$0, 4(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 8(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 12(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 16(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 20(%rax)
	jmp	.L207
.L230:
	.loc 1 634 14
	movl	-68(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L231
	.loc 1 634 14 is_stmt 0 discriminator 1
	cmpl	$16777217, %eax
	jle	.L232
.L231:
	.loc 1 634 14 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$634, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L232:
	.loc 1 634 9 is_stmt 1 discriminator 3
	movl	%eax, -68(%rbp)
	.loc 1 635 7
	movl	-68(%rbp), %edx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__skip_space
	.loc 1 635 7 is_stmt 0 discriminator 1
	movl	%eax, -68(%rbp)
	.loc 1 636 12 is_stmt 1
	movl	-92(%rbp), %eax
	.loc 1 636 7
	cmpl	%eax, -68(%rbp)
	jl	.L233
	.loc 1 636 32 discriminator 1
	movq	-88(%rbp), %rax
	movb	$0, (%rax)
	movq	-88(%rbp), %rax
	movl	$0, 4(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 8(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 12(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 16(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 20(%rax)
	jmp	.L207
.L233:
	.loc 1 637 7
	movq	-88(%rbp), %rax
	movb	$2, (%rax)
	movq	-88(%rbp), %rax
	movl	-52(%rbp), %edx
	movl	%edx, 4(%rax)
	movq	-88(%rbp), %rax
	movl	-56(%rbp), %edx
	movl	%edx, 8(%rax)
	movq	-88(%rbp), %rax
	movl	-60(%rbp), %edx
	movl	%edx, 12(%rax)
	movq	-88(%rbp), %rax
	movl	-64(%rbp), %edx
	movl	%edx, 16(%rax)
	movq	-88(%rbp), %rax
	movl	-68(%rbp), %edx
	movl	%edx, 20(%rax)
.L207:
.LBE27:
	.loc 1 638 8
	movq	-88(%rbp), %rax
	addq	$136, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE12:
	.size	silver_library_reports__read_member, .-silver_library_reports__read_member
	.section	.rodata
	.align 8
.LC50:
	.ascii	"failed precondition from silver_library_reports.adb:696"
	.align 8
.LC51:
	.ascii	"failed precondition from silver_library_reports.adb:697"
	.align 8
.LC52:
	.ascii	"failed precondition from silver_library_reports.adb:698"
	.text
	.align 2
	.type	silver_library_reports__read_item, @function
silver_library_reports__read_item:
.LFB13:
	.loc 1 694 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$120, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -72(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -96(%rbp)
	movq	%rdx, -88(%rbp)
	movq	%rcx, -80(%rbp)
	movl	%r8d, -100(%rbp)
	.loc 1 694 4
	movq	-88(%rbp), %rax
	movl	(%rax), %ebx
	movq	-88(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%ebx, %r12d
	jl	.L235
	.loc 1 694 4 is_stmt 0 discriminator 1
	movslq	%r12d, %rax
	cqto
	movslq	%ebx, %rcx
	movq	%rcx, %rsi
	movq	%rcx, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %r14
	movq	%rdx, %r15
	jmp	.L236
.L235:
	.loc 1 694 4 discriminator 2
	movl	$0, %r14d
	movl	$0, %r15d
.L236:
.LBB32:
	.loc 1 694 4 discriminator 3
	movslq	%ebx, %r13
	cmpl	%ebx, %r12d
	.loc 1 694 4 discriminator 6
	cmpl	%ebx, %r12d
	.loc 1 694 4 discriminator 9
	cmpl	%ebx, %r12d
	.loc 1 696 18 is_stmt 1
	cmpl	$1, %ebx
	je	.L243
.LBB33:
	.loc 1 696 18 is_stmt 0 discriminator 1
	leaq	.LC50(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L243:
.LBE33:
	.loc 1 696 54 is_stmt 1 discriminator 2
	movslq	%ebx, %rax
	leaq	16777215(%rax), %rdx
	movslq	%r12d, %rax
	.loc 1 696 18 discriminator 2
	cmpq	%rax, %rdx
	jge	.L244
.LBB34:
	.loc 1 696 18 is_stmt 0 discriminator 3
	leaq	.LC50(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L244:
.LBE34:
	.loc 1 697 17 is_stmt 1
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__valid
	.loc 1 697 17 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 1 696 18 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L245
.LBB35:
	.loc 1 696 18 is_stmt 0 discriminator 5
	leaq	.LC51(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rcx
	movq	-136(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L245:
.LBE35:
	.loc 1 698 26 is_stmt 1
	movl	-80(%rbp), %eax
	.loc 1 696 18 discriminator 6
	cmpl	%eax, -100(%rbp)
	jle	.L246
	.loc 1 698 60 discriminator 1
	movl	%r14d, %eax
	cmpl	$2147483647, %eax
	jne	.L247
	.loc 1 698 60 is_stmt 0 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$698, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L247:
	.loc 1 698 60 discriminator 4
	movl	%r14d, %eax
	addl	$1, %eax
	.loc 1 698 26 is_stmt 1 discriminator 5
	cmpl	-100(%rbp), %eax
	jge	.L248
.L246:
.LBB36:
	.loc 1 696 18 discriminator 7
	leaq	.LC52(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rcx
	movq	-120(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L248:
.LBE36:
	.loc 1 701 7
	movl	-100(%rbp), %eax
	movl	%eax, -52(%rbp)
	.loc 1 704 7
	movl	-52(%rbp), %edx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__skip_space
	.loc 1 704 7 is_stmt 0 discriminator 1
	movl	%eax, -52(%rbp)
	.loc 1 705 12 is_stmt 1
	movl	-76(%rbp), %eax
	.loc 1 705 7
	cmpl	%eax, -52(%rbp)
	jne	.L249
	.loc 1 705 30 discriminator 1
	movq	-72(%rbp), %rax
	movb	$1, (%rax)
	movq	-72(%rbp), %rax
	movl	$0, 4(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 8(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 12(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 16(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 20(%rax)
	jmp	.L250
.L249:
	.loc 1 706 12
	movl	-76(%rbp), %eax
	.loc 1 706 7
	cmpl	%eax, -52(%rbp)
	jge	.L251
	.loc 1 706 34 discriminator 1
	cmpl	-52(%rbp), %ebx
	jg	.L252
	.loc 1 706 34 is_stmt 0 discriminator 2
	cmpl	-52(%rbp), %r12d
	jge	.L253
.L252:
	.loc 1 706 34 discriminator 3
	leaq	.LC39(%rip), %rax
	movl	$706, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L253:
	.loc 1 706 43 is_stmt 1 discriminator 4
	movq	-96(%rbp), %rax
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	cmpb	$123, %al
	setne	%al
	.loc 1 706 26 discriminator 4
	testb	%al, %al
	je	.L254
.L251:
	.loc 1 706 55 discriminator 5
	movq	-72(%rbp), %rax
	movb	$0, (%rax)
	movq	-72(%rbp), %rax
	movl	$0, 4(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 8(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 12(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 16(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 20(%rax)
	jmp	.L250
.L254:
	.loc 1 707 12
	movl	-52(%rbp), %edx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__value_end
	.loc 1 707 12 is_stmt 0 discriminator 1
	movl	%eax, -56(%rbp)
	.loc 1 708 7 is_stmt 1
	cmpl	$0, -56(%rbp)
	je	.L255
	.loc 1 708 26 discriminator 1
	movl	-76(%rbp), %eax
	.loc 1 708 16 discriminator 1
	cmpl	%eax, -56(%rbp)
	jl	.L256
.L255:
	.loc 1 708 45 discriminator 2
	movq	-72(%rbp), %rax
	movb	$0, (%rax)
	movq	-72(%rbp), %rax
	movl	$0, 4(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 8(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 12(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 16(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 20(%rax)
	jmp	.L250
.L256:
	.loc 1 709 14
	movl	-56(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L257
	.loc 1 709 14 is_stmt 0 discriminator 1
	cmpl	$16777217, %eax
	jle	.L258
.L257:
	.loc 1 709 14 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$709, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L258:
	.loc 1 709 9 is_stmt 1 discriminator 3
	movl	%eax, -60(%rbp)
	.loc 1 710 7
	movl	-60(%rbp), %edx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__skip_space
	.loc 1 710 7 is_stmt 0 discriminator 1
	movl	%eax, -60(%rbp)
	.loc 1 711 12 is_stmt 1
	movl	-76(%rbp), %eax
	.loc 1 711 7
	cmpl	%eax, -60(%rbp)
	jne	.L259
	.loc 1 711 30 discriminator 1
	movq	-72(%rbp), %rax
	movb	$2, (%rax)
	movq	-72(%rbp), %rax
	movl	$0, 4(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 8(%rax)
	movq	-72(%rbp), %rax
	movl	-52(%rbp), %edx
	movl	%edx, 12(%rax)
	movq	-72(%rbp), %rax
	movl	-56(%rbp), %edx
	movl	%edx, 16(%rax)
	movq	-72(%rbp), %rax
	movl	-60(%rbp), %edx
	movl	%edx, 20(%rax)
	jmp	.L250
.L259:
	.loc 1 712 12
	movl	-76(%rbp), %eax
	.loc 1 712 7
	cmpl	%eax, -60(%rbp)
	jge	.L260
	.loc 1 712 34 discriminator 1
	cmpl	-60(%rbp), %ebx
	jg	.L261
	.loc 1 712 34 is_stmt 0 discriminator 2
	cmpl	-60(%rbp), %r12d
	jge	.L262
.L261:
	.loc 1 712 34 discriminator 3
	leaq	.LC39(%rip), %rax
	movl	$712, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L262:
	.loc 1 712 43 is_stmt 1 discriminator 4
	movq	-96(%rbp), %rax
	movl	-60(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	cmpb	$44, %al
	setne	%al
	.loc 1 712 26 discriminator 4
	testb	%al, %al
	je	.L263
.L260:
	.loc 1 712 55 discriminator 5
	movq	-72(%rbp), %rax
	movb	$0, (%rax)
	movq	-72(%rbp), %rax
	movl	$0, 4(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 8(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 12(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 16(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 20(%rax)
	jmp	.L250
.L263:
	.loc 1 713 14
	movl	-60(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L264
	.loc 1 713 14 is_stmt 0 discriminator 1
	cmpl	$16777217, %eax
	jle	.L265
.L264:
	.loc 1 713 14 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$713, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L265:
	.loc 1 713 9 is_stmt 1 discriminator 3
	movl	%eax, -60(%rbp)
	.loc 1 714 7
	movl	-60(%rbp), %edx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__skip_space
	.loc 1 714 7 is_stmt 0 discriminator 1
	movl	%eax, -60(%rbp)
	.loc 1 715 12 is_stmt 1
	movl	-76(%rbp), %eax
	.loc 1 715 7
	cmpl	%eax, -60(%rbp)
	jl	.L266
	.loc 1 715 31 discriminator 1
	movq	-72(%rbp), %rax
	movb	$0, (%rax)
	movq	-72(%rbp), %rax
	movl	$0, 4(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 8(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 12(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 16(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 20(%rax)
	jmp	.L250
.L266:
	.loc 1 716 7
	movq	-72(%rbp), %rax
	movb	$2, (%rax)
	movq	-72(%rbp), %rax
	movl	$0, 4(%rax)
	movq	-72(%rbp), %rax
	movl	$0, 8(%rax)
	movq	-72(%rbp), %rax
	movl	-52(%rbp), %edx
	movl	%edx, 12(%rax)
	movq	-72(%rbp), %rax
	movl	-56(%rbp), %edx
	movl	%edx, 16(%rax)
	movq	-72(%rbp), %rax
	movl	-60(%rbp), %edx
	movl	%edx, 20(%rax)
.L250:
.LBE32:
	.loc 1 717 8
	movq	-72(%rbp), %rax
	addq	$120, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE13:
	.size	silver_library_reports__read_item, .-silver_library_reports__read_item
	.section	.rodata
	.align 8
.LC53:
	.ascii	"failed precondition from silver_library_reports.adb:913"
	.align 8
.LC54:
	.ascii	"Loop_Invariant failed at silver_library_reports.adb:925"
	.align 8
.LC55:
	.ascii	"Loop_Invariant failed at silver_library_reports.adb:926"
	.align 8
.LC56:
	.ascii	"Loop_Variant failed at silver_library_reports.adb:930"
	.text
	.align 2
	.type	silver_library_reports__field, @function
silver_library_reports__field:
.LFB14:
	.loc 1 912 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$200, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r9
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r9, %rdi
	movq	%rsi, -112(%rbp)
	movq	%rdi, -104(%rbp)
	movq	%rdx, -120(%rbp)
	movq	%rcx, %rax
	movq	%r8, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -144(%rbp)
	movq	%rdx, -136(%rbp)
	.loc 1 912 4
	movq	-136(%rbp), %rax
	movl	(%rax), %r8d
	movq	-136(%rbp), %rax
	movl	4(%rax), %r9d
	movq	-104(%rbp), %rax
	movl	(%rax), %r12d
	movq	-104(%rbp), %rax
	movl	4(%rax), %r13d
	cmpl	%r12d, %r13d
	jl	.L268
	.loc 1 912 4 is_stmt 0 discriminator 1
	movslq	%r13d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r12d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %r14
	movq	%rdx, %r15
	jmp	.L269
.L268:
	.loc 1 912 4 discriminator 2
	movl	$0, %r14d
	movl	$0, %r15d
.L269:
.LBB37:
	.loc 1 912 4 discriminator 3
	cmpl	%r8d, %r9d
	.loc 1 912 4 discriminator 6
	cmpl	%r8d, %r9d
	.loc 1 912 4 discriminator 9
	cmpl	%r8d, %r9d
	.loc 1 912 4 discriminator 12
	movslq	%r12d, %rbx
	cmpl	%r12d, %r13d
	.loc 1 912 4 discriminator 15
	cmpl	%r12d, %r13d
	.loc 1 912 4 discriminator 18
	cmpl	%r12d, %r13d
	.loc 1 913 18 is_stmt 1
	cmpl	$1, %r12d
	je	.L282
.LBB38:
	.loc 1 913 18 is_stmt 0 discriminator 1
	leaq	.LC53(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L282:
.LBE38:
	.loc 1 913 54 is_stmt 1 discriminator 2
	movslq	%r12d, %rax
	leaq	16777215(%rax), %rdx
	movslq	%r13d, %rax
	.loc 1 913 18 discriminator 2
	cmpq	%rax, %rdx
	jge	.L283
.LBB39:
	.loc 1 913 18 is_stmt 0 discriminator 3
	leaq	.LC53(%rip), %rax
	movq	%rax, -240(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -232(%rbp)
	movq	-240(%rbp), %rbx
	movq	-232(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L283:
.LBE39:
	.loc 1 917 7 is_stmt 1
	leaq	-80(%rbp), %rax
	movq	%rax, %rdi
	call	silver_library_reports__memberIP
	.loc 1 918 7
	movl	$0, -88(%rbp)
	movl	$0, -84(%rbp)
	.loc 1 920 14
	movq	-120(%rbp), %rax
	movq	-112(%rbp), %rsi
	movq	-104(%rbp), %rcx
	movq	%rax, %rdx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver_library_reports__valid
	.loc 1 920 10 discriminator 1
	xorl	$1, %eax
	.loc 1 920 7 discriminator 1
	testb	%al, %al
	jne	.L284
	.loc 1 920 43 discriminator 2
	movl	-120(%rbp), %eax
	cmpl	%eax, %r12d
	jg	.L285
	.loc 1 920 43 is_stmt 0 discriminator 3
	movl	-120(%rbp), %eax
	cmpl	%eax, %r13d
	jge	.L286
.L285:
	.loc 1 920 43 discriminator 4
	leaq	.LC39(%rip), %rax
	movl	$920, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L286:
	.loc 1 920 63 is_stmt 1 discriminator 5
	movq	-112(%rbp), %rdx
	movl	-120(%rbp), %eax
	cltq
	subq	%rbx, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 1 920 63 is_stmt 0 discriminator 6
	cmpb	$123, %al
	setne	%al
	.loc 1 920 35 is_stmt 1 discriminator 6
	testb	%al, %al
	jne	.L284
	.loc 1 921 17
	movl	-116(%rbp), %eax
	cmpl	%eax, %r12d
	jg	.L287
	.loc 1 921 17 is_stmt 0 discriminator 1
	movl	-116(%rbp), %eax
	cmpl	%eax, %r13d
	jge	.L288
.L287:
	.loc 1 921 17 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$921, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L288:
	.loc 1 921 36 is_stmt 1 discriminator 3
	movq	-112(%rbp), %rax
	movl	-116(%rbp), %edx
	movslq	%edx, %rdx
	subq	%rbx, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 921 36 is_stmt 0 discriminator 4
	cmpb	$125, %al
	setne	%al
	.loc 1 921 9 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L289
.L284:
	.loc 1 922 12
	movl	$0, %eax
	movl	%eax, %edx
	movabsq	$4294967296, %rax
	orq	%rdx, %rax
	jmp	.L309
.L289:
	.loc 1 923 25
	movl	-120(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L291
	.loc 1 923 25 is_stmt 0 discriminator 1
	cmpl	$16777217, %eax
	jle	.L292
.L291:
	.loc 1 923 25 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$923, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L292:
	.loc 1 923 9 is_stmt 1 discriminator 3
	movl	%eax, -52(%rbp)
	.loc 1 924 7
	movl	$0, %ebx
.L308:
.LBB40:
	.loc 1 925 35
	movl	-120(%rbp), %eax
	.loc 1 925 33
	cmpl	%eax, -52(%rbp)
	jle	.L293
	.loc 1 925 70 discriminator 1
	movl	%r14d, %eax
	cmpl	$2147483647, %eax
	jne	.L294
	.loc 1 925 70 is_stmt 0 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$925, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L294:
	.loc 1 925 70 discriminator 4
	movl	%r14d, %eax
	addl	$1, %eax
	.loc 1 925 35 is_stmt 1 discriminator 5
	cmpl	-52(%rbp), %eax
	jge	.L295
.L293:
.LBB41:
	.loc 1 925 33 discriminator 6
	leaq	.LC54(%rip), %rax
	movq	%rax, -224(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rbx
	movq	-216(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L295:
.LBE41:
	.loc 1 926 40
	movl	-88(%rbp), %eax
	.loc 1 926 33
	testl	%eax, %eax
	jne	.L296
	.loc 1 926 40 discriminator 1
	movl	-84(%rbp), %eax
	testl	%eax, %eax
	je	.L297
.L296:
	.loc 1 926 58 discriminator 2
	movq	-88(%rbp), %rdx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__valid
	.loc 1 926 58 is_stmt 0 discriminator 3
	xorl	$1, %eax
	.loc 1 926 50 is_stmt 1 discriminator 3
	testb	%al, %al
	je	.L297
.LBB42:
	.loc 1 926 33 discriminator 4
	leaq	.LC55(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rcx
	movq	-200(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L297:
.LBE42:
	.loc 1 930 10
	testb	%bl, %bl
	je	.L298
	.loc 1 930 44 discriminator 1
	movl	-124(%rbp), %eax
	movl	%eax, -128(%rbp)
.L298:
	.loc 1 930 44 is_stmt 0 discriminator 2
	movl	-52(%rbp), %eax
	movl	%eax, -124(%rbp)
	.loc 1 930 10 is_stmt 1 discriminator 2
	testb	%bl, %bl
	je	.L299
	.loc 1 930 44 discriminator 3
	movl	-128(%rbp), %ecx
	cmpl	%ecx, %eax
	jg	.L300
.LBB43:
	.loc 1 930 44 is_stmt 0 discriminator 4
	leaq	.LC56(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rcx
	movq	-184(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L299:
.LBE43:
	.loc 1 930 10 is_stmt 1 discriminator 5
	movl	$1, %ebx
.L300:
	.loc 1 931 15
	leaq	-176(%rbp), %r9
	movl	-52(%rbp), %eax
	movq	-120(%rbp), %rdx
	movq	-112(%rbp), %rsi
	movq	-104(%rbp), %rdi
	movl	%eax, %r8d
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%r9, %rdi
	call	silver_library_reports__read_member
	movq	-176(%rbp), %rax
	movq	-168(%rbp), %rdx
	movq	%rax, -80(%rbp)
	movq	%rdx, -72(%rbp)
	movq	-160(%rbp), %rax
	movq	%rax, -64(%rbp)
	.loc 1 932 16
	movzbl	-80(%rbp), %eax
	cmpb	$2, %al
	jbe	.L301
	.loc 1 932 16 is_stmt 0 discriminator 1
	leaq	.LC39(%rip), %rax
	movl	$932, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L301:
	.loc 1 932 10 is_stmt 1 discriminator 2
	testb	%al, %al
	je	.L302
	cmpb	$1, %al
	je	.L303
	jmp	.L310
.L302:
	.loc 1 933 28
	movl	$0, %eax
	movl	%eax, %edx
	movabsq	$4294967296, %rax
	orq	%rdx, %rax
	jmp	.L309
.L303:
	.loc 1 934 30
	movq	-88(%rbp), %rax
	jmp	.L309
.L310:
	.loc 1 936 19
	movq	-144(%rbp), %rax
	movq	-136(%rbp), %rdx
	movq	-76(%rbp), %rsi
	movq	-112(%rbp), %rdi
	movq	-104(%rbp), %r9
	movq	%rax, %rcx
	movq	%rdx, %r8
	movq	%rsi, %rdx
	movq	%r9, %rsi
	call	silver_library_reports__string_equal
	.loc 1 936 16 discriminator 1
	testb	%al, %al
	je	.L305
	.loc 1 937 29
	movl	-88(%rbp), %eax
	.loc 1 937 19
	testl	%eax, %eax
	jne	.L306
	.loc 1 937 29 discriminator 1
	movl	-84(%rbp), %eax
	testl	%eax, %eax
	je	.L307
.L306:
	.loc 1 937 45 discriminator 2
	movl	$0, %eax
	movl	%eax, %edx
	movabsq	$4294967296, %rax
	orq	%rdx, %rax
	jmp	.L309
.L307:
	.loc 1 938 26
	movq	-68(%rbp), %rax
	movq	%rax, -88(%rbp)
.L305:
	.loc 1 940 18
	movl	-60(%rbp), %eax
	movl	%eax, -52(%rbp)
	.loc 1 941 14
	nop
.LBE40:
	.loc 1 942 15
	jmp	.L308
.L309:
.LBE37:
	.loc 1 943 8
	addq	$200, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE14:
	.size	silver_library_reports__field, .-silver_library_reports__field
	.section	.rodata
	.align 8
.LC57:
	.ascii	"failed precondition from silver_library_reports.adb:955"
	.text
	.align 2
	.type	silver_library_reports__empty_object, @function
silver_library_reports__empty_object:
.LFB15:
	.loc 1 954 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -64(%rbp)
	movq	%rbx, -56(%rbp)
	movq	%rdx, -72(%rbp)
	.loc 1 954 4
	movq	-56(%rbp), %rax
	movl	(%rax), %ebx
	movq	-56(%rbp), %rax
	movl	4(%rax), %r12d
.LBB44:
	movslq	%ebx, %r13
	cmpl	%ebx, %r12d
	.loc 1 954 4 is_stmt 0 discriminator 3
	cmpl	%ebx, %r12d
	.loc 1 954 4 discriminator 6
	cmpl	%ebx, %r12d
	.loc 1 955 18 is_stmt 1
	cmpl	$1, %ebx
	je	.L318
.LBB45:
	.loc 1 955 18 is_stmt 0 discriminator 1
	leaq	.LC57(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L318:
.LBE45:
	.loc 1 955 54 is_stmt 1 discriminator 2
	movslq	%ebx, %rax
	leaq	16777215(%rax), %rdx
	movslq	%r12d, %rax
	.loc 1 955 18 discriminator 2
	cmpq	%rax, %rdx
	jge	.L319
.LBB46:
	.loc 1 955 18 is_stmt 0 discriminator 3
	leaq	.LC57(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L319:
.LBE46:
	.loc 1 960 14 is_stmt 1
	movq	-72(%rbp), %rdx
	movq	-64(%rbp), %rcx
	movq	-56(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__valid
	.loc 1 960 10 discriminator 1
	xorl	$1, %eax
	.loc 1 960 7 discriminator 1
	testb	%al, %al
	jne	.L320
	.loc 1 960 41 discriminator 2
	movl	-72(%rbp), %eax
	cmpl	%eax, %ebx
	jg	.L321
	.loc 1 960 41 is_stmt 0 discriminator 3
	movl	-72(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L322
.L321:
	.loc 1 960 41 discriminator 4
	leaq	.LC39(%rip), %rax
	movl	$960, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L322:
	.loc 1 960 59 is_stmt 1 discriminator 5
	movq	-64(%rbp), %rax
	movl	-72(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	cmpb	$123, %al
	setne	%al
	.loc 1 960 33 discriminator 5
	testb	%al, %al
	jne	.L320
	.loc 1 961 17
	movl	-68(%rbp), %eax
	cmpl	%eax, %ebx
	jg	.L323
	.loc 1 961 17 is_stmt 0 discriminator 1
	movl	-68(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L324
.L323:
	.loc 1 961 17 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$961, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L324:
	.loc 1 961 34 is_stmt 1 discriminator 3
	movq	-64(%rbp), %rax
	movl	-68(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	cmpb	$125, %al
	setne	%al
	.loc 1 961 9 discriminator 3
	testb	%al, %al
	je	.L325
.L320:
	.loc 1 963 10
	movl	$0, %eax
	jmp	.L326
.L325:
	.loc 1 965 23
	movl	-72(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L327
	.loc 1 965 23 is_stmt 0 discriminator 1
	cmpl	$16777217, %eax
	jle	.L328
.L327:
	.loc 1 965 23 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$965, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L328:
	.loc 1 965 9 is_stmt 1 discriminator 3
	movl	%eax, -36(%rbp)
	.loc 1 966 7
	movl	-36(%rbp), %edx
	movq	-64(%rbp), %rcx
	movq	-56(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__skip_space
	.loc 1 966 7 is_stmt 0 discriminator 1
	movl	%eax, -36(%rbp)
	.loc 1 967 16 is_stmt 1
	movl	-68(%rbp), %eax
	.loc 1 967 7
	cmpl	%eax, -36(%rbp)
	sete	%al
.L326:
.LBE44:
	.loc 1 968 8
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE15:
	.size	silver_library_reports__empty_object, .-silver_library_reports__empty_object
	.section	.rodata
	.align 8
.LC58:
	.ascii	"failed precondition from silver_library_reports.adb:980"
	.text
	.align 2
	.type	silver_library_reports__empty_array, @function
silver_library_reports__empty_array:
.LFB16:
	.loc 1 979 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -64(%rbp)
	movq	%rbx, -56(%rbp)
	movq	%rdx, -72(%rbp)
	.loc 1 979 4
	movq	-56(%rbp), %rax
	movl	(%rax), %ebx
	movq	-56(%rbp), %rax
	movl	4(%rax), %r12d
.LBB47:
	movslq	%ebx, %r13
	cmpl	%ebx, %r12d
	.loc 1 979 4 is_stmt 0 discriminator 3
	cmpl	%ebx, %r12d
	.loc 1 979 4 discriminator 6
	cmpl	%ebx, %r12d
	.loc 1 980 18 is_stmt 1
	cmpl	$1, %ebx
	je	.L336
.LBB48:
	.loc 1 980 18 is_stmt 0 discriminator 1
	leaq	.LC58(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L336:
.LBE48:
	.loc 1 980 54 is_stmt 1 discriminator 2
	movslq	%ebx, %rax
	leaq	16777215(%rax), %rdx
	movslq	%r12d, %rax
	.loc 1 980 18 discriminator 2
	cmpq	%rax, %rdx
	jge	.L337
.LBB49:
	.loc 1 980 18 is_stmt 0 discriminator 3
	leaq	.LC58(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L337:
.LBE49:
	.loc 1 985 14 is_stmt 1
	movq	-72(%rbp), %rdx
	movq	-64(%rbp), %rcx
	movq	-56(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__valid
	.loc 1 985 10 discriminator 1
	xorl	$1, %eax
	.loc 1 985 7 discriminator 1
	testb	%al, %al
	jne	.L338
	.loc 1 985 41 discriminator 2
	movl	-72(%rbp), %eax
	cmpl	%eax, %ebx
	jg	.L339
	.loc 1 985 41 is_stmt 0 discriminator 3
	movl	-72(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L340
.L339:
	.loc 1 985 41 discriminator 4
	leaq	.LC39(%rip), %rax
	movl	$985, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L340:
	.loc 1 985 59 is_stmt 1 discriminator 5
	movq	-64(%rbp), %rax
	movl	-72(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	cmpb	$91, %al
	setne	%al
	.loc 1 985 33 discriminator 5
	testb	%al, %al
	jne	.L338
	.loc 1 986 17
	movl	-68(%rbp), %eax
	cmpl	%eax, %ebx
	jg	.L341
	.loc 1 986 17 is_stmt 0 discriminator 1
	movl	-68(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L342
.L341:
	.loc 1 986 17 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$986, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L342:
	.loc 1 986 34 is_stmt 1 discriminator 3
	movq	-64(%rbp), %rax
	movl	-68(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	cmpb	$93, %al
	setne	%al
	.loc 1 986 9 discriminator 3
	testb	%al, %al
	je	.L343
.L338:
	.loc 1 988 10
	movl	$0, %eax
	jmp	.L344
.L343:
	.loc 1 990 23
	movl	-72(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L345
	.loc 1 990 23 is_stmt 0 discriminator 1
	cmpl	$16777217, %eax
	jle	.L346
.L345:
	.loc 1 990 23 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$990, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L346:
	.loc 1 990 9 is_stmt 1 discriminator 3
	movl	%eax, -36(%rbp)
	.loc 1 991 7
	movl	-36(%rbp), %edx
	movq	-64(%rbp), %rcx
	movq	-56(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__skip_space
	.loc 1 991 7 is_stmt 0 discriminator 1
	movl	%eax, -36(%rbp)
	.loc 1 992 16 is_stmt 1
	movl	-68(%rbp), %eax
	.loc 1 992 7
	cmpl	%eax, -36(%rbp)
	sete	%al
.L344:
.LBE47:
	.loc 1 993 8
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE16:
	.size	silver_library_reports__empty_array, .-silver_library_reports__empty_array
	.align 2
	.type	silver_library_reports__entity_kindH, @function
silver_library_reports__entity_kindH:
.LFB17:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	movq	-8(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L348
	movl	%edx, %ecx
	subl	%eax, %ecx
	leal	1(%rcx), %r11d
	jmp	.L349
.L348:
	movl	$0, %r11d
.L349:
	movslq	%eax, %r9
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	leal	-1(%rax), %r10d
	movl	$0, %esi
	movl	$0, %ecx
	movl	$0, %edx
.L357:
	cmpl	$2, %edx
	jg	.L356
	movslq	%edx, %rax
	leaq	0(,%rax,4), %rdi
	leaq	entity_kindP.11(%rip), %rax
	movl	(%rdi,%rax), %eax
	cmpl	%eax, %r11d
	jl	.L356
	movq	-16(%rbp), %rax
	movslq	%edx, %rdi
	leaq	0(,%rdi,4), %r8
	leaq	entity_kindP.11(%rip), %rdi
	movl	(%r8,%rdi), %edi
	addl	%r10d, %edi
	movslq	%edi, %rdi
	subq	%r9, %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %r8d
	movslq	%edx, %rax
	leaq	entity_kindT1.10(%rip), %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %eax
	imull	%r8d, %eax
	leal	(%rsi,%rax), %edi
	movslq	%edi, %rax
	imulq	$-580400985, %rax, %rax
	shrq	$32, %rax
	addl	%edi, %eax
	sarl	$5, %eax
	movl	%eax, %esi
	movl	%edi, %eax
	sarl	$31, %eax
	subl	%eax, %esi
	movl	%esi, %eax
	sall	$3, %eax
	addl	%esi, %eax
	sall	$2, %eax
	addl	%esi, %eax
	movl	%edi, %esi
	subl	%eax, %esi
	movslq	%edx, %rax
	leaq	entity_kindT2.9(%rip), %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %eax
	imull	%r8d, %eax
	leal	(%rcx,%rax), %edi
	movslq	%edi, %rax
	imulq	$-580400985, %rax, %rax
	shrq	$32, %rax
	addl	%edi, %eax
	sarl	$5, %eax
	movl	%eax, %ecx
	movl	%edi, %eax
	sarl	$31, %eax
	subl	%eax, %ecx
	movl	%ecx, %eax
	sall	$3, %eax
	addl	%ecx, %eax
	sall	$2, %eax
	addl	%ecx, %eax
	movl	%edi, %ecx
	subl	%eax, %ecx
	addl	$1, %edx
	jmp	.L357
.L356:
	movslq	%esi, %rax
	leaq	entity_kindG.8(%rip), %rdx
	movzbl	(%rax,%rdx), %eax
	movzbl	%al, %edx
	movslq	%ecx, %rax
	leaq	entity_kindG.8(%rip), %rcx
	movzbl	(%rax,%rcx), %eax
	movzbl	%al, %eax
	leal	(%rdx,%rax), %ecx
	movslq	%ecx, %rax
	imulq	$954437177, %rax, %rax
	shrq	$32, %rax
	movl	%eax, %edx
	sarl	$2, %edx
	movl	%ecx, %eax
	sarl	$31, %eax
	subl	%eax, %edx
	movl	%edx, %eax
	sall	$3, %eax
	addl	%edx, %eax
	addl	%eax, %eax
	subl	%eax, %ecx
	movl	%ecx, %edx
	movl	%edx, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE17:
	.size	silver_library_reports__entity_kindH, .-silver_library_reports__entity_kindH
	.align 2
	.type	silver_library_reports__location_ok__B484b___finalizer.0, @function
silver_library_reports__location_ok__B484b___finalizer.0:
.LFB19:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE19:
	.size	silver_library_reports__location_ok__B484b___finalizer.0, .-silver_library_reports__location_ok__B484b___finalizer.0
	.section	.rodata
	.align 8
.LC59:
	.ascii	"failed precondition from silver_library_reports.adb:1029"
	.align 8
.LC2:
	.long	1
	.long	56
	.align 8
.LC3:
	.long	1
	.long	4
	.text
	.align 2
	.type	silver_library_reports__location_ok, @function
silver_library_reports__location_ok:
.LFB18:
	.loc 1 1027 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA18
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB0:
	subq	$168, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -128(%rbp)
	movq	%rdi, -120(%rbp)
	movq	%rdx, -136(%rbp)
	movb	%cl, -137(%rbp)
	.loc 1 1027 4
	leaq	16(%rbp), %rax
	.loc 1 1027 4 is_stmt 0 discriminator 1
	movq	%rax, -72(%rbp)
	movq	-120(%rbp), %rax
	movl	(%rax), %ebx
	movq	-120(%rbp), %rax
	movl	4(%rax), %r12d
.LBB52:
	movslq	%ebx, %r13
	cmpl	%ebx, %r12d
	.loc 1 1027 4 discriminator 4
	cmpl	%ebx, %r12d
	.loc 1 1027 4 discriminator 7
	cmpl	%ebx, %r12d
	.loc 1 1029 18 is_stmt 1
	cmpl	$1, %ebx
	je	.L368
.LBB53:
	.loc 1 1029 18 is_stmt 0 discriminator 1
	leaq	.LC59(%rip), %r10
	leaq	.LC2(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L368:
.LBE53:
	.loc 1 1029 54 is_stmt 1 discriminator 2
	movslq	%ebx, %rax
	leaq	16777215(%rax), %rdx
	movslq	%r12d, %rax
	.loc 1 1029 18 discriminator 2
	cmpq	%rax, %rdx
	jge	.L369
.LBB54:
	.loc 1 1029 18 is_stmt 0 discriminator 3
	leaq	.LC59(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC2(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L369:
.LBE54:
	.loc 1 1032 36 is_stmt 1
	leaq	silver_library_reports__json_sloc(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC3(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rax
	movq	-152(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-136(%rbp), %rdx
	movq	-128(%rbp), %rsi
	movq	-120(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -104(%rbp)
	.loc 1 1034 7
	movl	$0, -112(%rbp)
	movl	$0, -108(%rbp)
	.loc 1 1036 14
	movq	-104(%rbp), %rdx
	movq	-128(%rbp), %rcx
	movq	-120(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__valid
	.loc 1 1036 10 discriminator 1
	xorl	$1, %eax
	.loc 1 1036 7 discriminator 1
	testb	%al, %al
	jne	.L370
	.loc 1 1036 46 discriminator 2
	movl	-104(%rbp), %eax
	cmpl	%eax, %ebx
	jg	.L371
	.loc 1 1036 46 is_stmt 0 discriminator 3
	movl	-104(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L372
.L371:
	.loc 1 1036 46 discriminator 4
	leaq	.LC39(%rip), %rax
	movl	$1036, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L372:
	.loc 1 1036 69 is_stmt 1 discriminator 5
	movq	-128(%rbp), %rax
	movl	-104(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 1036 69 is_stmt 0 discriminator 6
	cmpb	$91, %al
	setne	%al
	.loc 1 1036 38 is_stmt 1 discriminator 6
	testb	%al, %al
	jne	.L370
	.loc 1 1037 17
	movl	-100(%rbp), %eax
	cmpl	%eax, %ebx
	jg	.L373
	.loc 1 1037 17 is_stmt 0 discriminator 1
	movl	-100(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L374
.L373:
	.loc 1 1037 17 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1037, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L374:
	.loc 1 1037 39 is_stmt 1 discriminator 3
	movq	-128(%rbp), %rax
	movl	-100(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 1037 39 is_stmt 0 discriminator 4
	cmpb	$93, %al
	setne	%al
	.loc 1 1037 9 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L375
.L370:
	.loc 1 1038 12
	movb	$0, -138(%rbp)
	jmp	.L388
.L375:
	.loc 1 1039 28
	movl	-104(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L377
	.loc 1 1039 28 is_stmt 0 discriminator 1
	cmpl	$16777217, %eax
	jle	.L378
.L377:
	.loc 1 1039 28 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1039, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L378:
	.loc 1 1039 9 is_stmt 1 discriminator 3
	movl	%eax, -52(%rbp)
	.loc 1 1040 7
	movl	-52(%rbp), %edx
	movq	-128(%rbp), %rcx
	movq	-120(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__skip_space
	.loc 1 1040 7 is_stmt 0 discriminator 1
	movl	%eax, -52(%rbp)
	.loc 1 1041 15 is_stmt 1
	movl	-52(%rbp), %edx
	movq	-128(%rbp), %rcx
	movq	-120(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__value_end
	.loc 1 1041 15 is_stmt 0 discriminator 1
	movl	%eax, -56(%rbp)
	.loc 1 1042 7 is_stmt 1
	cmpl	$0, -56(%rbp)
	je	.L379
	.loc 1 1042 32 discriminator 1
	movl	-100(%rbp), %eax
	.loc 1 1042 19 discriminator 1
	cmpl	%eax, -56(%rbp)
	jl	.L380
.L379:
	.loc 1 1042 55 discriminator 2
	movb	$0, -138(%rbp)
	jmp	.L388
.L380:
	.loc 1 1043 15
	leaq	silver_library_reports__json_file(%rip), %r14
	leaq	.LC3(%rip), %r15
	movl	-52(%rbp), %eax
	movabsq	$-4294967296, %rdx
	andq	-200(%rbp), %rdx
	orq	%rdx, %rax
	movq	%rax, %rcx
	movl	-56(%rbp), %eax
	salq	$32, %rax
	movl	%ecx, %edx
	orq	%rdx, %rax
	movq	%rax, %rbx
	movq	%r14, %rdx
	movq	%r15, %rdi
	movq	-128(%rbp), %rsi
	movq	-120(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %r8
	movq	%rbx, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	.loc 1 1043 12 discriminator 1
	movq	%rax, -112(%rbp)
	.loc 1 1044 17
	movl	-56(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L381
	.loc 1 1044 17 is_stmt 0 discriminator 1
	cmpl	$16777217, %eax
	jle	.L382
.L381:
	.loc 1 1044 17 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1044, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L382:
	.loc 1 1044 9 is_stmt 1 discriminator 3
	movl	%eax, -52(%rbp)
	.loc 1 1045 7
	movl	-52(%rbp), %edx
	movq	-128(%rbp), %rcx
	movq	-120(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__skip_space
.LEHE0:
	.loc 1 1045 7 is_stmt 0 discriminator 1
	movl	%eax, -52(%rbp)
	.loc 1 1046 12 is_stmt 1
	movl	-100(%rbp), %eax
	.loc 1 1046 7
	cmpl	%eax, -52(%rbp)
	je	.L383
	.loc 1 1046 35 discriminator 1
	movb	$0, -138(%rbp)
	jmp	.L388
.L383:
	leaq	-96(%rbp), %rax
	movq	%rax, %rdi
.LEHB1:
	call	system__secondary_stack__ss_mark@PLT
.LBB55:
	.loc 1 1048 9
	cmpb	$0, -137(%rbp)
	je	.L384
	.loc 1 1048 44 discriminator 1
	movzbl	-137(%rbp), %eax
	movl	%eax, %edi
	call	silver_library_reports__entity_file
	.loc 1 1048 18 discriminator 2
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-112(%rbp), %rdx
	movq	-128(%rbp), %rsi
	movq	-120(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
.LEHE1:
	.loc 1 1048 9 discriminator 3
	testb	%al, %al
	je	.L384
	.loc 1 1048 9 is_stmt 0 discriminator 4
	movb	$1, -138(%rbp)
	jmp	.L385
.L384:
	.loc 1 1048 9 discriminator 5
	movb	$0, -138(%rbp)
.L385:
	.loc 1 1047 7 is_stmt 1
	movl	$0, %ebx
.L390:
	.loc 1 1047 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
.LEHB2:
	call	silver_library_reports__location_ok__B484b___finalizer.0
.LEHE2:
	.loc 1 1047 0 is_stmt 0 discriminator 2
	cmpl	$1, %ebx
	je	.L386
	movl	$0, %eax
.L392:
	.loc 1 1047 0 discriminator 3
	cmpl	$1, %eax
	je	.L387
.L388:
.LBE55:
.LBE52:
	.loc 1 1049 8 is_stmt 1
	movzbl	-138(%rbp), %eax
	jmp	.L395
.L393:
	movq	%rax, -192(%rbp)
	movl	$1, %ebx
.LBB57:
.LBB56:
	.loc 1 1047 7 discriminator 4
	jmp	.L390
.L386:
	movq	-192(%rbp), %rax
	movq	%rax, -184(%rbp)
	jmp	.L391
.L394:
	movq	%rax, -184(%rbp)
.L391:
	movl	$1, %eax
	jmp	.L392
.L387:
	movq	-184(%rbp), %rax
	movq	%rax, %rdi
.LEHB3:
	call	_Unwind_Resume@PLT
.L395:
.LBE56:
.LBE57:
	.loc 1 1049 8
	addq	$168, %rsp
.LEHE3:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE18:
	.section	.gcc_except_table,"a",@progbits
.LLSDA18:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE18-.LLSDACSB18
.LLSDACSB18:
	.uleb128 .LEHB0-.LFB18
	.uleb128 .LEHE0-.LEHB0
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB1-.LFB18
	.uleb128 .LEHE1-.LEHB1
	.uleb128 .L393-.LFB18
	.uleb128 0
	.uleb128 .LEHB2-.LFB18
	.uleb128 .LEHE2-.LEHB2
	.uleb128 .L394-.LFB18
	.uleb128 0
	.uleb128 .LEHB3-.LFB18
	.uleb128 .LEHE3-.LEHB3
	.uleb128 0
	.uleb128 0
.LLSDACSE18:
	.text
	.size	silver_library_reports__location_ok, .-silver_library_reports__location_ok
	.section	.rodata
	.align 8
.LC60:
	.ascii	"failed precondition from silver_library_reports.adb:1055"
	.text
	.align 2
	.globl	silver_library_reports__main_spelling
	.type	silver_library_reports__main_spelling, @function
silver_library_reports__main_spelling:
.LFB20:
	.loc 1 1057 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r12
	pushq	%rbx
	subq	$32, %rsp
	.cfi_offset 12, -24
	.cfi_offset 3, -32
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -32(%rbp)
	movq	%rbx, -24(%rbp)
	movq	%rdx, -40(%rbp)
	.loc 1 1057 4
	movq	-24(%rbp), %rax
	movl	(%rax), %ebx
	movq	-24(%rbp), %rax
	movl	4(%rax), %r12d
.LBB58:
	.loc 1 1055 18
	cmpl	$1, %ebx
	je	.L397
.LBB59:
	.loc 1 1055 18 is_stmt 0 discriminator 1
	leaq	.LC60(%rip), %r10
	leaq	.LC2(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L397:
.LBE59:
	.loc 1 1055 54 is_stmt 1 discriminator 2
	movslq	%ebx, %rax
	leaq	16777215(%rax), %rdx
	movslq	%r12d, %rax
	.loc 1 1055 18 discriminator 2
	cmpq	%rax, %rdx
	jge	.L398
.LBB60:
	.loc 1 1055 18 is_stmt 0 discriminator 3
	leaq	.LC60(%rip), %r8
	leaq	.LC2(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L398:
.LBE60:
	.loc 1 1058 7 is_stmt 1
	movq	-40(%rbp), %rdx
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__valid
	.loc 1 1063 7
	testb	%al, %al
	je	.L399
	.loc 1 1058 45 discriminator 2
	movl	-36(%rbp), %edx
	movl	-40(%rbp), %eax
	subl	%eax, %edx
	.loc 1 1058 26 discriminator 2
	cmpl	$5, %edx
	jne	.L399
	.loc 1 1059 16
	movl	-40(%rbp), %eax
	cmpl	%eax, %ebx
	jg	.L400
	.loc 1 1059 16 is_stmt 0 discriminator 1
	movl	-40(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L401
.L400:
	.loc 1 1059 16 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1059, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L401:
	.loc 1 1059 34 is_stmt 1 discriminator 3
	movq	-32(%rbp), %rax
	movq	-24(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-40(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$34, %al
	sete	%al
	.loc 1 1059 7 discriminator 3
	testb	%al, %al
	je	.L399
	.loc 1 1059 49 discriminator 4
	movl	-36(%rbp), %eax
	cmpl	%eax, %ebx
	jg	.L402
	.loc 1 1059 49 is_stmt 0 discriminator 5
	movl	-36(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L403
.L402:
	.loc 1 1059 49 discriminator 6
	leaq	.LC39(%rip), %rax
	movl	$1059, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L403:
	.loc 1 1059 66 is_stmt 1 discriminator 7
	movq	-32(%rbp), %rax
	movq	-24(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-36(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$34, %al
	sete	%al
	.loc 1 1059 40 discriminator 7
	testb	%al, %al
	je	.L399
	.loc 1 1060 33
	movl	-40(%rbp), %eax
	addl	$1, %eax
	.loc 1 1060 16
	cmpl	%eax, %ebx
	jg	.L404
	.loc 1 1060 16 is_stmt 0 discriminator 1
	movl	-40(%rbp), %eax
	cmpl	%eax, %r12d
	jg	.L405
.L404:
	.loc 1 1060 16 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1060, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L405:
	.loc 1 1060 41 is_stmt 1 discriminator 3
	movq	-32(%rbp), %rax
	movq	-24(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 1 1060 33 discriminator 3
	movl	-40(%rbp), %ecx
	addl	$1, %ecx
	movslq	%ecx, %rcx
	.loc 1 1060 41 discriminator 3
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 1 1060 47 discriminator 3
	cmpb	$109, %al
	je	.L406
	.loc 1 1060 47 is_stmt 0 discriminator 4
	movq	-32(%rbp), %rax
	movq	-24(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 1 1060 33 is_stmt 1 discriminator 4
	movl	-40(%rbp), %ecx
	addl	$1, %ecx
	movslq	%ecx, %rcx
	.loc 1 1060 47 discriminator 4
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$77, %al
	jne	.L407
.L406:
	.loc 1 1060 47 is_stmt 0 discriminator 5
	movl	$1, %eax
	jmp	.L408
.L407:
	.loc 1 1060 47 discriminator 6
	movl	$0, %eax
.L408:
	.loc 1 1060 7 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L399
	.loc 1 1061 33
	movl	-40(%rbp), %eax
	addl	$2, %eax
	.loc 1 1061 16
	cmpl	%eax, %ebx
	jg	.L409
	.loc 1 1061 16 is_stmt 0 discriminator 1
	movl	-40(%rbp), %eax
	addl	$1, %eax
	cmpl	%eax, %r12d
	jg	.L410
.L409:
	.loc 1 1061 16 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1061, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L410:
	.loc 1 1061 41 is_stmt 1 discriminator 3
	movq	-32(%rbp), %rax
	movq	-24(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 1 1061 33 discriminator 3
	movl	-40(%rbp), %ecx
	addl	$2, %ecx
	movslq	%ecx, %rcx
	.loc 1 1061 41 discriminator 3
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 1 1061 47 discriminator 3
	cmpb	$97, %al
	je	.L411
	.loc 1 1061 47 is_stmt 0 discriminator 4
	movq	-32(%rbp), %rax
	movq	-24(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 1 1061 33 is_stmt 1 discriminator 4
	movl	-40(%rbp), %ecx
	addl	$2, %ecx
	movslq	%ecx, %rcx
	.loc 1 1061 47 discriminator 4
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$65, %al
	jne	.L412
.L411:
	.loc 1 1061 47 is_stmt 0 discriminator 5
	movl	$1, %eax
	jmp	.L413
.L412:
	.loc 1 1061 47 discriminator 6
	movl	$0, %eax
.L413:
	.loc 1 1061 7 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L399
	.loc 1 1062 33
	movl	-40(%rbp), %eax
	addl	$3, %eax
	.loc 1 1062 16
	cmpl	%eax, %ebx
	jg	.L414
	.loc 1 1062 16 is_stmt 0 discriminator 1
	movl	-40(%rbp), %eax
	addl	$2, %eax
	cmpl	%eax, %r12d
	jg	.L415
.L414:
	.loc 1 1062 16 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1062, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L415:
	.loc 1 1062 41 is_stmt 1 discriminator 3
	movq	-32(%rbp), %rax
	movq	-24(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 1 1062 33 discriminator 3
	movl	-40(%rbp), %ecx
	addl	$3, %ecx
	movslq	%ecx, %rcx
	.loc 1 1062 41 discriminator 3
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 1 1062 47 discriminator 3
	cmpb	$105, %al
	je	.L416
	.loc 1 1062 47 is_stmt 0 discriminator 4
	movq	-32(%rbp), %rax
	movq	-24(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 1 1062 33 is_stmt 1 discriminator 4
	movl	-40(%rbp), %ecx
	addl	$3, %ecx
	movslq	%ecx, %rcx
	.loc 1 1062 47 discriminator 4
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$73, %al
	jne	.L417
.L416:
	.loc 1 1062 47 is_stmt 0 discriminator 5
	movl	$1, %eax
	jmp	.L418
.L417:
	.loc 1 1062 47 discriminator 6
	movl	$0, %eax
.L418:
	.loc 1 1062 7 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L399
	.loc 1 1063 33 discriminator 1
	movl	-40(%rbp), %eax
	addl	$4, %eax
	.loc 1 1063 16 discriminator 1
	cmpl	%eax, %ebx
	jg	.L419
	.loc 1 1063 16 is_stmt 0 discriminator 2
	movl	-40(%rbp), %eax
	addl	$3, %eax
	cmpl	%eax, %r12d
	jg	.L420
.L419:
	.loc 1 1063 16 discriminator 3
	leaq	.LC39(%rip), %rax
	movl	$1063, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L420:
	.loc 1 1063 41 is_stmt 1 discriminator 4
	movq	-32(%rbp), %rax
	movq	-24(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 1 1063 33 discriminator 4
	movl	-40(%rbp), %ecx
	addl	$4, %ecx
	movslq	%ecx, %rcx
	.loc 1 1063 41 discriminator 4
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 1 1063 47 discriminator 4
	cmpb	$110, %al
	je	.L421
	.loc 1 1063 47 is_stmt 0 discriminator 5
	movq	-32(%rbp), %rax
	movq	-24(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 1 1063 33 is_stmt 1 discriminator 5
	movl	-40(%rbp), %ecx
	addl	$4, %ecx
	movslq	%ecx, %rcx
	.loc 1 1063 47 discriminator 5
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$78, %al
	jne	.L422
.L421:
	.loc 1 1063 47 is_stmt 0 discriminator 6
	movl	$1, %eax
	jmp	.L423
.L422:
	.loc 1 1063 47 discriminator 7
	movl	$0, %eax
.L423:
	.loc 1 1063 7 is_stmt 1 discriminator 8
	testb	%al, %al
	je	.L399
	.loc 1 1063 7 is_stmt 0 discriminator 9
	movl	$1, %eax
	jmp	.L424
.L399:
	.loc 1 1063 7 discriminator 10
	movl	$0, %eax
.L424:
.LBE58:
	.loc 1 1057 4 is_stmt 1
	addq	$32, %rsp
	popq	%rbx
	popq	%r12
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE20:
	.size	silver_library_reports__main_spelling, .-silver_library_reports__main_spelling
	.section	.rodata
	.align 8
.LC61:
	.ascii	"failed precondition from silver_library_reports.adb:1093"
	.align 8
.LC4:
	.long	1
	.long	9
	.align 8
.LC5:
	.long	1
	.long	18
	.align 8
.LC6:
	.long	1
	.long	13
	.align 8
.LC7:
	.long	1
	.long	27
	.align 8
.LC8:
	.long	1
	.long	24
	.align 8
.LC9:
	.long	1
	.long	34
	.align 8
.LC10:
	.long	1
	.long	16
	.align 8
.LC11:
	.long	1
	.long	31
	.align 8
.LC12:
	.long	1
	.long	33
	.align 8
.LC13:
	.long	1
	.long	23
	.align 8
.LC14:
	.long	1
	.long	14
	.align 8
.LC15:
	.long	1
	.long	29
	.align 8
.LC16:
	.long	1
	.long	30
	.text
	.align 2
	.type	silver_library_reports__entity_name, @function
silver_library_reports__entity_name:
.LFB21:
	.loc 1 1092 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$296, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -80(%rbp)
	movq	%rbx, -72(%rbp)
	movq	%rdx, -88(%rbp)
	.loc 1 1092 4
	movq	-72(%rbp), %rax
	movl	(%rax), %edx
	movq	-72(%rbp), %rax
	movl	4(%rax), %ecx
.LBB61:
	cmpl	%edx, %ecx
	.loc 1 1092 4 is_stmt 0 discriminator 3
	cmpl	%edx, %ecx
	.loc 1 1092 4 discriminator 6
	cmpl	%edx, %ecx
	.loc 1 1093 18 is_stmt 1
	cmpl	$1, %edx
	je	.L433
.LBB62:
	.loc 1 1093 18 is_stmt 0 discriminator 1
	leaq	.LC61(%rip), %r8
	leaq	.LC2(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L433:
.LBE62:
	.loc 1 1093 54 is_stmt 1 discriminator 2
	movslq	%edx, %rax
	leaq	16777215(%rax), %rdx
	movslq	%ecx, %rax
	.loc 1 1093 18 discriminator 2
	cmpq	%rax, %rdx
	jge	.L434
.LBB63:
	.loc 1 1093 18 is_stmt 0 discriminator 3
	leaq	.LC61(%rip), %r10
	leaq	.LC2(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L434:
.LBE63:
	.loc 1 1096 31 is_stmt 1
	leaq	silver_library_reports__json_name(%rip), %r12
	leaq	.LC3(%rip), %r13
	movq	%r12, %rcx
	movq	%r13, %rdi
	movq	-88(%rbp), %rdx
	movq	-80(%rbp), %rsi
	movq	-72(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -64(%rbp)
	.loc 1 1097 7
	movb	$0, -49(%rbp)
	.loc 1 1099 10
	movq	-64(%rbp), %rdx
	movq	-80(%rbp), %rcx
	movq	-72(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__main_spelling
	.loc 1 1099 7 discriminator 1
	testb	%al, %al
	je	.L435
	.loc 1 1099 49 discriminator 2
	movb	$17, -49(%rbp)
	jmp	.L436
.L435:
	.loc 1 1100 13
	leaq	silver_library_reports__atom_silver_io(%rip), %r14
	leaq	.LC4(%rip), %r15
	movq	%r14, %rcx
	movq	%r15, %rdi
	movq	-64(%rbp), %rdx
	movq	-80(%rbp), %rsi
	movq	-72(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1100 7 discriminator 1
	testb	%al, %al
	je	.L437
	.loc 1 1100 67 discriminator 2
	movb	$1, -49(%rbp)
	jmp	.L436
.L437:
	.loc 1 1101 13
	leaq	silver_library_reports__atom_silver_io_put_line(%rip), %rax
	movq	%rax, -336(%rbp)
	leaq	.LC5(%rip), %rax
	movq	%rax, -328(%rbp)
	movq	-336(%rbp), %rax
	movq	-328(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-64(%rbp), %rdx
	movq	-80(%rbp), %rsi
	movq	-72(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1101 7 discriminator 1
	testb	%al, %al
	je	.L438
	.loc 1 1101 76 discriminator 2
	movb	$2, -49(%rbp)
	jmp	.L436
.L438:
	.loc 1 1102 13
	leaq	silver_library_reports__atom_silver_io_put(%rip), %rax
	movq	%rax, -320(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -312(%rbp)
	movq	-320(%rbp), %rax
	movq	-312(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-64(%rbp), %rdx
	movq	-80(%rbp), %rsi
	movq	-72(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1102 7 discriminator 1
	testb	%al, %al
	je	.L439
	.loc 1 1102 71 discriminator 2
	movb	$3, -49(%rbp)
	jmp	.L436
.L439:
	.loc 1 1103 13
	leaq	silver_library_reports__atom_silver_output_libc(%rip), %rax
	movq	%rax, -304(%rbp)
	leaq	.LC5(%rip), %rax
	movq	%rax, -296(%rbp)
	movq	-304(%rbp), %rax
	movq	-296(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-64(%rbp), %rdx
	movq	-80(%rbp), %rsi
	movq	-72(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1103 7 discriminator 1
	testb	%al, %al
	je	.L440
	.loc 1 1103 76 discriminator 2
	movb	$4, -49(%rbp)
	jmp	.L436
.L440:
	.loc 1 1104 13
	leaq	silver_library_reports__atom_silver_output_libc_put_byte(%rip), %rax
	movq	%rax, -288(%rbp)
	leaq	.LC7(%rip), %rax
	movq	%rax, -280(%rbp)
	movq	-288(%rbp), %rax
	movq	-280(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-64(%rbp), %rdx
	movq	-80(%rbp), %rsi
	movq	-72(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1104 7 discriminator 1
	testb	%al, %al
	je	.L441
	.loc 1 1104 85 discriminator 2
	movb	$5, -49(%rbp)
	jmp	.L436
.L441:
	.loc 1 1105 13
	leaq	silver_library_reports__atom_silver_output_libc_flush(%rip), %rax
	movq	%rax, -272(%rbp)
	leaq	.LC8(%rip), %rax
	movq	%rax, -264(%rbp)
	movq	-272(%rbp), %rax
	movq	-264(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-64(%rbp), %rdx
	movq	-80(%rbp), %rsi
	movq	-72(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1105 7 discriminator 1
	testb	%al, %al
	je	.L442
	.loc 1 1105 82 discriminator 2
	movb	$6, -49(%rbp)
	jmp	.L436
.L442:
	.loc 1 1106 13
	leaq	silver_library_reports__atom_silver_output_libc_set_exit_status(%rip), %rax
	movq	%rax, -256(%rbp)
	leaq	.LC9(%rip), %rax
	movq	%rax, -248(%rbp)
	movq	-256(%rbp), %rax
	movq	-248(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-64(%rbp), %rdx
	movq	-80(%rbp), %rsi
	movq	-72(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1106 7 discriminator 1
	testb	%al, %al
	je	.L443
	.loc 1 1106 92 discriminator 2
	movb	$7, -49(%rbp)
	jmp	.L436
.L443:
	.loc 1 1107 13
	leaq	silver_library_reports__atom_silver_arguments(%rip), %rax
	movq	%rax, -240(%rbp)
	leaq	.LC10(%rip), %rax
	movq	%rax, -232(%rbp)
	movq	-240(%rbp), %rax
	movq	-232(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-64(%rbp), %rdx
	movq	-80(%rbp), %rsi
	movq	-72(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1107 7 discriminator 1
	testb	%al, %al
	je	.L444
	.loc 1 1107 74 discriminator 2
	movb	$8, -49(%rbp)
	jmp	.L436
.L444:
	.loc 1 1108 13
	leaq	silver_library_reports__atom_silver_arguments_input_is_valid(%rip), %rax
	movq	%rax, -224(%rbp)
	leaq	.LC11(%rip), %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rax
	movq	-216(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-64(%rbp), %rdx
	movq	-80(%rbp), %rsi
	movq	-72(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1108 7 discriminator 1
	testb	%al, %al
	je	.L445
	.loc 1 1108 89 discriminator 2
	movb	$9, -49(%rbp)
	jmp	.L436
.L445:
	.loc 1 1109 13
	leaq	silver_library_reports__atom_silver_arguments_first_or_default(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC12(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rax
	movq	%rsi, %r8
	movq	-64(%rbp), %rdx
	movq	-80(%rbp), %rdi
	movq	-72(%rbp), %rsi
	movq	%rax, %rcx
	call	silver_library_reports__string_equal
	.loc 1 1109 7 discriminator 1
	testb	%al, %al
	je	.L446
	.loc 1 1109 91 discriminator 2
	movb	$10, -49(%rbp)
	jmp	.L436
.L446:
	.loc 1 1110 13
	leaq	silver_library_reports__atom_silver_arguments_reject(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC13(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rax
	movq	%rsi, %rdi
	movq	-64(%rbp), %rdx
	movq	-80(%rbp), %rsi
	movq	-72(%rbp), %r9
	movq	%rax, %rcx
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%r9, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1110 7 discriminator 1
	testb	%al, %al
	je	.L447
	.loc 1 1110 81 discriminator 2
	movb	$11, -49(%rbp)
	jmp	.L436
.L447:
	.loc 1 1111 13
	leaq	silver_library_reports__atom_silver_arguments_is_message(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC7(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rax
	movq	-168(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-64(%rbp), %rdx
	movq	-80(%rbp), %rsi
	movq	-72(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1111 7 discriminator 1
	testb	%al, %al
	je	.L448
	.loc 1 1111 85 discriminator 2
	movb	$12, -49(%rbp)
	jmp	.L436
.L448:
	.loc 1 1112 13
	leaq	silver_library_reports__atom_silver_runtime(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC14(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rax
	movq	-152(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-64(%rbp), %rdx
	movq	-80(%rbp), %rsi
	movq	-72(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1112 7 discriminator 1
	testb	%al, %al
	je	.L449
	.loc 1 1112 72 discriminator 2
	movb	$13, -49(%rbp)
	jmp	.L436
.L449:
	.loc 1 1113 13
	leaq	silver_library_reports__atom_silver_runtime_argument_count(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC15(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rax
	movq	-136(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-64(%rbp), %rdx
	movq	-80(%rbp), %rsi
	movq	-72(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1113 7 discriminator 1
	testb	%al, %al
	je	.L450
	.loc 1 1113 87 discriminator 2
	movb	$14, -49(%rbp)
	jmp	.L436
.L450:
	.loc 1 1114 13
	leaq	silver_library_reports__atom_silver_runtime_argument(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC13(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rax
	movq	-120(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-64(%rbp), %rdx
	movq	-80(%rbp), %rsi
	movq	-72(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1114 7 discriminator 1
	testb	%al, %al
	je	.L451
	.loc 1 1114 81 discriminator 2
	movb	$15, -49(%rbp)
	jmp	.L436
.L451:
	.loc 1 1115 13
	leaq	silver_library_reports__atom_silver_runtime_set_exit_status(%rip), %rax
	movq	%rax, -112(%rbp)
	leaq	.LC16(%rip), %rax
	movq	%rax, -104(%rbp)
	movq	-112(%rbp), %rax
	movq	-104(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-64(%rbp), %rdx
	movq	-80(%rbp), %rsi
	movq	-72(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1115 7 discriminator 1
	testb	%al, %al
	je	.L436
	.loc 1 1115 88 discriminator 2
	movb	$16, -49(%rbp)
.L436:
	.loc 1 1117 14
	movzbl	-49(%rbp), %ecx
	movq	-88(%rbp), %rdx
	movq	-80(%rbp), %rsi
	movq	-72(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__location_ok
	.loc 1 1117 14 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 1 1117 7 is_stmt 1 discriminator 1
	testb	%al, %al
	je	.L452
	.loc 1 1117 54 discriminator 2
	movl	$0, %eax
	jmp	.L454
.L452:
	.loc 1 1118 7
	movzbl	-49(%rbp), %eax
.L454:
.LBE61:
	.loc 1 1119 8
	addq	$296, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE21:
	.size	silver_library_reports__entity_name, .-silver_library_reports__entity_name
	.section	.rodata
	.align 8
.LC62:
	.ascii	"failed precondition from silver_library_reports.adb:1122"
	.text
	.align 2
	.globl	silver_library_reports__positive_number
	.type	silver_library_reports__positive_number, @function
silver_library_reports__positive_number:
.LFB22:
	.loc 1 1124 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, %rax
	movq	%rsi, %r10
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r10, %rdi
	movq	%rsi, -80(%rbp)
	movq	%rdi, -72(%rbp)
	movq	%rdx, -88(%rbp)
	.loc 1 1124 4
	movq	-72(%rbp), %rax
	movl	(%rax), %r12d
	movq	-72(%rbp), %rax
	movl	4(%rax), %r13d
.LBB64:
	.loc 1 1122 18
	cmpl	$1, %r12d
	je	.L456
.LBB65:
	.loc 1 1122 18 is_stmt 0 discriminator 1
	leaq	.LC62(%rip), %r8
	leaq	.LC2(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L456:
.LBE65:
	.loc 1 1122 54 is_stmt 1 discriminator 2
	movslq	%r12d, %rax
	leaq	16777215(%rax), %rdx
	movslq	%r13d, %rax
	.loc 1 1122 18 discriminator 2
	cmpq	%rax, %rdx
	jge	.L457
.LBB66:
	.loc 1 1122 18 is_stmt 0 discriminator 3
	leaq	.LC62(%rip), %rcx
	leaq	.LC2(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L457:
.LBE66:
	.loc 1 1125 7 is_stmt 1
	movq	-88(%rbp), %rdx
	movq	-80(%rbp), %rcx
	movq	-72(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__valid
	.loc 1 1127 7
	testb	%al, %al
	je	.L458
	.loc 1 1126 17
	movl	$1, %esi
	.loc 1 1126 34
	movl	-88(%rbp), %eax
	movl	%eax, -44(%rbp)
	movl	-44(%rbp), %eax
	cmpl	$16777217, %eax
	jbe	.L459
	.loc 1 1126 34 is_stmt 0 discriminator 1
	leaq	.LC39(%rip), %rax
	movl	$1126, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L459:
	.loc 1 1126 48 is_stmt 1 discriminator 2
	movl	-84(%rbp), %eax
	movl	%eax, -48(%rbp)
	movl	-48(%rbp), %eax
	cmpl	$16777217, %eax
	jbe	.L460
	.loc 1 1126 48 is_stmt 0 discriminator 3
	leaq	.LC39(%rip), %rax
	movl	$1126, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L460:
.LBB67:
	.loc 1 1126 25 is_stmt 1 discriminator 4
	movl	-44(%rbp), %eax
	movl	%eax, -36(%rbp)
.L466:
	.loc 1 1126 17 discriminator 5
	movl	-36(%rbp), %eax
	cmpl	-48(%rbp), %eax
	jg	.L461
	.loc 1 1126 57 discriminator 6
	cmpl	-36(%rbp), %r12d
	jg	.L462
	.loc 1 1126 57 is_stmt 0 discriminator 7
	cmpl	-36(%rbp), %r13d
	jge	.L463
.L462:
	.loc 1 1126 57 discriminator 8
	leaq	.LC39(%rip), %rax
	movl	$1126, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L463:
	.loc 1 1126 66 is_stmt 1 discriminator 9
	movq	-80(%rbp), %rax
	movq	-72(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-36(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 1 1126 17 discriminator 9
	cmpb	$47, %al
	jbe	.L464
	.loc 1 1126 66 discriminator 10
	movq	-80(%rbp), %rax
	movq	-72(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-36(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$57, %al
	jbe	.L465
.L464:
	.loc 1 1126 17 discriminator 11
	movl	$0, %esi
	jmp	.L461
.L465:
	.loc 1 1126 17 is_stmt 0 discriminator 12
	addl	$1, -36(%rbp)
	jmp	.L466
.L461:
.LBE67:
	.loc 1 1126 7 is_stmt 1 discriminator 13
	testb	%sil, %sil
	je	.L458
	.loc 1 1127 17 discriminator 1
	movl	$0, %esi
	.loc 1 1127 35 discriminator 1
	movl	-88(%rbp), %eax
	movl	%eax, -52(%rbp)
	movl	-52(%rbp), %eax
	cmpl	$16777217, %eax
	jbe	.L467
	.loc 1 1127 35 is_stmt 0 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1127, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L467:
	.loc 1 1127 49 is_stmt 1 discriminator 3
	movl	-84(%rbp), %eax
	movl	%eax, -56(%rbp)
	movl	-56(%rbp), %eax
	cmpl	$16777217, %eax
	jbe	.L468
	.loc 1 1127 49 is_stmt 0 discriminator 4
	leaq	.LC39(%rip), %rax
	movl	$1127, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L468:
.LBB68:
	.loc 1 1127 26 is_stmt 1 discriminator 5
	movl	-52(%rbp), %eax
	movl	%eax, -40(%rbp)
.L473:
	.loc 1 1127 17 discriminator 6
	movl	-40(%rbp), %eax
	cmpl	-56(%rbp), %eax
	jg	.L469
	.loc 1 1127 58 discriminator 7
	cmpl	-40(%rbp), %r12d
	jg	.L470
	.loc 1 1127 58 is_stmt 0 discriminator 8
	cmpl	-40(%rbp), %r13d
	jge	.L471
.L470:
	.loc 1 1127 58 discriminator 9
	leaq	.LC39(%rip), %rax
	movl	$1127, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L471:
	.loc 1 1127 67 is_stmt 1 discriminator 10
	movq	-80(%rbp), %rax
	movq	-72(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-40(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 1 1127 17 discriminator 10
	cmpb	$48, %al
	je	.L472
	.loc 1 1127 17 is_stmt 0 discriminator 11
	movl	$1, %esi
	jmp	.L469
.L472:
	.loc 1 1127 17 discriminator 12
	addl	$1, -40(%rbp)
	jmp	.L473
.L469:
.LBE68:
	.loc 1 1127 7 is_stmt 1 discriminator 13
	testb	%sil, %sil
	je	.L458
	.loc 1 1127 7 is_stmt 0 discriminator 14
	movl	$1, %eax
	jmp	.L474
.L458:
	.loc 1 1127 7 discriminator 15
	movl	$0, %eax
.L474:
.LBE64:
	.loc 1 1124 4 is_stmt 1
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE22:
	.size	silver_library_reports__positive_number, .-silver_library_reports__positive_number
	.section	.rodata
	.align 8
.LC63:
	.ascii	"failed precondition from silver_library_reports.adb:1130"
	.text
	.align 2
	.globl	silver_library_reports__nonempty_string
	.type	silver_library_reports__nonempty_string, @function
silver_library_reports__nonempty_string:
.LFB23:
	.loc 1 1132 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, %rax
	movq	%rsi, %r10
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r10, %rdi
	movq	%rsi, -48(%rbp)
	movq	%rdi, -40(%rbp)
	movq	%rdx, -56(%rbp)
	.loc 1 1132 4
	movq	-40(%rbp), %rax
	movl	(%rax), %r12d
	movq	-40(%rbp), %rax
	movl	4(%rax), %r13d
.LBB69:
	.loc 1 1130 18
	cmpl	$1, %r12d
	je	.L477
.LBB70:
	.loc 1 1130 18 is_stmt 0 discriminator 1
	leaq	.LC63(%rip), %r8
	leaq	.LC2(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L477:
.LBE70:
	.loc 1 1130 54 is_stmt 1 discriminator 2
	movslq	%r12d, %rax
	leaq	16777215(%rax), %rdx
	movslq	%r13d, %rax
	.loc 1 1130 18 discriminator 2
	cmpq	%rax, %rdx
	jge	.L478
.LBB71:
	.loc 1 1130 18 is_stmt 0 discriminator 3
	leaq	.LC63(%rip), %rcx
	leaq	.LC2(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L478:
.LBE71:
	.loc 1 1133 7 is_stmt 1
	movq	-56(%rbp), %rdx
	movq	-48(%rbp), %rcx
	movq	-40(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__valid
	.loc 1 1134 40
	testb	%al, %al
	je	.L479
	.loc 1 1133 45 discriminator 2
	movl	-52(%rbp), %edx
	movl	-56(%rbp), %eax
	subl	%eax, %edx
	.loc 1 1133 26 discriminator 2
	cmpl	$1, %edx
	jle	.L479
	.loc 1 1134 16 discriminator 1
	movl	-56(%rbp), %eax
	cmpl	%eax, %r12d
	jg	.L480
	.loc 1 1134 16 is_stmt 0 discriminator 2
	movl	-56(%rbp), %eax
	cmpl	%eax, %r13d
	jge	.L481
.L480:
	.loc 1 1134 16 discriminator 3
	leaq	.LC39(%rip), %rax
	movl	$1134, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L481:
	.loc 1 1134 34 is_stmt 1 discriminator 4
	movq	-48(%rbp), %rax
	movq	-40(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-56(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$34, %al
	sete	%al
	.loc 1 1134 7 discriminator 4
	testb	%al, %al
	je	.L479
	.loc 1 1134 49 discriminator 5
	movl	-52(%rbp), %eax
	cmpl	%eax, %r12d
	jg	.L482
	.loc 1 1134 49 is_stmt 0 discriminator 6
	movl	-52(%rbp), %eax
	cmpl	%eax, %r13d
	jge	.L483
.L482:
	.loc 1 1134 49 discriminator 7
	leaq	.LC39(%rip), %rax
	movl	$1134, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L483:
	.loc 1 1134 66 is_stmt 1 discriminator 8
	movq	-48(%rbp), %rax
	movq	-40(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-52(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$34, %al
	sete	%al
	.loc 1 1134 40 discriminator 8
	testb	%al, %al
	je	.L479
	.loc 1 1134 40 is_stmt 0 discriminator 9
	movl	$1, %eax
	jmp	.L484
.L479:
	.loc 1 1134 40 discriminator 10
	movl	$0, %eax
.L484:
.LBE69:
	.loc 1 1132 4 is_stmt 1
	addq	$40, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE23:
	.size	silver_library_reports__nonempty_string, .-silver_library_reports__nonempty_string
	.section	.rodata
	.align 8
.LC64:
	.ascii	"failed precondition from silver_library_reports.adb:1138"
	.align 8
.LC65:
	.ascii	"failed precondition from silver_library_reports.adb:1139"
.LC66:
	.ascii	" "
	.align 8
.LC17:
	.long	1
	.long	1
	.text
	.align 2
	.globl	silver_library_reports__padded_key
	.type	silver_library_reports__padded_key, @function
silver_library_reports__padded_key:
.LFB24:
	.loc 1 1136 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$152, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -112(%rbp)
	movq	%rbx, -104(%rbp)
	movq	%rdx, -120(%rbp)
	.loc 1 1136 4
	movq	-104(%rbp), %rax
	movl	(%rax), %ebx
	movq	-104(%rbp), %rax
	movl	4(%rax), %r12d
.LBB72:
	movq	%rsp, %rax
	movq	%rax, -128(%rbp)
	.loc 1 1136 4 is_stmt 0 discriminator 1
	movslq	%ebx, %r13
	cmpl	%ebx, %r12d
	.loc 1 1136 4 discriminator 4
	cmpl	%ebx, %r12d
	.loc 1 1136 4 discriminator 7
	cmpl	%ebx, %r12d
	.loc 1 1138 15 is_stmt 1
	cmpl	$1, %ebx
	je	.L493
.LBB73:
	.loc 1 1138 15 is_stmt 0 discriminator 1
	leaq	.LC64(%rip), %r8
	leaq	.LC2(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L493:
.LBE73:
	.loc 1 1138 51 is_stmt 1 discriminator 2
	movslq	%ebx, %rax
	leaq	16777215(%rax), %rdx
	movslq	%r12d, %rax
	.loc 1 1138 15 discriminator 2
	cmpq	%rax, %rdx
	jge	.L494
.LBB74:
	.loc 1 1138 15 is_stmt 0 discriminator 3
	leaq	.LC64(%rip), %r10
	leaq	.LC2(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L494:
.LBE74:
	.loc 1 1139 19 is_stmt 1
	movq	-120(%rbp), %rdx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__valid
	.loc 1 1139 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 1 1138 15 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L495
.LBB75:
	.loc 1 1138 15 is_stmt 0 discriminator 5
	leaq	.LC65(%rip), %r14
	leaq	.LC2(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L495:
.LBE75:
	.loc 1 1147 36 is_stmt 1
	movl	-116(%rbp), %edx
	movl	-120(%rbp), %eax
	cmpl	%eax, %edx
	jl	.L496
	.loc 1 1147 36 is_stmt 0 discriminator 1
	movl	-120(%rbp), %eax
	cmpl	%eax, %ebx
	jg	.L497
	.loc 1 1147 36 discriminator 2
	movl	-116(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L496
.L497:
	.loc 1 1147 36 discriminator 3
	leaq	.LC39(%rip), %rax
	movl	$1147, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L496:
	.loc 1 1147 20 is_stmt 1 discriminator 4
	movl	-116(%rbp), %edx
	movl	-120(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 1147 20 is_stmt 0 discriminator 7
	movl	-116(%rbp), %edx
	movl	-120(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 1147 20 discriminator 10
	movl	-116(%rbp), %edx
	movl	-120(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 1147 20 discriminator 13
	movl	-116(%rbp), %edx
	movl	-120(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 1147 20 discriminator 16
	movl	-116(%rbp), %edx
	movl	-120(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 1147 20 discriminator 19
	movl	-116(%rbp), %edx
	movl	-120(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 1147 18 is_stmt 1 discriminator 22
	movl	-116(%rbp), %edx
	movl	-120(%rbp), %eax
	cmpl	%eax, %edx
	jl	.L510
	.loc 1 1147 18 is_stmt 0 discriminator 23
	movl	-116(%rbp), %edx
	movl	-120(%rbp), %eax
	subl	%eax, %edx
	leal	1(%rdx), %eax
	jmp	.L511
.L510:
	.loc 1 1147 18 discriminator 24
	movl	$0, %eax
.L511:
	.loc 1 1147 18 discriminator 25
	addl	$1, %eax
	movl	%eax, -52(%rbp)
	movl	-52(%rbp), %eax
	cltq
	movq	%rax, -64(%rbp)
	movl	-52(%rbp), %eax
	movslq	%eax, %r12
	movl	-52(%rbp), %eax
	cltq
	movl	$16, %edx
	subq	$1, %rdx
	addq	%rdx, %rax
	movl	$16, %ecx
	movl	$0, %edx
	divq	%rcx
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	movq	%rax, -72(%rbp)
.LBB76:
	.loc 1 1147 18 discriminator 26
	movq	-112(%rbp), %rax
	movl	-120(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	addq	%rdx, %rax
	movq	%rax, -192(%rbp)
	movl	-120(%rbp), %eax
	movl	%eax, -88(%rbp)
	movl	-116(%rbp), %eax
	movl	%eax, -84(%rbp)
	leaq	-88(%rbp), %rax
	movq	%rax, -184(%rbp)
	leaq	.LC66(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC17(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-72(%rbp), %rax
	movq	%rax, -160(%rbp)
	movl	$1, -80(%rbp)
	movl	-52(%rbp), %eax
	movl	%eax, -76(%rbp)
	leaq	-80(%rbp), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rax
	movq	-152(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rax
	movq	-192(%rbp), %r8
	movq	-184(%rbp), %r9
	movq	-176(%rbp), %rdx
	movq	-168(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	system__concat_2__str_concat_2@PLT
.LBE76:
	.loc 1 1147 7 is_stmt 1 discriminator 27
	movl	-52(%rbp), %eax
	cltq
	addq	$11, %rax
	andq	$-4, %rax
	movl	$4, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rbx
	.loc 1 1147 7 is_stmt 0 discriminator 28
	movq	%rbx, %rax
	movl	$1, (%rax)
	movl	-52(%rbp), %edx
	movl	%edx, 4(%rax)
	leaq	8(%rax), %rdx
	movq	-72(%rbp), %rax
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 1 1147 7 discriminator 29
	movq	%rbx, %rax
	addq	$8, %rax
	movq	%rax, -144(%rbp)
	movq	%rbx, %rax
	movq	%rax, -136(%rbp)
	.loc 1 1148 8 is_stmt 1
	movq	-128(%rbp), %rsp
	.loc 1 1147 7 discriminator 30
	movq	-144(%rbp), %rax
	movq	-136(%rbp), %rdx
.LBE72:
	.loc 1 1148 8
	leaq	-40(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE24:
	.size	silver_library_reports__padded_key, .-silver_library_reports__padded_key
	.align 2
	.type	silver_library_reports__referenced_entity__B_6___finalizer.1, @function
silver_library_reports__referenced_entity__B_6___finalizer.1:
.LFB26:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE26:
	.size	silver_library_reports__referenced_entity__B_6___finalizer.1, .-silver_library_reports__referenced_entity__B_6___finalizer.1
	.section	.rodata
	.align 8
.LC67:
	.ascii	"failed precondition from silver_library_reports.adb:1164"
	.text
	.align 2
	.type	silver_library_reports__referenced_entity, @function
silver_library_reports__referenced_entity:
.LFB25:
	.loc 1 1163 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA25
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB4:
	subq	$184, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %rbx
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%rbx, %rdi
	movq	%rsi, -176(%rbp)
	movq	%rdi, -168(%rbp)
	movq	%rdx, -184(%rbp)
	movq	%rcx, -192(%rbp)
	.loc 1 1163 4
	leaq	16(%rbp), %rax
	.loc 1 1163 4 is_stmt 0 discriminator 1
	movq	%rax, -120(%rbp)
	movq	-168(%rbp), %rax
	movl	(%rax), %ebx
	movq	-168(%rbp), %rax
	movl	4(%rax), %r12d
.LBB77:
	movslq	%ebx, %r13
	cmpl	%ebx, %r12d
	.loc 1 1163 4 discriminator 4
	cmpl	%ebx, %r12d
	.loc 1 1163 4 discriminator 7
	cmpl	%ebx, %r12d
	.loc 1 1164 18 is_stmt 1
	cmpl	$1, %ebx
	je	.L522
.LBB78:
	.loc 1 1164 18 is_stmt 0 discriminator 1
	leaq	.LC67(%rip), %r10
	leaq	.LC2(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L522:
.LBE78:
	.loc 1 1164 54 is_stmt 1 discriminator 2
	movslq	%ebx, %rax
	leaq	16777215(%rax), %rdx
	movslq	%r12d, %rax
	.loc 1 1164 18 discriminator 2
	cmpq	%rax, %rdx
	jge	.L523
.LBB79:
	.loc 1 1164 18 is_stmt 0 discriminator 3
	leaq	.LC67(%rip), %r8
	leaq	.LC2(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L523:
.LBE79:
	.loc 1 1168 14 is_stmt 1
	movq	-192(%rbp), %rdx
	movq	-176(%rbp), %rcx
	movq	-168(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__valid
	.loc 1 1168 14 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 1 1168 7 is_stmt 1 discriminator 1
	testb	%al, %al
	je	.L524
	.loc 1 1168 37 discriminator 2
	movl	$0, %eax
	movq	%rax, -200(%rbp)
	jmp	.L525
.L524:
	.loc 1 1169 15
	movl	$1, %ecx
	.loc 1 1169 31
	movl	-192(%rbp), %eax
	movl	%eax, -56(%rbp)
	movl	-56(%rbp), %eax
	cmpl	$16777217, %eax
	jbe	.L526
	.loc 1 1169 31 is_stmt 0 discriminator 1
	leaq	.LC39(%rip), %rax
	movl	$1169, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L526:
	.loc 1 1169 44 is_stmt 1 discriminator 2
	movl	-188(%rbp), %eax
	movl	%eax, -60(%rbp)
	movl	-60(%rbp), %eax
	cmpl	$16777217, %eax
	jbe	.L527
	.loc 1 1169 44 is_stmt 0 discriminator 3
	leaq	.LC39(%rip), %rax
	movl	$1169, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L527:
.LBB80:
	.loc 1 1169 23 is_stmt 1 discriminator 4
	movl	-56(%rbp), %eax
	movl	%eax, -52(%rbp)
.L533:
	.loc 1 1169 15 discriminator 5
	movl	-52(%rbp), %eax
	cmpl	-60(%rbp), %eax
	jg	.L528
	.loc 1 1169 53 discriminator 6
	cmpl	-52(%rbp), %ebx
	jg	.L529
	.loc 1 1169 53 is_stmt 0 discriminator 7
	cmpl	-52(%rbp), %r12d
	jge	.L530
.L529:
	.loc 1 1169 53 discriminator 8
	leaq	.LC39(%rip), %rax
	movl	$1169, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L530:
	.loc 1 1169 62 is_stmt 1 discriminator 9
	movq	-176(%rbp), %rax
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 1169 15 discriminator 9
	cmpb	$47, %al
	jbe	.L531
	.loc 1 1169 62 discriminator 10
	movq	-176(%rbp), %rax
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
.LEHE4:
	cmpb	$57, %al
	jbe	.L532
.L531:
	.loc 1 1169 15 discriminator 11
	movl	$0, %ecx
	jmp	.L528
.L532:
	.loc 1 1169 15 is_stmt 0 discriminator 12
	addl	$1, -52(%rbp)
	jmp	.L533
.L528:
.LBE80:
	.loc 1 1169 15 discriminator 13
	movl	%ecx, %eax
	xorl	$1, %eax
	.loc 1 1169 7 is_stmt 1 discriminator 13
	testb	%al, %al
	je	.L534
	.loc 1 1170 12
	movl	$0, %eax
	movq	%rax, -200(%rbp)
	jmp	.L525
.L534:
.LBB81:
	.loc 1 1171 7
	movq	%rsp, %rax
	movq	%rax, -216(%rbp)
	leaq	-144(%rbp), %rax
	movq	%rax, %rdi
.LEHB5:
	call	system__secondary_stack__ss_mark@PLT
	.loc 1 1172 54
	movl	-188(%rbp), %edx
	movl	-192(%rbp), %eax
	cmpl	%eax, %edx
	jl	.L535
	.loc 1 1172 54 is_stmt 0 discriminator 1
	movl	-192(%rbp), %eax
	cmpl	%eax, %ebx
	jg	.L536
	.loc 1 1172 54 discriminator 2
	movl	-188(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L535
.L536:
	.loc 1 1172 54 discriminator 3
	leaq	.LC39(%rip), %rax
	movl	$1172, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L535:
	.loc 1 1172 38 is_stmt 1 discriminator 4
	movl	-192(%rbp), %eax
	movl	%eax, -64(%rbp)
	movl	-188(%rbp), %eax
	movl	%eax, -68(%rbp)
	movl	-68(%rbp), %eax
	cmpl	-64(%rbp), %eax
	.loc 1 1172 38 is_stmt 0 discriminator 7
	movl	-68(%rbp), %eax
	cmpl	-64(%rbp), %eax
	.loc 1 1172 38 discriminator 10
	movl	-68(%rbp), %eax
	cmpl	-64(%rbp), %eax
	.loc 1 1172 54 is_stmt 1 discriminator 13
	movl	-188(%rbp), %edx
	movl	-192(%rbp), %eax
	cmpl	%eax, %edx
	jl	.L543
	.loc 1 1172 54 is_stmt 0 discriminator 14
	movl	-192(%rbp), %eax
	testl	%eax, %eax
	jg	.L543
	.loc 1 1172 54 discriminator 15
	leaq	.LC39(%rip), %rax
	movl	$1172, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.LEHE5:
.L543:
	.loc 1 1172 10 is_stmt 1 discriminator 16
	movl	-64(%rbp), %eax
	cltq
	movq	%rax, -80(%rbp)
	movl	-68(%rbp), %eax
	cmpl	-64(%rbp), %eax
	jl	.L544
	.loc 1 1172 10 is_stmt 0 discriminator 17
	movl	-68(%rbp), %eax
	cltq
	movq	%rax, -88(%rbp)
	jmp	.L545
.L544:
	.loc 1 1172 10 discriminator 18
	movl	-64(%rbp), %eax
	cltq
	subq	$1, %rax
	movq	%rax, -88(%rbp)
.L545:
	.loc 1 1172 10 discriminator 19
	movl	-68(%rbp), %eax
	cmpl	-64(%rbp), %eax
	.loc 1 1172 10 discriminator 22
	movl	-68(%rbp), %eax
	cmpl	-64(%rbp), %eax
	jl	.L548
	.loc 1 1172 10 discriminator 23
	movl	-68(%rbp), %eax
	movslq	%eax, %rdx
	movl	-64(%rbp), %eax
	cltq
	subq	%rax, %rdx
	leaq	1(%rdx), %rcx
	jmp	.L549
.L548:
	.loc 1 1172 10 discriminator 24
	movl	$0, %ecx
.L549:
	.loc 1 1172 10 discriminator 25
	movl	-68(%rbp), %eax
	cmpl	-64(%rbp), %eax
	.loc 1 1172 10 discriminator 28
	movl	-68(%rbp), %eax
	cmpl	-64(%rbp), %eax
	jl	.L552
	.loc 1 1172 10 discriminator 29
	movl	-68(%rbp), %eax
	movslq	%eax, %rdx
	movl	-64(%rbp), %eax
	cltq
	subq	%rax, %rdx
	leaq	1(%rdx), %rax
	jmp	.L553
.L552:
	.loc 1 1172 10 discriminator 30
	movl	$0, %eax
.L553:
	.loc 1 1172 10 discriminator 31
	movl	$16, %edx
	subq	$1, %rdx
	addq	%rdx, %rax
	movl	$16, %ebx
	movl	$0, %edx
.LEHB6:
	divq	%rbx
.LEHE6:
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	movq	%rax, -96(%rbp)
	.loc 1 1172 10 discriminator 32
	movq	-176(%rbp), %rax
	movl	-64(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	addq	%rax, %rdx
	movq	-96(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rcx, %rdx
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 1 1173 59 is_stmt 1
	movq	-192(%rbp), %rdx
	movq	-176(%rbp), %rcx
	movq	-168(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
.LEHB7:
	call	silver_library_reports__padded_key
	.loc 1 1173 36 discriminator 1
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-184(%rbp), %rdx
	movq	-176(%rbp), %rsi
	movq	-168(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -152(%rbp)
	.loc 1 1175 20
	movl	-152(%rbp), %eax
	.loc 1 1175 10
	testl	%eax, %eax
	jne	.L554
	.loc 1 1175 20 discriminator 1
	movl	-148(%rbp), %eax
	testl	%eax, %eax
	je	.L555
.L554:
	.loc 1 1175 36 discriminator 2
	movq	-152(%rbp), %rax
	movq	%rax, -200(%rbp)
	movl	$0, %ebx
	jmp	.L556
.L555:
	.loc 1 1176 17
	movq	-96(%rbp), %r14
	movl	-64(%rbp), %eax
	movl	%eax, -104(%rbp)
	movl	-68(%rbp), %eax
	movl	%eax, -100(%rbp)
	leaq	-104(%rbp), %rax
	movq	%rax, %r15
	movq	%r14, %rcx
	movq	%r15, %rdi
	movq	-184(%rbp), %rdx
	movq	-176(%rbp), %rsi
	movq	-168(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
.LEHE7:
	movq	%rax, -200(%rbp)
	.loc 1 1176 10 discriminator 1
	movl	$0, %ebx
.L556:
	.loc 1 1177 0
	leaq	-144(%rbp), %rax
	movq	%rax, %r10
.LEHB8:
	call	silver_library_reports__referenced_entity__B_6___finalizer.1
.LEHE8:
	.loc 1 1177 0 is_stmt 0 discriminator 1
	cmpl	$1, %ebx
	je	.L557
	movl	$0, %eax
.L561:
.LEHB9:
	.loc 1 1177 10 is_stmt 1 discriminator 2
	movq	-216(%rbp), %rsp
	.loc 1 1177 10 is_stmt 0 discriminator 3
	cmpl	$1, %eax
	je	.L558
.L525:
.LBE81:
.LBE77:
	.loc 1 1178 8 is_stmt 1
	movq	-200(%rbp), %rax
	jmp	.L564
.L562:
	movq	%rax, -224(%rbp)
	movl	$1, %ebx
.LBB83:
.LBB82:
	.loc 1 1171 7 discriminator 1
	jmp	.L556
.L557:
	movq	-224(%rbp), %rax
	movq	%rax, -208(%rbp)
	jmp	.L560
.L563:
	movq	%rax, -208(%rbp)
.L560:
	movl	$1, %eax
	jmp	.L561
.L558:
	movq	-208(%rbp), %rax
	movq	%rax, %rdi
	call	_Unwind_Resume@PLT
.L564:
.LBE82:
.LBE83:
	.loc 1 1178 8
	leaq	-40(%rbp), %rsp
.LEHE9:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE25:
	.section	.gcc_except_table
.LLSDA25:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE25-.LLSDACSB25
.LLSDACSB25:
	.uleb128 .LEHB4-.LFB25
	.uleb128 .LEHE4-.LEHB4
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB5-.LFB25
	.uleb128 .LEHE5-.LEHB5
	.uleb128 .L562-.LFB25
	.uleb128 0
	.uleb128 .LEHB6-.LFB25
	.uleb128 .LEHE6-.LEHB6
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB7-.LFB25
	.uleb128 .LEHE7-.LEHB7
	.uleb128 .L562-.LFB25
	.uleb128 0
	.uleb128 .LEHB8-.LFB25
	.uleb128 .LEHE8-.LEHB8
	.uleb128 .L563-.LFB25
	.uleb128 0
	.uleb128 .LEHB9-.LFB25
	.uleb128 .LEHE9-.LEHB9
	.uleb128 0
	.uleb128 0
.LLSDACSE25:
	.text
	.size	silver_library_reports__referenced_entity, .-silver_library_reports__referenced_entity
	.section	.rodata
	.align 8
.LC68:
	.ascii	"failed precondition from silver_library_reports.adb:1192"
	.align 8
.LC18:
	.long	1
	.long	3
	.align 8
.LC19:
	.long	1
	.long	10
	.align 8
.LC20:
	.long	1
	.long	11
	.text
	.align 2
	.type	silver_library_reports__reference_ok, @function
silver_library_reports__reference_ok:
.LFB27:
	.loc 1 1191 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	subq	$112, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -64(%rbp)
	movq	%rdi, -56(%rbp)
	movq	%rdx, -72(%rbp)
	movq	%rcx, -80(%rbp)
	.loc 1 1191 4
	movq	-56(%rbp), %rax
	movl	(%rax), %edx
	movq	-56(%rbp), %rax
	movl	4(%rax), %ecx
.LBB84:
	cmpl	%edx, %ecx
	.loc 1 1191 4 is_stmt 0 discriminator 3
	cmpl	%edx, %ecx
	.loc 1 1191 4 discriminator 6
	cmpl	%edx, %ecx
	.loc 1 1192 18 is_stmt 1
	cmpl	$1, %edx
	je	.L572
.LBB85:
	.loc 1 1192 18 is_stmt 0 discriminator 1
	leaq	.LC68(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC2(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rsi
	movq	-136(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L572:
.LBE85:
	.loc 1 1192 54 is_stmt 1 discriminator 2
	movslq	%edx, %rax
	leaq	16777215(%rax), %rdx
	movslq	%ecx, %rax
	.loc 1 1192 18 discriminator 2
	cmpq	%rax, %rdx
	jge	.L573
.LBB86:
	.loc 1 1192 18 is_stmt 0 discriminator 3
	leaq	.LC68(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC2(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rsi
	movq	-120(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L573:
.LBE86:
	.loc 1 1195 36 is_stmt 1
	leaq	silver_library_reports__json_predicate(%rip), %r10
	leaq	.LC4(%rip), %r11
	movq	%r10, %rcx
	movq	%r11, %rdi
	movq	-80(%rbp), %rdx
	movq	-64(%rbp), %rsi
	movq	-56(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -40(%rbp)
	.loc 1 1197 26
	leaq	silver_library_reports__json_arg(%rip), %rax
	movq	%rax, -112(%rbp)
	leaq	.LC18(%rip), %rax
	movq	%rax, -104(%rbp)
	movq	-112(%rbp), %rax
	movq	-104(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-80(%rbp), %rdx
	movq	-64(%rbp), %rsi
	movq	-56(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rcx
	.loc 1 1196 33
	movq	-72(%rbp), %rdx
	movq	-64(%rbp), %rsi
	movq	-56(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__referenced_entity
	movq	%rax, -48(%rbp)
	.loc 1 1199 15
	leaq	silver_library_reports__atom_claim_post(%rip), %rax
	movq	%rax, -96(%rbp)
	leaq	.LC19(%rip), %rax
	movq	%rax, -88(%rbp)
	movq	-96(%rbp), %rax
	movq	-88(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-40(%rbp), %rdx
	movq	-64(%rbp), %rsi
	movq	-56(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1202 9
	testb	%al, %al
	jne	.L574
	.loc 1 1200 23
	leaq	silver_library_reports__atom_claim_aorte(%rip), %r14
	leaq	.LC20(%rip), %r15
	movq	%r14, %rcx
	movq	%r15, %rdi
	movq	-40(%rbp), %rdx
	movq	-64(%rbp), %rsi
	movq	-56(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1200 15 discriminator 1
	testb	%al, %al
	jne	.L574
	.loc 1 1201 23
	leaq	silver_library_reports__atom_claim_effects(%rip), %r12
	leaq	.LC6(%rip), %r13
	movq	%r12, %rcx
	movq	%r13, %rdi
	movq	-40(%rbp), %rdx
	movq	-64(%rbp), %rsi
	movq	-56(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1201 15 discriminator 1
	testb	%al, %al
	je	.L575
.L574:
	.loc 1 1202 18 discriminator 1
	movq	-48(%rbp), %rdx
	movq	-64(%rbp), %rcx
	movq	-56(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__entity_name
	.loc 1 1202 45 discriminator 2
	testb	%al, %al
	setne	%al
	.loc 1 1202 9 discriminator 2
	testb	%al, %al
	je	.L575
	.loc 1 1202 9 is_stmt 0 discriminator 3
	movl	$1, %eax
	jmp	.L577
.L575:
	.loc 1 1202 9 discriminator 4
	movl	$0, %eax
.L577:
.LBE84:
	.loc 1 1203 8 is_stmt 1
	addq	$112, %rsp
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE27:
	.size	silver_library_reports__reference_ok, .-silver_library_reports__reference_ok
	.section	.rodata
	.align 8
.LC69:
	.ascii	"failed precondition from silver_library_reports.adb:1209"
.LC70:
	.ascii	"\"initialization of \\\""
.LC71:
	.ascii	"\\\" has no effect\""
	.text
	.align 2
	.globl	silver_library_reports__initializer_message
	.type	silver_library_reports__initializer_message, @function
silver_library_reports__initializer_message:
.LFB28:
	.loc 1 1211 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r12
	pushq	%rbx
	subq	$48, %rsp
	.cfi_offset 12, -24
	.cfi_offset 3, -32
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -48(%rbp)
	movq	%rbx, -40(%rbp)
	movq	%rdx, -56(%rbp)
	.loc 1 1211 4
	movq	-40(%rbp), %rax
	movl	(%rax), %ebx
	movq	-40(%rbp), %rax
	movl	4(%rax), %r12d
.LBB87:
	.loc 1 1209 15
	cmpl	$1, %ebx
	je	.L579
.LBB88:
	.loc 1 1209 15 is_stmt 0 discriminator 1
	leaq	.LC69(%rip), %r10
	leaq	.LC2(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L579:
.LBE88:
	.loc 1 1209 51 is_stmt 1 discriminator 2
	movslq	%ebx, %rax
	leaq	16777215(%rax), %rdx
	movslq	%r12d, %rax
	.loc 1 1209 15 discriminator 2
	cmpq	%rax, %rdx
	jge	.L580
.LBB89:
	.loc 1 1209 15 is_stmt 0 discriminator 3
	leaq	.LC69(%rip), %r8
	leaq	.LC2(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L580:
.LBE89:
	.loc 1 1212 7 is_stmt 1
	movq	-56(%rbp), %rdx
	movq	-48(%rbp), %rcx
	movq	-40(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__valid
	.loc 1 1219 9
	testb	%al, %al
	je	.L581
	.loc 1 1213 29
	movl	-52(%rbp), %edx
	movl	-56(%rbp), %eax
	subl	%eax, %edx
	.loc 1 1213 9
	cmpl	$37, %edx
	jle	.L581
	.loc 1 1214 29
	movl	-52(%rbp), %edx
	movl	-56(%rbp), %eax
	subl	%eax, %edx
	.loc 1 1214 9
	cmpl	$4133, %edx
	jg	.L581
	.loc 1 1215 18
	cmpl	%ebx, %r12d
	.loc 1 1215 18 is_stmt 0 discriminator 3
	cmpl	%ebx, %r12d
	.loc 1 1215 18 discriminator 6
	cmpl	%ebx, %r12d
	.loc 1 1215 35 is_stmt 1 discriminator 9
	movl	-56(%rbp), %eax
	cmpl	%eax, %ebx
	jg	.L588
	.loc 1 1215 35 is_stmt 0 discriminator 10
	movl	-56(%rbp), %eax
	addl	$19, %eax
	cmpl	%eax, %r12d
	jg	.L589
.L588:
	.loc 1 1215 35 discriminator 11
	leaq	.LC39(%rip), %rax
	movl	$1215, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L589:
	.loc 1 1215 87 is_stmt 1 discriminator 12
	movq	-48(%rbp), %rdx
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movl	-56(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rax, %rcx
	leaq	(%rdx,%rcx), %rax
	leaq	.LC70(%rip), %rcx
	movl	$21, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcmp@PLT
	.loc 1 1215 87 is_stmt 0 discriminator 13
	testl	%eax, %eax
	sete	%al
	.loc 1 1215 9 is_stmt 1 discriminator 13
	testb	%al, %al
	je	.L581
	.loc 1 1216 18
	cmpl	%ebx, %r12d
	.loc 1 1216 18 is_stmt 0 discriminator 3
	cmpl	%ebx, %r12d
	.loc 1 1216 18 discriminator 6
	cmpl	%ebx, %r12d
	.loc 1 1216 71 is_stmt 1 discriminator 9
	movl	-52(%rbp), %eax
	subl	$15, %eax
	cmpl	%eax, %ebx
	jge	.L596
	.loc 1 1216 71 is_stmt 0 discriminator 10
	movl	-52(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L597
.L596:
	.loc 1 1216 71 discriminator 11
	leaq	.LC39(%rip), %rax
	movl	$1216, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L597:
	.loc 1 1216 85 is_stmt 1 discriminator 12
	movq	-48(%rbp), %rdx
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	cltq
	.loc 1 1216 67 discriminator 12
	movl	-52(%rbp), %ecx
	subl	$16, %ecx
	movslq	%ecx, %rcx
	.loc 1 1216 85 discriminator 12
	subq	%rax, %rcx
	leaq	(%rdx,%rcx), %rax
	leaq	.LC71(%rip), %rcx
	movl	$17, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcmp@PLT
	.loc 1 1216 85 is_stmt 0 discriminator 13
	testl	%eax, %eax
	sete	%al
	.loc 1 1216 9 is_stmt 1 discriminator 13
	testb	%al, %al
	je	.L581
	.loc 1 1217 35
	movl	-56(%rbp), %eax
	addl	$21, %eax
	.loc 1 1217 18
	cmpl	%eax, %ebx
	jg	.L598
	.loc 1 1217 18 is_stmt 0 discriminator 1
	movl	-56(%rbp), %eax
	addl	$20, %eax
	cmpl	%eax, %r12d
	jg	.L599
.L598:
	.loc 1 1217 18 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1217, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L599:
	.loc 1 1217 74 is_stmt 1 discriminator 3
	movq	-48(%rbp), %rax
	movq	-40(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 1 1217 35 discriminator 3
	movl	-56(%rbp), %ecx
	addl	$21, %ecx
	movslq	%ecx, %rcx
	.loc 1 1217 74 discriminator 3
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 1 1217 87 discriminator 3
	cmpb	$64, %al
	jbe	.L600
	.loc 1 1217 74 discriminator 4
	movq	-48(%rbp), %rax
	movq	-40(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 1 1217 35 discriminator 4
	movl	-56(%rbp), %ecx
	addl	$21, %ecx
	movslq	%ecx, %rcx
	.loc 1 1217 74 discriminator 4
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$90, %al
	jbe	.L601
.L600:
	.loc 1 1217 87 discriminator 5
	movq	-48(%rbp), %rax
	movq	-40(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 1 1217 35 discriminator 5
	movl	-56(%rbp), %ecx
	addl	$21, %ecx
	movslq	%ecx, %rcx
	.loc 1 1217 87 discriminator 5
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$96, %al
	jbe	.L602
	.loc 1 1217 87 is_stmt 0 discriminator 6
	movq	-48(%rbp), %rax
	movq	-40(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 1 1217 35 is_stmt 1 discriminator 6
	movl	-56(%rbp), %ecx
	addl	$21, %ecx
	movslq	%ecx, %rcx
	.loc 1 1217 87 discriminator 6
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$122, %al
	ja	.L602
.L601:
	.loc 1 1217 87 is_stmt 0 discriminator 7
	movl	$1, %eax
	jmp	.L603
.L602:
	.loc 1 1217 87 discriminator 8
	movl	$0, %eax
.L603:
	.loc 1 1217 9 is_stmt 1 discriminator 9
	testb	%al, %al
	je	.L581
	.loc 1 1218 18
	movl	-52(%rbp), %eax
	subl	$16, %eax
	cmpl	%eax, %ebx
	jge	.L604
	.loc 1 1218 34 discriminator 1
	movl	-52(%rbp), %eax
	subl	$17, %eax
	.loc 1 1218 18 discriminator 1
	cmpl	%eax, %r12d
	jge	.L605
.L604:
	.loc 1 1218 18 is_stmt 0 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1218, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L605:
	.loc 1 1218 66 is_stmt 1 discriminator 3
	movq	-48(%rbp), %rax
	movq	-40(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 1 1218 34 discriminator 3
	movl	-52(%rbp), %ecx
	subl	$17, %ecx
	movslq	%ecx, %rcx
	.loc 1 1218 66 discriminator 3
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$95, %al
	setne	%al
	.loc 1 1218 9 discriminator 3
	testb	%al, %al
	je	.L581
	.loc 1 1219 19 discriminator 1
	movl	$1, %esi
	.loc 1 1219 43 discriminator 1
	movl	-56(%rbp), %eax
	.loc 1 1219 27 discriminator 1
	addl	$21, %eax
	movl	%eax, -24(%rbp)
	.loc 1 1219 87 discriminator 1
	movl	-52(%rbp), %eax
	.loc 1 1219 27 discriminator 1
	subl	$17, %eax
	movl	%eax, -28(%rbp)
	.loc 1 1219 19 discriminator 1
	movl	-24(%rbp), %eax
	cmpl	-28(%rbp), %eax
	jg	.L606
.LBB90:
	.loc 1 1219 27 discriminator 2
	movl	-24(%rbp), %eax
	movl	%eax, -20(%rbp)
.L625:
.LBB91:
	.loc 1 1220 11
	cmpl	-20(%rbp), %ebx
	jg	.L607
	.loc 1 1220 11 is_stmt 0 discriminator 1
	cmpl	-20(%rbp), %r12d
	jge	.L608
.L607:
	.loc 1 1220 11 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1220, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L608:
	.loc 1 1220 27 is_stmt 1 discriminator 3
	movq	-48(%rbp), %rax
	movq	-40(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-20(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 1 1220 62 discriminator 3
	cmpb	$64, %al
	jbe	.L609
	.loc 1 1220 27 discriminator 4
	movq	-48(%rbp), %rax
	movq	-40(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-20(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$90, %al
	jbe	.L610
.L609:
	.loc 1 1220 40 discriminator 5
	movq	-48(%rbp), %rax
	movq	-40(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-20(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$96, %al
	jbe	.L611
	.loc 1 1220 40 is_stmt 0 discriminator 6
	movq	-48(%rbp), %rax
	movq	-40(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-20(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$122, %al
	jbe	.L610
.L611:
	.loc 1 1220 53 is_stmt 1 discriminator 7
	movq	-48(%rbp), %rax
	movq	-40(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-20(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$47, %al
	jbe	.L612
	.loc 1 1220 53 is_stmt 0 discriminator 8
	movq	-48(%rbp), %rax
	movq	-40(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-20(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$57, %al
	jbe	.L610
.L612:
	.loc 1 1220 62 is_stmt 1 discriminator 9
	movq	-48(%rbp), %rax
	movq	-40(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-20(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$95, %al
	jne	.L613
.L610:
	.loc 1 1220 62 is_stmt 0 discriminator 10
	movl	$1, %eax
	jmp	.L614
.L613:
	.loc 1 1220 62 discriminator 11
	movl	$0, %eax
.L614:
	.loc 1 1220 20 is_stmt 1 discriminator 12
	xorl	$1, %eax
	.loc 1 1219 19 discriminator 3
	testb	%al, %al
	jne	.L615
	.loc 1 1221 24
	cmpl	-20(%rbp), %ebx
	jg	.L616
	.loc 1 1221 24 is_stmt 0 discriminator 1
	cmpl	-20(%rbp), %r12d
	jge	.L617
.L616:
	.loc 1 1221 24 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1221, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L617:
	.loc 1 1221 33 is_stmt 1 discriminator 3
	movq	-48(%rbp), %rax
	movq	-40(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-20(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 1 1221 21 discriminator 3
	cmpb	$95, %al
	jne	.L618
	.loc 1 1221 52 discriminator 4
	cmpl	$-2147483648, -20(%rbp)
	jne	.L619
	.loc 1 1221 52 is_stmt 0 discriminator 5
	leaq	.LC39(%rip), %rax
	movl	$1221, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L619:
	.loc 1 1221 52 discriminator 7
	movl	-20(%rbp), %eax
	subl	$1, %eax
	.loc 1 1221 44 is_stmt 1 discriminator 8
	cmpl	%ebx, %eax
	jl	.L620
	.loc 1 1221 44 is_stmt 0 discriminator 9
	cmpl	%r12d, %eax
	jle	.L621
.L620:
	.loc 1 1221 44 discriminator 10
	leaq	.LC39(%rip), %rax
	movl	$1221, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L621:
	.loc 1 1221 57 is_stmt 1 discriminator 11
	movq	-48(%rbp), %rax
	movq	-40(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 1 1221 52 discriminator 11
	movl	-20(%rbp), %ecx
	subl	$1, %ecx
	movslq	%ecx, %rcx
	.loc 1 1221 57 discriminator 11
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$95, %al
	setne	%al
	jmp	.L622
.L618:
	.loc 1 1221 21 discriminator 12
	movl	$1, %eax
.L622:
	.loc 1 1221 21 is_stmt 0 discriminator 13
	xorl	$1, %eax
	.loc 1 1221 11 is_stmt 1 discriminator 13
	testb	%al, %al
	je	.L623
.L615:
	.loc 1 1219 19 discriminator 4
	movl	$0, %esi
	jmp	.L606
.L623:
.LBE91:
	.loc 1 1219 19 is_stmt 0 discriminator 5
	movl	-20(%rbp), %eax
	cmpl	-28(%rbp), %eax
	je	.L606
	.loc 1 1219 19 discriminator 6
	addl	$1, -20(%rbp)
	jmp	.L625
.L606:
.LBE90:
	.loc 1 1219 9 is_stmt 1 discriminator 7
	testb	%sil, %sil
	je	.L581
	.loc 1 1219 9 is_stmt 0 discriminator 8
	movl	$1, %eax
	jmp	.L626
.L581:
	.loc 1 1219 9 discriminator 9
	movl	$0, %eax
.L626:
.LBE87:
	.loc 1 1211 4 is_stmt 1
	addq	$48, %rsp
	popq	%rbx
	popq	%r12
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE28:
	.size	silver_library_reports__initializer_message, .-silver_library_reports__initializer_message
	.section	.rodata
	.align 8
.LC72:
	.ascii	"failed precondition from silver_library_reports.adb:1225"
	.align 8
.LC21:
	.long	1
	.long	68
	.align 8
.LC22:
	.long	1
	.long	62
	.align 8
.LC23:
	.long	1
	.long	64
	.align 8
.LC24:
	.long	1
	.long	63
	.align 8
.LC25:
	.long	1
	.long	57
	.align 8
.LC26:
	.long	1
	.long	59
	.text
	.align 2
	.globl	silver_library_reports__output_message
	.type	silver_library_reports__output_message, @function
silver_library_reports__output_message:
.LFB29:
	.loc 1 1227 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$136, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -64(%rbp)
	movq	%rbx, -56(%rbp)
	movq	%rdx, -72(%rbp)
	.loc 1 1227 4
	movq	-56(%rbp), %rax
	movl	(%rax), %edx
	movq	-56(%rbp), %rax
	movl	4(%rax), %ecx
.LBB92:
	.loc 1 1225 15
	cmpl	$1, %edx
	je	.L629
.LBB93:
	.loc 1 1225 15 is_stmt 0 discriminator 1
	leaq	.LC72(%rip), %r8
	leaq	.LC2(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L629:
.LBE93:
	.loc 1 1225 51 is_stmt 1 discriminator 2
	movslq	%edx, %rax
	leaq	16777215(%rax), %rdx
	movslq	%ecx, %rax
	.loc 1 1225 15 discriminator 2
	cmpq	%rax, %rdx
	jge	.L630
.LBB94:
	.loc 1 1225 15 is_stmt 0 discriminator 3
	leaq	.LC72(%rip), %r10
	leaq	.LC2(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L630:
.LBE94:
	.loc 1 1228 7 is_stmt 1
	leaq	silver_library_reports__atom_unused_written_count(%rip), %r12
	leaq	.LC21(%rip), %r13
	movq	%r12, %rcx
	movq	%r13, %rdi
	movq	-72(%rbp), %rdx
	movq	-64(%rbp), %rsi
	movq	-56(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1235 7
	testb	%al, %al
	jne	.L631
	.loc 1 1229 15
	leaq	silver_library_reports__atom_unused_flushed(%rip), %r14
	leaq	.LC22(%rip), %r15
	movq	%r14, %rax
	movq	%r15, %r8
	movq	-72(%rbp), %rdx
	movq	-64(%rbp), %rdi
	movq	-56(%rbp), %rsi
	movq	%rax, %rcx
	call	silver_library_reports__string_equal
	.loc 1 1229 7 discriminator 1
	testb	%al, %al
	jne	.L631
	.loc 1 1230 15
	leaq	silver_library_reports__atom_unused_succeeded(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC23(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rax
	movq	%rsi, %rdi
	movq	-72(%rbp), %rdx
	movq	-64(%rbp), %rsi
	movq	-56(%rbp), %r9
	movq	%rax, %rcx
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%r9, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1230 7 discriminator 1
	testb	%al, %al
	jne	.L631
	.loc 1 1231 15
	leaq	silver_library_reports__atom_unused_written_bytes(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC21(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rax
	movq	-152(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-72(%rbp), %rdx
	movq	-64(%rbp), %rsi
	movq	-56(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1231 7 discriminator 1
	testb	%al, %al
	jne	.L631
	.loc 1 1232 15
	leaq	silver_library_reports__atom_put_unused_written_count(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC24(%rip), %rbx
	movq	%rbx, -136(%rbp)
	movq	-144(%rbp), %rax
	movq	-136(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-72(%rbp), %rdx
	movq	-64(%rbp), %rsi
	movq	-56(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1232 7 discriminator 1
	testb	%al, %al
	jne	.L631
	.loc 1 1233 15
	leaq	silver_library_reports__atom_put_unused_flushed(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC25(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rax
	movq	-120(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-72(%rbp), %rdx
	movq	-64(%rbp), %rsi
	movq	-56(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1233 7 discriminator 1
	testb	%al, %al
	jne	.L631
	.loc 1 1234 15
	leaq	silver_library_reports__atom_put_unused_succeeded(%rip), %rax
	movq	%rax, -112(%rbp)
	leaq	.LC26(%rip), %rax
	movq	%rax, -104(%rbp)
	movq	-112(%rbp), %rax
	movq	-104(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-72(%rbp), %rdx
	movq	-64(%rbp), %rsi
	movq	-56(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1234 7 discriminator 1
	testb	%al, %al
	jne	.L631
	.loc 1 1235 15 discriminator 1
	leaq	silver_library_reports__atom_put_unused_written_bytes(%rip), %rax
	movq	%rax, -96(%rbp)
	movq	%rbx, -88(%rbp)
	movq	-96(%rbp), %rax
	movq	-88(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-72(%rbp), %rdx
	movq	-64(%rbp), %rsi
	movq	-56(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1235 7 discriminator 2
	testb	%al, %al
	je	.L632
.L631:
	.loc 1 1235 7 is_stmt 0 discriminator 3
	movl	$1, %eax
	jmp	.L633
.L632:
	.loc 1 1235 7 discriminator 4
	movl	$0, %eax
.L633:
.LBE92:
	.loc 1 1227 4 is_stmt 1
	addq	$136, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE29:
	.size	silver_library_reports__output_message, .-silver_library_reports__output_message
	.align 2
	.type	silver_library_reports__list_kindH, @function
silver_library_reports__list_kindH:
.LFB30:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	movq	-8(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L636
	movl	%edx, %ecx
	subl	%eax, %ecx
	leal	1(%rcx), %r11d
	jmp	.L637
.L636:
	movl	$0, %r11d
.L637:
	movslq	%eax, %r9
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	leal	-1(%rax), %r10d
	movl	$0, %ecx
	movl	$0, %edx
	movl	$0, %eax
.L645:
	cmpl	$1, %eax
	jg	.L644
	movslq	%eax, %rsi
	leaq	0(,%rsi,4), %rdi
	leaq	list_kindP.7(%rip), %rsi
	movl	(%rdi,%rsi), %esi
	cmpl	%esi, %r11d
	jl	.L644
	movq	-16(%rbp), %rsi
	movslq	%eax, %rdi
	leaq	0(,%rdi,4), %r8
	leaq	list_kindP.7(%rip), %rdi
	movl	(%r8,%rdi), %edi
	addl	%r10d, %edi
	movslq	%edi, %rdi
	subq	%r9, %rdi
	movzbl	(%rsi,%rdi), %esi
	movzbl	%sil, %edi
	movslq	%eax, %rsi
	leaq	list_kindT1.6(%rip), %r8
	movzbl	(%rsi,%r8), %esi
	movzbl	%sil, %esi
	imull	%edi, %esi
	addl	%ecx, %esi
	movslq	%esi, %rcx
	imulq	$-1307163959, %rcx, %rcx
	shrq	$32, %rcx
	addl	%esi, %ecx
	sarl	$4, %ecx
	movl	%esi, %r8d
	sarl	$31, %r8d
	subl	%r8d, %ecx
	imull	$23, %ecx, %r8d
	movl	%esi, %ecx
	subl	%r8d, %ecx
	movslq	%eax, %rsi
	leaq	list_kindT2.5(%rip), %r8
	movzbl	(%rsi,%r8), %esi
	movzbl	%sil, %esi
	imull	%edi, %esi
	addl	%edx, %esi
	movslq	%esi, %rdx
	imulq	$-1307163959, %rdx, %rdx
	shrq	$32, %rdx
	addl	%esi, %edx
	sarl	$4, %edx
	movl	%esi, %edi
	sarl	$31, %edi
	subl	%edi, %edx
	imull	$23, %edx, %edi
	movl	%esi, %edx
	subl	%edi, %edx
	addl	$1, %eax
	jmp	.L645
.L644:
	movslq	%ecx, %rax
	leaq	list_kindG.4(%rip), %rcx
	movzbl	(%rax,%rcx), %eax
	movzbl	%al, %ecx
	movslq	%edx, %rax
	leaq	list_kindG.4(%rip), %rdx
	movzbl	(%rax,%rdx), %eax
	movzbl	%al, %eax
	addl	%eax, %ecx
	movslq	%ecx, %rax
	imulq	$780903145, %rax, %rax
	shrq	$32, %rax
	movl	%eax, %edx
	sarl	%edx
	movl	%ecx, %eax
	sarl	$31, %eax
	subl	%eax, %edx
	movl	%edx, %eax
	sall	$2, %eax
	addl	%edx, %eax
	addl	%eax, %eax
	addl	%edx, %eax
	subl	%eax, %ecx
	movl	%ecx, %edx
	movl	%edx, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE30:
	.size	silver_library_reports__list_kindH, .-silver_library_reports__list_kindH
	.section	.rodata
	.align 8
.LC73:
	.ascii	"failed precondition from silver_library_reports.adb:1336"
	.align 8
.LC27:
	.long	1
	.long	7
	.align 8
.LC28:
	.long	1
	.long	8
	.align 8
.LC29:
	.long	1
	.long	15
	.align 8
.LC30:
	.long	1
	.long	194
	.align 8
.LC31:
	.long	1
	.long	6
	.align 8
.LC32:
	.long	1
	.long	0
	.align 8
.LC33:
	.long	1
	.long	17
	.align 8
.LC34:
	.long	1
	.long	22
	.align 8
.LC35:
	.long	1
	.long	20
	.text
	.align 2
	.type	silver_library_reports__record_ok, @function
silver_library_reports__record_ok:
.LFB31:
	.loc 1 1334 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$1912, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r9
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r9, %rdi
	movq	%rsi, -240(%rbp)
	movq	%rdi, -232(%rbp)
	movq	%rdx, -248(%rbp)
	movq	%rcx, -256(%rbp)
	movb	%r8b, -257(%rbp)
	.loc 1 1334 4
	movq	-232(%rbp), %rax
	movl	(%rax), %edx
	movq	-232(%rbp), %rax
	movl	4(%rax), %ecx
.LBB97:
	cmpl	%edx, %ecx
	.loc 1 1334 4 is_stmt 0 discriminator 3
	cmpl	%edx, %ecx
	.loc 1 1334 4 discriminator 6
	cmpl	%edx, %ecx
	.loc 1 1336 18 is_stmt 1
	cmpl	$1, %edx
	je	.L654
.LBB98:
	.loc 1 1336 18 is_stmt 0 discriminator 1
	leaq	.LC73(%rip), %r10
	leaq	.LC2(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L654:
.LBE98:
	.loc 1 1336 54 is_stmt 1 discriminator 2
	movslq	%edx, %rax
	leaq	16777215(%rax), %rdx
	movslq	%ecx, %rax
	.loc 1 1336 18 discriminator 2
	cmpq	%rax, %rdx
	jge	.L655
.LBB99:
	.loc 1 1336 18 is_stmt 0 discriminator 3
	leaq	.LC73(%rip), %r12
	leaq	.LC2(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L655:
.LBE99:
	.loc 1 1339 7 is_stmt 1
	movl	$0, -56(%rbp)
	movl	$0, -52(%rbp)
	.loc 1 1341 7
	cmpb	$7, -257(%rbp)
	jne	.L656
	.loc 1 1341 40 discriminator 1
	movq	-248(%rbp), %rcx
	movq	-256(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__reference_ok
	.loc 1 1341 33 discriminator 2
	jmp	.L723
.L656:
	.loc 1 1342 7
	cmpb	$6, -257(%rbp)
	jne	.L658
	.loc 1 1343 17
	leaq	silver_library_reports__atom_warning(%rip), %rax
	movq	%rax, -1952(%rbp)
	leaq	.LC27(%rip), %r13
	movq	%r13, -1944(%rbp)
	.loc 1 1343 37
	leaq	silver_library_reports__json_severity(%rip), %r14
	leaq	.LC28(%rip), %r15
	movq	%r14, %rcx
	movq	%r15, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1343 17 discriminator 1
	movq	-1952(%rbp), %r14
	movq	-1944(%rbp), %r15
	movq	%r14, %rdx
	movq	%r15, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1359 9
	testb	%al, %al
	je	.L659
	.loc 1 1344 18
	leaq	silver_library_reports__atom_trivial(%rip), %rax
	movq	%rax, -1936(%rbp)
	movq	%r13, -1928(%rbp)
	.loc 1 1344 38
	leaq	silver_library_reports__json_how_proved(%rip), %rax
	movq	%rax, -1920(%rbp)
	leaq	.LC19(%rip), %rbx
	movq	%rbx, -1912(%rbp)
	movq	-1920(%rbp), %rax
	movq	-1912(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1344 18 discriminator 1
	movq	-1936(%rbp), %r9
	movq	-1928(%rbp), %r10
	movq	%r9, %rdx
	movq	%r10, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1344 9 discriminator 2
	testb	%al, %al
	je	.L659
	.loc 1 1345 18
	leaq	silver_library_reports__atom_main_adb(%rip), %rax
	movq	%rax, -1904(%rbp)
	leaq	.LC28(%rip), %rax
	movq	%rax, -1896(%rbp)
	.loc 1 1345 38
	leaq	silver_library_reports__json_file(%rip), %rax
	movq	%rax, -1888(%rbp)
	leaq	.LC3(%rip), %r12
	movq	%r12, -1880(%rbp)
	movq	-1888(%rbp), %rax
	movq	-1880(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1345 18 discriminator 1
	movq	-1904(%rbp), %r14
	movq	-1896(%rbp), %r15
	movq	%r14, %rdx
	movq	%r15, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1345 9 discriminator 2
	testb	%al, %al
	je	.L659
	.loc 1 1346 41
	leaq	silver_library_reports__json_line(%rip), %rax
	movq	%rax, -1872(%rbp)
	movq	%r12, %r15
	movq	%r15, -1864(%rbp)
	movq	-1872(%rbp), %rax
	movq	-1864(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 1346 18 discriminator 1
	movq	-240(%rbp), %rcx
	movq	-232(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__positive_number
	.loc 1 1346 9 discriminator 2
	testb	%al, %al
	je	.L659
	.loc 1 1347 41
	leaq	silver_library_reports__json_col(%rip), %rax
	movq	%rax, -1856(%rbp)
	leaq	.LC18(%rip), %rax
	movq	%rax, -1848(%rbp)
	movq	-1856(%rbp), %rax
	movq	-1848(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 1347 18 discriminator 1
	movq	-240(%rbp), %rcx
	movq	-232(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__positive_number
	.loc 1 1347 9 discriminator 2
	testb	%al, %al
	je	.L659
	.loc 1 1348 18
	leaq	silver_library_reports__atom_imprecise_image(%rip), %rax
	movq	%rax, -1840(%rbp)
	leaq	.LC29(%rip), %r12
	movq	%r12, -1832(%rbp)
	.loc 1 1348 38
	leaq	silver_library_reports__json_rule(%rip), %rax
	movq	%rax, -1824(%rbp)
	movq	%r15, -1816(%rbp)
	movq	-1824(%rbp), %rax
	movq	-1816(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1348 18 discriminator 1
	movq	-1840(%rbp), %r10
	movq	-1832(%rbp), %r11
	movq	%r10, %rdx
	movq	%r11, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1348 9 discriminator 2
	testb	%al, %al
	je	.L659
	.loc 1 1349 18
	leaq	silver_library_reports__atom_image_message(%rip), %rax
	movq	%rax, -1808(%rbp)
	leaq	.LC30(%rip), %rax
	movq	%rax, -1800(%rbp)
.LBB100:
	.loc 1 1349 38
	leaq	silver_library_reports__json_text(%rip), %rax
	movq	%rax, -1792(%rbp)
	movq	%r15, -1784(%rbp)
	.loc 1 1350 18
	leaq	silver_library_reports__json_message(%rip), %rax
	movq	%rax, -1776(%rbp)
	movq	%r13, -1768(%rbp)
	movq	-1776(%rbp), %rax
	movq	-1768(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1349 38 discriminator 1
	movq	-1792(%rbp), %r14
	movq	-1784(%rbp), %r15
	movq	%r14, %rdx
	movq	%r15, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
.LBE100:
	.loc 1 1349 18 discriminator 2
	movq	-1808(%rbp), %r10
	movq	-1800(%rbp), %r11
	movq	%r10, %rdx
	movq	%r11, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1349 9 discriminator 3
	testb	%al, %al
	je	.L659
	.loc 1 1351 18
	leaq	silver_library_reports__atom_unknown(%rip), %rax
	movq	%rax, -1760(%rbp)
	movq	%r13, -1752(%rbp)
.LBB101:
	.loc 1 1351 38
	leaq	silver_library_reports__json_status(%rip), %rax
	movq	%rax, -1744(%rbp)
	leaq	.LC31(%rip), %r15
	movq	%r15, -1736(%rbp)
	.loc 1 1352 18
	leaq	silver_library_reports__json_unproved_status(%rip), %rax
	movq	%rax, -1728(%rbp)
	movq	%r12, -1720(%rbp)
	movq	-1728(%rbp), %rax
	movq	-1720(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1351 38 discriminator 1
	movq	-1744(%rbp), %r11
	movq	-1736(%rbp), %r12
	movq	%r11, %rdx
	movq	%r12, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
.LBE101:
	.loc 1 1351 18 discriminator 2
	movq	-1760(%rbp), %r11
	movq	-1752(%rbp), %r12
	movq	%r11, %rdx
	movq	%r12, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1351 9 discriminator 3
	testb	%al, %al
	je	.L659
	.loc 1 1353 38
	leaq	silver_library_reports__json_check_tree(%rip), %rax
	movq	%rax, -1712(%rbp)
	movq	%rbx, -1704(%rbp)
	movq	-1712(%rbp), %rax
	movq	-1704(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 1353 18 discriminator 1
	movq	-240(%rbp), %rcx
	movq	-232(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__empty_object
	.loc 1 1353 9 discriminator 2
	testb	%al, %al
	je	.L659
	.loc 1 1354 18
	leaq	silver_library_reports__atom_empty(%rip), %rax
	movq	%rax, -1696(%rbp)
	leaq	.LC32(%rip), %rax
	movq	%rax, -1688(%rbp)
	.loc 1 1354 38
	leaq	silver_library_reports__json_suppressed(%rip), %rax
	movq	%rax, -1680(%rbp)
	movq	%rbx, -1672(%rbp)
	movq	-1680(%rbp), %rsi
	movq	-1672(%rbp), %rdi
	movq	%rsi, %rax
	movq	%rdi, %r8
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rdi
	movq	-232(%rbp), %rsi
	movq	%rax, %rcx
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 1354 18 discriminator 1
	movq	-1696(%rbp), %rsi
	movq	-1688(%rbp), %rdi
	movq	%rsi, %rax
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %r9
	movq	%rax, %rcx
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%r9, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1354 9 discriminator 2
	testb	%al, %al
	je	.L659
	.loc 1 1355 18
	leaq	silver_library_reports__json_entity(%rip), %rax
	movq	%rax, -1664(%rbp)
	movq	%r15, -1656(%rbp)
	movq	-1664(%rbp), %rax
	movq	-1656(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -64(%rbp)
	.loc 1 1355 18 is_stmt 0 discriminator 1
	leaq	-64(%rbp), %rax
	.loc 1 1355 50 is_stmt 1 discriminator 1
	movl	(%rax), %edx
	.loc 1 1355 50 is_stmt 0 discriminator 2
	testl	%edx, %edx
	jne	.L660
	.loc 1 1355 50 discriminator 3
	movl	4(%rax), %eax
	.loc 1 1355 50 discriminator 4
	testl	%eax, %eax
	jne	.L660
	.loc 1 1355 50 discriminator 5
	movl	$1, %eax
	jmp	.L661
.L660:
	.loc 1 1355 50 discriminator 6
	movl	$0, %eax
.L661:
	.loc 1 1355 9 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L659
	.loc 1 1356 18
	leaq	silver_library_reports__json_justification(%rip), %rax
	movq	%rax, -1648(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -1640(%rbp)
	movq	-1648(%rbp), %rax
	movq	-1640(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -72(%rbp)
	.loc 1 1356 18 is_stmt 0 discriminator 1
	leaq	-72(%rbp), %rax
	.loc 1 1356 57 is_stmt 1 discriminator 1
	movl	(%rax), %edx
	.loc 1 1356 57 is_stmt 0 discriminator 2
	testl	%edx, %edx
	jne	.L662
	.loc 1 1356 57 discriminator 3
	movl	4(%rax), %eax
	.loc 1 1356 57 discriminator 4
	testl	%eax, %eax
	jne	.L662
	.loc 1 1356 57 discriminator 5
	movl	$1, %eax
	jmp	.L663
.L662:
	.loc 1 1356 57 discriminator 6
	movl	$0, %eax
.L663:
	.loc 1 1356 9 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L659
	.loc 1 1357 18
	leaq	silver_library_reports__json_justified(%rip), %rax
	movq	%rax, -1632(%rbp)
	leaq	.LC4(%rip), %rax
	movq	%rax, -1624(%rbp)
	movq	-1632(%rbp), %rax
	movq	-1624(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -80(%rbp)
	.loc 1 1357 18 is_stmt 0 discriminator 1
	leaq	-80(%rbp), %rax
	.loc 1 1357 53 is_stmt 1 discriminator 1
	movl	(%rax), %edx
	.loc 1 1357 53 is_stmt 0 discriminator 2
	testl	%edx, %edx
	jne	.L664
	.loc 1 1357 53 discriminator 3
	movl	4(%rax), %eax
	.loc 1 1357 53 discriminator 4
	testl	%eax, %eax
	jne	.L664
	.loc 1 1357 53 discriminator 5
	movl	$1, %eax
	jmp	.L665
.L664:
	.loc 1 1357 53 discriminator 6
	movl	$0, %eax
.L665:
	.loc 1 1357 9 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L659
	.loc 1 1358 18
	leaq	silver_library_reports__json_annot_kind(%rip), %rax
	movq	%rax, -1616(%rbp)
	leaq	.LC19(%rip), %rax
	movq	%rax, -1608(%rbp)
	movq	-1616(%rbp), %rax
	movq	-1608(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -88(%rbp)
	.loc 1 1358 18 is_stmt 0 discriminator 1
	leaq	-88(%rbp), %rax
	.loc 1 1358 54 is_stmt 1 discriminator 1
	movl	(%rax), %edx
	.loc 1 1358 54 is_stmt 0 discriminator 2
	testl	%edx, %edx
	jne	.L666
	.loc 1 1358 54 discriminator 3
	movl	4(%rax), %eax
	.loc 1 1358 54 discriminator 4
	testl	%eax, %eax
	jne	.L666
	.loc 1 1358 54 discriminator 5
	movl	$1, %eax
	jmp	.L667
.L666:
	.loc 1 1358 54 discriminator 6
	movl	$0, %eax
.L667:
	.loc 1 1358 9 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L659
	.loc 1 1359 18 discriminator 1
	leaq	silver_library_reports__json_justif_msg(%rip), %rax
	movq	%rax, -1600(%rbp)
	leaq	.LC19(%rip), %rax
	movq	%rax, -1592(%rbp)
	movq	-1600(%rbp), %rax
	movq	-1592(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -96(%rbp)
	.loc 1 1359 18 is_stmt 0 discriminator 2
	leaq	-96(%rbp), %rax
	.loc 1 1359 54 is_stmt 1 discriminator 2
	movl	(%rax), %edx
	.loc 1 1359 54 is_stmt 0 discriminator 3
	testl	%edx, %edx
	jne	.L668
	.loc 1 1359 54 discriminator 4
	movl	4(%rax), %eax
	.loc 1 1359 54 discriminator 5
	testl	%eax, %eax
	jne	.L668
	.loc 1 1359 54 discriminator 6
	movl	$1, %eax
	jmp	.L669
.L668:
	.loc 1 1359 54 discriminator 7
	movl	$0, %eax
.L669:
	.loc 1 1359 9 is_stmt 1 discriminator 8
	testb	%al, %al
	je	.L659
	.loc 1 1359 9 is_stmt 0 discriminator 9
	movl	$1, %eax
	.loc 1 1343 10 is_stmt 1 discriminator 3
	jmp	.L723
.L659:
	.loc 1 1359 9 discriminator 10
	movl	$0, %eax
	.loc 1 1343 10 discriminator 3
	jmp	.L723
.L658:
	.loc 1 1361 7
	cmpb	$1, -257(%rbp)
	jbe	.L671
	.loc 1 1361 15 discriminator 1
	cmpb	$5, -257(%rbp)
	ja	.L671
	.loc 1 1363 9
	leaq	silver_library_reports__atom_warning(%rip), %rax
	movq	%rax, -1584(%rbp)
	leaq	.LC27(%rip), %rbx
	movq	%rbx, -1576(%rbp)
	.loc 1 1363 29
	leaq	silver_library_reports__json_severity(%rip), %rax
	movq	%rax, -1568(%rbp)
	leaq	.LC28(%rip), %r13
	movq	%r13, -1560(%rbp)
	movq	-1568(%rbp), %rax
	movq	-1560(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1363 9 discriminator 1
	movq	-1584(%rbp), %r14
	movq	-1576(%rbp), %r15
	movq	%r14, %rdx
	movq	%r15, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1389 9
	testb	%al, %al
	je	.L672
	.loc 1 1364 18
	leaq	silver_library_reports__json_flow(%rip), %rax
	movq	%rax, -1552(%rbp)
	leaq	.LC3(%rip), %r14
	movq	%r14, -1544(%rbp)
	.loc 1 1364 38
	leaq	silver_library_reports__json_how_proved(%rip), %rax
	movq	%rax, -1536(%rbp)
	leaq	.LC19(%rip), %rax
	movq	%rax, -1528(%rbp)
	movq	-1536(%rbp), %rax
	movq	-1528(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1364 18 discriminator 1
	movq	-1552(%rbp), %r9
	movq	-1544(%rbp), %r10
	movq	%r9, %rdx
	movq	%r10, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1364 9 discriminator 2
	testb	%al, %al
	je	.L672
	.loc 1 1365 18
	leaq	silver_library_reports__atom_main_adb(%rip), %rax
	movq	%rax, -1520(%rbp)
	movq	%r13, -1512(%rbp)
	.loc 1 1365 38
	leaq	silver_library_reports__json_file(%rip), %rax
	movq	%rax, -1504(%rbp)
	movq	%r14, -1496(%rbp)
	movq	-1504(%rbp), %rax
	movq	-1496(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1365 18 discriminator 1
	movq	-1520(%rbp), %r11
	movq	-1512(%rbp), %r12
	movq	%r11, %rdx
	movq	%r12, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1365 9 discriminator 2
	testb	%al, %al
	je	.L672
	.loc 1 1366 41
	leaq	silver_library_reports__json_line(%rip), %rax
	movq	%rax, -1488(%rbp)
	movq	%r14, -1480(%rbp)
	movq	-1488(%rbp), %rax
	movq	-1480(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 1366 18 discriminator 1
	movq	-240(%rbp), %rcx
	movq	-232(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__positive_number
	.loc 1 1366 9 discriminator 2
	testb	%al, %al
	je	.L672
	.loc 1 1367 41
	leaq	silver_library_reports__json_col(%rip), %rax
	movq	%rax, -1472(%rbp)
	leaq	.LC18(%rip), %rax
	movq	%rax, -1464(%rbp)
	movq	-1472(%rbp), %rax
	movq	-1464(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 1367 18 discriminator 1
	movq	-240(%rbp), %rcx
	movq	-232(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__positive_number
	.loc 1 1367 9 discriminator 2
	testb	%al, %al
	je	.L672
.LBB102:
	.loc 1 1369 28
	leaq	silver_library_reports__json_entity(%rip), %rax
	movq	%rax, -1456(%rbp)
	leaq	.LC31(%rip), %rax
	movq	%rax, -1448(%rbp)
	movq	-1456(%rbp), %rax
	movq	-1448(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rcx
	.loc 1 1368 37
	movq	-256(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__referenced_entity
	movq	%rax, %rdx
.LBE102:
	.loc 1 1368 18 discriminator 1
	movq	-240(%rbp), %rcx
	movq	-232(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__entity_name
	.loc 1 1369 62 discriminator 1
	cmpb	$17, %al
	sete	%al
	.loc 1 1368 9 discriminator 2
	testb	%al, %al
	je	.L672
	.loc 1 1371 13
	leaq	silver_library_reports__atom_ineffective(%rip), %rax
	movq	%rax, -1440(%rbp)
	leaq	.LC20(%rip), %rax
	movq	%rax, -1432(%rbp)
	.loc 1 1371 33
	leaq	silver_library_reports__json_rule(%rip), %rax
	movq	%rax, -1424(%rbp)
	movq	%r14, %r13
	movq	%r14, -1416(%rbp)
	movq	-1424(%rbp), %rax
	movq	-1416(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1371 13 discriminator 1
	movq	-1440(%rbp), %r14
	movq	-1432(%rbp), %r15
	movq	%r14, %rdx
	movq	%r15, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1370 9
	testb	%al, %al
	je	.L673
.LBB103:
	.loc 1 1373 43
	leaq	silver_library_reports__json_text(%rip), %r15
	movq	%r15, -1408(%rbp)
	movq	%r13, %r14
	movq	%r14, -1400(%rbp)
	.loc 1 1374 25
	leaq	silver_library_reports__json_message(%rip), %r13
	movq	%r13, -1392(%rbp)
	movq	%rbx, -1384(%rbp)
	movq	-1392(%rbp), %rax
	movq	-1384(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1373 43 discriminator 1
	movq	-1408(%rbp), %r9
	movq	-1400(%rbp), %r10
	movq	%r9, %rdx
	movq	%r10, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
.LBE103:
	.loc 1 1373 16 discriminator 2
	movq	-240(%rbp), %rcx
	movq	-232(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__initializer_message
	.loc 1 1372 13
	testb	%al, %al
	jne	.L674
.LBB104:
	.loc 1 1375 46
	movq	%r15, -1376(%rbp)
	movq	%r14, -1368(%rbp)
	.loc 1 1376 25
	movq	%r13, -1360(%rbp)
	movq	%rbx, -1352(%rbp)
	movq	-1360(%rbp), %rax
	movq	-1352(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1375 46 discriminator 1
	movq	-1376(%rbp), %r11
	movq	-1368(%rbp), %r12
	movq	%r11, %rdx
	movq	%r12, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
.LBE104:
	.loc 1 1375 24 discriminator 2
	movq	-240(%rbp), %rcx
	movq	-232(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__output_message
	.loc 1 1375 16 discriminator 3
	testb	%al, %al
	jne	.L674
	.loc 1 1377 16
	cmpb	$4, -257(%rbp)
	je	.L675
	.loc 1 1377 58 discriminator 1
	cmpb	$5, -257(%rbp)
	jne	.L676
.L675:
	.loc 1 1378 27
	leaq	silver_library_reports__atom_unused_assignment(%rip), %rax
	movq	%rax, -1344(%rbp)
	leaq	.LC33(%rip), %rax
	movq	%rax, -1336(%rbp)
.LBB105:
	.loc 1 1378 47
	leaq	silver_library_reports__json_text(%rip), %rax
	movq	%rax, -1328(%rbp)
	leaq	.LC3(%rip), %rax
	movq	%rax, -1320(%rbp)
	.loc 1 1379 27
	leaq	silver_library_reports__json_message(%rip), %rax
	movq	%rax, -1312(%rbp)
	leaq	.LC27(%rip), %rax
	movq	%rax, -1304(%rbp)
	movq	-1312(%rbp), %rax
	movq	-1304(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1378 47 discriminator 1
	movq	-1328(%rbp), %r9
	movq	-1320(%rbp), %r10
	movq	%r9, %rdx
	movq	%r10, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
.LBE105:
	.loc 1 1378 27 discriminator 2
	movq	-1344(%rbp), %r11
	movq	-1336(%rbp), %r12
	movq	%r11, %rdx
	movq	%r12, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1378 18 discriminator 3
	testb	%al, %al
	jne	.L674
.L676:
	.loc 1 1380 25
	leaq	silver_library_reports__atom_statement_no_effect(%rip), %rax
	movq	%rax, -1296(%rbp)
	leaq	.LC13(%rip), %rax
	movq	%rax, -1288(%rbp)
.LBB106:
	.loc 1 1380 45
	leaq	silver_library_reports__json_text(%rip), %rax
	movq	%rax, -1280(%rbp)
	leaq	.LC3(%rip), %rax
	movq	%rax, -1272(%rbp)
	.loc 1 1381 27
	leaq	silver_library_reports__json_message(%rip), %rax
	movq	%rax, -1264(%rbp)
	leaq	.LC27(%rip), %rax
	movq	%rax, -1256(%rbp)
	movq	-1264(%rbp), %rax
	movq	-1256(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1380 45 discriminator 1
	movq	-1280(%rbp), %r11
	movq	-1272(%rbp), %r12
	movq	%r11, %rdx
	movq	%r12, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
.LBE106:
	.loc 1 1380 25 discriminator 2
	movq	-1296(%rbp), %r14
	movq	-1288(%rbp), %r15
	movq	%r14, %rdx
	movq	%r15, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1380 16 discriminator 3
	testb	%al, %al
	jne	.L674
.L673:
	.loc 1 1382 21
	leaq	silver_library_reports__atom_dead_code(%rip), %rax
	movq	%rax, -1248(%rbp)
	leaq	.LC4(%rip), %rax
	movq	%rax, -1240(%rbp)
	.loc 1 1382 41
	leaq	silver_library_reports__json_rule(%rip), %rax
	movq	%rax, -1232(%rbp)
	leaq	.LC3(%rip), %rbx
	movq	%rbx, -1224(%rbp)
	movq	-1232(%rbp), %rax
	movq	-1224(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1382 21 discriminator 1
	movq	-1248(%rbp), %r14
	movq	-1240(%rbp), %r15
	movq	%r14, %rdx
	movq	%r15, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1382 12 discriminator 2
	testb	%al, %al
	je	.L672
	.loc 1 1383 23
	leaq	silver_library_reports__atom_statement_unreachable(%rip), %rax
	movq	%rax, -1216(%rbp)
	leaq	.LC11(%rip), %rax
	movq	%rax, -1208(%rbp)
.LBB107:
	.loc 1 1383 43
	leaq	silver_library_reports__json_text(%rip), %rax
	movq	%rax, -1200(%rbp)
	movq	%rbx, -1192(%rbp)
	.loc 1 1384 23
	leaq	silver_library_reports__json_message(%rip), %rax
	movq	%rax, -1184(%rbp)
	leaq	.LC27(%rip), %rax
	movq	%rax, -1176(%rbp)
	movq	-1184(%rbp), %rax
	movq	-1176(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1383 43 discriminator 1
	movq	-1200(%rbp), %r9
	movq	-1192(%rbp), %r10
	movq	%r9, %rdx
	movq	%r10, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
.LBE107:
	.loc 1 1383 23 discriminator 2
	movq	-1216(%rbp), %rsi
	movq	-1208(%rbp), %rdi
	movq	%rsi, %rax
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %r9
	movq	%rax, %rcx
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%r9, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1383 14 discriminator 3
	testb	%al, %al
	je	.L672
.L674:
	.loc 1 1385 18
	leaq	silver_library_reports__json_justification(%rip), %rax
	movq	%rax, -1168(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -1160(%rbp)
	movq	-1168(%rbp), %rax
	movq	-1160(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -104(%rbp)
	.loc 1 1385 18 is_stmt 0 discriminator 1
	leaq	-104(%rbp), %rax
	.loc 1 1385 57 is_stmt 1 discriminator 1
	movl	(%rax), %edx
	.loc 1 1385 57 is_stmt 0 discriminator 2
	testl	%edx, %edx
	jne	.L677
	.loc 1 1385 57 discriminator 3
	movl	4(%rax), %eax
	.loc 1 1385 57 discriminator 4
	testl	%eax, %eax
	jne	.L677
	.loc 1 1385 57 discriminator 5
	movl	$1, %eax
	jmp	.L678
.L677:
	.loc 1 1385 57 discriminator 6
	movl	$0, %eax
.L678:
	.loc 1 1385 9 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L672
	.loc 1 1386 18
	leaq	silver_library_reports__json_justified(%rip), %rax
	movq	%rax, -1152(%rbp)
	leaq	.LC4(%rip), %rax
	movq	%rax, -1144(%rbp)
	movq	-1152(%rbp), %rax
	movq	-1144(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -112(%rbp)
	.loc 1 1386 18 is_stmt 0 discriminator 1
	leaq	-112(%rbp), %rax
	.loc 1 1386 53 is_stmt 1 discriminator 1
	movl	(%rax), %edx
	.loc 1 1386 53 is_stmt 0 discriminator 2
	testl	%edx, %edx
	jne	.L679
	.loc 1 1386 53 discriminator 3
	movl	4(%rax), %eax
	.loc 1 1386 53 discriminator 4
	testl	%eax, %eax
	jne	.L679
	.loc 1 1386 53 discriminator 5
	movl	$1, %eax
	jmp	.L680
.L679:
	.loc 1 1386 53 discriminator 6
	movl	$0, %eax
.L680:
	.loc 1 1386 9 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L672
	.loc 1 1387 18
	leaq	silver_library_reports__json_suppressed(%rip), %rax
	movq	%rax, -1136(%rbp)
	leaq	.LC19(%rip), %rax
	movq	%rax, -1128(%rbp)
	movq	-1136(%rbp), %rax
	movq	-1128(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -120(%rbp)
	.loc 1 1387 18 is_stmt 0 discriminator 1
	leaq	-120(%rbp), %rax
	.loc 1 1387 54 is_stmt 1 discriminator 1
	movl	(%rax), %edx
	.loc 1 1387 54 is_stmt 0 discriminator 2
	testl	%edx, %edx
	jne	.L681
	.loc 1 1387 54 discriminator 3
	movl	4(%rax), %eax
	.loc 1 1387 54 discriminator 4
	testl	%eax, %eax
	jne	.L681
	.loc 1 1387 54 discriminator 5
	movl	$1, %eax
	jmp	.L682
.L681:
	.loc 1 1387 54 discriminator 6
	movl	$0, %eax
.L682:
	.loc 1 1387 9 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L672
	.loc 1 1388 18
	leaq	silver_library_reports__json_annot_kind(%rip), %rax
	movq	%rax, -1120(%rbp)
	leaq	.LC19(%rip), %rax
	movq	%rax, -1112(%rbp)
	movq	-1120(%rbp), %rax
	movq	-1112(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -128(%rbp)
	.loc 1 1388 18 is_stmt 0 discriminator 1
	leaq	-128(%rbp), %rax
	.loc 1 1388 54 is_stmt 1 discriminator 1
	movl	(%rax), %edx
	.loc 1 1388 54 is_stmt 0 discriminator 2
	testl	%edx, %edx
	jne	.L683
	.loc 1 1388 54 discriminator 3
	movl	4(%rax), %eax
	.loc 1 1388 54 discriminator 4
	testl	%eax, %eax
	jne	.L683
	.loc 1 1388 54 discriminator 5
	movl	$1, %eax
	jmp	.L684
.L683:
	.loc 1 1388 54 discriminator 6
	movl	$0, %eax
.L684:
	.loc 1 1388 9 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L672
	.loc 1 1389 18 discriminator 1
	leaq	silver_library_reports__json_justif_msg(%rip), %rax
	movq	%rax, -1104(%rbp)
	leaq	.LC19(%rip), %rax
	movq	%rax, -1096(%rbp)
	movq	-1104(%rbp), %rax
	movq	-1096(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -136(%rbp)
	.loc 1 1389 18 is_stmt 0 discriminator 2
	leaq	-136(%rbp), %rax
	.loc 1 1389 54 is_stmt 1 discriminator 2
	movl	(%rax), %edx
	.loc 1 1389 54 is_stmt 0 discriminator 3
	testl	%edx, %edx
	jne	.L685
	.loc 1 1389 54 discriminator 4
	movl	4(%rax), %eax
	.loc 1 1389 54 discriminator 5
	testl	%eax, %eax
	jne	.L685
	.loc 1 1389 54 discriminator 6
	movl	$1, %eax
	jmp	.L686
.L685:
	.loc 1 1389 54 discriminator 7
	movl	$0, %eax
.L686:
	.loc 1 1389 9 is_stmt 1 discriminator 8
	testb	%al, %al
	je	.L672
	.loc 1 1389 9 is_stmt 0 discriminator 9
	movl	$1, %eax
	.loc 1 1362 10 is_stmt 1
	jmp	.L723
.L672:
	.loc 1 1389 9 discriminator 10
	movl	$0, %eax
	.loc 1 1362 10
	jmp	.L723
.L671:
	.loc 1 1392 7
	cmpb	$8, -257(%rbp)
	je	.L688
	.loc 1 1392 35 discriminator 1
	cmpb	$9, -257(%rbp)
	je	.L688
	.loc 1 1392 56 discriminator 2
	cmpb	$10, -257(%rbp)
	jne	.L689
.L688:
	.loc 1 1393 17
	leaq	silver_library_reports__atom_vc_postcondition(%rip), %rax
	movq	%rax, -1088(%rbp)
	leaq	.LC10(%rip), %rax
	movq	%rax, -1080(%rbp)
	.loc 1 1393 37
	leaq	silver_library_reports__json_rule(%rip), %rax
	movq	%rax, -1072(%rbp)
	leaq	.LC3(%rip), %rax
	movq	%rax, -1064(%rbp)
	movq	-1072(%rbp), %rax
	movq	-1064(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 1393 17 discriminator 1
	movq	-1088(%rbp), %rsi
	movq	-1080(%rbp), %rdi
	movq	%rsi, %rcx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1394 12
	testb	%al, %al
	je	.L690
.LBB108:
	.loc 1 1395 31
	leaq	silver_library_reports__json_entity(%rip), %rax
	movq	%rax, -1056(%rbp)
	leaq	.LC31(%rip), %rax
	movq	%rax, -1048(%rbp)
	movq	-1056(%rbp), %rax
	movq	-1048(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rcx
	.loc 1 1394 40 discriminator 1
	movq	-256(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__referenced_entity
	movq	%rax, %rdx
.LBE108:
	.loc 1 1394 21 discriminator 2
	movq	-240(%rbp), %rcx
	movq	-232(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__entity_name
	.loc 1 1396 20
	cmpb	$8, -257(%rbp)
	je	.L691
	.loc 1 1397 20
	cmpb	$9, -257(%rbp)
	jne	.L692
	.loc 1 1396 20 discriminator 1
	movl	$3, %edx
	jmp	.L693
.L692:
	.loc 1 1396 20 is_stmt 0 discriminator 2
	movl	$10, %edx
	jmp	.L693
.L691:
	.loc 1 1396 20 discriminator 3
	movl	$2, %edx
.L693:
	.loc 1 1396 17 is_stmt 1 discriminator 4
	cmpb	%al, %dl
	sete	%al
	.loc 1 1394 12 discriminator 4
	testb	%al, %al
	je	.L690
	.loc 1 1394 12 is_stmt 0 discriminator 5
	movl	$1, %eax
	.loc 1 1393 10 is_stmt 1 discriminator 3
	jmp	.L723
.L690:
	.loc 1 1394 12 discriminator 6
	movl	$0, %eax
	.loc 1 1393 10 discriminator 3
	jmp	.L723
.L689:
	.loc 1 1399 14
	leaq	silver_library_reports__json_how_proved(%rip), %rax
	movq	%rax, -1040(%rbp)
	leaq	.LC19(%rip), %rax
	movq	%rax, -1032(%rbp)
	movq	-1040(%rbp), %rax
	movq	-1032(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	.loc 1 1399 11 discriminator 1
	movq	%rax, -56(%rbp)
	.loc 1 1400 7
	cmpb	$1, -257(%rbp)
	jne	.L695
	.loc 1 1401 17
	leaq	silver_library_reports__atom_info(%rip), %rax
	movq	%rax, -1024(%rbp)
	leaq	.LC3(%rip), %r15
	movq	%r15, -1016(%rbp)
	.loc 1 1401 37
	leaq	silver_library_reports__json_severity(%rip), %rax
	movq	%rax, -1008(%rbp)
	leaq	.LC28(%rip), %rax
	movq	%rax, -1000(%rbp)
	movq	-1008(%rbp), %rax
	movq	-1000(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1401 17 discriminator 1
	movq	-1024(%rbp), %r9
	movq	-1016(%rbp), %r10
	movq	%r9, %rdx
	movq	%r10, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1416 12
	testb	%al, %al
	je	.L696
	.loc 1 1402 21
	leaq	silver_library_reports__atom_prover(%rip), %rax
	movq	%rax, -992(%rbp)
	leaq	.LC31(%rip), %rax
	movq	%rax, -984(%rbp)
	movq	-992(%rbp), %rax
	movq	-984(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-56(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1402 12 discriminator 1
	testb	%al, %al
	je	.L696
	.loc 1 1403 22
	leaq	silver_library_reports__atom_vc_range_check(%rip), %rax
	movq	%rax, -976(%rbp)
	leaq	.LC14(%rip), %rax
	movq	%rax, -968(%rbp)
	.loc 1 1403 42
	leaq	silver_library_reports__json_rule(%rip), %r14
	movq	%r14, -960(%rbp)
	movq	%r15, -952(%rbp)
	movq	-960(%rbp), %rax
	movq	-952(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1403 22 discriminator 1
	movq	-976(%rbp), %r11
	movq	-968(%rbp), %r12
	movq	%r11, %rdx
	movq	%r12, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1403 12 discriminator 2
	testb	%al, %al
	jne	.L697
	.loc 1 1404 22
	leaq	silver_library_reports__atom_vc_length_check(%rip), %rax
	movq	%rax, -944(%rbp)
	leaq	.LC29(%rip), %rax
	movq	%rax, -936(%rbp)
	.loc 1 1404 42
	movq	%r14, %r12
	movq	%r14, -928(%rbp)
	movq	%r15, %r13
	movq	%r15, -920(%rbp)
	movq	-928(%rbp), %rax
	movq	-920(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1404 22 discriminator 1
	movq	-944(%rbp), %r14
	movq	-936(%rbp), %r15
	movq	%r14, %rdx
	movq	%r15, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1404 14 discriminator 2
	testb	%al, %al
	jne	.L697
	.loc 1 1405 22
	leaq	silver_library_reports__atom_vc_overflow_check(%rip), %rax
	movq	%rax, -912(%rbp)
	leaq	.LC33(%rip), %rbx
	movq	%rbx, -904(%rbp)
	.loc 1 1405 42
	movq	%r12, %r14
	movq	%r14, -896(%rbp)
	movq	%r13, %r15
	movq	%r15, -888(%rbp)
	movq	-896(%rbp), %rax
	movq	-888(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1405 22 discriminator 1
	movq	-912(%rbp), %r9
	movq	-904(%rbp), %r10
	movq	%r9, %rdx
	movq	%r10, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1405 14 discriminator 2
	testb	%al, %al
	jne	.L697
	.loc 1 1406 22
	leaq	silver_library_reports__atom_vc_division_check(%rip), %rax
	movq	%rax, -880(%rbp)
	movq	%rbx, -872(%rbp)
	.loc 1 1406 42
	movq	%r14, -864(%rbp)
	movq	%r15, -856(%rbp)
	movq	-864(%rbp), %rax
	movq	-856(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1406 22 discriminator 1
	movq	-880(%rbp), %r11
	movq	-872(%rbp), %r12
	movq	%r11, %rdx
	movq	%r12, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1406 14 discriminator 2
	testb	%al, %al
	je	.L696
.L697:
	.loc 1 1407 21
	leaq	silver_library_reports__atom_main_adb(%rip), %rax
	movq	%rax, -848(%rbp)
	leaq	.LC28(%rip), %rax
	movq	%rax, -840(%rbp)
	.loc 1 1407 41
	leaq	silver_library_reports__json_file(%rip), %rax
	movq	%rax, -832(%rbp)
	leaq	.LC3(%rip), %rbx
	movq	%rbx, -824(%rbp)
	movq	-832(%rbp), %rax
	movq	-824(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1407 21 discriminator 1
	movq	-848(%rbp), %r14
	movq	-840(%rbp), %r15
	movq	%r14, %rdx
	movq	%r15, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1407 12 discriminator 2
	testb	%al, %al
	je	.L696
	.loc 1 1408 44
	leaq	silver_library_reports__json_line(%rip), %rax
	movq	%rax, -816(%rbp)
	movq	%rbx, -808(%rbp)
	movq	-816(%rbp), %rax
	movq	-808(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 1408 21 discriminator 1
	movq	-240(%rbp), %rcx
	movq	-232(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__positive_number
	.loc 1 1408 12 discriminator 2
	testb	%al, %al
	je	.L696
	.loc 1 1409 44
	leaq	silver_library_reports__json_col(%rip), %rax
	movq	%rax, -800(%rbp)
	leaq	.LC18(%rip), %rax
	movq	%rax, -792(%rbp)
	movq	-800(%rbp), %rsi
	movq	-792(%rbp), %rdi
	movq	%rsi, %rax
	movq	%rdi, %r8
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rdi
	movq	-232(%rbp), %rsi
	movq	%rax, %rcx
	call	silver_library_reports__field
	.loc 1 1409 21 discriminator 1
	movq	-240(%rbp), %rcx
	movq	-232(%rbp), %rsi
	movq	%rax, %rdx
	movq	%rcx, %rdi
	call	silver_library_reports__positive_number
	.loc 1 1409 12 discriminator 2
	testb	%al, %al
	je	.L696
.LBB109:
	.loc 1 1411 31
	leaq	silver_library_reports__json_entity(%rip), %rax
	movq	%rax, -784(%rbp)
	leaq	.LC31(%rip), %rax
	movq	%rax, -776(%rbp)
	movq	-784(%rbp), %rsi
	movq	-776(%rbp), %rdi
	movq	%rsi, %rax
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %r9
	movq	%rax, %rcx
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%r9, %rsi
	call	silver_library_reports__field
	movq	%rax, %rcx
	.loc 1 1410 40
	movq	-256(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__referenced_entity
	movq	%rax, %rdx
.LBE109:
	.loc 1 1410 21 discriminator 1
	movq	-240(%rbp), %rcx
	movq	-232(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__entity_name
	.loc 1 1411 65 discriminator 1
	cmpb	$17, %al
	sete	%al
	.loc 1 1410 12 discriminator 2
	testb	%al, %al
	je	.L696
	.loc 1 1412 21
	leaq	silver_library_reports__json_justification(%rip), %rax
	movq	%rax, -768(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -760(%rbp)
	movq	-768(%rbp), %rax
	movq	-760(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -144(%rbp)
	.loc 1 1412 21 is_stmt 0 discriminator 1
	leaq	-144(%rbp), %rax
	.loc 1 1412 60 is_stmt 1 discriminator 1
	movl	(%rax), %edx
	.loc 1 1412 60 is_stmt 0 discriminator 2
	testl	%edx, %edx
	jne	.L698
	.loc 1 1412 60 discriminator 3
	movl	4(%rax), %eax
	.loc 1 1412 60 discriminator 4
	testl	%eax, %eax
	jne	.L698
	.loc 1 1412 60 discriminator 5
	movl	$1, %eax
	jmp	.L699
.L698:
	.loc 1 1412 60 discriminator 6
	movl	$0, %eax
.L699:
	.loc 1 1412 12 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L696
	.loc 1 1413 21
	leaq	silver_library_reports__json_justified(%rip), %rax
	movq	%rax, -752(%rbp)
	leaq	.LC4(%rip), %rax
	movq	%rax, -744(%rbp)
	movq	-752(%rbp), %rax
	movq	-744(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -152(%rbp)
	.loc 1 1413 21 is_stmt 0 discriminator 1
	leaq	-152(%rbp), %rax
	.loc 1 1413 56 is_stmt 1 discriminator 1
	movl	(%rax), %edx
	.loc 1 1413 56 is_stmt 0 discriminator 2
	testl	%edx, %edx
	jne	.L700
	.loc 1 1413 56 discriminator 3
	movl	4(%rax), %eax
	.loc 1 1413 56 discriminator 4
	testl	%eax, %eax
	jne	.L700
	.loc 1 1413 56 discriminator 5
	movl	$1, %eax
	jmp	.L701
.L700:
	.loc 1 1413 56 discriminator 6
	movl	$0, %eax
.L701:
	.loc 1 1413 12 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L696
	.loc 1 1414 21
	leaq	silver_library_reports__json_suppressed(%rip), %rax
	movq	%rax, -736(%rbp)
	leaq	.LC19(%rip), %rax
	movq	%rax, -728(%rbp)
	movq	-736(%rbp), %rax
	movq	-728(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -160(%rbp)
	.loc 1 1414 21 is_stmt 0 discriminator 1
	leaq	-160(%rbp), %rax
	.loc 1 1414 57 is_stmt 1 discriminator 1
	movl	(%rax), %edx
	.loc 1 1414 57 is_stmt 0 discriminator 2
	testl	%edx, %edx
	jne	.L702
	.loc 1 1414 57 discriminator 3
	movl	4(%rax), %eax
	.loc 1 1414 57 discriminator 4
	testl	%eax, %eax
	jne	.L702
	.loc 1 1414 57 discriminator 5
	movl	$1, %eax
	jmp	.L703
.L702:
	.loc 1 1414 57 discriminator 6
	movl	$0, %eax
.L703:
	.loc 1 1414 12 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L696
	.loc 1 1415 21
	leaq	silver_library_reports__json_annot_kind(%rip), %rax
	movq	%rax, -720(%rbp)
	leaq	.LC19(%rip), %rax
	movq	%rax, -712(%rbp)
	movq	-720(%rbp), %rax
	movq	-712(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -168(%rbp)
	.loc 1 1415 21 is_stmt 0 discriminator 1
	leaq	-168(%rbp), %rax
	.loc 1 1415 57 is_stmt 1 discriminator 1
	movl	(%rax), %edx
	.loc 1 1415 57 is_stmt 0 discriminator 2
	testl	%edx, %edx
	jne	.L704
	.loc 1 1415 57 discriminator 3
	movl	4(%rax), %eax
	.loc 1 1415 57 discriminator 4
	testl	%eax, %eax
	jne	.L704
	.loc 1 1415 57 discriminator 5
	movl	$1, %eax
	jmp	.L705
.L704:
	.loc 1 1415 57 discriminator 6
	movl	$0, %eax
.L705:
	.loc 1 1415 12 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L696
	.loc 1 1416 21 discriminator 1
	leaq	silver_library_reports__json_justif_msg(%rip), %rax
	movq	%rax, -704(%rbp)
	leaq	.LC19(%rip), %rax
	movq	%rax, -696(%rbp)
	movq	-704(%rbp), %rax
	movq	-696(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -176(%rbp)
	.loc 1 1416 21 is_stmt 0 discriminator 2
	leaq	-176(%rbp), %rax
	.loc 1 1416 57 is_stmt 1 discriminator 2
	movl	(%rax), %edx
	.loc 1 1416 57 is_stmt 0 discriminator 3
	testl	%edx, %edx
	jne	.L706
	.loc 1 1416 57 discriminator 4
	movl	4(%rax), %eax
	.loc 1 1416 57 discriminator 5
	testl	%eax, %eax
	jne	.L706
	.loc 1 1416 57 discriminator 6
	movl	$1, %eax
	jmp	.L707
.L706:
	.loc 1 1416 57 discriminator 7
	movl	$0, %eax
.L707:
	.loc 1 1416 12 is_stmt 1 discriminator 8
	testb	%al, %al
	je	.L696
	.loc 1 1416 12 is_stmt 0 discriminator 9
	movl	$1, %eax
	.loc 1 1401 10 is_stmt 1 discriminator 3
	jmp	.L723
.L696:
	.loc 1 1416 12 discriminator 10
	movl	$0, %eax
	.loc 1 1401 10 discriminator 3
	jmp	.L723
.L695:
	.loc 1 1418 14
	leaq	silver_library_reports__atom_info(%rip), %rax
	movq	%rax, -688(%rbp)
	leaq	.LC3(%rip), %rbx
	movq	%rbx, -680(%rbp)
	.loc 1 1418 34
	leaq	silver_library_reports__json_severity(%rip), %rax
	movq	%rax, -672(%rbp)
	leaq	.LC28(%rip), %rax
	movq	%rax, -664(%rbp)
	movq	-672(%rbp), %rax
	movq	-664(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1418 14 discriminator 1
	movq	-688(%rbp), %r11
	movq	-680(%rbp), %r12
	movq	%r11, %rdx
	movq	%r12, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1436 9
	testb	%al, %al
	je	.L709
	.loc 1 1419 19
	leaq	silver_library_reports__json_flow(%rip), %rax
	movq	%rax, -656(%rbp)
	movq	%rbx, -648(%rbp)
	movq	-656(%rbp), %rax
	movq	-648(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-56(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1419 9 discriminator 1
	testb	%al, %al
	jne	.L710
	.loc 1 1420 19
	leaq	silver_library_reports__atom_prover(%rip), %rax
	movq	%rax, -640(%rbp)
	leaq	.LC31(%rip), %rax
	movq	%rax, -632(%rbp)
	movq	-640(%rbp), %rax
	movq	-632(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-56(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1420 11 discriminator 1
	testb	%al, %al
	jne	.L710
	.loc 1 1421 19
	leaq	silver_library_reports__atom_trivial(%rip), %rax
	movq	%rax, -624(%rbp)
	leaq	.LC27(%rip), %rax
	movq	%rax, -616(%rbp)
	movq	-624(%rbp), %rax
	movq	-616(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-56(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1421 11 discriminator 1
	testb	%al, %al
	je	.L709
.L710:
	.loc 1 1422 18
	leaq	silver_library_reports__json_justification(%rip), %rax
	movq	%rax, -608(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -600(%rbp)
	movq	-608(%rbp), %rax
	movq	-600(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -184(%rbp)
	.loc 1 1422 18 is_stmt 0 discriminator 1
	leaq	-184(%rbp), %rdx
	.loc 1 1422 57 is_stmt 1 discriminator 1
	movl	(%rdx), %eax
	.loc 1 1422 57 is_stmt 0 discriminator 2
	testl	%eax, %eax
	jne	.L711
	.loc 1 1422 57 discriminator 3
	movl	4(%rdx), %eax
	.loc 1 1422 57 discriminator 4
	testl	%eax, %eax
	jne	.L711
	.loc 1 1422 57 discriminator 5
	movl	$1, %eax
	jmp	.L712
.L711:
	.loc 1 1422 57 discriminator 6
	movl	$0, %eax
.L712:
	.loc 1 1422 9 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L709
	.loc 1 1423 18
	leaq	silver_library_reports__json_justified(%rip), %rax
	movq	%rax, -592(%rbp)
	leaq	.LC4(%rip), %rax
	movq	%rax, -584(%rbp)
	movq	-592(%rbp), %rax
	movq	-584(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -192(%rbp)
	.loc 1 1423 18 is_stmt 0 discriminator 1
	leaq	-192(%rbp), %rdx
	.loc 1 1423 53 is_stmt 1 discriminator 1
	movl	(%rdx), %eax
	.loc 1 1423 53 is_stmt 0 discriminator 2
	testl	%eax, %eax
	jne	.L713
	.loc 1 1423 53 discriminator 3
	movl	4(%rdx), %eax
	.loc 1 1423 53 discriminator 4
	testl	%eax, %eax
	jne	.L713
	.loc 1 1423 53 discriminator 5
	movl	$1, %eax
	jmp	.L714
.L713:
	.loc 1 1423 53 discriminator 6
	movl	$0, %eax
.L714:
	.loc 1 1423 9 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L709
	.loc 1 1424 18
	leaq	silver_library_reports__json_suppressed(%rip), %rax
	movq	%rax, -576(%rbp)
	leaq	.LC19(%rip), %rax
	movq	%rax, -568(%rbp)
	movq	-576(%rbp), %rax
	movq	-568(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -200(%rbp)
	.loc 1 1424 18 is_stmt 0 discriminator 1
	leaq	-200(%rbp), %rdx
	.loc 1 1424 54 is_stmt 1 discriminator 1
	movl	(%rdx), %eax
	.loc 1 1424 54 is_stmt 0 discriminator 2
	testl	%eax, %eax
	jne	.L715
	.loc 1 1424 54 discriminator 3
	movl	4(%rdx), %eax
	.loc 1 1424 54 discriminator 4
	testl	%eax, %eax
	jne	.L715
	.loc 1 1424 54 discriminator 5
	movl	$1, %eax
	jmp	.L716
.L715:
	.loc 1 1424 54 discriminator 6
	movl	$0, %eax
.L716:
	.loc 1 1424 9 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L709
	.loc 1 1425 18
	leaq	silver_library_reports__json_annot_kind(%rip), %rax
	movq	%rax, -560(%rbp)
	leaq	.LC19(%rip), %rax
	movq	%rax, -552(%rbp)
	movq	-560(%rbp), %rax
	movq	-552(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -208(%rbp)
	.loc 1 1425 18 is_stmt 0 discriminator 1
	leaq	-208(%rbp), %rdx
	.loc 1 1425 54 is_stmt 1 discriminator 1
	movl	(%rdx), %eax
	.loc 1 1425 54 is_stmt 0 discriminator 2
	testl	%eax, %eax
	jne	.L717
	.loc 1 1425 54 discriminator 3
	movl	4(%rdx), %eax
	.loc 1 1425 54 discriminator 4
	testl	%eax, %eax
	jne	.L717
	.loc 1 1425 54 discriminator 5
	movl	$1, %eax
	jmp	.L718
.L717:
	.loc 1 1425 54 discriminator 6
	movl	$0, %eax
.L718:
	.loc 1 1425 9 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L709
	.loc 1 1426 18
	leaq	silver_library_reports__json_justif_msg(%rip), %rax
	movq	%rax, -544(%rbp)
	leaq	.LC19(%rip), %rax
	movq	%rax, -536(%rbp)
	movq	-544(%rbp), %rax
	movq	-536(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -216(%rbp)
	.loc 1 1426 18 is_stmt 0 discriminator 1
	leaq	-216(%rbp), %rdx
	.loc 1 1426 54 is_stmt 1 discriminator 1
	movl	(%rdx), %eax
	.loc 1 1426 54 is_stmt 0 discriminator 2
	testl	%eax, %eax
	jne	.L719
	.loc 1 1426 54 discriminator 3
	movl	4(%rdx), %eax
	.loc 1 1426 54 discriminator 4
	testl	%eax, %eax
	jne	.L719
	.loc 1 1426 54 discriminator 5
	movl	$1, %eax
	jmp	.L720
.L719:
	.loc 1 1426 54 discriminator 6
	movl	$0, %eax
.L720:
	.loc 1 1426 9 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L709
	.loc 1 1427 41
	leaq	silver_library_reports__json_rule(%rip), %rax
	movq	%rax, -528(%rbp)
	leaq	.LC3(%rip), %r13
	movq	%r13, -520(%rbp)
	movq	-528(%rbp), %rax
	movq	-520(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 1427 18 discriminator 1
	movq	-240(%rbp), %rcx
	movq	-232(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__nonempty_string
	.loc 1 1427 9 discriminator 2
	testb	%al, %al
	je	.L709
	.loc 1 1428 19
	leaq	silver_library_reports__atom_silver_io_ads(%rip), %rax
	movq	%rax, -512(%rbp)
	leaq	.LC6(%rip), %rbx
	movq	%rbx, -504(%rbp)
	.loc 1 1428 39
	leaq	silver_library_reports__json_file(%rip), %r14
	movq	%r14, -496(%rbp)
	movq	%r13, -488(%rbp)
	movq	-496(%rbp), %rax
	movq	-488(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1428 19 discriminator 1
	movq	-512(%rbp), %r9
	movq	-504(%rbp), %r10
	movq	%r9, %rdx
	movq	%r10, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1428 9 discriminator 2
	testb	%al, %al
	jne	.L721
	.loc 1 1429 19
	leaq	silver_library_reports__atom_silver_io_adb(%rip), %rax
	movq	%rax, -480(%rbp)
	movq	%rbx, -472(%rbp)
	.loc 1 1429 39
	movq	%r14, -464(%rbp)
	movq	%r13, -456(%rbp)
	movq	-464(%rbp), %rax
	movq	-456(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1429 19 discriminator 1
	movq	-480(%rbp), %r11
	movq	-472(%rbp), %r12
	movq	%r11, %rdx
	movq	%r12, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1429 11 discriminator 2
	testb	%al, %al
	jne	.L721
	.loc 1 1430 19
	leaq	silver_library_reports__atom_silver_output_libc_ads(%rip), %rax
	movq	%rax, -448(%rbp)
	leaq	.LC34(%rip), %rax
	movq	%rax, -440(%rbp)
	.loc 1 1430 39
	movq	%r14, %r12
	movq	%r14, -432(%rbp)
	movq	%r13, -424(%rbp)
	movq	-432(%rbp), %rax
	movq	-424(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1430 19 discriminator 1
	movq	-448(%rbp), %r14
	movq	-440(%rbp), %r15
	movq	%r14, %rdx
	movq	%r15, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1430 11 discriminator 2
	testb	%al, %al
	jne	.L721
	.loc 1 1431 19
	leaq	silver_library_reports__atom_silver_arguments_ads(%rip), %rax
	movq	%rax, -416(%rbp)
	leaq	.LC35(%rip), %rbx
	movq	%rbx, -408(%rbp)
	.loc 1 1431 39
	movq	%r12, %r14
	movq	%r14, -400(%rbp)
	movq	%r13, %r15
	movq	%r15, -392(%rbp)
	movq	-400(%rbp), %rax
	movq	-392(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 1431 19 discriminator 1
	movq	-416(%rbp), %r9
	movq	-408(%rbp), %r10
	movq	%r9, %rdx
	movq	%r10, %r8
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1431 11 discriminator 2
	testb	%al, %al
	jne	.L721
	.loc 1 1432 19
	leaq	silver_library_reports__atom_silver_arguments_adb(%rip), %rax
	movq	%rax, -384(%rbp)
	movq	%rbx, -376(%rbp)
	.loc 1 1432 39
	movq	%r14, -368(%rbp)
	movq	%r15, -360(%rbp)
	movq	-368(%rbp), %rsi
	movq	-360(%rbp), %rdi
	movq	%rsi, %rax
	movq	%rdi, %r8
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rdi
	movq	-232(%rbp), %rsi
	movq	%rax, %rcx
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 1432 19 discriminator 1
	movq	-384(%rbp), %rsi
	movq	-376(%rbp), %rdi
	movq	%rsi, %rax
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %r9
	movq	%rax, %rcx
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%r9, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1432 11 discriminator 2
	testb	%al, %al
	jne	.L721
	.loc 1 1433 19
	leaq	silver_library_reports__atom_silver_runtime_ads(%rip), %rax
	movq	%rax, -352(%rbp)
	leaq	.LC5(%rip), %rax
	movq	%rax, -344(%rbp)
	.loc 1 1433 39
	movq	%r14, -336(%rbp)
	movq	%r15, -328(%rbp)
	movq	-336(%rbp), %rax
	movq	-328(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 1433 19 discriminator 1
	movq	-352(%rbp), %rsi
	movq	-344(%rbp), %rdi
	movq	%rsi, %rcx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 1433 11 discriminator 2
	testb	%al, %al
	je	.L709
.L721:
	.loc 1 1434 41
	leaq	silver_library_reports__json_line(%rip), %rax
	movq	%rax, -320(%rbp)
	leaq	.LC3(%rip), %rax
	movq	%rax, -312(%rbp)
	movq	-320(%rbp), %rax
	movq	-312(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 1434 18 discriminator 1
	movq	-240(%rbp), %rcx
	movq	-232(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__positive_number
	.loc 1 1434 9 discriminator 2
	testb	%al, %al
	je	.L709
	.loc 1 1435 41
	leaq	silver_library_reports__json_col(%rip), %rax
	movq	%rax, -304(%rbp)
	leaq	.LC18(%rip), %rax
	movq	%rax, -296(%rbp)
	movq	-304(%rbp), %rax
	movq	-296(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 1435 18 discriminator 1
	movq	-240(%rbp), %rcx
	movq	-232(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__positive_number
	.loc 1 1435 9 discriminator 2
	testb	%al, %al
	je	.L709
.LBB110:
	.loc 1 1437 28
	leaq	silver_library_reports__json_entity(%rip), %rax
	movq	%rax, -288(%rbp)
	leaq	.LC31(%rip), %rax
	movq	%rax, -280(%rbp)
	movq	-288(%rbp), %rax
	movq	-280(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-248(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rcx
	.loc 1 1436 37 discriminator 1
	movq	-256(%rbp), %rdx
	movq	-240(%rbp), %rsi
	movq	-232(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__referenced_entity
	movq	%rax, %rdx
.LBE110:
	.loc 1 1436 18 discriminator 2
	movq	-240(%rbp), %rcx
	movq	-232(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__entity_name
	.loc 1 1437 62 discriminator 1
	testb	%al, %al
	setne	%al
	.loc 1 1436 9 discriminator 3
	testb	%al, %al
	je	.L709
	.loc 1 1436 9 is_stmt 0 discriminator 4
	movl	$1, %eax
	.loc 1 1418 7 is_stmt 1 discriminator 3
	jmp	.L724
.L709:
	.loc 1 1436 9 discriminator 5
	movl	$0, %eax
.L724:
	.loc 1 1418 7 discriminator 3
	nop
.L723:
.LBE97:
	.loc 1 1438 8
	addq	$1912, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE31:
	.size	silver_library_reports__record_ok, .-silver_library_reports__record_ok
	.align 2
	.globl	silver_library_reports__list_summaryIP
	.type	silver_library_reports__list_summaryIP, @function
silver_library_reports__list_summaryIP:
.LFB32:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE32:
	.size	silver_library_reports__list_summaryIP, .-silver_library_reports__list_summaryIP
	.section	.rodata
	.align 8
.LC74:
	.ascii	"failed precondition from silver_library_reports.adb:1492"
	.align 8
.LC75:
	.ascii	"Loop_Invariant failed at silver_library_reports.adb:1504"
	.align 8
.LC76:
	.ascii	"Loop_Variant failed at silver_library_reports.adb:1508"
	.align 8
.LC36:
	.long	1
	.long	54
	.text
	.align 2
	.type	silver_library_reports__list_ok, @function
silver_library_reports__list_ok:
.LFB33:
	.loc 1 1490 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$184, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r9
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r9, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movq	%rdx, -104(%rbp)
	movq	%rcx, -112(%rbp)
	movb	%r8b, -113(%rbp)
	.loc 1 1490 4
	movq	-88(%rbp), %rax
	movl	(%rax), %r12d
	movq	-88(%rbp), %rax
	movl	4(%rax), %r13d
	cmpl	%r12d, %r13d
	jl	.L727
	.loc 1 1490 4 is_stmt 0 discriminator 1
	movslq	%r13d, %rax
	cqto
	movslq	%r12d, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %r14
	movq	%rdx, %r15
	jmp	.L728
.L727:
	.loc 1 1490 4 discriminator 2
	movl	$0, %r14d
	movl	$0, %r15d
.L728:
.LBB111:
	.loc 1 1490 4 discriminator 3
	movslq	%r12d, %rbx
	cmpl	%r12d, %r13d
	.loc 1 1490 4 discriminator 6
	cmpl	%r12d, %r13d
	.loc 1 1490 4 discriminator 9
	cmpl	%r12d, %r13d
	.loc 1 1492 18 is_stmt 1
	cmpl	$1, %r12d
	je	.L735
.LBB112:
	.loc 1 1492 18 is_stmt 0 discriminator 1
	leaq	.LC74(%rip), %r10
	leaq	.LC2(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L735:
.LBE112:
	.loc 1 1492 54 is_stmt 1 discriminator 2
	movslq	%r12d, %rax
	leaq	16777215(%rax), %rdx
	movslq	%r13d, %rax
	.loc 1 1492 18 discriminator 2
	cmpq	%rax, %rdx
	jge	.L736
.LBB113:
	.loc 1 1492 18 is_stmt 0 discriminator 3
	leaq	.LC74(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC2(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L736:
.LBE113:
	.loc 1 1496 7 is_stmt 1
	leaq	-80(%rbp), %rax
	movq	%rax, %rdi
	call	silver_library_reports__memberIP
	.loc 1 1497 7
	movb	$0, -53(%rbp)
	.loc 1 1499 14
	movq	-104(%rbp), %rdx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__valid
	.loc 1 1499 10 discriminator 1
	xorl	$1, %eax
	.loc 1 1499 7 discriminator 1
	testb	%al, %al
	jne	.L737
	.loc 1 1499 42 discriminator 2
	movl	-104(%rbp), %eax
	cmpl	%eax, %r12d
	jg	.L738
	.loc 1 1499 42 is_stmt 0 discriminator 3
	movl	-104(%rbp), %eax
	cmpl	%eax, %r13d
	jge	.L739
.L738:
	.loc 1 1499 42 discriminator 4
	leaq	.LC39(%rip), %rax
	movl	$1499, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L739:
	.loc 1 1499 61 is_stmt 1 discriminator 5
	movq	-96(%rbp), %rax
	movl	-104(%rbp), %edx
	movslq	%edx, %rdx
	subq	%rbx, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 1499 61 is_stmt 0 discriminator 6
	cmpb	$91, %al
	setne	%al
	.loc 1 1499 34 is_stmt 1 discriminator 6
	testb	%al, %al
	jne	.L737
	.loc 1 1500 17
	movl	-100(%rbp), %eax
	cmpl	%eax, %r12d
	jg	.L740
	.loc 1 1500 17 is_stmt 0 discriminator 1
	movl	-100(%rbp), %eax
	cmpl	%eax, %r13d
	jge	.L741
.L740:
	.loc 1 1500 17 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1500, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L741:
	.loc 1 1500 35 is_stmt 1 discriminator 3
	movq	-96(%rbp), %rax
	movl	-100(%rbp), %edx
	movslq	%edx, %rdx
	subq	%rbx, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 1500 35 is_stmt 0 discriminator 4
	cmpb	$93, %al
	setne	%al
	.loc 1 1500 9 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L742
.L737:
	.loc 1 1501 12
	movl	$0, %eax
	jmp	.L767
.L742:
	.loc 1 1502 24
	movl	-104(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L744
	.loc 1 1502 24 is_stmt 0 discriminator 1
	cmpl	$16777217, %eax
	jle	.L745
.L744:
	.loc 1 1502 24 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1502, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L745:
	.loc 1 1502 9 is_stmt 1 discriminator 3
	movl	%eax, -52(%rbp)
	.loc 1 1503 7
	movl	$0, %ebx
.L766:
.LBB114:
	.loc 1 1504 35
	movl	-104(%rbp), %eax
	.loc 1 1504 33
	cmpl	%eax, -52(%rbp)
	jle	.L746
	.loc 1 1504 69 discriminator 1
	movl	%r14d, %eax
	cmpl	$2147483647, %eax
	jne	.L747
	.loc 1 1504 69 is_stmt 0 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1504, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L747:
	.loc 1 1504 69 discriminator 4
	movl	%r14d, %eax
	addl	$1, %eax
	.loc 1 1504 35 is_stmt 1 discriminator 5
	cmpl	-52(%rbp), %eax
	jge	.L748
.L746:
.LBB115:
	.loc 1 1504 33 discriminator 6
	leaq	.LC75(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC2(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L748:
.LBE115:
	.loc 1 1508 10
	testb	%bl, %bl
	je	.L749
	.loc 1 1508 44 discriminator 1
	movl	-212(%rbp), %eax
	movl	%eax, -216(%rbp)
.L749:
	.loc 1 1508 44 is_stmt 0 discriminator 2
	movl	-52(%rbp), %eax
	movl	%eax, -212(%rbp)
	.loc 1 1508 10 is_stmt 1 discriminator 2
	testb	%bl, %bl
	je	.L750
	.loc 1 1508 44 discriminator 3
	movl	-216(%rbp), %ecx
	cmpl	%ecx, %eax
	jg	.L751
.LBB116:
	.loc 1 1508 44 is_stmt 0 discriminator 4
	leaq	.LC76(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC36(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L750:
.LBE116:
	.loc 1 1508 10 is_stmt 1 discriminator 5
	movl	$1, %ebx
.L751:
	.loc 1 1509 15
	leaq	-160(%rbp), %rax
	movl	-52(%rbp), %edi
	movq	-104(%rbp), %rcx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rdx
	movl	%edi, %r8d
	movq	%rax, %rdi
	call	silver_library_reports__read_item
	movq	-160(%rbp), %rax
	movq	-152(%rbp), %rdx
	movq	%rax, -80(%rbp)
	movq	%rdx, -72(%rbp)
	movq	-144(%rbp), %rax
	movq	%rax, -64(%rbp)
	.loc 1 1510 16
	movzbl	-80(%rbp), %eax
	cmpb	$2, %al
	jbe	.L752
	.loc 1 1510 16 is_stmt 0 discriminator 1
	leaq	.LC39(%rip), %rax
	movl	$1510, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L752:
	.loc 1 1510 10 is_stmt 1 discriminator 2
	testb	%al, %al
	je	.L753
	cmpb	$1, %al
	je	.L754
	jmp	.L768
.L753:
	.loc 1 1511 28
	movl	$0, %eax
	jmp	.L767
.L754:
	.loc 1 1513 97
	cmpb	$8, -113(%rbp)
	je	.L756
	.loc 1 1513 52 discriminator 1
	cmpb	$9, -113(%rbp)
	je	.L756
	.loc 1 1513 73 discriminator 2
	cmpb	$10, -113(%rbp)
	jne	.L757
.L756:
	.loc 1 1513 97 discriminator 3
	cmpb	$0, -53(%rbp)
	je	.L758
.L757:
	.loc 1 1513 97 is_stmt 0 discriminator 4
	movl	$1, %eax
	.loc 1 1513 16 is_stmt 1 discriminator 6
	jmp	.L767
.L758:
	.loc 1 1513 97 discriminator 5
	movl	$0, %eax
	.loc 1 1513 16 discriminator 6
	jmp	.L767
.L768:
.LBB117:
	.loc 1 1515 16
	cmpb	$8, -113(%rbp)
	je	.L760
	.loc 1 1515 44 discriminator 1
	cmpb	$9, -113(%rbp)
	je	.L760
	.loc 1 1515 65 discriminator 2
	cmpb	$10, -113(%rbp)
	jne	.L761
.L760:
	.loc 1 1516 34
	cmpb	$0, -53(%rbp)
	jne	.L762
	.loc 1 1516 42 discriminator 1
	movzbl	-113(%rbp), %edi
	movq	-112(%rbp), %rcx
	movq	-68(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__record_ok
	.loc 1 1516 34 discriminator 2
	testb	%al, %al
	je	.L763
.L762:
	.loc 1 1516 34 is_stmt 0 discriminator 3
	movl	$1, %eax
	jmp	.L764
.L763:
	.loc 1 1516 34 discriminator 4
	movl	$0, %eax
.L764:
	.loc 1 1516 25 is_stmt 1 discriminator 5
	movb	%al, -53(%rbp)
	jmp	.L765
.L761:
	.loc 1 1517 26
	movzbl	-113(%rbp), %edi
	movq	-112(%rbp), %rcx
	movq	-68(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__record_ok
	.loc 1 1517 26 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 1 1517 16 is_stmt 1 discriminator 1
	testb	%al, %al
	je	.L765
	.loc 1 1518 19
	movl	$0, %eax
	jmp	.L767
.L765:
	.loc 1 1520 18
	movl	-60(%rbp), %eax
	movl	%eax, -52(%rbp)
.LBE117:
	.loc 1 1521 14
	nop
.LBE114:
	.loc 1 1522 15
	jmp	.L766
.L767:
.LBE111:
	.loc 1 1523 8
	addq	$184, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE33:
	.size	silver_library_reports__list_ok, .-silver_library_reports__list_ok
	.section	.rodata
	.align 8
.LC77:
	.ascii	"failed precondition from silver_library_reports.adb:1557"
	.align 8
.LC78:
	.ascii	"Loop_Invariant failed at silver_library_reports.adb:1568"
	.align 8
.LC79:
	.ascii	"Loop_Variant failed at silver_library_reports.adb:1572"
	.align 8
.LC37:
	.long	1
	.long	5
	.text
	.align 2
	.type	silver_library_reports__dependencies_ok, @function
silver_library_reports__dependencies_ok:
.LFB34:
	.loc 1 1555 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$200, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movq	%rdx, -104(%rbp)
	movq	%rcx, -112(%rbp)
	.loc 1 1555 4
	movq	-88(%rbp), %rax
	movl	(%rax), %r12d
	movq	-88(%rbp), %rax
	movl	4(%rax), %r13d
	cmpl	%r12d, %r13d
	jl	.L770
	.loc 1 1555 4 is_stmt 0 discriminator 1
	movslq	%r13d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r12d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, -160(%rbp)
	movq	%rdx, -152(%rbp)
	jmp	.L771
.L770:
	.loc 1 1555 4 discriminator 2
	movq	$0, -160(%rbp)
	movq	$0, -152(%rbp)
.L771:
.LBB118:
	.loc 1 1555 4 discriminator 3
	movslq	%r12d, %rbx
	cmpl	%r12d, %r13d
	.loc 1 1555 4 discriminator 6
	cmpl	%r12d, %r13d
	.loc 1 1555 4 discriminator 9
	cmpl	%r12d, %r13d
	.loc 1 1557 18 is_stmt 1
	cmpl	$1, %r12d
	je	.L778
.LBB119:
	.loc 1 1557 18 is_stmt 0 discriminator 1
	leaq	.LC77(%rip), %r10
	leaq	.LC2(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L778:
.LBE119:
	.loc 1 1557 54 is_stmt 1 discriminator 2
	movslq	%r12d, %rax
	leaq	16777215(%rax), %rdx
	movslq	%r13d, %rax
	.loc 1 1557 18 discriminator 2
	cmpq	%rax, %rdx
	jge	.L779
.LBB120:
	.loc 1 1557 18 is_stmt 0 discriminator 3
	leaq	.LC77(%rip), %r14
	leaq	.LC2(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L779:
.LBE120:
	.loc 1 1561 7 is_stmt 1
	leaq	-80(%rbp), %rax
	movq	%rax, %rdi
	call	silver_library_reports__memberIP
	.loc 1 1563 14
	movq	-104(%rbp), %rdx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__valid
	.loc 1 1563 10 discriminator 1
	xorl	$1, %eax
	.loc 1 1563 7 discriminator 1
	testb	%al, %al
	jne	.L780
	.loc 1 1563 42 discriminator 2
	movl	-104(%rbp), %eax
	cmpl	%eax, %r12d
	jg	.L781
	.loc 1 1563 42 is_stmt 0 discriminator 3
	movl	-104(%rbp), %eax
	cmpl	%eax, %r13d
	jge	.L782
.L781:
	.loc 1 1563 42 discriminator 4
	leaq	.LC39(%rip), %rax
	movl	$1563, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L782:
	.loc 1 1563 61 is_stmt 1 discriminator 5
	movq	-96(%rbp), %rdx
	movl	-104(%rbp), %eax
	cltq
	subq	%rbx, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 1 1563 61 is_stmt 0 discriminator 6
	cmpb	$91, %al
	setne	%al
	.loc 1 1563 34 is_stmt 1 discriminator 6
	testb	%al, %al
	jne	.L780
	.loc 1 1564 17
	movl	-100(%rbp), %eax
	cmpl	%eax, %r12d
	jg	.L783
	.loc 1 1564 17 is_stmt 0 discriminator 1
	movl	-100(%rbp), %eax
	cmpl	%eax, %r13d
	jge	.L784
.L783:
	.loc 1 1564 17 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1564, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L784:
	.loc 1 1564 35 is_stmt 1 discriminator 3
	movq	-96(%rbp), %rdx
	movl	-100(%rbp), %eax
	cltq
	subq	%rbx, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 1 1564 35 is_stmt 0 discriminator 4
	cmpb	$93, %al
	setne	%al
	.loc 1 1564 9 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L785
.L780:
	.loc 1 1565 12
	movl	$0, %eax
	jmp	.L802
.L785:
	.loc 1 1566 24
	movl	-104(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L787
	.loc 1 1566 24 is_stmt 0 discriminator 1
	cmpl	$16777217, %eax
	jle	.L788
.L787:
	.loc 1 1566 24 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1566, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L788:
	.loc 1 1566 9 is_stmt 1 discriminator 3
	movl	%eax, -52(%rbp)
	.loc 1 1567 7
	movl	$0, %ebx
.L801:
.LBB121:
	.loc 1 1568 35
	movl	-104(%rbp), %eax
	.loc 1 1568 33
	cmpl	%eax, -52(%rbp)
	jle	.L789
	.loc 1 1568 69 discriminator 1
	movl	-160(%rbp), %eax
	cmpl	$2147483647, %eax
	jne	.L790
	.loc 1 1568 69 is_stmt 0 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1568, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L790:
	.loc 1 1568 69 discriminator 4
	movl	-160(%rbp), %eax
	addl	$1, %eax
	.loc 1 1568 35 is_stmt 1 discriminator 5
	cmpl	-52(%rbp), %eax
	jge	.L791
.L789:
.LBB122:
	.loc 1 1568 33 discriminator 6
	leaq	.LC78(%rip), %rax
	movq	%rax, -224(%rbp)
	leaq	.LC2(%rip), %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rbx
	movq	-216(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L791:
.LBE122:
	.loc 1 1572 10
	testb	%bl, %bl
	je	.L792
	.loc 1 1572 44 discriminator 1
	movl	-228(%rbp), %eax
	movl	%eax, -232(%rbp)
.L792:
	.loc 1 1572 44 is_stmt 0 discriminator 2
	movl	-52(%rbp), %eax
	movl	%eax, -228(%rbp)
	.loc 1 1572 10 is_stmt 1 discriminator 2
	testb	%bl, %bl
	je	.L793
	.loc 1 1572 44 discriminator 3
	movl	-232(%rbp), %ecx
	cmpl	%ecx, %eax
	jg	.L794
.LBB123:
	.loc 1 1572 44 is_stmt 0 discriminator 4
	leaq	.LC79(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC36(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L793:
.LBE123:
	.loc 1 1572 10 is_stmt 1 discriminator 5
	movl	$1, %ebx
.L794:
	.loc 1 1573 15
	leaq	-144(%rbp), %rdi
	movl	-52(%rbp), %esi
	movq	-104(%rbp), %rcx
	movq	-96(%rbp), %rdx
	movq	-88(%rbp), %rax
	movl	%esi, %r8d
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_library_reports__read_item
	movq	-144(%rbp), %rax
	movq	-136(%rbp), %rdx
	movq	%rax, -80(%rbp)
	movq	%rdx, -72(%rbp)
	movq	-128(%rbp), %rax
	movq	%rax, -64(%rbp)
	.loc 1 1574 16
	movzbl	-80(%rbp), %eax
	cmpb	$2, %al
	jbe	.L795
	.loc 1 1574 16 is_stmt 0 discriminator 1
	leaq	.LC39(%rip), %rax
	movl	$1574, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L795:
	.loc 1 1574 10 is_stmt 1 discriminator 2
	testb	%al, %al
	je	.L796
	cmpb	$1, %al
	je	.L797
	jmp	.L803
.L796:
	.loc 1 1575 28
	movl	$0, %eax
	jmp	.L802
.L797:
	.loc 1 1576 30
	movl	$1, %eax
	jmp	.L802
.L803:
.LBB124:
	.loc 1 1578 53
	leaq	silver_library_reports__json_claim(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC37(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rax
	movq	-184(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-68(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	.loc 1 1578 23 discriminator 1
	movq	-112(%rbp), %rdx
	movq	-96(%rbp), %rdi
	movq	-88(%rbp), %rsi
	movq	%rax, %rcx
	call	silver_library_reports__reference_ok
	.loc 1 1578 19 discriminator 2
	xorl	$1, %eax
	.loc 1 1578 16 discriminator 2
	testb	%al, %al
	jne	.L799
	.loc 1 1580 27
	leaq	silver_library_reports__json_assumptions(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC20(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rax
	movq	-168(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-68(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 1579 30
	movq	-112(%rbp), %rax
	movq	-96(%rbp), %rdi
	movq	-88(%rbp), %rsi
	movl	$7, %r8d
	movq	%rax, %rcx
	call	silver_library_reports__list_ok
	.loc 1 1579 26 discriminator 1
	xorl	$1, %eax
	.loc 1 1579 18 discriminator 1
	testb	%al, %al
	je	.L800
.L799:
	.loc 1 1581 21
	movl	$0, %eax
	jmp	.L802
.L800:
	.loc 1 1582 18
	movl	-60(%rbp), %eax
	movl	%eax, -52(%rbp)
.LBE124:
	.loc 1 1583 14
	nop
.LBE121:
	.loc 1 1584 15
	jmp	.L801
.L802:
.LBE118:
	.loc 1 1585 8
	addq	$200, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE34:
	.size	silver_library_reports__dependencies_ok, .-silver_library_reports__dependencies_ok
	.align 2
	.globl	silver_library_reports__Tentity_setBIP
	.type	silver_library_reports__Tentity_setBIP, @function
silver_library_reports__Tentity_setBIP:
.LFB35:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE35:
	.size	silver_library_reports__Tentity_setBIP, .-silver_library_reports__Tentity_setBIP
	.align 2
	.globl	silver_library_reports__remember
	.type	silver_library_reports__remember, @function
silver_library_reports__remember:
.LFB36:
	.loc 1 1633 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -40(%rbp)
	movq	%rsi, -48(%rbp)
	movb	%dl, -49(%rbp)
	.loc 1 1639 14
	movq	-48(%rbp), %rcx
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -32(%rbp)
	movq	%rdx, -24(%rbp)
	movzwl	16(%rcx), %eax
	movw	%ax, -16(%rbp)
	.loc 1 1639 31
	movzbl	-49(%rbp), %eax
	movb	$1, -32(%rbp,%rax)
	.loc 1 1639 7 discriminator 1
	movq	-40(%rbp), %rcx
	movq	-32(%rbp), %rax
	movq	-24(%rbp), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movzwl	-16(%rbp), %eax
	movw	%ax, 16(%rcx)
	.loc 1 1640 8
	movq	-40(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE36:
	.size	silver_library_reports__remember, .-silver_library_reports__remember
	.align 2
	.globl	silver_library_reports__entity_summaryIP
	.type	silver_library_reports__entity_summaryIP, @function
silver_library_reports__entity_summaryIP:
.LFB37:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE37:
	.size	silver_library_reports__entity_summaryIP, .-silver_library_reports__entity_summaryIP
	.align 2
	.type	silver_library_reports__map_ok__L_9__B1016b___finalizer.2, @function
silver_library_reports__map_ok__L_9__B1016b___finalizer.2:
.LFB39:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	addq	$24, %rax
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE39:
	.size	silver_library_reports__map_ok__L_9__B1016b___finalizer.2, .-silver_library_reports__map_ok__L_9__B1016b___finalizer.2
	.section	.rodata
	.align 8
.LC80:
	.ascii	"failed precondition from silver_library_reports.adb:1751"
	.align 8
.LC81:
	.ascii	"Loop_Invariant failed at silver_library_reports.adb:1764"
	.align 8
.LC82:
	.ascii	"Loop_Variant failed at silver_library_reports.adb:1768"
	.text
	.align 2
	.type	silver_library_reports__map_ok, @function
silver_library_reports__map_ok:
.LFB38:
	.loc 1 1749 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA38
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB10:
	subq	$392, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r10
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r10, %rdi
	movq	%rsi, -224(%rbp)
	movq	%rdi, -216(%rbp)
	movq	%rdx, -232(%rbp)
	movq	%rcx, -240(%rbp)
	movb	%r8b, -241(%rbp)
	movb	%r9b, -242(%rbp)
	.loc 1 1749 4
	leaq	16(%rbp), %rax
	.loc 1 1749 4 is_stmt 0 discriminator 1
	movq	%rax, -80(%rbp)
	movq	-216(%rbp), %rax
	movl	(%rax), %edx
	movl	%edx, -292(%rbp)
	movq	-216(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -296(%rbp)
	cmpl	%edx, %eax
	jl	.L813
	.loc 1 1749 4 discriminator 2
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%edx, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, -320(%rbp)
	movq	%rdx, -312(%rbp)
	jmp	.L814
.L813:
	.loc 1 1749 4 discriminator 3
	movq	$0, -320(%rbp)
	movq	$0, -312(%rbp)
.L814:
.LBB125:
	.loc 1 1749 4 discriminator 4
	movl	-292(%rbp), %eax
	movslq	%eax, %rbx
	movq	%rbx, -304(%rbp)
	movl	-296(%rbp), %ebx
	cmpl	%eax, %ebx
	.loc 1 1749 4 discriminator 7
	cmpl	%eax, %ebx
	.loc 1 1749 4 discriminator 10
	cmpl	%eax, %ebx
	.loc 1 1751 18 is_stmt 1
	cmpl	$1, %eax
	je	.L821
.LBB126:
	.loc 1 1751 18 is_stmt 0 discriminator 1
	leaq	.LC80(%rip), %r12
	leaq	.LC2(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L821:
.LBE126:
	.loc 1 1751 54 is_stmt 1 discriminator 2
	movslq	-292(%rbp), %rax
	leaq	16777215(%rax), %rdx
	movslq	-296(%rbp), %rax
	.loc 1 1751 18 discriminator 2
	cmpq	%rax, %rdx
	jge	.L822
.LBB127:
	.loc 1 1751 18 is_stmt 0 discriminator 3
	leaq	.LC80(%rip), %r14
	leaq	.LC2(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L822:
.LBE127:
	.loc 1 1754 7 is_stmt 1
	pxor	%xmm0, %xmm0
	movaps	%xmm0, -160(%rbp)
	movd	%xmm0, %eax
	movw	%ax, -144(%rbp)
	.loc 1 1756 7
	leaq	-192(%rbp), %rax
	movq	%rax, %rdi
	call	silver_library_reports__memberIP
	.loc 1 1759 14
	movq	-232(%rbp), %rdx
	movq	-224(%rbp), %rcx
	movq	-216(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__valid
	.loc 1 1759 10 discriminator 1
	xorl	$1, %eax
	.loc 1 1759 7 discriminator 1
	testb	%al, %al
	jne	.L823
	.loc 1 1759 42 discriminator 2
	movl	-232(%rbp), %eax
	cmpl	%eax, -292(%rbp)
	jg	.L824
	.loc 1 1759 42 is_stmt 0 discriminator 3
	movl	-232(%rbp), %eax
	cmpl	%eax, -296(%rbp)
	jge	.L825
.L824:
	.loc 1 1759 42 discriminator 4
	leaq	.LC39(%rip), %rax
	movl	$1759, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L825:
	.loc 1 1759 61 is_stmt 1 discriminator 5
	movq	-224(%rbp), %rdx
	movl	-232(%rbp), %eax
	cltq
	movq	-304(%rbp), %rbx
	subq	%rbx, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 1 1759 61 is_stmt 0 discriminator 6
	cmpb	$123, %al
	setne	%al
	.loc 1 1759 34 is_stmt 1 discriminator 6
	testb	%al, %al
	jne	.L823
	.loc 1 1760 17
	movl	-228(%rbp), %eax
	cmpl	%eax, -292(%rbp)
	jg	.L826
	.loc 1 1760 17 is_stmt 0 discriminator 1
	movl	-228(%rbp), %eax
	cmpl	%eax, -296(%rbp)
	jge	.L827
.L826:
	.loc 1 1760 17 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1760, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L827:
	.loc 1 1760 35 is_stmt 1 discriminator 3
	movq	-224(%rbp), %rdx
	movl	-228(%rbp), %eax
	cltq
	movq	-304(%rbp), %rdi
	subq	%rdi, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 1 1760 35 is_stmt 0 discriminator 4
	cmpb	$125, %al
	setne	%al
	.loc 1 1760 9 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L828
.L823:
	.loc 1 1761 12
	movl	$0, %ebx
	jmp	.L883
.L828:
	.loc 1 1762 24
	movl	-232(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L830
	.loc 1 1762 24 is_stmt 0 discriminator 1
	cmpl	$16777217, %eax
	jle	.L831
.L830:
	.loc 1 1762 24 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1762, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L831:
	.loc 1 1762 9 is_stmt 1 discriminator 3
	movl	%eax, -52(%rbp)
	.loc 1 1763 7
	movl	$0, %r12d
.L873:
.LBB128:
	.loc 1 1764 35
	movl	-232(%rbp), %eax
	.loc 1 1764 33
	cmpl	%eax, -52(%rbp)
	jle	.L832
	.loc 1 1764 69 discriminator 1
	movl	-320(%rbp), %eax
	cmpl	$2147483647, %eax
	jne	.L833
	.loc 1 1764 69 is_stmt 0 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$1764, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L833:
	.loc 1 1764 69 discriminator 4
	movl	-320(%rbp), %eax
	addl	$1, %eax
	.loc 1 1764 35 is_stmt 1 discriminator 5
	cmpl	-52(%rbp), %eax
	jge	.L834
.L832:
.LBB129:
	.loc 1 1764 33 discriminator 6
	leaq	.LC81(%rip), %rax
	movq	%rax, -400(%rbp)
	leaq	.LC2(%rip), %rax
	movq	%rax, -392(%rbp)
	movq	-400(%rbp), %rbx
	movq	-392(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L834:
.LBE129:
	.loc 1 1768 10
	testb	%r12b, %r12b
	je	.L835
	.loc 1 1768 44 discriminator 1
	movl	-328(%rbp), %eax
	movl	%eax, -412(%rbp)
.L835:
	.loc 1 1768 44 is_stmt 0 discriminator 2
	movl	-52(%rbp), %eax
	movl	%eax, -328(%rbp)
	.loc 1 1768 10 is_stmt 1 discriminator 2
	testb	%r12b, %r12b
	je	.L836
	.loc 1 1768 44 discriminator 3
	movl	-412(%rbp), %ebx
	cmpl	%ebx, %eax
	jg	.L837
.LBB130:
	.loc 1 1768 44 is_stmt 0 discriminator 4
	leaq	.LC82(%rip), %rax
	movq	%rax, -384(%rbp)
	leaq	.LC36(%rip), %rax
	movq	%rax, -376(%rbp)
	movq	-384(%rbp), %rbx
	movq	-376(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L836:
.LBE130:
	.loc 1 1768 10 is_stmt 1 discriminator 5
	movl	$1, %r12d
.L837:
	.loc 1 1769 15
	leaq	-288(%rbp), %rdi
	movl	-52(%rbp), %esi
	movq	-232(%rbp), %rcx
	movq	-224(%rbp), %rdx
	movq	-216(%rbp), %rax
	movl	%esi, %r8d
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_library_reports__read_member
	movq	-288(%rbp), %rax
	movq	-280(%rbp), %rdx
	movq	%rax, -192(%rbp)
	movq	%rdx, -184(%rbp)
	movq	-272(%rbp), %rax
	movq	%rax, -176(%rbp)
	.loc 1 1770 16
	movzbl	-192(%rbp), %eax
	cmpb	$2, %al
	jbe	.L838
	.loc 1 1770 16 is_stmt 0 discriminator 1
	leaq	.LC39(%rip), %rax
	movl	$1770, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L838:
	.loc 1 1770 10 is_stmt 1 discriminator 2
	testb	%al, %al
	je	.L839
	cmpb	$1, %al
	je	.L898
	jmp	.L896
.L839:
	.loc 1 1771 28
	movl	$0, %ebx
	jmp	.L883
.L896:
.LBB131:
	.loc 1 1779 30
	movl	-184(%rbp), %edx
	movl	-188(%rbp), %eax
	subl	%eax, %edx
	.loc 1 1779 16
	testl	%edx, %edx
	jg	.L843
	.loc 1 1779 53 discriminator 1
	movl	$0, %ebx
	jmp	.L883
.L843:
	.loc 1 1780 16
	cmpb	$0, -242(%rbp)
	je	.L845
	.loc 1 1782 56
	movl	-188(%rbp), %eax
	leal	1(%rax), %edx
	.loc 1 1782 74
	movl	-184(%rbp), %eax
	leal	-1(%rax), %esi
	.loc 1 1782 60
	cmpl	%edx, %esi
	jl	.L846
	.loc 1 1782 60 is_stmt 0 discriminator 1
	cmpl	%edx, -292(%rbp)
	jg	.L847
	.loc 1 1782 60 discriminator 2
	cmpl	%esi, -296(%rbp)
	jge	.L846
.L847:
	.loc 1 1782 60 discriminator 3
	leaq	.LC39(%rip), %rax
	movl	$1782, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L846:
	.loc 1 1782 38 is_stmt 1 discriminator 4
	cmpl	%edx, %esi
	.loc 1 1782 38 is_stmt 0 discriminator 7
	cmpl	%edx, %esi
	.loc 1 1782 38 discriminator 10
	cmpl	%edx, %esi
.LBB132:
	.loc 1 1781 46 is_stmt 1
	movq	-224(%rbp), %rcx
	movslq	%edx, %rax
	movq	-304(%rbp), %rdi
	subq	%rdi, %rax
	addq	%rcx, %rax
	movq	%rax, -368(%rbp)
	movl	%edx, -72(%rbp)
	movl	%esi, -68(%rbp)
	leaq	-72(%rbp), %rax
	movq	%rax, -360(%rbp)
	movq	-368(%rbp), %rax
	movq	-360(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-240(%rbp), %rdx
	movq	-224(%rbp), %rsi
	movq	-216(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 1781 27 discriminator 1
	movq	-224(%rbp), %rcx
	movq	-216(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__entity_name
.LEHE10:
	.loc 1 1781 27 is_stmt 0 discriminator 2
	movb	%al, -53(%rbp)
	leaq	-104(%rbp), %rax
	movq	%rax, %rdi
.LEHB11:
	call	system__secondary_stack__ss_mark@PLT
.LBE132:
.LBB133:
	.loc 1 1783 22 is_stmt 1
	movzbl	-241(%rbp), %edx
	movzbl	-53(%rbp), %eax
	movl	%edx, %esi
	movl	%eax, %edi
	call	silver_library_reports__expected_coverage
	movq	%rax, %rcx
	movq	%rdx, %rbx
	.loc 1 1783 52 discriminator 1
	movq	%rbx, %rax
	movl	4(%rax), %edx
	movq	%rbx, %rax
	movl	(%rax), %eax
	.loc 1 1784 21
	cmpl	%eax, %edx
	jl	.L854
	.loc 1 1783 60 discriminator 2
	movq	%rbx, %rax
	movl	4(%rax), %eax
	movl	%eax, %esi
	movq	%rbx, %rax
	movl	(%rax), %eax
	movl	%eax, %edx
	movl	%esi, %eax
	subl	%edx, %eax
	cmpl	$-1, %eax
	je	.L854
	.loc 1 1784 62 discriminator 1
	movzbl	-241(%rbp), %edx
	movzbl	-53(%rbp), %eax
	movl	%edx, %esi
	movl	%eax, %edi
	call	silver_library_reports__expected_coverage
	.loc 1 1784 33 discriminator 2
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-180(%rbp), %rdx
	movq	-224(%rbp), %rsi
	movq	-216(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
.LEHE11:
	.loc 1 1784 29 discriminator 3
	xorl	$1, %eax
	.loc 1 1784 21 discriminator 3
	testb	%al, %al
	je	.L855
.L854:
	.loc 1 1784 21 is_stmt 0 discriminator 4
	movb	$1, -321(%rbp)
	jmp	.L856
.L855:
	.loc 1 1784 21 discriminator 5
	movb	$0, -321(%rbp)
.L856:
	.loc 1 1784 0 is_stmt 1 discriminator 6
	movl	$1, %ebx
.L885:
	.loc 1 1784 0 is_stmt 0 discriminator 7
	leaq	-128(%rbp), %rax
	movq	%rax, %r10
.LEHB12:
	call	silver_library_reports__map_ok__L_9__B1016b___finalizer.2
.LEHE12:
	.loc 1 1784 0 discriminator 8
	cmpl	$1, %ebx
	jne	.L857
	.loc 1 1784 0 discriminator 10
	movl	$1, %eax
.L887:
	.loc 1 1784 0 discriminator 11
	cmpl	$1, %eax
	jne	.L858
	.loc 1 1784 0 discriminator 12
	nop
.LBE133:
	.loc 1 1783 19 is_stmt 1 discriminator 3
	cmpb	$0, -321(%rbp)
	je	.L859
	.loc 1 1785 24
	movl	$0, %ebx
	jmp	.L883
.L845:
	.loc 1 1787 60
	movl	-188(%rbp), %eax
	leal	1(%rax), %edx
	.loc 1 1787 78
	movl	-184(%rbp), %eax
	leal	-1(%rax), %esi
	.loc 1 1787 64
	cmpl	%edx, %esi
	jl	.L860
	.loc 1 1787 64 is_stmt 0 discriminator 1
	cmpl	%edx, -292(%rbp)
	jg	.L861
	.loc 1 1787 64 discriminator 2
	cmpl	%esi, -296(%rbp)
	jge	.L860
.L861:
	.loc 1 1787 64 discriminator 3
	leaq	.LC39(%rip), %rax
	movl	$1787, %esi
	movq	%rax, %rdi
.LEHB13:
	call	__gnat_rcheck_CE_Range_Check@PLT
.L860:
	.loc 1 1787 42 is_stmt 1 discriminator 4
	cmpl	%edx, %esi
	.loc 1 1787 42 is_stmt 0 discriminator 7
	cmpl	%edx, %esi
	.loc 1 1787 42 discriminator 10
	cmpl	%edx, %esi
	.loc 1 1787 22 is_stmt 1 discriminator 13
	movq	-224(%rbp), %rcx
	movslq	%edx, %rax
	movq	-304(%rbp), %rbx
	subq	%rbx, %rax
	addq	%rcx, %rax
	movq	%rax, -352(%rbp)
	movl	%edx, -64(%rbp)
	movl	%esi, -60(%rbp)
	leaq	-64(%rbp), %rax
	movq	%rax, -344(%rbp)
	movq	-352(%rbp), %rax
	movq	-344(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-232(%rbp), %rdx
	movq	-224(%rbp), %rsi
	movq	-216(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, -200(%rbp)
	.loc 1 1787 22 is_stmt 0 discriminator 14
	leaq	-200(%rbp), %rcx
	.loc 1 1787 84 is_stmt 1 discriminator 14
	movl	(%rcx), %edx
	.loc 1 1787 84 is_stmt 0 discriminator 15
	movl	-180(%rbp), %eax
	.loc 1 1787 19 is_stmt 1 discriminator 15
	cmpl	%eax, %edx
	jne	.L868
	.loc 1 1787 84 discriminator 16
	movl	4(%rcx), %edx
	.loc 1 1787 84 is_stmt 0 discriminator 17
	movl	-176(%rbp), %eax
	cmpl	%eax, %edx
	je	.L869
.L868:
	.loc 1 1788 24 is_stmt 1
	movl	$0, %ebx
	jmp	.L883
.L869:
	.loc 1 1789 27
	movq	-180(%rbp), %rdx
	movq	-224(%rbp), %rcx
	movq	-216(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__entity_name
	.loc 1 1789 27 is_stmt 0 discriminator 1
	movb	%al, -53(%rbp)
.L859:
	.loc 1 1793 16 is_stmt 1
	cmpb	$0, -53(%rbp)
	je	.L870
	.loc 1 1793 34 discriminator 1
	movzbl	-53(%rbp), %eax
	movzbl	-160(%rbp,%rax), %eax
	.loc 1 1793 34 is_stmt 0 discriminator 2
	testb	%al, %al
	je	.L871
.L870:
	.loc 1 1795 19 is_stmt 1
	movl	$0, %ebx
	jmp	.L883
.L871:
	.loc 1 1812 24
	leaq	-288(%rbp), %rcx
	movzbl	-53(%rbp), %edx
	leaq	-160(%rbp), %rax
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	silver_library_reports__remember
.LEHE13:
	movq	-288(%rbp), %rax
	movq	-280(%rbp), %rdx
	movq	%rax, -160(%rbp)
	movq	%rdx, -152(%rbp)
	movzwl	-272(%rbp), %eax
	movw	%ax, -144(%rbp)
	.loc 1 1813 18
	movl	-172(%rbp), %eax
	movl	%eax, -52(%rbp)
.LBE131:
	.loc 1 1814 14 discriminator 1
	nop
.LBE128:
	.loc 1 1815 15
	jmp	.L873
.L898:
.LBB136:
	.loc 1 1777 16
	nop
.LBE136:
	.loc 1 1816 15
	movl	$1, %ebx
.LBB137:
	.loc 1 1816 23 discriminator 1
	movb	$0, -54(%rbp)
.L882:
	leaq	-128(%rbp), %rax
	movq	%rax, %rdi
.LEHB14:
	call	system__secondary_stack__ss_mark@PLT
.LBB138:
.LBB139:
	.loc 1 1816 58 discriminator 2
	movzbl	-54(%rbp), %eax
	movzbl	-160(%rbp,%rax), %r12d
	.loc 1 1817 10
	cmpb	$0, -242(%rbp)
	je	.L874
	.loc 1 1817 27 discriminator 1
	movzbl	-241(%rbp), %edx
	movzbl	-54(%rbp), %eax
	movl	%edx, %esi
	movl	%eax, %edi
	call	silver_library_reports__expected_coverage
	.loc 1 1817 57 discriminator 2
	movq	%rdx, %rcx
	movl	4(%rcx), %esi
	movq	%rdx, %rcx
	movl	(%rcx), %ecx
	.loc 1 1817 65 discriminator 2
	cmpl	%ecx, %esi
	jl	.L875
	.loc 1 1817 65 is_stmt 0 discriminator 3
	movq	%rdx, %rcx
	movl	4(%rcx), %ecx
	movq	%rdx, %rax
	movl	(%rax), %eax
	movl	%eax, %edx
	movl	%ecx, %eax
	subl	%edx, %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L875
	.loc 1 1817 65 discriminator 4
	movl	$1, %eax
	jmp	.L877
.L875:
	.loc 1 1817 65 discriminator 5
	movl	$0, %eax
	.loc 1 1817 10 is_stmt 1 discriminator 6
	jmp	.L877
.L874:
	.loc 1 1818 15
	movzbl	-241(%rbp), %edx
	movzbl	-54(%rbp), %eax
	movl	%edx, %esi
	movl	%eax, %edi
	call	silver_library_reports__expected_entity
.LEHE14:
.L877:
	.loc 1 1816 15 discriminator 4
	cmpb	%r12b, %al
	setne	-322(%rbp)
	.loc 1 1816 0 discriminator 4
	movl	$1, %r12d
.L889:
	.loc 1 1816 0 is_stmt 0 discriminator 5
	leaq	-128(%rbp), %rax
	movq	%rax, %r10
.LEHB15:
	call	silver_library_reports__map_ok__B1041b__L1042b__B1043b___finalizer.3
.LEHE15:
	.loc 1 1816 0 discriminator 6
	cmpl	$1, %r12d
	jne	.L878
	.loc 1 1816 0 discriminator 8
	movl	$1, %eax
.L891:
	.loc 1 1816 0 discriminator 9
	cmpl	$1, %eax
	jne	.L879
	.loc 1 1816 0 discriminator 10
	nop
.LBE139:
	.loc 1 1816 15 is_stmt 1 discriminator 11
	cmpb	$0, -322(%rbp)
	je	.L880
	.loc 1 1816 15 is_stmt 0 discriminator 12
	movl	$0, %ebx
.LBE138:
.LBE137:
	.loc 1 1816 7 is_stmt 1 discriminator 15
	jmp	.L899
.L880:
.LBB142:
	.loc 1 1816 15 discriminator 13
	cmpb	$17, -54(%rbp)
	je	.L899
	.loc 1 1816 15 is_stmt 0 discriminator 14
	addb	$1, -54(%rbp)
	jmp	.L882
.L899:
.LBE142:
	.loc 1 1816 7 is_stmt 1 discriminator 15
	nop
.L883:
.LBE125:
	.loc 1 1819 8
	movl	%ebx, %eax
	jmp	.L897
.L892:
	movq	%rax, -424(%rbp)
	movl	$0, %ebx
.LBB145:
.LBB143:
.LBB135:
.LBB134:
	.loc 1 1784 21 discriminator 13
	jmp	.L885
.L857:
	movq	-424(%rbp), %rax
	movq	%rax, -336(%rbp)
	jmp	.L886
.L893:
	movq	%rax, -336(%rbp)
.L886:
	movl	$0, %eax
	jmp	.L887
.L858:
	movq	-336(%rbp), %rax
	movq	%rax, %rdi
.LEHB16:
	call	_Unwind_Resume@PLT
.L894:
	movq	%rax, -432(%rbp)
	movl	$0, %r12d
.LBE134:
.LBE135:
.LBE143:
.LBB144:
.LBB141:
.LBB140:
	.loc 1 1816 15 discriminator 16
	jmp	.L889
.L878:
	movq	-432(%rbp), %rax
	movq	%rax, -408(%rbp)
	jmp	.L890
.L895:
	movq	%rax, -408(%rbp)
.L890:
	movl	$0, %eax
	jmp	.L891
.L879:
	movq	-408(%rbp), %rax
	movq	%rax, %rdi
	call	_Unwind_Resume@PLT
.L897:
.LBE140:
.LBE141:
.LBE144:
.LBE145:
	.loc 1 1819 8
	addq	$392, %rsp
.LEHE16:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE38:
	.section	.gcc_except_table
.LLSDA38:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE38-.LLSDACSB38
.LLSDACSB38:
	.uleb128 .LEHB10-.LFB38
	.uleb128 .LEHE10-.LEHB10
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB11-.LFB38
	.uleb128 .LEHE11-.LEHB11
	.uleb128 .L892-.LFB38
	.uleb128 0
	.uleb128 .LEHB12-.LFB38
	.uleb128 .LEHE12-.LEHB12
	.uleb128 .L893-.LFB38
	.uleb128 0
	.uleb128 .LEHB13-.LFB38
	.uleb128 .LEHE13-.LEHB13
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB14-.LFB38
	.uleb128 .LEHE14-.LEHB14
	.uleb128 .L894-.LFB38
	.uleb128 0
	.uleb128 .LEHB15-.LFB38
	.uleb128 .LEHE15-.LEHB15
	.uleb128 .L895-.LFB38
	.uleb128 0
	.uleb128 .LEHB16-.LFB38
	.uleb128 .LEHE16-.LEHB16
	.uleb128 0
	.uleb128 0
.LLSDACSE38:
	.text
	.size	silver_library_reports__map_ok, .-silver_library_reports__map_ok
	.align 2
	.type	silver_library_reports__map_ok__B1041b__L1042b__B1043b___finalizer.3, @function
silver_library_reports__map_ok__B1041b__L1042b__B1043b___finalizer.3:
.LFB40:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE40:
	.size	silver_library_reports__map_ok__B1041b__L1042b__B1043b___finalizer.3, .-silver_library_reports__map_ok__B1041b__L1042b__B1043b___finalizer.3
	.section	.rodata
	.align 8
.LC83:
	.ascii	"failed precondition from silver_library_reports.adb:1822"
	.text
	.align 2
	.type	silver_library_reports__entities_ok, @function
silver_library_reports__entities_ok:
.LFB41:
	.loc 1 1821 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 3, -24
	movq	%rdi, %rax
	movq	%rsi, %rbx
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%rbx, %rdi
	movq	%rsi, -32(%rbp)
	movq	%rdi, -24(%rbp)
	movq	%rdx, -40(%rbp)
	movb	%cl, -41(%rbp)
	.loc 1 1821 4
	movq	-24(%rbp), %rax
	movl	(%rax), %eax
	movq	-24(%rbp), %rdx
	movl	4(%rdx), %edx
.LBB146:
	cmpl	%eax, %edx
	.loc 1 1821 4 is_stmt 0 discriminator 3
	cmpl	%eax, %edx
	.loc 1 1821 4 discriminator 6
	cmpl	%eax, %edx
	.loc 1 1822 18 is_stmt 1
	cmpl	$1, %eax
	je	.L909
.LBB147:
	.loc 1 1822 18 is_stmt 0 discriminator 1
	leaq	.LC83(%rip), %r10
	leaq	.LC2(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L909:
.LBE147:
	.loc 1 1822 54 is_stmt 1 discriminator 2
	cltq
	leaq	16777215(%rax), %rcx
	movslq	%edx, %rax
	.loc 1 1822 18 discriminator 2
	cmpq	%rax, %rcx
	jge	.L910
.LBB148:
	.loc 1 1822 18 is_stmt 0 discriminator 3
	leaq	.LC83(%rip), %r8
	leaq	.LC2(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L910:
.LBE148:
	.loc 1 1826 14 is_stmt 1
	movzbl	-41(%rbp), %edi
	movq	-40(%rbp), %rcx
	movq	-40(%rbp), %rdx
	movq	-32(%rbp), %rsi
	movq	-24(%rbp), %rax
	movl	$0, %r9d
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__map_ok
.LBE146:
	.loc 1 1827 8
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE41:
	.size	silver_library_reports__entities_ok, .-silver_library_reports__entities_ok
	.section	.rodata
	.align 8
.LC84:
	.ascii	"failed precondition from silver_library_reports.adb:1830"
	.text
	.align 2
	.type	silver_library_reports__coverage_ok, @function
silver_library_reports__coverage_ok:
.LFB42:
	.loc 1 1829 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	subq	$48, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	movq	%rdi, %rax
	movq	%rsi, %r9
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r9, %rdi
	movq	%rsi, -32(%rbp)
	movq	%rdi, -24(%rbp)
	movq	%rdx, -40(%rbp)
	movq	%rcx, -48(%rbp)
	movb	%r8b, -49(%rbp)
	.loc 1 1829 4
	movq	-24(%rbp), %rax
	movl	(%rax), %eax
	movq	-24(%rbp), %rdx
	movl	4(%rdx), %edx
.LBB149:
	cmpl	%eax, %edx
	.loc 1 1829 4 is_stmt 0 discriminator 3
	cmpl	%eax, %edx
	.loc 1 1829 4 discriminator 6
	cmpl	%eax, %edx
	.loc 1 1830 18 is_stmt 1
	cmpl	$1, %eax
	je	.L919
.LBB150:
	.loc 1 1830 18 is_stmt 0 discriminator 1
	leaq	.LC84(%rip), %r12
	leaq	.LC2(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L919:
.LBE150:
	.loc 1 1830 54 is_stmt 1 discriminator 2
	cltq
	leaq	16777215(%rax), %rcx
	movslq	%edx, %rax
	.loc 1 1830 18 discriminator 2
	cmpq	%rax, %rcx
	jge	.L920
.LBB151:
	.loc 1 1830 18 is_stmt 0 discriminator 3
	leaq	.LC84(%rip), %r10
	leaq	.LC2(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L920:
.LBE151:
	.loc 1 1834 14 is_stmt 1
	movzbl	-49(%rbp), %edi
	movq	-48(%rbp), %rcx
	movq	-40(%rbp), %rdx
	movq	-32(%rbp), %rsi
	movq	-24(%rbp), %rax
	movl	$1, %r9d
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__map_ok
.LBE149:
	.loc 1 1835 8
	addq	$48, %rsp
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE42:
	.size	silver_library_reports__coverage_ok, .-silver_library_reports__coverage_ok
	.section	.rodata
	.align 8
.LC85:
	.ascii	"failed precondition from silver_library_reports.adb:4254"
	.text
	.align 2
	.type	silver_library_reports__audit_normalized_report, @function
silver_library_reports__audit_normalized_report:
.LFB43:
	.loc 1 4253 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$344, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -96(%rbp)
	movq	%rbx, -88(%rbp)
	movb	%dl, -97(%rbp)
	.loc 1 4253 4
	movq	-88(%rbp), %rax
	movl	(%rax), %r8d
	movq	-88(%rbp), %rax
	movl	4(%rax), %r9d
	cmpl	%r8d, %r9d
	jl	.L923
	.loc 1 4253 4 is_stmt 0 discriminator 1
	movslq	%r9d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r8d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %r12
	movq	%rdx, %r13
	jmp	.L924
.L923:
	.loc 1 4253 4 discriminator 2
	movl	$0, %r12d
	movl	$0, %r13d
.L924:
.LBB152:
	.loc 1 4253 4 discriminator 3
	cmpl	%r8d, %r9d
	.loc 1 4253 4 discriminator 6
	cmpl	%r8d, %r9d
	.loc 1 4253 4 discriminator 9
	cmpl	%r8d, %r9d
	.loc 1 4254 18 is_stmt 1
	cmpl	$1, %r8d
	je	.L931
.LBB153:
	.loc 1 4254 18 is_stmt 0 discriminator 1
	leaq	.LC85(%rip), %r10
	leaq	.LC2(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L931:
.LBE153:
	.loc 1 4258 22 is_stmt 1
	movl	%r12d, %eax
	.loc 1 4258 7
	testl	%eax, %eax
	jle	.L932
	.loc 1 4258 22 discriminator 1
	movl	%r12d, %eax
	cmpl	$16777216, %eax
	jle	.L933
.L932:
	.loc 1 4258 57 discriminator 2
	movl	$0, %eax
	jmp	.L934
.L933:
.LBB154:
	.loc 1 4260 10
	movl	$1, -52(%rbp)
	.loc 1 4263 10
	movl	$0, -72(%rbp)
	movl	$0, -68(%rbp)
	.loc 1 4263 18
	movl	$0, -80(%rbp)
	movl	$0, -76(%rbp)
	.loc 1 4265 10
	movl	-52(%rbp), %edx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__skip_space
	.loc 1 4265 10 is_stmt 0 discriminator 1
	movl	%eax, -52(%rbp)
	.loc 1 4266 18 is_stmt 1
	movl	-52(%rbp), %edx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__value_end
	.loc 1 4266 18 is_stmt 0 discriminator 1
	movl	%eax, -56(%rbp)
	.loc 1 4267 10 is_stmt 1
	cmpl	$0, -56(%rbp)
	jne	.L935
	.loc 1 4267 27 discriminator 1
	movl	$0, %eax
	jmp	.L934
.L935:
	.loc 1 4268 23
	movl	-56(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L937
	.loc 1 4268 23 is_stmt 0 discriminator 1
	cmpl	$16777217, %eax
	jle	.L938
.L937:
	.loc 1 4268 23 discriminator 2
	leaq	.LC39(%rip), %rax
	movl	$4268, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L938:
	.loc 1 4268 15 is_stmt 1 discriminator 3
	movl	%eax, -60(%rbp)
	.loc 1 4269 10
	movl	-60(%rbp), %edx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__skip_space
	.loc 1 4269 10 is_stmt 0 discriminator 1
	movl	%eax, -60(%rbp)
	.loc 1 4270 33 is_stmt 1
	movl	%r12d, %eax
	cmpl	$2147483647, %eax
	jne	.L939
	.loc 1 4270 33 is_stmt 0 discriminator 1
	leaq	.LC39(%rip), %rax
	movl	$4270, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L939:
	.loc 1 4270 33 discriminator 3
	movl	%r12d, %eax
	addl	$1, %eax
	.loc 1 4270 10 is_stmt 1 discriminator 4
	cmpl	-60(%rbp), %eax
	je	.L940
	.loc 1 4270 42 discriminator 5
	movl	$0, %eax
	jmp	.L934
.L940:
	.loc 1 4271 17
	movl	-52(%rbp), %eax
	movl	%eax, -72(%rbp)
	movl	-56(%rbp), %eax
	movl	%eax, -68(%rbp)
	.loc 1 4272 22
	leaq	silver_library_reports__json_entities(%rip), %r14
	leaq	.LC28(%rip), %r15
	movq	%r14, %rcx
	movq	%r15, %rdi
	movq	-72(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	.loc 1 4272 19 discriminator 1
	movq	%rax, -80(%rbp)
	.loc 1 4273 17
	leaq	silver_library_reports__atom_progress_proof(%rip), %rax
	movq	%rax, -384(%rbp)
	leaq	.LC14(%rip), %rax
	movq	%rax, -376(%rbp)
	.loc 1 4273 37
	leaq	silver_library_reports__json_progress(%rip), %rax
	movq	%rax, -368(%rbp)
	leaq	.LC28(%rip), %rax
	movq	%rax, -360(%rbp)
	movq	-368(%rbp), %rax
	movq	-360(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-72(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 4273 17 discriminator 1
	movq	-384(%rbp), %rbx
	movq	-376(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %r8
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 4295 12
	testb	%al, %al
	je	.L941
	.loc 1 4274 21
	leaq	silver_library_reports__atom_stop_reason_none(%rip), %rax
	movq	%rax, -352(%rbp)
	leaq	.LC10(%rip), %rax
	movq	%rax, -344(%rbp)
	.loc 1 4274 41
	leaq	silver_library_reports__json_stop_reason(%rip), %rax
	movq	%rax, -336(%rbp)
	leaq	.LC20(%rip), %rax
	movq	%rax, -328(%rbp)
	movq	-336(%rbp), %rax
	movq	-328(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-72(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 4274 21 discriminator 1
	movq	-352(%rbp), %rbx
	movq	-344(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %r8
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__string_equal
	.loc 1 4274 12 discriminator 2
	testb	%al, %al
	je	.L941
	.loc 1 4275 40
	leaq	silver_library_reports__json_skip_flow_proof(%rip), %rax
	movq	%rax, -320(%rbp)
	leaq	.LC29(%rip), %rax
	movq	%rax, -312(%rbp)
	movq	-320(%rbp), %rax
	movq	-312(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-72(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 4275 21 discriminator 1
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__empty_array
	.loc 1 4275 12 discriminator 2
	testb	%al, %al
	je	.L941
	.loc 1 4276 40
	leaq	silver_library_reports__json_skip_proof(%rip), %rax
	movq	%rax, -304(%rbp)
	leaq	.LC19(%rip), %rbx
	movq	%rbx, -296(%rbp)
	movq	-304(%rbp), %rax
	movq	-296(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-72(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 4276 21 discriminator 1
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__empty_array
	.loc 1 4276 12 discriminator 2
	testb	%al, %al
	je	.L941
	.loc 1 4277 40
	leaq	silver_library_reports__json_pragma_assume(%rip), %rax
	movq	%rax, -288(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -280(%rbp)
	movq	-288(%rbp), %rax
	movq	-280(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-72(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 4277 21 discriminator 1
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__empty_array
	.loc 1 4277 12 discriminator 2
	testb	%al, %al
	je	.L941
	.loc 1 4295 12 discriminator 1
	cmpb	$3, -97(%rbp)
	jbe	.L942
	.loc 1 4279 29
	leaq	silver_library_reports__json_warn_error(%rip), %rax
	movq	%rax, -272(%rbp)
	movq	%rbx, -264(%rbp)
	movq	-272(%rbp), %rax
	movq	-264(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-72(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 4279 14 discriminator 1
	movq	-80(%rbp), %rax
	movq	-96(%rbp), %rdi
	movq	-88(%rbp), %rsi
	movl	$6, %r8d
	movq	%rax, %rcx
	call	silver_library_reports__list_ok
	.loc 1 4278 12
	testb	%al, %al
	jne	.L943
	jmp	.L941
.L942:
	.loc 1 4280 38
	leaq	silver_library_reports__json_warn_error(%rip), %rax
	movq	%rax, -256(%rbp)
	leaq	.LC19(%rip), %rax
	movq	%rax, -248(%rbp)
	movq	-256(%rbp), %rax
	movq	-248(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-72(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 4280 19 discriminator 1
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__empty_array
	.loc 1 4278 22 discriminator 1
	testb	%al, %al
	je	.L941
.L943:
	.loc 1 4281 21
	movzbl	-97(%rbp), %ecx
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__entities_ok
	.loc 1 4281 12 discriminator 1
	testb	%al, %al
	je	.L941
	.loc 1 4282 40
	leaq	silver_library_reports__json_spark(%rip), %rax
	movq	%rax, -240(%rbp)
	leaq	.LC37(%rip), %rax
	movq	%rax, -232(%rbp)
	movq	-240(%rbp), %rax
	movq	-232(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-72(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %r9
	.loc 1 4282 21 discriminator 1
	movzbl	-97(%rbp), %edx
	movq	-80(%rbp), %rax
	movq	-96(%rbp), %rdi
	movq	-88(%rbp), %rsi
	movl	%edx, %r8d
	movq	%rax, %rcx
	movq	%r9, %rdx
	call	silver_library_reports__coverage_ok
	.loc 1 4282 12 discriminator 2
	testb	%al, %al
	je	.L941
	.loc 1 4283 21
	cmpb	$7, -97(%rbp)
	je	.L944
	.loc 1 4284 38
	cmpb	$8, -97(%rbp)
	je	.L944
	.loc 1 4284 49 discriminator 1
	cmpb	$9, -97(%rbp)
	je	.L944
	.loc 1 4284 62 discriminator 2
	cmpb	$10, -97(%rbp)
	je	.L944
	.loc 1 4284 81 discriminator 3
	cmpb	$12, -97(%rbp)
	je	.L944
	.loc 1 4285 20
	cmpb	$13, -97(%rbp)
	je	.L944
	.loc 1 4285 45 discriminator 1
	cmpb	$14, -97(%rbp)
	je	.L944
	.loc 1 4285 74 discriminator 2
	cmpb	$15, -97(%rbp)
	je	.L944
	.loc 1 4286 20
	cmpb	$16, -97(%rbp)
	je	.L944
	.loc 1 4287 15
	cmpb	$21, -97(%rbp)
	je	.L945
	.loc 1 4287 45 discriminator 1
	cmpb	$22, -97(%rbp)
	je	.L945
	.loc 1 4287 60 discriminator 2
	cmpb	$23, -97(%rbp)
	je	.L945
	.loc 1 4287 77 discriminator 3
	cmpb	$24, -97(%rbp)
	je	.L945
	.loc 1 4287 96 discriminator 4
	cmpb	$29, -97(%rbp)
	je	.L945
	.loc 1 4288 20
	cmpb	$25, -97(%rbp)
	je	.L945
	.loc 1 4288 45 discriminator 1
	cmpb	$26, -97(%rbp)
	je	.L945
	.loc 1 4288 74 discriminator 2
	cmpb	$27, -97(%rbp)
	je	.L945
	.loc 1 4289 20
	cmpb	$28, -97(%rbp)
	je	.L945
	.loc 1 4290 15
	cmpb	$16, -97(%rbp)
	ja	.L946
	.loc 1 4291 15
	cmpb	$3, -97(%rbp)
	jbe	.L947
	.loc 1 4283 21 discriminator 1
	movl	$2, %ebx
	.loc 1 4283 21 is_stmt 0 discriminator 4
	jmp	.L949
.L947:
	.loc 1 4283 21 discriminator 2
	movl	$0, %ebx
	.loc 1 4283 21 discriminator 4
	jmp	.L949
.L946:
	.loc 1 4283 21 discriminator 3
	movl	$4, %ebx
	.loc 1 4283 21 discriminator 4
	jmp	.L949
.L945:
	.loc 1 4283 21 discriminator 5
	movl	$5, %ebx
	.loc 1 4283 21 discriminator 6
	jmp	.L950
.L949:
	jmp	.L950
.L944:
	.loc 1 4283 21 discriminator 7
	movl	$3, %ebx
.L950:
	.loc 1 4283 36 is_stmt 1 discriminator 8
	leaq	silver_library_reports__json_flow(%rip), %rax
	movq	%rax, -224(%rbp)
	leaq	.LC3(%rip), %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rax
	movq	-216(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-72(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %r9
	.loc 1 4283 21 discriminator 9
	movzbl	%bl, %eax
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rdi
	movq	-88(%rbp), %rsi
	movl	%eax, %r8d
	movq	%rdx, %rcx
	movq	%r9, %rdx
	call	silver_library_reports__list_ok
	.loc 1 4283 12 discriminator 10
	testb	%al, %al
	je	.L941
	.loc 1 4292 21
	cmpb	$3, -97(%rbp)
	jbe	.L951
	.loc 1 4292 21 is_stmt 0 discriminator 1
	movl	$1, %ebx
	jmp	.L952
.L951:
	.loc 1 4292 21 discriminator 2
	movl	$0, %ebx
.L952:
	.loc 1 4292 36 is_stmt 1 discriminator 3
	leaq	silver_library_reports__json_proof(%rip), %r15
	movq	%r15, -208(%rbp)
	leaq	.LC37(%rip), %r14
	movq	%r14, -200(%rbp)
	movq	-208(%rbp), %rsi
	movq	-200(%rbp), %rdi
	movq	%rsi, %rax
	movq	%rdi, %r8
	movq	-72(%rbp), %rdx
	movq	-96(%rbp), %rdi
	movq	-88(%rbp), %rsi
	movq	%rax, %rcx
	call	silver_library_reports__field
	movq	%rax, %rsi
	.loc 1 4292 21 discriminator 4
	movzbl	%bl, %eax
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rdi
	movq	-88(%rbp), %r9
	movl	%eax, %r8d
	movq	%rdx, %rcx
	movq	%rsi, %rdx
	movq	%r9, %rsi
	call	silver_library_reports__list_ok
	.loc 1 4292 12 discriminator 5
	testb	%al, %al
	je	.L941
	.loc 1 4294 44
	leaq	silver_library_reports__json_assumptions(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC20(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rax
	movq	-184(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-72(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 4294 21 discriminator 1
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__dependencies_ok
	.loc 1 4294 12 discriminator 2
	testb	%al, %al
	je	.L941
	.loc 1 4295 12 discriminator 2
	cmpb	$1, -97(%rbp)
	je	.L953
	.loc 1 4295 47 discriminator 3
	cmpb	$3, -97(%rbp)
	je	.L953
	.loc 1 4295 64 discriminator 4
	cmpb	$3, -97(%rbp)
	ja	.L953
	.loc 1 4296 38
	leaq	silver_library_reports__json_flow(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC3(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rax
	movq	-168(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-72(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 4296 19 discriminator 1
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__empty_array
	.loc 1 4296 15 discriminator 2
	xorl	$1, %eax
	.loc 1 4295 82 discriminator 5
	testb	%al, %al
	je	.L941
	.loc 1 4297 47
	movq	%r15, -160(%rbp)
	movq	%r14, -152(%rbp)
	movq	-160(%rbp), %rax
	movq	-152(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-72(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdx
	.loc 1 4297 28 discriminator 1
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__empty_array
	.loc 1 4297 24 discriminator 2
	xorl	$1, %eax
	.loc 1 4297 15 discriminator 2
	testb	%al, %al
	je	.L941
	.loc 1 4298 24
	cmpb	$0, -97(%rbp)
	jne	.L954
	.loc 1 4298 24 is_stmt 0 discriminator 1
	movl	$8, %ebx
	jmp	.L955
.L954:
	.loc 1 4298 24 discriminator 2
	movl	$10, %ebx
.L955:
	.loc 1 4298 39 is_stmt 1 discriminator 3
	leaq	silver_library_reports__json_proof(%rip), %r15
	movq	%r15, -144(%rbp)
	leaq	.LC37(%rip), %r14
	movq	%r14, -136(%rbp)
	movq	-144(%rbp), %rax
	movq	-136(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-72(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 4298 24 discriminator 4
	movzbl	%bl, %ecx
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movl	%ecx, %r8d
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__list_ok
	.loc 1 4298 15 discriminator 5
	testb	%al, %al
	je	.L941
	.loc 1 4295 12 discriminator 6
	cmpb	$0, -97(%rbp)
	jne	.L953
	.loc 1 4301 24
	movq	%r15, -128(%rbp)
	movq	%r14, -120(%rbp)
	movq	-128(%rbp), %rax
	movq	-120(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rdi
	movq	-72(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__field
	movq	%rax, %rdi
	.loc 1 4300 48
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movl	$9, %r8d
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__list_ok
	.loc 1 4300 15 discriminator 1
	testb	%al, %al
	je	.L941
.L953:
	.loc 1 4295 12 discriminator 7
	movl	$1, %eax
	.loc 1 4273 10 discriminator 3
	jmp	.L957
.L941:
	.loc 1 4295 12 discriminator 8
	movl	$0, %eax
.L957:
	.loc 1 4273 10 discriminator 3
	nop
.L934:
.LBE154:
.LBE152:
	.loc 1 4303 8
	addq	$344, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE43:
	.size	silver_library_reports__audit_normalized_report, .-silver_library_reports__audit_normalized_report
	.section	.rodata
	.align 8
.LC86:
	.ascii	"failed precondition from silver_library_reports.adb:4308"
	.text
	.align 2
	.type	silver_library_reports__audit_rebased_report, @function
silver_library_reports__audit_rebased_report:
.LFB44:
	.loc 1 4307 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$64, %rsp
	.cfi_offset 14, -24
	.cfi_offset 13, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -80(%rbp)
	movq	%rbx, -72(%rbp)
	movb	%dl, -81(%rbp)
	.loc 1 4307 4
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	movq	-72(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L959
	.loc 1 4307 4 is_stmt 0 discriminator 1
	movslq	%edx, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	movslq	%eax, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rcx
	sbbq	%rdi, %rbx
	addq	$1, %rcx
	adcq	$0, %rbx
	jmp	.L960
.L959:
	.loc 1 4307 4 discriminator 2
	movl	$0, %ecx
	movl	$0, %ebx
.L960:
	movq	%rsp, %rsi
	movq	%rsi, %r14
.LBB155:
	.loc 1 4307 4 discriminator 4
	cmpl	%eax, %edx
	.loc 1 4307 4 discriminator 7
	cmpl	%eax, %edx
	.loc 1 4307 4 discriminator 10
	cmpl	%eax, %edx
	.loc 1 4308 32 is_stmt 1
	movl	%ecx, %esi
	.loc 1 4308 18
	testl	%esi, %esi
	jle	.L967
	.loc 1 4308 32 discriminator 1
	movl	%ecx, %esi
	cmpl	$16777216, %esi
	jle	.L968
.L967:
.LBB156:
	.loc 1 4308 18 discriminator 2
	leaq	.LC86(%rip), %r8
	leaq	.LC2(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L968:
.LBE156:
	.loc 1 4311 7
	movl	%ecx, -36(%rbp)
	movl	-36(%rbp), %ecx
	movl	$0, %esi
	testl	%ecx, %ecx
	cmovs	%esi, %ecx
	movslq	%ecx, %rcx
	movq	%rcx, -48(%rbp)
	movl	-36(%rbp), %ecx
	movl	$0, %esi
	testl	%ecx, %ecx
	cmovs	%esi, %ecx
	movslq	%ecx, %rsi
	.loc 1 4311 54
	movl	-36(%rbp), %ecx
	movl	$0, %edi
	testl	%ecx, %ecx
	cmovs	%edi, %ecx
	movslq	%ecx, %rcx
	cmpl	%eax, %edx
	jl	.L969
	.loc 1 4311 54 is_stmt 0 discriminator 1
	movslq	%edx, %rdx
	cltq
	subq	%rax, %rdx
	movq	%rdx, %rax
	addq	$1, %rax
	jmp	.L970
.L969:
	.loc 1 4311 54 discriminator 2
	movl	$0, %eax
.L970:
	.loc 1 4311 54 discriminator 3
	cmpq	%rcx, %rax
	je	.L971
	.loc 1 4311 54 discriminator 4
	leaq	.LC39(%rip), %rax
	movl	$4311, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Length_Check@PLT
.L971:
	.loc 1 4311 7 is_stmt 1 discriminator 5
	movl	-36(%rbp), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	cltq
	movl	$16, %edx
	subq	$1, %rdx
	addq	%rdx, %rax
	movl	$16, %ebx
	movl	$0, %edx
	divq	%rbx
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	movq	%rax, -56(%rbp)
	.loc 1 4311 7 is_stmt 0 discriminator 6
	movq	-80(%rbp), %rax
	movq	-56(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%rsi, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 1 4313 14 is_stmt 1
	movq	-56(%rbp), %r12
	movl	$1, -64(%rbp)
	movl	-36(%rbp), %eax
	movl	%eax, -60(%rbp)
	leaq	-64(%rbp), %rax
	movq	%rax, %r13
	movzbl	-81(%rbp), %eax
	movq	%r12, %rsi
	movq	%r13, %rcx
	movl	%eax, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver_library_reports__audit_normalized_report
	.loc 1 4313 7 discriminator 1
	nop
	.loc 1 4314 8
	movq	%r14, %rsp
.LBE155:
	leaq	-32(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE44:
	.size	silver_library_reports__audit_rebased_report, .-silver_library_reports__audit_rebased_report
	.align 2
	.type	silver_library_reports__audit_report, @function
silver_library_reports__audit_report:
.LFB45:
	.loc 1 4316 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 3, -24
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -32(%rbp)
	movq	%rbx, -24(%rbp)
	movb	%dl, -33(%rbp)
	.loc 1 4316 4
	movq	-24(%rbp), %rax
	movl	(%rax), %eax
	movq	-24(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L974
	.loc 1 4316 4 is_stmt 0 discriminator 1
	movslq	%edx, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	movslq	%eax, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rcx
	sbbq	%rdi, %rbx
	addq	$1, %rcx
	adcq	$0, %rbx
	jmp	.L975
.L974:
	.loc 1 4316 4 discriminator 2
	movl	$0, %ecx
	movl	$0, %ebx
.L975:
.LBB157:
	.loc 1 4316 4 discriminator 3
	cmpl	%eax, %edx
	.loc 1 4316 4 discriminator 6
	cmpl	%eax, %edx
	.loc 1 4316 4 discriminator 9
	cmpl	%eax, %edx
	.loc 1 4320 24 is_stmt 1
	movl	%ecx, %edx
	.loc 1 4320 7
	testl	%edx, %edx
	jle	.L982
	.loc 1 4320 24 discriminator 1
	movl	%ecx, %edx
	cmpl	$16777216, %edx
	jle	.L983
.L982:
	.loc 1 4320 59 discriminator 2
	movl	$0, %eax
	jmp	.L984
.L983:
	.loc 1 4321 7
	cmpl	$1, %eax
	jne	.L985
	.loc 1 4322 17
	movzbl	-33(%rbp), %edx
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_normalized_report
	.loc 1 4322 10 discriminator 1
	jmp	.L984
.L985:
	.loc 1 4324 17
	movzbl	-33(%rbp), %edx
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_rebased_report
	.loc 1 4324 10 discriminator 1
	nop
.L984:
.LBE157:
	.loc 1 4326 8
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE45:
	.size	silver_library_reports__audit_report, .-silver_library_reports__audit_report
	.align 2
	.globl	silver_library_reports__complete_runtime_proof
	.type	silver_library_reports__complete_runtime_proof, @function
silver_library_reports__complete_runtime_proof:
.LFB46:
	.loc 1 4328 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 3, -24
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -32(%rbp)
	movq	%rbx, -24(%rbp)
	movb	%dl, -33(%rbp)
	.loc 1 4328 4
	movq	-24(%rbp), %rax
	movl	(%rax), %eax
	movq	-24(%rbp), %rdx
	movl	4(%rdx), %edx
.LBB158:
	cmpl	%eax, %edx
	.loc 1 4328 4 is_stmt 0 discriminator 3
	cmpl	%eax, %edx
	.loc 1 4328 4 discriminator 6
	cmpl	%eax, %edx
	.loc 1 4331 28 is_stmt 1
	cltq
	leaq	262143(%rax), %rcx
	movslq	%edx, %rax
	.loc 1 4331 57
	cmpq	%rax, %rcx
	jl	.L993
	.loc 1 4331 66 discriminator 1
	movzbl	-33(%rbp), %eax
	movl	%eax, %edi
	call	silver_library_reports__audit_of
	.loc 1 4331 66 is_stmt 0 discriminator 2
	movzbl	%al, %edx
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4331 57 is_stmt 1 discriminator 3
	testb	%al, %al
	je	.L993
	.loc 1 4331 57 is_stmt 0 discriminator 4
	movl	$1, %eax
	jmp	.L994
.L993:
	.loc 1 4331 57 discriminator 5
	movl	$0, %eax
.L994:
.LBE158:
	.loc 1 4332 8 is_stmt 1
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE46:
	.size	silver_library_reports__complete_runtime_proof, .-silver_library_reports__complete_runtime_proof
	.align 2
	.globl	silver_library_reports__complete_application_proof
	.type	silver_library_reports__complete_application_proof, @function
silver_library_reports__complete_application_proof:
.LFB47:
	.loc 1 4333 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 3, -24
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -32(%rbp)
	movq	%rbx, -24(%rbp)
	movb	%dl, -33(%rbp)
	.loc 1 4333 4
	movq	-24(%rbp), %rax
	movl	(%rax), %eax
	movq	-24(%rbp), %rdx
	movl	4(%rdx), %edx
.LBB159:
	cmpl	%eax, %edx
	.loc 1 4333 4 is_stmt 0 discriminator 3
	cmpl	%eax, %edx
	.loc 1 4333 4 discriminator 6
	cmpl	%eax, %edx
	.loc 1 4336 20 is_stmt 1
	cmpb	$3, -33(%rbp)
	jbe	.L1003
	.loc 1 4336 20 is_stmt 0 discriminator 1
	leaq	.LC39(%rip), %rax
	movl	$4336, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L1003:
	.loc 1 4336 20 discriminator 2
	cmpb	$3, -33(%rbp)
	jbe	.L1004
	.loc 1 4336 20 discriminator 3
	leaq	.LC39(%rip), %rax
	movl	$4336, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L1004:
	.loc 1 4336 15 is_stmt 1 discriminator 4
	cmpb	$2, -33(%rbp)
	je	.L1005
	cmpb	$2, -33(%rbp)
	ja	.L1006
	cmpb	$0, -33(%rbp)
	je	.L1007
	cmpb	$1, -33(%rbp)
	je	.L1008
	jmp	.L1006
.L1007:
	.loc 1 4337 31
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$11, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4340 11
	testb	%al, %al
	jne	.L1009
	.loc 1 4338 19
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$4, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4338 11 discriminator 1
	testb	%al, %al
	jne	.L1009
	.loc 1 4339 19
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$5, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4339 11 discriminator 1
	testb	%al, %al
	jne	.L1009
	.loc 1 4340 19 discriminator 1
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$6, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4340 11 discriminator 2
	testb	%al, %al
	je	.L1010
.L1009:
	.loc 1 4340 11 is_stmt 0 discriminator 3
	movl	$1, %eax
	.loc 1 4340 11 discriminator 5
	jmp	.L1012
.L1010:
	.loc 1 4340 11 discriminator 4
	movl	$0, %eax
	.loc 1 4340 11 discriminator 5
	jmp	.L1012
.L1008:
	.loc 1 4341 33 is_stmt 1
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$12, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4349 11
	testb	%al, %al
	jne	.L1013
	.loc 1 4342 19
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$10, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4342 11 discriminator 1
	testb	%al, %al
	jne	.L1013
	.loc 1 4343 19
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$7, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4343 11 discriminator 1
	testb	%al, %al
	jne	.L1013
	.loc 1 4344 19
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$8, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4344 11 discriminator 1
	testb	%al, %al
	jne	.L1013
	.loc 1 4345 19
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$9, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4345 11 discriminator 1
	testb	%al, %al
	jne	.L1013
	.loc 1 4346 19
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$13, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4346 11 discriminator 1
	testb	%al, %al
	jne	.L1013
	.loc 1 4347 19
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$14, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4347 11 discriminator 1
	testb	%al, %al
	jne	.L1013
	.loc 1 4348 19
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$15, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4348 11 discriminator 1
	testb	%al, %al
	jne	.L1013
	.loc 1 4349 19 discriminator 1
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$16, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4349 11 discriminator 2
	testb	%al, %al
	je	.L1014
.L1013:
	.loc 1 4349 11 is_stmt 0 discriminator 3
	movl	$1, %eax
	.loc 1 4349 11 discriminator 5
	jmp	.L1012
.L1014:
	.loc 1 4349 11 discriminator 4
	movl	$0, %eax
	.loc 1 4349 11 discriminator 5
	jmp	.L1012
.L1005:
	.loc 1 4350 33 is_stmt 1
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$17, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4353 11
	testb	%al, %al
	jne	.L1016
	.loc 1 4351 19
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$18, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4351 11 discriminator 1
	testb	%al, %al
	jne	.L1016
	.loc 1 4352 19
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$19, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4352 11 discriminator 1
	testb	%al, %al
	jne	.L1016
	.loc 1 4353 19 discriminator 1
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$20, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4353 11 discriminator 2
	testb	%al, %al
	je	.L1017
.L1016:
	.loc 1 4353 11 is_stmt 0 discriminator 3
	movl	$1, %eax
	.loc 1 4353 11 discriminator 5
	jmp	.L1012
.L1017:
	.loc 1 4353 11 discriminator 4
	movl	$0, %eax
	.loc 1 4353 11 discriminator 5
	jmp	.L1012
.L1006:
	.loc 1 4354 33 is_stmt 1
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$29, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4362 11
	testb	%al, %al
	jne	.L1019
	.loc 1 4355 19
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$24, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4355 11 discriminator 1
	testb	%al, %al
	jne	.L1019
	.loc 1 4356 19
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$21, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4356 11 discriminator 1
	testb	%al, %al
	jne	.L1019
	.loc 1 4357 19
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$22, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4357 11 discriminator 1
	testb	%al, %al
	jne	.L1019
	.loc 1 4358 19
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$23, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4358 11 discriminator 1
	testb	%al, %al
	jne	.L1019
	.loc 1 4359 19
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$25, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4359 11 discriminator 1
	testb	%al, %al
	jne	.L1019
	.loc 1 4360 19
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$26, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4360 11 discriminator 1
	testb	%al, %al
	jne	.L1019
	.loc 1 4361 19
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$27, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4361 11 discriminator 1
	testb	%al, %al
	jne	.L1019
	.loc 1 4362 19 discriminator 1
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movl	$28, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_library_reports__audit_report
	.loc 1 4362 11 discriminator 2
	testb	%al, %al
	je	.L1020
.L1019:
	.loc 1 4362 11 is_stmt 0 discriminator 3
	movl	$1, %eax
	.loc 1 4362 11 discriminator 5
	jmp	.L1012
.L1020:
	.loc 1 4362 11 discriminator 4
	movl	$0, %eax
.L1012:
.LBE159:
	.loc 1 4363 8 is_stmt 1
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE47:
	.size	silver_library_reports__complete_application_proof, .-silver_library_reports__complete_application_proof
	.align 2
	.globl	silver_library_reports__audit_of
	.type	silver_library_reports__audit_of, @function
silver_library_reports__audit_of:
.LFB48:
	.loc 1 23 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movb	%dil, -1(%rbp)
	.loc 1 24 12
	cmpb	$3, -1(%rbp)
	jbe	.L1023
	.loc 1 24 12 is_stmt 0 discriminator 1
	leaq	.LC39(%rip), %rax
	movl	$24, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L1023:
	.loc 1 24 12 discriminator 2
	cmpb	$3, -1(%rbp)
	jbe	.L1024
	.loc 1 24 12 discriminator 3
	leaq	.LC39(%rip), %rax
	movl	$24, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L1024:
	.loc 1 24 7 is_stmt 1 discriminator 4
	cmpb	$2, -1(%rbp)
	je	.L1025
	cmpb	$2, -1(%rbp)
	ja	.L1026
	cmpb	$0, -1(%rbp)
	je	.L1027
	cmpb	$1, -1(%rbp)
	je	.L1028
	jmp	.L1026
.L1027:
	.loc 1 25 30
	movl	$0, %eax
	jmp	.L1029
.L1028:
	.loc 1 26 36
	movl	$1, %eax
	jmp	.L1029
.L1025:
	.loc 1 27 32
	movl	$2, %eax
	jmp	.L1029
.L1026:
	.loc 1 28 35
	movl	$3, %eax
.L1029:
	.loc 1 23 4
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE48:
	.size	silver_library_reports__audit_of, .-silver_library_reports__audit_of
	.align 2
	.globl	silver_library_reports__valid
	.type	silver_library_reports__valid, @function
silver_library_reports__valid:
.LFB49:
	.loc 1 133 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	.cfi_offset 3, -24
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -32(%rbp)
	movq	%rbx, -24(%rbp)
	movq	%rdx, -40(%rbp)
	.loc 1 133 4
	movq	-24(%rbp), %rax
	movl	4(%rax), %edx
	movq	-24(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L1031
	.loc 1 133 4 is_stmt 0 discriminator 1
	movq	-24(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-24(%rbp), %rcx
	movl	(%rcx), %esi
	movslq	%esi, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L1032
.L1031:
	.loc 1 133 4 discriminator 2
	movl	$0, %eax
	movl	$0, %edx
.L1032:
	.loc 1 134 18 is_stmt 1
	movl	-40(%rbp), %ecx
	.loc 1 135 7
	testl	%ecx, %ecx
	jle	.L1033
	.loc 1 134 43 discriminator 1
	movl	-40(%rbp), %esi
	movl	-36(%rbp), %ecx
	.loc 1 134 23 discriminator 1
	cmpl	%ecx, %esi
	jg	.L1033
	.loc 1 135 26 discriminator 1
	movl	-36(%rbp), %ecx
	.loc 1 135 7 discriminator 1
	cmpl	%eax, %ecx
	jg	.L1033
	.loc 1 135 7 is_stmt 0 discriminator 2
	movl	$1, %eax
	jmp	.L1034
.L1033:
	.loc 1 135 7 discriminator 3
	movl	$0, %eax
.L1034:
	.loc 1 133 4 is_stmt 1
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE49:
	.size	silver_library_reports__valid, .-silver_library_reports__valid
	.align 2
	.globl	silver_library_reports__space
	.type	silver_library_reports__space, @function
silver_library_reports__space:
.LFB50:
	.loc 1 137 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movb	%dil, -1(%rbp)
	.loc 1 139 38
	cmpb	$32, -1(%rbp)
	je	.L1037
	.loc 1 138 15
	cmpb	$9, -1(%rbp)
	je	.L1037
	.loc 1 139 7 discriminator 1
	cmpb	$10, -1(%rbp)
	je	.L1037
	.loc 1 139 38 discriminator 2
	cmpb	$13, -1(%rbp)
	jne	.L1038
.L1037:
	.loc 1 139 38 is_stmt 0 discriminator 3
	movl	$1, %eax
	jmp	.L1039
.L1038:
	.loc 1 139 38 discriminator 4
	movl	$0, %eax
.L1039:
	.loc 1 137 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE50:
	.size	silver_library_reports__space, .-silver_library_reports__space
	.align 2
	.globl	silver_library_reports__merge_field
	.type	silver_library_reports__merge_field, @function
silver_library_reports__merge_field:
.LFB51:
	.loc 1 719 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	.loc 1 720 15
	movl	-8(%rbp), %eax
	.loc 1 720 7
	testl	%eax, %eax
	jne	.L1042
	.loc 1 720 15 discriminator 1
	movl	-4(%rbp), %eax
	cmpl	$1, %eax
	je	.L1043
.L1042:
	.loc 1 720 41 discriminator 2
	movl	-16(%rbp), %eax
	.loc 1 720 27 discriminator 2
	testl	%eax, %eax
	jne	.L1044
	.loc 1 720 41 discriminator 3
	movl	-12(%rbp), %eax
	cmpl	$1, %eax
	jne	.L1044
.L1043:
	.loc 1 720 58 discriminator 4
	movl	$0, %eax
	movl	%eax, %edx
	movabsq	$4294967296, %rax
	orq	%rdx, %rax
	jmp	.L1045
.L1044:
	.loc 1 721 18
	movl	-8(%rbp), %eax
	.loc 1 721 7
	testl	%eax, %eax
	jne	.L1046
	.loc 1 721 18 discriminator 1
	movl	-4(%rbp), %eax
	testl	%eax, %eax
	jne	.L1046
	.loc 1 721 33 discriminator 2
	movq	-16(%rbp), %rax
	jmp	.L1045
.L1046:
	.loc 1 722 19
	movl	-16(%rbp), %eax
	.loc 1 722 7
	testl	%eax, %eax
	jne	.L1047
	.loc 1 722 19 discriminator 1
	movl	-12(%rbp), %eax
	testl	%eax, %eax
	jne	.L1047
	.loc 1 722 34 discriminator 2
	movq	-8(%rbp), %rax
	jmp	.L1045
.L1047:
	.loc 1 722 44 discriminator 3
	movl	$0, %eax
	movl	%eax, %edx
	movabsq	$4294967296, %rax
	orq	%rdx, %rax
.L1045:
	.loc 1 719 4
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE51:
	.size	silver_library_reports__merge_field, .-silver_library_reports__merge_field
	.align 2
	.globl	silver_library_reports__entity_file
	.type	silver_library_reports__entity_file, @function
silver_library_reports__entity_file:
.LFB52:
	.loc 1 999 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movb	%dil, -33(%rbp)
	.loc 1 1000 12
	cmpb	$17, -33(%rbp)
	jbe	.L1049
	.loc 1 1000 12 is_stmt 0 discriminator 1
	leaq	.LC39(%rip), %rax
	movl	$1000, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L1049:
	.loc 1 1000 12 discriminator 2
	cmpb	$17, -33(%rbp)
	jbe	.L1050
	.loc 1 1000 12 discriminator 3
	leaq	.LC39(%rip), %rax
	movl	$1000, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L1050:
	.loc 1 1000 7 is_stmt 1 discriminator 4
	cmpb	$17, -33(%rbp)
	je	.L1051
	cmpb	$17, -33(%rbp)
	ja	.L1052
	cmpb	$16, -33(%rbp)
	ja	.L1052
	cmpb	$13, -33(%rbp)
	jnb	.L1053
	cmpb	$12, -33(%rbp)
	je	.L1054
	cmpb	$12, -33(%rbp)
	ja	.L1052
	cmpb	$11, -33(%rbp)
	ja	.L1052
	cmpb	$8, -33(%rbp)
	jnb	.L1055
	cmpb	$3, -33(%rbp)
	ja	.L1056
	cmpb	$0, -33(%rbp)
	jne	.L1057
	jmp	.L1052
.L1056:
	movzbl	-33(%rbp), %eax
	subl	$4, %eax
	cmpb	$3, %al
	ja	.L1052
	jmp	.L1060
.L1057:
	.loc 1 1001 45
	movl	$4, %esi
	movl	$24, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 1001 45 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$13, 4(%rax)
	movabsq	$7592913276874025331, %rbx
	movq	%rbx, 8(%rax)
	movabsq	$8314877664098344818, %rbx
	movq	%rbx, 13(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L1059
.L1060:
	.loc 1 1002 67 is_stmt 1
	movl	$4, %esi
	movl	$32, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 1002 67 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$22, 4(%rax)
	movq	silver_library_reports__atom_silver_output_libc_ads(%rip), %rcx
	movq	8+silver_library_reports__atom_silver_output_libc_ads(%rip), %rbx
	movq	%rcx, 8(%rax)
	movq	%rbx, 16(%rax)
	movq	14+silver_library_reports__atom_silver_output_libc_ads(%rip), %rcx
	movq	%rcx, 22(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L1059
.L1055:
	.loc 1 1003 80 is_stmt 1
	movl	$4, %esi
	movl	$28, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 1003 80 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$20, 4(%rax)
	movq	silver_library_reports__atom_silver_arguments_ads(%rip), %rcx
	movq	8+silver_library_reports__atom_silver_arguments_ads(%rip), %rbx
	movq	%rcx, 8(%rax)
	movq	%rbx, 16(%rax)
	movl	16+silver_library_reports__atom_silver_arguments_ads(%rip), %ecx
	movl	%ecx, 24(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L1059
.L1054:
	.loc 1 1004 28 is_stmt 1
	movl	$4, %esi
	movl	$28, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 1004 28 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$20, 4(%rax)
	movq	silver_library_reports__atom_silver_arguments_adb(%rip), %rcx
	movq	8+silver_library_reports__atom_silver_arguments_adb(%rip), %rbx
	movq	%rcx, 8(%rax)
	movq	%rbx, 16(%rax)
	movl	16+silver_library_reports__atom_silver_arguments_adb(%rip), %ecx
	movl	%ecx, 24(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L1059
.L1053:
	.loc 1 1005 83 is_stmt 1
	movl	$4, %esi
	movl	$28, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 1005 83 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$18, 4(%rax)
	movq	silver_library_reports__atom_silver_runtime_ads(%rip), %rcx
	movq	8+silver_library_reports__atom_silver_runtime_ads(%rip), %rbx
	movq	%rcx, 8(%rax)
	movq	%rbx, 16(%rax)
	movzwl	16+silver_library_reports__atom_silver_runtime_ads(%rip), %ecx
	movw	%cx, 24(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L1059
.L1051:
	.loc 1 1006 29 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 1006 29 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$8, 4(%rax)
	movabsq	$7089898565436793197, %rbx
	movq	%rbx, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L1059
.L1052:
	.loc 1 1007 25 is_stmt 1
	movl	$4, %esi
	movl	$8, %edi
	call	system__secondary_stack__ss_allocate@PLT
	.loc 1 1007 25 is_stmt 0 discriminator 1
	movq	%rax, %rdx
	movl	$1, (%rdx)
	movl	$0, 4(%rdx)
	movq	%rax, %rdx
	addq	$8, %rdx
	movq	%rdx, %r12
	movq	%rax, %r13
.L1059:
	.loc 1 999 4 is_stmt 1
	movq	%r12, %rax
	movq	%r13, %rdx
	addq	$24, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE52:
	.size	silver_library_reports__entity_file, .-silver_library_reports__entity_file
	.align 2
	.globl	silver_library_reports__expected_entity
	.type	silver_library_reports__expected_entity, @function
silver_library_reports__expected_entity:
.LFB53:
	.loc 1 1587 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movb	%dil, -1(%rbp)
	movb	%sil, -2(%rbp)
	.loc 1 1589 12
	cmpb	$29, -2(%rbp)
	jbe	.L1062
	.loc 1 1589 12 is_stmt 0 discriminator 1
	leaq	.LC39(%rip), %rax
	movl	$1589, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L1062:
	.loc 1 1589 12 discriminator 2
	cmpb	$29, -2(%rbp)
	jbe	.L1063
	.loc 1 1589 12 discriminator 3
	leaq	.LC39(%rip), %rax
	movl	$1589, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L1063:
	.loc 1 1589 7 is_stmt 1 discriminator 4
	cmpb	$29, -2(%rbp)
	je	.L1064
	cmpb	$29, -2(%rbp)
	ja	.L1065
	cmpb	$28, -2(%rbp)
	je	.L1066
	cmpb	$28, -2(%rbp)
	ja	.L1065
	cmpb	$27, -2(%rbp)
	je	.L1067
	cmpb	$27, -2(%rbp)
	ja	.L1065
	cmpb	$26, -2(%rbp)
	je	.L1068
	cmpb	$26, -2(%rbp)
	ja	.L1065
	cmpb	$25, -2(%rbp)
	je	.L1069
	cmpb	$25, -2(%rbp)
	ja	.L1065
	cmpb	$24, -2(%rbp)
	je	.L1070
	cmpb	$24, -2(%rbp)
	ja	.L1065
	cmpb	$23, -2(%rbp)
	je	.L1071
	cmpb	$23, -2(%rbp)
	ja	.L1065
	cmpb	$22, -2(%rbp)
	je	.L1072
	cmpb	$22, -2(%rbp)
	ja	.L1065
	cmpb	$21, -2(%rbp)
	je	.L1073
	cmpb	$21, -2(%rbp)
	ja	.L1065
	cmpb	$19, -2(%rbp)
	je	.L1074
	cmpb	$19, -2(%rbp)
	ja	.L1065
	cmpb	$18, -2(%rbp)
	je	.L1075
	cmpb	$18, -2(%rbp)
	ja	.L1065
	cmpb	$17, -2(%rbp)
	je	.L1064
	cmpb	$17, -2(%rbp)
	ja	.L1065
	cmpb	$16, -2(%rbp)
	je	.L1066
	cmpb	$16, -2(%rbp)
	ja	.L1065
	cmpb	$15, -2(%rbp)
	je	.L1067
	cmpb	$15, -2(%rbp)
	ja	.L1065
	cmpb	$14, -2(%rbp)
	je	.L1068
	cmpb	$14, -2(%rbp)
	ja	.L1065
	cmpb	$13, -2(%rbp)
	je	.L1069
	cmpb	$13, -2(%rbp)
	ja	.L1065
	cmpb	$12, -2(%rbp)
	ja	.L1065
	cmpb	$11, -2(%rbp)
	jnb	.L1064
	cmpb	$10, -2(%rbp)
	je	.L1070
	cmpb	$10, -2(%rbp)
	ja	.L1065
	cmpb	$9, -2(%rbp)
	je	.L1071
	cmpb	$9, -2(%rbp)
	ja	.L1065
	cmpb	$8, -2(%rbp)
	je	.L1072
	cmpb	$8, -2(%rbp)
	ja	.L1065
	cmpb	$7, -2(%rbp)
	je	.L1073
	cmpb	$7, -2(%rbp)
	ja	.L1065
	cmpb	$5, -2(%rbp)
	je	.L1074
	cmpb	$5, -2(%rbp)
	ja	.L1065
	cmpb	$4, -2(%rbp)
	je	.L1075
	cmpb	$4, -2(%rbp)
	ja	.L1065
	cmpb	$3, -2(%rbp)
	je	.L1076
	cmpb	$3, -2(%rbp)
	ja	.L1065
	cmpb	$2, -2(%rbp)
	je	.L1077
	cmpb	$2, -2(%rbp)
	ja	.L1065
	cmpb	$0, -2(%rbp)
	je	.L1078
	cmpb	$1, -2(%rbp)
	je	.L1079
	jmp	.L1065
.L1078:
	.loc 1 1590 82
	cmpb	$1, -1(%rbp)
	je	.L1080
	.loc 1 1590 46 discriminator 1
	cmpb	$2, -1(%rbp)
	je	.L1080
	.loc 1 1590 57 discriminator 2
	cmpb	$3, -1(%rbp)
	je	.L1080
	.loc 1 1590 63 discriminator 3
	cmpb	$5, -1(%rbp)
	je	.L1080
	.loc 1 1590 74 discriminator 4
	cmpb	$6, -1(%rbp)
	je	.L1080
	.loc 1 1590 82 discriminator 5
	cmpb	$7, -1(%rbp)
	jne	.L1081
.L1080:
	.loc 1 1590 82 is_stmt 0 discriminator 6
	movl	$1, %eax
	.loc 1 1590 82 discriminator 8
	jmp	.L1083
.L1081:
	.loc 1 1590 82 discriminator 7
	movl	$0, %eax
	.loc 1 1590 82 discriminator 8
	jmp	.L1083
.L1079:
	.loc 1 1591 74 is_stmt 1
	cmpb	$4, -1(%rbp)
	je	.L1084
	.loc 1 1591 55 discriminator 1
	cmpb	$5, -1(%rbp)
	je	.L1084
	.loc 1 1591 66 discriminator 2
	cmpb	$6, -1(%rbp)
	je	.L1084
	.loc 1 1591 74 discriminator 3
	cmpb	$7, -1(%rbp)
	jne	.L1085
.L1084:
	.loc 1 1591 74 is_stmt 0 discriminator 4
	movl	$1, %eax
	.loc 1 1591 74 discriminator 6
	jmp	.L1083
.L1085:
	.loc 1 1591 74 discriminator 5
	movl	$0, %eax
	.loc 1 1591 74 discriminator 6
	jmp	.L1083
.L1077:
	.loc 1 1593 70 is_stmt 1
	cmpb	$8, -1(%rbp)
	je	.L1087
	.loc 1 1592 59 discriminator 1
	cmpb	$9, -1(%rbp)
	je	.L1087
	.loc 1 1592 76 discriminator 2
	cmpb	$10, -1(%rbp)
	je	.L1087
	.loc 1 1593 13 discriminator 1
	cmpb	$11, -1(%rbp)
	je	.L1087
	.loc 1 1593 22 discriminator 2
	cmpb	$12, -1(%rbp)
	je	.L1087
	.loc 1 1593 35 discriminator 3
	cmpb	$7, -1(%rbp)
	je	.L1087
	.loc 1 1593 53 discriminator 4
	cmpb	$14, -1(%rbp)
	je	.L1087
	.loc 1 1593 70 discriminator 5
	cmpb	$15, -1(%rbp)
	jne	.L1088
.L1087:
	.loc 1 1593 70 is_stmt 0 discriminator 6
	movl	$1, %eax
	.loc 1 1593 70 discriminator 8
	jmp	.L1083
.L1088:
	.loc 1 1593 70 discriminator 7
	movl	$0, %eax
	.loc 1 1593 70 discriminator 8
	jmp	.L1083
.L1076:
	.loc 1 1594 86 is_stmt 1
	cmpb	$13, -1(%rbp)
	je	.L1090
	.loc 1 1594 58 discriminator 1
	cmpb	$14, -1(%rbp)
	je	.L1090
	.loc 1 1594 75 discriminator 2
	cmpb	$15, -1(%rbp)
	je	.L1090
	.loc 1 1594 86 discriminator 3
	cmpb	$16, -1(%rbp)
	jne	.L1091
.L1090:
	.loc 1 1594 86 is_stmt 0 discriminator 4
	movl	$1, %eax
	.loc 1 1594 86 discriminator 6
	jmp	.L1083
.L1091:
	.loc 1 1594 86 discriminator 5
	movl	$0, %eax
	.loc 1 1594 86 discriminator 6
	jmp	.L1083
.L1073:
	.loc 1 1596 78 is_stmt 1
	cmpb	$17, -1(%rbp)
	je	.L1093
	.loc 1 1596 33 discriminator 1
	cmpb	$10, -1(%rbp)
	je	.L1093
	.loc 1 1596 52 discriminator 2
	cmpb	$9, -1(%rbp)
	je	.L1093
	.loc 1 1596 69 discriminator 3
	cmpb	$11, -1(%rbp)
	je	.L1093
	.loc 1 1596 78 discriminator 4
	cmpb	$2, -1(%rbp)
	jne	.L1094
.L1093:
	.loc 1 1596 78 is_stmt 0 discriminator 5
	movl	$1, %eax
	.loc 1 1596 78 discriminator 7
	jmp	.L1083
.L1094:
	.loc 1 1596 78 discriminator 6
	movl	$0, %eax
	.loc 1 1596 78 discriminator 7
	jmp	.L1083
.L1072:
	.loc 1 1598 78 is_stmt 1
	cmpb	$17, -1(%rbp)
	je	.L1096
	.loc 1 1598 33 discriminator 1
	cmpb	$10, -1(%rbp)
	je	.L1096
	.loc 1 1598 52 discriminator 2
	cmpb	$9, -1(%rbp)
	je	.L1096
	.loc 1 1598 69 discriminator 3
	cmpb	$11, -1(%rbp)
	je	.L1096
	.loc 1 1598 78 discriminator 4
	cmpb	$3, -1(%rbp)
	jne	.L1097
.L1096:
	.loc 1 1598 78 is_stmt 0 discriminator 5
	movl	$1, %eax
	.loc 1 1598 78 discriminator 7
	jmp	.L1083
.L1097:
	.loc 1 1598 78 discriminator 6
	movl	$0, %eax
	.loc 1 1598 78 discriminator 7
	jmp	.L1083
.L1071:
	.loc 1 1600 89 is_stmt 1
	cmpb	$17, -1(%rbp)
	je	.L1099
	.loc 1 1600 33 discriminator 1
	cmpb	$10, -1(%rbp)
	je	.L1099
	.loc 1 1600 52 discriminator 2
	cmpb	$9, -1(%rbp)
	je	.L1099
	.loc 1 1600 69 discriminator 3
	cmpb	$11, -1(%rbp)
	je	.L1099
	.loc 1 1600 78 discriminator 4
	cmpb	$2, -1(%rbp)
	je	.L1099
	.loc 1 1600 89 discriminator 5
	cmpb	$3, -1(%rbp)
	jne	.L1100
.L1099:
	.loc 1 1600 89 is_stmt 0 discriminator 6
	movl	$1, %eax
	.loc 1 1600 89 discriminator 8
	jmp	.L1083
.L1100:
	.loc 1 1600 89 discriminator 7
	movl	$0, %eax
	.loc 1 1600 89 discriminator 8
	jmp	.L1083
.L1069:
	.loc 1 1602 61 is_stmt 1
	cmpb	$17, -1(%rbp)
	je	.L1102
	.loc 1 1602 33 discriminator 1
	cmpb	$10, -1(%rbp)
	je	.L1102
	.loc 1 1602 52 discriminator 2
	cmpb	$11, -1(%rbp)
	je	.L1102
	.loc 1 1602 61 discriminator 3
	cmpb	$2, -1(%rbp)
	jne	.L1103
.L1102:
	.loc 1 1602 61 is_stmt 0 discriminator 4
	movl	$1, %eax
	.loc 1 1602 61 discriminator 6
	jmp	.L1083
.L1103:
	.loc 1 1602 61 discriminator 5
	movl	$0, %eax
	.loc 1 1602 61 discriminator 6
	jmp	.L1083
.L1068:
	.loc 1 1604 61 is_stmt 1
	cmpb	$17, -1(%rbp)
	je	.L1105
	.loc 1 1604 33 discriminator 1
	cmpb	$10, -1(%rbp)
	je	.L1105
	.loc 1 1604 52 discriminator 2
	cmpb	$11, -1(%rbp)
	je	.L1105
	.loc 1 1604 61 discriminator 3
	cmpb	$3, -1(%rbp)
	jne	.L1106
.L1105:
	.loc 1 1604 61 is_stmt 0 discriminator 4
	movl	$1, %eax
	.loc 1 1604 61 discriminator 6
	jmp	.L1083
.L1106:
	.loc 1 1604 61 discriminator 5
	movl	$0, %eax
	.loc 1 1604 61 discriminator 6
	jmp	.L1083
.L1067:
	.loc 1 1606 72 is_stmt 1
	cmpb	$17, -1(%rbp)
	je	.L1108
	.loc 1 1606 33 discriminator 1
	cmpb	$10, -1(%rbp)
	je	.L1108
	.loc 1 1606 52 discriminator 2
	cmpb	$11, -1(%rbp)
	je	.L1108
	.loc 1 1606 61 discriminator 3
	cmpb	$2, -1(%rbp)
	je	.L1108
	.loc 1 1606 72 discriminator 4
	cmpb	$3, -1(%rbp)
	jne	.L1109
.L1108:
	.loc 1 1606 72 is_stmt 0 discriminator 5
	movl	$1, %eax
	.loc 1 1606 72 discriminator 7
	jmp	.L1083
.L1109:
	.loc 1 1606 72 discriminator 6
	movl	$0, %eax
	.loc 1 1606 72 discriminator 7
	jmp	.L1083
.L1066:
	.loc 1 1608 52 is_stmt 1
	cmpb	$17, -1(%rbp)
	je	.L1111
	.loc 1 1608 33 discriminator 1
	cmpb	$10, -1(%rbp)
	je	.L1111
	.loc 1 1608 52 discriminator 2
	cmpb	$11, -1(%rbp)
	jne	.L1112
.L1111:
	.loc 1 1608 52 is_stmt 0 discriminator 3
	movl	$1, %eax
	.loc 1 1608 52 discriminator 5
	jmp	.L1083
.L1112:
	.loc 1 1608 52 discriminator 4
	movl	$0, %eax
	.loc 1 1608 52 discriminator 5
	jmp	.L1083
.L1070:
	.loc 1 1610 69 is_stmt 1
	cmpb	$17, -1(%rbp)
	je	.L1114
	.loc 1 1610 33 discriminator 1
	cmpb	$10, -1(%rbp)
	je	.L1114
	.loc 1 1610 52 discriminator 2
	cmpb	$9, -1(%rbp)
	je	.L1114
	.loc 1 1610 69 discriminator 3
	cmpb	$11, -1(%rbp)
	jne	.L1115
.L1114:
	.loc 1 1610 69 is_stmt 0 discriminator 4
	movl	$1, %eax
	.loc 1 1610 69 discriminator 6
	jmp	.L1083
.L1115:
	.loc 1 1610 69 discriminator 5
	movl	$0, %eax
	.loc 1 1610 69 discriminator 6
	jmp	.L1083
.L1064:
	.loc 1 1612 16 is_stmt 1
	cmpb	$17, -1(%rbp)
	sete	%al
	jmp	.L1083
.L1075:
	.loc 1 1613 72
	cmpb	$17, -1(%rbp)
	je	.L1117
	.loc 1 1613 72 is_stmt 0 discriminator 1
	cmpb	$2, -1(%rbp)
	jne	.L1118
.L1117:
	.loc 1 1613 72 discriminator 2
	movl	$1, %eax
	.loc 1 1613 72 discriminator 4
	jmp	.L1083
.L1118:
	.loc 1 1613 72 discriminator 3
	movl	$0, %eax
	.loc 1 1613 72 discriminator 4
	jmp	.L1083
.L1074:
	.loc 1 1614 67 is_stmt 1
	cmpb	$17, -1(%rbp)
	je	.L1120
	.loc 1 1614 67 is_stmt 0 discriminator 1
	cmpb	$3, -1(%rbp)
	jne	.L1121
.L1120:
	.loc 1 1614 67 discriminator 2
	movl	$1, %eax
	.loc 1 1614 67 discriminator 4
	jmp	.L1083
.L1121:
	.loc 1 1614 67 discriminator 3
	movl	$0, %eax
	.loc 1 1614 67 discriminator 4
	jmp	.L1083
.L1065:
	.loc 1 1615 82 is_stmt 1
	cmpb	$17, -1(%rbp)
	je	.L1123
	.loc 1 1615 71 discriminator 1
	cmpb	$2, -1(%rbp)
	je	.L1123
	.loc 1 1615 82 discriminator 2
	cmpb	$3, -1(%rbp)
	jne	.L1124
.L1123:
	.loc 1 1615 82 is_stmt 0 discriminator 3
	movl	$1, %eax
	.loc 1 1615 82 discriminator 5
	jmp	.L1083
.L1124:
	.loc 1 1615 82 discriminator 4
	movl	$0, %eax
.L1083:
	.loc 1 1587 4 is_stmt 1
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE53:
	.size	silver_library_reports__expected_entity, .-silver_library_reports__expected_entity
	.align 2
	.globl	silver_library_reports__expected_coverage
	.type	silver_library_reports__expected_coverage, @function
silver_library_reports__expected_coverage:
.LFB54:
	.loc 1 1617 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	subq	$16, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	movb	%dil, -17(%rbp)
	movb	%sil, -18(%rbp)
	.loc 1 1619 12
	cmpb	$29, -18(%rbp)
	jbe	.L1127
	.loc 1 1619 12 is_stmt 0 discriminator 1
	leaq	.LC39(%rip), %rax
	movl	$1619, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L1127:
	.loc 1 1619 12 discriminator 2
	cmpb	$29, -18(%rbp)
	jbe	.L1128
	.loc 1 1619 12 discriminator 3
	leaq	.LC39(%rip), %rax
	movl	$1619, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L1128:
	.loc 1 1619 7 is_stmt 1 discriminator 4
	cmpb	$3, -18(%rbp)
	je	.L1129
	cmpb	$3, -18(%rbp)
	ja	.L1130
	cmpb	$2, -18(%rbp)
	je	.L1131
	cmpb	$2, -18(%rbp)
	ja	.L1130
	cmpb	$0, -18(%rbp)
	je	.L1132
	cmpb	$1, -18(%rbp)
	je	.L1133
	jmp	.L1130
.L1132:
	.loc 1 1620 26
	cmpb	$1, -17(%rbp)
	je	.L1134
	.loc 1 1620 50 discriminator 1
	cmpb	$2, -17(%rbp)
	je	.L1134
	.loc 1 1620 61 discriminator 2
	cmpb	$3, -17(%rbp)
	jne	.L1135
.L1134:
	.loc 1 1620 70 discriminator 3
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 1620 70 is_stmt 0 discriminator 4
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$27745, 8(%rax)
	movb	$108, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L1136
.L1135:
	.loc 1 1620 84 is_stmt 1 discriminator 5
	movl	$4, %esi
	movl	$8, %edi
	call	system__secondary_stack__ss_allocate@PLT
	.loc 1 1620 84 is_stmt 0 discriminator 6
	movq	%rax, %rdx
	movl	$1, (%rdx)
	movl	$0, 4(%rdx)
	movq	%rax, %rdx
	addq	$8, %rdx
	movq	%rdx, %r12
	movq	%rax, %r13
	jmp	.L1136
.L1133:
	.loc 1 1622 12 is_stmt 1
	cmpb	$4, -17(%rbp)
	jne	.L1137
	.loc 1 1622 40 discriminator 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 1622 40 is_stmt 0 discriminator 2
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$27745, 8(%rax)
	movb	$108, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L1136
.L1137:
	.loc 1 1623 12 is_stmt 1
	cmpb	$5, -17(%rbp)
	je	.L1138
	.loc 1 1623 37 discriminator 1
	cmpb	$6, -17(%rbp)
	je	.L1138
	.loc 1 1623 45 discriminator 2
	cmpb	$7, -17(%rbp)
	jne	.L1139
.L1138:
	.loc 1 1623 66 discriminator 3
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 1623 66 is_stmt 0 discriminator 4
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1667592307, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L1136
.L1139:
	.loc 1 1623 81 is_stmt 1 discriminator 5
	movl	$4, %esi
	movl	$8, %edi
	call	system__secondary_stack__ss_allocate@PLT
	.loc 1 1623 81 is_stmt 0 discriminator 6
	movq	%rax, %rdx
	movl	$1, (%rdx)
	movl	$0, 4(%rdx)
	movq	%rax, %rdx
	addq	$8, %rdx
	movq	%rdx, %r12
	movq	%rax, %r13
	jmp	.L1136
.L1131:
	.loc 1 1625 12 is_stmt 1
	cmpb	$8, -17(%rbp)
	je	.L1140
	.loc 1 1625 43 discriminator 1
	cmpb	$9, -17(%rbp)
	je	.L1140
	.loc 1 1625 60 discriminator 2
	cmpb	$10, -17(%rbp)
	je	.L1140
	.loc 1 1625 79 discriminator 3
	cmpb	$11, -17(%rbp)
	je	.L1140
	.loc 1 1625 88 discriminator 4
	cmpb	$12, -17(%rbp)
	jne	.L1141
.L1140:
	.loc 1 1626 17
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 1626 17 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$27745, 8(%rax)
	movb	$108, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L1136
.L1141:
	.loc 1 1626 31 is_stmt 1 discriminator 2
	movl	$4, %esi
	movl	$8, %edi
	call	system__secondary_stack__ss_allocate@PLT
	.loc 1 1626 31 is_stmt 0 discriminator 3
	movq	%rax, %rdx
	movl	$1, (%rdx)
	movl	$0, 4(%rdx)
	movq	%rax, %rdx
	addq	$8, %rdx
	movq	%rdx, %r12
	movq	%rax, %r13
	jmp	.L1136
.L1129:
	.loc 1 1628 12 is_stmt 1
	cmpb	$13, -17(%rbp)
	jne	.L1142
	.loc 1 1628 43 discriminator 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 1628 43 is_stmt 0 discriminator 2
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$27745, 8(%rax)
	movb	$108, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L1136
.L1142:
	.loc 1 1629 12 is_stmt 1
	cmpb	$14, -17(%rbp)
	je	.L1143
	.loc 1 1629 43 discriminator 1
	cmpb	$15, -17(%rbp)
	je	.L1143
	.loc 1 1629 54 discriminator 2
	cmpb	$16, -17(%rbp)
	jne	.L1144
.L1143:
	.loc 1 1629 79 discriminator 3
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 1629 79 is_stmt 0 discriminator 4
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1667592307, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L1136
.L1144:
	.loc 1 1629 94 is_stmt 1 discriminator 5
	movl	$4, %esi
	movl	$8, %edi
	call	system__secondary_stack__ss_allocate@PLT
	.loc 1 1629 94 is_stmt 0 discriminator 6
	movq	%rax, %rdx
	movl	$1, (%rdx)
	movl	$0, 4(%rdx)
	movq	%rax, %rdx
	addq	$8, %rdx
	movq	%rdx, %r12
	movq	%rax, %r13
	jmp	.L1136
.L1130:
	.loc 1 1630 36 is_stmt 1
	cmpb	$17, -17(%rbp)
	jne	.L1145
	.loc 1 1630 63 discriminator 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 1630 63 is_stmt 0 discriminator 2
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$27745, 8(%rax)
	movb	$108, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L1136
.L1145:
	.loc 1 1630 77 is_stmt 1 discriminator 3
	movl	$4, %esi
	movl	$8, %edi
	call	system__secondary_stack__ss_allocate@PLT
	.loc 1 1630 77 is_stmt 0 discriminator 4
	movq	%rax, %rdx
	movl	$1, (%rdx)
	movl	$0, 4(%rdx)
	movq	%rax, %rdx
	addq	$8, %rdx
	movq	%rdx, %r12
	movq	%rax, %r13
.L1136:
	.loc 1 1617 4 is_stmt 1
	movq	%r12, %rax
	movq	%r13, %rdx
	addq	$16, %rsp
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE54:
	.size	silver_library_reports__expected_coverage, .-silver_library_reports__expected_coverage
	.globl	silver_library_reports_E
	.data
	.align 2
	.type	silver_library_reports_E, @object
	.size	silver_library_reports_E, 2
silver_library_reports_E:
	.zero	2
	.globl	silver_library_reports__max_report_length
	.section	.rodata
	.align 4
	.type	silver_library_reports__max_report_length, @object
	.size	silver_library_reports__max_report_length, 4
silver_library_reports__max_report_length:
	.long	16777216
	.globl	silver_library_reports__max_runtime_report_length
	.align 4
	.type	silver_library_reports__max_runtime_report_length, @object
	.size	silver_library_reports__max_runtime_report_length, 4
silver_library_reports__max_runtime_report_length:
	.long	262144
	.globl	silver_library_reports__report_kindS
	.align 32
	.type	silver_library_reports__report_kindS, @object
	.size	silver_library_reports__report_kindS, 61
silver_library_reports__report_kindS:
	.ascii	"LIBRARY_BODYIMPORTED_INTERFACEARGUMENTS_BODYRUNTIME_INTERFAC"
	.ascii	"E"
	.globl	silver_library_reports__report_kindN
	.align 8
	.type	silver_library_reports__report_kindN, @object
	.size	silver_library_reports__report_kindN, 8
silver_library_reports__report_kindN:
	.byte	1
	.byte	13
	.byte	31
	.byte	45
	.byte	62
	.zero	3
	.globl	silver_library_reports__audit_kindS
	.align 32
	.type	silver_library_reports__audit_kindS, @object
	.size	silver_library_reports__audit_kindS, 508
silver_library_reports__audit_kindS:
	.ascii	"IO_BODYLIBC_INTERFACEARGUMENT_BODYARGV_INTERFACESTATIC_MAINS"
	.ascii	"TATIC_PUTSTATIC_MIXEDMAIN_BODYMAIN_PUTMAIN_MIXEDARGUMENT_EFF"
	.ascii	"ECTSBINDING_MAINARGUMENT_BINDING_MAINARGUMENT_WITHOUT_QUERYA"
	.ascii	"RGUMENT_PUT_WITHOUT_QUERYARGUMENT_MIXED_WITHOUT_QUERYARGUMEN"
	.ascii	"T_EFFECTS_WITHOUT_QUERYASSIGNMENT_MAINASSIGNMENT_EFFECTSASSI"
	.ascii	"GNMENT_PUTASSIGNMENT_MIXEDSELECTED_MAINSELECTED_PUTSELECTED_"
	.ascii	"MIXEDSELECTED_EFFECTSSELECTED_WITHOUT_QUERYSELECTED_PUT_WITH"
	.ascii	"OUT_QUERYSELECTED_MIXED_WITHOUT_QUERYSELECTED_EFFECTS_WITHOU"
	.ascii	"T_QUERYSELECTED_BINDING_MAIN"
	.globl	silver_library_reports__audit_kindN
	.align 32
	.type	silver_library_reports__audit_kindN, @object
	.size	silver_library_reports__audit_kindN, 62
silver_library_reports__audit_kindN:
	.value	1
	.value	8
	.value	22
	.value	35
	.value	49
	.value	60
	.value	70
	.value	82
	.value	91
	.value	99
	.value	109
	.value	125
	.value	137
	.value	158
	.value	180
	.value	206
	.value	234
	.value	264
	.value	279
	.value	297
	.value	311
	.value	327
	.value	340
	.value	352
	.value	366
	.value	382
	.value	404
	.value	430
	.value	458
	.value	488
	.value	509
	.globl	silver_library_reports__atom_empty
	.type	silver_library_reports__atom_empty, @object
	.size	silver_library_reports__atom_empty, 1
silver_library_reports__atom_empty:
	.zero	1
	.globl	silver_library_reports__initialization_prefix
	.align 16
	.type	silver_library_reports__initialization_prefix, @object
	.size	silver_library_reports__initialization_prefix, 21
silver_library_reports__initialization_prefix:
	.ascii	"\"initialization of \\\""
	.globl	silver_library_reports__initialization_suffix
	.align 16
	.type	silver_library_reports__initialization_suffix, @object
	.size	silver_library_reports__initialization_suffix, 17
silver_library_reports__initialization_suffix:
	.ascii	"\\\" has no effect\""
	.globl	silver_library_reports__atom_imprecise_image
	.align 16
	.type	silver_library_reports__atom_imprecise_image, @object
	.size	silver_library_reports__atom_imprecise_image, 16
silver_library_reports__atom_imprecise_image:
	.ascii	"imprecise-image"
	.zero	1
	.globl	silver_library_reports__atom_image_message
	.align 32
	.type	silver_library_reports__atom_image_message, @object
	.size	silver_library_reports__atom_image_message, 194
silver_library_reports__atom_image_message:
	.ascii	"references to the \\\"Image\\\" attribute are handled in an "
	.ascii	"imprecise way, so nothing will be known about the evaluation"
	.ascii	" of the attribute reference apart from a bound on its length"
	.ascii	" [imprecise-image]"
	.globl	silver_library_reports__atom_unknown
	.align 8
	.type	silver_library_reports__atom_unknown, @object
	.size	silver_library_reports__atom_unknown, 8
silver_library_reports__atom_unknown:
	.ascii	"unknown"
	.zero	1
	.globl	silver_library_reports__atom_ineffective
	.align 16
	.type	silver_library_reports__atom_ineffective, @object
	.size	silver_library_reports__atom_ineffective, 16
silver_library_reports__atom_ineffective:
	.ascii	"INEFFECTIVE"
	.zero	5
	.globl	silver_library_reports__atom_dead_code
	.align 16
	.type	silver_library_reports__atom_dead_code, @object
	.size	silver_library_reports__atom_dead_code, 16
silver_library_reports__atom_dead_code:
	.ascii	"DEAD_CODE"
	.zero	7
	.globl	silver_library_reports__atom_statement_no_effect
	.align 16
	.type	silver_library_reports__atom_statement_no_effect, @object
	.size	silver_library_reports__atom_statement_no_effect, 23
silver_library_reports__atom_statement_no_effect:
	.ascii	"statement has no effect"
	.globl	silver_library_reports__atom_statement_unreachable
	.align 16
	.type	silver_library_reports__atom_statement_unreachable, @object
	.size	silver_library_reports__atom_statement_unreachable, 31
silver_library_reports__atom_statement_unreachable:
	.ascii	"this statement is never reached"
	.globl	silver_library_reports__atom_warning
	.align 8
	.type	silver_library_reports__atom_warning, @object
	.size	silver_library_reports__atom_warning, 8
silver_library_reports__atom_warning:
	.ascii	"warning"
	.zero	1
	.globl	silver_library_reports__atom_unused_assignment
	.align 16
	.type	silver_library_reports__atom_unused_assignment, @object
	.size	silver_library_reports__atom_unused_assignment, 17
silver_library_reports__atom_unused_assignment:
	.ascii	"unused assignment"
	.globl	silver_library_reports__atom_unused_written_count
	.align 32
	.type	silver_library_reports__atom_unused_written_count, @object
	.size	silver_library_reports__atom_unused_written_count, 68
silver_library_reports__atom_unused_written_count:
	.ascii	"\\\"Written_Count\\\" is set by \\\"Put_Line\\\" but not use"
	.ascii	"d after the call"
	.globl	silver_library_reports__atom_unused_flushed
	.align 32
	.type	silver_library_reports__atom_unused_flushed, @object
	.size	silver_library_reports__atom_unused_flushed, 62
silver_library_reports__atom_unused_flushed:
	.ascii	"\\\"Flushed\\\" is set by \\\"Put_Line\\\" but not used afte"
	.ascii	"r the call"
	.globl	silver_library_reports__atom_unused_succeeded
	.align 32
	.type	silver_library_reports__atom_unused_succeeded, @object
	.size	silver_library_reports__atom_unused_succeeded, 64
silver_library_reports__atom_unused_succeeded:
	.ascii	"\\\"Succeeded\\\" is set by \\\"Put_Line\\\" but not used af"
	.ascii	"ter the call"
	.globl	silver_library_reports__atom_unused_written_bytes
	.align 32
	.type	silver_library_reports__atom_unused_written_bytes, @object
	.size	silver_library_reports__atom_unused_written_bytes, 68
silver_library_reports__atom_unused_written_bytes:
	.ascii	"\\\"Written_Bytes\\\" is set by \\\"Put_Line\\\" but not use"
	.ascii	"d after the call"
	.globl	silver_library_reports__atom_put_unused_written_count
	.align 32
	.type	silver_library_reports__atom_put_unused_written_count, @object
	.size	silver_library_reports__atom_put_unused_written_count, 63
silver_library_reports__atom_put_unused_written_count:
	.ascii	"\\\"Written_Count\\\" is set by \\\"Put\\\" but not used aft"
	.ascii	"er the call"
	.globl	silver_library_reports__atom_put_unused_flushed
	.align 32
	.type	silver_library_reports__atom_put_unused_flushed, @object
	.size	silver_library_reports__atom_put_unused_flushed, 57
silver_library_reports__atom_put_unused_flushed:
	.ascii	"\\\"Flushed\\\" is set by \\\"Put\\\" but not used after the"
	.ascii	" call"
	.globl	silver_library_reports__atom_put_unused_succeeded
	.align 32
	.type	silver_library_reports__atom_put_unused_succeeded, @object
	.size	silver_library_reports__atom_put_unused_succeeded, 59
silver_library_reports__atom_put_unused_succeeded:
	.ascii	"\\\"Succeeded\\\" is set by \\\"Put\\\" but not used after t"
	.ascii	"he call"
	.globl	silver_library_reports__atom_put_unused_written_bytes
	.align 32
	.type	silver_library_reports__atom_put_unused_written_bytes, @object
	.size	silver_library_reports__atom_put_unused_written_bytes, 63
silver_library_reports__atom_put_unused_written_bytes:
	.ascii	"\\\"Written_Bytes\\\" is set by \\\"Put\\\" but not used aft"
	.ascii	"er the call"
	.globl	silver_library_reports__atom_claim_aorte
	.align 16
	.type	silver_library_reports__atom_claim_aorte, @object
	.size	silver_library_reports__atom_claim_aorte, 16
silver_library_reports__atom_claim_aorte:
	.ascii	"CLAIM_AORTE"
	.zero	5
	.globl	silver_library_reports__atom_claim_effects
	.align 16
	.type	silver_library_reports__atom_claim_effects, @object
	.size	silver_library_reports__atom_claim_effects, 16
silver_library_reports__atom_claim_effects:
	.ascii	"CLAIM_EFFECTS"
	.zero	3
	.globl	silver_library_reports__atom_claim_post
	.align 16
	.type	silver_library_reports__atom_claim_post, @object
	.size	silver_library_reports__atom_claim_post, 16
silver_library_reports__atom_claim_post:
	.ascii	"CLAIM_POST"
	.zero	6
	.globl	silver_library_reports__atom_progress_proof
	.align 16
	.type	silver_library_reports__atom_progress_proof, @object
	.size	silver_library_reports__atom_progress_proof, 16
silver_library_reports__atom_progress_proof:
	.ascii	"PROGRESS_PROOF"
	.zero	2
	.globl	silver_library_reports__atom_stop_reason_none
	.align 16
	.type	silver_library_reports__atom_stop_reason_none, @object
	.size	silver_library_reports__atom_stop_reason_none, 16
silver_library_reports__atom_stop_reason_none:
	.ascii	"STOP_REASON_NONE"
	.globl	silver_library_reports__atom_silver_arguments
	.align 16
	.type	silver_library_reports__atom_silver_arguments, @object
	.size	silver_library_reports__atom_silver_arguments, 16
silver_library_reports__atom_silver_arguments:
	.ascii	"Silver_Arguments"
	.globl	silver_library_reports__atom_silver_arguments_first_or_default
	.align 32
	.type	silver_library_reports__atom_silver_arguments_first_or_default, @object
	.size	silver_library_reports__atom_silver_arguments_first_or_default, 33
silver_library_reports__atom_silver_arguments_first_or_default:
	.ascii	"Silver_Arguments.First_Or_Default"
	.globl	silver_library_reports__atom_silver_arguments_input_is_valid
	.align 16
	.type	silver_library_reports__atom_silver_arguments_input_is_valid, @object
	.size	silver_library_reports__atom_silver_arguments_input_is_valid, 31
silver_library_reports__atom_silver_arguments_input_is_valid:
	.ascii	"Silver_Arguments.Input_Is_Valid"
	.globl	silver_library_reports__atom_silver_arguments_is_message
	.align 16
	.type	silver_library_reports__atom_silver_arguments_is_message, @object
	.size	silver_library_reports__atom_silver_arguments_is_message, 27
silver_library_reports__atom_silver_arguments_is_message:
	.ascii	"Silver_Arguments.Is_Message"
	.globl	silver_library_reports__atom_silver_arguments_reject
	.align 16
	.type	silver_library_reports__atom_silver_arguments_reject, @object
	.size	silver_library_reports__atom_silver_arguments_reject, 23
silver_library_reports__atom_silver_arguments_reject:
	.ascii	"Silver_Arguments.Reject"
	.globl	silver_library_reports__atom_silver_io
	.align 16
	.type	silver_library_reports__atom_silver_io, @object
	.size	silver_library_reports__atom_silver_io, 16
silver_library_reports__atom_silver_io:
	.ascii	"Silver_IO"
	.zero	7
	.globl	silver_library_reports__atom_silver_io_put_line
	.align 16
	.type	silver_library_reports__atom_silver_io_put_line, @object
	.size	silver_library_reports__atom_silver_io_put_line, 18
silver_library_reports__atom_silver_io_put_line:
	.ascii	"Silver_IO.Put_Line"
	.globl	silver_library_reports__atom_silver_io_put
	.align 16
	.type	silver_library_reports__atom_silver_io_put, @object
	.size	silver_library_reports__atom_silver_io_put, 16
silver_library_reports__atom_silver_io_put:
	.ascii	"Silver_IO.Put"
	.zero	3
	.globl	silver_library_reports__atom_silver_output_libc
	.align 16
	.type	silver_library_reports__atom_silver_output_libc, @object
	.size	silver_library_reports__atom_silver_output_libc, 18
silver_library_reports__atom_silver_output_libc:
	.ascii	"Silver_Output_Libc"
	.globl	silver_library_reports__atom_silver_output_libc_flush
	.align 16
	.type	silver_library_reports__atom_silver_output_libc_flush, @object
	.size	silver_library_reports__atom_silver_output_libc_flush, 24
silver_library_reports__atom_silver_output_libc_flush:
	.ascii	"Silver_Output_Libc.Flush"
	.globl	silver_library_reports__atom_silver_output_libc_put_byte
	.align 16
	.type	silver_library_reports__atom_silver_output_libc_put_byte, @object
	.size	silver_library_reports__atom_silver_output_libc_put_byte, 27
silver_library_reports__atom_silver_output_libc_put_byte:
	.ascii	"Silver_Output_Libc.Put_Byte"
	.globl	silver_library_reports__atom_silver_output_libc_set_exit_status
	.align 32
	.type	silver_library_reports__atom_silver_output_libc_set_exit_status, @object
	.size	silver_library_reports__atom_silver_output_libc_set_exit_status, 34
silver_library_reports__atom_silver_output_libc_set_exit_status:
	.ascii	"Silver_Output_Libc.Set_Exit_Status"
	.globl	silver_library_reports__atom_silver_runtime
	.align 16
	.type	silver_library_reports__atom_silver_runtime, @object
	.size	silver_library_reports__atom_silver_runtime, 16
silver_library_reports__atom_silver_runtime:
	.ascii	"Silver_Runtime"
	.zero	2
	.globl	silver_library_reports__atom_silver_runtime_argument
	.align 16
	.type	silver_library_reports__atom_silver_runtime_argument, @object
	.size	silver_library_reports__atom_silver_runtime_argument, 23
silver_library_reports__atom_silver_runtime_argument:
	.ascii	"Silver_Runtime.Argument"
	.globl	silver_library_reports__atom_silver_runtime_argument_count
	.align 16
	.type	silver_library_reports__atom_silver_runtime_argument_count, @object
	.size	silver_library_reports__atom_silver_runtime_argument_count, 29
silver_library_reports__atom_silver_runtime_argument_count:
	.ascii	"Silver_Runtime.Argument_Count"
	.globl	silver_library_reports__atom_silver_runtime_set_exit_status
	.align 16
	.type	silver_library_reports__atom_silver_runtime_set_exit_status, @object
	.size	silver_library_reports__atom_silver_runtime_set_exit_status, 30
silver_library_reports__atom_silver_runtime_set_exit_status:
	.ascii	"Silver_Runtime.Set_Exit_Status"
	.globl	silver_library_reports__atom_vc_postcondition
	.align 16
	.type	silver_library_reports__atom_vc_postcondition, @object
	.size	silver_library_reports__atom_vc_postcondition, 16
silver_library_reports__atom_vc_postcondition:
	.ascii	"VC_POSTCONDITION"
	.globl	silver_library_reports__atom_vc_range_check
	.align 16
	.type	silver_library_reports__atom_vc_range_check, @object
	.size	silver_library_reports__atom_vc_range_check, 16
silver_library_reports__atom_vc_range_check:
	.ascii	"VC_RANGE_CHECK"
	.zero	2
	.globl	silver_library_reports__atom_vc_length_check
	.align 16
	.type	silver_library_reports__atom_vc_length_check, @object
	.size	silver_library_reports__atom_vc_length_check, 16
silver_library_reports__atom_vc_length_check:
	.ascii	"VC_LENGTH_CHECK"
	.zero	1
	.globl	silver_library_reports__atom_vc_overflow_check
	.align 16
	.type	silver_library_reports__atom_vc_overflow_check, @object
	.size	silver_library_reports__atom_vc_overflow_check, 17
silver_library_reports__atom_vc_overflow_check:
	.ascii	"VC_OVERFLOW_CHECK"
	.globl	silver_library_reports__atom_vc_division_check
	.align 16
	.type	silver_library_reports__atom_vc_division_check, @object
	.size	silver_library_reports__atom_vc_division_check, 17
silver_library_reports__atom_vc_division_check:
	.ascii	"VC_DIVISION_CHECK"
	.globl	silver_library_reports__atom_all
	.align 4
	.type	silver_library_reports__atom_all, @object
	.size	silver_library_reports__atom_all, 4
silver_library_reports__atom_all:
	.ascii	"all"
	.zero	1
	.globl	silver_library_reports__atom_info
	.align 4
	.type	silver_library_reports__atom_info, @object
	.size	silver_library_reports__atom_info, 4
silver_library_reports__atom_info:
	.ascii	"info"
	.globl	silver_library_reports__atom_main_adb
	.align 8
	.type	silver_library_reports__atom_main_adb, @object
	.size	silver_library_reports__atom_main_adb, 8
silver_library_reports__atom_main_adb:
	.ascii	"main.adb"
	.globl	silver_library_reports__atom_prover
	.align 8
	.type	silver_library_reports__atom_prover, @object
	.size	silver_library_reports__atom_prover, 8
silver_library_reports__atom_prover:
	.ascii	"prover"
	.zero	2
	.globl	silver_library_reports__atom_silver_arguments_adb
	.align 16
	.type	silver_library_reports__atom_silver_arguments_adb, @object
	.size	silver_library_reports__atom_silver_arguments_adb, 20
silver_library_reports__atom_silver_arguments_adb:
	.ascii	"silver_arguments.adb"
	.globl	silver_library_reports__atom_silver_arguments_ads
	.align 16
	.type	silver_library_reports__atom_silver_arguments_ads, @object
	.size	silver_library_reports__atom_silver_arguments_ads, 20
silver_library_reports__atom_silver_arguments_ads:
	.ascii	"silver_arguments.ads"
	.globl	silver_library_reports__atom_silver_io_adb
	.align 16
	.type	silver_library_reports__atom_silver_io_adb, @object
	.size	silver_library_reports__atom_silver_io_adb, 16
silver_library_reports__atom_silver_io_adb:
	.ascii	"silver_io.adb"
	.zero	3
	.globl	silver_library_reports__atom_silver_io_ads
	.align 16
	.type	silver_library_reports__atom_silver_io_ads, @object
	.size	silver_library_reports__atom_silver_io_ads, 16
silver_library_reports__atom_silver_io_ads:
	.ascii	"silver_io.ads"
	.zero	3
	.globl	silver_library_reports__atom_silver_output_libc_ads
	.align 16
	.type	silver_library_reports__atom_silver_output_libc_ads, @object
	.size	silver_library_reports__atom_silver_output_libc_ads, 22
silver_library_reports__atom_silver_output_libc_ads:
	.ascii	"silver_output_libc.ads"
	.globl	silver_library_reports__atom_silver_runtime_ads
	.align 16
	.type	silver_library_reports__atom_silver_runtime_ads, @object
	.size	silver_library_reports__atom_silver_runtime_ads, 18
silver_library_reports__atom_silver_runtime_ads:
	.ascii	"silver_runtime.ads"
	.globl	silver_library_reports__atom_spec
	.align 4
	.type	silver_library_reports__atom_spec, @object
	.size	silver_library_reports__atom_spec, 4
silver_library_reports__atom_spec:
	.ascii	"spec"
	.globl	silver_library_reports__atom_trivial
	.align 8
	.type	silver_library_reports__atom_trivial, @object
	.size	silver_library_reports__atom_trivial, 8
silver_library_reports__atom_trivial:
	.ascii	"trivial"
	.zero	1
	.globl	silver_library_reports__json_check_tree
	.align 16
	.type	silver_library_reports__json_check_tree, @object
	.size	silver_library_reports__json_check_tree, 16
silver_library_reports__json_check_tree:
	.ascii	"check_tree"
	.zero	6
	.globl	silver_library_reports__json_unproved_status
	.align 16
	.type	silver_library_reports__json_unproved_status, @object
	.size	silver_library_reports__json_unproved_status, 16
silver_library_reports__json_unproved_status:
	.ascii	"unproved_status"
	.zero	1
	.globl	silver_library_reports__json_status
	.align 8
	.type	silver_library_reports__json_status, @object
	.size	silver_library_reports__json_status, 8
silver_library_reports__json_status:
	.ascii	"status"
	.zero	2
	.globl	silver_library_reports__json_sloc
	.align 4
	.type	silver_library_reports__json_sloc, @object
	.size	silver_library_reports__json_sloc, 4
silver_library_reports__json_sloc:
	.ascii	"sloc"
	.globl	silver_library_reports__json_file
	.align 4
	.type	silver_library_reports__json_file, @object
	.size	silver_library_reports__json_file, 4
silver_library_reports__json_file:
	.ascii	"file"
	.globl	silver_library_reports__json_name
	.align 4
	.type	silver_library_reports__json_name, @object
	.size	silver_library_reports__json_name, 4
silver_library_reports__json_name:
	.ascii	"name"
	.globl	silver_library_reports__json_predicate
	.align 16
	.type	silver_library_reports__json_predicate, @object
	.size	silver_library_reports__json_predicate, 16
silver_library_reports__json_predicate:
	.ascii	"predicate"
	.zero	7
	.globl	silver_library_reports__json_arg
	.align 4
	.type	silver_library_reports__json_arg, @object
	.size	silver_library_reports__json_arg, 4
silver_library_reports__json_arg:
	.ascii	"arg"
	.zero	1
	.globl	silver_library_reports__json_rule
	.align 4
	.type	silver_library_reports__json_rule, @object
	.size	silver_library_reports__json_rule, 4
silver_library_reports__json_rule:
	.ascii	"rule"
	.globl	silver_library_reports__json_message
	.align 8
	.type	silver_library_reports__json_message, @object
	.size	silver_library_reports__json_message, 8
silver_library_reports__json_message:
	.ascii	"message"
	.zero	1
	.globl	silver_library_reports__json_text
	.align 4
	.type	silver_library_reports__json_text, @object
	.size	silver_library_reports__json_text, 4
silver_library_reports__json_text:
	.ascii	"text"
	.globl	silver_library_reports__json_entity
	.align 8
	.type	silver_library_reports__json_entity, @object
	.size	silver_library_reports__json_entity, 8
silver_library_reports__json_entity:
	.ascii	"entity"
	.zero	2
	.globl	silver_library_reports__json_how_proved
	.align 16
	.type	silver_library_reports__json_how_proved, @object
	.size	silver_library_reports__json_how_proved, 16
silver_library_reports__json_how_proved:
	.ascii	"how_proved"
	.zero	6
	.globl	silver_library_reports__json_severity
	.align 8
	.type	silver_library_reports__json_severity, @object
	.size	silver_library_reports__json_severity, 8
silver_library_reports__json_severity:
	.ascii	"severity"
	.globl	silver_library_reports__json_line
	.align 4
	.type	silver_library_reports__json_line, @object
	.size	silver_library_reports__json_line, 4
silver_library_reports__json_line:
	.ascii	"line"
	.globl	silver_library_reports__json_col
	.align 4
	.type	silver_library_reports__json_col, @object
	.size	silver_library_reports__json_col, 4
silver_library_reports__json_col:
	.ascii	"col"
	.zero	1
	.globl	silver_library_reports__json_justification
	.align 16
	.type	silver_library_reports__json_justification, @object
	.size	silver_library_reports__json_justification, 16
silver_library_reports__json_justification:
	.ascii	"justification"
	.zero	3
	.globl	silver_library_reports__json_justified
	.align 16
	.type	silver_library_reports__json_justified, @object
	.size	silver_library_reports__json_justified, 16
silver_library_reports__json_justified:
	.ascii	"justified"
	.zero	7
	.globl	silver_library_reports__json_suppressed
	.align 16
	.type	silver_library_reports__json_suppressed, @object
	.size	silver_library_reports__json_suppressed, 16
silver_library_reports__json_suppressed:
	.ascii	"suppressed"
	.zero	6
	.globl	silver_library_reports__json_annot_kind
	.align 16
	.type	silver_library_reports__json_annot_kind, @object
	.size	silver_library_reports__json_annot_kind, 16
silver_library_reports__json_annot_kind:
	.ascii	"annot_kind"
	.zero	6
	.globl	silver_library_reports__json_justif_msg
	.align 16
	.type	silver_library_reports__json_justif_msg, @object
	.size	silver_library_reports__json_justif_msg, 16
silver_library_reports__json_justif_msg:
	.ascii	"justif_msg"
	.zero	6
	.globl	silver_library_reports__json_claim
	.align 8
	.type	silver_library_reports__json_claim, @object
	.size	silver_library_reports__json_claim, 8
silver_library_reports__json_claim:
	.ascii	"claim"
	.zero	3
	.globl	silver_library_reports__json_assumptions
	.align 16
	.type	silver_library_reports__json_assumptions, @object
	.size	silver_library_reports__json_assumptions, 16
silver_library_reports__json_assumptions:
	.ascii	"assumptions"
	.zero	5
	.globl	silver_library_reports__json_entities
	.align 8
	.type	silver_library_reports__json_entities, @object
	.size	silver_library_reports__json_entities, 8
silver_library_reports__json_entities:
	.ascii	"entities"
	.globl	silver_library_reports__json_progress
	.align 8
	.type	silver_library_reports__json_progress, @object
	.size	silver_library_reports__json_progress, 8
silver_library_reports__json_progress:
	.ascii	"progress"
	.globl	silver_library_reports__json_stop_reason
	.align 16
	.type	silver_library_reports__json_stop_reason, @object
	.size	silver_library_reports__json_stop_reason, 16
silver_library_reports__json_stop_reason:
	.ascii	"stop_reason"
	.zero	5
	.globl	silver_library_reports__json_skip_flow_proof
	.align 16
	.type	silver_library_reports__json_skip_flow_proof, @object
	.size	silver_library_reports__json_skip_flow_proof, 16
silver_library_reports__json_skip_flow_proof:
	.ascii	"skip_flow_proof"
	.zero	1
	.globl	silver_library_reports__json_skip_proof
	.align 16
	.type	silver_library_reports__json_skip_proof, @object
	.size	silver_library_reports__json_skip_proof, 16
silver_library_reports__json_skip_proof:
	.ascii	"skip_proof"
	.zero	6
	.globl	silver_library_reports__json_pragma_assume
	.align 16
	.type	silver_library_reports__json_pragma_assume, @object
	.size	silver_library_reports__json_pragma_assume, 16
silver_library_reports__json_pragma_assume:
	.ascii	"pragma_assume"
	.zero	3
	.globl	silver_library_reports__json_warn_error
	.align 16
	.type	silver_library_reports__json_warn_error, @object
	.size	silver_library_reports__json_warn_error, 16
silver_library_reports__json_warn_error:
	.ascii	"warn_error"
	.zero	6
	.globl	silver_library_reports__json_spark
	.align 8
	.type	silver_library_reports__json_spark, @object
	.size	silver_library_reports__json_spark, 8
silver_library_reports__json_spark:
	.ascii	"spark"
	.zero	3
	.globl	silver_library_reports__json_flow
	.align 4
	.type	silver_library_reports__json_flow, @object
	.size	silver_library_reports__json_flow, 4
silver_library_reports__json_flow:
	.ascii	"flow"
	.globl	silver_library_reports__json_proof
	.align 8
	.type	silver_library_reports__json_proof, @object
	.size	silver_library_reports__json_proof, 8
silver_library_reports__json_proof:
	.ascii	"proof"
	.zero	3
	.globl	silver_library_reports__missing
	.align 8
	.type	silver_library_reports__missing, @object
	.size	silver_library_reports__missing, 8
silver_library_reports__missing:
	.zero	8
	.globl	silver_library_reports__malformed
	.align 8
	.type	silver_library_reports__malformed, @object
	.size	silver_library_reports__malformed, 8
silver_library_reports__malformed:
	.long	0
	.long	1
	.globl	silver_library_reports__empty_nesting
	.align 32
	.type	silver_library_reports__empty_nesting, @object
	.size	silver_library_reports__empty_nesting, 64
silver_library_reports__empty_nesting:
	.ascii	"                                                            "
	.ascii	"    "
	.globl	silver_library_reports__member_stateS
	.align 16
	.type	silver_library_reports__member_stateS, @object
	.size	silver_library_reports__member_stateS, 21
silver_library_reports__member_stateS:
	.ascii	"BROKENFINISHEDPRESENT"
	.globl	silver_library_reports__member_stateN
	.align 4
	.type	silver_library_reports__member_stateN, @object
	.size	silver_library_reports__member_stateN, 4
silver_library_reports__member_stateN:
	.byte	1
	.byte	7
	.byte	15
	.byte	22
	.globl	silver_library_reports__bad_member
	.align 16
	.type	silver_library_reports__bad_member, @object
	.size	silver_library_reports__bad_member, 24
silver_library_reports__bad_member:
	.zero	24
	.globl	silver_library_reports__end_member
	.align 16
	.type	silver_library_reports__end_member, @object
	.size	silver_library_reports__end_member, 24
silver_library_reports__end_member:
	.byte	1
	.zero	3
	.long	0
	.long	0
	.long	0
	.long	0
	.long	0
	.globl	silver_library_reports__projection_tree_name
	.align 16
	.type	silver_library_reports__projection_tree_name, @object
	.size	silver_library_reports__projection_tree_name, 16
silver_library_reports__projection_tree_name:
	.ascii	"check_tree"
	.zero	6
	.globl	silver_library_reports__entity_kindS
	.align 32
	.type	silver_library_reports__entity_kindS, @object
	.size	silver_library_reports__entity_kindS, 198
silver_library_reports__entity_kindS:
	.ascii	"UNKNOWNIO_PACKAGEPUT_LINEPUTLIBC_PACKAGEPUT_BYTEFLUSHSET_EXI"
	.ascii	"T_STATUSARGUMENTS_PACKAGEINPUT_IS_VALIDFIRST_OR_DEFAULTREJEC"
	.ascii	"TIS_MESSAGERUNTIME_PACKAGEARGUMENT_COUNTARGUMENTRUNTIME_EXIT"
	.ascii	"_STATUSMAIN_ENTITY"
	.globl	silver_library_reports__entity_kindN
	.align 32
	.type	silver_library_reports__entity_kindN, @object
	.size	silver_library_reports__entity_kindN, 38
silver_library_reports__entity_kindN:
	.value	1
	.value	8
	.value	18
	.value	26
	.value	29
	.value	41
	.value	49
	.value	54
	.value	69
	.value	86
	.value	100
	.value	116
	.value	122
	.value	132
	.value	147
	.value	161
	.value	169
	.value	188
	.value	199
	.globl	silver_library_reports__list_kindS
	.align 32
	.type	silver_library_reports__list_kindS, @object
	.size	silver_library_reports__list_kindS, 179
silver_library_reports__list_kindS:
	.ascii	"CHECKSMAIN_CHECKSBINDING_DIAGNOSTICSARGUMENT_DIAGNOSTICSASSI"
	.ascii	"GNMENT_DIAGNOSTICSSELECTED_DIAGNOSTICSIMAGE_ADVISORIESREFERE"
	.ascii	"NCESPOSTCONDITIONSPUT_POSTCONDITIONSARGUMENT_POSTCONDITIONS"
	.globl	silver_library_reports__list_kindN
	.align 16
	.type	silver_library_reports__list_kindN, @object
	.size	silver_library_reports__list_kindN, 24
silver_library_reports__list_kindN:
	.value	1
	.value	7
	.value	18
	.value	37
	.value	57
	.value	79
	.value	99
	.value	115
	.value	125
	.value	139
	.value	157
	.value	180
	.globl	silver_library_reports__no_entities
	.align 16
	.type	silver_library_reports__no_entities, @object
	.size	silver_library_reports__no_entities, 18
silver_library_reports__no_entities:
	.zero	18
	.align 4
	.type	report_kindP.19, @object
	.size	report_kindP.19, 4
report_kindP.19:
	.long	1
	.type	report_kindT1.18, @object
	.size	report_kindT1.18, 1
report_kindT1.18:
	.byte	7
	.type	report_kindT2.17, @object
	.size	report_kindT2.17, 1
report_kindT2.17:
	.byte	9
	.align 16
	.type	report_kindG.16, @object
	.size	report_kindG.16, 16
report_kindG.16:
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	1
	.byte	3
	.byte	1
	.zero	4
	.align 16
	.type	audit_kindP.15, @object
	.size	audit_kindP.15, 20
audit_kindP.15:
	.long	4
	.long	9
	.long	10
	.long	14
	.long	17
	.align 8
	.type	audit_kindT1.14, @object
	.size	audit_kindT1.14, 8
audit_kindT1.14:
	.byte	46
	.byte	4
	.byte	51
	.byte	60
	.byte	14
	.zero	3
	.align 8
	.type	audit_kindT2.13, @object
	.size	audit_kindT2.13, 8
audit_kindT2.13:
	.byte	27
	.byte	32
	.byte	2
	.byte	33
	.byte	28
	.zero	3
	.align 32
	.type	audit_kindG.12, @object
	.size	audit_kindG.12, 61
audit_kindG.12:
	.byte	22
	.byte	0
	.byte	0
	.byte	23
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	17
	.byte	0
	.byte	0
	.byte	24
	.byte	0
	.byte	10
	.byte	0
	.byte	27
	.byte	0
	.byte	5
	.byte	0
	.byte	0
	.byte	0
	.byte	13
	.byte	19
	.byte	0
	.byte	0
	.byte	0
	.byte	21
	.byte	19
	.byte	5
	.byte	0
	.byte	0
	.byte	6
	.byte	28
	.byte	0
	.byte	13
	.byte	6
	.byte	7
	.byte	28
	.byte	18
	.byte	6
	.byte	10
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	23
	.byte	3
	.byte	0
	.byte	0
	.byte	1
	.byte	24
	.byte	15
	.byte	0
	.byte	0
	.byte	22
	.byte	10
	.byte	0
	.align 16
	.type	entity_kindP.11, @object
	.size	entity_kindP.11, 16
entity_kindP.11:
	.long	3
	.long	5
	.long	9
	.zero	4
	.align 4
	.type	entity_kindT1.10, @object
	.size	entity_kindT1.10, 4
entity_kindT1.10:
	.byte	2
	.byte	4
	.byte	16
	.zero	1
	.align 4
	.type	entity_kindT2.9, @object
	.size	entity_kindT2.9, 4
entity_kindT2.9:
	.byte	27
	.byte	25
	.byte	1
	.zero	1
	.align 32
	.type	entity_kindG.8, @object
	.size	entity_kindG.8, 37
entity_kindG.8:
	.byte	0
	.byte	0
	.byte	0
	.byte	8
	.byte	0
	.byte	0
	.byte	10
	.byte	0
	.byte	0
	.byte	11
	.byte	0
	.byte	3
	.byte	0
	.byte	0
	.byte	4
	.byte	3
	.byte	0
	.byte	0
	.byte	17
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.byte	10
	.byte	0
	.byte	2
	.byte	17
	.byte	0
	.byte	5
	.byte	9
	.byte	3
	.byte	0
	.byte	16
	.byte	0
	.align 8
	.type	list_kindP.7, @object
	.size	list_kindP.7, 8
list_kindP.7:
	.long	2
	.long	10
	.align 2
	.type	list_kindT1.6, @object
	.size	list_kindT1.6, 2
list_kindT1.6:
	.byte	18
	.byte	19
	.align 2
	.type	list_kindT2.5, @object
	.size	list_kindT2.5, 2
list_kindT2.5:
	.byte	21
	.byte	10
	.align 16
	.type	list_kindG.4, @object
	.size	list_kindG.4, 23
list_kindG.4:
	.byte	0
	.byte	1
	.byte	2
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.byte	4
	.byte	0
	.byte	10
	.byte	3
	.byte	0
	.byte	0
	.byte	5
	.byte	0
	.byte	8
	.byte	0
	.byte	0
	.byte	8
	.byte	0
	.byte	0
	.byte	0
	.byte	1
	.text
.Letext0:
	.file 2 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_library_reports.ads"
	.file 3 "<built-in>"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x244a
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x24
	.long	.LASF282
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.long	.LLRL6
	.quad	0
	.long	.Ldebug_line0
	.uleb128 0x2
	.long	.LASF2
	.byte	0x2
	.byte	0x8
	.long	0x4d
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__max_report_length
	.uleb128 0x25
	.sleb128 2147483647
	.long	.LASF283
	.long	0x52
	.uleb128 0xc
	.long	0x3f
	.uleb128 0x10
	.byte	0x4
	.byte	0x5
	.long	.LASF45
	.uleb128 0x2
	.long	.LASF3
	.byte	0x2
	.byte	0x9
	.long	0x4d
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__max_runtime_report_length
	.uleb128 0x12
	.long	.LASF8
	.byte	0x2
	.byte	0xc
	.long	0x92
	.uleb128 0x6
	.long	.LASF4
	.byte	0
	.uleb128 0x6
	.long	.LASF5
	.byte	0x1
	.uleb128 0x6
	.long	.LASF6
	.byte	0x2
	.uleb128 0x6
	.long	.LASF7
	.byte	0x3
	.byte	0
	.uleb128 0xc
	.long	0x6e
	.uleb128 0x12
	.long	.LASF9
	.byte	0x2
	.byte	0xa
	.long	0xbb
	.uleb128 0x6
	.long	.LASF10
	.byte	0
	.uleb128 0x6
	.long	.LASF11
	.byte	0x1
	.uleb128 0x6
	.long	.LASF12
	.byte	0x2
	.uleb128 0x6
	.long	.LASF13
	.byte	0x3
	.byte	0
	.uleb128 0xc
	.long	0x97
	.uleb128 0x12
	.long	.LASF14
	.byte	0x1
	.byte	0xb
	.long	0x180
	.uleb128 0x6
	.long	.LASF15
	.byte	0
	.uleb128 0x6
	.long	.LASF16
	.byte	0x1
	.uleb128 0x6
	.long	.LASF17
	.byte	0x2
	.uleb128 0x6
	.long	.LASF18
	.byte	0x3
	.uleb128 0x6
	.long	.LASF19
	.byte	0x4
	.uleb128 0x6
	.long	.LASF20
	.byte	0x5
	.uleb128 0x6
	.long	.LASF21
	.byte	0x6
	.uleb128 0x6
	.long	.LASF22
	.byte	0x7
	.uleb128 0x6
	.long	.LASF23
	.byte	0x8
	.uleb128 0x6
	.long	.LASF24
	.byte	0x9
	.uleb128 0x6
	.long	.LASF25
	.byte	0xa
	.uleb128 0x6
	.long	.LASF26
	.byte	0xb
	.uleb128 0x6
	.long	.LASF27
	.byte	0xc
	.uleb128 0x6
	.long	.LASF28
	.byte	0xd
	.uleb128 0x6
	.long	.LASF29
	.byte	0xe
	.uleb128 0x6
	.long	.LASF30
	.byte	0xf
	.uleb128 0x6
	.long	.LASF31
	.byte	0x10
	.uleb128 0x6
	.long	.LASF32
	.byte	0x11
	.uleb128 0x6
	.long	.LASF33
	.byte	0x12
	.uleb128 0x6
	.long	.LASF34
	.byte	0x13
	.uleb128 0x6
	.long	.LASF35
	.byte	0x14
	.uleb128 0x6
	.long	.LASF36
	.byte	0x15
	.uleb128 0x6
	.long	.LASF37
	.byte	0x16
	.uleb128 0x6
	.long	.LASF38
	.byte	0x17
	.uleb128 0x6
	.long	.LASF39
	.byte	0x18
	.uleb128 0x6
	.long	.LASF40
	.byte	0x19
	.uleb128 0x6
	.long	.LASF41
	.byte	0x1a
	.uleb128 0x6
	.long	.LASF42
	.byte	0x1b
	.uleb128 0x6
	.long	.LASF43
	.byte	0x1c
	.uleb128 0x6
	.long	.LASF44
	.byte	0x1d
	.byte	0
	.uleb128 0xc
	.long	0xc0
	.uleb128 0x3
	.long	0x19a
	.long	0x195
	.uleb128 0x4
	.long	0x52
	.sleb128 0
	.byte	0
	.uleb128 0x1
	.long	0x185
	.uleb128 0x10
	.byte	0x1
	.byte	0x8
	.long	.LASF46
	.uleb128 0xc
	.long	0x19a
	.uleb128 0x3
	.long	0x19a
	.long	0x1b6
	.uleb128 0x4
	.long	0x52
	.sleb128 21
	.byte	0
	.uleb128 0x1
	.long	0x1a6
	.uleb128 0x3
	.long	0x19a
	.long	0x1cb
	.uleb128 0x4
	.long	0x52
	.sleb128 17
	.byte	0
	.uleb128 0x1
	.long	0x1bb
	.uleb128 0x3
	.long	0x19a
	.long	0x1e0
	.uleb128 0x4
	.long	0x52
	.sleb128 15
	.byte	0
	.uleb128 0x1
	.long	0x1d0
	.uleb128 0x3
	.long	0x19a
	.long	0x1f6
	.uleb128 0x4
	.long	0x52
	.sleb128 194
	.byte	0
	.uleb128 0x1
	.long	0x1e5
	.uleb128 0x3
	.long	0x19a
	.long	0x20b
	.uleb128 0x4
	.long	0x52
	.sleb128 7
	.byte	0
	.uleb128 0x1
	.long	0x1fb
	.uleb128 0x3
	.long	0x19a
	.long	0x220
	.uleb128 0x4
	.long	0x52
	.sleb128 11
	.byte	0
	.uleb128 0x1
	.long	0x210
	.uleb128 0x3
	.long	0x19a
	.long	0x235
	.uleb128 0x4
	.long	0x52
	.sleb128 9
	.byte	0
	.uleb128 0x1
	.long	0x225
	.uleb128 0x3
	.long	0x19a
	.long	0x24a
	.uleb128 0x4
	.long	0x52
	.sleb128 23
	.byte	0
	.uleb128 0x1
	.long	0x23a
	.uleb128 0x3
	.long	0x19a
	.long	0x25f
	.uleb128 0x4
	.long	0x52
	.sleb128 31
	.byte	0
	.uleb128 0x1
	.long	0x24f
	.uleb128 0x3
	.long	0x19a
	.long	0x274
	.uleb128 0x4
	.long	0x52
	.sleb128 7
	.byte	0
	.uleb128 0x1
	.long	0x264
	.uleb128 0x3
	.long	0x19a
	.long	0x289
	.uleb128 0x4
	.long	0x52
	.sleb128 17
	.byte	0
	.uleb128 0x1
	.long	0x279
	.uleb128 0x3
	.long	0x19a
	.long	0x29f
	.uleb128 0x4
	.long	0x52
	.sleb128 68
	.byte	0
	.uleb128 0x1
	.long	0x28e
	.uleb128 0x3
	.long	0x19a
	.long	0x2b4
	.uleb128 0x4
	.long	0x52
	.sleb128 62
	.byte	0
	.uleb128 0x1
	.long	0x2a4
	.uleb128 0x3
	.long	0x19a
	.long	0x2ca
	.uleb128 0x4
	.long	0x52
	.sleb128 64
	.byte	0
	.uleb128 0x1
	.long	0x2b9
	.uleb128 0x3
	.long	0x19a
	.long	0x2e0
	.uleb128 0x4
	.long	0x52
	.sleb128 68
	.byte	0
	.uleb128 0x1
	.long	0x2cf
	.uleb128 0x3
	.long	0x19a
	.long	0x2f5
	.uleb128 0x4
	.long	0x52
	.sleb128 63
	.byte	0
	.uleb128 0x1
	.long	0x2e5
	.uleb128 0x3
	.long	0x19a
	.long	0x30a
	.uleb128 0x4
	.long	0x52
	.sleb128 57
	.byte	0
	.uleb128 0x1
	.long	0x2fa
	.uleb128 0x3
	.long	0x19a
	.long	0x31f
	.uleb128 0x4
	.long	0x52
	.sleb128 59
	.byte	0
	.uleb128 0x1
	.long	0x30f
	.uleb128 0x3
	.long	0x19a
	.long	0x334
	.uleb128 0x4
	.long	0x52
	.sleb128 63
	.byte	0
	.uleb128 0x1
	.long	0x324
	.uleb128 0x3
	.long	0x19a
	.long	0x349
	.uleb128 0x4
	.long	0x52
	.sleb128 11
	.byte	0
	.uleb128 0x1
	.long	0x339
	.uleb128 0x3
	.long	0x19a
	.long	0x35e
	.uleb128 0x4
	.long	0x52
	.sleb128 13
	.byte	0
	.uleb128 0x1
	.long	0x34e
	.uleb128 0x3
	.long	0x19a
	.long	0x373
	.uleb128 0x4
	.long	0x52
	.sleb128 10
	.byte	0
	.uleb128 0x1
	.long	0x363
	.uleb128 0x3
	.long	0x19a
	.long	0x388
	.uleb128 0x4
	.long	0x52
	.sleb128 14
	.byte	0
	.uleb128 0x1
	.long	0x378
	.uleb128 0x3
	.long	0x19a
	.long	0x39d
	.uleb128 0x4
	.long	0x52
	.sleb128 16
	.byte	0
	.uleb128 0x1
	.long	0x38d
	.uleb128 0x3
	.long	0x19a
	.long	0x3b2
	.uleb128 0x4
	.long	0x52
	.sleb128 16
	.byte	0
	.uleb128 0x1
	.long	0x3a2
	.uleb128 0x3
	.long	0x19a
	.long	0x3c7
	.uleb128 0x4
	.long	0x52
	.sleb128 33
	.byte	0
	.uleb128 0x1
	.long	0x3b7
	.uleb128 0x3
	.long	0x19a
	.long	0x3dc
	.uleb128 0x4
	.long	0x52
	.sleb128 31
	.byte	0
	.uleb128 0x1
	.long	0x3cc
	.uleb128 0x3
	.long	0x19a
	.long	0x3f1
	.uleb128 0x4
	.long	0x52
	.sleb128 27
	.byte	0
	.uleb128 0x1
	.long	0x3e1
	.uleb128 0x3
	.long	0x19a
	.long	0x406
	.uleb128 0x4
	.long	0x52
	.sleb128 23
	.byte	0
	.uleb128 0x1
	.long	0x3f6
	.uleb128 0x3
	.long	0x19a
	.long	0x41b
	.uleb128 0x4
	.long	0x52
	.sleb128 9
	.byte	0
	.uleb128 0x1
	.long	0x40b
	.uleb128 0x3
	.long	0x19a
	.long	0x430
	.uleb128 0x4
	.long	0x52
	.sleb128 18
	.byte	0
	.uleb128 0x1
	.long	0x420
	.uleb128 0x3
	.long	0x19a
	.long	0x445
	.uleb128 0x4
	.long	0x52
	.sleb128 13
	.byte	0
	.uleb128 0x1
	.long	0x435
	.uleb128 0x3
	.long	0x19a
	.long	0x45a
	.uleb128 0x4
	.long	0x52
	.sleb128 18
	.byte	0
	.uleb128 0x1
	.long	0x44a
	.uleb128 0x3
	.long	0x19a
	.long	0x46f
	.uleb128 0x4
	.long	0x52
	.sleb128 24
	.byte	0
	.uleb128 0x1
	.long	0x45f
	.uleb128 0x3
	.long	0x19a
	.long	0x484
	.uleb128 0x4
	.long	0x52
	.sleb128 27
	.byte	0
	.uleb128 0x1
	.long	0x474
	.uleb128 0x3
	.long	0x19a
	.long	0x499
	.uleb128 0x4
	.long	0x52
	.sleb128 34
	.byte	0
	.uleb128 0x1
	.long	0x489
	.uleb128 0x3
	.long	0x19a
	.long	0x4ae
	.uleb128 0x4
	.long	0x52
	.sleb128 14
	.byte	0
	.uleb128 0x1
	.long	0x49e
	.uleb128 0x3
	.long	0x19a
	.long	0x4c3
	.uleb128 0x4
	.long	0x52
	.sleb128 23
	.byte	0
	.uleb128 0x1
	.long	0x4b3
	.uleb128 0x3
	.long	0x19a
	.long	0x4d8
	.uleb128 0x4
	.long	0x52
	.sleb128 29
	.byte	0
	.uleb128 0x1
	.long	0x4c8
	.uleb128 0x3
	.long	0x19a
	.long	0x4ed
	.uleb128 0x4
	.long	0x52
	.sleb128 30
	.byte	0
	.uleb128 0x1
	.long	0x4dd
	.uleb128 0x3
	.long	0x19a
	.long	0x502
	.uleb128 0x4
	.long	0x52
	.sleb128 16
	.byte	0
	.uleb128 0x1
	.long	0x4f2
	.uleb128 0x3
	.long	0x19a
	.long	0x517
	.uleb128 0x4
	.long	0x52
	.sleb128 14
	.byte	0
	.uleb128 0x1
	.long	0x507
	.uleb128 0x3
	.long	0x19a
	.long	0x52c
	.uleb128 0x4
	.long	0x52
	.sleb128 15
	.byte	0
	.uleb128 0x1
	.long	0x51c
	.uleb128 0x3
	.long	0x19a
	.long	0x541
	.uleb128 0x4
	.long	0x52
	.sleb128 17
	.byte	0
	.uleb128 0x1
	.long	0x531
	.uleb128 0x3
	.long	0x19a
	.long	0x556
	.uleb128 0x4
	.long	0x52
	.sleb128 17
	.byte	0
	.uleb128 0x1
	.long	0x546
	.uleb128 0x3
	.long	0x19a
	.long	0x56b
	.uleb128 0x4
	.long	0x52
	.sleb128 3
	.byte	0
	.uleb128 0x1
	.long	0x55b
	.uleb128 0x3
	.long	0x19a
	.long	0x580
	.uleb128 0x4
	.long	0x52
	.sleb128 4
	.byte	0
	.uleb128 0x1
	.long	0x570
	.uleb128 0x3
	.long	0x19a
	.long	0x595
	.uleb128 0x4
	.long	0x52
	.sleb128 8
	.byte	0
	.uleb128 0x1
	.long	0x585
	.uleb128 0x3
	.long	0x19a
	.long	0x5aa
	.uleb128 0x4
	.long	0x52
	.sleb128 6
	.byte	0
	.uleb128 0x1
	.long	0x59a
	.uleb128 0x3
	.long	0x19a
	.long	0x5bf
	.uleb128 0x4
	.long	0x52
	.sleb128 20
	.byte	0
	.uleb128 0x1
	.long	0x5af
	.uleb128 0x3
	.long	0x19a
	.long	0x5d4
	.uleb128 0x4
	.long	0x52
	.sleb128 20
	.byte	0
	.uleb128 0x1
	.long	0x5c4
	.uleb128 0x3
	.long	0x19a
	.long	0x5e9
	.uleb128 0x4
	.long	0x52
	.sleb128 13
	.byte	0
	.uleb128 0x1
	.long	0x5d9
	.uleb128 0x3
	.long	0x19a
	.long	0x5fe
	.uleb128 0x4
	.long	0x52
	.sleb128 13
	.byte	0
	.uleb128 0x1
	.long	0x5ee
	.uleb128 0x3
	.long	0x19a
	.long	0x613
	.uleb128 0x4
	.long	0x52
	.sleb128 22
	.byte	0
	.uleb128 0x1
	.long	0x603
	.uleb128 0x3
	.long	0x19a
	.long	0x628
	.uleb128 0x4
	.long	0x52
	.sleb128 18
	.byte	0
	.uleb128 0x1
	.long	0x618
	.uleb128 0x3
	.long	0x19a
	.long	0x63d
	.uleb128 0x4
	.long	0x52
	.sleb128 4
	.byte	0
	.uleb128 0x1
	.long	0x62d
	.uleb128 0x3
	.long	0x19a
	.long	0x652
	.uleb128 0x4
	.long	0x52
	.sleb128 7
	.byte	0
	.uleb128 0x1
	.long	0x642
	.uleb128 0x3
	.long	0x19a
	.long	0x667
	.uleb128 0x4
	.long	0x52
	.sleb128 10
	.byte	0
	.uleb128 0x1
	.long	0x657
	.uleb128 0x3
	.long	0x19a
	.long	0x67c
	.uleb128 0x4
	.long	0x52
	.sleb128 15
	.byte	0
	.uleb128 0x1
	.long	0x66c
	.uleb128 0x3
	.long	0x19a
	.long	0x691
	.uleb128 0x4
	.long	0x52
	.sleb128 6
	.byte	0
	.uleb128 0x1
	.long	0x681
	.uleb128 0x3
	.long	0x19a
	.long	0x6a6
	.uleb128 0x4
	.long	0x52
	.sleb128 4
	.byte	0
	.uleb128 0x1
	.long	0x696
	.uleb128 0x3
	.long	0x19a
	.long	0x6bb
	.uleb128 0x4
	.long	0x52
	.sleb128 4
	.byte	0
	.uleb128 0x1
	.long	0x6ab
	.uleb128 0x3
	.long	0x19a
	.long	0x6d0
	.uleb128 0x4
	.long	0x52
	.sleb128 4
	.byte	0
	.uleb128 0x1
	.long	0x6c0
	.uleb128 0x3
	.long	0x19a
	.long	0x6e5
	.uleb128 0x4
	.long	0x52
	.sleb128 9
	.byte	0
	.uleb128 0x1
	.long	0x6d5
	.uleb128 0x3
	.long	0x19a
	.long	0x6fa
	.uleb128 0x4
	.long	0x52
	.sleb128 3
	.byte	0
	.uleb128 0x1
	.long	0x6ea
	.uleb128 0x3
	.long	0x19a
	.long	0x70f
	.uleb128 0x4
	.long	0x52
	.sleb128 4
	.byte	0
	.uleb128 0x1
	.long	0x6ff
	.uleb128 0x3
	.long	0x19a
	.long	0x724
	.uleb128 0x4
	.long	0x52
	.sleb128 7
	.byte	0
	.uleb128 0x1
	.long	0x714
	.uleb128 0x3
	.long	0x19a
	.long	0x739
	.uleb128 0x4
	.long	0x52
	.sleb128 4
	.byte	0
	.uleb128 0x1
	.long	0x729
	.uleb128 0x3
	.long	0x19a
	.long	0x74e
	.uleb128 0x4
	.long	0x52
	.sleb128 6
	.byte	0
	.uleb128 0x1
	.long	0x73e
	.uleb128 0x3
	.long	0x19a
	.long	0x763
	.uleb128 0x4
	.long	0x52
	.sleb128 10
	.byte	0
	.uleb128 0x1
	.long	0x753
	.uleb128 0x3
	.long	0x19a
	.long	0x778
	.uleb128 0x4
	.long	0x52
	.sleb128 8
	.byte	0
	.uleb128 0x1
	.long	0x768
	.uleb128 0x3
	.long	0x19a
	.long	0x78d
	.uleb128 0x4
	.long	0x52
	.sleb128 4
	.byte	0
	.uleb128 0x1
	.long	0x77d
	.uleb128 0x3
	.long	0x19a
	.long	0x7a2
	.uleb128 0x4
	.long	0x52
	.sleb128 3
	.byte	0
	.uleb128 0x1
	.long	0x792
	.uleb128 0x3
	.long	0x19a
	.long	0x7b7
	.uleb128 0x4
	.long	0x52
	.sleb128 13
	.byte	0
	.uleb128 0x1
	.long	0x7a7
	.uleb128 0x3
	.long	0x19a
	.long	0x7cc
	.uleb128 0x4
	.long	0x52
	.sleb128 9
	.byte	0
	.uleb128 0x1
	.long	0x7bc
	.uleb128 0x3
	.long	0x19a
	.long	0x7e1
	.uleb128 0x4
	.long	0x52
	.sleb128 10
	.byte	0
	.uleb128 0x1
	.long	0x7d1
	.uleb128 0x3
	.long	0x19a
	.long	0x7f6
	.uleb128 0x4
	.long	0x52
	.sleb128 10
	.byte	0
	.uleb128 0x1
	.long	0x7e6
	.uleb128 0x3
	.long	0x19a
	.long	0x80b
	.uleb128 0x4
	.long	0x52
	.sleb128 10
	.byte	0
	.uleb128 0x1
	.long	0x7fb
	.uleb128 0x3
	.long	0x19a
	.long	0x820
	.uleb128 0x4
	.long	0x52
	.sleb128 5
	.byte	0
	.uleb128 0x1
	.long	0x810
	.uleb128 0x3
	.long	0x19a
	.long	0x835
	.uleb128 0x4
	.long	0x52
	.sleb128 11
	.byte	0
	.uleb128 0x1
	.long	0x825
	.uleb128 0x3
	.long	0x19a
	.long	0x84a
	.uleb128 0x4
	.long	0x52
	.sleb128 8
	.byte	0
	.uleb128 0x1
	.long	0x83a
	.uleb128 0x3
	.long	0x19a
	.long	0x85f
	.uleb128 0x4
	.long	0x52
	.sleb128 8
	.byte	0
	.uleb128 0x1
	.long	0x84f
	.uleb128 0x3
	.long	0x19a
	.long	0x874
	.uleb128 0x4
	.long	0x52
	.sleb128 11
	.byte	0
	.uleb128 0x1
	.long	0x864
	.uleb128 0x3
	.long	0x19a
	.long	0x889
	.uleb128 0x4
	.long	0x52
	.sleb128 15
	.byte	0
	.uleb128 0x1
	.long	0x879
	.uleb128 0x3
	.long	0x19a
	.long	0x89e
	.uleb128 0x4
	.long	0x52
	.sleb128 10
	.byte	0
	.uleb128 0x1
	.long	0x88e
	.uleb128 0x3
	.long	0x19a
	.long	0x8b3
	.uleb128 0x4
	.long	0x52
	.sleb128 13
	.byte	0
	.uleb128 0x1
	.long	0x8a3
	.uleb128 0x3
	.long	0x19a
	.long	0x8c8
	.uleb128 0x4
	.long	0x52
	.sleb128 10
	.byte	0
	.uleb128 0x1
	.long	0x8b8
	.uleb128 0x3
	.long	0x19a
	.long	0x8dd
	.uleb128 0x4
	.long	0x52
	.sleb128 5
	.byte	0
	.uleb128 0x1
	.long	0x8cd
	.uleb128 0x3
	.long	0x19a
	.long	0x8f2
	.uleb128 0x4
	.long	0x52
	.sleb128 4
	.byte	0
	.uleb128 0x1
	.long	0x8e2
	.uleb128 0x3
	.long	0x19a
	.long	0x907
	.uleb128 0x4
	.long	0x52
	.sleb128 5
	.byte	0
	.uleb128 0x1
	.long	0x8f7
	.uleb128 0x15
	.sleb128 16777217
	.long	.LASF49
	.long	0x52
	.uleb128 0xc
	.long	0x90c
	.uleb128 0x26
	.long	.LASF55
	.byte	0x8
	.byte	0x1
	.byte	0x7e
	.byte	0x9
	.long	0x942
	.uleb128 0x16
	.long	.LASF47
	.byte	0x7f
	.long	0x90c
	.byte	0
	.uleb128 0x16
	.long	.LASF48
	.byte	0x80
	.long	0x90c
	.byte	0x4
	.byte	0
	.uleb128 0xc
	.long	0x91e
	.uleb128 0x17
	.long	.LASF92
	.long	0x19a
	.long	0x95c
	.uleb128 0x4
	.long	0x52
	.sleb128 64
	.byte	0
	.uleb128 0xc
	.long	0x947
	.uleb128 0x15
	.sleb128 64
	.long	.LASF50
	.long	0x52
	.uleb128 0x13
	.long	.LASF51
	.value	0x1d5
	.long	0x98a
	.uleb128 0x6
	.long	.LASF52
	.byte	0
	.uleb128 0x6
	.long	.LASF53
	.byte	0x1
	.uleb128 0x6
	.long	.LASF54
	.byte	0x2
	.byte	0
	.uleb128 0x27
	.long	.LASF56
	.byte	0x18
	.byte	0x1
	.value	0x1d6
	.byte	0x9
	.long	0x9cb
	.uleb128 0x14
	.long	.LASF57
	.value	0x1d7
	.long	0x96c
	.byte	0
	.uleb128 0x28
	.string	"key"
	.byte	0x1
	.value	0x1d8
	.byte	0x7
	.long	0x91e
	.byte	0x4
	.uleb128 0x14
	.long	.LASF58
	.value	0x1d9
	.long	0x91e
	.byte	0xc
	.uleb128 0x14
	.long	.LASF59
	.value	0x1da
	.long	0x90c
	.byte	0x14
	.byte	0
	.uleb128 0xc
	.long	0x98a
	.uleb128 0x3
	.long	0x19a
	.long	0x9e0
	.uleb128 0x4
	.long	0x52
	.sleb128 10
	.byte	0
	.uleb128 0x1
	.long	0x9d0
	.uleb128 0x13
	.long	.LASF60
	.value	0x3e3
	.long	0xa5d
	.uleb128 0x6
	.long	.LASF61
	.byte	0
	.uleb128 0x6
	.long	.LASF62
	.byte	0x1
	.uleb128 0x6
	.long	.LASF63
	.byte	0x2
	.uleb128 0x6
	.long	.LASF64
	.byte	0x3
	.uleb128 0x6
	.long	.LASF65
	.byte	0x4
	.uleb128 0x6
	.long	.LASF66
	.byte	0x5
	.uleb128 0x6
	.long	.LASF67
	.byte	0x6
	.uleb128 0x6
	.long	.LASF68
	.byte	0x7
	.uleb128 0x6
	.long	.LASF69
	.byte	0x8
	.uleb128 0x6
	.long	.LASF70
	.byte	0x9
	.uleb128 0x6
	.long	.LASF71
	.byte	0xa
	.uleb128 0x6
	.long	.LASF72
	.byte	0xb
	.uleb128 0x6
	.long	.LASF73
	.byte	0xc
	.uleb128 0x6
	.long	.LASF74
	.byte	0xd
	.uleb128 0x6
	.long	.LASF75
	.byte	0xe
	.uleb128 0x6
	.long	.LASF76
	.byte	0xf
	.uleb128 0x6
	.long	.LASF77
	.byte	0x10
	.uleb128 0x6
	.long	.LASF78
	.byte	0x11
	.byte	0
	.uleb128 0xc
	.long	0x9e5
	.uleb128 0x13
	.long	.LASF79
	.value	0x4d5
	.long	0xab0
	.uleb128 0x6
	.long	.LASF80
	.byte	0
	.uleb128 0x6
	.long	.LASF81
	.byte	0x1
	.uleb128 0x6
	.long	.LASF82
	.byte	0x2
	.uleb128 0x6
	.long	.LASF83
	.byte	0x3
	.uleb128 0x6
	.long	.LASF84
	.byte	0x4
	.uleb128 0x6
	.long	.LASF85
	.byte	0x5
	.uleb128 0x6
	.long	.LASF86
	.byte	0x6
	.uleb128 0x6
	.long	.LASF87
	.byte	0x7
	.uleb128 0x6
	.long	.LASF88
	.byte	0x8
	.uleb128 0x6
	.long	.LASF89
	.byte	0x9
	.uleb128 0x6
	.long	.LASF90
	.byte	0xa
	.byte	0
	.uleb128 0xc
	.long	0xa62
	.uleb128 0x10
	.byte	0x1
	.byte	0x2
	.long	.LASF91
	.uleb128 0xc
	.long	0xab5
	.uleb128 0x17
	.long	.LASF93
	.long	0xab5
	.long	0xad6
	.uleb128 0x29
	.long	0x9e5
	.byte	0
	.byte	0x11
	.byte	0
	.uleb128 0xc
	.long	0xac1
	.uleb128 0x18
	.long	.LASF96
	.uleb128 0x10
	.byte	0x1
	.byte	0x7
	.long	.LASF94
	.uleb128 0x10
	.byte	0x8
	.byte	0x7
	.long	.LASF95
	.uleb128 0x18
	.long	.LASF97
	.uleb128 0x2
	.long	.LASF98
	.byte	0x1
	.byte	0x1e
	.long	0x195
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_empty
	.uleb128 0x2
	.long	.LASF99
	.byte	0x1
	.byte	0x1f
	.long	0x1b6
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__initialization_prefix
	.uleb128 0x2
	.long	.LASF100
	.byte	0x1
	.byte	0x20
	.long	0x1cb
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__initialization_suffix
	.uleb128 0x2
	.long	.LASF101
	.byte	0x1
	.byte	0x21
	.long	0x1e0
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_imprecise_image
	.uleb128 0x2
	.long	.LASF102
	.byte	0x1
	.byte	0x22
	.long	0x1f6
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_image_message
	.uleb128 0x2
	.long	.LASF103
	.byte	0x1
	.byte	0x23
	.long	0x20b
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_unknown
	.uleb128 0x2
	.long	.LASF104
	.byte	0x1
	.byte	0x24
	.long	0x220
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_ineffective
	.uleb128 0x2
	.long	.LASF105
	.byte	0x1
	.byte	0x25
	.long	0x235
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_dead_code
	.uleb128 0x2
	.long	.LASF106
	.byte	0x1
	.byte	0x26
	.long	0x24a
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_statement_no_effect
	.uleb128 0x2
	.long	.LASF107
	.byte	0x1
	.byte	0x27
	.long	0x25f
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_statement_unreachable
	.uleb128 0x2
	.long	.LASF108
	.byte	0x1
	.byte	0x28
	.long	0x274
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_warning
	.uleb128 0x2
	.long	.LASF109
	.byte	0x1
	.byte	0x29
	.long	0x289
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_unused_assignment
	.uleb128 0x2
	.long	.LASF110
	.byte	0x1
	.byte	0x2a
	.long	0x29f
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_unused_written_count
	.uleb128 0x2
	.long	.LASF111
	.byte	0x1
	.byte	0x2b
	.long	0x2b4
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_unused_flushed
	.uleb128 0x2
	.long	.LASF112
	.byte	0x1
	.byte	0x2c
	.long	0x2ca
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_unused_succeeded
	.uleb128 0x2
	.long	.LASF113
	.byte	0x1
	.byte	0x2d
	.long	0x2e0
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_unused_written_bytes
	.uleb128 0x2
	.long	.LASF114
	.byte	0x1
	.byte	0x2e
	.long	0x2f5
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_put_unused_written_count
	.uleb128 0x2
	.long	.LASF115
	.byte	0x1
	.byte	0x2f
	.long	0x30a
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_put_unused_flushed
	.uleb128 0x2
	.long	.LASF116
	.byte	0x1
	.byte	0x30
	.long	0x31f
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_put_unused_succeeded
	.uleb128 0x2
	.long	.LASF117
	.byte	0x1
	.byte	0x31
	.long	0x334
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_put_unused_written_bytes
	.uleb128 0x2
	.long	.LASF118
	.byte	0x1
	.byte	0x32
	.long	0x349
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_claim_aorte
	.uleb128 0x2
	.long	.LASF119
	.byte	0x1
	.byte	0x33
	.long	0x35e
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_claim_effects
	.uleb128 0x2
	.long	.LASF120
	.byte	0x1
	.byte	0x34
	.long	0x373
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_claim_post
	.uleb128 0x2
	.long	.LASF121
	.byte	0x1
	.byte	0x35
	.long	0x388
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_progress_proof
	.uleb128 0x2
	.long	.LASF122
	.byte	0x1
	.byte	0x36
	.long	0x39d
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_stop_reason_none
	.uleb128 0x2
	.long	.LASF123
	.byte	0x1
	.byte	0x37
	.long	0x3b2
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_arguments
	.uleb128 0x2
	.long	.LASF124
	.byte	0x1
	.byte	0x38
	.long	0x3c7
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_arguments_first_or_default
	.uleb128 0x2
	.long	.LASF125
	.byte	0x1
	.byte	0x39
	.long	0x3dc
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_arguments_input_is_valid
	.uleb128 0x2
	.long	.LASF126
	.byte	0x1
	.byte	0x3a
	.long	0x3f1
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_arguments_is_message
	.uleb128 0x2
	.long	.LASF127
	.byte	0x1
	.byte	0x3b
	.long	0x406
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_arguments_reject
	.uleb128 0x2
	.long	.LASF128
	.byte	0x1
	.byte	0x3c
	.long	0x41b
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_io
	.uleb128 0x2
	.long	.LASF129
	.byte	0x1
	.byte	0x3d
	.long	0x430
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_io_put_line
	.uleb128 0x2
	.long	.LASF130
	.byte	0x1
	.byte	0x3e
	.long	0x445
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_io_put
	.uleb128 0x2
	.long	.LASF131
	.byte	0x1
	.byte	0x3f
	.long	0x45a
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_output_libc
	.uleb128 0x2
	.long	.LASF132
	.byte	0x1
	.byte	0x40
	.long	0x46f
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_output_libc_flush
	.uleb128 0x2
	.long	.LASF133
	.byte	0x1
	.byte	0x41
	.long	0x484
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_output_libc_put_byte
	.uleb128 0x2
	.long	.LASF134
	.byte	0x1
	.byte	0x42
	.long	0x499
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_output_libc_set_exit_status
	.uleb128 0x2
	.long	.LASF135
	.byte	0x1
	.byte	0x43
	.long	0x4ae
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_runtime
	.uleb128 0x2
	.long	.LASF136
	.byte	0x1
	.byte	0x44
	.long	0x4c3
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_runtime_argument
	.uleb128 0x2
	.long	.LASF137
	.byte	0x1
	.byte	0x45
	.long	0x4d8
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_runtime_argument_count
	.uleb128 0x2
	.long	.LASF138
	.byte	0x1
	.byte	0x46
	.long	0x4ed
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_runtime_set_exit_status
	.uleb128 0x2
	.long	.LASF139
	.byte	0x1
	.byte	0x47
	.long	0x502
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_vc_postcondition
	.uleb128 0x2
	.long	.LASF140
	.byte	0x1
	.byte	0x48
	.long	0x517
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_vc_range_check
	.uleb128 0x2
	.long	.LASF141
	.byte	0x1
	.byte	0x49
	.long	0x52c
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_vc_length_check
	.uleb128 0x2
	.long	.LASF142
	.byte	0x1
	.byte	0x4a
	.long	0x541
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_vc_overflow_check
	.uleb128 0x2
	.long	.LASF143
	.byte	0x1
	.byte	0x4b
	.long	0x556
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_vc_division_check
	.uleb128 0x2
	.long	.LASF144
	.byte	0x1
	.byte	0x4c
	.long	0x56b
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_all
	.uleb128 0x2
	.long	.LASF145
	.byte	0x1
	.byte	0x4d
	.long	0x580
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_info
	.uleb128 0x2
	.long	.LASF146
	.byte	0x1
	.byte	0x4e
	.long	0x595
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_main_adb
	.uleb128 0x2
	.long	.LASF147
	.byte	0x1
	.byte	0x4f
	.long	0x5aa
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_prover
	.uleb128 0x2
	.long	.LASF148
	.byte	0x1
	.byte	0x50
	.long	0x5bf
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_arguments_adb
	.uleb128 0x2
	.long	.LASF149
	.byte	0x1
	.byte	0x51
	.long	0x5d4
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_arguments_ads
	.uleb128 0x2
	.long	.LASF150
	.byte	0x1
	.byte	0x52
	.long	0x5e9
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_io_adb
	.uleb128 0x2
	.long	.LASF151
	.byte	0x1
	.byte	0x53
	.long	0x5fe
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_io_ads
	.uleb128 0x2
	.long	.LASF152
	.byte	0x1
	.byte	0x54
	.long	0x613
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_output_libc_ads
	.uleb128 0x2
	.long	.LASF153
	.byte	0x1
	.byte	0x55
	.long	0x628
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_silver_runtime_ads
	.uleb128 0x2
	.long	.LASF154
	.byte	0x1
	.byte	0x56
	.long	0x63d
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_spec
	.uleb128 0x2
	.long	.LASF155
	.byte	0x1
	.byte	0x57
	.long	0x652
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__atom_trivial
	.uleb128 0x2
	.long	.LASF156
	.byte	0x1
	.byte	0x5b
	.long	0x667
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_check_tree
	.uleb128 0x2
	.long	.LASF157
	.byte	0x1
	.byte	0x5c
	.long	0x67c
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_unproved_status
	.uleb128 0x2
	.long	.LASF158
	.byte	0x1
	.byte	0x5d
	.long	0x691
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_status
	.uleb128 0x2
	.long	.LASF159
	.byte	0x1
	.byte	0x5e
	.long	0x6a6
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_sloc
	.uleb128 0x2
	.long	.LASF160
	.byte	0x1
	.byte	0x5f
	.long	0x6bb
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_file
	.uleb128 0x2
	.long	.LASF161
	.byte	0x1
	.byte	0x60
	.long	0x6d0
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_name
	.uleb128 0x2
	.long	.LASF162
	.byte	0x1
	.byte	0x61
	.long	0x6e5
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_predicate
	.uleb128 0x2
	.long	.LASF163
	.byte	0x1
	.byte	0x62
	.long	0x6fa
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_arg
	.uleb128 0x2
	.long	.LASF164
	.byte	0x1
	.byte	0x63
	.long	0x70f
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_rule
	.uleb128 0x2
	.long	.LASF165
	.byte	0x1
	.byte	0x64
	.long	0x724
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_message
	.uleb128 0x2
	.long	.LASF166
	.byte	0x1
	.byte	0x65
	.long	0x739
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_text
	.uleb128 0x2
	.long	.LASF167
	.byte	0x1
	.byte	0x66
	.long	0x74e
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_entity
	.uleb128 0x2
	.long	.LASF168
	.byte	0x1
	.byte	0x67
	.long	0x763
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_how_proved
	.uleb128 0x2
	.long	.LASF169
	.byte	0x1
	.byte	0x68
	.long	0x778
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_severity
	.uleb128 0x2
	.long	.LASF170
	.byte	0x1
	.byte	0x69
	.long	0x78d
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_line
	.uleb128 0x2
	.long	.LASF171
	.byte	0x1
	.byte	0x6a
	.long	0x7a2
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_col
	.uleb128 0x2
	.long	.LASF172
	.byte	0x1
	.byte	0x6b
	.long	0x7b7
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_justification
	.uleb128 0x2
	.long	.LASF173
	.byte	0x1
	.byte	0x6c
	.long	0x7cc
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_justified
	.uleb128 0x2
	.long	.LASF174
	.byte	0x1
	.byte	0x6d
	.long	0x7e1
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_suppressed
	.uleb128 0x2
	.long	.LASF175
	.byte	0x1
	.byte	0x6e
	.long	0x7f6
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_annot_kind
	.uleb128 0x2
	.long	.LASF176
	.byte	0x1
	.byte	0x6f
	.long	0x80b
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_justif_msg
	.uleb128 0x2
	.long	.LASF177
	.byte	0x1
	.byte	0x70
	.long	0x820
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_claim
	.uleb128 0x2
	.long	.LASF178
	.byte	0x1
	.byte	0x71
	.long	0x835
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_assumptions
	.uleb128 0x2
	.long	.LASF179
	.byte	0x1
	.byte	0x72
	.long	0x84a
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_entities
	.uleb128 0x2
	.long	.LASF180
	.byte	0x1
	.byte	0x73
	.long	0x85f
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_progress
	.uleb128 0x2
	.long	.LASF181
	.byte	0x1
	.byte	0x74
	.long	0x874
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_stop_reason
	.uleb128 0x2
	.long	.LASF182
	.byte	0x1
	.byte	0x75
	.long	0x889
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_skip_flow_proof
	.uleb128 0x2
	.long	.LASF183
	.byte	0x1
	.byte	0x76
	.long	0x89e
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_skip_proof
	.uleb128 0x2
	.long	.LASF184
	.byte	0x1
	.byte	0x77
	.long	0x8b3
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_pragma_assume
	.uleb128 0x2
	.long	.LASF185
	.byte	0x1
	.byte	0x78
	.long	0x8c8
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_warn_error
	.uleb128 0x2
	.long	.LASF186
	.byte	0x1
	.byte	0x79
	.long	0x8dd
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_spark
	.uleb128 0x2
	.long	.LASF187
	.byte	0x1
	.byte	0x7a
	.long	0x8f2
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_flow
	.uleb128 0x2
	.long	.LASF188
	.byte	0x1
	.byte	0x7b
	.long	0x907
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__json_proof
	.uleb128 0x2
	.long	.LASF189
	.byte	0x1
	.byte	0x82
	.long	0x942
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__missing
	.uleb128 0x2
	.long	.LASF190
	.byte	0x1
	.byte	0x83
	.long	0x942
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__malformed
	.uleb128 0x2
	.long	.LASF191
	.byte	0x1
	.byte	0x9c
	.long	0x95c
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__empty_nesting
	.uleb128 0x11
	.long	.LASF192
	.value	0x1dc
	.long	0x9cb
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__bad_member
	.uleb128 0x11
	.long	.LASF193
	.value	0x1dd
	.long	0x9cb
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__end_member
	.uleb128 0x11
	.long	.LASF194
	.value	0x2f8
	.long	0x9e0
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__projection_tree_name
	.uleb128 0x11
	.long	.LASF195
	.value	0x66a
	.long	0xad6
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_reports__no_entities
	.uleb128 0x2a
	.long	.LASF284
	.byte	0x1
	.byte	0x1
	.byte	0x6
	.long	0x1312
	.uleb128 0x2b
	.long	.LASF285
	.byte	0x1
	.byte	0x1
	.byte	0x6
	.byte	0
	.uleb128 0x2c
	.byte	0x1
	.byte	0x7
	.byte	0x4
	.long	0x1309
	.uleb128 0x2d
	.long	.LASF196
	.byte	0x10
	.byte	0x3
	.byte	0
	.long	0x135d
	.uleb128 0x19
	.long	.LASF197
	.long	0x1330
	.byte	0
	.uleb128 0x1a
	.long	0x13fd
	.uleb128 0x2e
	.byte	0x8
	.byte	0x3
	.byte	0
	.long	0x1352
	.uleb128 0x1b
	.string	"LB0"
	.long	0x3f
	.byte	0
	.uleb128 0x1b
	.string	"UB0"
	.long	0x3f
	.byte	0x4
	.byte	0
	.uleb128 0x19
	.long	.LASF198
	.long	0x141c
	.byte	0x8
	.byte	0
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x1
	.long	0x131a
	.uleb128 0x3
	.long	0x19a
	.long	0x141c
	.uleb128 0x2f
	.long	0x52
	.uleb128 0x6
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x94
	.byte	0x4
	.uleb128 0x8
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x23
	.uleb128 0x4
	.byte	0x94
	.byte	0x4
	.byte	0
	.uleb128 0x1a
	.long	0x1335
	.uleb128 0xd
	.long	.LASF201
	.value	0x651
	.long	0x131a
	.quad	.LFB54
	.quad	.LFE54-.LFB54
	.uleb128 0x1
	.byte	0x9c
	.long	0x1461
	.uleb128 0x5
	.long	.LASF199
	.value	0x651
	.byte	0x20
	.long	0xa5d
	.uleb128 0x2
	.byte	0x91
	.sleb128 -33
	.uleb128 0x5
	.long	.LASF200
	.value	0x651
	.byte	0x34
	.long	0x180
	.uleb128 0x2
	.byte	0x91
	.sleb128 -34
	.byte	0
	.uleb128 0xd
	.long	.LASF202
	.value	0x633
	.long	0xab5
	.quad	.LFB53
	.quad	.LFE53-.LFB53
	.uleb128 0x1
	.byte	0x9c
	.long	0x14a1
	.uleb128 0x5
	.long	.LASF199
	.value	0x633
	.byte	0x1e
	.long	0xa5d
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.uleb128 0x5
	.long	.LASF200
	.value	0x633
	.byte	0x32
	.long	0x180
	.uleb128 0x2
	.byte	0x91
	.sleb128 -18
	.byte	0
	.uleb128 0xd
	.long	.LASF203
	.value	0x3e7
	.long	0x131a
	.quad	.LFB52
	.quad	.LFE52-.LFB52
	.uleb128 0x1
	.byte	0x9c
	.long	0x14d2
	.uleb128 0x5
	.long	.LASF199
	.value	0x3e7
	.byte	0x1a
	.long	0xa5d
	.uleb128 0x2
	.byte	0x91
	.sleb128 -49
	.byte	0
	.uleb128 0x1c
	.long	.LASF204
	.value	0x2cf
	.long	0x91e
	.quad	.LFB51
	.quad	.LFE51-.LFB51
	.uleb128 0x1
	.byte	0x9c
	.long	0x1512
	.uleb128 0x5
	.long	.LASF205
	.value	0x2cf
	.byte	0x1a
	.long	0x942
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0x5
	.long	.LASF206
	.value	0x2cf
	.byte	0x20
	.long	0x942
	.uleb128 0x2
	.byte	0x91
	.sleb128 -32
	.byte	0
	.uleb128 0x1d
	.long	.LASF207
	.byte	0x89
	.long	0xab5
	.quad	.LFB50
	.quad	.LFE50-.LFB50
	.uleb128 0x1
	.byte	0x9c
	.long	0x153f
	.uleb128 0x1e
	.string	"c"
	.byte	0x89
	.byte	0x14
	.long	0x1a1
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.byte	0
	.uleb128 0x1d
	.long	.LASF208
	.byte	0x85
	.long	0xab5
	.quad	.LFB49
	.quad	.LFE49-.LFB49
	.uleb128 0x1
	.byte	0x9c
	.long	0x157e
	.uleb128 0xe
	.long	.LASF209
	.byte	0x1
	.byte	0x85
	.byte	0x14
	.long	0x13f8
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0xe
	.long	.LASF210
	.byte	0x1
	.byte	0x85
	.byte	0x23
	.long	0x942
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.byte	0
	.uleb128 0x1f
	.long	.LASF211
	.byte	0x17
	.long	0xc0
	.quad	.LFB48
	.quad	.LFE48-.LFB48
	.uleb128 0x1
	.byte	0x9c
	.long	0x15ae
	.uleb128 0xe
	.long	.LASF200
	.byte	0x1
	.byte	0x17
	.byte	0x17
	.long	0xbb
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.byte	0
	.uleb128 0xd
	.long	.LASF212
	.value	0x10ed
	.long	0xab5
	.quad	.LFB47
	.quad	.LFE47-.LFB47
	.uleb128 0x1
	.byte	0x9c
	.long	0x15ee
	.uleb128 0xe
	.long	.LASF213
	.byte	0x2
	.byte	0x55
	.byte	0x7
	.long	0x13f3
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0xe
	.long	.LASF200
	.byte	0x2
	.byte	0x55
	.byte	0x18
	.long	0x92
	.uleb128 0x2
	.byte	0x91
	.sleb128 -49
	.byte	0
	.uleb128 0xd
	.long	.LASF214
	.value	0x10e8
	.long	0xab5
	.quad	.LFB46
	.quad	.LFE46-.LFB46
	.uleb128 0x1
	.byte	0x9c
	.long	0x162e
	.uleb128 0xe
	.long	.LASF213
	.byte	0x2
	.byte	0x42
	.byte	0x7
	.long	0x13ee
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0xe
	.long	.LASF200
	.byte	0x2
	.byte	0x42
	.byte	0x18
	.long	0xbb
	.uleb128 0x2
	.byte	0x91
	.sleb128 -49
	.byte	0
	.uleb128 0x9
	.long	.LASF215
	.value	0x10dc
	.long	0xab5
	.quad	.LFB45
	.quad	.LFE45-.LFB45
	.uleb128 0x1
	.byte	0x9c
	.long	0x166e
	.uleb128 0x5
	.long	.LASF213
	.value	0x10dc
	.byte	0x1b
	.long	0x13e9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0x5
	.long	.LASF200
	.value	0x10dc
	.byte	0x2c
	.long	0x180
	.uleb128 0x2
	.byte	0x91
	.sleb128 -49
	.byte	0
	.uleb128 0x9
	.long	.LASF216
	.value	0x10d3
	.long	0xab5
	.quad	.LFB44
	.quad	.LFE44-.LFB44
	.uleb128 0x1
	.byte	0x9c
	.long	0x16f2
	.uleb128 0x5
	.long	.LASF213
	.value	0x10d3
	.byte	0x23
	.long	0x13e4
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x5
	.long	.LASF200
	.value	0x10d3
	.byte	0x34
	.long	0x180
	.uleb128 0x3
	.byte	0x91
	.sleb128 -97
	.uleb128 0xa
	.quad	.LBB155
	.quad	.LBE155-.LBB155
	.uleb128 0xb
	.long	.LASF235
	.long	0x52
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.uleb128 0x3
	.long	0x19a
	.long	0x16df
	.uleb128 0x20
	.long	0x52
	.long	0x16c0
	.byte	0
	.uleb128 0x7
	.long	.LASF209
	.value	0x10d7
	.byte	0x7
	.long	0x16cc
	.uleb128 0x4
	.byte	0x91
	.sleb128 -72
	.byte	0x6
	.byte	0
	.byte	0
	.uleb128 0x9
	.long	.LASF217
	.value	0x109d
	.long	0xab5
	.quad	.LFB43
	.quad	.LFE43-.LFB43
	.uleb128 0x1
	.byte	0x9c
	.long	0x1796
	.uleb128 0x5
	.long	.LASF209
	.value	0x109d
	.byte	0x26
	.long	0x13df
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x5
	.long	.LASF200
	.value	0x109d
	.byte	0x35
	.long	0x180
	.uleb128 0x3
	.byte	0x91
	.sleb128 -113
	.uleb128 0xa
	.quad	.LBB154
	.quad	.LBE154-.LBB154
	.uleb128 0x7
	.long	.LASF218
	.value	0x10a4
	.byte	0xa
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x7
	.long	.LASF48
	.value	0x10a5
	.byte	0xa
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x7
	.long	.LASF219
	.value	0x10a6
	.byte	0xa
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x7
	.long	.LASF220
	.value	0x10a7
	.byte	0xa
	.long	0x91e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -88
	.uleb128 0x7
	.long	.LASF221
	.value	0x10a7
	.byte	0x12
	.long	0x91e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.byte	0
	.byte	0
	.uleb128 0x9
	.long	.LASF222
	.value	0x725
	.long	0xab5
	.quad	.LFB42
	.quad	.LFE42-.LFB42
	.uleb128 0x1
	.byte	0x9c
	.long	0x17f5
	.uleb128 0x5
	.long	.LASF209
	.value	0x725
	.byte	0x1a
	.long	0x13da
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0x5
	.long	.LASF223
	.value	0x725
	.byte	0x29
	.long	0x942
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x5
	.long	.LASF221
	.value	0x725
	.byte	0x33
	.long	0x942
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x5
	.long	.LASF200
	.value	0x725
	.byte	0x44
	.long	0x180
	.uleb128 0x3
	.byte	0x91
	.sleb128 -65
	.byte	0
	.uleb128 0x9
	.long	.LASF224
	.value	0x71d
	.long	0xab5
	.quad	.LFB41
	.quad	.LFE41-.LFB41
	.uleb128 0x1
	.byte	0x9c
	.long	0x1844
	.uleb128 0x5
	.long	.LASF209
	.value	0x71d
	.byte	0x1a
	.long	0x13d5
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0x5
	.long	.LASF221
	.value	0x71d
	.byte	0x29
	.long	0x942
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x5
	.long	.LASF200
	.value	0x71d
	.byte	0x3a
	.long	0x180
	.uleb128 0x2
	.byte	0x91
	.sleb128 -57
	.byte	0
	.uleb128 0x9
	.long	.LASF225
	.value	0x6d5
	.long	0xab5
	.quad	.LFB38
	.quad	.LFE38-.LFB38
	.uleb128 0x1
	.byte	0x9c
	.long	0x190e
	.uleb128 0x5
	.long	.LASF209
	.value	0x6d5
	.byte	0x15
	.long	0x13d0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -240
	.uleb128 0x5
	.long	.LASF226
	.value	0x6d5
	.byte	0x24
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -248
	.uleb128 0x5
	.long	.LASF221
	.value	0x6d5
	.byte	0x2b
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -256
	.uleb128 0x5
	.long	.LASF200
	.value	0x6d6
	.byte	0x15
	.long	0x180
	.uleb128 0x3
	.byte	0x91
	.sleb128 -257
	.uleb128 0x5
	.long	.LASF223
	.value	0x6d6
	.byte	0x28
	.long	0xabc
	.uleb128 0x3
	.byte	0x91
	.sleb128 -258
	.uleb128 0xf
	.long	.LLRL4
	.uleb128 0x7
	.long	.LASF227
	.value	0x6da
	.byte	0x7
	.long	0xac1
	.uleb128 0x3
	.byte	0x91
	.sleb128 -176
	.uleb128 0x8
	.string	"p"
	.value	0x6db
	.byte	0x7
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x8
	.string	"m"
	.value	0x6dc
	.byte	0x7
	.long	0x98a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -208
	.uleb128 0x7
	.long	.LASF199
	.value	0x6dd
	.byte	0x7
	.long	0x9e5
	.uleb128 0x3
	.byte	0x91
	.sleb128 -69
	.uleb128 0xf
	.long	.LLRL5
	.uleb128 0x7
	.long	.LASF199
	.value	0x718
	.byte	0x17
	.long	0x9e5
	.uleb128 0x3
	.byte	0x91
	.sleb128 -70
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x1c
	.long	.LASF228
	.value	0x661
	.long	0xac1
	.quad	.LFB36
	.quad	.LFE36-.LFB36
	.uleb128 0x1
	.byte	0x9c
	.long	0x194f
	.uleb128 0x5
	.long	.LASF227
	.value	0x661
	.byte	0x17
	.long	0x194f
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x5
	.long	.LASF199
	.value	0x661
	.byte	0x2a
	.long	0xa5d
	.uleb128 0x3
	.byte	0x91
	.sleb128 -65
	.byte	0
	.uleb128 0x21
	.long	0xac1
	.uleb128 0x9
	.long	.LASF229
	.value	0x613
	.long	0xab5
	.quad	.LFB34
	.quad	.LFE34-.LFB34
	.uleb128 0x1
	.byte	0x9c
	.long	0x19d4
	.uleb128 0x5
	.long	.LASF209
	.value	0x614
	.byte	0x7
	.long	0x13cb
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x5
	.long	.LASF226
	.value	0x614
	.byte	0x16
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -120
	.uleb128 0x5
	.long	.LASF221
	.value	0x614
	.byte	0x1d
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0xa
	.quad	.LBB118
	.quad	.LBE118-.LBB118
	.uleb128 0x8
	.string	"p"
	.value	0x618
	.byte	0x7
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x8
	.string	"m"
	.value	0x619
	.byte	0x7
	.long	0x98a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.byte	0
	.byte	0
	.uleb128 0x9
	.long	.LASF230
	.value	0x5d2
	.long	0xab5
	.quad	.LFB33
	.quad	.LFE33-.LFB33
	.uleb128 0x1
	.byte	0x9c
	.long	0x1a74
	.uleb128 0x5
	.long	.LASF209
	.value	0x5d3
	.byte	0x7
	.long	0x13c6
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x5
	.long	.LASF226
	.value	0x5d3
	.byte	0x16
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -120
	.uleb128 0x5
	.long	.LASF221
	.value	0x5d3
	.byte	0x1d
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x5
	.long	.LASF200
	.value	0x5d3
	.byte	0x2e
	.long	0xab0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -129
	.uleb128 0xa
	.quad	.LBB111
	.quad	.LBE111-.LBB111
	.uleb128 0x8
	.string	"p"
	.value	0x5d7
	.byte	0x7
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x8
	.string	"m"
	.value	0x5d8
	.byte	0x7
	.long	0x98a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x7
	.long	.LASF231
	.value	0x5d9
	.byte	0x7
	.long	0xab5
	.uleb128 0x3
	.byte	0x91
	.sleb128 -69
	.byte	0
	.byte	0
	.uleb128 0x9
	.long	.LASF232
	.value	0x536
	.long	0xab5
	.quad	.LFB31
	.quad	.LFE31-.LFB31
	.uleb128 0x1
	.byte	0x9c
	.long	0x1af8
	.uleb128 0x5
	.long	.LASF209
	.value	0x537
	.byte	0x7
	.long	0x13c1
	.uleb128 0x3
	.byte	0x91
	.sleb128 -256
	.uleb128 0x5
	.long	.LASF210
	.value	0x537
	.byte	0x16
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -264
	.uleb128 0x5
	.long	.LASF221
	.value	0x537
	.byte	0x1c
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -272
	.uleb128 0x5
	.long	.LASF200
	.value	0x537
	.byte	0x2d
	.long	0xab0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -273
	.uleb128 0xa
	.quad	.LBB97
	.quad	.LBE97-.LBB97
	.uleb128 0x8
	.string	"how"
	.value	0x53b
	.byte	0x7
	.long	0x91e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.byte	0
	.byte	0
	.uleb128 0xd
	.long	.LASF233
	.value	0x4cb
	.long	0xab5
	.quad	.LFB29
	.quad	.LFE29-.LFB29
	.uleb128 0x1
	.byte	0x9c
	.long	0x1b3a
	.uleb128 0x5
	.long	.LASF209
	.value	0x4c7
	.byte	0x1d
	.long	0x13bc
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x5
	.long	.LASF210
	.value	0x4c7
	.byte	0x2c
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -88
	.byte	0
	.uleb128 0xd
	.long	.LASF234
	.value	0x4bb
	.long	0xab5
	.quad	.LFB28
	.quad	.LFE28-.LFB28
	.uleb128 0x1
	.byte	0x9c
	.long	0x1bc4
	.uleb128 0x5
	.long	.LASF209
	.value	0x4b7
	.byte	0x22
	.long	0x13b7
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x5
	.long	.LASF210
	.value	0x4b7
	.byte	0x31
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0xa
	.quad	.LBB87
	.quad	.LBE87-.LBB87
	.uleb128 0xb
	.long	.LASF236
	.long	0x52
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0xb
	.long	.LASF237
	.long	0x52
	.uleb128 0x2
	.byte	0x91
	.sleb128 -44
	.uleb128 0xa
	.quad	.LBB90
	.quad	.LBE90-.LBB90
	.uleb128 0x8
	.string	"i"
	.value	0x4c3
	.byte	0x1b
	.long	0x52
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x9
	.long	.LASF238
	.value	0x4a7
	.long	0xab5
	.quad	.LFB27
	.quad	.LFE27-.LFB27
	.uleb128 0x1
	.byte	0x9c
	.long	0x1c46
	.uleb128 0x5
	.long	.LASF209
	.value	0x4a7
	.byte	0x1b
	.long	0x13b2
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x5
	.long	.LASF221
	.value	0x4a7
	.byte	0x2a
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -88
	.uleb128 0x5
	.long	.LASF239
	.value	0x4a7
	.byte	0x34
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0xa
	.quad	.LBB84
	.quad	.LBE84-.LBB84
	.uleb128 0x7
	.long	.LASF240
	.value	0x4ab
	.byte	0x7
	.long	0x91e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x7
	.long	.LASF241
	.value	0x4ac
	.byte	0x7
	.long	0x91e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.byte	0
	.byte	0
	.uleb128 0x9
	.long	.LASF242
	.value	0x48b
	.long	0x91e
	.quad	.LFB25
	.quad	.LFE25-.LFB25
	.uleb128 0x1
	.byte	0x9c
	.long	0x1d34
	.uleb128 0x5
	.long	.LASF209
	.value	0x48b
	.byte	0x20
	.long	0x13ad
	.uleb128 0x3
	.byte	0x91
	.sleb128 -192
	.uleb128 0x5
	.long	.LASF221
	.value	0x48b
	.byte	0x2f
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -200
	.uleb128 0x22
	.string	"arg"
	.value	0x48b
	.byte	0x39
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -208
	.uleb128 0xf
	.long	.LLRL2
	.uleb128 0xb
	.long	.LASF243
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0xb
	.long	.LASF244
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x23
	.quad	.LBB80
	.quad	.LBE80-.LBB80
	.long	0x1cda
	.uleb128 0x8
	.string	"i"
	.value	0x491
	.byte	0x17
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.uleb128 0xf
	.long	.LLRL3
	.uleb128 0xb
	.long	.LASF245
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0xb
	.long	.LASF246
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -84
	.uleb128 0x3
	.long	0x19a
	.long	0x1d10
	.uleb128 0x30
	.long	0x52
	.long	0x1cdf
	.long	0x1cec
	.byte	0
	.uleb128 0x7
	.long	.LASF247
	.value	0x494
	.byte	0xa
	.long	0x1cf9
	.uleb128 0x4
	.byte	0x91
	.sleb128 -112
	.byte	0x6
	.uleb128 0x7
	.long	.LASF241
	.value	0x495
	.byte	0xa
	.long	0x91e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -168
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0xd
	.long	.LASF248
	.value	0x470
	.long	0x131a
	.quad	.LFB24
	.quad	.LFE24-.LFB24
	.uleb128 0x1
	.byte	0x9c
	.long	0x1db6
	.uleb128 0x5
	.long	.LASF209
	.value	0x470
	.byte	0x19
	.long	0x13a8
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x22
	.string	"arg"
	.value	0x470
	.byte	0x28
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -136
	.uleb128 0xa
	.quad	.LBB72
	.quad	.LBE72-.LBB72
	.uleb128 0xb
	.long	.LASF249
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x3
	.long	0x19a
	.long	0x1da6
	.uleb128 0x20
	.long	0x52
	.long	0x1d86
	.byte	0
	.uleb128 0xb
	.long	.LASF250
	.long	0x1d93
	.uleb128 0x4
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0
	.byte	0
	.uleb128 0xd
	.long	.LASF251
	.value	0x46c
	.long	0xab5
	.quad	.LFB23
	.quad	.LFE23-.LFB23
	.uleb128 0x1
	.byte	0x9c
	.long	0x1df7
	.uleb128 0x5
	.long	.LASF209
	.value	0x469
	.byte	0x1e
	.long	0x13a3
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x5
	.long	.LASF210
	.value	0x469
	.byte	0x2d
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.byte	0
	.uleb128 0xd
	.long	.LASF252
	.value	0x464
	.long	0xab5
	.quad	.LFB22
	.quad	.LFE22-.LFB22
	.uleb128 0x1
	.byte	0x9c
	.long	0x1ebf
	.uleb128 0x5
	.long	.LASF209
	.value	0x461
	.byte	0x1e
	.long	0x139e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x5
	.long	.LASF210
	.value	0x461
	.byte	0x2d
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -104
	.uleb128 0xa
	.quad	.LBB64
	.quad	.LBE64-.LBB64
	.uleb128 0xb
	.long	.LASF253
	.long	0x90c
	.uleb128 0x2
	.byte	0x91
	.sleb128 -60
	.uleb128 0xb
	.long	.LASF254
	.long	0x90c
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0xb
	.long	.LASF255
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0xb
	.long	.LASF256
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x23
	.quad	.LBB67
	.quad	.LBE67-.LBB67
	.long	0x1e9e
	.uleb128 0x8
	.string	"i"
	.value	0x466
	.byte	0x19
	.long	0x52
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.byte	0
	.uleb128 0xa
	.quad	.LBB68
	.quad	.LBE68-.LBB68
	.uleb128 0x8
	.string	"i"
	.value	0x467
	.byte	0x1a
	.long	0x52
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x9
	.long	.LASF257
	.value	0x444
	.long	0x9e5
	.quad	.LFB21
	.quad	.LFE21-.LFB21
	.uleb128 0x1
	.byte	0x9c
	.long	0x1f33
	.uleb128 0x5
	.long	.LASF209
	.value	0x444
	.byte	0x1a
	.long	0x1399
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x5
	.long	.LASF241
	.value	0x444
	.byte	0x29
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -104
	.uleb128 0xa
	.quad	.LBB61
	.quad	.LBE61-.LBB61
	.uleb128 0x7
	.long	.LASF199
	.value	0x448
	.byte	0x7
	.long	0x91e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x7
	.long	.LASF258
	.value	0x449
	.byte	0x7
	.long	0x9e5
	.uleb128 0x3
	.byte	0x91
	.sleb128 -65
	.byte	0
	.byte	0
	.uleb128 0xd
	.long	.LASF259
	.value	0x421
	.long	0xab5
	.quad	.LFB20
	.quad	.LFE20-.LFB20
	.uleb128 0x1
	.byte	0x9c
	.long	0x1f73
	.uleb128 0x5
	.long	.LASF209
	.value	0x41e
	.byte	0x1c
	.long	0x1394
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0x5
	.long	.LASF199
	.value	0x41e
	.byte	0x2b
	.long	0x942
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.byte	0
	.uleb128 0x9
	.long	.LASF260
	.value	0x403
	.long	0xab5
	.quad	.LFB18
	.quad	.LFE18-.LFB18
	.uleb128 0x1
	.byte	0x9c
	.long	0x2009
	.uleb128 0x5
	.long	.LASF209
	.value	0x403
	.byte	0x1a
	.long	0x138f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x5
	.long	.LASF241
	.value	0x403
	.byte	0x29
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -152
	.uleb128 0x5
	.long	.LASF199
	.value	0x403
	.byte	0x38
	.long	0xa5d
	.uleb128 0x3
	.byte	0x91
	.sleb128 -153
	.uleb128 0xf
	.long	.LLRL1
	.uleb128 0x7
	.long	.LASF261
	.value	0x408
	.byte	0x7
	.long	0x91e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -120
	.uleb128 0x8
	.string	"p"
	.value	0x409
	.byte	0x7
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x7
	.long	.LASF48
	.value	0x409
	.byte	0xa
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x7
	.long	.LASF262
	.value	0x40a
	.byte	0x7
	.long	0x91e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.byte	0
	.byte	0
	.uleb128 0x9
	.long	.LASF263
	.value	0x3d3
	.long	0xab5
	.quad	.LFB16
	.quad	.LFE16-.LFB16
	.uleb128 0x1
	.byte	0x9c
	.long	0x206a
	.uleb128 0x5
	.long	.LASF209
	.value	0x3d3
	.byte	0x1a
	.long	0x138a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x5
	.long	.LASF210
	.value	0x3d3
	.byte	0x29
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -88
	.uleb128 0xa
	.quad	.LBB47
	.quad	.LBE47-.LBB47
	.uleb128 0x8
	.string	"p"
	.value	0x3d7
	.byte	0x7
	.long	0x90c
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.byte	0
	.byte	0
	.uleb128 0x9
	.long	.LASF264
	.value	0x3ba
	.long	0xab5
	.quad	.LFB15
	.quad	.LFE15-.LFB15
	.uleb128 0x1
	.byte	0x9c
	.long	0x20cb
	.uleb128 0x5
	.long	.LASF209
	.value	0x3ba
	.byte	0x1b
	.long	0x1385
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x5
	.long	.LASF210
	.value	0x3ba
	.byte	0x2a
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -88
	.uleb128 0xa
	.quad	.LBB44
	.quad	.LBE44-.LBB44
	.uleb128 0x8
	.string	"p"
	.value	0x3be
	.byte	0x7
	.long	0x90c
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.byte	0
	.byte	0
	.uleb128 0x9
	.long	.LASF265
	.value	0x390
	.long	0x91e
	.quad	.LFB14
	.quad	.LFE14-.LFB14
	.uleb128 0x1
	.byte	0x9c
	.long	0x215b
	.uleb128 0x5
	.long	.LASF209
	.value	0x390
	.byte	0x14
	.long	0x1380
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x5
	.long	.LASF220
	.value	0x390
	.byte	0x23
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -136
	.uleb128 0x5
	.long	.LASF199
	.value	0x390
	.byte	0x32
	.long	0x137b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0xa
	.quad	.LBB37
	.quad	.LBE37-.LBB37
	.uleb128 0x8
	.string	"p"
	.value	0x394
	.byte	0x7
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x8
	.string	"m"
	.value	0x395
	.byte	0x7
	.long	0x98a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x7
	.long	.LASF258
	.value	0x396
	.byte	0x7
	.long	0x91e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -104
	.byte	0
	.byte	0
	.uleb128 0x9
	.long	.LASF266
	.value	0x2b6
	.long	0x98a
	.quad	.LFB13
	.quad	.LFE13-.LFB13
	.uleb128 0x1
	.byte	0x9c
	.long	0x21e9
	.uleb128 0x5
	.long	.LASF209
	.value	0x2b6
	.byte	0x18
	.long	0x1376
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x5
	.long	.LASF226
	.value	0x2b6
	.byte	0x27
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x5
	.long	.LASF267
	.value	0x2b6
	.byte	0x35
	.long	0x919
	.uleb128 0x3
	.byte	0x91
	.sleb128 -116
	.uleb128 0xa
	.quad	.LBB32
	.quad	.LBE32-.LBB32
	.uleb128 0x8
	.string	"p"
	.value	0x2bd
	.byte	0x7
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x8
	.string	"l"
	.value	0x2be
	.byte	0x7
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x8
	.string	"t"
	.value	0x2be
	.byte	0xa
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.byte	0
	.byte	0
	.uleb128 0x9
	.long	.LASF268
	.value	0x260
	.long	0x98a
	.quad	.LFB12
	.quad	.LFE12-.LFB12
	.uleb128 0x1
	.byte	0x9c
	.long	0x2293
	.uleb128 0x5
	.long	.LASF209
	.value	0x260
	.byte	0x1a
	.long	0x1371
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x5
	.long	.LASF220
	.value	0x260
	.byte	0x29
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x5
	.long	.LASF267
	.value	0x260
	.byte	0x38
	.long	0x919
	.uleb128 0x3
	.byte	0x91
	.sleb128 -132
	.uleb128 0xa
	.quad	.LBB27
	.quad	.LBE27-.LBB27
	.uleb128 0x8
	.string	"p"
	.value	0x267
	.byte	0x7
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x8
	.string	"k"
	.value	0x268
	.byte	0x7
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x8
	.string	"v"
	.value	0x268
	.byte	0xa
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x8
	.string	"l"
	.value	0x268
	.byte	0xd
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x8
	.string	"t"
	.value	0x268
	.byte	0x10
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -84
	.byte	0
	.byte	0
	.uleb128 0xd
	.long	.LASF269
	.value	0x1cf
	.long	0xab5
	.quad	.LFB10
	.quad	.LFE10-.LFB10
	.uleb128 0x1
	.byte	0x9c
	.long	0x22e4
	.uleb128 0x5
	.long	.LASF209
	.value	0x1cb
	.byte	0x1b
	.long	0x136c
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x5
	.long	.LASF210
	.value	0x1cb
	.byte	0x2a
	.long	0x942
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x5
	.long	.LASF270
	.value	0x1cb
	.byte	0x37
	.long	0x1367
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.byte	0
	.uleb128 0x9
	.long	.LASF271
	.value	0x16b
	.long	0x90c
	.quad	.LFB9
	.quad	.LFE9-.LFB9
	.uleb128 0x1
	.byte	0x9c
	.long	0x23b6
	.uleb128 0x5
	.long	.LASF209
	.value	0x16b
	.byte	0x18
	.long	0x1362
	.uleb128 0x3
	.byte	0x91
	.sleb128 -176
	.uleb128 0x5
	.long	.LASF218
	.value	0x16b
	.byte	0x27
	.long	0x919
	.uleb128 0x3
	.byte	0x91
	.sleb128 -180
	.uleb128 0xa
	.quad	.LBB16
	.quad	.LBE16-.LBB16
	.uleb128 0x7
	.long	.LASF272
	.value	0x170
	.byte	0x7
	.long	0x947
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0x7
	.long	.LASF273
	.value	0x171
	.byte	0x7
	.long	0x961
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x7
	.long	.LASF274
	.value	0x172
	.byte	0x7
	.long	0xab5
	.uleb128 0x3
	.byte	0x91
	.sleb128 -69
	.uleb128 0x7
	.long	.LASF275
	.value	0x173
	.byte	0x7
	.long	0xab5
	.uleb128 0x3
	.byte	0x91
	.sleb128 -70
	.uleb128 0x7
	.long	.LASF276
	.value	0x174
	.byte	0x7
	.long	0xab5
	.uleb128 0x3
	.byte	0x91
	.sleb128 -77
	.uleb128 0xb
	.long	.LASF277
	.long	0x90c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -84
	.uleb128 0xb
	.long	.LASF278
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -88
	.uleb128 0xf
	.long	.LLRL0
	.uleb128 0x8
	.string	"i"
	.value	0x17a
	.byte	0xb
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x9
	.long	.LASF279
	.value	0x159
	.long	0x90c
	.quad	.LFB7
	.quad	.LFE7-.LFB7
	.uleb128 0x1
	.byte	0x9c
	.long	0x23fa
	.uleb128 0x5
	.long	.LASF209
	.value	0x159
	.byte	0x1a
	.long	0x135d
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x5
	.long	.LASF267
	.value	0x159
	.byte	0x29
	.long	0x90c
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x10
	.byte	0
	.uleb128 0x1f
	.long	.LASF280
	.byte	0xa0
	.long	0x947
	.quad	.LFB6
	.quad	.LFE6-.LFB6
	.uleb128 0x1
	.byte	0x9c
	.long	0x2448
	.uleb128 0xe
	.long	.LASF272
	.byte	0x1
	.byte	0xa0
	.byte	0x15
	.long	0x2448
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0xe
	.long	.LASF281
	.byte	0x1
	.byte	0xa0
	.byte	0x26
	.long	0x4d
	.uleb128 0x3
	.byte	0x91
	.sleb128 -116
	.uleb128 0x1e
	.string	"c"
	.byte	0xa0
	.byte	0x38
	.long	0x1a1
	.uleb128 0x3
	.byte	0x91
	.sleb128 -117
	.byte	0
	.uleb128 0x21
	.long	0x947
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x28
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x1c
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x55
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3e
	.uleb128 0x21
	.sleb128 7
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3e
	.uleb128 0x21
	.sleb128 7
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x14
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 7
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x15
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x16
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 7
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x17
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x18
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x3e
	.uleb128 0x21
	.sleb128 5
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x19
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x1a
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1b
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x1c
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1d
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1e
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x1f
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x20
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x21
	.uleb128 0x10
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x22
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x23
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x24
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x55
	.uleb128 0x17
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x25
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x26
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x27
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x28
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x29
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0xb
	.uleb128 0x2f
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x2a
	.uleb128 0x1e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x2b
	.uleb128 0x1e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x2c
	.uleb128 0x3a
	.byte	0
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x18
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x2d
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x2e
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x2f
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x18
	.uleb128 0x2f
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x30
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0x13
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0xbc
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.LFE6-.Ltext0
	.quad	.LFB7
	.quad	.LFE10-.LFB7
	.quad	.LFB12
	.quad	.LFE16-.LFB12
	.quad	.LFB18
	.quad	.LFE24-.LFB18
	.quad	.LFB25
	.quad	.LFE29-.LFB25
	.quad	.LFB31
	.quad	.LFE31-.LFB31
	.quad	.LFB33
	.quad	.LFE34-.LFB33
	.quad	.LFB36
	.quad	.LFE36-.LFB36
	.quad	.LFB38
	.quad	.LFE38-.LFB38
	.quad	.LFB41
	.quad	.Letext0-.LFB41
	.quad	0
	.quad	0
	.section	.debug_rnglists,"",@progbits
.Ldebug_ranges0:
	.long	.Ldebug_ranges3-.Ldebug_ranges2
.Ldebug_ranges2:
	.value	0x5
	.byte	0x8
	.byte	0
	.long	0
.LLRL0:
	.byte	0x5
	.quad	.LBB20
	.byte	0x4
	.uleb128 .LBB20-.LBB20
	.uleb128 .LBE20-.LBB20
	.byte	0x4
	.uleb128 .LBB23-.LBB20
	.uleb128 .LBE23-.LBB20
	.byte	0
.LLRL1:
	.byte	0x5
	.quad	.LBB52
	.byte	0x4
	.uleb128 .LBB52-.LBB52
	.uleb128 .LBE52-.LBB52
	.byte	0x4
	.uleb128 .LBB57-.LBB52
	.uleb128 .LBE57-.LBB52
	.byte	0
.LLRL2:
	.byte	0x5
	.quad	.LBB77
	.byte	0x4
	.uleb128 .LBB77-.LBB77
	.uleb128 .LBE77-.LBB77
	.byte	0x4
	.uleb128 .LBB83-.LBB77
	.uleb128 .LBE83-.LBB77
	.byte	0
.LLRL3:
	.byte	0x5
	.quad	.LBB81
	.byte	0x4
	.uleb128 .LBB81-.LBB81
	.uleb128 .LBE81-.LBB81
	.byte	0x4
	.uleb128 .LBB82-.LBB81
	.uleb128 .LBE82-.LBB81
	.byte	0
.LLRL4:
	.byte	0x5
	.quad	.LBB125
	.byte	0x4
	.uleb128 .LBB125-.LBB125
	.uleb128 .LBE125-.LBB125
	.byte	0x4
	.uleb128 .LBB145-.LBB125
	.uleb128 .LBE145-.LBB125
	.byte	0
.LLRL5:
	.byte	0x5
	.quad	.LBB137
	.byte	0x4
	.uleb128 .LBB137-.LBB137
	.uleb128 .LBE137-.LBB137
	.byte	0x4
	.uleb128 .LBB142-.LBB137
	.uleb128 .LBE142-.LBB137
	.byte	0x4
	.uleb128 .LBB144-.LBB137
	.uleb128 .LBE144-.LBB137
	.byte	0
.LLRL6:
	.byte	0x7
	.quad	.Ltext0
	.uleb128 .LFE6-.Ltext0
	.byte	0x7
	.quad	.LFB7
	.uleb128 .LFE10-.LFB7
	.byte	0x7
	.quad	.LFB12
	.uleb128 .LFE16-.LFB12
	.byte	0x7
	.quad	.LFB18
	.uleb128 .LFE24-.LFB18
	.byte	0x7
	.quad	.LFB25
	.uleb128 .LFE29-.LFB25
	.byte	0x7
	.quad	.LFB31
	.uleb128 .LFE31-.LFB31
	.byte	0x7
	.quad	.LFB33
	.uleb128 .LFE34-.LFB33
	.byte	0x7
	.quad	.LFB36
	.uleb128 .LFE36-.LFB36
	.byte	0x7
	.quad	.LFB38
	.uleb128 .LFE38-.LFB38
	.byte	0x7
	.quad	.LFB41
	.uleb128 .Letext0-.LFB41
	.byte	0
.Ldebug_ranges3:
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF172:
	.string	"silver_library_reports__json_justification"
.LASF166:
	.string	"silver_library_reports__json_text"
.LASF194:
	.string	"silver_library_reports__projection_tree_name"
.LASF51:
	.string	"silver_library_reports__member_state"
.LASF29:
	.string	"silver_library_reports__argument_put_without_query"
.LASF58:
	.string	"value"
.LASF169:
	.string	"silver_library_reports__json_severity"
.LASF19:
	.string	"silver_library_reports__static_main"
.LASF155:
	.string	"silver_library_reports__atom_trivial"
.LASF28:
	.string	"silver_library_reports__argument_without_query"
.LASF151:
	.string	"silver_library_reports__atom_silver_io_ads"
.LASF33:
	.string	"silver_library_reports__assignment_effects"
.LASF182:
	.string	"silver_library_reports__json_skip_flow_proof"
.LASF146:
	.string	"silver_library_reports__atom_main_adb"
.LASF78:
	.string	"silver_library_reports__main_entity"
.LASF111:
	.string	"silver_library_reports__atom_unused_flushed"
.LASF173:
	.string	"silver_library_reports__json_justified"
.LASF40:
	.string	"silver_library_reports__selected_without_query"
.LASF244:
	.string	"R584b"
.LASF181:
	.string	"silver_library_reports__json_stop_reason"
.LASF220:
	.string	"object"
.LASF152:
	.string	"silver_library_reports__atom_silver_output_libc_ads"
.LASF16:
	.string	"silver_library_reports__libc_interface"
.LASF205:
	.string	"left"
.LASF148:
	.string	"silver_library_reports__atom_silver_arguments_adb"
.LASF124:
	.string	"silver_library_reports__atom_silver_arguments_first_or_default"
.LASF216:
	.string	"silver_library_reports__audit_rebased_report"
.LASF71:
	.string	"silver_library_reports__first_or_default"
.LASF14:
	.string	"silver_library_reports__audit_kind"
.LASF127:
	.string	"silver_library_reports__atom_silver_arguments_reject"
.LASF12:
	.string	"silver_library_reports__arguments_body"
.LASF263:
	.string	"silver_library_reports__empty_array"
.LASF195:
	.string	"silver_library_reports__no_entities"
.LASF254:
	.string	"R528b"
.LASF279:
	.string	"silver_library_reports__skip_space"
.LASF240:
	.string	"predicate"
.LASF207:
	.string	"silver_library_reports__space"
.LASF285:
	.string	"big_integers"
.LASF276:
	.string	"container"
.LASF59:
	.string	"next"
.LASF66:
	.string	"silver_library_reports__put_byte"
.LASF63:
	.string	"silver_library_reports__put_line"
.LASF267:
	.string	"position"
.LASF222:
	.string	"silver_library_reports__coverage_ok"
.LASF206:
	.string	"right"
.LASF101:
	.string	"silver_library_reports__atom_imprecise_image"
.LASF21:
	.string	"silver_library_reports__static_mixed"
.LASF104:
	.string	"silver_library_reports__atom_ineffective"
.LASF75:
	.string	"silver_library_reports__argument_count"
.LASF13:
	.string	"silver_library_reports__runtime_interface"
.LASF130:
	.string	"silver_library_reports__atom_silver_io_put"
.LASF190:
	.string	"silver_library_reports__malformed"
.LASF52:
	.string	"silver_library_reports__broken"
.LASF265:
	.string	"silver_library_reports__field"
.LASF38:
	.string	"silver_library_reports__selected_mixed"
.LASF266:
	.string	"silver_library_reports__read_item"
.LASF176:
	.string	"silver_library_reports__json_justif_msg"
.LASF120:
	.string	"silver_library_reports__atom_claim_post"
.LASF213:
	.string	"report"
.LASF57:
	.string	"state"
.LASF3:
	.string	"silver_library_reports__max_runtime_report_length"
.LASF86:
	.string	"silver_library_reports__image_advisories"
.LASF76:
	.string	"silver_library_reports__argument"
.LASF117:
	.string	"silver_library_reports__atom_put_unused_written_bytes"
.LASF122:
	.string	"silver_library_reports__atom_stop_reason_none"
.LASF215:
	.string	"silver_library_reports__audit_report"
.LASF160:
	.string	"silver_library_reports__json_file"
.LASF192:
	.string	"silver_library_reports__bad_member"
.LASF177:
	.string	"silver_library_reports__json_claim"
.LASF277:
	.string	"silver_library_reports__value_end__L_2__T187b___L"
.LASF202:
	.string	"silver_library_reports__expected_entity"
.LASF268:
	.string	"silver_library_reports__read_member"
.LASF99:
	.string	"silver_library_reports__initialization_prefix"
.LASF283:
	.string	"positive"
.LASF156:
	.string	"silver_library_reports__json_check_tree"
.LASF214:
	.string	"silver_library_reports__complete_runtime_proof"
.LASF225:
	.string	"silver_library_reports__map_ok"
.LASF32:
	.string	"silver_library_reports__assignment_main"
.LASF81:
	.string	"silver_library_reports__main_checks"
.LASF89:
	.string	"silver_library_reports__put_postconditions"
.LASF84:
	.string	"silver_library_reports__assignment_diagnostics"
.LASF142:
	.string	"silver_library_reports__atom_vc_overflow_check"
.LASF46:
	.string	"character"
.LASF186:
	.string	"silver_library_reports__json_spark"
.LASF73:
	.string	"silver_library_reports__is_message"
.LASF271:
	.string	"silver_library_reports__value_end"
.LASF106:
	.string	"silver_library_reports__atom_statement_no_effect"
.LASF228:
	.string	"silver_library_reports__remember"
.LASF163:
	.string	"silver_library_reports__json_arg"
.LASF257:
	.string	"silver_library_reports__entity_name"
.LASF280:
	.string	"silver_library_reports__pushed"
.LASF158:
	.string	"silver_library_reports__json_status"
.LASF15:
	.string	"silver_library_reports__io_body"
.LASF118:
	.string	"silver_library_reports__atom_claim_aorte"
.LASF264:
	.string	"silver_library_reports__empty_object"
.LASF174:
	.string	"silver_library_reports__json_suppressed"
.LASF261:
	.string	"locations"
.LASF229:
	.string	"silver_library_reports__dependencies_ok"
.LASF79:
	.string	"silver_library_reports__list_kind"
.LASF4:
	.string	"silver_library_reports__static_output"
.LASF44:
	.string	"silver_library_reports__selected_binding_main"
.LASF45:
	.string	"integer"
.LASF179:
	.string	"silver_library_reports__json_entities"
.LASF135:
	.string	"silver_library_reports__atom_silver_runtime"
.LASF270:
	.string	"expected"
.LASF232:
	.string	"silver_library_reports__record_ok"
.LASF107:
	.string	"silver_library_reports__atom_statement_unreachable"
.LASF227:
	.string	"seen"
.LASF26:
	.string	"silver_library_reports__binding_main"
.LASF199:
	.string	"name"
.LASF6:
	.string	"silver_library_reports__assigned_output"
.LASF238:
	.string	"silver_library_reports__reference_ok"
.LASF284:
	.string	"spark"
.LASF281:
	.string	"level"
.LASF200:
	.string	"kind"
.LASF65:
	.string	"silver_library_reports__libc_package"
.LASF56:
	.string	"silver_library_reports__member"
.LASF273:
	.string	"depth"
.LASF147:
	.string	"silver_library_reports__atom_prover"
.LASF48:
	.string	"last"
.LASF212:
	.string	"silver_library_reports__complete_application_proof"
.LASF136:
	.string	"silver_library_reports__atom_silver_runtime_argument"
.LASF68:
	.string	"silver_library_reports__set_exit_status"
.LASF247:
	.string	"number"
.LASF259:
	.string	"silver_library_reports__main_spelling"
.LASF224:
	.string	"silver_library_reports__entities_ok"
.LASF95:
	.string	"system__address"
.LASF69:
	.string	"silver_library_reports__arguments_package"
.LASF23:
	.string	"silver_library_reports__main_put"
.LASF145:
	.string	"silver_library_reports__atom_info"
.LASF234:
	.string	"silver_library_reports__initializer_message"
.LASF43:
	.string	"silver_library_reports__selected_effects_without_query"
.LASF211:
	.string	"silver_library_reports__audit_of"
.LASF210:
	.string	"item"
.LASF22:
	.string	"silver_library_reports__main_body"
.LASF167:
	.string	"silver_library_reports__json_entity"
.LASF82:
	.string	"silver_library_reports__binding_diagnostics"
.LASF217:
	.string	"silver_library_reports__audit_normalized_report"
.LASF94:
	.string	"system__storage_elements__storage_element"
.LASF5:
	.string	"silver_library_reports__argument_output"
.LASF9:
	.string	"silver_library_reports__report_kind"
.LASF219:
	.string	"tail"
.LASF150:
	.string	"silver_library_reports__atom_silver_io_adb"
.LASF233:
	.string	"silver_library_reports__output_message"
.LASF223:
	.string	"coverage"
.LASF239:
	.string	"reference"
.LASF250:
	.string	"S562b"
.LASF251:
	.string	"silver_library_reports__nonempty_string"
.LASF184:
	.string	"silver_library_reports__json_pragma_assume"
.LASF178:
	.string	"silver_library_reports__json_assumptions"
.LASF50:
	.string	"silver_library_reports__nesting_level"
.LASF183:
	.string	"silver_library_reports__json_skip_proof"
.LASF241:
	.string	"entity"
.LASF93:
	.string	"silver_library_reports__entity_set"
.LASF157:
	.string	"silver_library_reports__json_unproved_status"
.LASF203:
	.string	"silver_library_reports__entity_file"
.LASF108:
	.string	"silver_library_reports__atom_warning"
.LASF85:
	.string	"silver_library_reports__selected_diagnostics"
.LASF53:
	.string	"silver_library_reports__finished"
.LASF60:
	.string	"silver_library_reports__entity_kind"
.LASF20:
	.string	"silver_library_reports__static_put"
.LASF42:
	.string	"silver_library_reports__selected_mixed_without_query"
.LASF116:
	.string	"silver_library_reports__atom_put_unused_succeeded"
.LASF185:
	.string	"silver_library_reports__json_warn_error"
.LASF61:
	.string	"silver_library_reports__unknown"
.LASF139:
	.string	"silver_library_reports__atom_vc_postcondition"
.LASF132:
	.string	"silver_library_reports__atom_silver_output_libc_flush"
.LASF201:
	.string	"silver_library_reports__expected_coverage"
.LASF274:
	.string	"quoted"
.LASF175:
	.string	"silver_library_reports__json_annot_kind"
.LASF191:
	.string	"silver_library_reports__empty_nesting"
.LASF141:
	.string	"silver_library_reports__atom_vc_length_check"
.LASF36:
	.string	"silver_library_reports__selected_main"
.LASF204:
	.string	"silver_library_reports__merge_field"
.LASF7:
	.string	"silver_library_reports__selected_output"
.LASF131:
	.string	"silver_library_reports__atom_silver_output_libc"
.LASF159:
	.string	"silver_library_reports__json_sloc"
.LASF87:
	.string	"silver_library_reports__references"
.LASF144:
	.string	"silver_library_reports__atom_all"
.LASF126:
	.string	"silver_library_reports__atom_silver_arguments_is_message"
.LASF125:
	.string	"silver_library_reports__atom_silver_arguments_input_is_valid"
.LASF62:
	.string	"silver_library_reports__io_package"
.LASF37:
	.string	"silver_library_reports__selected_put"
.LASF260:
	.string	"silver_library_reports__location_ok"
.LASF110:
	.string	"silver_library_reports__atom_unused_written_count"
.LASF80:
	.string	"silver_library_reports__checks"
.LASF18:
	.string	"silver_library_reports__argv_interface"
.LASF30:
	.string	"silver_library_reports__argument_mixed_without_query"
.LASF221:
	.string	"entities"
.LASF17:
	.string	"silver_library_reports__argument_body"
.LASF128:
	.string	"silver_library_reports__atom_silver_io"
.LASF262:
	.string	"file"
.LASF100:
	.string	"silver_library_reports__initialization_suffix"
.LASF138:
	.string	"silver_library_reports__atom_silver_runtime_set_exit_status"
.LASF105:
	.string	"silver_library_reports__atom_dead_code"
.LASF112:
	.string	"silver_library_reports__atom_unused_succeeded"
.LASF218:
	.string	"start"
.LASF180:
	.string	"silver_library_reports__json_progress"
.LASF88:
	.string	"silver_library_reports__postconditions"
.LASF64:
	.string	"silver_library_reports__put"
.LASF90:
	.string	"silver_library_reports__argument_postconditions"
.LASF92:
	.string	"silver_library_reports__nesting"
.LASF164:
	.string	"silver_library_reports__json_rule"
.LASF98:
	.string	"silver_library_reports__atom_empty"
.LASF256:
	.string	"R534b"
.LASF230:
	.string	"silver_library_reports__list_ok"
.LASF25:
	.string	"silver_library_reports__argument_effects"
.LASF196:
	.string	"string"
.LASF134:
	.string	"silver_library_reports__atom_silver_output_libc_set_exit_status"
.LASF137:
	.string	"silver_library_reports__atom_silver_runtime_argument_count"
.LASF47:
	.string	"first"
.LASF129:
	.string	"silver_library_reports__atom_silver_io_put_line"
.LASF236:
	.string	"silver_library_reports__initializer_message__B632b__L633b__T634b___L"
.LASF165:
	.string	"silver_library_reports__json_message"
.LASF133:
	.string	"silver_library_reports__atom_silver_output_libc_put_byte"
.LASF143:
	.string	"silver_library_reports__atom_vc_division_check"
.LASF2:
	.string	"silver_library_reports__max_report_length"
.LASF27:
	.string	"silver_library_reports__argument_binding_main"
.LASF209:
	.string	"text"
.LASF208:
	.string	"silver_library_reports__valid"
.LASF242:
	.string	"silver_library_reports__referenced_entity"
.LASF91:
	.string	"boolean"
.LASF31:
	.string	"silver_library_reports__argument_effects_without_query"
.LASF171:
	.string	"silver_library_reports__json_col"
.LASF55:
	.string	"silver_library_reports__span"
.LASF275:
	.string	"escaped"
.LASF235:
	.string	"silver_library_reports__audit_rebased_report__TTtextSP1___U"
.LASF34:
	.string	"silver_library_reports__assignment_put"
.LASF170:
	.string	"silver_library_reports__json_line"
.LASF189:
	.string	"silver_library_reports__missing"
.LASF193:
	.string	"silver_library_reports__end_member"
.LASF154:
	.string	"silver_library_reports__atom_spec"
.LASF188:
	.string	"silver_library_reports__json_proof"
.LASF255:
	.string	"R533b"
.LASF97:
	.string	"system__storage_elements__Tstorage_offsetB"
.LASF123:
	.string	"silver_library_reports__atom_silver_arguments"
.LASF67:
	.string	"silver_library_reports__flush"
.LASF109:
	.string	"silver_library_reports__atom_unused_assignment"
.LASF72:
	.string	"silver_library_reports__reject"
.LASF149:
	.string	"silver_library_reports__atom_silver_arguments_ads"
.LASF253:
	.string	"R527b"
.LASF8:
	.string	"silver_library_reports__application_kind"
.LASF121:
	.string	"silver_library_reports__atom_progress_proof"
.LASF231:
	.string	"found"
.LASF162:
	.string	"silver_library_reports__json_predicate"
.LASF140:
	.string	"silver_library_reports__atom_vc_range_check"
.LASF77:
	.string	"silver_library_reports__runtime_exit_status"
.LASF249:
	.string	"silver_library_reports__padded_key__TTS562bSP1___U"
.LASF197:
	.string	"P_ARRAY"
.LASF245:
	.string	"silver_library_reports__referenced_entity__B_6__T587b___L"
.LASF252:
	.string	"silver_library_reports__positive_number"
.LASF39:
	.string	"silver_library_reports__selected_effects"
.LASF115:
	.string	"silver_library_reports__atom_put_unused_flushed"
.LASF35:
	.string	"silver_library_reports__assignment_mixed"
.LASF54:
	.string	"silver_library_reports__present"
.LASF103:
	.string	"silver_library_reports__atom_unknown"
.LASF161:
	.string	"silver_library_reports__json_name"
.LASF248:
	.string	"silver_library_reports__padded_key"
.LASF113:
	.string	"silver_library_reports__atom_unused_written_bytes"
.LASF83:
	.string	"silver_library_reports__argument_diagnostics"
.LASF243:
	.string	"R583b"
.LASF237:
	.string	"silver_library_reports__initializer_message__B632b__L633b__T634b___U"
.LASF269:
	.string	"silver_library_reports__string_equal"
.LASF114:
	.string	"silver_library_reports__atom_put_unused_written_count"
.LASF278:
	.string	"silver_library_reports__value_end__L_2__T187b___U"
.LASF153:
	.string	"silver_library_reports__atom_silver_runtime_ads"
.LASF187:
	.string	"silver_library_reports__json_flow"
.LASF119:
	.string	"silver_library_reports__atom_claim_effects"
.LASF74:
	.string	"silver_library_reports__runtime_package"
.LASF102:
	.string	"silver_library_reports__atom_image_message"
.LASF70:
	.string	"silver_library_reports__input_is_valid"
.LASF272:
	.string	"stack"
.LASF24:
	.string	"silver_library_reports__main_mixed"
.LASF96:
	.string	"system__parameters__Tsize_typeB"
.LASF49:
	.string	"silver_library_reports__offset"
.LASF282:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF11:
	.string	"silver_library_reports__imported_interface"
.LASF41:
	.string	"silver_library_reports__selected_put_without_query"
.LASF258:
	.string	"result"
.LASF226:
	.string	"items"
.LASF168:
	.string	"silver_library_reports__json_how_proved"
.LASF10:
	.string	"silver_library_reports__library_body"
.LASF198:
	.string	"P_BOUNDS"
.LASF246:
	.string	"silver_library_reports__referenced_entity__B_6__T587b___U"
	.section	.debug_line_str,"MS",@progbits,1
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_library_reports.adb"
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
	.hidden	DW.ref.__gnat_personality_v0
	.weak	DW.ref.__gnat_personality_v0
	.section	.data.rel.local.DW.ref.__gnat_personality_v0,"awG",@progbits,DW.ref.__gnat_personality_v0,comdat
	.align 8
	.type	DW.ref.__gnat_personality_v0, @object
	.size	DW.ref.__gnat_personality_v0, 8
DW.ref.__gnat_personality_v0:
	.quad	__gnat_personality_v0
	.globl	__gnat_personality_v0
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
