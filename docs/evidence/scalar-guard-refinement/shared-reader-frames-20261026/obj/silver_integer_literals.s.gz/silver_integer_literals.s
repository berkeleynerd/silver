	.file	"silver_integer_literals.adb"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_integer_literals.adb"
	.align 2
	.globl	silver_integer_literals__literal_resultIP
	.type	silver_integer_literals__literal_resultIP, @function
silver_integer_literals__literal_resultIP:
.LFB2:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	silver_integer_literals__literal_resultIP, .-silver_integer_literals__literal_resultIP
	.section	.rodata
.LC4:
	.ascii	"silver_integer_literals.adb"
	.zero	1
	.align 8
.LC5:
	.ascii	"Loop_Invariant failed at silver_integer_literals.adb:62"
	.align 8
.LC6:
	.ascii	"Loop_Invariant failed at silver_integer_literals.adb:63"
	.align 8
.LC7:
	.ascii	"Loop_Invariant failed at silver_integer_literals.adb:64"
	.align 8
.LC8:
	.ascii	"Loop_Variant failed at silver_integer_literals.adb:67"
	.align 8
.LC0:
	.long	1
	.long	55
	.align 8
.LC2:
	.long	1
	.long	53
	.text
	.align 2
	.type	silver_integer_literals__numeral___wrapped_statements.0, @function
silver_integer_literals__numeral___wrapped_statements.0:
.LFB4:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_integer_literals.adb"
	.loc 1 54 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -72(%rbp)
	.loc 1 54 4
	movl	28(%rbx), %eax
	movl	%eax, -84(%rbp)
	movl	24(%rbx), %r13d
.LBB2:
	.loc 1 56 7
	movl	20(%rbx), %eax
	movl	%eax, -52(%rbp)
	.loc 1 57 7
	movl	$0, -56(%rbp)
	.loc 1 58 7
	movb	$1, -57(%rbp)
	.loc 1 60 7
	cmpl	$0, -52(%rbp)
	jne	.L3
	.loc 1 60 24 discriminator 1
	movl	$0, %eax
	movq	%rax, -80(%rbp)
	jmp	.L4
.L3:
	.loc 1 61 31
	movb	$0, -85(%rbp)
.L34:
.LBB3:
	.loc 1 61 18 discriminator 1
	cmpl	-52(%rbp), %r13d
	jl	.L5
	.loc 1 62 33
	movl	20(%rbx), %eax
	cmpl	%eax, -52(%rbp)
	jl	.L6
	.loc 1 62 63 discriminator 1
	cmpl	$2147483647, %r13d
	jne	.L7
	.loc 1 62 63 is_stmt 0 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$62, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L7:
	.loc 1 62 63 discriminator 4
	leal	1(%r13), %eax
	.loc 1 62 38 is_stmt 1 discriminator 5
	cmpl	-52(%rbp), %eax
	jge	.L8
.L6:
.LBB4:
	.loc 1 62 33 discriminator 6
	leaq	.LC5(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rcx
	movq	-136(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L8:
.LBE4:
	.loc 1 63 33
	movl	20(%rbx), %eax
	cmpl	%eax, -52(%rbp)
	je	.L9
	.loc 1 63 49 discriminator 1
	movl	20(%rbx), %eax
	cmpl	%eax, -52(%rbp)
	jg	.L9
.LBB5:
	.loc 1 63 33 discriminator 2
	leaq	.LC6(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rsi
	movq	-120(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L9:
.LBE5:
	.loc 1 64 33
	movl	20(%rbx), %eax
	cmpl	%eax, -52(%rbp)
	jne	.L10
	.loc 1 64 33 is_stmt 0 discriminator 1
	movzbl	-57(%rbp), %eax
	xorl	$1, %eax
	testb	%al, %al
	je	.L10
.LBB6:
	.loc 1 64 33 discriminator 2
	leaq	.LC7(%rip), %rax
	movq	%rax, -112(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -104(%rbp)
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L10:
.LBE6:
	.loc 1 67 10 is_stmt 1
	cmpb	$0, -85(%rbp)
	je	.L11
	.loc 1 67 44 discriminator 1
	movl	-92(%rbp), %eax
	movl	%eax, -96(%rbp)
.L11:
	.loc 1 67 44 is_stmt 0 discriminator 2
	movl	-52(%rbp), %eax
	movl	%eax, -92(%rbp)
	.loc 1 67 10 is_stmt 1 discriminator 2
	cmpb	$0, -85(%rbp)
	je	.L12
	.loc 1 67 44 discriminator 3
	movl	-96(%rbp), %ecx
	cmpl	%ecx, %eax
	jg	.L13
.LBB7:
	.loc 1 67 44 is_stmt 0 discriminator 4
	leaq	.LC8(%rip), %r14
	leaq	.LC2(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L12:
.LBE7:
	.loc 1 67 10 is_stmt 1 discriminator 5
	movb	$1, -85(%rbp)
.L13:
	.loc 1 68 20
	movl	-84(%rbp), %eax
	cmpl	-52(%rbp), %eax
	jg	.L14
	.loc 1 68 20 is_stmt 0 discriminator 1
	cmpl	-52(%rbp), %r13d
	jge	.L15
.L14:
	.loc 1 68 20 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$68, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L15:
	.loc 1 68 13 is_stmt 1 discriminator 3
	movq	8(%rbx), %rax
	movq	(%rax), %rcx
	movl	-52(%rbp), %eax
	movslq	%eax, %rdx
	movq	(%rbx), %rax
	subq	%rax, %rdx
	movzbl	(%rcx,%rdx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_integer_literals__digit
	movl	%eax, %edx
	.loc 1 68 10 discriminator 4
	movl	16(%rbx), %eax
	cmpl	%edx, %eax
	jle	.L16
	.loc 1 69 52
	movl	-84(%rbp), %eax
	cmpl	-52(%rbp), %eax
	jg	.L17
	.loc 1 69 52 is_stmt 0 discriminator 1
	cmpl	-52(%rbp), %r13d
	jge	.L18
.L17:
	.loc 1 69 52 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$69, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L18:
	.loc 1 69 45 is_stmt 1 discriminator 3
	movq	8(%rbx), %rax
	movq	(%rax), %rcx
	movl	-52(%rbp), %eax
	movslq	%eax, %rdx
	movq	(%rbx), %rax
	subq	%rax, %rdx
	movzbl	(%rcx,%rdx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_integer_literals__digit
	movl	%eax, %edx
	.loc 1 69 43 discriminator 4
	movl	$4096, %eax
	subl	%edx, %eax
	.loc 1 69 66 discriminator 4
	movl	16(%rbx), %ecx
	cltd
	idivl	%ecx
	.loc 1 69 13 discriminator 4
	cmpl	%eax, -56(%rbp)
	jle	.L19
	.loc 1 70 16
	movl	$0, %eax
	movq	%rax, -80(%rbp)
	jmp	.L4
.L19:
	.loc 1 72 44
	movl	-84(%rbp), %eax
	cmpl	-52(%rbp), %eax
	jg	.L20
	.loc 1 72 44 is_stmt 0 discriminator 1
	cmpl	-52(%rbp), %r13d
	jge	.L21
.L20:
	.loc 1 72 44 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$72, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L21:
	.loc 1 72 35 is_stmt 1 discriminator 3
	movl	16(%rbx), %eax
	imull	-56(%rbp), %eax
	movl	%eax, %r12d
	.loc 1 72 37 discriminator 3
	movq	8(%rbx), %rax
	movq	(%rax), %rcx
	movl	-52(%rbp), %eax
	movslq	%eax, %rdx
	movq	(%rbx), %rax
	subq	%rax, %rdx
	movzbl	(%rcx,%rdx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_integer_literals__digit
	.loc 1 72 35 discriminator 4
	movl	$0, %edx
	addl	%r12d, %eax
	jno	.L22
	movl	$1, %edx
.L22:
	movl	%eax, %ecx
	.loc 1 72 35 is_stmt 0 discriminator 5
	movl	%edx, %eax
	testl	%eax, %eax
	je	.L24
	.loc 1 72 35 discriminator 6
	leaq	.LC4(%rip), %rax
	movl	$72, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L24:
	.loc 1 72 35 discriminator 8
	movl	%ecx, %eax
	.loc 1 72 35 discriminator 9
	testl	%eax, %eax
	js	.L25
	.loc 1 72 35 discriminator 10
	cmpl	$4096, %eax
	jle	.L26
.L25:
	.loc 1 72 35 discriminator 11
	leaq	.LC4(%rip), %rax
	movl	$72, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L26:
	.loc 1 72 19 is_stmt 1 discriminator 12
	movl	%eax, -56(%rbp)
	.loc 1 73 24
	movb	$0, -57(%rbp)
	jmp	.L27
.L16:
	.loc 1 74 16
	movl	-84(%rbp), %eax
	cmpl	-52(%rbp), %eax
	jg	.L28
	.loc 1 74 16 is_stmt 0 discriminator 1
	cmpl	-52(%rbp), %r13d
	jge	.L29
.L28:
	.loc 1 74 16 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$74, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L29:
	.loc 1 74 28 is_stmt 1 discriminator 3
	movq	8(%rbx), %rax
	movq	(%rax), %rcx
	movl	-52(%rbp), %eax
	movslq	%eax, %rdx
	movq	(%rbx), %rax
	subq	%rax, %rdx
	movzbl	(%rcx,%rdx), %eax
	.loc 1 74 10 discriminator 3
	cmpb	$95, %al
	jne	.L36
	.loc 1 75 13
	cmpb	$0, -57(%rbp)
	je	.L31
	.loc 1 75 32 discriminator 1
	movl	$0, %eax
	movq	%rax, -80(%rbp)
	jmp	.L4
.L31:
	.loc 1 76 24
	movb	$1, -57(%rbp)
.L27:
	.loc 1 80 23
	movl	-52(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L32
	.loc 1 80 23 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L33
.L32:
	.loc 1 80 23 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$80, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L33:
	.loc 1 80 15 is_stmt 1 discriminator 3
	movl	%eax, -52(%rbp)
.LBE3:
	.loc 1 81 15
	jmp	.L34
.L36:
.LBB8:
	.loc 1 78 13
	nop
.L5:
.LBE8:
	.loc 1 82 7
	cmpb	$0, -57(%rbp)
	je	.L35
	.loc 1 82 26 discriminator 1
	movl	$0, %eax
	movq	%rax, -80(%rbp)
	jmp	.L4
.L35:
	.loc 1 83 7
	movl	-52(%rbp), %eax
	movabsq	$-4294967296, %rdx
	andq	-80(%rbp), %rdx
	orq	%rdx, %rax
	movq	%rax, %rsi
	movl	-56(%rbp), %eax
	salq	$32, %rax
	movl	%esi, %edx
	orq	%rdx, %rax
	movq	%rax, -80(%rbp)
.L4:
.LBE2:
	.loc 1 84 8
	movq	-80(%rbp), %rax
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	silver_integer_literals__numeral___wrapped_statements.0, .-silver_integer_literals__numeral___wrapped_statements.0
	.section	.rodata
	.align 8
.LC9:
	.ascii	"failed precondition from silver_integer_literals.adb:48"
	.align 8
.LC10:
	.ascii	"failed precondition from silver_integer_literals.adb:49"
	.align 8
.LC11:
	.ascii	"failed postcondition from silver_integer_literals.adb:50"
	.align 8
.LC1:
	.long	1
	.long	56
	.text
	.align 2
	.type	silver_integer_literals__numeral, @function
silver_integer_literals__numeral:
.LFB3:
	.loc 1 54 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %rbx
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%rbx, %rdi
	movq	%rsi, -128(%rbp)
	movq	%rdi, -120(%rbp)
	movl	%edx, -132(%rbp)
	movl	%ecx, -136(%rbp)
	.loc 1 54 4
	leaq	16(%rbp), %rdx
	.loc 1 54 4 is_stmt 0 discriminator 1
	leaq	-128(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -88(%rbp)
	movl	-132(%rbp), %eax
	movl	%eax, -76(%rbp)
	movl	-136(%rbp), %eax
	movl	%eax, -80(%rbp)
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -68(%rbp)
	movq	-120(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -72(%rbp)
	movl	-72(%rbp), %edx
	movl	-68(%rbp), %eax
	cmpl	%eax, %edx
	jl	.L38
	.loc 1 54 4 discriminator 2
	movl	-72(%rbp), %ecx
	movslq	%ecx, %rax
	cqto
	movl	-68(%rbp), %esi
	movslq	%esi, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L39
.L38:
	.loc 1 54 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L39:
.LBB9:
	.loc 1 54 4 discriminator 4
	movl	-68(%rbp), %ecx
	movslq	%ecx, %rcx
	movq	%rcx, -96(%rbp)
	movl	-72(%rbp), %esi
	movl	-68(%rbp), %ecx
	cmpl	%ecx, %esi
	.loc 1 54 4 discriminator 7
	movl	-72(%rbp), %esi
	movl	-68(%rbp), %ecx
	cmpl	%ecx, %esi
	.loc 1 54 4 discriminator 10
	movl	-72(%rbp), %esi
	movl	-68(%rbp), %ecx
	cmpl	%ecx, %esi
	.loc 1 48 15 is_stmt 1
	movl	-68(%rbp), %ecx
	cmpl	$1, %ecx
	je	.L46
.LBB10:
	.loc 1 48 15 is_stmt 0 discriminator 1
	leaq	.LC9(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L46:
.LBE10:
	.loc 1 48 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 1 48 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L47
	.loc 1 48 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L48
.L47:
.LBB11:
	.loc 1 48 15 discriminator 4
	leaq	.LC9(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L48:
.LBE11:
	.loc 1 49 41
	movl	-72(%rbp), %eax
	cmpl	$2147483647, %eax
	jne	.L49
	.loc 1 49 41 is_stmt 0 discriminator 1
	leaq	.LC4(%rip), %rax
	movl	$49, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L49:
	.loc 1 49 41 discriminator 3
	movl	-72(%rbp), %eax
	leal	1(%rax), %edx
	.loc 1 48 15 is_stmt 1 discriminator 5
	movl	-76(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L50
.LBB12:
	.loc 1 48 15 is_stmt 0 discriminator 6
	leaq	.LC10(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L50:
.LBE12:
.LBB13:
	.loc 1 54 4 is_stmt 1 discriminator 13
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
	call	silver_integer_literals__numeral___wrapped_statements.0
	movq	%rax, -104(%rbp)
	.loc 1 50 49
	movl	-104(%rbp), %eax
	.loc 1 50 28
	testl	%eax, %eax
	je	.L51
	.loc 1 51 40
	movl	-104(%rbp), %eax
	.loc 1 51 10
	movl	-76(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L52
	.loc 1 52 42
	movl	-104(%rbp), %eax
	.loc 1 52 55
	movl	-72(%rbp), %edx
	cmpl	$2147483647, %edx
	jne	.L53
	.loc 1 52 55 is_stmt 0 discriminator 1
	leaq	.LC4(%rip), %rax
	movl	$52, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L53:
	.loc 1 52 55 discriminator 3
	movl	-72(%rbp), %edx
	addl	$1, %edx
	.loc 1 52 12 is_stmt 1 discriminator 4
	cmpl	%eax, %edx
	jge	.L51
.L52:
.LBB14:
	.loc 1 50 28 discriminator 1
	leaq	.LC11(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L51:
.LBE14:
	.loc 1 54 4 discriminator 14
	movq	-104(%rbp), %rax
.LBE13:
.LBE9:
	.loc 1 54 4 is_stmt 0
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.size	silver_integer_literals__numeral, .-silver_integer_literals__numeral
	.align 2
	.globl	silver_integer_literals__mantissa_resultIP
	.type	silver_integer_literals__mantissa_resultIP, @function
silver_integer_literals__mantissa_resultIP:
.LFB5:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	.cfi_offset 3, -24
	movq	%rcx, %rax
	movq	%rbx, %rdx
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE5:
	.size	silver_integer_literals__mantissa_resultIP, .-silver_integer_literals__mantissa_resultIP
	.align 2
	.type	silver_integer_literals__read_mantissa___wrapped_statements.1, @function
silver_integer_literals__read_mantissa___wrapped_statements.1:
.LFB7:
	.loc 1 122 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%r10, %rbx
	movq	%r10, -72(%rbp)
	.loc 1 122 4
	movl	24(%rbx), %r13d
	movl	20(%rbx), %r12d
.LBB15:
	.loc 1 123 44
	movq	8(%rbx), %rax
	movl	16(%rbx), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$10, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_integer_literals__numeral
	movq	%rax, -56(%rbp)
	.loc 1 125 24
	movl	-56(%rbp), %eax
	.loc 1 125 7
	testl	%eax, %eax
	jne	.L57
	.loc 1 125 33 discriminator 1
	movq	silver_integer_literals__invalid_mantissa(%rip), %rax
	movq	%rax, -44(%rbp)
	movl	8+silver_integer_literals__invalid_mantissa(%rip), %eax
	movl	%eax, -36(%rbp)
	jmp	.L83
.L57:
	.loc 1 126 24
	movl	-56(%rbp), %eax
	.loc 1 126 7
	cmpl	%eax, %r12d
	jl	.L59
	.loc 1 126 46 discriminator 1
	movl	-56(%rbp), %eax
	cmpl	%eax, %r13d
	jg	.L60
	.loc 1 126 46 is_stmt 0 discriminator 2
	movl	-56(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L61
.L60:
	.loc 1 126 46 discriminator 3
	leaq	.LC4(%rip), %rax
	movl	$126, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L61:
	.loc 1 126 70 is_stmt 1 discriminator 4
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movl	-56(%rbp), %edx
	movslq	%edx, %rcx
	movq	(%rbx), %rdx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 1 126 76 discriminator 5
	cmpb	$35, %al
	je	.L62
	.loc 1 126 76 is_stmt 0 discriminator 6
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movl	-56(%rbp), %edx
	movslq	%edx, %rcx
	movq	(%rbx), %rdx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 1 126 76 discriminator 7
	cmpb	$58, %al
	jne	.L63
.L62:
	.loc 1 126 76 discriminator 8
	movl	$1, %eax
	jmp	.L64
.L63:
	.loc 1 126 76 discriminator 9
	movl	$0, %eax
.L64:
	.loc 1 126 37 is_stmt 1 discriminator 10
	testb	%al, %al
	je	.L59
	.loc 1 127 27
	movl	-52(%rbp), %eax
	.loc 1 127 10
	cmpl	$1, %eax
	jle	.L65
	.loc 1 127 27 discriminator 1
	movl	-52(%rbp), %eax
	cmpl	$16, %eax
	jle	.L66
.L65:
	.loc 1 127 52 discriminator 2
	movq	silver_integer_literals__invalid_mantissa(%rip), %rax
	movq	%rax, -44(%rbp)
	movl	8+silver_integer_literals__invalid_mantissa(%rip), %eax
	movl	%eax, -36(%rbp)
	jmp	.L83
.L66:
.LBB16:
	.loc 1 129 78
	movl	-56(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L67
	.loc 1 129 78 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L68
.L67:
	.loc 1 129 78 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$129, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L68:
	.loc 1 129 90 is_stmt 1 discriminator 3
	movl	-52(%rbp), %edx
	cmpl	$1, %edx
	jle	.L69
	.loc 1 129 90 is_stmt 0 discriminator 4
	cmpl	$16, %edx
	jle	.L70
.L69:
	.loc 1 129 90 discriminator 5
	leaq	.LC4(%rip), %rax
	movl	$129, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L70:
	.loc 1 129 49 is_stmt 1 discriminator 6
	movq	8(%rbx), %rcx
	movq	(%rcx), %rdi
	movq	8(%rcx), %rsi
	movl	%edx, %ecx
	movl	%eax, %edx
	call	silver_integer_literals__numeral
	movq	%rax, -64(%rbp)
	.loc 1 131 29
	movl	-64(%rbp), %eax
	.loc 1 131 13
	testl	%eax, %eax
	jne	.L71
	.loc 1 131 38 discriminator 1
	movq	silver_integer_literals__invalid_mantissa(%rip), %rax
	movq	%rax, -44(%rbp)
	movl	8+silver_integer_literals__invalid_mantissa(%rip), %eax
	movl	%eax, -36(%rbp)
	jmp	.L83
.L71:
	.loc 1 132 29
	movl	-64(%rbp), %eax
	.loc 1 132 13
	cmpl	%eax, %r12d
	jl	.L73
	.loc 1 132 49 discriminator 1
	movl	-64(%rbp), %eax
	cmpl	%eax, %r13d
	jg	.L74
	.loc 1 132 49 is_stmt 0 discriminator 2
	movl	-64(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L75
.L74:
	.loc 1 132 49 discriminator 3
	leaq	.LC4(%rip), %rax
	movl	$132, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L75:
	.loc 1 132 72 is_stmt 1 discriminator 4
	movl	-56(%rbp), %eax
	cmpl	%eax, %r13d
	jg	.L76
	.loc 1 132 72 is_stmt 0 discriminator 5
	movl	-56(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L77
.L76:
	.loc 1 132 72 discriminator 6
	leaq	.LC4(%rip), %rax
	movl	$132, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L77:
	.loc 1 132 69 is_stmt 1 discriminator 7
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movl	-64(%rbp), %edx
	movslq	%edx, %rcx
	movq	(%rbx), %rdx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %ecx
	.loc 1 132 69 is_stmt 0 discriminator 8
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movl	-56(%rbp), %edx
	movslq	%edx, %rsi
	movq	(%rbx), %rdx
	subq	%rdx, %rsi
	movzbl	(%rax,%rsi), %eax
	.loc 1 132 69 discriminator 9
	cmpb	%al, %cl
	setne	%al
	.loc 1 132 41 is_stmt 1 discriminator 9
	testb	%al, %al
	je	.L78
.L73:
	.loc 1 133 16
	movq	silver_integer_literals__invalid_mantissa(%rip), %rax
	movq	%rax, -44(%rbp)
	movl	8+silver_integer_literals__invalid_mantissa(%rip), %eax
	movl	%eax, -36(%rbp)
	jmp	.L83
.L78:
	.loc 1 135 43
	movl	-64(%rbp), %eax
	leal	1(%rax), %edx
	testl	%edx, %edx
	js	.L79
	.loc 1 135 43 is_stmt 0 discriminator 1
	cmpl	$4097, %edx
	jle	.L80
.L79:
	.loc 1 135 43 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$135, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L80:
	.loc 1 135 86 is_stmt 1 discriminator 3
	movl	-52(%rbp), %eax
	cmpl	$1, %eax
	jle	.L81
	.loc 1 135 86 is_stmt 0 discriminator 4
	cmpl	$16, %eax
	jle	.L82
.L81:
	.loc 1 135 86 discriminator 5
	leaq	.LC4(%rip), %rax
	movl	$135, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L82:
	.loc 1 135 13 is_stmt 1 discriminator 6
	movl	%edx, -44(%rbp)
	movl	-60(%rbp), %edx
	movl	%edx, -40(%rbp)
	movl	%eax, -36(%rbp)
	jmp	.L83
.L59:
.LBE16:
	.loc 1 138 7
	movl	-56(%rbp), %eax
	movl	%eax, -44(%rbp)
	movl	-52(%rbp), %eax
	movl	%eax, -40(%rbp)
	movl	$10, -36(%rbp)
.L83:
.LBE15:
	.loc 1 139 8
	movq	-44(%rbp), %rax
	movl	-36(%rbp), %ecx
	movq	%rcx, %rdx
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE7:
	.size	silver_integer_literals__read_mantissa___wrapped_statements.1, .-silver_integer_literals__read_mantissa___wrapped_statements.1
	.section	.rodata
	.align 8
.LC12:
	.ascii	"failed precondition from silver_integer_literals.adb:116"
	.align 8
.LC13:
	.ascii	"failed precondition from silver_integer_literals.adb:117"
	.align 8
.LC14:
	.ascii	"failed postcondition from silver_integer_literals.adb:118"
	.align 8
.LC3:
	.long	1
	.long	57
	.text
	.align 2
	.type	silver_integer_literals__read_mantissa, @function
silver_integer_literals__read_mantissa:
.LFB6:
	.loc 1 122 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	addq	$-128, %rsp
	.cfi_offset 14, -24
	.cfi_offset 13, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r14
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r14, %rdi
	movq	%rsi, -128(%rbp)
	movq	%rdi, -120(%rbp)
	movl	%edx, -132(%rbp)
	.loc 1 122 4
	leaq	16(%rbp), %rdx
	.loc 1 122 4 is_stmt 0 discriminator 1
	leaq	-128(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -88(%rbp)
	movl	-132(%rbp), %eax
	movl	%eax, -80(%rbp)
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -72(%rbp)
	movq	-120(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -76(%rbp)
	movl	-76(%rbp), %edx
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jl	.L85
	.loc 1 122 4 discriminator 2
	movl	-76(%rbp), %esi
	movslq	%esi, %rax
	cqto
	movl	-72(%rbp), %r14d
	movslq	%r14d, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L86
.L85:
	.loc 1 122 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L86:
.LBB17:
	.loc 1 122 4 discriminator 4
	movl	-72(%rbp), %esi
	movslq	%esi, %rsi
	movq	%rsi, -96(%rbp)
	movl	-76(%rbp), %edi
	movl	-72(%rbp), %esi
	cmpl	%esi, %edi
	.loc 1 122 4 discriminator 7
	movl	-76(%rbp), %edi
	movl	-72(%rbp), %esi
	cmpl	%esi, %edi
	.loc 1 122 4 discriminator 10
	movl	-76(%rbp), %edi
	movl	-72(%rbp), %esi
	cmpl	%esi, %edi
	.loc 1 116 15 is_stmt 1
	movl	-72(%rbp), %esi
	cmpl	$1, %esi
	je	.L93
.LBB18:
	.loc 1 116 15 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L93:
.LBE18:
	.loc 1 116 51 is_stmt 1 discriminator 2
	movl	%eax, %esi
	.loc 1 116 15 discriminator 2
	testl	%esi, %esi
	jle	.L94
	.loc 1 116 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L95
.L94:
.LBB19:
	.loc 1 116 15 discriminator 4
	leaq	.LC12(%rip), %r8
	leaq	.LC1(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L95:
.LBE19:
	.loc 1 117 41
	movl	-76(%rbp), %eax
	cmpl	$2147483647, %eax
	jne	.L96
	.loc 1 117 41 is_stmt 0 discriminator 1
	leaq	.LC4(%rip), %rax
	movl	$117, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L96:
	.loc 1 117 41 discriminator 3
	movl	-76(%rbp), %eax
	leal	1(%rax), %edx
	.loc 1 116 15 is_stmt 1 discriminator 5
	movl	-80(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L97
.LBB20:
	.loc 1 116 15 is_stmt 0 discriminator 6
	leaq	.LC13(%rip), %rcx
	leaq	.LC1(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L97:
.LBE20:
.LBB21:
	.loc 1 122 4 is_stmt 1 discriminator 13
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
	call	silver_integer_literals__read_mantissa___wrapped_statements.1
	movq	%rax, -112(%rbp)
	movl	-104(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -104(%rbp)
	.loc 1 118 55
	movl	-112(%rbp), %eax
	.loc 1 118 28
	testl	%eax, %eax
	je	.L98
	.loc 1 119 46
	movl	-112(%rbp), %eax
	.loc 1 119 10
	movl	-80(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L99
	.loc 1 120 48
	movl	-112(%rbp), %eax
	.loc 1 120 61
	movl	-76(%rbp), %edx
	cmpl	$2147483647, %edx
	jne	.L100
	.loc 1 120 61 is_stmt 0 discriminator 1
	leaq	.LC4(%rip), %rax
	movl	$120, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L100:
	.loc 1 120 61 discriminator 3
	movl	-76(%rbp), %edx
	addl	$1, %edx
	.loc 1 120 12 is_stmt 1 discriminator 4
	cmpl	%eax, %edx
	jge	.L98
.L99:
.LBB22:
	.loc 1 118 28 discriminator 1
	leaq	.LC14(%rip), %r12
	leaq	.LC3(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L98:
.LBE22:
	.loc 1 122 4 discriminator 14
	movq	-112(%rbp), %rax
	movq	%rax, -44(%rbp)
	movl	-104(%rbp), %eax
	movl	%eax, -36(%rbp)
	.loc 1 122 4 is_stmt 0 discriminator 16
	movq	-44(%rbp), %rax
	movl	-36(%rbp), %ecx
	movq	%rcx, %rdx
.LBE21:
.LBE17:
	.loc 1 122 4
	subq	$-128, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE6:
	.size	silver_integer_literals__read_mantissa, .-silver_integer_literals__read_mantissa
	.align 2
	.globl	silver_integer_literals__scale_resultIP
	.type	silver_integer_literals__scale_resultIP, @function
silver_integer_literals__scale_resultIP:
.LFB8:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE8:
	.size	silver_integer_literals__scale_resultIP, .-silver_integer_literals__scale_resultIP
	.align 2
	.type	silver_integer_literals__power, @function
silver_integer_literals__power:
.LFB9:
	.loc 1 157 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movl	%edi, -20(%rbp)
	movl	%esi, -24(%rbp)
	movl	%edx, -28(%rbp)
	.loc 1 158 7
	movl	-24(%rbp), %eax
	movl	%eax, -4(%rbp)
	.loc 1 160 11
	movl	-28(%rbp), %eax
	movl	%eax, -12(%rbp)
.LBB23:
	movl	$1, -8(%rbp)
.L109:
	.loc 1 160 11 is_stmt 0 discriminator 1
	movl	-8(%rbp), %eax
	cmpl	-12(%rbp), %eax
	jg	.L104
.LBB24:
	.loc 1 163 40 is_stmt 1
	movl	$4096, %eax
	cltd
	idivl	-20(%rbp)
	.loc 1 163 10
	cmpl	%eax, -4(%rbp)
	jle	.L105
	.loc 1 163 52 discriminator 1
	movl	$0, %eax
	movq	%rax, %rcx
	jmp	.L106
.L105:
	.loc 1 164 27
	movl	-4(%rbp), %eax
	imull	-20(%rbp), %eax
	testl	%eax, %eax
	js	.L107
	.loc 1 164 27 is_stmt 0 discriminator 1
	cmpl	$4096, %eax
	jle	.L108
.L107:
	.loc 1 164 27 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$164, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L108:
	.loc 1 164 17 is_stmt 1 discriminator 3
	movl	%eax, -4(%rbp)
.LBE24:
	.loc 1 160 11 discriminator 2
	addl	$1, -8(%rbp)
	.loc 1 165 15
	jmp	.L109
.L104:
.LBE23:
	.loc 1 166 7
	movb	$1, %cl
	movl	-4(%rbp), %eax
	salq	$32, %rax
	movl	%ecx, %edx
	orq	%rdx, %rax
	movq	%rax, %rcx
.L106:
	.loc 1 167 8
	movq	%rcx, %rax
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE9:
	.size	silver_integer_literals__power, .-silver_integer_literals__power
	.align 2
	.type	silver_integer_literals__exponent_start___wrapped_statements.2, @function
silver_integer_literals__exponent_start___wrapped_statements.2:
.LFB11:
	.loc 1 174 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	.loc 1 174 4
	movq	(%rax), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %esi
	movq	(%rax), %rdx
	movq	8(%rdx), %rdx
	movl	4(%rdx), %edx
.LBB25:
	.loc 1 175 7
	movl	8(%rax), %ecx
	cmpl	%ecx, %edx
	jl	.L111
	.loc 1 175 41 discriminator 1
	movl	8(%rax), %ecx
	cmpl	%ecx, %esi
	jg	.L112
	.loc 1 175 41 is_stmt 0 discriminator 2
	movl	8(%rax), %ecx
	cmpl	%ecx, %edx
	jge	.L113
.L112:
	.loc 1 175 41 discriminator 3
	leaq	.LC4(%rip), %rax
	movl	$175, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L113:
	.loc 1 175 57 is_stmt 1 discriminator 4
	movq	(%rax), %rdx
	movq	(%rdx), %rdx
	movq	(%rax), %rcx
	movq	8(%rcx), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movl	8(%rax), %esi
	movslq	%esi, %rsi
	subq	%rcx, %rsi
	movzbl	(%rdx,%rsi), %edx
	cmpb	$43, %dl
	sete	%dl
	.loc 1 175 32 discriminator 4
	testb	%dl, %dl
	je	.L111
	.loc 1 175 77 discriminator 5
	movl	8(%rax), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L114
	.loc 1 175 77 is_stmt 0 discriminator 6
	cmpl	$4097, %eax
	jle	.L116
.L114:
	.loc 1 175 77 discriminator 7
	leaq	.LC4(%rip), %rax
	movl	$175, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L111:
	.loc 1 175 86 is_stmt 1 discriminator 9
	movl	8(%rax), %eax
.L116:
.LBE25:
	.loc 1 174 4
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE11:
	.size	silver_integer_literals__exponent_start___wrapped_statements.2, .-silver_integer_literals__exponent_start___wrapped_statements.2
	.section	.rodata
	.align 8
.LC15:
	.ascii	"failed precondition from silver_integer_literals.adb:171"
	.align 8
.LC16:
	.ascii	"failed precondition from silver_integer_literals.adb:172"
	.align 8
.LC17:
	.ascii	"failed postcondition from silver_integer_literals.adb:173"
	.text
	.align 2
	.globl	silver_integer_literals__exponent_start
	.type	silver_integer_literals__exponent_start, @function
silver_integer_literals__exponent_start:
.LFB10:
	.loc 1 174 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r14
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r14, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movl	%edx, -100(%rbp)
	.loc 1 174 4
	leaq	16(%rbp), %rdx
	.loc 1 174 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -80(%rbp)
	movl	-100(%rbp), %eax
	movl	%eax, -72(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %r15d
	movq	-88(%rbp), %rax
	movl	4(%rax), %r14d
	movq	-88(%rbp), %rax
	movl	4(%rax), %edx
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L118
	.loc 1 174 4 discriminator 2
	movq	-88(%rbp), %rax
	movl	4(%rax), %esi
	movslq	%esi, %rax
	cqto
	movq	-88(%rbp), %rsi
	movl	(%rsi), %edi
	movl	%edi, -104(%rbp)
	movslq	-104(%rbp), %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L119
.L118:
	.loc 1 174 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L119:
.LBB26:
	.loc 1 171 15 is_stmt 1
	cmpl	$1, %r15d
	je	.L120
.LBB27:
	.loc 1 171 15 is_stmt 0 discriminator 1
	leaq	.LC15(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L120:
.LBE27:
	.loc 1 171 51 is_stmt 1 discriminator 2
	movl	%eax, %esi
	.loc 1 171 15 discriminator 2
	testl	%esi, %esi
	jle	.L121
	.loc 1 171 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L122
.L121:
.LBB28:
	.loc 1 171 15 discriminator 4
	leaq	.LC15(%rip), %r8
	leaq	.LC1(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L122:
.LBE28:
	.loc 1 171 15 is_stmt 0 discriminator 5
	movl	-72(%rbp), %eax
	testl	%eax, %eax
	jle	.L123
	.loc 1 172 46 is_stmt 1
	cmpl	$2147483647, %r14d
	jne	.L124
	.loc 1 172 46 is_stmt 0 discriminator 1
	leaq	.LC4(%rip), %rax
	movl	$172, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L124:
	.loc 1 172 46 discriminator 3
	leal	1(%r14), %edx
	.loc 1 172 28 is_stmt 1 discriminator 4
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L125
.L123:
.LBB29:
	.loc 1 171 15 discriminator 6
	leaq	.LC16(%rip), %rcx
	leaq	.LC1(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L125:
.LBE29:
.LBB30:
	.loc 1 174 4 discriminator 5
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_integer_literals__exponent_start___wrapped_statements.2
	.loc 1 173 16
	movl	-72(%rbp), %edx
	cmpl	%edx, %eax
	jl	.L126
	.loc 1 173 63 discriminator 1
	cmpl	$2147483647, %r14d
	jne	.L127
	.loc 1 173 63 is_stmt 0 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$173, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L127:
	.loc 1 173 63 discriminator 4
	leal	1(%r14), %edx
	.loc 1 173 38 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L129
.L126:
.LBB31:
	.loc 1 173 16 discriminator 6
	leaq	.LC17(%rip), %r12
	leaq	.LC3(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L129:
.LBE31:
.LBE30:
.LBE26:
	.loc 1 174 4
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE10:
	.size	silver_integer_literals__exponent_start, .-silver_integer_literals__exponent_start
	.align 2
	.type	silver_integer_literals__read_exponent___wrapped_statements.3, @function
silver_integer_literals__read_exponent___wrapped_statements.3:
.LFB13:
	.loc 1 199 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r12
	pushq	%rbx
	subq	$32, %rsp
	.cfi_offset 12, -24
	.cfi_offset 3, -32
	movq	%r10, %rbx
	movq	%r10, -40(%rbp)
	.loc 1 199 4
	movl	28(%rbx), %ecx
	movl	24(%rbx), %eax
.LBB32:
	.loc 1 201 23
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	.loc 1 201 7
	cmpl	%edx, %eax
	jl	.L131
	.loc 1 201 45 discriminator 1
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	jg	.L132
	.loc 1 201 45 is_stmt 0 discriminator 2
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %eax
	jge	.L133
.L132:
	.loc 1 201 45 discriminator 3
	leaq	.LC4(%rip), %rax
	movl	$201, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L133:
	.loc 1 201 68 is_stmt 1 discriminator 4
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rcx
	movq	(%rbx), %rdx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 1 201 74 discriminator 4
	cmpb	$101, %al
	je	.L134
	.loc 1 201 74 is_stmt 0 discriminator 5
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rcx
	movq	(%rbx), %rdx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$69, %al
	jne	.L135
.L134:
	.loc 1 201 74 discriminator 6
	movl	$1, %eax
	jmp	.L136
.L135:
	.loc 1 201 74 discriminator 7
	movl	$0, %eax
.L136:
	.loc 1 201 36 is_stmt 1 discriminator 8
	testb	%al, %al
	je	.L131
.LBB33:
	.loc 1 204 65
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L137
	.loc 1 204 65 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L138
.L137:
	.loc 1 204 65 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$204, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L138:
	.loc 1 204 15 is_stmt 1 discriminator 3
	movq	8(%rbx), %rdx
	movq	(%rdx), %rsi
	movq	8(%rdx), %rcx
	movl	%eax, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver_integer_literals__exponent_start
	movl	%eax, %edx
	.loc 1 204 15 is_stmt 0 discriminator 4
	movq	8(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$10, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_integer_literals__numeral
	movq	%rax, -24(%rbp)
	.loc 1 206 31 is_stmt 1
	movl	-24(%rbp), %eax
	.loc 1 206 13
	testl	%eax, %eax
	jne	.L139
	.loc 1 206 40 discriminator 1
	movl	$0, %eax
	movq	%rax, %r12
	jmp	.L143
.L139:
.LBB34:
	.loc 1 208 50
	movl	-20(%rbp), %edx
	movq	16(%rbx), %rax
	movl	4(%rax), %ecx
	movq	16(%rbx), %rax
	movl	8(%rax), %eax
	movl	%ecx, %esi
	movl	%eax, %edi
	call	silver_integer_literals__power
	movq	%rax, -32(%rbp)
	.loc 1 210 19
	movzbl	-32(%rbp), %eax
	xorl	$1, %eax
	.loc 1 210 16
	testb	%al, %al
	je	.L141
	.loc 1 210 41 discriminator 1
	movl	$0, %eax
	movq	%rax, %r12
	jmp	.L143
.L141:
	.loc 1 211 16
	movl	-24(%rbp), %eax
	movl	%eax, %edx
	movabsq	$-4294967296, %rax
	andq	%r12, %rax
	orq	%rdx, %rax
	movq	%rax, %r12
	movl	-28(%rbp), %eax
	movl	%eax, %eax
	salq	$32, %rax
	movl	%r12d, %edx
	orq	%rdx, %rax
	movq	%rax, %r12
	jmp	.L143
.L131:
.LBE34:
.LBE33:
	.loc 1 215 7
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, %edx
	movabsq	$-4294967296, %rax
	andq	%r12, %rax
	orq	%rdx, %rax
	movq	%rax, %r12
	movq	16(%rbx), %rax
	movl	4(%rax), %eax
	movl	%eax, %eax
	salq	$32, %rax
	movl	%r12d, %edx
	orq	%rdx, %rax
	movq	%rax, %r12
.L143:
.LBE32:
	.loc 1 216 8
	movq	%r12, %rax
	addq	$32, %rsp
	popq	%rbx
	popq	%r12
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE13:
	.size	silver_integer_literals__read_exponent___wrapped_statements.3, .-silver_integer_literals__read_exponent___wrapped_statements.3
	.section	.rodata
	.align 8
.LC18:
	.ascii	"failed precondition from silver_integer_literals.adb:194"
	.align 8
.LC19:
	.ascii	"failed precondition from silver_integer_literals.adb:195"
	.align 8
.LC20:
	.ascii	"failed postcondition from silver_integer_literals.adb:196"
	.text
	.align 2
	.type	silver_integer_literals__read_exponent, @function
silver_integer_literals__read_exponent:
.LFB12:
	.loc 1 199 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %rbx
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%rbx, %rdi
	movq	%rsi, -128(%rbp)
	movq	%rdi, -120(%rbp)
	movq	%rdx, %rax
	movq	%rcx, %rdx
	movq	%rax, -144(%rbp)
	movl	-136(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -136(%rbp)
	.loc 1 199 4
	leaq	16(%rbp), %rax
	.loc 1 199 4 is_stmt 0 discriminator 1
	leaq	-128(%rbp), %rdx
	movq	%rax, -64(%rbp)
	leaq	-144(%rbp), %rax
	movq	%rdx, -88(%rbp)
	movq	%rax, -80(%rbp)
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -68(%rbp)
	movq	-120(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -72(%rbp)
	movl	-72(%rbp), %edx
	movl	-68(%rbp), %eax
	cmpl	%eax, %edx
	jl	.L145
	.loc 1 199 4 discriminator 2
	movl	-72(%rbp), %ecx
	movslq	%ecx, %rax
	cqto
	movl	-68(%rbp), %esi
	movslq	%esi, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L146
.L145:
	.loc 1 199 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L146:
.LBB35:
	.loc 1 199 4 discriminator 4
	movl	-68(%rbp), %ecx
	movslq	%ecx, %rcx
	movq	%rcx, -96(%rbp)
	movl	-72(%rbp), %esi
	movl	-68(%rbp), %ecx
	cmpl	%ecx, %esi
	.loc 1 199 4 discriminator 7
	movl	-72(%rbp), %esi
	movl	-68(%rbp), %ecx
	cmpl	%ecx, %esi
	.loc 1 199 4 discriminator 10
	movl	-72(%rbp), %esi
	movl	-68(%rbp), %ecx
	cmpl	%ecx, %esi
	.loc 1 194 15 is_stmt 1
	movl	-68(%rbp), %ecx
	cmpl	$1, %ecx
	je	.L153
.LBB36:
	.loc 1 194 15 is_stmt 0 discriminator 1
	leaq	.LC18(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L153:
.LBE36:
	.loc 1 194 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 1 194 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L154
	.loc 1 194 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L155
.L154:
.LBB37:
	.loc 1 194 15 discriminator 4
	leaq	.LC18(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L155:
.LBE37:
	.loc 1 195 32
	movl	-144(%rbp), %eax
	.loc 1 194 15 discriminator 5
	testl	%eax, %eax
	jle	.L156
	.loc 1 195 32 discriminator 1
	movl	-144(%rbp), %eax
	.loc 1 195 50 discriminator 1
	movl	-72(%rbp), %edx
	cmpl	$2147483647, %edx
	jne	.L157
	.loc 1 195 50 is_stmt 0 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$195, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L157:
	.loc 1 195 50 discriminator 4
	movl	-72(%rbp), %edx
	addl	$1, %edx
	.loc 1 195 32 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L158
.L156:
.LBB38:
	.loc 1 194 15 discriminator 6
	leaq	.LC19(%rip), %r8
	leaq	.LC1(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L158:
.LBE38:
.LBB39:
	.loc 1 199 4 discriminator 13
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
	call	silver_integer_literals__read_exponent___wrapped_statements.3
	movq	%rax, -104(%rbp)
	.loc 1 196 55
	movl	-104(%rbp), %eax
	.loc 1 196 28
	testl	%eax, %eax
	je	.L159
	.loc 1 197 45
	movl	-104(%rbp), %edx
	movl	-144(%rbp), %eax
	.loc 1 197 10
	cmpl	%eax, %edx
	jl	.L160
	.loc 1 197 45 discriminator 1
	movl	-104(%rbp), %eax
	.loc 1 197 74 discriminator 1
	movl	-72(%rbp), %edx
	cmpl	$2147483647, %edx
	jne	.L161
	.loc 1 197 74 is_stmt 0 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$197, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L161:
	.loc 1 197 74 discriminator 4
	movl	-72(%rbp), %edx
	addl	$1, %edx
	.loc 1 197 45 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L159
.L160:
.LBB40:
	.loc 1 196 28 discriminator 1
	leaq	.LC20(%rip), %r12
	leaq	.LC3(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L159:
.LBE40:
	.loc 1 199 4 discriminator 14
	movq	-104(%rbp), %rax
.LBE39:
.LBE35:
	.loc 1 199 4 is_stmt 0
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE12:
	.size	silver_integer_literals__read_exponent, .-silver_integer_literals__read_exponent
	.align 2
	.type	silver_integer_literals__read_integer___wrapped_statements.4, @function
silver_integer_literals__read_integer___wrapped_statements.4:
.LFB15:
	.loc 1 226 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%r10, %rbx
	movq	%r10, -72(%rbp)
	.loc 1 226 4
	movl	24(%rbx), %r13d
	movl	20(%rbx), %r12d
.LBB41:
	.loc 1 228 44
	movq	8(%rbx), %rax
	movl	16(%rbx), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_integer_literals__read_mantissa
	movq	%rax, -48(%rbp)
	movl	-40(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -40(%rbp)
	.loc 1 230 23
	movl	-48(%rbp), %eax
	.loc 1 230 7
	testl	%eax, %eax
	jne	.L164
	.loc 1 230 32 discriminator 1
	movl	$0, %eax
	jmp	.L171
.L164:
.LBB42:
	.loc 1 232 46
	movq	8(%rbx), %rcx
	movq	-48(%rbp), %rax
	movl	-40(%rbp), %esi
	movq	%rsi, %rdx
	movq	(%rcx), %rdi
	movq	8(%rcx), %rsi
	movq	%rdx, %rcx
	movq	%rax, %rdx
	call	silver_integer_literals__read_exponent
	movq	%rax, -56(%rbp)
	.loc 1 234 26
	movl	-56(%rbp), %eax
	.loc 1 234 10
	testl	%eax, %eax
	je	.L166
	.loc 1 235 26
	movl	-56(%rbp), %eax
	.loc 1 234 30 discriminator 1
	cmpl	%eax, %r12d
	jl	.L167
	.loc 1 235 73 discriminator 1
	movl	-56(%rbp), %eax
	cmpl	%eax, %r13d
	jg	.L168
	.loc 1 235 73 is_stmt 0 discriminator 2
	movl	-56(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L169
.L168:
	.loc 1 235 73 discriminator 3
	leaq	.LC4(%rip), %rax
	movl	$235, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L169:
	.loc 1 235 48 is_stmt 1 discriminator 4
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movl	-56(%rbp), %edx
	movslq	%edx, %rcx
	movq	(%rbx), %rdx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 1 235 48 is_stmt 0 discriminator 5
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_identifier_character@PLT
	.loc 1 235 39 is_stmt 1 discriminator 6
	testb	%al, %al
	je	.L167
.L166:
	.loc 1 236 15
	movl	$0, %eax
	jmp	.L171
.L167:
	.loc 1 237 10
	movq	-56(%rbp), %rax
.L171:
.LBE42:
.LBE41:
	.loc 1 239 8
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE15:
	.size	silver_integer_literals__read_integer___wrapped_statements.4, .-silver_integer_literals__read_integer___wrapped_statements.4
	.section	.rodata
	.align 8
.LC21:
	.ascii	"failed precondition from silver_integer_literals.ads:27"
.LC22:
	.ascii	"silver_integer_literals.ads"
	.zero	1
	.align 8
.LC23:
	.ascii	"failed precondition from silver_integer_literals.ads:28"
	.align 8
.LC24:
	.ascii	"failed postcondition from silver_integer_literals.ads:29"
	.text
	.align 2
	.globl	silver_integer_literals__read_integer
	.type	silver_integer_literals__read_integer, @function
silver_integer_literals__read_integer:
.LFB14:
	.loc 1 226 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$96, %rsp
	.cfi_offset 14, -24
	.cfi_offset 13, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r14
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r14, %rdi
	movq	%rsi, -112(%rbp)
	movq	%rdi, -104(%rbp)
	movl	%edx, -116(%rbp)
	.loc 1 226 4
	leaq	16(%rbp), %rdx
	.loc 1 226 4 is_stmt 0 discriminator 1
	leaq	-112(%rbp), %rax
	movq	%rdx, -48(%rbp)
	movq	%rax, -72(%rbp)
	movl	-116(%rbp), %eax
	movl	%eax, -64(%rbp)
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -56(%rbp)
	movq	-104(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -60(%rbp)
	movl	-60(%rbp), %edx
	movl	-56(%rbp), %eax
	cmpl	%eax, %edx
	jl	.L173
	.loc 1 226 4 discriminator 2
	movl	-60(%rbp), %esi
	movslq	%esi, %rax
	cqto
	movl	-56(%rbp), %r14d
	movslq	%r14d, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L174
.L173:
	.loc 1 226 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L174:
.LBB43:
	.loc 1 226 4 discriminator 4
	movl	-56(%rbp), %esi
	movslq	%esi, %rsi
	movq	%rsi, -80(%rbp)
	movl	-60(%rbp), %edi
	movl	-56(%rbp), %esi
	cmpl	%esi, %edi
	.loc 1 226 4 discriminator 7
	movl	-60(%rbp), %edi
	movl	-56(%rbp), %esi
	cmpl	%esi, %edi
	.loc 1 226 4 discriminator 10
	movl	-60(%rbp), %edi
	movl	-56(%rbp), %esi
	cmpl	%esi, %edi
	.file 2 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_integer_literals.ads"
	.loc 2 27 15 is_stmt 1
	movl	-56(%rbp), %esi
	cmpl	$1, %esi
	je	.L181
.LBB44:
	.loc 2 27 15 is_stmt 0 discriminator 1
	leaq	.LC21(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L181:
.LBE44:
	.loc 2 27 51 is_stmt 1 discriminator 2
	movl	%eax, %esi
	.loc 2 27 15 discriminator 2
	testl	%esi, %esi
	jle	.L182
	.loc 2 27 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L183
.L182:
.LBB45:
	.loc 2 27 15 discriminator 4
	leaq	.LC21(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L183:
.LBE45:
	.loc 2 28 41
	movl	-60(%rbp), %eax
	cmpl	$2147483647, %eax
	jne	.L184
	.loc 2 28 41 is_stmt 0 discriminator 1
	leaq	.LC22(%rip), %rax
	movl	$28, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L184:
	.loc 2 28 41 discriminator 3
	movl	-60(%rbp), %eax
	leal	1(%rax), %edx
	.loc 2 27 15 is_stmt 1 discriminator 5
	movl	-64(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L185
.LBB46:
	.loc 2 27 15 is_stmt 0 discriminator 6
	leaq	.LC23(%rip), %rcx
	leaq	.LC0(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L185:
.LBE46:
.LBB47:
	.loc 1 226 4 is_stmt 1 discriminator 13
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_integer_literals__read_integer___wrapped_statements.4
	movq	%rax, -88(%rbp)
	.loc 2 29 54
	movl	-88(%rbp), %eax
	.loc 2 29 28
	testl	%eax, %eax
	je	.L186
	.loc 2 30 45
	movl	-88(%rbp), %eax
	.loc 2 30 10
	movl	-64(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L187
	.loc 2 31 47
	movl	-88(%rbp), %eax
	.loc 2 31 60
	movl	-60(%rbp), %edx
	cmpl	$2147483647, %edx
	jne	.L188
	.loc 2 31 60 is_stmt 0 discriminator 1
	leaq	.LC22(%rip), %rax
	movl	$31, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L188:
	.loc 2 31 60 discriminator 3
	movl	-60(%rbp), %edx
	addl	$1, %edx
	.loc 2 31 12 is_stmt 1 discriminator 4
	cmpl	%eax, %edx
	jge	.L186
.L187:
.LBB48:
	.loc 2 29 28 discriminator 1
	leaq	.LC24(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L186:
.LBE48:
	.loc 1 226 4 discriminator 14
	movq	-88(%rbp), %rax
.LBE47:
.LBE43:
	.loc 1 226 4 is_stmt 0
	addq	$96, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE14:
	.size	silver_integer_literals__read_integer, .-silver_integer_literals__read_integer
	.align 2
	.globl	silver_integer_literals__digit
	.type	silver_integer_literals__digit, @function
silver_integer_literals__digit:
.LFB16:
	.loc 1 2 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movb	%dil, -1(%rbp)
	.loc 1 3 15
	movzbl	-1(%rbp), %eax
	.loc 1 3 7
	cmpb	$47, %al
	jbe	.L191
	.loc 1 3 15 discriminator 1
	movzbl	-1(%rbp), %eax
	cmpb	$57, %al
	ja	.L191
	.loc 1 3 55 discriminator 2
	movzbl	-1(%rbp), %eax
	movzbl	%al, %eax
	subl	$48, %eax
	testl	%eax, %eax
	jns	.L193
	.loc 1 3 55 is_stmt 0 discriminator 3
	leaq	.LC4(%rip), %rax
	movl	$3, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L191:
	.loc 1 4 18 is_stmt 1
	movzbl	-1(%rbp), %eax
	.loc 1 4 7
	cmpb	$64, %al
	jbe	.L194
	.loc 1 4 18 discriminator 1
	movzbl	-1(%rbp), %eax
	cmpb	$70, %al
	ja	.L194
	.loc 1 4 82 discriminator 2
	movzbl	-1(%rbp), %eax
	movzbl	%al, %eax
	subl	$55, %eax
	testl	%eax, %eax
	jns	.L193
	.loc 1 4 82 is_stmt 0 discriminator 3
	leaq	.LC4(%rip), %rax
	movl	$4, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L194:
	.loc 1 5 18 is_stmt 1
	movzbl	-1(%rbp), %eax
	.loc 1 5 7
	cmpb	$96, %al
	jbe	.L196
	.loc 1 5 18 discriminator 1
	movzbl	-1(%rbp), %eax
	cmpb	$102, %al
	ja	.L196
	.loc 1 5 82 discriminator 2
	movzbl	-1(%rbp), %eax
	movzbl	%al, %eax
	subl	$87, %eax
	testl	%eax, %eax
	jns	.L193
	.loc 1 5 82 is_stmt 0 discriminator 3
	leaq	.LC4(%rip), %rax
	movl	$5, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L196:
	.loc 1 6 12 is_stmt 1
	movl	$16, %eax
.L193:
	.loc 1 2 4
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE16:
	.size	silver_integer_literals__digit, .-silver_integer_literals__digit
	.globl	silver_integer_literals_E
	.data
	.align 2
	.type	silver_integer_literals_E, @object
	.size	silver_integer_literals_E, 2
silver_integer_literals_E:
	.zero	2
	.globl	silver_integer_literals__invalid
	.section	.rodata
	.align 8
	.type	silver_integer_literals__invalid, @object
	.size	silver_integer_literals__invalid, 8
silver_integer_literals__invalid:
	.zero	8
	.globl	silver_integer_literals__invalid_mantissa
	.align 16
	.type	silver_integer_literals__invalid_mantissa, @object
	.size	silver_integer_literals__invalid_mantissa, 16
silver_integer_literals__invalid_mantissa:
	.long	0
	.long	0
	.long	10
	.zero	4
	.globl	silver_integer_literals__invalid_scale
	.align 8
	.type	silver_integer_literals__invalid_scale, @object
	.size	silver_integer_literals__invalid_scale, 8
silver_integer_literals__invalid_scale:
	.zero	8
	.text
.Letext0:
	.file 3 "<built-in>"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x60b
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x11
	.long	.LASF43
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.long	.LLRL0
	.quad	0
	.long	.Ldebug_line0
	.uleb128 0x7
	.sleb128 0
	.sleb128 4097
	.long	.LASF2
	.long	0x3b
	.uleb128 0x4
	.long	0x2a
	.uleb128 0x9
	.byte	0x4
	.byte	0x5
	.long	.LASF12
	.uleb128 0x7
	.sleb128 0
	.sleb128 4096
	.long	.LASF3
	.long	0x3b
	.uleb128 0x4
	.long	0x42
	.uleb128 0x7
	.sleb128 2
	.sleb128 16
	.long	.LASF4
	.long	0x3b
	.uleb128 0x4
	.long	0x53
	.uleb128 0xa
	.long	.LASF7
	.byte	0x8
	.byte	0x2
	.byte	0x8
	.long	0x88
	.uleb128 0x5
	.long	.LASF5
	.byte	0x2
	.byte	0x9
	.long	0x2a
	.byte	0
	.uleb128 0x5
	.long	.LASF6
	.byte	0x2
	.byte	0xa
	.long	0x42
	.byte	0x4
	.byte	0
	.uleb128 0x4
	.long	0x63
	.uleb128 0xa
	.long	.LASF8
	.byte	0xc
	.byte	0x1
	.byte	0x56
	.long	0xbe
	.uleb128 0x5
	.long	.LASF5
	.byte	0x1
	.byte	0x57
	.long	0x2a
	.byte	0
	.uleb128 0x5
	.long	.LASF6
	.byte	0x1
	.byte	0x58
	.long	0x42
	.byte	0x4
	.uleb128 0x5
	.long	.LASF9
	.byte	0x1
	.byte	0x59
	.long	0x53
	.byte	0x8
	.byte	0
	.uleb128 0x4
	.long	0x8d
	.uleb128 0xa
	.long	.LASF10
	.byte	0x8
	.byte	0x1
	.byte	0x8d
	.long	0xe8
	.uleb128 0x5
	.long	.LASF11
	.byte	0x1
	.byte	0x8e
	.long	0xed
	.byte	0
	.uleb128 0x5
	.long	.LASF6
	.byte	0x1
	.byte	0x8f
	.long	0x42
	.byte	0x4
	.byte	0
	.uleb128 0x4
	.long	0xc3
	.uleb128 0x9
	.byte	0x1
	.byte	0x2
	.long	.LASF13
	.uleb128 0xb
	.long	.LASF14
	.byte	0x2
	.byte	0xc
	.long	0x88
	.uleb128 0x9
	.byte	0x3
	.quad	silver_integer_literals__invalid
	.uleb128 0xb
	.long	.LASF15
	.byte	0x1
	.byte	0x5b
	.long	0xbe
	.uleb128 0x9
	.byte	0x3
	.quad	silver_integer_literals__invalid_mantissa
	.uleb128 0xb
	.long	.LASF16
	.byte	0x1
	.byte	0x91
	.long	0xe8
	.uleb128 0x9
	.byte	0x3
	.quad	silver_integer_literals__invalid_scale
	.uleb128 0x12
	.long	.LASF44
	.byte	0x2
	.byte	0x1
	.byte	0x6
	.uleb128 0x13
	.byte	0x2
	.byte	0x4
	.byte	0x4
	.long	0x133
	.uleb128 0xc
	.long	.LASF19
	.byte	0x2
	.long	0x173
	.quad	.LFB16
	.quad	.LFE16-.LFB16
	.uleb128 0x1
	.byte	0x9c
	.long	0x173
	.uleb128 0x1
	.long	.LASF21
	.byte	0x1
	.byte	0x2
	.byte	0x14
	.long	0x189
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.byte	0
	.uleb128 0x7
	.sleb128 0
	.sleb128 2147483647
	.long	.LASF17
	.long	0x3b
	.uleb128 0x9
	.byte	0x1
	.byte	0x8
	.long	.LASF18
	.uleb128 0x4
	.long	0x182
	.uleb128 0xc
	.long	.LASF20
	.byte	0xe2
	.long	0x63
	.quad	.LFB14
	.quad	.LFE14-.LFB14
	.uleb128 0x1
	.byte	0x9c
	.long	0x248
	.uleb128 0x1
	.long	.LASF22
	.byte	0x2
	.byte	0x18
	.byte	0x1b
	.long	0x29f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x1
	.long	.LASF23
	.byte	0x2
	.byte	0x18
	.byte	0x2a
	.long	0x36
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x2
	.quad	.LBB43
	.quad	.LBE43-.LBB43
	.uleb128 0x8
	.long	.LASF29
	.long	0x63
	.quad	.LFB15
	.quad	.LFE15-.LFB15
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x2
	.quad	.LBB41
	.quad	.LBE41-.LBB41
	.uleb128 0x3
	.long	.LASF24
	.byte	0xe4
	.byte	0x7
	.long	0x8d
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x2
	.quad	.LBB42
	.quad	.LBE42-.LBB42
	.uleb128 0x3
	.long	.LASF25
	.byte	0xe8
	.byte	0xa
	.long	0x63
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x14
	.long	.LASF26
	.byte	0x10
	.byte	0x3
	.byte	0
	.long	0x28b
	.uleb128 0xe
	.long	.LASF27
	.long	0x25e
	.byte	0
	.uleb128 0xf
	.long	0x2a4
	.uleb128 0x15
	.byte	0x8
	.byte	0x3
	.byte	0
	.long	0x280
	.uleb128 0x10
	.string	"LB0"
	.long	0x2c3
	.byte	0
	.uleb128 0x10
	.string	"UB0"
	.long	0x2c3
	.byte	0x4
	.byte	0
	.uleb128 0xe
	.long	.LASF28
	.long	0x2d1
	.byte	0x8
	.byte	0
	.uleb128 0x6
	.long	0x248
	.uleb128 0x6
	.long	0x248
	.uleb128 0x6
	.long	0x248
	.uleb128 0x6
	.long	0x248
	.uleb128 0x6
	.long	0x248
	.uleb128 0x16
	.long	0x182
	.long	0x2c3
	.uleb128 0x17
	.long	0x3b
	.uleb128 0x6
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x94
	.byte	0x4
	.uleb128 0x8
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x23
	.uleb128 0x4
	.byte	0x94
	.byte	0x4
	.byte	0
	.uleb128 0x18
	.sleb128 2147483647
	.long	.LASF45
	.long	0x3b
	.uleb128 0xf
	.long	0x263
	.uleb128 0xd
	.long	.LASF34
	.byte	0xc7
	.long	0x63
	.quad	.LFB12
	.quad	.LFE12-.LFB12
	.uleb128 0x1
	.byte	0x9c
	.long	0x38c
	.uleb128 0x1
	.long	.LASF22
	.byte	0x1
	.byte	0xc0
	.byte	0x1c
	.long	0x29a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x1
	.long	.LASF24
	.byte	0x1
	.byte	0xc0
	.byte	0x2b
	.long	0xbe
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0x2
	.quad	.LBB35
	.quad	.LBE35-.LBB35
	.uleb128 0x8
	.long	.LASF30
	.long	0x63
	.quad	.LFB13
	.quad	.LFE13-.LFB13
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -56
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x2
	.quad	.LBB33
	.quad	.LBE33-.LBB33
	.uleb128 0x3
	.long	.LASF31
	.byte	0xcb
	.byte	0xd
	.long	0x63
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x2
	.quad	.LBB34
	.quad	.LBE34-.LBB34
	.uleb128 0x3
	.long	.LASF32
	.byte	0xd0
	.byte	0x10
	.long	0xc3
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0xc
	.long	.LASF33
	.byte	0xae
	.long	0x2a
	.quad	.LFB10
	.quad	.LFE10-.LFB10
	.uleb128 0x1
	.byte	0x9c
	.long	0x403
	.uleb128 0x1
	.long	.LASF22
	.byte	0x1
	.byte	0xa9
	.byte	0x1d
	.long	0x295
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF23
	.byte	0x1
	.byte	0xa9
	.byte	0x2c
	.long	0x36
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x2
	.quad	.LBB26
	.quad	.LBE26-.LBB26
	.uleb128 0x19
	.long	.LASF46
	.long	0x2a
	.quad	.LFB11
	.quad	.LFE11-.LFB11
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -24
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.byte	0
	.byte	0
	.uleb128 0xd
	.long	.LASF35
	.byte	0x9d
	.long	0xc3
	.quad	.LFB9
	.quad	.LFE9-.LFB9
	.uleb128 0x1
	.byte	0x9c
	.long	0x48b
	.uleb128 0x1
	.long	.LASF9
	.byte	0x1
	.byte	0x9b
	.byte	0x14
	.long	0x5e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.uleb128 0x1
	.long	.LASF6
	.byte	0x1
	.byte	0x9b
	.byte	0x29
	.long	0x4e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x1
	.long	.LASF31
	.byte	0x1
	.byte	0x9b
	.byte	0x30
	.long	0x4e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -44
	.uleb128 0x3
	.long	.LASF25
	.byte	0x9e
	.byte	0x7
	.long	0x42
	.uleb128 0x2
	.byte	0x91
	.sleb128 -20
	.uleb128 0x1a
	.long	.LASF47
	.long	0x42
	.uleb128 0x2
	.byte	0x91
	.sleb128 -28
	.uleb128 0x2
	.quad	.LBB23
	.quad	.LBE23-.LBB23
	.uleb128 0x3
	.long	.LASF36
	.byte	0xa0
	.byte	0xb
	.long	0x3b
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.byte	0
	.byte	0
	.uleb128 0xd
	.long	.LASF37
	.byte	0x7a
	.long	0x8d
	.quad	.LFB6
	.quad	.LFE6-.LFB6
	.uleb128 0x1
	.byte	0x9c
	.long	0x546
	.uleb128 0x1
	.long	.LASF22
	.byte	0x1
	.byte	0x72
	.byte	0x1c
	.long	0x290
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x1
	.long	.LASF23
	.byte	0x1
	.byte	0x72
	.byte	0x2b
	.long	0x36
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x2
	.quad	.LBB17
	.quad	.LBE17-.LBB17
	.uleb128 0x8
	.long	.LASF38
	.long	0x8d
	.quad	.LFB7
	.quad	.LFE7-.LFB7
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x2
	.quad	.LBB15
	.quad	.LBE15-.LBB15
	.uleb128 0x3
	.long	.LASF39
	.byte	0x7b
	.byte	0x7
	.long	0x63
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x2
	.quad	.LBB16
	.quad	.LBE16-.LBB16
	.uleb128 0x3
	.long	.LASF24
	.byte	0x81
	.byte	0xd
	.long	0x63
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x1b
	.long	.LASF48
	.byte	0x1
	.byte	0x36
	.byte	0x4
	.long	0x63
	.quad	.LFB3
	.quad	.LFE3-.LFB3
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x1
	.long	.LASF22
	.byte	0x1
	.byte	0x2d
	.byte	0x16
	.long	0x28b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x1
	.long	.LASF23
	.byte	0x1
	.byte	0x2d
	.byte	0x25
	.long	0x36
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x1
	.long	.LASF9
	.byte	0x1
	.byte	0x2d
	.byte	0x42
	.long	0x5e
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x2
	.quad	.LBB9
	.quad	.LBE9-.LBB9
	.uleb128 0x8
	.long	.LASF40
	.long	0x63
	.quad	.LFB4
	.quad	.LFE4-.LFB4
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x2
	.quad	.LBB2
	.quad	.LBE2-.LBB2
	.uleb128 0x3
	.long	.LASF41
	.byte	0x38
	.byte	0x7
	.long	0x2a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x3
	.long	.LASF6
	.byte	0x39
	.byte	0x7
	.long	0x42
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x3
	.long	.LASF42
	.byte	0x3a
	.byte	0x7
	.long	0xed
	.uleb128 0x3
	.byte	0x91
	.sleb128 -73
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 7
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0xd
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x55
	.uleb128 0x17
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x1e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0x3a
	.byte	0
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x18
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x14
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x15
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x16
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x17
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x18
	.uleb128 0x2f
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x18
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x19
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x1a
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x1b
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x4c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.LFE3-.Ltext0
	.quad	.LFB7
	.quad	.LFE6-.LFB7
	.quad	.LFB9
	.quad	.Letext0-.LFB9
	.quad	0
	.quad	0
	.section	.debug_rnglists,"",@progbits
.Ldebug_ranges0:
	.long	.Ldebug_ranges3-.Ldebug_ranges2
.Ldebug_ranges2:
	.value	0x5
	.byte	0x8
	.byte	0
	.long	0
.LLRL0:
	.byte	0x7
	.quad	.Ltext0
	.uleb128 .LFE3-.Ltext0
	.byte	0x7
	.quad	.LFB7
	.uleb128 .LFE6-.LFB7
	.byte	0x7
	.quad	.LFB9
	.uleb128 .Letext0-.LFB9
	.byte	0
.Ldebug_ranges3:
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF27:
	.string	"P_ARRAY"
.LASF33:
	.string	"silver_integer_literals__exponent_start"
.LASF47:
	.string	"silver_integer_literals__power__L_3__T59b___U"
.LASF41:
	.string	"next"
.LASF7:
	.string	"silver_integer_literals__literal_result"
.LASF18:
	.string	"character"
.LASF6:
	.string	"value"
.LASF45:
	.string	"positive"
.LASF34:
	.string	"silver_integer_literals__read_exponent"
.LASF22:
	.string	"text"
.LASF26:
	.string	"string"
.LASF28:
	.string	"P_BOUNDS"
.LASF17:
	.string	"natural"
.LASF44:
	.string	"silver_profile"
.LASF30:
	.string	"silver_integer_literals__read_exponent___wrapped_statements"
.LASF40:
	.string	"silver_integer_literals__numeral___wrapped_statements"
.LASF9:
	.string	"base"
.LASF42:
	.string	"need_digit"
.LASF35:
	.string	"silver_integer_literals__power"
.LASF2:
	.string	"silver_integer_literals__literal_position"
.LASF8:
	.string	"silver_integer_literals__mantissa_result"
.LASF23:
	.string	"position"
.LASF14:
	.string	"silver_integer_literals__invalid"
.LASF20:
	.string	"silver_integer_literals__read_integer"
.LASF5:
	.string	"after"
.LASF46:
	.string	"silver_integer_literals__exponent_start___wrapped_statements"
.LASF25:
	.string	"result"
.LASF15:
	.string	"silver_integer_literals__invalid_mantissa"
.LASF24:
	.string	"number"
.LASF48:
	.string	"silver_integer_literals__numeral"
.LASF16:
	.string	"silver_integer_literals__invalid_scale"
.LASF32:
	.string	"scaled"
.LASF29:
	.string	"silver_integer_literals__read_integer___wrapped_statements"
.LASF36:
	.string	"index"
.LASF11:
	.string	"valid"
.LASF19:
	.string	"silver_integer_literals__digit"
.LASF10:
	.string	"silver_integer_literals__scale_result"
.LASF31:
	.string	"exponent"
.LASF39:
	.string	"leading"
.LASF38:
	.string	"silver_integer_literals__read_mantissa___wrapped_statements"
.LASF12:
	.string	"integer"
.LASF21:
	.string	"item"
.LASF3:
	.string	"silver_integer_literals__literal_value"
.LASF43:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF13:
	.string	"boolean"
.LASF4:
	.string	"silver_integer_literals__literal_base"
.LASF37:
	.string	"silver_integer_literals__read_mantissa"
	.section	.debug_line_str,"MS",@progbits,1
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_integer_literals.adb"
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
