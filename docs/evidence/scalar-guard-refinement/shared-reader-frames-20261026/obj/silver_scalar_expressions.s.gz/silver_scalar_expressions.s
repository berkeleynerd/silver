	.file	"silver_scalar_expressions.adb"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_scalar_expressions.adb"
	.align 2
	.globl	silver_scalar_expressions__bindingIP
	.type	silver_scalar_expressions__bindingIP, @function
silver_scalar_expressions__bindingIP:
.LFB2:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	silver_scalar_expressions__bindingIP, .-silver_scalar_expressions__bindingIP
	.align 2
	.globl	silver_scalar_expressions__Tbinding_arrayBIP
	.type	silver_scalar_expressions__Tbinding_arrayBIP, @function
silver_scalar_expressions__Tbinding_arrayBIP:
.LFB3:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.size	silver_scalar_expressions__Tbinding_arrayBIP, .-silver_scalar_expressions__Tbinding_arrayBIP
	.align 2
	.globl	silver_scalar_expressions__environmentIP
	.type	silver_scalar_expressions__environmentIP, @function
silver_scalar_expressions__environmentIP:
.LFB4:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	silver_scalar_expressions__environmentIP, .-silver_scalar_expressions__environmentIP
	.section	.rodata
	.align 8
.LC7:
	.ascii	"failed precondition from silver_scalar_expressions.ads:30"
.LC8:
	.ascii	"silver_scalar_expressions.ads"
	.zero	1
	.align 8
.LC0:
	.long	1
	.long	57
	.text
	.align 2
	.globl	silver_scalar_expressions__valid_environment
	.type	silver_scalar_expressions__valid_environment, @function
silver_scalar_expressions__valid_environment:
.LFB5:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_scalar_expressions.ads"
	.loc 1 31 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 3, -24
	movq	%rdi, %rax
	movq	%rsi, %r10
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r10, %rdi
	movq	%rsi, -48(%rbp)
	movq	%rdi, -40(%rbp)
	movq	%rdx, -56(%rbp)
	.loc 1 31 4
	movq	-40(%rbp), %rax
	movl	(%rax), %r10d
	movq	-40(%rbp), %rax
	movl	4(%rax), %edx
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L8
	.loc 1 31 4 is_stmt 0 discriminator 1
	movq	-40(%rbp), %rax
	movl	4(%rax), %esi
	movslq	%esi, %rax
	cqto
	movq	-40(%rbp), %rsi
	movl	(%rsi), %r11d
	movslq	%r11d, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L9
.L8:
	.loc 1 31 4 discriminator 2
	movl	$0, %eax
	movl	$0, %edx
.L9:
.LBB2:
	.loc 1 30 15 is_stmt 1
	cmpl	$1, %r10d
	je	.L10
.LBB3:
	.loc 1 30 15 is_stmt 0 discriminator 1
	leaq	.LC7(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L10:
.LBE3:
	.loc 1 30 51 is_stmt 1 discriminator 2
	movl	%eax, %esi
	.loc 1 30 15 discriminator 2
	testl	%esi, %esi
	jle	.L11
	.loc 1 30 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L12
.L11:
.LBB4:
	.loc 1 30 15 discriminator 4
	leaq	.LC7(%rip), %rcx
	leaq	.LC0(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L12:
.LBE4:
	.loc 1 32 7
	movl	$1, %ebx
	.loc 1 32 34
	movq	-56(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -24(%rbp)
	movl	-24(%rbp), %eax
	cmpl	$341, %eax
	jbe	.L13
	.loc 1 32 34 is_stmt 0 discriminator 1
	leaq	.LC8(%rip), %rax
	movl	$32, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L13:
.LBB5:
	.loc 1 32 15 is_stmt 1 discriminator 2
	movl	$1, -20(%rbp)
.L17:
	.loc 1 32 7 discriminator 3
	movl	-20(%rbp), %eax
	cmpl	-24(%rbp), %eax
	jg	.L18
.LBB6:
	.loc 1 33 35
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movq	-56(%rbp), %rax
	subq	$1, %rdx
	salq	$5, %rdx
	addq	%rdx, %rax
	addq	$4, %rax
	movl	(%rax), %eax
	.loc 1 32 7 discriminator 4
	testl	%eax, %eax
	jle	.L15
	.loc 1 34 18
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movq	-56(%rbp), %rax
	subq	$1, %rdx
	salq	$5, %rdx
	addq	%rdx, %rax
	addq	$8, %rax
	movl	(%rax), %ecx
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movq	-56(%rbp), %rax
	subq	$1, %rdx
	salq	$5, %rdx
	addq	%rdx, %rax
	addq	$4, %rax
	movl	(%rax), %edx
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__valid_name_state@PLT
	.loc 1 34 18 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 1 34 9 is_stmt 1 discriminator 1
	testb	%al, %al
	je	.L16
.L15:
	.loc 1 32 7 discriminator 5
	movl	$0, %ebx
.LBE6:
.LBE5:
	.loc 1 32 7 is_stmt 0 discriminator 7
	jmp	.L18
.L16:
.LBB7:
	.loc 1 32 7 discriminator 6
	addl	$1, -20(%rbp)
	jmp	.L17
.L18:
.LBE7:
	.loc 1 32 7 discriminator 8
	movl	%ebx, %eax
.LBE2:
	.loc 1 31 4 is_stmt 1
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE5:
	.size	silver_scalar_expressions__valid_environment, .-silver_scalar_expressions__valid_environment
	.align 2
	.globl	silver_scalar_expressions__expression_resultIP
	.type	silver_scalar_expressions__expression_resultIP, @function
silver_scalar_expressions__expression_resultIP:
.LFB6:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE6:
	.size	silver_scalar_expressions__expression_resultIP, .-silver_scalar_expressions__expression_resultIP
	.section	.rodata
	.align 8
.LC9:
	.ascii	"failed precondition from silver_scalar_expressions.ads:57"
	.text
	.align 2
	.globl	silver_scalar_expressions__append
	.type	silver_scalar_expressions__append, @function
silver_scalar_expressions__append:
.LFB7:
	.loc 1 54 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$10952, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -10936(%rbp)
	movq	%rsi, -10944(%rbp)
	movq	%rdx, -10952(%rbp)
	.loc 1 57 30
	movq	-10944(%rbp), %rax
	movl	(%rax), %eax
	.loc 1 57 18
	cmpl	$340, %eax
	jle	.L22
.LBB8:
	.loc 1 57 18 is_stmt 0 discriminator 1
	leaq	.LC9(%rip), %rcx
	leaq	.LC0(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L22:
.LBE8:
	.loc 1 55 29 is_stmt 1
	movq	-10944(%rbp), %rax
	movl	(%rax), %eax
	leal	1(%rax), %ebx
	testl	%ebx, %ebx
	js	.L23
	.loc 1 55 29 is_stmt 0 discriminator 1
	cmpl	$341, %ebx
	jle	.L24
.L23:
	.loc 1 55 29 discriminator 2
	leaq	.LC8(%rip), %rax
	movl	$55, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L24:
	.loc 1 56 17 is_stmt 1
	movq	-10944(%rbp), %rdx
	leaq	-10928(%rbp), %rax
	leaq	4(%rdx), %rcx
	movl	$10912, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 1 56 53
	movq	-10944(%rbp), %rax
	movl	(%rax), %eax
	testl	%eax, %eax
	js	.L25
	.loc 1 56 53 is_stmt 0 discriminator 1
	movq	-10944(%rbp), %rax
	movl	(%rax), %eax
	cmpl	$340, %eax
	jle	.L26
.L25:
	.loc 1 56 53 discriminator 2
	leaq	.LC8(%rip), %rax
	movl	$56, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L26:
	.loc 1 56 53 discriminator 3
	movq	-10944(%rbp), %rax
	movl	(%rax), %eax
	addl	$1, %eax
	cltq
	subq	$1, %rax
	salq	$5, %rax
	leaq	-16(%rax), %rax
	addq	%rbp, %rax
	leaq	-10912(%rax), %rsi
	movq	-10952(%rbp), %rcx
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, (%rsi)
	movq	%rdx, 8(%rsi)
	movq	16(%rcx), %rax
	movq	24(%rcx), %rdx
	movq	%rax, 16(%rsi)
	movq	%rdx, 24(%rsi)
	.loc 1 55 7 is_stmt 1 discriminator 3
	movq	-10936(%rbp), %rax
	movl	%ebx, (%rax)
	movq	-10936(%rbp), %rax
	leaq	4(%rax), %rcx
	leaq	-10928(%rbp), %rax
	movl	$10912, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 1 54 4
	movq	-10936(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE7:
	.size	silver_scalar_expressions__append, .-silver_scalar_expressions__append
	.align 2
	.globl	silver_scalar_expressions__body_binding
	.type	silver_scalar_expressions__body_binding, @function
silver_scalar_expressions__body_binding:
.LFB8:
	.loc 1 61 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -40(%rbp)
	movq	%rsi, -48(%rbp)
	.loc 1 62 6
	movq	-48(%rbp), %rcx
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -32(%rbp)
	movq	%rdx, -24(%rbp)
	movq	16(%rcx), %rax
	movq	24(%rcx), %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	.loc 1 62 23
	movq	-48(%rbp), %rax
	movzbl	28(%rax), %eax
	.loc 1 63 9
	testb	%al, %al
	je	.L29
	.loc 1 62 23 discriminator 1
	movq	-48(%rbp), %rax
	movq	20(%rax), %rax
	movq	%rax, -24(%rbp)
	jmp	.L30
.L29:
	.loc 1 62 23 is_stmt 0 discriminator 2
	movq	-48(%rbp), %rax
	movq	8(%rax), %rax
	movq	%rax, -24(%rbp)
.L30:
	.loc 1 62 6 is_stmt 1 discriminator 3
	movq	-40(%rbp), %rcx
	movq	-32(%rbp), %rax
	movq	-24(%rbp), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movq	-16(%rbp), %rax
	movq	-8(%rbp), %rdx
	movq	%rax, 16(%rcx)
	movq	%rdx, 24(%rcx)
	.loc 1 61 4
	movq	-40(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE8:
	.size	silver_scalar_expressions__body_binding, .-silver_scalar_expressions__body_binding
	.align 2
	.type	silver_scalar_expressions__body_environment___wrapped_statements.0, @function
silver_scalar_expressions__body_environment___wrapped_statements.0:
.LFB10:
	.file 2 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_scalar_expressions.adb"
	.loc 2 8 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r12
	pushq	%rbx
	subq	$10944, %rsp
	.cfi_offset 12, -24
	.cfi_offset 3, -32
	movq	%rdi, -10952(%rbp)
	movq	%r10, %r12
	movq	%r10, -10960(%rbp)
	.loc 2 9 6
	movq	(%r12), %rax
	movl	(%rax), %eax
	movl	%eax, -10944(%rbp)
.LBB9:
	.loc 2 10 16
	movl	$1, %ebx
.L34:
	.loc 2 10 16 is_stmt 0 discriminator 1
	cmpl	$341, %ebx
	jg	.L33
	.loc 2 10 47 is_stmt 1 discriminator 2
	movslq	%ebx, %rdx
	movq	(%r12), %rax
	subq	$1, %rdx
	salq	$5, %rdx
	addq	%rdx, %rax
	leaq	4(%rax), %rdx
	.loc 2 10 16 discriminator 2
	movslq	%ebx, %rax
	.loc 2 10 47 discriminator 2
	subq	$1, %rax
	salq	$5, %rax
	leaq	-16(%rax), %rax
	addq	%rbp, %rax
	subq	$10928, %rax
	addq	$4, %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_scalar_expressions__body_binding
	.loc 2 10 16 discriminator 3
	addl	$1, %ebx
	jmp	.L34
.L33:
.LBE9:
	.loc 2 9 6 discriminator 1
	movq	-10952(%rbp), %rax
	movq	%rax, %rcx
	leaq	-10944(%rbp), %rax
	movl	$10916, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 8 4
	movq	-10952(%rbp), %rax
	addq	$10944, %rsp
	popq	%rbx
	popq	%r12
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE10:
	.size	silver_scalar_expressions__body_environment___wrapped_statements.0, .-silver_scalar_expressions__body_environment___wrapped_statements.0
	.section	.rodata
	.align 8
.LC10:
	.ascii	"failed postcondition from silver_scalar_expressions.ads:66"
	.align 8
.LC11:
	.ascii	"failed postcondition from silver_scalar_expressions.ads:67"
	.align 8
.LC1:
	.long	1
	.long	58
	.text
	.align 2
	.globl	silver_scalar_expressions__body_environment
	.type	silver_scalar_expressions__body_environment, @function
silver_scalar_expressions__body_environment:
.LFB9:
	.loc 2 8 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$11016, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -11048(%rbp)
	movq	%rsi, -11056(%rbp)
	.loc 2 8 4
	leaq	16(%rbp), %rax
	.loc 2 8 4 is_stmt 0 discriminator 1
	movq	%rax, -72(%rbp)
	movq	-11056(%rbp), %rax
	movq	%rax, -80(%rbp)
.LBB10:
	leaq	-11008(%rbp), %rax
	leaq	-80(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_scalar_expressions__body_environment___wrapped_statements.0
.LBB11:
	.loc 1 66 46 is_stmt 1
	movl	-11008(%rbp), %edx
	movq	-80(%rbp), %rax
	movl	(%rax), %eax
	.loc 1 66 16
	cmpl	%eax, %edx
	je	.L37
.LBB12:
	.loc 1 66 16 is_stmt 0 discriminator 1
	leaq	.LC10(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L37:
.LBE12:
	.loc 1 67 20 is_stmt 1
	movl	$1, %ebx
.LBB13:
	.loc 1 67 28
	movl	$1, -52(%rbp)
.L41:
	.loc 1 67 20 discriminator 1
	cmpl	$341, -52(%rbp)
	jg	.L38
.LBB14:
	.loc 1 68 52
	movl	-52(%rbp), %eax
	movslq	%eax, %rdx
	movq	-80(%rbp), %rax
	subq	$1, %rdx
	salq	$5, %rdx
	addq	%rdx, %rax
	leaq	4(%rax), %rdx
	leaq	-11040(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_scalar_expressions__body_binding
	.loc 1 68 52 is_stmt 0 discriminator 1
	leaq	-11040(%rbp), %rax
	.loc 1 68 50 is_stmt 1 discriminator 1
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	subq	$1, %rdx
	salq	$5, %rdx
	leaq	-48(%rdx), %rsi
	leaq	(%rsi,%rbp), %rdx
	subq	$10956, %rdx
	movl	(%rdx), %ecx
	.loc 1 68 50 is_stmt 0 discriminator 2
	movl	(%rax), %edx
	.loc 1 67 20 is_stmt 1 discriminator 2
	cmpl	%edx, %ecx
	jne	.L39
	.loc 1 68 50 discriminator 4
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	subq	$1, %rdx
	salq	$5, %rdx
	leaq	-48(%rdx), %rdi
	leaq	(%rdi,%rbp), %rdx
	subq	$10952, %rdx
	movl	(%rdx), %ecx
	.loc 1 68 50 is_stmt 0 discriminator 5
	movl	4(%rax), %edx
	.loc 1 68 50 discriminator 6
	cmpl	%edx, %ecx
	jne	.L39
	.loc 1 68 50 discriminator 7
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	subq	$1, %rdx
	salq	$5, %rdx
	leaq	-48(%rdx), %rsi
	leaq	(%rsi,%rbp), %rdx
	subq	$10948, %rdx
	movl	(%rdx), %ecx
	.loc 1 68 50 discriminator 8
	movl	8(%rax), %edx
	.loc 1 68 50 discriminator 9
	cmpl	%edx, %ecx
	jne	.L39
	.loc 1 68 50 discriminator 10
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	subq	$1, %rdx
	salq	$5, %rdx
	leaq	-48(%rdx), %rdi
	leaq	(%rdi,%rbp), %rdx
	subq	$10944, %rdx
	movl	(%rdx), %ecx
	.loc 1 68 50 discriminator 11
	movl	12(%rax), %edx
	.loc 1 68 50 discriminator 12
	cmpl	%edx, %ecx
	jne	.L39
	.loc 1 68 50 discriminator 13
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	salq	$5, %rdx
	leaq	-48(%rdx), %rsi
	leaq	(%rsi,%rbp), %rdx
	subq	$10972, %rdx
	movzbl	(%rdx), %ecx
	.loc 1 68 50 discriminator 14
	movzbl	16(%rax), %edx
	.loc 1 68 50 discriminator 15
	cmpb	%dl, %cl
	jne	.L39
	.loc 1 68 50 discriminator 16
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	salq	$5, %rdx
	leaq	-48(%rdx), %rdi
	leaq	(%rdi,%rbp), %rdx
	subq	$10968, %rdx
	movl	(%rdx), %ecx
	.loc 1 68 50 discriminator 17
	movl	20(%rax), %edx
	.loc 1 68 50 discriminator 18
	cmpl	%edx, %ecx
	jne	.L39
	.loc 1 68 50 discriminator 19
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	salq	$5, %rdx
	leaq	-48(%rdx), %rsi
	leaq	(%rsi,%rbp), %rdx
	subq	$10964, %rdx
	movl	(%rdx), %ecx
	.loc 1 68 50 discriminator 20
	movl	24(%rax), %edx
	.loc 1 68 50 discriminator 21
	cmpl	%edx, %ecx
	jne	.L39
	.loc 1 68 50 discriminator 22
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	salq	$5, %rdx
	leaq	-48(%rdx), %rdi
	leaq	(%rdi,%rbp), %rdx
	subq	$10960, %rdx
	movzbl	(%rdx), %edx
	.loc 1 68 50 discriminator 23
	movzbl	28(%rax), %eax
	.loc 1 68 50 discriminator 24
	cmpb	%al, %dl
	je	.L40
.L39:
	.loc 1 67 20 is_stmt 1 discriminator 3
	movl	$0, %ebx
	jmp	.L38
.L40:
.LBE14:
	.loc 1 67 20 is_stmt 0 discriminator 5
	addl	$1, -52(%rbp)
	jmp	.L41
.L38:
.LBE13:
	.loc 1 67 20 discriminator 6
	movl	%ebx, %eax
	xorl	$1, %eax
	.loc 1 66 16 is_stmt 1 discriminator 2
	testb	%al, %al
	je	.L42
.LBB15:
	.loc 1 66 16 is_stmt 0 discriminator 3
	leaq	.LC11(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L42:
.LBE15:
.LBE11:
	.loc 2 8 4 is_stmt 1 discriminator 2
	movq	-11048(%rbp), %rax
	movq	%rax, %rcx
	leaq	-11008(%rbp), %rax
	movl	$10916, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE10:
	.loc 2 8 4 is_stmt 0
	movq	-11048(%rbp), %rax
	addq	$11016, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE9:
	.size	silver_scalar_expressions__body_environment, .-silver_scalar_expressions__body_environment
	.section	.rodata
	.align 8
.LC12:
	.ascii	"Loop_Invariant failed at silver_scalar_expressions.adb:27"
	.align 8
.LC13:
	.ascii	"Loop_Variant failed at silver_scalar_expressions.adb:31"
.LC14:
	.ascii	"silver_scalar_expressions.adb"
	.zero	1
	.align 8
.LC2:
	.long	1
	.long	55
	.text
	.align 2
	.type	silver_scalar_expressions__lookup___wrapped_statements.1, @function
silver_scalar_expressions__lookup___wrapped_statements.1:
.LFB12:
	.loc 2 20 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -72(%rbp)
	.loc 2 23 7
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, -52(%rbp)
	.loc 2 25 7
	movl	20(%rbx), %eax
	testl	%eax, %eax
	je	.L45
	.loc 2 25 20 discriminator 1
	movl	16(%rbx), %edx
	movl	20(%rbx), %eax
	cmpl	%eax, %edx
	jg	.L46
.L45:
	.loc 2 25 48 discriminator 2
	movl	$0, %eax
	jmp	.L47
.L46:
	.loc 2 26 23
	movb	$0, -73(%rbp)
.L68:
.LBB16:
	.loc 2 26 19 discriminator 1
	cmpl	$0, -52(%rbp)
	jle	.L48
	.loc 2 27 39
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	.loc 2 27 33
	cmpl	%eax, -52(%rbp)
	jle	.L49
.LBB17:
	.loc 2 27 33 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L49:
.LBE17:
	.loc 2 31 10 is_stmt 1
	cmpb	$0, -73(%rbp)
	je	.L50
	.loc 2 31 44 discriminator 1
	movl	-80(%rbp), %eax
	movl	%eax, -84(%rbp)
.L50:
	.loc 2 31 44 is_stmt 0 discriminator 2
	movl	-52(%rbp), %eax
	movl	%eax, -80(%rbp)
	.loc 2 31 10 is_stmt 1 discriminator 2
	cmpb	$0, -73(%rbp)
	je	.L51
	.loc 2 31 44 discriminator 3
	movl	-84(%rbp), %edi
	cmpl	%edi, %eax
	jl	.L52
.LBB18:
	.loc 2 31 44 is_stmt 0 discriminator 4
	leaq	.LC13(%rip), %r12
	leaq	.LC2(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L51:
.LBE18:
	.loc 2 31 10 is_stmt 1 discriminator 5
	movb	$1, -73(%rbp)
.L52:
	.loc 2 32 36
	cmpl	$0, -52(%rbp)
	jle	.L53
	.loc 2 32 36 is_stmt 0 discriminator 1
	cmpl	$341, -52(%rbp)
	jle	.L54
.L53:
	.loc 2 32 36 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$32, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L54:
	.loc 2 32 63 is_stmt 1 discriminator 3
	cmpl	$0, -52(%rbp)
	jle	.L55
	.loc 2 32 63 is_stmt 0 discriminator 4
	cmpl	$341, -52(%rbp)
	jle	.L56
.L55:
	.loc 2 32 63 discriminator 5
	leaq	.LC14(%rip), %rax
	movl	$32, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L56:
	.loc 2 32 50 is_stmt 1 discriminator 6
	movl	-52(%rbp), %eax
	movslq	%eax, %rdx
	movq	8(%rbx), %rax
	subq	$1, %rdx
	salq	$5, %rdx
	addq	%rdx, %rax
	addq	$4, %rax
	movl	(%rax), %eax
	testl	%eax, %eax
	jle	.L57
	.loc 2 32 50 is_stmt 0 discriminator 7
	cmpl	$4097, %eax
	jle	.L58
.L57:
	.loc 2 32 50 discriminator 8
	leaq	.LC14(%rip), %rax
	movl	$32, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L58:
	.loc 2 32 77 is_stmt 1 discriminator 9
	movl	-52(%rbp), %edx
	movslq	%edx, %rcx
	movq	8(%rbx), %rdx
	subq	$1, %rcx
	salq	$5, %rcx
	addq	%rcx, %rdx
	addq	$8, %rdx
	movl	(%rdx), %edx
	testl	%edx, %edx
	jle	.L59
	.loc 2 32 77 is_stmt 0 discriminator 10
	cmpl	$4097, %edx
	jle	.L60
.L59:
	.loc 2 32 77 discriminator 11
	leaq	.LC14(%rip), %rax
	movl	$32, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L60:
	.loc 2 33 25 is_stmt 1
	movl	20(%rbx), %ecx
	testl	%ecx, %ecx
	jle	.L61
	.loc 2 33 25 is_stmt 0 discriminator 1
	movl	20(%rbx), %ecx
	cmpl	$4097, %ecx
	jle	.L62
.L61:
	.loc 2 33 25 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$33, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L62:
	.loc 2 33 32 is_stmt 1 discriminator 3
	movl	16(%rbx), %ecx
	testl	%ecx, %ecx
	jle	.L63
	.loc 2 33 32 is_stmt 0 discriminator 4
	movl	16(%rbx), %ecx
	cmpl	$4097, %ecx
	jle	.L64
.L63:
	.loc 2 33 32 discriminator 5
	leaq	.LC14(%rip), %rax
	movl	$33, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L64:
	.loc 2 32 13 is_stmt 1 discriminator 12
	movq	(%rbx), %rcx
	movl	20(%rbx), %r8d
	movl	16(%rbx), %r9d
	movq	(%rcx), %rdi
	movq	8(%rcx), %rsi
	movl	%edx, %ecx
	movl	%eax, %edx
	call	silver_output_lexical__equal_name@PLT
	.loc 2 32 10 discriminator 13
	testb	%al, %al
	je	.L65
	.loc 2 34 15
	movl	-52(%rbp), %eax
	jmp	.L47
.L65:
	.loc 2 35 25
	movl	-52(%rbp), %eax
	subl	$1, %eax
	testl	%eax, %eax
	js	.L66
	.loc 2 35 25 is_stmt 0 discriminator 1
	cmpl	$341, %eax
	jle	.L67
.L66:
	.loc 2 35 25 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$35, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L67:
	.loc 2 35 16 is_stmt 1 discriminator 3
	movl	%eax, -52(%rbp)
.LBE16:
	.loc 2 36 15
	jmp	.L68
.L48:
	.loc 2 37 7
	movl	$0, %eax
.L47:
	.loc 2 38 8
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE12:
	.size	silver_scalar_expressions__lookup___wrapped_statements.1, .-silver_scalar_expressions__lookup___wrapped_statements.1
	.section	.rodata
	.align 8
.LC15:
	.ascii	"failed precondition from silver_scalar_expressions.ads:49"
	.align 8
.LC16:
	.ascii	"failed precondition from silver_scalar_expressions.ads:50"
	.align 8
.LC17:
	.ascii	"failed precondition from silver_scalar_expressions.ads:51"
	.align 8
.LC18:
	.ascii	"failed postcondition from silver_scalar_expressions.ads:52"
	.text
	.align 2
	.globl	silver_scalar_expressions__lookup
	.type	silver_scalar_expressions__lookup, @function
silver_scalar_expressions__lookup:
.LFB11:
	.loc 2 20 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	addq	$-128, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r9
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r9, %rdi
	movq	%rsi, -80(%rbp)
	movq	%rdi, -72(%rbp)
	movq	%rdx, -88(%rbp)
	movl	%ecx, -92(%rbp)
	movl	%r8d, -96(%rbp)
	.loc 2 20 4
	leaq	16(%rbp), %rdx
	.loc 2 20 4 is_stmt 0 discriminator 1
	leaq	-80(%rbp), %rax
	movq	%rdx, -40(%rbp)
	movq	%rax, -64(%rbp)
	movq	-88(%rbp), %rax
	movq	%rax, -56(%rbp)
	movl	-92(%rbp), %eax
	movl	%eax, -44(%rbp)
	movl	-96(%rbp), %eax
	movl	%eax, -48(%rbp)
	movq	-72(%rbp), %rax
	movl	(%rax), %r8d
	movq	-72(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%r8d, %r12d
	jl	.L70
	.loc 2 20 4 discriminator 2
	movslq	%r12d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r8d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L71
.L70:
	.loc 2 20 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L71:
.LBB19:
	.loc 2 20 4 discriminator 4
	cmpl	%r8d, %r12d
	.loc 2 20 4 discriminator 7
	cmpl	%r8d, %r12d
	.loc 2 20 4 discriminator 10
	cmpl	%r8d, %r12d
	.loc 1 49 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L78
.LBB20:
	.loc 1 49 15 is_stmt 0 discriminator 1
	leaq	.LC15(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L78:
.LBE20:
	.loc 1 49 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 1 49 15 discriminator 2
	testl	%eax, %eax
	jle	.L79
	.loc 1 49 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L80
.L79:
.LBB21:
	.loc 1 49 15 discriminator 4
	leaq	.LC15(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L80:
.LBE21:
	.loc 1 50 19
	movq	-56(%rbp), %rdx
	movq	-80(%rbp), %rcx
	movq	-72(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__valid_environment
	.loc 1 50 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 1 49 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L81
.LBB22:
	.loc 1 49 15 is_stmt 0 discriminator 6
	leaq	.LC16(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L81:
.LBE22:
	.loc 1 51 38 is_stmt 1
	cmpl	$2147483647, %r12d
	jne	.L82
	.loc 1 51 38 is_stmt 0 discriminator 1
	leaq	.LC8(%rip), %rax
	movl	$51, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L82:
	.loc 1 51 38 discriminator 3
	leal	1(%r12), %edx
	.loc 1 49 15 is_stmt 1 discriminator 7
	movl	-44(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L83
.LBB23:
	.loc 1 49 15 is_stmt 0 discriminator 8
	leaq	.LC17(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L83:
.LBE23:
	.loc 1 51 70 is_stmt 1 discriminator 4
	cmpl	$2147483647, %r12d
	jne	.L84
	.loc 1 51 70 is_stmt 0 discriminator 5
	leaq	.LC8(%rip), %rax
	movl	$51, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L84:
	.loc 1 51 70 discriminator 7
	leal	1(%r12), %edx
	.loc 1 49 15 is_stmt 1 discriminator 9
	movl	-48(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L85
.LBB24:
	.loc 1 49 15 is_stmt 0 discriminator 10
	leaq	.LC17(%rip), %rax
	movq	%rax, -112(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -104(%rbp)
	movq	-112(%rbp), %rbx
	movq	-104(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L85:
.LBE24:
.LBB25:
	.loc 2 20 4 is_stmt 1 discriminator 13
	leaq	-64(%rbp), %rax
	movq	%rax, %r10
	call	silver_scalar_expressions__lookup___wrapped_statements.1
	.loc 1 52 42
	movq	-56(%rbp), %rdx
	movl	(%rdx), %edx
	.loc 1 52 28
	cmpl	%edx, %eax
	jle	.L87
.LBB26:
	.loc 1 52 28 is_stmt 0 discriminator 1
	leaq	.LC18(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L87:
.LBE26:
.LBE25:
.LBE19:
	.loc 2 20 4 is_stmt 1
	subq	$-128, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE11:
	.size	silver_scalar_expressions__lookup, .-silver_scalar_expressions__lookup
	.align 2
	.type	silver_scalar_expressions__skip___wrapped_statements.2, @function
silver_scalar_expressions__skip___wrapped_statements.2:
.LFB14:
	.loc 2 48 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%r10, %rax
	movq	%r10, -24(%rbp)
	.loc 2 51 7
	movl	8(%rax), %edx
	testl	%edx, %edx
	jne	.L89
	.loc 2 51 28 discriminator 1
	movl	$0, %eax
	jmp	.L90
.L89:
	.loc 2 52 15
	movl	8(%rax), %edx
	testl	%edx, %edx
	jle	.L91
	.loc 2 52 15 is_stmt 0 discriminator 1
	movl	8(%rax), %edx
	cmpl	$4097, %edx
	jle	.L92
.L91:
	.loc 2 52 15 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$52, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L92:
	.loc 2 52 12 is_stmt 1 discriminator 3
	movl	8(%rax), %edx
	movl	%edx, -4(%rbp)
	.loc 2 53 7
	movq	(%rax), %rax
	movl	-4(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__skip_trivia@PLT
	.loc 2 53 7 is_stmt 0 discriminator 1
	movl	%eax, -4(%rbp)
	.loc 2 54 7 is_stmt 1
	movl	-4(%rbp), %eax
.L90:
	.loc 2 55 8
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE14:
	.size	silver_scalar_expressions__skip___wrapped_statements.2, .-silver_scalar_expressions__skip___wrapped_statements.2
	.section	.rodata
	.align 8
.LC19:
	.ascii	"failed precondition from silver_scalar_expressions.adb:42"
	.align 8
.LC20:
	.ascii	"failed precondition from silver_scalar_expressions.adb:43"
	.align 8
.LC21:
	.ascii	"failed postcondition from silver_scalar_expressions.adb:44"
	.text
	.align 2
	.globl	silver_scalar_expressions__skip
	.type	silver_scalar_expressions__skip, @function
silver_scalar_expressions__skip:
.LFB13:
	.loc 2 48 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -96(%rbp)
	movq	%rbx, -88(%rbp)
	movl	%edx, -100(%rbp)
	.loc 2 48 4
	leaq	16(%rbp), %rdx
	.loc 2 48 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -80(%rbp)
	movl	-100(%rbp), %eax
	movl	%eax, -72(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	movq	-88(%rbp), %rdx
	movl	4(%rdx), %ebx
	cmpl	%eax, %ebx
	jl	.L94
	.loc 2 48 4 discriminator 2
	movslq	%ebx, %rdx
	movq	%rdx, %rsi
	movq	%rdx, %rdi
	sarq	$63, %rdi
	movslq	%eax, %rdx
	movq	%rdx, %rcx
	sarq	$63, %rcx
	subq	%rdx, %rsi
	sbbq	%rcx, %rdi
	addq	$1, %rsi
	adcq	$0, %rdi
	jmp	.L95
.L94:
	.loc 2 48 4 discriminator 3
	movl	$0, %esi
	movl	$0, %edi
.L95:
.LBB27:
	.loc 2 48 4 discriminator 4
	cmpl	%eax, %ebx
	.loc 2 48 4 discriminator 7
	cmpl	%eax, %ebx
	.loc 2 48 4 discriminator 10
	cmpl	%eax, %ebx
	.loc 2 42 15 is_stmt 1
	cmpl	$1, %eax
	je	.L102
.LBB28:
	.loc 2 42 15 is_stmt 0 discriminator 1
	leaq	.LC19(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L102:
.LBE28:
	.loc 2 42 51 is_stmt 1 discriminator 2
	movl	%esi, %eax
	.loc 2 42 15 discriminator 2
	testl	%eax, %eax
	jle	.L103
	.loc 2 42 51 discriminator 3
	movl	%esi, %eax
	cmpl	$4096, %eax
	jle	.L104
.L103:
.LBB29:
	.loc 2 42 15 discriminator 4
	leaq	.LC19(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L104:
.LBE29:
	.loc 2 43 41
	cmpl	$2147483647, %ebx
	jne	.L105
	.loc 2 43 41 is_stmt 0 discriminator 1
	leaq	.LC14(%rip), %rax
	movl	$43, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L105:
	.loc 2 43 41 discriminator 3
	leal	1(%rbx), %edx
	.loc 2 42 15 is_stmt 1 discriminator 5
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L106
.LBB30:
	.loc 2 42 15 is_stmt 0 discriminator 6
	leaq	.LC20(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L106:
.LBE30:
.LBB31:
	.loc 2 48 4 is_stmt 1 discriminator 13
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_scalar_expressions__skip___wrapped_statements.2
	.loc 2 44 29
	movl	-72(%rbp), %edx
	testl	%edx, %edx
	jne	.L107
	.loc 2 44 29 is_stmt 0 discriminator 1
	testl	%eax, %eax
	setne	%dl
	jmp	.L108
.L107:
	.loc 2 45 34 is_stmt 1
	movl	-72(%rbp), %edx
	cmpl	%edx, %eax
	jl	.L109
	.loc 2 45 59 discriminator 1
	cmpl	$2147483647, %ebx
	jne	.L110
	.loc 2 45 59 is_stmt 0 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$45, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L110:
	.loc 2 45 59 discriminator 4
	leal	1(%rbx), %edx
	.loc 2 45 34 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L111
.L109:
	.loc 2 45 34 is_stmt 0 discriminator 6
	movl	$1, %edx
	jmp	.L108
.L111:
	.loc 2 45 34 discriminator 7
	movl	$0, %edx
.L108:
	.loc 2 44 29 is_stmt 1 discriminator 3
	testb	%dl, %dl
	je	.L114
.LBB32:
	.loc 2 44 29 is_stmt 0 discriminator 4
	leaq	.LC21(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L114:
.LBE32:
.LBE31:
.LBE27:
	.loc 2 48 4 is_stmt 1
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE13:
	.size	silver_scalar_expressions__skip, .-silver_scalar_expressions__skip
	.align 2
	.type	silver_scalar_expressions__symbol___wrapped_statements.3, @function
silver_scalar_expressions__symbol___wrapped_statements.3:
.LFB16:
	.loc 2 64 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%r10, %rbx
	movq	%r10, -56(%rbp)
	.loc 2 64 4
	movq	(%rbx), %rax
	movq	8(%rax), %rax
	movl	(%rax), %r13d
	movq	(%rbx), %rax
	movq	8(%rax), %rax
	movl	4(%rax), %r12d
.LBB33:
	.loc 2 66 52
	movq	(%rbx), %rax
	movl	8(%rbx), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__skip
	.loc 2 66 52 is_stmt 0 discriminator 1
	movl	%eax, -36(%rbp)
	.loc 2 67 14 is_stmt 1
	cmpl	$0, -36(%rbp)
	je	.L116
	.loc 2 67 27 discriminator 1
	cmpl	-36(%rbp), %r12d
	jl	.L116
	.loc 2 67 61 discriminator 2
	cmpl	-36(%rbp), %r13d
	jg	.L117
	.loc 2 67 61 is_stmt 0 discriminator 3
	cmpl	-36(%rbp), %r12d
	jge	.L118
.L117:
	.loc 2 67 61 discriminator 4
	leaq	.LC14(%rip), %rax
	movl	$67, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L118:
	.loc 2 67 74 is_stmt 1 discriminator 5
	movq	(%rbx), %rax
	movq	(%rax), %rax
	movq	(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-36(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	movzbl	12(%rbx), %edx
	cmpb	%al, %dl
	setne	%al
	xorl	$1, %eax
	.loc 2 67 53 discriminator 5
	testb	%al, %al
	je	.L116
	.loc 2 68 32
	movl	-36(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L119
	.loc 2 68 32 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L123
.L119:
	.loc 2 68 32 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$68, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L116:
	.loc 2 67 14 is_stmt 1 discriminator 7
	movl	$0, %eax
	.loc 2 66 7 discriminator 2
	jmp	.L121
.L123:
	.loc 2 67 14 discriminator 6
	nop
.L121:
.LBE33:
	.loc 2 64 4
	addq	$40, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE16:
	.size	silver_scalar_expressions__symbol___wrapped_statements.3, .-silver_scalar_expressions__symbol___wrapped_statements.3
	.section	.rodata
	.align 8
.LC22:
	.ascii	"failed precondition from silver_scalar_expressions.adb:60"
	.align 8
.LC23:
	.ascii	"failed precondition from silver_scalar_expressions.adb:61"
	.align 8
.LC24:
	.ascii	"failed postcondition from silver_scalar_expressions.adb:62"
	.text
	.align 2
	.globl	silver_scalar_expressions__symbol
	.type	silver_scalar_expressions__symbol, @function
silver_scalar_expressions__symbol:
.LFB15:
	.loc 2 64 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %rbx
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%rbx, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movl	%edx, -100(%rbp)
	movb	%cl, -101(%rbp)
	.loc 2 64 4
	leaq	16(%rbp), %rdx
	.loc 2 64 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -80(%rbp)
	movl	-100(%rbp), %eax
	movl	%eax, -72(%rbp)
	movzbl	-101(%rbp), %eax
	movb	%al, -68(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -108(%rbp)
	movq	-88(%rbp), %rax
	movl	4(%rax), %ebx
	movq	-88(%rbp), %rax
	movl	4(%rax), %edx
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L125
	.loc 2 64 4 discriminator 2
	movq	-88(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-88(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movq	%rcx, %rsi
	movq	%rcx, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L126
.L125:
	.loc 2 64 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L126:
.LBB34:
	.loc 2 60 15 is_stmt 1
	cmpl	$1, -108(%rbp)
	je	.L127
.LBB35:
	.loc 2 60 15 is_stmt 0 discriminator 1
	leaq	.LC22(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L127:
.LBE35:
	.loc 2 60 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 60 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L128
	.loc 2 60 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L129
.L128:
.LBB36:
	.loc 2 60 15 discriminator 4
	leaq	.LC22(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L129:
.LBE36:
	.loc 2 61 41
	cmpl	$2147483647, %ebx
	jne	.L130
	.loc 2 61 41 is_stmt 0 discriminator 1
	leaq	.LC14(%rip), %rax
	movl	$61, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L130:
	.loc 2 61 41 discriminator 3
	leal	1(%rbx), %edx
	.loc 2 60 15 is_stmt 1 discriminator 5
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L131
.LBB37:
	.loc 2 60 15 is_stmt 0 discriminator 6
	leaq	.LC23(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L131:
.LBE37:
.LBB38:
	.loc 2 64 4 is_stmt 1 discriminator 5
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_scalar_expressions__symbol___wrapped_statements.3
	.loc 2 62 16
	testl	%eax, %eax
	je	.L135
	.loc 2 63 10
	movl	-72(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L133
	.loc 2 63 61 discriminator 1
	cmpl	$2147483647, %ebx
	jne	.L134
	.loc 2 63 61 is_stmt 0 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$63, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L134:
	.loc 2 63 61 discriminator 4
	leal	1(%rbx), %edx
	.loc 2 63 32 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L135
.L133:
.LBB39:
	.loc 2 62 16 discriminator 1
	leaq	.LC24(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L135:
.LBE39:
.LBE38:
.LBE34:
	.loc 2 64 4
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE15:
	.size	silver_scalar_expressions__symbol, .-silver_scalar_expressions__symbol
	.align 2
	.type	silver_scalar_expressions__name_after___wrapped_statements.4, @function
silver_scalar_expressions__name_after___wrapped_statements.4:
.LFB18:
	.loc 2 78 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%r10, %rax
	movq	%r10, -24(%rbp)
	.loc 2 82 7
	movl	8(%rax), %edx
	testl	%edx, %edx
	jne	.L137
	.loc 2 82 28 discriminator 1
	movl	$0, %eax
	jmp	.L138
.L137:
	.loc 2 83 15
	movl	8(%rax), %edx
	testl	%edx, %edx
	jle	.L139
	.loc 2 83 15 is_stmt 0 discriminator 1
	movl	8(%rax), %edx
	cmpl	$4097, %edx
	jle	.L140
.L139:
	.loc 2 83 15 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$83, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L140:
	.loc 2 83 12 is_stmt 1 discriminator 3
	movl	8(%rax), %edx
	movl	%edx, -4(%rbp)
.LBB40:
	.loc 2 84 7
	movq	(%rax), %rax
	movl	-4(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__match_identifier@PLT
	.loc 2 84 7 is_stmt 0 discriminator 1
	movl	%eax, -4(%rbp)
	shrq	$32, %rax
	andb	$-1, %ah
	movb	%al, -5(%rbp)
.LBE40:
	.loc 2 85 15 is_stmt 1
	cmpb	$0, -5(%rbp)
	je	.L141
	.loc 2 85 31 discriminator 1
	movl	-4(%rbp), %eax
	jmp	.L138
.L141:
	.loc 2 85 41 discriminator 2
	movl	$0, %eax
.L138:
	.loc 2 86 8
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE18:
	.size	silver_scalar_expressions__name_after___wrapped_statements.4, .-silver_scalar_expressions__name_after___wrapped_statements.4
	.section	.rodata
	.align 8
.LC25:
	.ascii	"failed precondition from silver_scalar_expressions.adb:72"
	.align 8
.LC26:
	.ascii	"failed precondition from silver_scalar_expressions.adb:73"
	.align 8
.LC27:
	.ascii	"failed postcondition from silver_scalar_expressions.adb:74"
	.text
	.align 2
	.globl	silver_scalar_expressions__name_after
	.type	silver_scalar_expressions__name_after, @function
silver_scalar_expressions__name_after:
.LFB17:
	.loc 2 78 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -96(%rbp)
	movq	%rbx, -88(%rbp)
	movl	%edx, -100(%rbp)
	.loc 2 78 4
	leaq	16(%rbp), %rdx
	.loc 2 78 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -80(%rbp)
	movl	-100(%rbp), %eax
	movl	%eax, -72(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	movq	-88(%rbp), %rdx
	movl	4(%rdx), %ebx
	cmpl	%eax, %ebx
	jl	.L143
	.loc 2 78 4 discriminator 2
	movslq	%ebx, %rdx
	movq	%rdx, %rsi
	movq	%rdx, %rdi
	sarq	$63, %rdi
	movslq	%eax, %rdx
	movq	%rdx, %rcx
	sarq	$63, %rcx
	subq	%rdx, %rsi
	sbbq	%rcx, %rdi
	addq	$1, %rsi
	adcq	$0, %rdi
	jmp	.L144
.L143:
	.loc 2 78 4 discriminator 3
	movl	$0, %esi
	movl	$0, %edi
.L144:
.LBB41:
	.loc 2 78 4 discriminator 4
	cmpl	%eax, %ebx
	.loc 2 78 4 discriminator 7
	cmpl	%eax, %ebx
	.loc 2 78 4 discriminator 10
	cmpl	%eax, %ebx
	.loc 2 72 15 is_stmt 1
	cmpl	$1, %eax
	je	.L151
.LBB42:
	.loc 2 72 15 is_stmt 0 discriminator 1
	leaq	.LC25(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L151:
.LBE42:
	.loc 2 72 51 is_stmt 1 discriminator 2
	movl	%esi, %eax
	.loc 2 72 15 discriminator 2
	testl	%eax, %eax
	jle	.L152
	.loc 2 72 51 discriminator 3
	movl	%esi, %eax
	cmpl	$4096, %eax
	jle	.L153
.L152:
.LBB43:
	.loc 2 72 15 discriminator 4
	leaq	.LC25(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L153:
.LBE43:
	.loc 2 73 41
	cmpl	$2147483647, %ebx
	jne	.L154
	.loc 2 73 41 is_stmt 0 discriminator 1
	leaq	.LC14(%rip), %rax
	movl	$73, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L154:
	.loc 2 73 41 discriminator 3
	leal	1(%rbx), %edx
	.loc 2 72 15 is_stmt 1 discriminator 5
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L155
.LBB44:
	.loc 2 72 15 is_stmt 0 discriminator 6
	leaq	.LC26(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L155:
.LBE44:
.LBB45:
	.loc 2 78 4 is_stmt 1 discriminator 13
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_scalar_expressions__name_after___wrapped_statements.4
	.loc 2 74 28
	testl	%eax, %eax
	je	.L159
	.loc 2 75 10
	movl	-72(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L157
	.loc 2 75 65 discriminator 1
	cmpl	$2147483647, %ebx
	jne	.L158
	.loc 2 75 65 is_stmt 0 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$75, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L158:
	.loc 2 75 65 discriminator 4
	leal	1(%rbx), %edx
	.loc 2 75 36 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L159
.L157:
.LBB46:
	.loc 2 74 28 discriminator 1
	leaq	.LC27(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L159:
.LBE46:
.LBE45:
.LBE41:
	.loc 2 78 4
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE17:
	.size	silver_scalar_expressions__name_after, .-silver_scalar_expressions__name_after
	.align 2
	.type	silver_scalar_expressions__literal_result___wrapped_statements.5, @function
silver_scalar_expressions__literal_result___wrapped_statements.5:
.LFB20:
	.loc 2 94 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -72(%rbp)
	movq	%r10, %rbx
	movq	%r10, -80(%rbp)
	.loc 2 97 65
	movzbl	8(%rbx), %eax
	testb	%al, %al
	je	.L161
	.loc 2 99 28
	movq	(%rbx), %rax
	movq	8(%rax), %rax
	.loc 2 97 65 discriminator 1
	negq	%rax
	movq	%rax, %rdx
	jmp	.L162
.L161:
	.loc 2 97 65 is_stmt 0 discriminator 2
	movq	(%rbx), %rax
	movq	8(%rax), %rdx
.L162:
	.loc 2 97 65 discriminator 3
	movzbl	8(%rbx), %eax
	testb	%al, %al
	je	.L163
	.loc 2 98 28 is_stmt 1
	movq	(%rbx), %rax
	movq	8(%rax), %rax
	.loc 2 97 65 discriminator 4
	negq	%rax
	jmp	.L164
.L163:
	.loc 2 97 65 is_stmt 0 discriminator 5
	movq	(%rbx), %rax
	movq	8(%rax), %rax
.L164:
	.loc 2 97 65 discriminator 6
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__checked@PLT
	movq	%rax, -64(%rbp)
	movl	-56(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -56(%rbp)
	.loc 2 100 30 is_stmt 1
	movq	(%rbx), %rax
	movl	(%rax), %eax
	.loc 2 100 14
	testl	%eax, %eax
	je	.L165
	.loc 2 100 34 discriminator 1
	movzbl	-64(%rbp), %eax
	testb	%al, %al
	je	.L165
	.loc 2 100 14 discriminator 2
	movq	(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, -48(%rbp)
	movq	-60(%rbp), %rax
	movq	%rax, -44(%rbp)
	movl	$1, -36(%rbp)
	movb	$1, -32(%rbp)
	jmp	.L166
.L165:
	.loc 2 100 14 is_stmt 0 discriminator 3
	movl	$0, -48(%rbp)
	movl	$1, -44(%rbp)
	movl	$0, -40(%rbp)
	movl	$0, -36(%rbp)
	movb	$0, -32(%rbp)
.L166:
	.loc 2 100 14 discriminator 4
	leaq	-48(%rbp), %rsi
	.loc 2 97 7 is_stmt 1 discriminator 7
	movq	-72(%rbp), %rcx
	movq	(%rsi), %rax
	movq	8(%rsi), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movl	16(%rsi), %eax
	movl	%eax, 16(%rcx)
	.loc 2 94 4
	movq	-72(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE20:
	.size	silver_scalar_expressions__literal_result___wrapped_statements.5, .-silver_scalar_expressions__literal_result___wrapped_statements.5
	.section	.rodata
	.align 8
.LC28:
	.ascii	"failed postcondition from silver_scalar_expressions.adb:91"
	.text
	.align 2
	.globl	silver_scalar_expressions__literal_result
	.type	silver_scalar_expressions__literal_result, @function
silver_scalar_expressions__literal_result:
.LFB19:
	.loc 2 94 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	subq	$96, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	movq	%rdi, -88(%rbp)
	movl	%esi, %eax
	movq	%rdx, %rsi
	movq	%rsi, %rdx
	movq	%rax, -112(%rbp)
	movq	%rdx, -104(%rbp)
	movb	%cl, -89(%rbp)
	.loc 2 94 4
	leaq	16(%rbp), %rdx
	.loc 2 94 4 is_stmt 0 discriminator 1
	leaq	-112(%rbp), %rax
	movq	%rdx, -32(%rbp)
	movq	%rax, -48(%rbp)
	movzbl	-89(%rbp), %eax
	movb	%al, -40(%rbp)
.LBB47:
	leaq	-80(%rbp), %rax
	leaq	-48(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_scalar_expressions__literal_result___wrapped_statements.5
	.loc 2 91 47 is_stmt 1
	movl	-80(%rbp), %eax
	.loc 2 91 19
	testl	%eax, %eax
	je	.L169
	.loc 2 92 45
	movl	-80(%rbp), %edx
	movl	-112(%rbp), %eax
	.loc 2 92 8
	cmpl	%eax, %edx
	jne	.L170
	.loc 2 93 50
	movl	-68(%rbp), %eax
	.loc 2 93 10
	cmpl	$1, %eax
	je	.L169
.L170:
.LBB48:
	.loc 2 91 19 discriminator 1
	leaq	.LC28(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L169:
.LBE48:
	.loc 2 94 4 discriminator 2
	movq	-88(%rbp), %rcx
	movq	-80(%rbp), %rax
	movq	-72(%rbp), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movl	-64(%rbp), %eax
	movl	%eax, 16(%rcx)
.LBE47:
	.loc 2 94 4 is_stmt 0
	movq	-88(%rbp), %rax
	addq	$96, %rsp
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE19:
	.size	silver_scalar_expressions__literal_result, .-silver_scalar_expressions__literal_result
	.align 2
	.type	silver_scalar_expressions__unary_result___wrapped_statements.6, @function
silver_scalar_expressions__unary_result___wrapped_statements.6:
.LFB22:
	.loc 2 108 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$120, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -120(%rbp)
	movq	%r10, %rbx
	movq	%r10, -128(%rbp)
	.loc 2 111 10
	movzbl	8(%rbx), %eax
	testb	%al, %al
	je	.L173
	.loc 2 111 34 discriminator 1
	movq	(%rbx), %rax
	movq	4(%rax), %rax
	movq	%rax, %rdi
	call	silver_scalars__negate@PLT
	movq	%rax, -60(%rbp)
	movl	-52(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -52(%rbp)
	.loc 2 111 34 is_stmt 0 discriminator 2
	leaq	-60(%rbp), %rax
	.loc 2 110 15 is_stmt 1
	movq	(%rax), %rdx
	movq	%rdx, -80(%rbp)
	movl	8(%rax), %eax
	movl	%eax, -72(%rbp)
	jmp	.L174
.L173:
	.loc 2 110 15 is_stmt 0 discriminator 1
	movb	$1, -80(%rbp)
	movq	(%rbx), %rax
	movq	4(%rax), %rax
	movq	%rax, -76(%rbp)
.L174:
	.loc 2 112 31 is_stmt 1
	movq	(%rbx), %rax
	movl	(%rax), %eax
	.loc 2 112 14
	testl	%eax, %eax
	je	.L175
	.loc 2 112 35 discriminator 1
	movzbl	-80(%rbp), %eax
	testb	%al, %al
	je	.L175
	.loc 2 113 19
	movq	(%rbx), %rcx
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -112(%rbp)
	movq	%rdx, -104(%rbp)
	movl	16(%rcx), %eax
	movl	%eax, -96(%rbp)
	.loc 2 113 39
	movq	-76(%rbp), %rax
	movq	%rax, -108(%rbp)
	.loc 2 112 14 discriminator 2
	movq	-112(%rbp), %rax
	movq	-104(%rbp), %rdx
	movq	%rax, -48(%rbp)
	movq	%rdx, -40(%rbp)
	movl	-96(%rbp), %eax
	movl	%eax, -32(%rbp)
	jmp	.L176
.L175:
	.loc 2 112 14 is_stmt 0 discriminator 3
	movl	$0, -48(%rbp)
	movl	$1, -44(%rbp)
	movl	$0, -40(%rbp)
	movl	$0, -36(%rbp)
	movb	$0, -32(%rbp)
.L176:
	.loc 2 112 14 discriminator 4
	leaq	-48(%rbp), %rsi
	.loc 2 110 7 is_stmt 1 discriminator 2
	movq	-120(%rbp), %rcx
	movq	(%rsi), %rax
	movq	8(%rsi), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movl	16(%rsi), %eax
	movl	%eax, 16(%rcx)
	.loc 2 108 4
	movq	-120(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE22:
	.size	silver_scalar_expressions__unary_result___wrapped_statements.6, .-silver_scalar_expressions__unary_result___wrapped_statements.6
	.section	.rodata
	.align 8
.LC29:
	.ascii	"failed postcondition from silver_scalar_expressions.adb:105"
	.align 8
.LC3:
	.long	1
	.long	59
	.text
	.align 2
	.globl	silver_scalar_expressions__unary_result
	.type	silver_scalar_expressions__unary_result, @function
silver_scalar_expressions__unary_result:
.LFB21:
	.loc 2 108 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	subq	$96, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	movq	%rdi, -88(%rbp)
	movq	%rsi, -96(%rbp)
	movb	%dl, -97(%rbp)
	.loc 2 108 4
	leaq	16(%rbp), %rax
	.loc 2 108 4 is_stmt 0 discriminator 1
	movq	%rax, -32(%rbp)
	movq	-96(%rbp), %rax
	movq	%rax, -48(%rbp)
	movzbl	-97(%rbp), %eax
	movb	%al, -40(%rbp)
.LBB49:
	leaq	-80(%rbp), %rax
	leaq	-48(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_scalar_expressions__unary_result___wrapped_statements.6
	.loc 2 105 45 is_stmt 1
	movl	-80(%rbp), %eax
	.loc 2 105 19
	testl	%eax, %eax
	je	.L179
	.loc 2 106 43
	movl	-80(%rbp), %edx
	movq	-48(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 106 8
	cmpl	%eax, %edx
	jne	.L180
	.loc 2 107 48
	movl	-68(%rbp), %edx
	movq	-48(%rbp), %rax
	movl	12(%rax), %eax
	.loc 2 107 10
	cmpl	%eax, %edx
	je	.L179
.L180:
.LBB50:
	.loc 2 105 19 discriminator 1
	leaq	.LC29(%rip), %r12
	leaq	.LC3(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L179:
.LBE50:
	.loc 2 108 4 discriminator 2
	movq	-88(%rbp), %rcx
	movq	-80(%rbp), %rax
	movq	-72(%rbp), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movl	-64(%rbp), %eax
	movl	%eax, 16(%rcx)
.LBE49:
	.loc 2 108 4 is_stmt 0
	movq	-88(%rbp), %rax
	addq	$96, %rsp
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE21:
	.size	silver_scalar_expressions__unary_result, .-silver_scalar_expressions__unary_result
	.align 2
	.type	silver_scalar_expressions__binary_result___wrapped_statements.7, @function
silver_scalar_expressions__binary_result___wrapped_statements.7:
.LFB24:
	.loc 2 121 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$184, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -184(%rbp)
	movq	%r10, %rbx
	movq	%r10, -192(%rbp)
	.loc 2 124 10
	movzbl	16(%rbx), %eax
	cmpb	$114, %al
	je	.L183
	cmpb	$114, %al
	ja	.L184
	cmpb	$109, %al
	je	.L185
	cmpb	$109, %al
	ja	.L184
	cmpb	$47, %al
	je	.L186
	cmpb	$47, %al
	ja	.L184
	cmpb	$45, %al
	je	.L187
	cmpb	$45, %al
	ja	.L184
	cmpb	$42, %al
	je	.L188
	cmpb	$43, %al
	jne	.L184
	.loc 2 125 31
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	4(%rdx), %rdx
	movq	4(%rax), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__add@PLT
	movq	%rax, -96(%rbp)
	movl	-88(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -88(%rbp)
	.loc 2 125 31 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	.loc 2 124 10 is_stmt 1 discriminator 1
	jmp	.L189
.L187:
	.loc 2 126 31
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	4(%rdx), %rdx
	movq	4(%rax), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__subtract@PLT
	movq	%rax, -112(%rbp)
	movl	-104(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -104(%rbp)
	.loc 2 126 31 is_stmt 0 discriminator 1
	leaq	-112(%rbp), %rax
	.loc 2 124 10 is_stmt 1 discriminator 2
	jmp	.L189
.L188:
	.loc 2 127 31
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	4(%rdx), %rdx
	movq	4(%rax), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__multiply@PLT
	movq	%rax, -128(%rbp)
	movl	-120(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -120(%rbp)
	.loc 2 127 31 is_stmt 0 discriminator 1
	leaq	-128(%rbp), %rax
	.loc 2 124 10 is_stmt 1 discriminator 3
	jmp	.L189
.L186:
	.loc 2 128 31
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	4(%rdx), %rdx
	movq	4(%rax), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__divide@PLT
	movq	%rax, -144(%rbp)
	movl	-136(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -136(%rbp)
	.loc 2 128 31 is_stmt 0 discriminator 1
	leaq	-144(%rbp), %rax
	.loc 2 124 10 is_stmt 1 discriminator 4
	jmp	.L189
.L185:
	.loc 2 129 31
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	4(%rdx), %rdx
	movq	4(%rax), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__modulo@PLT
	movq	%rax, -160(%rbp)
	movl	-152(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -152(%rbp)
	.loc 2 129 31 is_stmt 0 discriminator 1
	leaq	-160(%rbp), %rax
	.loc 2 124 10 is_stmt 1 discriminator 5
	jmp	.L189
.L183:
	.loc 2 130 31
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	4(%rdx), %rdx
	movq	4(%rax), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__remainder@PLT
	movq	%rax, -176(%rbp)
	movl	-168(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -168(%rbp)
	.loc 2 130 31 is_stmt 0 discriminator 1
	leaq	-176(%rbp), %rax
	.loc 2 124 10 is_stmt 1 discriminator 6
	jmp	.L189
.L184:
	.loc 2 131 34
	leaq	C123b.15(%rip), %rax
	.loc 2 124 10 discriminator 7
	nop
.L189:
	.loc 2 123 15
	movq	%rax, -24(%rbp)
	.loc 2 132 28
	movq	8(%rbx), %rdx
	movl	(%rdx), %edx
	.loc 2 132 14
	testl	%edx, %edx
	je	.L190
	.loc 2 132 52 discriminator 1
	movq	(%rbx), %rdx
	movl	(%rdx), %edx
	.loc 2 132 32 discriminator 1
	testl	%edx, %edx
	je	.L190
	.loc 2 132 56 discriminator 2
	movzbl	(%rax), %edx
	.loc 2 132 56 is_stmt 0 discriminator 3
	testb	%dl, %dl
	je	.L190
	.loc 2 133 38 is_stmt 1
	movq	8(%rbx), %rdx
	movl	12(%rdx), %esi
	.loc 2 133 53
	movq	(%rbx), %rdx
	movl	12(%rdx), %edx
	movl	$64, %ecx
	subl	%edx, %ecx
	.loc 2 133 16
	cmpl	%ecx, %esi
	jg	.L190
	.loc 2 134 76
	movq	8(%rbx), %rdx
	movl	12(%rdx), %ecx
	movq	(%rbx), %rdx
	movl	12(%rdx), %edx
	addl	%ecx, %edx
	testl	%edx, %edx
	js	.L191
	.loc 2 134 76 is_stmt 0 discriminator 1
	cmpl	$64, %edx
	jle	.L192
.L191:
	.loc 2 134 76 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$134, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L192:
	.loc 2 134 32 is_stmt 1 discriminator 3
	movq	(%rbx), %rcx
	movl	(%rcx), %ecx
	movl	%ecx, -48(%rbp)
	movq	4(%rax), %rax
	movq	%rax, -44(%rbp)
	.loc 2 134 32 is_stmt 0 discriminator 4
	movl	%edx, -36(%rbp)
	.loc 2 135 45 is_stmt 1
	movq	8(%rbx), %rax
	movzbl	16(%rax), %eax
	testb	%al, %al
	je	.L193
	.loc 2 135 45 is_stmt 0 discriminator 1
	movq	(%rbx), %rax
	movzbl	16(%rax), %eax
	testb	%al, %al
	je	.L193
	.loc 2 135 45 discriminator 2
	movl	$1, %eax
	jmp	.L194
.L193:
	.loc 2 135 45 discriminator 3
	movl	$0, %eax
.L194:
	.loc 2 134 32 is_stmt 1 discriminator 5
	movb	%al, -32(%rbp)
	leaq	-48(%rbp), %rcx
	.loc 2 132 14 discriminator 4
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -80(%rbp)
	movq	%rdx, -72(%rbp)
	movl	16(%rcx), %eax
	movl	%eax, -64(%rbp)
	.loc 2 132 14 is_stmt 0 discriminator 5
	jmp	.L195
.L190:
	.loc 2 132 14 discriminator 6
	movl	$0, -80(%rbp)
	movl	$1, -76(%rbp)
	movl	$0, -72(%rbp)
	movl	$0, -68(%rbp)
	movb	$0, -64(%rbp)
.L195:
	.loc 2 132 14 discriminator 7
	leaq	-80(%rbp), %rsi
	.loc 2 123 7 is_stmt 1 discriminator 1
	movq	-184(%rbp), %rcx
	movq	(%rsi), %rax
	movq	8(%rsi), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movl	16(%rsi), %eax
	movl	%eax, 16(%rcx)
	.loc 2 121 4
	movq	-184(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE24:
	.size	silver_scalar_expressions__binary_result___wrapped_statements.7, .-silver_scalar_expressions__binary_result___wrapped_statements.7
	.section	.rodata
	.align 8
.LC30:
	.ascii	"failed postcondition from silver_scalar_expressions.adb:117"
	.text
	.align 2
	.globl	silver_scalar_expressions__binary_result
	.type	silver_scalar_expressions__binary_result, @function
silver_scalar_expressions__binary_result:
.LFB23:
	.loc 2 121 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	subq	$96, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	movq	%rdi, -88(%rbp)
	movq	%rsi, -96(%rbp)
	movq	%rdx, -104(%rbp)
	movb	%cl, -105(%rbp)
	.loc 2 121 4
	leaq	16(%rbp), %rax
	.loc 2 121 4 is_stmt 0 discriminator 1
	movq	%rax, -24(%rbp)
	movq	-96(%rbp), %rax
	movq	%rax, -40(%rbp)
	movq	-104(%rbp), %rax
	movq	%rax, -48(%rbp)
	movzbl	-105(%rbp), %eax
	movb	%al, -32(%rbp)
.LBB51:
	leaq	-80(%rbp), %rax
	leaq	-48(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_scalar_expressions__binary_result___wrapped_statements.7
	.loc 2 117 46 is_stmt 1
	movl	-80(%rbp), %eax
	.loc 2 117 19
	testl	%eax, %eax
	je	.L198
	.loc 2 118 44
	movl	-80(%rbp), %edx
	movq	-48(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 118 8
	cmpl	%eax, %edx
	jne	.L199
	.loc 2 119 49
	movl	-68(%rbp), %edx
	movq	-40(%rbp), %rax
	movl	12(%rax), %eax
	.loc 2 119 10
	cmpl	%eax, %edx
	jl	.L199
	.loc 2 120 49
	movl	-68(%rbp), %edx
	movq	-48(%rbp), %rax
	movl	12(%rax), %eax
	.loc 2 120 10
	cmpl	%eax, %edx
	jge	.L198
.L199:
.LBB52:
	.loc 2 117 19 discriminator 1
	leaq	.LC30(%rip), %r12
	leaq	.LC3(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L198:
.LBE52:
	.loc 2 121 4 discriminator 2
	movq	-88(%rbp), %rcx
	movq	-80(%rbp), %rax
	movq	-72(%rbp), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movl	-64(%rbp), %eax
	movl	%eax, 16(%rcx)
.LBE51:
	.loc 2 121 4 is_stmt 0
	movq	-88(%rbp), %rax
	addq	$96, %rsp
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE23:
	.size	silver_scalar_expressions__binary_result, .-silver_scalar_expressions__binary_result
	.align 2
	.type	silver_scalar_expressions__close_result___wrapped_statements.8, @function
silver_scalar_expressions__close_result___wrapped_statements.8:
.LFB26:
	.loc 2 144 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$88, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -88(%rbp)
	movq	%r10, %rbx
	movq	%r10, -96(%rbp)
	.loc 2 145 52
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	movq	(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$41, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__symbol
	.loc 2 145 52 is_stmt 0 discriminator 1
	movl	%eax, -20(%rbp)
	.loc 2 146 14 is_stmt 1
	cmpl	$0, -20(%rbp)
	je	.L202
	.loc 2 146 45 discriminator 1
	movq	8(%rbx), %rcx
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -80(%rbp)
	movq	%rdx, -72(%rbp)
	movl	16(%rcx), %eax
	movl	%eax, -64(%rbp)
	.loc 2 146 63 discriminator 1
	movl	-20(%rbp), %eax
	movl	%eax, -80(%rbp)
	.loc 2 146 14 discriminator 1
	movq	-80(%rbp), %rax
	movq	-72(%rbp), %rdx
	movq	%rax, -48(%rbp)
	movq	%rdx, -40(%rbp)
	movl	-64(%rbp), %eax
	movl	%eax, -32(%rbp)
	jmp	.L203
.L202:
	.loc 2 146 14 is_stmt 0 discriminator 2
	movl	$0, -48(%rbp)
	movl	$1, -44(%rbp)
	movl	$0, -40(%rbp)
	movl	$0, -36(%rbp)
	movb	$0, -32(%rbp)
.L203:
	.loc 2 146 14 discriminator 3
	leaq	-48(%rbp), %rsi
	.loc 2 145 7 is_stmt 1 discriminator 2
	movq	-88(%rbp), %rcx
	movq	(%rsi), %rax
	movq	8(%rsi), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movl	16(%rsi), %eax
	movl	%eax, 16(%rcx)
	.loc 2 144 4
	movq	-88(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE26:
	.size	silver_scalar_expressions__close_result___wrapped_statements.8, .-silver_scalar_expressions__close_result___wrapped_statements.8
	.section	.rodata
	.align 8
.LC31:
	.ascii	"failed precondition from silver_scalar_expressions.adb:139"
	.align 8
.LC32:
	.ascii	"failed precondition from silver_scalar_expressions.adb:140"
	.align 8
.LC33:
	.ascii	"failed postcondition from silver_scalar_expressions.adb:141"
	.text
	.align 2
	.globl	silver_scalar_expressions__close_result
	.type	silver_scalar_expressions__close_result, @function
silver_scalar_expressions__close_result:
.LFB25:
	.loc 2 144 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$120, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -120(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -144(%rbp)
	movq	%rdx, -136(%rbp)
	movq	%rcx, -128(%rbp)
	.loc 2 144 4
	leaq	16(%rbp), %rdx
	.loc 2 144 4 is_stmt 0 discriminator 1
	leaq	-144(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -80(%rbp)
	movq	-128(%rbp), %rax
	movq	%rax, -72(%rbp)
	movq	-136(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -148(%rbp)
	movq	-136(%rbp), %rax
	movl	4(%rax), %ebx
	movq	-136(%rbp), %rax
	movl	4(%rax), %edx
	movq	-136(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L206
	.loc 2 144 4 discriminator 2
	movq	-136(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-136(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movq	%rcx, %rsi
	movq	%rcx, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L207
.L206:
	.loc 2 144 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L207:
.LBB53:
	.loc 2 139 15 is_stmt 1
	cmpl	$1, -148(%rbp)
	je	.L208
.LBB54:
	.loc 2 139 15 is_stmt 0 discriminator 1
	leaq	.LC31(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L208:
.LBE54:
	.loc 2 139 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 139 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L209
	.loc 2 139 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L210
.L209:
.LBB55:
	.loc 2 139 15 discriminator 4
	leaq	.LC31(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L210:
.LBE55:
	.loc 2 140 31
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 140 44
	cmpl	$2147483647, %ebx
	jne	.L211
	.loc 2 140 44 is_stmt 0 discriminator 1
	leaq	.LC14(%rip), %rax
	movl	$140, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L211:
	.loc 2 140 44 discriminator 3
	leal	1(%rbx), %edx
	.loc 2 139 15 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L212
.LBB56:
	.loc 2 139 15 is_stmt 0 discriminator 6
	leaq	.LC32(%rip), %r8
	leaq	.LC1(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L212:
.LBE56:
.LBB57:
	.loc 2 144 4 is_stmt 1 discriminator 5
	leaq	-112(%rbp), %rax
	leaq	-80(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_scalar_expressions__close_result___wrapped_statements.8
	.loc 2 141 42
	movl	-112(%rbp), %eax
	.loc 2 141 16
	testl	%eax, %eax
	je	.L213
	.loc 2 142 45
	movq	-72(%rbp), %rax
	movl	(%rax), %edx
	movl	-112(%rbp), %eax
	.loc 2 142 10
	cmpl	%eax, %edx
	jge	.L214
	.loc 2 142 45 discriminator 1
	movl	-112(%rbp), %eax
	.loc 2 142 77 discriminator 1
	cmpl	$2147483647, %ebx
	jne	.L215
	.loc 2 142 77 is_stmt 0 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$142, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L215:
	.loc 2 142 77 discriminator 4
	leal	1(%rbx), %edx
	.loc 2 142 45 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jl	.L214
	.loc 2 143 50
	movl	-100(%rbp), %edx
	movq	-72(%rbp), %rax
	movl	12(%rax), %eax
	.loc 2 143 12
	cmpl	%eax, %edx
	je	.L213
.L214:
.LBB58:
	.loc 2 141 16 discriminator 1
	leaq	.LC33(%rip), %r12
	leaq	.LC3(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L213:
.LBE58:
	.loc 2 144 4 discriminator 6
	movq	-120(%rbp), %rcx
	movq	-112(%rbp), %rax
	movq	-104(%rbp), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movl	-96(%rbp), %eax
	movl	%eax, 16(%rcx)
.LBE57:
.LBE53:
	.loc 2 144 4 is_stmt 0
	movq	-120(%rbp), %rax
	addq	$120, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE25:
	.size	silver_scalar_expressions__close_result, .-silver_scalar_expressions__close_result
	.align 2
	.type	silver_scalar_expressions__read_atom___wrapped_statements.9, @function
silver_scalar_expressions__read_atom___wrapped_statements.9:
.LFB28:
	.loc 2 159 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$232, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, -248(%rbp)
	movq	%r10, %rbx
	movq	%r10, -256(%rbp)
	.loc 2 159 4
	movq	8(%rbx), %rax
	movq	8(%rax), %rax
	movl	(%rax), %r13d
	movq	8(%rbx), %rax
	movq	8(%rax), %rax
	movl	4(%rax), %r12d
.LBB59:
	.loc 2 163 52
	movq	8(%rbx), %rax
	movl	24(%rbx), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__skip
	.loc 2 163 52 is_stmt 0 discriminator 1
	movl	%eax, -36(%rbp)
	.loc 2 164 52 is_stmt 1
	movq	8(%rbx), %rax
	movl	-36(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__name_after
	.loc 2 164 52 is_stmt 0 discriminator 1
	movl	%eax, -40(%rbp)
	.loc 2 165 49 is_stmt 1
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movl	-40(%rbp), %edi
	movl	-36(%rbp), %ecx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__lookup
	.loc 2 165 49 is_stmt 0 discriminator 1
	movl	%eax, -44(%rbp)
	.loc 2 167 10 is_stmt 1
	cmpl	$0, -36(%rbp)
	je	.L218
	.loc 2 167 23 discriminator 1
	cmpl	-36(%rbp), %r12d
	jl	.L218
	.loc 2 168 16
	cmpl	-36(%rbp), %r13d
	jg	.L219
	.loc 2 168 16 is_stmt 0 discriminator 1
	cmpl	-36(%rbp), %r12d
	jge	.L220
.L219:
	.loc 2 168 16 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$168, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L220:
	.loc 2 168 32 is_stmt 1 discriminator 3
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movq	8(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-36(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 2 168 10 discriminator 4
	cmpb	$43, %al
	je	.L221
	.loc 2 168 38 discriminator 5
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movq	8(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-36(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 2 168 38 is_stmt 0 discriminator 6
	cmpb	$45, %al
	jne	.L222
.L221:
	.loc 2 169 13 is_stmt 1
	movzbl	28(%rbx), %eax
	testb	%al, %al
	je	.L223
	.loc 2 170 77
	movl	-36(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L224
	.loc 2 170 77 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L225
.L224:
	.loc 2 170 77 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$170, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L225:
	.loc 2 170 84 is_stmt 1 discriminator 3
	cmpl	-36(%rbp), %r13d
	jg	.L226
	.loc 2 170 84 is_stmt 0 discriminator 4
	cmpl	-36(%rbp), %r12d
	jge	.L227
.L226:
	.loc 2 170 84 discriminator 5
	leaq	.LC14(%rip), %rax
	movl	$170, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L227:
.LBB60:
	.loc 2 169 49 is_stmt 1 discriminator 1
	movq	8(%rbx), %rdx
	movq	(%rdx), %rdx
	movq	8(%rbx), %rcx
	movq	8(%rcx), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movl	-36(%rbp), %esi
	movslq	%esi, %rsi
	subq	%rcx, %rsi
	movzbl	(%rdx,%rsi), %edx
	.loc 2 169 49 is_stmt 0 discriminator 2
	cmpb	$45, %dl
	sete	%r12b
	.loc 2 170 59 is_stmt 1 discriminator 6
	movq	8(%rbx), %rdx
	movq	(%rdx), %rsi
	movq	8(%rdx), %rcx
	movl	%eax, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver_scalar_expressions__skip
	movl	%eax, %edx
	.loc 2 170 38 discriminator 7
	movq	8(%rbx), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_literals__read_integer@PLT
	movq	%rdx, %rcx
	movq	%rcx, %rdx
	.loc 2 169 49 discriminator 3
	leaq	-192(%rbp), %rdi
	movzbl	%r12b, %ecx
	movl	%eax, %esi
	movq	%rdx, %rax
	movq	%rax, %rdx
	call	silver_scalar_expressions__literal_result
.LBE60:
	.loc 2 169 49 is_stmt 0 discriminator 4
	leaq	-192(%rbp), %rcx
	.loc 2 168 10 is_stmt 1 discriminator 7
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -128(%rbp)
	movq	%rdx, -120(%rbp)
	movl	16(%rcx), %eax
	movl	%eax, -112(%rbp)
	.loc 2 168 10 is_stmt 0 discriminator 9
	jmp	.L229
.L223:
	.loc 2 168 10 discriminator 8
	movl	$0, -128(%rbp)
	movl	$1, -124(%rbp)
	movl	$0, -120(%rbp)
	movl	$0, -116(%rbp)
	movb	$0, -112(%rbp)
	.loc 2 168 10 discriminator 9
	jmp	.L229
.L222:
	.loc 2 173 37 is_stmt 1
	movq	8(%rbx), %rax
	movl	-36(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_literals__read_integer@PLT
	movl	%eax, %ecx
	movq	%rdx, %rax
	movl	%ecx, -208(%rbp)
	movq	%rax, -200(%rbp)
	.loc 2 175 32
	movl	-208(%rbp), %eax
	.loc 2 175 16
	testl	%eax, %eax
	je	.L230
	.loc 2 175 42 discriminator 1
	leaq	-240(%rbp), %rax
	movl	-208(%rbp), %esi
	movq	-200(%rbp), %rdx
	movl	$0, %ecx
	movq	%rax, %rdi
	call	silver_scalar_expressions__literal_result
	.loc 2 175 42 is_stmt 0 discriminator 2
	leaq	-240(%rbp), %rcx
	.loc 2 175 16 is_stmt 1 discriminator 2
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -96(%rbp)
	movq	%rdx, -88(%rbp)
	movl	16(%rcx), %eax
	movl	%eax, -80(%rbp)
	jmp	.L231
.L230:
	.loc 2 176 16
	cmpl	$0, -44(%rbp)
	je	.L232
	.loc 2 176 32 discriminator 1
	movl	20(%rbx), %eax
	testl	%eax, %eax
	je	.L233
	.loc 2 177 36
	movl	20(%rbx), %eax
	testl	%eax, %eax
	jle	.L234
	.loc 2 177 36 is_stmt 0 discriminator 1
	movl	20(%rbx), %eax
	cmpl	$4097, %eax
	jle	.L235
.L234:
	.loc 2 177 36 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$177, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L235:
	.loc 2 177 48 is_stmt 1 discriminator 3
	movl	16(%rbx), %eax
	testl	%eax, %eax
	jle	.L236
	.loc 2 177 48 is_stmt 0 discriminator 4
	movl	16(%rbx), %eax
	cmpl	$4097, %eax
	jle	.L237
.L236:
	.loc 2 177 48 discriminator 5
	leaq	.LC14(%rip), %rax
	movl	$177, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L237:
	.loc 2 177 60 is_stmt 1 discriminator 6
	cmpl	$0, -36(%rbp)
	jle	.L238
	.loc 2 177 60 is_stmt 0 discriminator 7
	cmpl	$4097, -36(%rbp)
	jle	.L239
.L238:
	.loc 2 177 60 discriminator 8
	leaq	.LC14(%rip), %rax
	movl	$177, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L239:
	.loc 2 177 67 is_stmt 1 discriminator 9
	cmpl	$0, -40(%rbp)
	jle	.L240
	.loc 2 177 67 is_stmt 0 discriminator 10
	cmpl	$4097, -40(%rbp)
	jle	.L241
.L240:
	.loc 2 177 67 discriminator 11
	leaq	.LC14(%rip), %rax
	movl	$177, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L241:
	.loc 2 177 18 is_stmt 1 discriminator 12
	movq	8(%rbx), %rax
	movl	20(%rbx), %edx
	movl	16(%rbx), %ecx
	movl	-40(%rbp), %r8d
	movl	-36(%rbp), %edi
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%r8d, %r9d
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__equal_name@PLT
	.loc 2 177 18 is_stmt 0 discriminator 13
	xorl	$1, %eax
	.loc 2 176 57 is_stmt 1 discriminator 2
	testb	%al, %al
	je	.L232
.L233:
	.loc 2 179 53
	cmpl	$0, -44(%rbp)
	jle	.L242
	.loc 2 179 53 is_stmt 0 discriminator 1
	cmpl	$341, -44(%rbp)
	jle	.L243
.L242:
	.loc 2 179 53 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$179, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L243:
	.loc 2 179 85 is_stmt 1 discriminator 3
	cmpl	$0, -44(%rbp)
	jle	.L244
	.loc 2 179 85 is_stmt 0 discriminator 4
	cmpl	$341, -44(%rbp)
	jle	.L245
.L244:
	.loc 2 179 85 discriminator 5
	leaq	.LC14(%rip), %rax
	movl	$179, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L245:
	.loc 2 179 21 is_stmt 1 discriminator 6
	movl	-40(%rbp), %eax
	movl	%eax, -64(%rbp)
	.loc 2 179 36 discriminator 6
	movl	-44(%rbp), %eax
	movslq	%eax, %rdx
	movq	(%rbx), %rax
	subq	$1, %rdx
	salq	$5, %rdx
	addq	%rdx, %rax
	movq	12(%rax), %rax
	movq	%rax, %rdi
	call	silver_scalars__normalize@PLT
	.loc 2 179 21 discriminator 7
	movq	%rax, -60(%rbp)
	movl	$1, -52(%rbp)
	movl	-44(%rbp), %eax
	movslq	%eax, %rdx
	movq	(%rbx), %rax
	salq	$5, %rdx
	addq	%rdx, %rax
	subq	$12, %rax
	movzbl	(%rax), %eax
	.loc 2 179 21 is_stmt 0 discriminator 8
	movb	%al, -48(%rbp)
	leaq	-64(%rbp), %rcx
	.loc 2 175 16 is_stmt 1 discriminator 3
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -96(%rbp)
	movq	%rdx, -88(%rbp)
	movl	16(%rcx), %eax
	movl	%eax, -80(%rbp)
	.loc 2 175 16 is_stmt 0 discriminator 4
	jmp	.L231
.L232:
	.loc 2 175 16 discriminator 5
	movl	$0, -96(%rbp)
	movl	$1, -92(%rbp)
	movl	$0, -88(%rbp)
	movl	$0, -84(%rbp)
	movb	$0, -80(%rbp)
.L231:
	.loc 2 175 16 discriminator 6
	leaq	-96(%rbp), %rcx
	.loc 2 168 10 is_stmt 1 discriminator 10
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -128(%rbp)
	movq	%rdx, -120(%rbp)
	movl	16(%rcx), %eax
	movl	%eax, -112(%rbp)
.L229:
	.loc 2 168 10 is_stmt 0 discriminator 11
	leaq	-128(%rbp), %rcx
	.loc 2 167 10 is_stmt 1 discriminator 2
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -160(%rbp)
	movq	%rdx, -152(%rbp)
	movl	16(%rcx), %eax
	movl	%eax, -144(%rbp)
	.loc 2 167 10 is_stmt 0 discriminator 3
	jmp	.L246
.L218:
	.loc 2 167 10 discriminator 4
	movl	$0, -160(%rbp)
	movl	$1, -156(%rbp)
	movl	$0, -152(%rbp)
	movl	$0, -148(%rbp)
	movb	$0, -144(%rbp)
.L246:
	.loc 2 167 10 discriminator 5
	leaq	-160(%rbp), %rsi
	.loc 2 163 7 is_stmt 1 discriminator 2
	movq	-248(%rbp), %rcx
	movq	(%rsi), %rax
	movq	8(%rsi), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movl	16(%rsi), %eax
	movl	%eax, 16(%rcx)
.LBE59:
	.loc 2 159 4
	movq	-248(%rbp), %rax
	addq	$232, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE28:
	.size	silver_scalar_expressions__read_atom___wrapped_statements.9, .-silver_scalar_expressions__read_atom___wrapped_statements.9
	.section	.rodata
	.align 8
.LC34:
	.ascii	"failed precondition from silver_scalar_expressions.adb:153"
	.align 8
.LC35:
	.ascii	"failed precondition from silver_scalar_expressions.adb:154"
	.align 8
.LC36:
	.ascii	"failed precondition from silver_scalar_expressions.adb:155"
	.align 8
.LC37:
	.ascii	"failed postcondition from silver_scalar_expressions.adb:156"
	.text
	.align 2
	.globl	silver_scalar_expressions__read_atom
	.type	silver_scalar_expressions__read_atom, @function
silver_scalar_expressions__read_atom:
.LFB27:
	.loc 2 159 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$192, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, -120(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -144(%rbp)
	movq	%rdx, -136(%rbp)
	movl	%ecx, -124(%rbp)
	movq	%r8, -152(%rbp)
	movl	%r9d, -128(%rbp)
	.loc 2 159 4
	leaq	16(%rbp), %rdx
	.loc 2 159 4 is_stmt 0 discriminator 1
	leaq	-144(%rbp), %rax
	movq	%rdx, -48(%rbp)
	movq	%rax, -72(%rbp)
	movl	-124(%rbp), %eax
	movl	%eax, -56(%rbp)
	movq	-152(%rbp), %rax
	movq	%rax, -80(%rbp)
	movl	-128(%rbp), %eax
	movl	%eax, -60(%rbp)
	movl	16(%rbp), %eax
	movl	%eax, -64(%rbp)
	movzbl	24(%rbp), %eax
	movb	%al, -52(%rbp)
	movq	-136(%rbp), %rax
	movl	(%rax), %r8d
	movq	-136(%rbp), %rax
	movl	4(%rax), %r12d
	movq	-136(%rbp), %rax
	movl	4(%rax), %edx
	movq	-136(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L249
	.loc 2 159 4 discriminator 2
	movq	-136(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-136(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L250
.L249:
	.loc 2 159 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L250:
.LBB61:
	.loc 2 153 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L251
.LBB62:
	.loc 2 153 15 is_stmt 0 discriminator 1
	leaq	.LC34(%rip), %rax
	movq	%rax, -224(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rbx
	movq	-216(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L251:
.LBE62:
	.loc 2 153 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 153 15 discriminator 2
	testl	%eax, %eax
	jle	.L252
	.loc 2 153 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L253
.L252:
.LBB63:
	.loc 2 153 15 discriminator 4
	leaq	.LC34(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L253:
.LBE63:
	.loc 2 154 41
	cmpl	$2147483647, %r12d
	jne	.L254
	.loc 2 154 41 is_stmt 0 discriminator 1
	leaq	.LC14(%rip), %rax
	movl	$154, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L254:
	.loc 2 154 41 discriminator 3
	leal	1(%r12), %edx
	.loc 2 153 15 is_stmt 1 discriminator 5
	movl	-56(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L255
.LBB64:
	.loc 2 153 15 is_stmt 0 discriminator 6
	leaq	.LC35(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L255:
.LBE64:
	.loc 2 154 54 is_stmt 1 discriminator 4
	movq	-80(%rbp), %rdx
	movq	-144(%rbp), %rcx
	movq	-136(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__valid_environment
	.loc 2 154 54 is_stmt 0 discriminator 5
	xorl	$1, %eax
	.loc 2 153 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L256
.LBB65:
	.loc 2 153 15 is_stmt 0 discriminator 8
	leaq	.LC35(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L256:
.LBE65:
	.loc 2 155 19 is_stmt 1
	movl	-60(%rbp), %edx
	movl	-64(%rbp), %ecx
	movq	-144(%rbp), %rsi
	movq	-136(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__valid_name_state@PLT
	.loc 2 155 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 153 15 is_stmt 1 discriminator 9
	testb	%al, %al
	je	.L257
.LBB66:
	.loc 2 153 15 is_stmt 0 discriminator 10
	leaq	.LC36(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L257:
.LBE66:
.LBB67:
	.loc 2 159 4 is_stmt 1 discriminator 5
	leaq	-112(%rbp), %rax
	leaq	-80(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_scalar_expressions__read_atom___wrapped_statements.9
	.loc 2 156 39
	movl	-112(%rbp), %eax
	.loc 2 156 16
	testl	%eax, %eax
	je	.L258
	.loc 2 157 42
	movl	-112(%rbp), %eax
	.loc 2 157 10
	movl	-56(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L259
	.loc 2 157 42 discriminator 1
	movl	-112(%rbp), %eax
	.loc 2 157 71 discriminator 1
	cmpl	$2147483647, %r12d
	jne	.L260
	.loc 2 157 71 is_stmt 0 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$157, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L260:
	.loc 2 157 71 discriminator 4
	leal	1(%r12), %edx
	.loc 2 157 42 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jl	.L259
	.loc 2 158 47
	movl	-100(%rbp), %eax
	.loc 2 158 12
	testl	%eax, %eax
	jg	.L258
.L259:
.LBB68:
	.loc 2 156 16 discriminator 1
	leaq	.LC37(%rip), %r14
	leaq	.LC3(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L258:
.LBE68:
	.loc 2 159 4 discriminator 6
	movq	-120(%rbp), %rcx
	movq	-112(%rbp), %rax
	movq	-104(%rbp), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movl	-96(%rbp), %eax
	movl	%eax, 16(%rcx)
.LBE67:
.LBE61:
	.loc 2 159 4 is_stmt 0
	movq	-120(%rbp), %rax
	addq	$192, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE27:
	.size	silver_scalar_expressions__read_atom, .-silver_scalar_expressions__read_atom
	.section	.rodata
	.align 8
.LC38:
	.ascii	"failed precondition from silver_scalar_expressions.adb:185"
	.align 8
.LC39:
	.ascii	"failed precondition from silver_scalar_expressions.adb:186"
	.align 8
.LC40:
	.ascii	"failed precondition from silver_scalar_expressions.adb:187"
	.align 8
.LC41:
	.ascii	"failed precondition from silver_scalar_expressions.adb:188"
	.align 8
.LC42:
	.ascii	"failed postcondition from silver_scalar_expressions.adb:189"
	.text
	.align 2
	.globl	silver_scalar_expressions__read_unary
	.type	silver_scalar_expressions__read_unary, @function
silver_scalar_expressions__read_unary:
.LFB29:
	.loc 2 193 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$208, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, -120(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -144(%rbp)
	movq	%rdx, -136(%rbp)
	movl	%ecx, -124(%rbp)
	movq	%r8, -152(%rbp)
	movl	%r9d, -128(%rbp)
	.loc 2 193 4
	leaq	16(%rbp), %rdx
	.loc 2 193 4 is_stmt 0 discriminator 1
	leaq	-144(%rbp), %rax
	movq	%rdx, -48(%rbp)
	movq	%rax, -72(%rbp)
	movl	-124(%rbp), %eax
	movl	%eax, -56(%rbp)
	movq	-152(%rbp), %rax
	movq	%rax, -80(%rbp)
	movl	-128(%rbp), %eax
	movl	%eax, -60(%rbp)
	movl	16(%rbp), %eax
	movl	%eax, -64(%rbp)
	movq	-136(%rbp), %rax
	movl	(%rax), %r8d
	movq	-136(%rbp), %rax
	movl	4(%rax), %r12d
	movq	-136(%rbp), %rax
	movl	4(%rax), %edx
	movq	-136(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L263
	.loc 2 193 4 discriminator 2
	movq	-136(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-136(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L264
.L263:
	.loc 2 193 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L264:
.LBB69:
	.loc 2 185 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L265
.LBB70:
	.loc 2 185 15 is_stmt 0 discriminator 1
	leaq	.LC38(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L265:
.LBE70:
	.loc 2 185 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 185 15 discriminator 2
	testl	%eax, %eax
	jle	.L266
	.loc 2 185 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L267
.L266:
.LBB71:
	.loc 2 185 15 discriminator 4
	leaq	.LC38(%rip), %rax
	movq	%rax, -240(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -232(%rbp)
	movq	-240(%rbp), %rbx
	movq	-232(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L267:
.LBE71:
	.loc 2 185 15 is_stmt 0 discriminator 5
	movl	-56(%rbp), %eax
	testl	%eax, %eax
	jle	.L268
	.loc 2 186 28 is_stmt 1
	movl	-56(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L269
.L268:
.LBB72:
	.loc 2 185 15 discriminator 6
	leaq	.LC39(%rip), %rax
	movq	%rax, -224(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rbx
	movq	-216(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L269:
.LBE72:
	.loc 2 186 55 discriminator 1
	movl	-56(%rbp), %eax
	cmpl	%eax, %r8d
	jg	.L270
	.loc 2 186 55 is_stmt 0 discriminator 2
	movl	-56(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L271
.L270:
	.loc 2 186 55 discriminator 3
	leaq	.LC14(%rip), %rax
	movl	$186, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L271:
	.loc 2 186 74 is_stmt 1 discriminator 4
	movq	-144(%rbp), %rax
	movq	-136(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-56(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 2 186 80 discriminator 4
	cmpb	$43, %al
	je	.L272
	.loc 2 186 80 is_stmt 0 discriminator 5
	movq	-144(%rbp), %rax
	movq	-136(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-56(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$45, %al
	jne	.L273
.L272:
	.loc 2 186 80 discriminator 6
	movl	$1, %eax
	jmp	.L274
.L273:
	.loc 2 186 80 discriminator 7
	movl	$0, %eax
.L274:
	.loc 2 186 80 discriminator 8
	xorl	$1, %eax
	.loc 2 185 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L275
.LBB73:
	.loc 2 185 15 is_stmt 0 discriminator 8
	leaq	.LC39(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L275:
.LBE73:
	.loc 2 187 19 is_stmt 1
	movq	-80(%rbp), %rdx
	movq	-144(%rbp), %rcx
	movq	-136(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__valid_environment
	.loc 2 187 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 185 15 is_stmt 1 discriminator 9
	testb	%al, %al
	je	.L276
.LBB74:
	.loc 2 185 15 is_stmt 0 discriminator 10
	leaq	.LC40(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L276:
.LBE74:
	.loc 2 188 19 is_stmt 1
	movl	-60(%rbp), %edx
	movl	-64(%rbp), %ecx
	movq	-144(%rbp), %rsi
	movq	-136(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__valid_name_state@PLT
	.loc 2 188 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 185 15 is_stmt 1 discriminator 11
	testb	%al, %al
	je	.L277
.LBB75:
	.loc 2 185 15 is_stmt 0 discriminator 12
	leaq	.LC41(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L277:
.LBE75:
	.loc 2 192 55 is_stmt 1
	cmpl	$2147483647, %r12d
	jne	.L278
	.loc 2 192 55 is_stmt 0 discriminator 1
	leaq	.LC14(%rip), %rax
	movl	$192, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L278:
	.loc 2 192 55 discriminator 3
	leal	1(%r12), %eax
	.loc 2 192 60 is_stmt 1 discriminator 4
	movl	-56(%rbp), %edx
	movl	$0, %ecx
	subl	%edx, %eax
	jno	.L279
	movl	$1, %ecx
.L279:
	movl	%eax, %edx
	.loc 2 192 60 is_stmt 0 discriminator 5
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L281
	.loc 2 192 60 discriminator 6
	leaq	.LC14(%rip), %rax
	movl	$192, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L281:
	.loc 2 192 60 discriminator 8
	movl	%edx, %eax
	movl	%eax, -52(%rbp)
.LBB76:
	.loc 2 193 4 is_stmt 1 discriminator 5
	leaq	-112(%rbp), %rax
	leaq	-80(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_scalar_expressions__read_unary___wrapped_statements.10
	.loc 2 189 40
	movl	-112(%rbp), %eax
	.loc 2 189 16
	testl	%eax, %eax
	je	.L282
	.loc 2 190 43
	movl	-112(%rbp), %eax
	.loc 2 190 10
	movl	-56(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L283
	.loc 2 190 43 discriminator 1
	movl	-112(%rbp), %eax
	.loc 2 190 72 discriminator 1
	cmpl	$2147483647, %r12d
	jne	.L284
	.loc 2 190 72 is_stmt 0 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$190, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L284:
	.loc 2 190 72 discriminator 4
	leal	1(%r12), %edx
	.loc 2 190 43 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jl	.L283
	.loc 2 191 48
	movl	-100(%rbp), %eax
	.loc 2 191 12
	testl	%eax, %eax
	jg	.L282
.L283:
.LBB77:
	.loc 2 189 16 discriminator 1
	leaq	.LC42(%rip), %r14
	leaq	.LC3(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L282:
.LBE77:
	.loc 2 193 4 discriminator 6
	movq	-120(%rbp), %rcx
	movq	-112(%rbp), %rax
	movq	-104(%rbp), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movl	-96(%rbp), %eax
	movl	%eax, 16(%rcx)
.LBE76:
.LBE69:
	.loc 2 193 4 is_stmt 0
	movq	-120(%rbp), %rax
	addq	$208, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE29:
	.size	silver_scalar_expressions__read_unary, .-silver_scalar_expressions__read_unary
	.align 2
	.type	silver_scalar_expressions__read_unary___wrapped_statements.10, @function
silver_scalar_expressions__read_unary___wrapped_statements.10:
.LFB31:
	.loc 2 193 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$200, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, -216(%rbp)
	movq	%r10, %rbx
	movq	%r10, -224(%rbp)
	.loc 2 193 4
	movq	8(%rbx), %rax
	movq	8(%rax), %rax
	movl	(%rax), %r13d
	movq	8(%rbx), %rax
	movq	8(%rax), %rax
	movl	4(%rax), %r12d
.LBB78:
	.loc 2 196 72
	movl	24(%rbx), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L287
	.loc 2 196 72 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L288
.L287:
	.loc 2 196 72 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$196, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L288:
	.loc 2 196 51 is_stmt 1 discriminator 3
	movq	8(%rbx), %rdx
	movq	(%rdx), %rsi
	movq	8(%rdx), %rcx
	movl	%eax, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver_scalar_expressions__skip
	.loc 2 196 51 is_stmt 0 discriminator 4
	movl	%eax, -36(%rbp)
	.loc 2 198 39 is_stmt 1
	movq	8(%rbx), %rax
	movl	-36(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_literals__read_integer@PLT
	movl	%eax, %ecx
	movq	%rdx, %rax
	movl	%ecx, -80(%rbp)
	movq	%rax, -72(%rbp)
.LBB79:
	.loc 2 200 26
	movl	-80(%rbp), %eax
	.loc 2 200 10
	testl	%eax, %eax
	je	.L289
	.loc 2 200 60 discriminator 1
	movl	24(%rbx), %eax
	cmpl	%eax, %r13d
	jg	.L290
	.loc 2 200 60 is_stmt 0 discriminator 2
	movl	24(%rbx), %eax
	cmpl	%eax, %r12d
	jge	.L291
.L290:
	.loc 2 200 60 discriminator 3
	leaq	.LC14(%rip), %rax
	movl	$200, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L291:
	.loc 2 200 36 is_stmt 1 discriminator 4
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movq	8(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	24(%rbx), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 2 200 36 is_stmt 0 discriminator 5
	cmpb	$45, %al
	sete	%dl
	leaq	-144(%rbp), %rax
	movzbl	%dl, %ecx
	movl	-80(%rbp), %esi
	movq	-72(%rbp), %rdx
	movq	%rax, %rdi
	call	silver_scalar_expressions__literal_result
	.loc 2 200 36 discriminator 6
	leaq	-144(%rbp), %rcx
	.loc 2 200 10 is_stmt 1 discriminator 6
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -64(%rbp)
	movq	%rdx, -56(%rbp)
	movl	16(%rcx), %eax
	movl	%eax, -48(%rbp)
	jmp	.L292
.L289:
	.loc 2 202 81
	movl	24(%rbx), %eax
	cmpl	%eax, %r13d
	jg	.L293
	.loc 2 202 81 is_stmt 0 discriminator 1
	movl	24(%rbx), %eax
	cmpl	%eax, %r12d
	jge	.L294
.L293:
	.loc 2 202 81 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$202, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L294:
.LBB80:
	.loc 2 201 15 is_stmt 1
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movq	8(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	24(%rbx), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 2 201 15 is_stmt 0 discriminator 1
	cmpb	$45, %al
	sete	%r12b
	.loc 2 202 13 is_stmt 1 discriminator 3
	movq	8(%rbx), %rax
	movq	(%rbx), %r8
	movl	20(%rbx), %r9d
	movl	16(%rbx), %esi
	leaq	-208(%rbp), %rdi
	movl	-36(%rbp), %ecx
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	pushq	$0
	pushq	%rsi
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_scalar_expressions__read_expression
	addq	$16, %rsp
	.loc 2 201 15 discriminator 2
	leaq	-176(%rbp), %rax
	movzbl	%r12b, %edx
	leaq	-208(%rbp), %rcx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	silver_scalar_expressions__unary_result
.LBE80:
	.loc 2 201 15 is_stmt 0 discriminator 3
	leaq	-176(%rbp), %rcx
	.loc 2 200 10 is_stmt 1 discriminator 7
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -64(%rbp)
	movq	%rdx, -56(%rbp)
	movl	16(%rcx), %eax
	movl	%eax, -48(%rbp)
.L292:
	.loc 2 199 13
	movq	8(%rbx), %rax
	leaq	-112(%rbp), %rdi
	leaq	-64(%rbp), %rcx
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_scalar_expressions__close_result
.LBE79:
	.loc 2 199 13 is_stmt 0 discriminator 1
	leaq	-112(%rbp), %rsi
	.loc 2 196 7 is_stmt 1 discriminator 5
	movq	-216(%rbp), %rcx
	movq	(%rsi), %rax
	movq	8(%rsi), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movl	16(%rsi), %eax
	movl	%eax, 16(%rcx)
.LBE78:
	.loc 2 193 4
	movq	-216(%rbp), %rax
	leaq	-24(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE31:
	.size	silver_scalar_expressions__read_unary___wrapped_statements.10, .-silver_scalar_expressions__read_unary___wrapped_statements.10
	.section	.rodata
.LC43:
	.ascii	"mod"
.LC44:
	.ascii	"rem"
	.align 8
.LC5:
	.long	1
	.long	3
	.text
	.align 2
	.type	silver_scalar_expressions__binary_after___wrapped_statements.11, @function
silver_scalar_expressions__binary_after___wrapped_statements.11:
.LFB33:
	.loc 2 210 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -72(%rbp)
	.loc 2 210 4
	movq	(%rbx), %rax
	movq	8(%rax), %rax
	movl	(%rax), %r13d
	movq	(%rbx), %rax
	movq	8(%rax), %rax
	movl	4(%rax), %r12d
.LBB81:
	.loc 2 211 52
	movq	(%rbx), %rax
	movl	8(%rbx), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__name_after
	.loc 2 211 52 is_stmt 0 discriminator 1
	movl	%eax, -52(%rbp)
	.loc 2 213 10 is_stmt 1
	movl	8(%rbx), %eax
	testl	%eax, %eax
	je	.L297
	.loc 2 213 26 discriminator 1
	movl	8(%rbx), %eax
	cmpl	%eax, %r12d
	jl	.L297
	.loc 2 214 16
	movl	8(%rbx), %eax
	cmpl	%eax, %r13d
	jg	.L298
	.loc 2 214 16 is_stmt 0 discriminator 1
	movl	8(%rbx), %eax
	cmpl	%eax, %r12d
	jge	.L299
.L298:
	.loc 2 214 16 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$214, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L299:
	.loc 2 214 35 is_stmt 1 discriminator 3
	movq	(%rbx), %rax
	movq	(%rax), %rax
	movq	(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	8(%rbx), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 2 214 10 discriminator 3
	cmpb	$43, %al
	je	.L300
	.loc 2 214 41 discriminator 4
	movq	(%rbx), %rax
	movq	(%rax), %rax
	movq	(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	8(%rbx), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$45, %al
	je	.L300
	.loc 2 214 47 discriminator 5
	movq	(%rbx), %rax
	movq	(%rax), %rax
	movq	(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	8(%rbx), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$42, %al
	jne	.L301
.L300:
	.loc 2 214 65 discriminator 6
	movl	8(%rbx), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L302
	.loc 2 214 65 is_stmt 0 discriminator 7
	cmpl	$4097, %eax
	jle	.L328
.L302:
	.loc 2 214 65 discriminator 8
	leaq	.LC14(%rip), %rax
	movl	$214, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L301:
	.loc 2 215 16 is_stmt 1
	movl	8(%rbx), %eax
	cmpl	%eax, %r13d
	jg	.L305
	.loc 2 215 16 is_stmt 0 discriminator 1
	movl	8(%rbx), %eax
	cmpl	%eax, %r12d
	jge	.L306
.L305:
	.loc 2 215 16 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$215, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L306:
	.loc 2 215 32 is_stmt 1 discriminator 3
	movq	(%rbx), %rax
	movq	(%rax), %rax
	movq	(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	8(%rbx), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 2 215 10 discriminator 3
	cmpb	$47, %al
	jne	.L307
	.loc 2 216 13
	movl	8(%rbx), %eax
	cmpl	%eax, %r12d
	jle	.L308
	.loc 2 216 61 discriminator 1
	movl	8(%rbx), %eax
	addl	$1, %eax
	.loc 2 216 46 discriminator 1
	cmpl	%eax, %r13d
	jg	.L309
	.loc 2 216 46 is_stmt 0 discriminator 2
	movl	8(%rbx), %eax
	cmpl	%eax, %r12d
	jg	.L310
.L309:
	.loc 2 216 46 discriminator 3
	leaq	.LC14(%rip), %rax
	movl	$216, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L310:
	.loc 2 216 66 is_stmt 1 discriminator 4
	movq	(%rbx), %rax
	movq	(%rax), %rax
	movq	(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 2 216 61 discriminator 4
	movl	8(%rbx), %ecx
	addl	$1, %ecx
	movslq	%ecx, %rcx
	.loc 2 216 66 discriminator 4
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$61, %al
	sete	%al
	xorl	$1, %eax
	.loc 2 216 37 discriminator 4
	testb	%al, %al
	je	.L311
.L308:
	.loc 2 216 93 discriminator 5
	movl	8(%rbx), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L312
	.loc 2 216 93 is_stmt 0 discriminator 6
	cmpl	$4097, %eax
	jle	.L329
.L312:
	.loc 2 216 93 discriminator 7
	leaq	.LC14(%rip), %rax
	movl	$216, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L311:
	.loc 2 215 10 is_stmt 1 discriminator 5
	movl	$0, %eax
	.loc 2 213 10 discriminator 2
	jmp	.L326
.L307:
	.loc 2 217 10
	cmpl	$0, -52(%rbp)
	je	.L316
	.loc 2 218 28
	movl	8(%rbx), %eax
	testl	%eax, %eax
	jle	.L317
	.loc 2 218 28 is_stmt 0 discriminator 1
	movl	8(%rbx), %eax
	cmpl	$4097, %eax
	jle	.L318
.L317:
	.loc 2 218 28 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$218, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L318:
	.loc 2 218 38 is_stmt 1 discriminator 3
	cmpl	$0, -52(%rbp)
	jle	.L319
	.loc 2 218 38 is_stmt 0 discriminator 4
	cmpl	$4097, -52(%rbp)
	jle	.L320
.L319:
	.loc 2 218 38 discriminator 5
	leaq	.LC14(%rip), %rax
	movl	$218, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L320:
	.loc 2 218 13 is_stmt 1 discriminator 6
	leaq	.LC43(%rip), %rax
	movq	%rax, -96(%rbp)
	leaq	.LC5(%rip), %rax
	movq	%rax, -88(%rbp)
	movq	(%rbx), %rax
	movl	8(%rbx), %edx
	movl	-52(%rbp), %ecx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	-96(%rbp), %r8
	movq	-88(%rbp), %r9
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__name_is@PLT
	.loc 2 217 27 discriminator 1
	testb	%al, %al
	jne	.L321
	.loc 2 218 75 discriminator 8
	movl	8(%rbx), %eax
	testl	%eax, %eax
	jle	.L322
	.loc 2 218 75 is_stmt 0 discriminator 9
	movl	8(%rbx), %eax
	cmpl	$4097, %eax
	jle	.L323
.L322:
	.loc 2 218 75 discriminator 10
	leaq	.LC14(%rip), %rax
	movl	$218, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L323:
	.loc 2 218 85 is_stmt 1 discriminator 11
	cmpl	$0, -52(%rbp)
	jle	.L324
	.loc 2 218 85 is_stmt 0 discriminator 12
	cmpl	$4097, -52(%rbp)
	jle	.L325
.L324:
	.loc 2 218 85 discriminator 13
	leaq	.LC14(%rip), %rax
	movl	$218, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L325:
	.loc 2 218 60 is_stmt 1 discriminator 14
	leaq	.LC44(%rip), %r14
	leaq	.LC5(%rip), %r15
	movq	(%rbx), %rax
	movl	8(%rbx), %edx
	movl	-52(%rbp), %ecx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%r14, %r8
	movq	%r15, %r9
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__name_is@PLT
	.loc 2 218 52 discriminator 15
	testb	%al, %al
	je	.L316
.L321:
	.loc 2 215 10 discriminator 6
	movl	-52(%rbp), %eax
	jmp	.L304
.L316:
	.loc 2 215 10 is_stmt 0 discriminator 7
	movl	$0, %eax
	.loc 2 213 10 is_stmt 1 discriminator 2
	jmp	.L326
.L328:
	.loc 2 214 10 discriminator 9
	nop
	jmp	.L326
.L329:
	.loc 2 215 10 discriminator 4
	nop
.L304:
	.loc 2 213 10 discriminator 2
	jmp	.L326
.L297:
	.loc 2 213 10 is_stmt 0 discriminator 3
	movl	$0, %eax
.L326:
.LBE81:
	.loc 2 210 4 is_stmt 1
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE33:
	.size	silver_scalar_expressions__binary_after___wrapped_statements.11, .-silver_scalar_expressions__binary_after___wrapped_statements.11
	.section	.rodata
	.align 8
.LC45:
	.ascii	"failed precondition from silver_scalar_expressions.adb:206"
	.align 8
.LC46:
	.ascii	"failed precondition from silver_scalar_expressions.adb:207"
	.align 8
.LC47:
	.ascii	"failed postcondition from silver_scalar_expressions.adb:208"
	.text
	.align 2
	.globl	silver_scalar_expressions__binary_after
	.type	silver_scalar_expressions__binary_after, @function
silver_scalar_expressions__binary_after:
.LFB32:
	.loc 2 210 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r14
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r14, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movl	%edx, -100(%rbp)
	.loc 2 210 4
	leaq	16(%rbp), %rdx
	.loc 2 210 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -80(%rbp)
	movl	-100(%rbp), %eax
	movl	%eax, -72(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %r15d
	movq	-88(%rbp), %rax
	movl	4(%rax), %r14d
	movq	-88(%rbp), %rax
	movl	4(%rax), %edx
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L331
	.loc 2 210 4 discriminator 2
	movq	-88(%rbp), %rax
	movl	4(%rax), %esi
	movslq	%esi, %rax
	cqto
	movq	-88(%rbp), %rsi
	movl	(%rsi), %edi
	movl	%edi, -104(%rbp)
	movslq	-104(%rbp), %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L332
.L331:
	.loc 2 210 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L332:
.LBB82:
	.loc 2 206 15 is_stmt 1
	cmpl	$1, %r15d
	je	.L333
.LBB83:
	.loc 2 206 15 is_stmt 0 discriminator 1
	leaq	.LC45(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L333:
.LBE83:
	.loc 2 206 51 is_stmt 1 discriminator 2
	movl	%eax, %esi
	.loc 2 206 15 discriminator 2
	testl	%esi, %esi
	jle	.L334
	.loc 2 206 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L335
.L334:
.LBB84:
	.loc 2 206 15 discriminator 4
	leaq	.LC45(%rip), %r8
	leaq	.LC1(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L335:
.LBE84:
	.loc 2 207 41
	cmpl	$2147483647, %r14d
	jne	.L336
	.loc 2 207 41 is_stmt 0 discriminator 1
	leaq	.LC14(%rip), %rax
	movl	$207, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L336:
	.loc 2 207 41 discriminator 3
	leal	1(%r14), %edx
	.loc 2 206 15 is_stmt 1 discriminator 5
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L337
.LBB85:
	.loc 2 206 15 is_stmt 0 discriminator 6
	leaq	.LC46(%rip), %rcx
	leaq	.LC1(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L337:
.LBE85:
.LBB86:
	.loc 2 210 4 is_stmt 1 discriminator 5
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_scalar_expressions__binary_after___wrapped_statements.11
	.loc 2 208 16
	testl	%eax, %eax
	je	.L341
	.loc 2 209 10
	movl	-72(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L339
	.loc 2 209 67 discriminator 1
	cmpl	$2147483647, %r14d
	jne	.L340
	.loc 2 209 67 is_stmt 0 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$209, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L340:
	.loc 2 209 67 discriminator 4
	leal	1(%r14), %edx
	.loc 2 209 38 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L341
.L339:
.LBB87:
	.loc 2 208 16 discriminator 1
	leaq	.LC47(%rip), %r12
	leaq	.LC3(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L341:
.LBE87:
.LBE86:
.LBE82:
	.loc 2 210 4
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE32:
	.size	silver_scalar_expressions__binary_after, .-silver_scalar_expressions__binary_after
	.section	.rodata
	.align 8
.LC48:
	.ascii	"failed precondition from silver_scalar_expressions.adb:226"
	.align 8
.LC49:
	.ascii	"failed precondition from silver_scalar_expressions.adb:227"
	.align 8
.LC50:
	.ascii	"failed precondition from silver_scalar_expressions.adb:228"
	.align 8
.LC51:
	.ascii	"failed precondition from silver_scalar_expressions.adb:229"
	.align 8
.LC52:
	.ascii	"failed postcondition from silver_scalar_expressions.adb:231"
	.text
	.align 2
	.globl	silver_scalar_expressions__read_compound
	.type	silver_scalar_expressions__read_compound, @function
silver_scalar_expressions__read_compound:
.LFB34:
	.loc 2 235 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$208, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, -120(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -144(%rbp)
	movq	%rdx, -136(%rbp)
	movl	%ecx, -124(%rbp)
	movq	%r8, -152(%rbp)
	movq	%r9, -160(%rbp)
	.loc 2 235 4
	leaq	16(%rbp), %rdx
	.loc 2 235 4 is_stmt 0 discriminator 1
	leaq	-144(%rbp), %rax
	movq	%rdx, -40(%rbp)
	movq	%rax, -64(%rbp)
	movq	-152(%rbp), %rax
	movq	%rax, -80(%rbp)
	movq	-160(%rbp), %rax
	movq	%rax, -72(%rbp)
	movl	16(%rbp), %eax
	movl	%eax, -52(%rbp)
	movl	24(%rbp), %eax
	movl	%eax, -56(%rbp)
	movq	-136(%rbp), %rax
	movl	(%rax), %r8d
	movq	-136(%rbp), %rax
	movl	4(%rax), %r12d
	movq	-136(%rbp), %rax
	movl	4(%rax), %edx
	movq	-136(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L343
	.loc 2 235 4 discriminator 2
	movq	-136(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-136(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L344
.L343:
	.loc 2 235 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L344:
.LBB88:
	.loc 2 226 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L345
.LBB89:
	.loc 2 226 15 is_stmt 0 discriminator 1
	leaq	.LC48(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L345:
.LBE89:
	.loc 2 226 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 226 15 discriminator 2
	testl	%eax, %eax
	jle	.L346
	.loc 2 226 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L347
.L346:
.LBB90:
	.loc 2 226 15 discriminator 4
	leaq	.LC48(%rip), %rax
	movq	%rax, -240(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -232(%rbp)
	movq	-240(%rbp), %rbx
	movq	-232(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L347:
.LBE90:
	.loc 2 227 41
	cmpl	$2147483647, %r12d
	jne	.L348
	.loc 2 227 41 is_stmt 0 discriminator 1
	leaq	.LC14(%rip), %rax
	movl	$227, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L348:
	.loc 2 227 41 discriminator 3
	leal	1(%r12), %eax
	.loc 2 226 15 is_stmt 1 discriminator 5
	cmpl	-124(%rbp), %eax
	jge	.L349
.LBB91:
	.loc 2 226 15 is_stmt 0 discriminator 6
	leaq	.LC49(%rip), %rax
	movq	%rax, -224(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rbx
	movq	-216(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L349:
.LBE91:
	.loc 2 227 54 is_stmt 1 discriminator 4
	movq	-80(%rbp), %rdx
	movq	-144(%rbp), %rcx
	movq	-136(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__valid_environment
	.loc 2 227 54 is_stmt 0 discriminator 5
	xorl	$1, %eax
	.loc 2 226 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L350
.LBB92:
	.loc 2 226 15 is_stmt 0 discriminator 8
	leaq	.LC49(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L350:
.LBE92:
	.loc 2 228 19 is_stmt 1
	movl	-52(%rbp), %edx
	movl	-56(%rbp), %ecx
	movq	-144(%rbp), %rsi
	movq	-136(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__valid_name_state@PLT
	.loc 2 228 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 226 15 is_stmt 1 discriminator 9
	testb	%al, %al
	je	.L351
.LBB93:
	.loc 2 226 15 is_stmt 0 discriminator 10
	leaq	.LC50(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L351:
.LBE93:
	.loc 2 229 31 is_stmt 1
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 226 15 discriminator 11
	testl	%eax, %eax
	je	.L352
	.loc 2 230 24
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 229 35 discriminator 1
	cmpl	%eax, -124(%rbp)
	jge	.L353
	.loc 2 230 24 discriminator 1
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 230 53 discriminator 1
	cmpl	$2147483647, %r12d
	jne	.L354
	.loc 2 230 53 is_stmt 0 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$230, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L354:
	.loc 2 230 53 discriminator 4
	leal	1(%r12), %edx
	.loc 2 230 24 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jl	.L353
	.loc 2 230 80 discriminator 6
	movq	-72(%rbp), %rax
	movl	12(%rax), %eax
	.loc 2 230 57 discriminator 6
	testl	%eax, %eax
	jg	.L352
.L353:
.LBB94:
	.loc 2 226 15 discriminator 12
	leaq	.LC51(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L352:
.LBE94:
	.loc 2 234 55
	cmpl	$2147483647, %r12d
	jne	.L355
	.loc 2 234 55 is_stmt 0 discriminator 1
	leaq	.LC14(%rip), %rax
	movl	$234, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L355:
	.loc 2 234 55 discriminator 3
	leal	1(%r12), %eax
	.loc 2 234 60 is_stmt 1 discriminator 4
	movl	$0, %edx
	subl	-124(%rbp), %eax
	jno	.L356
	movl	$1, %edx
.L356:
	movl	%eax, %ecx
	.loc 2 234 60 is_stmt 0 discriminator 5
	movl	%edx, %eax
	testl	%eax, %eax
	je	.L358
	.loc 2 234 60 discriminator 6
	leaq	.LC14(%rip), %rax
	movl	$234, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L358:
	.loc 2 234 60 discriminator 8
	movl	%ecx, %eax
	movl	%eax, -48(%rbp)
.LBB95:
	.loc 2 235 4 is_stmt 1 discriminator 5
	leaq	-112(%rbp), %rax
	leaq	-80(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_scalar_expressions__read_compound___wrapped_statements.12
	.loc 2 231 43
	movl	-112(%rbp), %eax
	.loc 2 231 16
	testl	%eax, %eax
	je	.L359
	.loc 2 232 46
	movl	-112(%rbp), %eax
	.loc 2 232 10
	cmpl	%eax, -124(%rbp)
	jge	.L360
	.loc 2 232 46 discriminator 1
	movl	-112(%rbp), %eax
	.loc 2 232 75 discriminator 1
	cmpl	$2147483647, %r12d
	jne	.L361
	.loc 2 232 75 is_stmt 0 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$232, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L361:
	.loc 2 232 75 discriminator 4
	leal	1(%r12), %edx
	.loc 2 232 46 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jl	.L360
	.loc 2 233 51
	movl	-100(%rbp), %eax
	.loc 2 233 12
	testl	%eax, %eax
	jg	.L359
.L360:
.LBB96:
	.loc 2 231 16 discriminator 1
	leaq	.LC52(%rip), %r14
	leaq	.LC3(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L359:
.LBE96:
	.loc 2 235 4 discriminator 6
	movq	-120(%rbp), %rcx
	movq	-112(%rbp), %rax
	movq	-104(%rbp), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movl	-96(%rbp), %eax
	movl	%eax, 16(%rcx)
.LBE95:
.LBE88:
	.loc 2 235 4 is_stmt 0
	movq	-120(%rbp), %rax
	addq	$208, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE34:
	.size	silver_scalar_expressions__read_compound, .-silver_scalar_expressions__read_compound
	.align 2
	.type	silver_scalar_expressions__read_compound___wrapped_statements.12, @function
silver_scalar_expressions__read_compound___wrapped_statements.12:
.LFB36:
	.loc 2 235 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$216, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, -232(%rbp)
	movq	%r10, %rbx
	movq	%r10, -240(%rbp)
	.loc 2 235 4
	movq	16(%rbx), %rax
	movq	8(%rax), %rax
	movl	(%rax), %r13d
	movq	16(%rbx), %rax
	movq	8(%rax), %rax
	movl	4(%rax), %r12d
.LBB97:
	.loc 2 239 51
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	movq	16(%rbx), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__skip
	.loc 2 239 51 is_stmt 0 discriminator 1
	movl	%eax, -36(%rbp)
	.loc 2 240 52 is_stmt 1
	movq	16(%rbx), %rax
	movl	-36(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__binary_after
	.loc 2 240 52 is_stmt 0 discriminator 1
	movl	%eax, -40(%rbp)
	.loc 2 242 10 is_stmt 1
	cmpl	$0, -36(%rbp)
	je	.L364
	.loc 2 242 22 discriminator 1
	cmpl	-36(%rbp), %r12d
	jl	.L364
	.loc 2 243 16
	cmpl	-36(%rbp), %r13d
	jg	.L365
	.loc 2 243 16 is_stmt 0 discriminator 1
	cmpl	-36(%rbp), %r12d
	jge	.L366
.L365:
	.loc 2 243 16 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$243, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L366:
	.loc 2 243 28 is_stmt 1 discriminator 3
	movq	16(%rbx), %rax
	movq	(%rax), %rax
	movq	16(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-36(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 2 243 10 discriminator 4
	cmpb	$41, %al
	jne	.L367
	.loc 2 243 39 discriminator 5
	movq	8(%rbx), %rcx
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -128(%rbp)
	movq	%rdx, -120(%rbp)
	movl	16(%rcx), %eax
	movl	%eax, -112(%rbp)
	.loc 2 243 70 discriminator 5
	movl	-36(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L368
	.loc 2 243 70 is_stmt 0 discriminator 6
	cmpl	$4097, %eax
	jle	.L369
.L368:
	.loc 2 243 70 discriminator 7
	leaq	.LC14(%rip), %rax
	movl	$243, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L369:
	.loc 2 243 56 is_stmt 1 discriminator 8
	movl	%eax, -128(%rbp)
	.loc 2 243 10 discriminator 8
	movq	-128(%rbp), %rax
	movq	-120(%rbp), %rdx
	movq	%rax, -64(%rbp)
	movq	%rdx, -56(%rbp)
	movl	-112(%rbp), %eax
	movl	%eax, -48(%rbp)
	jmp	.L370
.L367:
	.loc 2 244 10
	cmpl	$0, -40(%rbp)
	je	.L371
	.loc 2 246 99
	cmpl	-36(%rbp), %r13d
	jg	.L372
	.loc 2 246 99 is_stmt 0 discriminator 1
	cmpl	-36(%rbp), %r12d
	jge	.L373
.L372:
	.loc 2 246 99 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$246, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L373:
.LBB98:
.LBB99:
	.loc 2 245 35 is_stmt 1
	movq	16(%rbx), %rax
	movq	(%rax), %rax
	movq	16(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-36(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 2 245 35 is_stmt 0 discriminator 1
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__lowercase@PLT
	movl	%eax, %r12d
	.loc 2 246 19 is_stmt 1 discriminator 3
	movq	16(%rbx), %rax
	movq	(%rbx), %r8
	movl	28(%rbx), %r9d
	movl	24(%rbx), %esi
	leaq	-224(%rbp), %rdi
	movl	-40(%rbp), %ecx
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	pushq	$0
	pushq	%rsi
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_scalar_expressions__read_expression
	addq	$16, %rsp
	.loc 2 245 35 discriminator 3
	movq	8(%rbx), %rsi
	leaq	-192(%rbp), %rax
	movsbl	%r12b, %ecx
	leaq	-224(%rbp), %rdx
	movq	%rax, %rdi
	call	silver_scalar_expressions__binary_result
.LBE99:
	.loc 2 245 15 discriminator 4
	movq	16(%rbx), %rax
	leaq	-160(%rbp), %rdi
	leaq	-192(%rbp), %rcx
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_scalar_expressions__close_result
.LBE98:
	.loc 2 245 15 is_stmt 0 discriminator 5
	leaq	-160(%rbp), %rcx
	.loc 2 243 10 is_stmt 1 discriminator 9
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -64(%rbp)
	movq	%rdx, -56(%rbp)
	movl	16(%rcx), %eax
	movl	%eax, -48(%rbp)
	jmp	.L370
.L371:
	.loc 2 243 10 is_stmt 0 discriminator 10
	movl	$0, -64(%rbp)
	movl	$1, -60(%rbp)
	movl	$0, -56(%rbp)
	movl	$0, -52(%rbp)
	movb	$0, -48(%rbp)
.L370:
	.loc 2 243 10 discriminator 11
	leaq	-64(%rbp), %rcx
	.loc 2 242 10 is_stmt 1 discriminator 2
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -96(%rbp)
	movq	%rdx, -88(%rbp)
	movl	16(%rcx), %eax
	movl	%eax, -80(%rbp)
	.loc 2 242 10 is_stmt 0 discriminator 3
	jmp	.L374
.L364:
	.loc 2 242 10 discriminator 4
	movl	$0, -96(%rbp)
	movl	$1, -92(%rbp)
	movl	$0, -88(%rbp)
	movl	$0, -84(%rbp)
	movb	$0, -80(%rbp)
.L374:
	.loc 2 242 10 discriminator 5
	leaq	-96(%rbp), %rsi
	.loc 2 239 7 is_stmt 1 discriminator 2
	movq	-232(%rbp), %rcx
	movq	(%rsi), %rax
	movq	8(%rsi), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movl	16(%rsi), %eax
	movl	%eax, 16(%rcx)
.LBE97:
	.loc 2 235 4
	movq	-232(%rbp), %rax
	leaq	-24(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE36:
	.size	silver_scalar_expressions__read_compound___wrapped_statements.12, .-silver_scalar_expressions__read_compound___wrapped_statements.12
	.section	.rodata
	.align 8
.LC53:
	.ascii	"failed precondition from silver_scalar_expressions.adb:252"
	.align 8
.LC54:
	.ascii	"failed precondition from silver_scalar_expressions.adb:253"
	.align 8
.LC55:
	.ascii	"failed precondition from silver_scalar_expressions.adb:254"
	.align 8
.LC56:
	.ascii	"failed postcondition from silver_scalar_expressions.adb:255"
	.text
	.align 2
	.globl	silver_scalar_expressions__read_group
	.type	silver_scalar_expressions__read_group, @function
silver_scalar_expressions__read_group:
.LFB37:
	.loc 2 259 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$192, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, -120(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -144(%rbp)
	movq	%rdx, -136(%rbp)
	movl	%ecx, -124(%rbp)
	movq	%r8, -152(%rbp)
	movl	%r9d, -128(%rbp)
	.loc 2 259 4
	leaq	16(%rbp), %rdx
	.loc 2 259 4 is_stmt 0 discriminator 1
	leaq	-144(%rbp), %rax
	movq	%rdx, -48(%rbp)
	movq	%rax, -72(%rbp)
	movl	-124(%rbp), %eax
	movl	%eax, -56(%rbp)
	movq	-152(%rbp), %rax
	movq	%rax, -80(%rbp)
	movl	-128(%rbp), %eax
	movl	%eax, -60(%rbp)
	movl	16(%rbp), %eax
	movl	%eax, -64(%rbp)
	movq	-136(%rbp), %rax
	movl	(%rax), %r8d
	movq	-136(%rbp), %rax
	movl	4(%rax), %r12d
	movq	-136(%rbp), %rax
	movl	4(%rax), %edx
	movq	-136(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L377
	.loc 2 259 4 discriminator 2
	movq	-136(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-136(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L378
.L377:
	.loc 2 259 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L378:
.LBB100:
	.loc 2 252 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L379
.LBB101:
	.loc 2 252 15 is_stmt 0 discriminator 1
	leaq	.LC53(%rip), %rax
	movq	%rax, -224(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rbx
	movq	-216(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L379:
.LBE101:
	.loc 2 252 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 252 15 discriminator 2
	testl	%eax, %eax
	jle	.L380
	.loc 2 252 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L381
.L380:
.LBB102:
	.loc 2 252 15 discriminator 4
	leaq	.LC53(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L381:
.LBE102:
	.loc 2 252 15 is_stmt 0 discriminator 5
	movl	-56(%rbp), %eax
	testl	%eax, %eax
	jle	.L382
	.loc 2 253 28 is_stmt 1
	movl	-56(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L383
.L382:
.LBB103:
	.loc 2 252 15 discriminator 6
	leaq	.LC54(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L383:
.LBE103:
	.loc 2 253 55 discriminator 1
	movq	-80(%rbp), %rdx
	movq	-144(%rbp), %rcx
	movq	-136(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__valid_environment
	.loc 2 253 55 is_stmt 0 discriminator 2
	xorl	$1, %eax
	.loc 2 252 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L384
.LBB104:
	.loc 2 252 15 is_stmt 0 discriminator 8
	leaq	.LC54(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L384:
.LBE104:
	.loc 2 254 19 is_stmt 1
	movl	-60(%rbp), %edx
	movl	-64(%rbp), %ecx
	movq	-144(%rbp), %rsi
	movq	-136(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__valid_name_state@PLT
	.loc 2 254 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 252 15 is_stmt 1 discriminator 9
	testb	%al, %al
	je	.L385
.LBB105:
	.loc 2 252 15 is_stmt 0 discriminator 10
	leaq	.LC55(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L385:
.LBE105:
	.loc 2 258 55 is_stmt 1
	cmpl	$2147483647, %r12d
	jne	.L386
	.loc 2 258 55 is_stmt 0 discriminator 1
	leaq	.LC14(%rip), %rax
	movl	$258, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L386:
	.loc 2 258 55 discriminator 3
	leal	1(%r12), %eax
	.loc 2 258 60 is_stmt 1 discriminator 4
	movl	-56(%rbp), %edx
	movl	$0, %ecx
	subl	%edx, %eax
	jno	.L387
	movl	$1, %ecx
.L387:
	movl	%eax, %edx
	.loc 2 258 60 is_stmt 0 discriminator 5
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L389
	.loc 2 258 60 discriminator 6
	leaq	.LC14(%rip), %rax
	movl	$258, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L389:
	.loc 2 258 60 discriminator 8
	movl	%edx, %eax
	movl	%eax, -52(%rbp)
.LBB106:
	.loc 2 259 4 is_stmt 1 discriminator 5
	leaq	-112(%rbp), %rax
	leaq	-80(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_scalar_expressions__read_group___wrapped_statements.13
	.loc 2 255 40
	movl	-112(%rbp), %eax
	.loc 2 255 16
	testl	%eax, %eax
	je	.L390
	.loc 2 256 43
	movl	-112(%rbp), %eax
	.loc 2 256 10
	movl	-56(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L391
	.loc 2 256 43 discriminator 1
	movl	-112(%rbp), %eax
	.loc 2 256 72 discriminator 1
	cmpl	$2147483647, %r12d
	jne	.L392
	.loc 2 256 72 is_stmt 0 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$256, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L392:
	.loc 2 256 72 discriminator 4
	leal	1(%r12), %edx
	.loc 2 256 43 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jl	.L391
	.loc 2 257 48
	movl	-100(%rbp), %eax
	.loc 2 257 12
	testl	%eax, %eax
	jg	.L390
.L391:
.LBB107:
	.loc 2 255 16 discriminator 1
	leaq	.LC56(%rip), %r14
	leaq	.LC3(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L390:
.LBE107:
	.loc 2 259 4 discriminator 6
	movq	-120(%rbp), %rcx
	movq	-112(%rbp), %rax
	movq	-104(%rbp), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movl	-96(%rbp), %eax
	movl	%eax, 16(%rcx)
.LBE106:
.LBE100:
	.loc 2 259 4 is_stmt 0
	movq	-120(%rbp), %rax
	addq	$192, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE37:
	.size	silver_scalar_expressions__read_group, .-silver_scalar_expressions__read_group
	.align 2
	.type	silver_scalar_expressions__read_group___wrapped_statements.13, @function
silver_scalar_expressions__read_group___wrapped_statements.13:
.LFB39:
	.loc 2 259 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$184, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, -200(%rbp)
	movq	%r10, %rbx
	movq	%r10, -208(%rbp)
	.loc 2 259 4
	movq	8(%rbx), %rax
	movq	8(%rax), %rax
	movl	(%rax), %r13d
	movq	8(%rbx), %rax
	movq	8(%rax), %rax
	movl	4(%rax), %r12d
.LBB108:
	.loc 2 262 73
	movl	24(%rbx), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L395
	.loc 2 262 73 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L396
.L395:
	.loc 2 262 73 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$262, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L396:
	.loc 2 262 52 is_stmt 1 discriminator 3
	movq	8(%rbx), %rdx
	movq	(%rdx), %rsi
	movq	8(%rdx), %rcx
	movl	%eax, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver_scalar_expressions__skip
	.loc 2 262 52 is_stmt 0 discriminator 4
	movl	%eax, -36(%rbp)
	.loc 2 264 10 is_stmt 1
	cmpl	-36(%rbp), %r12d
	jl	.L397
	.loc 2 265 16
	cmpl	-36(%rbp), %r13d
	jg	.L398
	.loc 2 265 16 is_stmt 0 discriminator 1
	cmpl	-36(%rbp), %r12d
	jge	.L399
.L398:
	.loc 2 265 16 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$265, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L399:
	.loc 2 265 32 is_stmt 1 discriminator 3
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movq	8(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-36(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 2 265 10 discriminator 4
	cmpb	$43, %al
	je	.L400
	.loc 2 265 38 discriminator 5
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movq	8(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-36(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 2 265 38 is_stmt 0 discriminator 6
	cmpb	$45, %al
	jne	.L401
.L400:
	.loc 2 265 47 is_stmt 1 discriminator 7
	movq	8(%rbx), %rax
	movq	(%rbx), %r8
	movl	20(%rbx), %r9d
	movl	16(%rbx), %esi
	leaq	-128(%rbp), %rdi
	movl	-36(%rbp), %ecx
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	subq	$8, %rsp
	pushq	%rsi
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_scalar_expressions__read_unary
	addq	$16, %rsp
	.loc 2 265 47 is_stmt 0 discriminator 8
	leaq	-128(%rbp), %rcx
	.loc 2 265 10 is_stmt 1 discriminator 8
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -64(%rbp)
	movq	%rdx, -56(%rbp)
	movl	16(%rcx), %eax
	movl	%eax, -48(%rbp)
	.loc 2 265 10 is_stmt 0 discriminator 9
	jmp	.L402
.L401:
.LBB109:
	.loc 2 267 12 is_stmt 1
	movq	8(%rbx), %rax
	movq	(%rbx), %r8
	movl	20(%rbx), %r9d
	movl	16(%rbx), %esi
	leaq	-192(%rbp), %rdi
	movl	-36(%rbp), %ecx
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	pushq	$1
	pushq	%rsi
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_scalar_expressions__read_expression
	addq	$16, %rsp
	.loc 2 266 15
	movq	8(%rbx), %rax
	movl	24(%rbx), %ecx
	movq	(%rbx), %r10
	movl	20(%rbx), %esi
	movl	16(%rbx), %r8d
	leaq	-160(%rbp), %rdi
	leaq	-192(%rbp), %r9
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	pushq	%r8
	pushq	%rsi
	movq	%r10, %r8
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_scalar_expressions__read_compound
	addq	$16, %rsp
.LBE109:
	.loc 2 266 15 is_stmt 0 discriminator 1
	leaq	-160(%rbp), %rcx
	.loc 2 265 10 is_stmt 1 discriminator 10
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -64(%rbp)
	movq	%rdx, -56(%rbp)
	movl	16(%rcx), %eax
	movl	%eax, -48(%rbp)
.L402:
	.loc 2 265 10 is_stmt 0 discriminator 11
	leaq	-64(%rbp), %rcx
	.loc 2 264 10 is_stmt 1 discriminator 1
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -96(%rbp)
	movq	%rdx, -88(%rbp)
	movl	16(%rcx), %eax
	movl	%eax, -80(%rbp)
	jmp	.L403
.L397:
	.loc 2 264 10 is_stmt 0 discriminator 2
	movl	$0, -96(%rbp)
	movl	$1, -92(%rbp)
	movl	$0, -88(%rbp)
	movl	$0, -84(%rbp)
	movb	$0, -80(%rbp)
.L403:
	.loc 2 264 10 discriminator 3
	leaq	-96(%rbp), %rsi
	.loc 2 262 7 is_stmt 1 discriminator 5
	movq	-200(%rbp), %rcx
	movq	(%rsi), %rax
	movq	8(%rsi), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movl	16(%rsi), %eax
	movl	%eax, 16(%rcx)
.LBE108:
	.loc 2 259 4
	movq	-200(%rbp), %rax
	leaq	-24(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE39:
	.size	silver_scalar_expressions__read_group___wrapped_statements.13, .-silver_scalar_expressions__read_group___wrapped_statements.13
	.section	.rodata
	.align 8
.LC57:
	.ascii	"failed precondition from silver_scalar_expressions.ads:86"
	.align 8
.LC58:
	.ascii	"failed precondition from silver_scalar_expressions.ads:87"
	.align 8
.LC59:
	.ascii	"failed precondition from silver_scalar_expressions.ads:88"
	.align 8
.LC60:
	.ascii	"failed postcondition from silver_scalar_expressions.ads:89"
	.text
	.align 2
	.globl	silver_scalar_expressions__read_expression
	.type	silver_scalar_expressions__read_expression, @function
silver_scalar_expressions__read_expression:
.LFB40:
	.loc 2 269 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$192, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, -120(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -144(%rbp)
	movq	%rdx, -136(%rbp)
	movl	%ecx, -124(%rbp)
	movq	%r8, -152(%rbp)
	movl	%r9d, -128(%rbp)
	.loc 2 269 4
	leaq	16(%rbp), %rdx
	.loc 2 269 4 is_stmt 0 discriminator 1
	leaq	-144(%rbp), %rax
	movq	%rdx, -40(%rbp)
	movq	%rax, -72(%rbp)
	movl	-124(%rbp), %eax
	movl	%eax, -56(%rbp)
	movq	-152(%rbp), %rax
	movq	%rax, -80(%rbp)
	movl	-128(%rbp), %eax
	movl	%eax, -60(%rbp)
	movl	16(%rbp), %eax
	movl	%eax, -64(%rbp)
	movzbl	24(%rbp), %eax
	movb	%al, -48(%rbp)
	movq	-136(%rbp), %rax
	movl	(%rax), %r8d
	movq	-136(%rbp), %rax
	movl	4(%rax), %r12d
	movq	-136(%rbp), %rax
	movl	4(%rax), %edx
	movq	-136(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L406
	.loc 2 269 4 discriminator 2
	movq	-136(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-136(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L407
.L406:
	.loc 2 269 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L407:
.LBB110:
	.loc 1 86 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L408
.LBB111:
	.loc 1 86 15 is_stmt 0 discriminator 1
	leaq	.LC57(%rip), %rax
	movq	%rax, -224(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rbx
	movq	-216(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L408:
.LBE111:
	.loc 1 86 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 1 86 15 discriminator 2
	testl	%eax, %eax
	jle	.L409
	.loc 1 86 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L410
.L409:
.LBB112:
	.loc 1 86 15 discriminator 4
	leaq	.LC57(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L410:
.LBE112:
	.loc 1 87 41
	cmpl	$2147483647, %r12d
	jne	.L411
	.loc 1 87 41 is_stmt 0 discriminator 1
	leaq	.LC8(%rip), %rax
	movl	$87, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L411:
	.loc 1 87 41 discriminator 3
	leal	1(%r12), %edx
	.loc 1 86 15 is_stmt 1 discriminator 5
	movl	-56(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L412
.LBB113:
	.loc 1 86 15 is_stmt 0 discriminator 6
	leaq	.LC58(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L412:
.LBE113:
	.loc 1 87 54 is_stmt 1 discriminator 4
	movq	-80(%rbp), %rdx
	movq	-144(%rbp), %rcx
	movq	-136(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__valid_environment
	.loc 1 87 54 is_stmt 0 discriminator 5
	xorl	$1, %eax
	.loc 1 86 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L413
.LBB114:
	.loc 1 86 15 is_stmt 0 discriminator 8
	leaq	.LC58(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L413:
.LBE114:
	.loc 1 88 19 is_stmt 1
	movl	-60(%rbp), %edx
	movl	-64(%rbp), %ecx
	movq	-144(%rbp), %rsi
	movq	-136(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__valid_name_state@PLT
	.loc 1 88 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 1 86 15 is_stmt 1 discriminator 9
	testb	%al, %al
	je	.L414
.LBB115:
	.loc 1 86 15 is_stmt 0 discriminator 10
	leaq	.LC59(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L414:
.LBE115:
	.loc 1 92 55 is_stmt 1
	cmpl	$2147483647, %r12d
	jne	.L415
	.loc 1 92 55 is_stmt 0 discriminator 1
	leaq	.LC8(%rip), %rax
	movl	$92, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L415:
	.loc 1 92 55 discriminator 3
	leal	1(%r12), %eax
	.loc 1 92 60 is_stmt 1 discriminator 4
	movl	-56(%rbp), %edx
	movl	$0, %ecx
	subl	%edx, %eax
	jno	.L416
	movl	$1, %ecx
.L416:
	movl	%eax, %edx
	.loc 1 92 60 is_stmt 0 discriminator 5
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L418
	.loc 1 92 60 discriminator 6
	leaq	.LC8(%rip), %rax
	movl	$92, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L418:
	.loc 1 92 60 discriminator 8
	movl	%edx, %eax
	movl	%eax, -52(%rbp)
.LBB116:
	.loc 2 269 4 is_stmt 1 discriminator 5
	leaq	-112(%rbp), %rax
	leaq	-80(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_scalar_expressions__read_expression___wrapped_statements.14
	.loc 1 89 45
	movl	-112(%rbp), %eax
	.loc 1 89 16
	testl	%eax, %eax
	je	.L419
	.loc 1 90 48
	movl	-112(%rbp), %eax
	.loc 1 90 10
	movl	-56(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L420
	.loc 1 90 48 discriminator 1
	movl	-112(%rbp), %eax
	.loc 1 90 77 discriminator 1
	cmpl	$2147483647, %r12d
	jne	.L421
	.loc 1 90 77 is_stmt 0 discriminator 2
	leaq	.LC8(%rip), %rax
	movl	$90, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L421:
	.loc 1 90 77 discriminator 4
	leal	1(%r12), %edx
	.loc 1 90 48 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jl	.L420
	.loc 1 91 53
	movl	-100(%rbp), %eax
	.loc 1 91 12
	testl	%eax, %eax
	jg	.L419
.L420:
.LBB117:
	.loc 1 89 16 discriminator 1
	leaq	.LC60(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L419:
.LBE117:
	.loc 2 269 4 discriminator 6
	movq	-120(%rbp), %rcx
	movq	-112(%rbp), %rax
	movq	-104(%rbp), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movl	-96(%rbp), %eax
	movl	%eax, 16(%rcx)
.LBE116:
.LBE110:
	.loc 2 269 4 is_stmt 0
	movq	-120(%rbp), %rax
	addq	$192, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE40:
	.size	silver_scalar_expressions__read_expression, .-silver_scalar_expressions__read_expression
	.align 2
	.type	silver_scalar_expressions__read_expression___wrapped_statements.14, @function
silver_scalar_expressions__read_expression___wrapped_statements.14:
.LFB42:
	.loc 2 269 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$152, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, -168(%rbp)
	movq	%r10, %rbx
	movq	%r10, -176(%rbp)
	.loc 2 269 4
	movq	8(%rbx), %rax
	movq	8(%rax), %rax
	movl	(%rax), %r13d
	movq	8(%rbx), %rax
	movq	8(%rax), %rax
	movl	4(%rax), %r12d
.LBB118:
	.loc 2 273 52
	movq	8(%rbx), %rax
	movl	24(%rbx), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__skip
	.loc 2 273 52 is_stmt 0 discriminator 1
	movl	%eax, -36(%rbp)
	.loc 2 275 10 is_stmt 1
	cmpl	$0, -36(%rbp)
	je	.L424
	.loc 2 275 23 discriminator 1
	cmpl	-36(%rbp), %r12d
	jl	.L424
	.loc 2 276 16
	cmpl	-36(%rbp), %r13d
	jg	.L425
	.loc 2 276 16 is_stmt 0 discriminator 1
	cmpl	-36(%rbp), %r12d
	jge	.L426
.L425:
	.loc 2 276 16 discriminator 2
	leaq	.LC14(%rip), %rax
	movl	$276, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L426:
	.loc 2 276 29 is_stmt 1 discriminator 3
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movq	8(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	-36(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 2 276 10 discriminator 4
	cmpb	$40, %al
	jne	.L427
	.loc 2 276 55 discriminator 5
	movq	8(%rbx), %rax
	movq	(%rbx), %r8
	movl	20(%rbx), %r9d
	movl	16(%rbx), %esi
	leaq	-128(%rbp), %rdi
	movl	-36(%rbp), %ecx
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	subq	$8, %rsp
	pushq	%rsi
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_scalar_expressions__read_group
	addq	$16, %rsp
	.loc 2 276 55 is_stmt 0 discriminator 6
	leaq	-128(%rbp), %rcx
	.loc 2 276 10 is_stmt 1 discriminator 6
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -64(%rbp)
	movq	%rdx, -56(%rbp)
	movl	16(%rcx), %eax
	movl	%eax, -48(%rbp)
	jmp	.L428
.L427:
	.loc 2 277 15
	movq	8(%rbx), %rax
	movq	(%rbx), %r10
	movl	20(%rbx), %r9d
	movl	16(%rbx), %esi
	movzbl	32(%rbx), %r8d
	leaq	-160(%rbp), %rdi
	movl	-36(%rbp), %ecx
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movzbl	%r8b, %r8d
	pushq	%r8
	pushq	%rsi
	movq	%r10, %r8
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_scalar_expressions__read_atom
	addq	$16, %rsp
	.loc 2 277 15 is_stmt 0 discriminator 1
	leaq	-160(%rbp), %rcx
	.loc 2 276 10 is_stmt 1 discriminator 7
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -64(%rbp)
	movq	%rdx, -56(%rbp)
	movl	16(%rcx), %eax
	movl	%eax, -48(%rbp)
.L428:
	.loc 2 276 10 is_stmt 0 discriminator 8
	leaq	-64(%rbp), %rcx
	.loc 2 275 10 is_stmt 1 discriminator 2
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -96(%rbp)
	movq	%rdx, -88(%rbp)
	movl	16(%rcx), %eax
	movl	%eax, -80(%rbp)
	.loc 2 275 10 is_stmt 0 discriminator 3
	jmp	.L429
.L424:
	.loc 2 275 10 discriminator 4
	movl	$0, -96(%rbp)
	movl	$1, -92(%rbp)
	movl	$0, -88(%rbp)
	movl	$0, -84(%rbp)
	movb	$0, -80(%rbp)
.L429:
	.loc 2 275 10 discriminator 5
	leaq	-96(%rbp), %rsi
	.loc 2 273 7 is_stmt 1 discriminator 2
	movq	-168(%rbp), %rcx
	movq	(%rsi), %rax
	movq	8(%rsi), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movl	16(%rsi), %eax
	movl	%eax, 16(%rcx)
.LBE118:
	.loc 2 269 4
	movq	-168(%rbp), %rax
	leaq	-24(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE42:
	.size	silver_scalar_expressions__read_expression___wrapped_statements.14, .-silver_scalar_expressions__read_expression___wrapped_statements.14
	.align 2
	.globl	silver_scalar_expressions___elabs
	.type	silver_scalar_expressions___elabs, @function
silver_scalar_expressions___elabs:
.LFB1:
	.loc 1 5 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	.loc 1 27 48
	movl	$0, silver_scalar_expressions__empty_environment(%rip)
.LBB119:
	.loc 1 27 52
	movl	$1, %edx
.L433:
	.loc 1 27 52 is_stmt 0 discriminator 1
	cmpl	$341, %edx
	jg	.L434
	.loc 1 27 52 discriminator 2
	movslq	%edx, %rax
	leaq	-1(%rax), %rcx
	movq	%rcx, %rsi
	salq	$5, %rsi
	leaq	4+silver_scalar_expressions__empty_environment(%rip), %rcx
	movl	$0, (%rsi,%rcx)
	leaq	-1(%rax), %rcx
	movq	%rcx, %rsi
	salq	$5, %rsi
	leaq	8+silver_scalar_expressions__empty_environment(%rip), %rcx
	movl	$0, (%rsi,%rcx)
	leaq	-1(%rax), %rcx
	movq	%rcx, %rsi
	salq	$5, %rsi
	leaq	12+silver_scalar_expressions__empty_environment(%rip), %rcx
	movl	$1, (%rsi,%rcx)
	leaq	-1(%rax), %rcx
	movq	%rcx, %rsi
	salq	$5, %rsi
	leaq	16+silver_scalar_expressions__empty_environment(%rip), %rcx
	movl	$0, (%rsi,%rcx)
	movq	%rax, %rsi
	salq	$5, %rsi
	leaq	-12+silver_scalar_expressions__empty_environment(%rip), %rcx
	movb	$0, (%rsi,%rcx)
	movq	%rax, %rsi
	salq	$5, %rsi
	leaq	-8+silver_scalar_expressions__empty_environment(%rip), %rcx
	movl	$1, (%rsi,%rcx)
	movq	%rax, %rsi
	salq	$5, %rsi
	leaq	-4+silver_scalar_expressions__empty_environment(%rip), %rcx
	movl	$0, (%rsi,%rcx)
	salq	$5, %rax
	movq	%rax, %rcx
	leaq	silver_scalar_expressions__empty_environment(%rip), %rax
	movb	$0, (%rcx,%rax)
	addl	$1, %edx
	jmp	.L433
.L434:
.LBE119:
	.loc 1 93 5 is_stmt 1
	nop
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1:
	.size	silver_scalar_expressions___elabs, .-silver_scalar_expressions___elabs
	.globl	silver_scalar_expressions_E
	.data
	.align 2
	.type	silver_scalar_expressions_E, @object
	.size	silver_scalar_expressions_E, 2
silver_scalar_expressions_E:
	.zero	2
	.globl	silver_scalar_expressions__max_bindings
	.section	.rodata
	.align 4
	.type	silver_scalar_expressions__max_bindings, @object
	.size	silver_scalar_expressions__max_bindings, 4
silver_scalar_expressions__max_bindings:
	.long	341
	.globl	silver_scalar_expressions__max_operands
	.align 4
	.type	silver_scalar_expressions__max_operands, @object
	.size	silver_scalar_expressions__max_operands, 4
silver_scalar_expressions__max_operands:
	.long	64
	.globl	silver_scalar_expressions__empty_binding
	.align 32
	.type	silver_scalar_expressions__empty_binding, @object
	.size	silver_scalar_expressions__empty_binding, 32
silver_scalar_expressions__empty_binding:
	.long	0
	.long	0
	.long	1
	.long	0
	.byte	0
	.zero	3
	.long	1
	.long	0
	.byte	0
	.zero	3
	.globl	silver_scalar_expressions__empty_environment
	.bss
	.align 32
	.type	silver_scalar_expressions__empty_environment, @object
	.size	silver_scalar_expressions__empty_environment, 10916
silver_scalar_expressions__empty_environment:
	.zero	10916
	.globl	silver_scalar_expressions__invalid
	.section	.rodata
	.align 16
	.type	silver_scalar_expressions__invalid, @object
	.size	silver_scalar_expressions__invalid, 20
silver_scalar_expressions__invalid:
	.long	0
	.long	1
	.long	0
	.long	0
	.byte	0
	.zero	3
	.align 16
	.type	C123b.15, @object
	.size	C123b.15, 16
C123b.15:
	.byte	0
	.zero	3
	.long	1
	.long	0
	.zero	4
	.text
.Letext0:
	.file 3 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_scalars.ads"
	.file 4 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_scalar_literals.ads"
	.file 5 "<built-in>"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0xe82
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x16
	.long	.LASF92
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.long	.LLRL1
	.quad	0
	.long	.Ldebug_line0
	.uleb128 0xa
	.long	.LASF2
	.byte	0x8
	.long	0x4c
	.uleb128 0x9
	.byte	0x3
	.quad	silver_scalar_expressions__max_bindings
	.uleb128 0xe
	.sleb128 2147483647
	.long	.LASF30
	.long	0x51
	.uleb128 0x8
	.long	0x3e
	.uleb128 0xc
	.byte	0x4
	.byte	0x5
	.long	.LASF18
	.uleb128 0xa
	.long	.LASF3
	.byte	0x9
	.long	0x4c
	.uleb128 0x9
	.byte	0x3
	.quad	silver_scalar_expressions__max_operands
	.uleb128 0x2
	.long	.LASF45
	.byte	0x2
	.byte	0x4
	.byte	0x4
	.long	0x7b
	.uleb128 0x2
	.byte	0x9
	.byte	0xff
	.uleb128 0x17
	.byte	0x1
	.sleb128 0
	.long	.LASF93
	.long	0x51
	.uleb128 0x9
	.sleb128 0
	.sleb128 341
	.long	.LASF4
	.long	0x51
	.uleb128 0x9
	.sleb128 0
	.sleb128 64
	.long	.LASF5
	.long	0x51
	.uleb128 0x9
	.sleb128 0
	.sleb128 4097
	.long	.LASF6
	.long	0x51
	.uleb128 0x8
	.long	0x9e
	.uleb128 0x9
	.sleb128 -2147483648
	.sleb128 2147483647
	.long	.LASF7
	.long	0x51
	.uleb128 0xb
	.long	.LASF10
	.byte	0x8
	.byte	0x3
	.byte	0x9
	.long	0xe9
	.uleb128 0x4
	.long	.LASF8
	.byte	0x3
	.byte	0xa
	.byte	0x7
	.long	0xaf
	.byte	0
	.uleb128 0x4
	.long	.LASF9
	.byte	0x3
	.byte	0xa
	.byte	0xe
	.long	0xaf
	.byte	0x4
	.byte	0
	.uleb128 0xb
	.long	.LASF11
	.byte	0x20
	.byte	0x1
	.byte	0xd
	.long	0x144
	.uleb128 0x4
	.long	.LASF12
	.byte	0x1
	.byte	0xe
	.byte	0x7
	.long	0x9e
	.byte	0
	.uleb128 0x4
	.long	.LASF13
	.byte	0x1
	.byte	0xe
	.byte	0xe
	.long	0x9e
	.byte	0x4
	.uleb128 0x4
	.long	.LASF14
	.byte	0x1
	.byte	0xf
	.byte	0x7
	.long	0xc2
	.byte	0x8
	.uleb128 0x4
	.long	.LASF15
	.byte	0x1
	.byte	0x10
	.byte	0x7
	.long	0x149
	.byte	0x10
	.uleb128 0x4
	.long	.LASF16
	.byte	0x1
	.byte	0x11
	.byte	0x7
	.long	0xc2
	.byte	0x14
	.uleb128 0x4
	.long	.LASF17
	.byte	0x1
	.byte	0x12
	.byte	0x7
	.long	0x149
	.byte	0x1c
	.byte	0
	.uleb128 0x8
	.long	0xe9
	.uleb128 0xc
	.byte	0x1
	.byte	0x2
	.long	.LASF19
	.uleb128 0x8
	.long	0x149
	.uleb128 0x18
	.long	.LASF94
	.long	0xe9
	.long	0x16a
	.uleb128 0x19
	.long	0x51
	.sleb128 341
	.byte	0
	.uleb128 0x1a
	.long	.LASF20
	.value	0x2aa4
	.byte	0x1
	.byte	0x17
	.byte	0x9
	.long	0x193
	.uleb128 0x4
	.long	.LASF21
	.byte	0x1
	.byte	0x18
	.byte	0x7
	.long	0x86
	.byte	0
	.uleb128 0x4
	.long	.LASF22
	.byte	0x1
	.byte	0x19
	.byte	0x7
	.long	0x155
	.byte	0x4
	.byte	0
	.uleb128 0xb
	.long	.LASF23
	.byte	0x14
	.byte	0x1
	.byte	0x46
	.long	0x1d4
	.uleb128 0x4
	.long	.LASF13
	.byte	0x1
	.byte	0x47
	.byte	0x7
	.long	0x9e
	.byte	0
	.uleb128 0x4
	.long	.LASF14
	.byte	0x1
	.byte	0x48
	.byte	0x7
	.long	0xc2
	.byte	0x4
	.uleb128 0x4
	.long	.LASF24
	.byte	0x1
	.byte	0x49
	.byte	0x7
	.long	0x92
	.byte	0xc
	.uleb128 0x4
	.long	.LASF15
	.byte	0x1
	.byte	0x4a
	.byte	0x7
	.long	0x149
	.byte	0x10
	.byte	0
	.uleb128 0x8
	.long	0x193
	.uleb128 0x9
	.sleb128 0
	.sleb128 4097
	.long	.LASF25
	.long	0x51
	.uleb128 0x9
	.sleb128 0
	.sleb128 2147483648
	.long	.LASF26
	.long	0x1f4
	.uleb128 0xc
	.byte	0x8
	.byte	0x5
	.long	.LASF27
	.uleb128 0xb
	.long	.LASF28
	.byte	0x10
	.byte	0x4
	.byte	0xa
	.long	0x222
	.uleb128 0x4
	.long	.LASF13
	.byte	0x4
	.byte	0xb
	.byte	0x7
	.long	0x1d9
	.byte	0
	.uleb128 0x4
	.long	.LASF29
	.byte	0x4
	.byte	0xc
	.byte	0x7
	.long	0x1e5
	.byte	0x8
	.byte	0
	.uleb128 0x8
	.long	0x1fb
	.uleb128 0xe
	.sleb128 4097
	.long	.LASF31
	.long	0x51
	.uleb128 0xb
	.long	.LASF32
	.byte	0xc
	.byte	0x3
	.byte	0x47
	.long	0x259
	.uleb128 0x4
	.long	.LASF33
	.byte	0x3
	.byte	0x48
	.byte	0x7
	.long	0x149
	.byte	0
	.uleb128 0x4
	.long	.LASF14
	.byte	0x3
	.byte	0x49
	.byte	0x7
	.long	0xc2
	.byte	0x4
	.byte	0
	.uleb128 0xa
	.long	.LASF34
	.byte	0x14
	.long	0x144
	.uleb128 0x9
	.byte	0x3
	.quad	silver_scalar_expressions__empty_binding
	.uleb128 0xa
	.long	.LASF35
	.byte	0x1b
	.long	0x16a
	.uleb128 0x9
	.byte	0x3
	.quad	silver_scalar_expressions__empty_environment
	.uleb128 0xa
	.long	.LASF36
	.byte	0x4c
	.long	0x1d4
	.uleb128 0x9
	.byte	0x3
	.quad	silver_scalar_expressions__invalid
	.uleb128 0xf
	.long	.LASF37
	.byte	0x1
	.uleb128 0x10
	.byte	0x6
	.long	0x295
	.uleb128 0xf
	.long	.LASF38
	.byte	0x2
	.uleb128 0x10
	.byte	0x7
	.long	0x2a1
	.uleb128 0x1b
	.long	.LASF95
	.byte	0x1
	.byte	0x5
	.byte	0x1
	.quad	.LFB1
	.quad	.LFE1-.LFB1
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x11
	.long	.LASF50
	.value	0x10d
	.long	0x193
	.quad	.LFB40
	.quad	.LFE40-.LFB40
	.uleb128 0x1
	.byte	0x9c
	.long	0x3a7
	.uleb128 0x1
	.long	.LASF39
	.byte	0x1
	.byte	0x51
	.byte	0x7
	.long	0x421
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0x1
	.long	.LASF40
	.byte	0x1
	.byte	0x51
	.byte	0x16
	.long	0xaa
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x1
	.long	.LASF41
	.byte	0x1
	.byte	0x51
	.byte	0x33
	.long	0x456
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF42
	.byte	0x1
	.byte	0x52
	.byte	0x7
	.long	0xaa
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x1
	.long	.LASF43
	.byte	0x1
	.byte	0x52
	.byte	0x2b
	.long	0xaa
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x1
	.long	.LASF44
	.byte	0x1
	.byte	0x53
	.byte	0x7
	.long	0x150
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x20
	.uleb128 0x3
	.quad	.LBB110
	.quad	.LBE110-.LBB110
	.uleb128 0x5
	.long	.LASF52
	.long	0x193
	.quad	.LFB42
	.quad	.LFE42-.LFB42
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -192
	.byte	0x6
	.byte	0x23
	.uleb128 0x28
	.byte	0x6
	.uleb128 0x3
	.quad	.LBB118
	.quad	.LBE118-.LBB118
	.uleb128 0x12
	.long	.LASF12
	.value	0x111
	.long	0x9e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x1c
	.long	.LASF46
	.byte	0x10
	.byte	0x5
	.byte	0
	.long	0x3ea
	.uleb128 0x13
	.long	.LASF47
	.long	0x3bd
	.byte	0
	.uleb128 0x14
	.long	0x426
	.uleb128 0x1d
	.byte	0x8
	.byte	0x5
	.byte	0
	.long	0x3df
	.uleb128 0x15
	.string	"LB0"
	.long	0x3e
	.byte	0
	.uleb128 0x15
	.string	"UB0"
	.long	0x3e
	.byte	0x4
	.byte	0
	.uleb128 0x13
	.long	.LASF48
	.long	0x451
	.byte	0x8
	.byte	0
	.uleb128 0x7
	.long	0x3a7
	.uleb128 0x7
	.long	0x3a7
	.uleb128 0x7
	.long	0x3a7
	.uleb128 0x7
	.long	0x3a7
	.uleb128 0x7
	.long	0x3a7
	.uleb128 0x7
	.long	0x3a7
	.uleb128 0x7
	.long	0x3a7
	.uleb128 0x7
	.long	0x3a7
	.uleb128 0x7
	.long	0x3a7
	.uleb128 0x7
	.long	0x3a7
	.uleb128 0x7
	.long	0x3a7
	.uleb128 0x7
	.long	0x3a7
	.uleb128 0x1e
	.long	0x445
	.long	0x445
	.uleb128 0x1f
	.long	0x51
	.uleb128 0x6
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x94
	.byte	0x4
	.uleb128 0x8
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x23
	.uleb128 0x4
	.byte	0x94
	.byte	0x4
	.byte	0
	.uleb128 0xc
	.byte	0x1
	.byte	0x8
	.long	.LASF49
	.uleb128 0x8
	.long	0x445
	.uleb128 0x14
	.long	0x3c2
	.uleb128 0xd
	.long	0x16a
	.uleb128 0x11
	.long	.LASF51
	.value	0x103
	.long	0x193
	.quad	.LFB37
	.quad	.LFE37-.LFB37
	.uleb128 0x1
	.byte	0x9c
	.long	0x529
	.uleb128 0x1
	.long	.LASF39
	.byte	0x2
	.byte	0xf9
	.byte	0x7
	.long	0x41c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0x1
	.long	.LASF40
	.byte	0x2
	.byte	0xf9
	.byte	0x16
	.long	0xaa
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x1
	.long	.LASF41
	.byte	0x2
	.byte	0xf9
	.byte	0x33
	.long	0x456
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF42
	.byte	0x2
	.byte	0xfa
	.byte	0x7
	.long	0xaa
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x1
	.long	.LASF43
	.byte	0x2
	.byte	0xfa
	.byte	0x13
	.long	0xaa
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x3
	.quad	.LBB100
	.quad	.LBE100-.LBB100
	.uleb128 0x5
	.long	.LASF53
	.long	0x193
	.quad	.LFB39
	.quad	.LFE39-.LFB39
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -224
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x3
	.quad	.LBB108
	.quad	.LBE108-.LBB108
	.uleb128 0x12
	.long	.LASF12
	.value	0x106
	.long	0x9e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF54
	.byte	0x2
	.byte	0xeb
	.long	0x193
	.quad	.LFB34
	.quad	.LFE34-.LFB34
	.uleb128 0x1
	.byte	0x9c
	.long	0x617
	.uleb128 0x1
	.long	.LASF39
	.byte	0x2
	.byte	0xde
	.byte	0x7
	.long	0x417
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0x1
	.long	.LASF40
	.byte	0x2
	.byte	0xde
	.byte	0x16
	.long	0xaa
	.uleb128 0x3
	.byte	0x91
	.sleb128 -140
	.uleb128 0x1
	.long	.LASF41
	.byte	0x2
	.byte	0xde
	.byte	0x33
	.long	0x456
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF55
	.byte	0x2
	.byte	0xdf
	.byte	0x7
	.long	0x617
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF42
	.byte	0x2
	.byte	0xdf
	.byte	0x21
	.long	0xaa
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x1c
	.uleb128 0x1
	.long	.LASF43
	.byte	0x2
	.byte	0xdf
	.byte	0x2d
	.long	0xaa
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x3
	.quad	.LBB88
	.quad	.LBE88-.LBB88
	.uleb128 0x5
	.long	.LASF56
	.long	0x193
	.quad	.LFB36
	.quad	.LFE36-.LFB36
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -256
	.byte	0x6
	.byte	0x23
	.uleb128 0x28
	.byte	0x6
	.uleb128 0x3
	.quad	.LBB97
	.quad	.LBE97-.LBB97
	.uleb128 0x2
	.long	.LASF57
	.byte	0x2
	.byte	0xef
	.byte	0xf
	.long	0x9e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.uleb128 0x2
	.long	.LASF13
	.byte	0x2
	.byte	0xf0
	.byte	0xf
	.long	0x9e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0xd
	.long	0x193
	.uleb128 0x6
	.long	.LASF58
	.byte	0x2
	.byte	0xd2
	.long	0x9e
	.quad	.LFB32
	.quad	.LFE32-.LFB32
	.uleb128 0x1
	.byte	0x9c
	.long	0x6b8
	.uleb128 0x1
	.long	.LASF39
	.byte	0x2
	.byte	0xcc
	.byte	0x1b
	.long	0x412
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF40
	.byte	0x2
	.byte	0xcc
	.byte	0x2a
	.long	0xaa
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x3
	.quad	.LBB82
	.quad	.LBE82-.LBB82
	.uleb128 0x5
	.long	.LASF59
	.long	0x9e
	.quad	.LFB33
	.quad	.LFE33-.LFB33
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0x3
	.quad	.LBB81
	.quad	.LBE81-.LBB81
	.uleb128 0x2
	.long	.LASF13
	.byte	0x2
	.byte	0xd3
	.byte	0xf
	.long	0x9e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF60
	.byte	0x2
	.byte	0xc1
	.long	0x193
	.quad	.LFB29
	.quad	.LFE29-.LFB29
	.uleb128 0x1
	.byte	0x9c
	.long	0x797
	.uleb128 0x1
	.long	.LASF39
	.byte	0x2
	.byte	0xb6
	.byte	0x7
	.long	0x40d
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0x1
	.long	.LASF40
	.byte	0x2
	.byte	0xb6
	.byte	0x16
	.long	0xaa
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x1
	.long	.LASF41
	.byte	0x2
	.byte	0xb6
	.byte	0x33
	.long	0x456
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF42
	.byte	0x2
	.byte	0xb7
	.byte	0x7
	.long	0xaa
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x1
	.long	.LASF43
	.byte	0x2
	.byte	0xb7
	.byte	0x13
	.long	0xaa
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x3
	.quad	.LBB69
	.quad	.LBE69-.LBB69
	.uleb128 0x5
	.long	.LASF61
	.long	0x193
	.quad	.LFB31
	.quad	.LFE31-.LFB31
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -240
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x3
	.quad	.LBB78
	.quad	.LBE78-.LBB78
	.uleb128 0x2
	.long	.LASF57
	.byte	0x2
	.byte	0xc4
	.byte	0xf
	.long	0x9e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.uleb128 0x2
	.long	.LASF62
	.byte	0x2
	.byte	0xc5
	.byte	0xf
	.long	0x1fb
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF63
	.byte	0x2
	.byte	0x9f
	.long	0x193
	.quad	.LFB27
	.quad	.LFE27-.LFB27
	.uleb128 0x1
	.byte	0x9c
	.long	0x8a6
	.uleb128 0x1
	.long	.LASF39
	.byte	0x2
	.byte	0x95
	.byte	0x7
	.long	0x408
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0x1
	.long	.LASF40
	.byte	0x2
	.byte	0x95
	.byte	0x16
	.long	0xaa
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x1
	.long	.LASF41
	.byte	0x2
	.byte	0x95
	.byte	0x33
	.long	0x456
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF42
	.byte	0x2
	.byte	0x96
	.byte	0x7
	.long	0xaa
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x1
	.long	.LASF43
	.byte	0x2
	.byte	0x96
	.byte	0x13
	.long	0xaa
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x1
	.long	.LASF44
	.byte	0x2
	.byte	0x96
	.byte	0x32
	.long	0x150
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x1c
	.uleb128 0x3
	.quad	.LBB61
	.quad	.LBE61-.LBB61
	.uleb128 0x5
	.long	.LASF64
	.long	0x193
	.quad	.LFB28
	.quad	.LFE28-.LFB28
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -272
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x3
	.quad	.LBB59
	.quad	.LBE59-.LBB59
	.uleb128 0x2
	.long	.LASF12
	.byte	0x2
	.byte	0xa3
	.byte	0xf
	.long	0x9e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.uleb128 0x2
	.long	.LASF13
	.byte	0x2
	.byte	0xa4
	.byte	0xf
	.long	0x9e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x2
	.long	.LASF65
	.byte	0x2
	.byte	0xa5
	.byte	0xf
	.long	0x86
	.uleb128 0x2
	.byte	0x91
	.sleb128 -60
	.uleb128 0x2
	.long	.LASF62
	.byte	0x2
	.byte	0xac
	.byte	0x15
	.long	0x1fb
	.uleb128 0x3
	.byte	0x91
	.sleb128 -224
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF66
	.byte	0x2
	.byte	0x90
	.long	0x193
	.quad	.LFB25
	.quad	.LFE25-.LFB25
	.uleb128 0x1
	.byte	0x9c
	.long	0x92f
	.uleb128 0x1
	.long	.LASF39
	.byte	0x2
	.byte	0x89
	.byte	0x1b
	.long	0x403
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0x1
	.long	.LASF29
	.byte	0x2
	.byte	0x89
	.byte	0x2a
	.long	0x617
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x3
	.quad	.LBB53
	.quad	.LBE53-.LBB53
	.uleb128 0x5
	.long	.LASF67
	.long	0x193
	.quad	.LFB26
	.quad	.LFE26-.LFB26
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -112
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0x2
	.long	.LASF13
	.byte	0x2
	.byte	0x91
	.byte	0xf
	.long	0x9e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF68
	.byte	0x2
	.byte	0x79
	.long	0x193
	.quad	.LFB23
	.quad	.LFE23-.LFB23
	.uleb128 0x1
	.byte	0x9c
	.long	0x9b5
	.uleb128 0x1
	.long	.LASF55
	.byte	0x2
	.byte	0x74
	.byte	0x7
	.long	0x617
	.uleb128 0x4
	.byte	0x91
	.sleb128 -64
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF69
	.byte	0x2
	.byte	0x74
	.byte	0xd
	.long	0x617
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x1
	.long	.LASF70
	.byte	0x2
	.byte	0x74
	.byte	0x28
	.long	0x44c
	.uleb128 0x4
	.byte	0x91
	.sleb128 -64
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x5
	.long	.LASF71
	.long	0x193
	.quad	.LFB24
	.quad	.LFE24-.LFB24
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -208
	.byte	0x6
	.byte	0x23
	.uleb128 0x18
	.byte	0x6
	.uleb128 0x2
	.long	.LASF72
	.byte	0x2
	.byte	0x7b
	.byte	0xf
	.long	0x9b5
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.byte	0
	.byte	0
	.uleb128 0xd
	.long	0x232
	.uleb128 0x6
	.long	.LASF73
	.byte	0x2
	.byte	0x6c
	.long	0x193
	.quad	.LFB21
	.quad	.LFE21-.LFB21
	.uleb128 0x1
	.byte	0x9c
	.long	0xa30
	.uleb128 0x1
	.long	.LASF74
	.byte	0x2
	.byte	0x67
	.byte	0x1b
	.long	0x617
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x1
	.long	.LASF75
	.byte	0x2
	.byte	0x67
	.byte	0x38
	.long	0x150
	.uleb128 0x4
	.byte	0x91
	.sleb128 -64
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x5
	.long	.LASF76
	.long	0x193
	.quad	.LFB22
	.quad	.LFE22-.LFB22
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -144
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0x2
	.long	.LASF72
	.byte	0x2
	.byte	0x6e
	.byte	0xf
	.long	0x232
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF77
	.byte	0x2
	.byte	0x5e
	.long	0x193
	.quad	.LFB19
	.quad	.LFE19-.LFB19
	.uleb128 0x1
	.byte	0x9c
	.long	0xaa7
	.uleb128 0x1
	.long	.LASF62
	.byte	0x2
	.byte	0x59
	.byte	0x7
	.long	0x222
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x1
	.long	.LASF75
	.byte	0x2
	.byte	0x59
	.byte	0x37
	.long	0x150
	.uleb128 0x4
	.byte	0x91
	.sleb128 -64
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x5
	.long	.LASF78
	.long	0x193
	.quad	.LFB20
	.quad	.LFE20-.LFB20
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -96
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0x2
	.long	.LASF72
	.byte	0x2
	.byte	0x61
	.byte	0xf
	.long	0x232
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF79
	.byte	0x2
	.byte	0x4e
	.long	0x9e
	.quad	.LFB17
	.quad	.LFE17-.LFB17
	.uleb128 0x1
	.byte	0x9c
	.long	0xb3e
	.uleb128 0x1
	.long	.LASF39
	.byte	0x2
	.byte	0x46
	.byte	0x19
	.long	0x3fe
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF40
	.byte	0x2
	.byte	0x46
	.byte	0x28
	.long	0xaa
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x3
	.quad	.LBB41
	.quad	.LBE41-.LBB41
	.uleb128 0x5
	.long	.LASF80
	.long	0x9e
	.quad	.LFB18
	.quad	.LFE18-.LFB18
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -40
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0x2
	.long	.LASF57
	.byte	0x2
	.byte	0x4f
	.byte	0x7
	.long	0x227
	.uleb128 0x2
	.byte	0x91
	.sleb128 -20
	.uleb128 0x2
	.long	.LASF81
	.byte	0x2
	.byte	0x50
	.byte	0x7
	.long	0x149
	.uleb128 0x2
	.byte	0x91
	.sleb128 -21
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF82
	.byte	0x2
	.byte	0x40
	.long	0x9e
	.quad	.LFB15
	.quad	.LFE15-.LFB15
	.uleb128 0x1
	.byte	0x9c
	.long	0xbeb
	.uleb128 0x1
	.long	.LASF39
	.byte	0x2
	.byte	0x39
	.byte	0x15
	.long	0x3f9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF40
	.byte	0x2
	.byte	0x39
	.byte	0x24
	.long	0xaa
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF83
	.byte	0x2
	.byte	0x39
	.byte	0x41
	.long	0x44c
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0xc
	.uleb128 0x3
	.quad	.LBB34
	.quad	.LBE34-.LBB34
	.uleb128 0x5
	.long	.LASF84
	.long	0x9e
	.quad	.LFB16
	.quad	.LFE16-.LFB16
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -72
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0x3
	.quad	.LBB33
	.quad	.LBE33-.LBB33
	.uleb128 0x2
	.long	.LASF12
	.byte	0x2
	.byte	0x42
	.byte	0xf
	.long	0x9e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF85
	.byte	0x2
	.byte	0x30
	.long	0x9e
	.quad	.LFB13
	.quad	.LFE13-.LFB13
	.uleb128 0x1
	.byte	0x9c
	.long	0xc73
	.uleb128 0x1
	.long	.LASF39
	.byte	0x2
	.byte	0x28
	.byte	0x13
	.long	0x3f4
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF40
	.byte	0x2
	.byte	0x28
	.byte	0x22
	.long	0xaa
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x3
	.quad	.LBB27
	.quad	.LBE27-.LBB27
	.uleb128 0x5
	.long	.LASF86
	.long	0x9e
	.quad	.LFB14
	.quad	.LFE14-.LFB14
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -40
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0x2
	.long	.LASF57
	.byte	0x2
	.byte	0x31
	.byte	0x7
	.long	0x227
	.uleb128 0x2
	.byte	0x91
	.sleb128 -20
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF87
	.byte	0x2
	.byte	0x14
	.long	0x86
	.quad	.LFB11
	.quad	.LFE11-.LFB11
	.uleb128 0x1
	.byte	0x9c
	.long	0xd21
	.uleb128 0x1
	.long	.LASF39
	.byte	0x1
	.byte	0x2e
	.byte	0x7
	.long	0x3ef
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF41
	.byte	0x1
	.byte	0x2e
	.byte	0x16
	.long	0x456
	.uleb128 0x5
	.byte	0x91
	.sleb128 -80
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF12
	.byte	0x1
	.byte	0x2e
	.byte	0x2b
	.long	0xaa
	.uleb128 0x5
	.byte	0x91
	.sleb128 -80
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x1
	.long	.LASF13
	.byte	0x1
	.byte	0x2e
	.byte	0x32
	.long	0xaa
	.uleb128 0x5
	.byte	0x91
	.sleb128 -80
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x3
	.quad	.LBB19
	.quad	.LBE19-.LBB19
	.uleb128 0x5
	.long	.LASF88
	.long	0x86
	.quad	.LFB12
	.quad	.LFE12-.LFB12
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0x23
	.uleb128 0x18
	.byte	0x6
	.uleb128 0x2
	.long	.LASF65
	.byte	0x2
	.byte	0x17
	.byte	0x7
	.long	0x86
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF89
	.byte	0x2
	.byte	0x8
	.long	0x16a
	.quad	.LFB9
	.quad	.LFE9-.LFB9
	.uleb128 0x1
	.byte	0x9c
	.long	0xd99
	.uleb128 0x1
	.long	.LASF41
	.byte	0x1
	.byte	0x40
	.byte	0x1f
	.long	0x456
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x20
	.long	.LASF96
	.long	0x16a
	.quad	.LFB10
	.quad	.LFE10-.LFB10
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -10976
	.byte	0x6
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.uleb128 0x3
	.quad	.LBB13
	.quad	.LBE13-.LBB13
	.uleb128 0x21
	.string	"T4b"
	.byte	0x1
	.byte	0x43
	.byte	0x1c
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.uleb128 0x22
	.long	.LASF90
	.byte	0x1
	.byte	0x3d
	.byte	0x4
	.long	0xe9
	.quad	.LFB8
	.quad	.LFE8-.LFB8
	.uleb128 0x1
	.byte	0x9c
	.long	0xdcb
	.uleb128 0x1
	.long	.LASF83
	.byte	0x1
	.byte	0x3d
	.byte	0x1b
	.long	0xdcb
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.byte	0
	.uleb128 0xd
	.long	0xe9
	.uleb128 0x6
	.long	.LASF91
	.byte	0x1
	.byte	0x36
	.long	0x16a
	.quad	.LFB7
	.quad	.LFE7-.LFB7
	.uleb128 0x1
	.byte	0x9c
	.long	0xe14
	.uleb128 0x1
	.long	.LASF41
	.byte	0x1
	.byte	0x36
	.byte	0x15
	.long	0x456
	.uleb128 0x4
	.byte	0x91
	.sleb128 -10960
	.uleb128 0x1
	.long	.LASF83
	.byte	0x1
	.byte	0x36
	.byte	0x2a
	.long	0xdcb
	.uleb128 0x4
	.byte	0x91
	.sleb128 -10968
	.byte	0
	.uleb128 0x23
	.long	.LASF97
	.byte	0x1
	.byte	0x1f
	.byte	0x4
	.long	0x149
	.quad	.LFB5
	.quad	.LFE5-.LFB5
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x1
	.long	.LASF39
	.byte	0x1
	.byte	0x1c
	.byte	0x20
	.long	0x3ea
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x1
	.long	.LASF41
	.byte	0x1
	.byte	0x1c
	.byte	0x2f
	.long	0x456
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x3
	.quad	.LBB2
	.quad	.LBE2-.LBB2
	.uleb128 0x24
	.long	.LASF98
	.long	0x86
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x25
	.long	.LLRL0
	.uleb128 0x2
	.long	.LASF65
	.byte	0x1
	.byte	0x20
	.byte	0xf
	.long	0x51
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0xd
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x10
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x1e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 6
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0x3a
	.byte	0
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x18
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 15
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 5
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x14
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x15
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 5
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x16
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x55
	.uleb128 0x17
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x17
	.uleb128 0x21
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x18
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x19
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0x1a
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0x5
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1b
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x1c
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1d
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1e
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1f
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x18
	.uleb128 0x2f
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x20
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x21
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x22
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x23
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x24
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x25
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x55
	.uleb128 0x17
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x3c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.LFE5-.Ltext0
	.quad	.LFB7
	.quad	.Letext0-.LFB7
	.quad	0
	.quad	0
	.section	.debug_rnglists,"",@progbits
.Ldebug_ranges0:
	.long	.Ldebug_ranges3-.Ldebug_ranges2
.Ldebug_ranges2:
	.value	0x5
	.byte	0x8
	.byte	0
	.long	0
.LLRL0:
	.byte	0x5
	.quad	.LBB5
	.byte	0x4
	.uleb128 .LBB5-.LBB5
	.uleb128 .LBE5-.LBB5
	.byte	0x4
	.uleb128 .LBB7-.LBB5
	.uleb128 .LBE7-.LBB5
	.byte	0
.LLRL1:
	.byte	0x7
	.quad	.Ltext0
	.uleb128 .LFE5-.Ltext0
	.byte	0x7
	.quad	.LFB7
	.uleb128 .Letext0-.LFB7
	.byte	0
.Ldebug_ranges3:
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF20:
	.string	"silver_scalar_expressions__environment"
.LASF56:
	.string	"silver_scalar_expressions__read_compound___wrapped_statements"
.LASF47:
	.string	"P_ARRAY"
.LASF52:
	.string	"silver_scalar_expressions__read_expression___wrapped_statements"
.LASF39:
	.string	"text"
.LASF35:
	.string	"silver_scalar_expressions__empty_environment"
.LASF9:
	.string	"upper"
.LASF18:
	.string	"integer"
.LASF76:
	.string	"silver_scalar_expressions__unary_result___wrapped_statements"
.LASF63:
	.string	"silver_scalar_expressions__read_atom"
.LASF93:
	.string	"_renaming_type"
.LASF95:
	.string	"silver_scalar_expressions___elabs"
.LASF11:
	.string	"silver_scalar_expressions__binding"
.LASF10:
	.string	"silver_scalars__interval"
.LASF3:
	.string	"silver_scalar_expressions__max_operands"
.LASF96:
	.string	"silver_scalar_expressions__body_environment___wrapped_statements"
.LASF25:
	.string	"silver_scalar_literals__literal_position"
.LASF6:
	.string	"silver_output_lexical__literal_position"
.LASF97:
	.string	"silver_scalar_expressions__valid_environment"
.LASF81:
	.string	"matched"
.LASF29:
	.string	"value"
.LASF28:
	.string	"silver_scalar_literals__literal_result"
.LASF65:
	.string	"index"
.LASF60:
	.string	"silver_scalar_expressions__read_unary"
.LASF84:
	.string	"silver_scalar_expressions__symbol___wrapped_statements"
.LASF83:
	.string	"item"
.LASF85:
	.string	"silver_scalar_expressions__skip"
.LASF82:
	.string	"silver_scalar_expressions__symbol"
.LASF90:
	.string	"silver_scalar_expressions__body_binding"
.LASF77:
	.string	"silver_scalar_expressions__literal_result"
.LASF14:
	.string	"bounds"
.LASF8:
	.string	"lower"
.LASF38:
	.string	"silver_output_lexical"
.LASF80:
	.string	"silver_scalar_expressions__name_after___wrapped_statements"
.LASF54:
	.string	"silver_scalar_expressions__read_compound"
.LASF15:
	.string	"static"
.LASF43:
	.string	"mask_after"
.LASF61:
	.string	"silver_scalar_expressions__read_unary___wrapped_statements"
.LASF46:
	.string	"string"
.LASF68:
	.string	"silver_scalar_expressions__binary_result"
.LASF33:
	.string	"safe"
.LASF53:
	.string	"silver_scalar_expressions__read_group___wrapped_statements"
.LASF75:
	.string	"negative"
.LASF27:
	.string	"long_long_integer"
.LASF24:
	.string	"operands"
.LASF67:
	.string	"silver_scalar_expressions__close_result___wrapped_statements"
.LASF48:
	.string	"P_BOUNDS"
.LASF7:
	.string	"silver_scalars__value"
.LASF69:
	.string	"right"
.LASF13:
	.string	"after"
.LASF71:
	.string	"silver_scalar_expressions__binary_result___wrapped_statements"
.LASF5:
	.string	"silver_scalar_expressions__operand_count"
.LASF51:
	.string	"silver_scalar_expressions__read_group"
.LASF57:
	.string	"next"
.LASF17:
	.string	"mutable"
.LASF72:
	.string	"checked"
.LASF91:
	.string	"silver_scalar_expressions__append"
.LASF32:
	.string	"silver_scalars__check_result"
.LASF62:
	.string	"number"
.LASF16:
	.string	"declared_bounds"
.LASF88:
	.string	"silver_scalar_expressions__lookup___wrapped_statements"
.LASF98:
	.string	"R18s"
.LASF55:
	.string	"left"
.LASF92:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF70:
	.string	"operator"
.LASF73:
	.string	"silver_scalar_expressions__unary_result"
.LASF78:
	.string	"silver_scalar_expressions__literal_result___wrapped_statements"
.LASF31:
	.string	"silver_output_lexical__cursor"
.LASF94:
	.string	"silver_scalar_expressions__binding_array"
.LASF87:
	.string	"silver_scalar_expressions__lookup"
.LASF41:
	.string	"names"
.LASF26:
	.string	"silver_scalar_literals__literal_value"
.LASF30:
	.string	"positive"
.LASF36:
	.string	"silver_scalar_expressions__invalid"
.LASF4:
	.string	"silver_scalar_expressions__binding_count"
.LASF49:
	.string	"character"
.LASF89:
	.string	"silver_scalar_expressions__body_environment"
.LASF22:
	.string	"items"
.LASF2:
	.string	"silver_scalar_expressions__max_bindings"
.LASF64:
	.string	"silver_scalar_expressions__read_atom___wrapped_statements"
.LASF21:
	.string	"count"
.LASF45:
	.string	"silver_scalar_expressions__scalars___XRP_silver_scalars___XE"
.LASF66:
	.string	"silver_scalar_expressions__close_result"
.LASF74:
	.string	"operand"
.LASF42:
	.string	"mask_first"
.LASF34:
	.string	"silver_scalar_expressions__empty_binding"
.LASF79:
	.string	"silver_scalar_expressions__name_after"
.LASF37:
	.string	"silver_profile"
.LASF86:
	.string	"silver_scalar_expressions__skip___wrapped_statements"
.LASF40:
	.string	"position"
.LASF58:
	.string	"silver_scalar_expressions__binary_after"
.LASF50:
	.string	"silver_scalar_expressions__read_expression"
.LASF59:
	.string	"silver_scalar_expressions__binary_after___wrapped_statements"
.LASF23:
	.string	"silver_scalar_expressions__expression_result"
.LASF19:
	.string	"boolean"
.LASF12:
	.string	"first"
.LASF44:
	.string	"allow_sign"
	.section	.debug_line_str,"MS",@progbits,1
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_scalar_expressions.adb"
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
