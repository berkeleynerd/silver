	.file	"silver_build.ads"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_build.ads"
	.globl	silver_build_E
	.data
	.align 2
	.type	silver_build_E, @object
	.size	silver_build_E, 2
silver_build_E:
	.zero	2
	.globl	silver_build__host
	.section	.rodata
	.align 16
	.type	silver_build__host, @object
	.size	silver_build__host, 16
silver_build__host:
	.ascii	"linux-x86_64"
	.zero	4
	.globl	silver_build__artifacts_directory
	.align 32
	.type	silver_build__artifacts_directory, @object
	.size	silver_build__artifacts_directory, 54
silver_build__artifacts_directory:
	.ascii	"/home/canto/src/github.com/berkeleynerd/silver/.silver"
	.globl	silver_build__root_directory
	.align 32
	.type	silver_build__root_directory, @object
	.size	silver_build__root_directory, 67
silver_build__root_directory:
	.ascii	"/home/canto/src/github.com/berkeleynerd/silver/.silver/linux"
	.ascii	"-x86_64"
	.globl	silver_build__source_directory
	.align 32
	.type	silver_build__source_directory, @object
	.size	silver_build__source_directory, 50
silver_build__source_directory:
	.ascii	"/home/canto/src/github.com/berkeleynerd/silver/src"
	.globl	silver_build__quoted_root_directory
	.align 32
	.type	silver_build__quoted_root_directory, @object
	.size	silver_build__quoted_root_directory, 67
silver_build__quoted_root_directory:
	.ascii	"/home/canto/src/github.com/berkeleynerd/silver/.silver/linux"
	.ascii	"-x86_64"
	.globl	silver_build__image_gnatprove
	.align 32
	.type	silver_build__image_gnatprove, @object
	.size	silver_build__image_gnatprove, 93
silver_build__image_gnatprove:
	.ascii	"/home/canto/src/github.com/berkeleynerd/silver/.silver/linux"
	.ascii	"-x86_64/image-tools/bin/gnatprove"
	.globl	silver_build__alire_exec
	.align 32
	.type	silver_build__alire_exec, @object
	.size	silver_build__alire_exec, 362
silver_build__alire_exec:
	.ascii	"cd /home/canto/src/github.com/berkeleynerd/silver/.silver/li"
	.ascii	"nux-x86_64/toolchain && unset ALR_CONFIG GPR_CONFIG GPR_PROJ"
	.ascii	"ECT_PATH GPR_PROJECT_PATH_FILE ADA_PROJECT_PATH && ALIRE_SET"
	.ascii	"TINGS_DIR=/home/canto/src/github.com/berkeleynerd/silver/.to"
	.ascii	"ols/linux-x86_64/alire/settings /home/canto/src/github.com/b"
	.ascii	"erkeleynerd/silver/.tools/linux-x86_64/alr/bin/alr -n exec -"
	.ascii	"- "
	.text
.Letext0:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_build.ads"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x14c
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x6
	.long	.LASF11
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.long	.Ldebug_line0
	.uleb128 0x1
	.long	0x3a
	.long	0x2e
	.uleb128 0x2
	.long	0x33
	.sleb128 12
	.byte	0
	.uleb128 0x3
	.long	0x1e
	.uleb128 0x5
	.byte	0x4
	.byte	0x5
	.long	.LASF2
	.uleb128 0x5
	.byte	0x1
	.byte	0x8
	.long	.LASF3
	.uleb128 0x1
	.long	0x3a
	.long	0x51
	.uleb128 0x2
	.long	0x33
	.sleb128 54
	.byte	0
	.uleb128 0x3
	.long	0x41
	.uleb128 0x1
	.long	0x3a
	.long	0x67
	.uleb128 0x2
	.long	0x33
	.sleb128 67
	.byte	0
	.uleb128 0x3
	.long	0x56
	.uleb128 0x1
	.long	0x3a
	.long	0x7c
	.uleb128 0x2
	.long	0x33
	.sleb128 50
	.byte	0
	.uleb128 0x3
	.long	0x6c
	.uleb128 0x1
	.long	0x3a
	.long	0x92
	.uleb128 0x2
	.long	0x33
	.sleb128 67
	.byte	0
	.uleb128 0x3
	.long	0x81
	.uleb128 0x1
	.long	0x3a
	.long	0xa8
	.uleb128 0x2
	.long	0x33
	.sleb128 93
	.byte	0
	.uleb128 0x3
	.long	0x97
	.uleb128 0x1
	.long	0x3a
	.long	0xbe
	.uleb128 0x2
	.long	0x33
	.sleb128 362
	.byte	0
	.uleb128 0x3
	.long	0xad
	.uleb128 0x4
	.long	.LASF4
	.byte	0x3
	.long	0x2e
	.uleb128 0x9
	.byte	0x3
	.quad	silver_build__host
	.uleb128 0x4
	.long	.LASF5
	.byte	0x4
	.long	0x51
	.uleb128 0x9
	.byte	0x3
	.quad	silver_build__artifacts_directory
	.uleb128 0x4
	.long	.LASF6
	.byte	0x5
	.long	0x67
	.uleb128 0x9
	.byte	0x3
	.quad	silver_build__root_directory
	.uleb128 0x4
	.long	.LASF7
	.byte	0x6
	.long	0x7c
	.uleb128 0x9
	.byte	0x3
	.quad	silver_build__source_directory
	.uleb128 0x4
	.long	.LASF8
	.byte	0x7
	.long	0x92
	.uleb128 0x9
	.byte	0x3
	.quad	silver_build__quoted_root_directory
	.uleb128 0x4
	.long	.LASF9
	.byte	0x8
	.long	0xa8
	.uleb128 0x9
	.byte	0x3
	.quad	silver_build__image_gnatprove
	.uleb128 0x4
	.long	.LASF10
	.byte	0x9
	.long	0xbe
	.uleb128 0x9
	.byte	0x3
	.quad	silver_build__alire_exec
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x1c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	0
	.quad	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF8:
	.string	"silver_build__quoted_root_directory"
.LASF7:
	.string	"silver_build__source_directory"
.LASF4:
	.string	"silver_build__host"
.LASF10:
	.string	"silver_build__alire_exec"
.LASF11:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF3:
	.string	"character"
.LASF2:
	.string	"integer"
.LASF5:
	.string	"silver_build__artifacts_directory"
.LASF6:
	.string	"silver_build__root_directory"
.LASF9:
	.string	"silver_build__image_gnatprove"
	.section	.debug_line_str,"MS",@progbits,1
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_build.ads"
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
