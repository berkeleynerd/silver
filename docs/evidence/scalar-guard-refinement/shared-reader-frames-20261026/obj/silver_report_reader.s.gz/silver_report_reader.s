	.file	"silver_report_reader.adb"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_report_reader.adb"
	.align 2
	.type	silver_report_reader__read_report___wrapped_statements__B23b___finalizer.1, @function
silver_report_reader__read_report___wrapped_statements__B23b___finalizer.1:
.LFB4:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	silver_report_reader__read_report___wrapped_statements__B23b___finalizer.1, .-silver_report_reader__read_report___wrapped_statements__B23b___finalizer.1
	.section	.rodata
.LC3:
	.ascii	"rb"
	.align 8
.LC4:
	.ascii	"Loop_Invariant failed at silver_report_reader.adb:34"
	.align 8
.LC5:
	.ascii	"Loop_Invariant failed at silver_report_reader.adb:35"
.LC6:
	.ascii	"silver_report_reader.adb"
	.zero	1
	.align 8
.LC2:
	.long	1
	.long	2
	.align 8
.LC0:
	.long	1
	.long	52
	.text
	.align 2
	.type	silver_report_reader__read_report___wrapped_statements.0, @function
silver_report_reader__read_report___wrapped_statements.0:
.LFB3:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_report_reader.adb"
	.loc 1 11 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA3
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB0:
	subq	$840, %rsp
.LEHE0:
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -840(%rbp)
	.loc 1 11 4
	leaq	16(%rbp), %rax
	.loc 1 11 4 is_stmt 0 discriminator 1
	movq	%rax, -440(%rbp)
	.loc 1 15 7 is_stmt 1
	leaq	-432(%rbp), %rax
	leaq	silver_report_projection__initial_state(%rip), %rcx
	movl	$360, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 1 19 17
	movq	16(%rbx), %rax
	movq	8(%rax), %rax
	movl	(%rax), %edx
	movq	16(%rbx), %rax
	movq	8(%rax), %rax
	movl	4(%rax), %eax
	movl	%edx, %esi
	movl	%eax, %edi
	call	_GLOBAL__SZ1_silver_report_reader
	movq	%rax, %rdx
	.loc 1 19 17 is_stmt 0 discriminator 1
	movq	16(%rbx), %rax
	movq	(%rax), %rax
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset@PLT
	.loc 1 20 12 is_stmt 1
	movl	$0, %eax
	movl	%eax, 24(%rbx)
	.loc 1 21 16
	movl	$0, %eax
	movb	%al, 29(%rbx)
	.loc 1 22 15
	movl	$0, %eax
	movb	%al, 28(%rbx)
.LBB2:
	leaq	-464(%rbp), %rax
	movq	%rax, %rdi
.LEHB1:
	call	system__secondary_stack__ss_mark@PLT
.LBB3:
	.loc 1 30 61
	leaq	.LC3(%rip), %rax
	movq	%rax, -864(%rbp)
	leaq	.LC2(%rip), %rax
	movq	%rax, -856(%rbp)
	movq	-864(%rbp), %rax
	movq	-856(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movl	$1, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	interfaces__c__to_c__2@PLT
	.loc 1 30 15 discriminator 1
	movq	%rax, -864(%rbp)
	.loc 1 30 35 discriminator 1
	movq	8(%rbx), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movl	$1, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	interfaces__c__to_c__2@PLT
	.loc 1 30 15 discriminator 2
	movq	-864(%rbp), %rsi
	movq	%rax, %rdi
	call	fopen@PLT
.LEHE1:
	.loc 1 30 12 discriminator 3
	movq	%rax, -56(%rbp)
.LBE3:
	.loc 1 30 0 discriminator 3
	movl	$1, -864(%rbp)
.L54:
	.loc 1 30 0 is_stmt 0 discriminator 4
	leaq	-464(%rbp), %rax
	movq	%rax, %r10
.LEHB2:
	call	silver_report_reader__read_report___wrapped_statements__B23b___finalizer.1
.LEHE2:
	.loc 1 30 0 discriminator 5
	cmpl	$1, -864(%rbp)
	jne	.L4
	.loc 1 30 0 discriminator 7
	movl	$1, %eax
.L56:
	.loc 1 30 0 discriminator 8
	cmpl	$1, %eax
	jne	.L5
	.loc 1 30 0 discriminator 9
	nop
.LBE2:
	.loc 1 31 7 is_stmt 1
	cmpq	$0, -56(%rbp)
	je	.L60
.L6:
.LBB4:
	.loc 1 34 47
	movq	16(%rbx), %rax
	movq	8(%rax), %rax
	movl	4(%rax), %edx
	movq	16(%rbx), %rax
	movq	8(%rax), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L8
	.loc 1 34 47 is_stmt 0 discriminator 1
	movq	16(%rbx), %rax
	movq	8(%rax), %rax
	movl	4(%rax), %eax
	movl	%eax, %ecx
	movq	16(%rbx), %rax
	movq	8(%rax), %rax
	movl	(%rax), %eax
	movl	%eax, %edx
	movl	%ecx, %eax
	subl	%edx, %eax
	addl	$1, %eax
	movl	%eax, %edx
	jmp	.L9
.L8:
	.loc 1 34 47 discriminator 2
	movl	$0, %edx
.L9:
	.loc 1 34 38 is_stmt 1 discriminator 3
	movl	24(%rbx), %eax
	.loc 1 34 33 discriminator 3
	cmpl	%eax, %edx
	jge	.L10
.LBB5:
	.loc 1 34 33 is_stmt 0 discriminator 4
	leaq	.LC4(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
.LEHB3:
	call	system__assertions__raise_assert_failure@PLT
.L10:
.LBE5:
	.loc 1 35 33 is_stmt 1
	movzbl	28(%rbx), %eax
	testb	%al, %al
	jne	.L11
	.loc 1 35 45 discriminator 1
	movzbl	29(%rbx), %eax
	testb	%al, %al
	je	.L12
.L11:
.LBB6:
	.loc 1 35 33 discriminator 2
	leaq	.LC5(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L12:
.LBE6:
	.loc 1 42 18
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	fgetc@PLT
	.loc 1 42 18 is_stmt 0 discriminator 1
	movl	%eax, -60(%rbp)
	.loc 1 43 10 is_stmt 1
	cmpl	$-1, -60(%rbp)
	jne	.L13
	.loc 1 45 23
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	ferror@PLT
	.loc 1 45 23 is_stmt 0 discriminator 1
	movl	%eax, -64(%rbp)
	.loc 1 46 35 is_stmt 1
	cmpl	$0, -64(%rbp)
	jne	.L14
	.loc 1 46 68 discriminator 1
	leaq	-432(%rbp), %rax
	movq	%rax, %rdi
	call	silver_report_projection__complete@PLT
	.loc 1 46 35 discriminator 2
	testb	%al, %al
	je	.L14
	.loc 1 46 35 is_stmt 0 discriminator 3
	movl	$1, %eax
	jmp	.L15
.L14:
	.loc 1 46 35 discriminator 4
	movl	$0, %eax
.L15:
	.loc 1 46 21 is_stmt 1 discriminator 5
	movb	%al, 28(%rbx)
	.loc 1 47 13
	jmp	.L16
.L13:
	.loc 1 48 10
	cmpl	$0, -60(%rbp)
	js	.L61
	.loc 1 48 21 discriminator 1
	cmpl	$255, -60(%rbp)
	jg	.L61
.LBB7:
	.loc 1 53 73
	cmpl	$0, -60(%rbp)
	js	.L19
	.loc 1 53 73 is_stmt 0 discriminator 1
	cmpl	$255, -60(%rbp)
	jle	.L20
.L19:
	.loc 1 53 73 discriminator 2
	leaq	.LC6(%rip), %rax
	movl	$53, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L20:
	.loc 1 53 39 is_stmt 1 discriminator 3
	movl	-60(%rbp), %eax
	movl	%eax, %edx
	leaq	-832(%rbp), %rax
	movsbl	%dl, %edx
	leaq	-432(%rbp), %rcx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	silver_report_projection__advance@PLT
	.loc 1 61 21
	leaq	-432(%rbp), %rax
	leaq	-832(%rbp), %rcx
	movl	$360, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 1 63 13
	movzbl	-76(%rbp), %eax
	testb	%al, %al
	jne	.L62
	.loc 1 64 28
	movl	-468(%rbp), %eax
	.loc 1 64 36
	movq	16(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	4(%rdx), %ecx
	movq	16(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	.loc 1 64 44
	cmpl	%edx, %ecx
	jl	.L23
	.loc 1 64 44 is_stmt 0 discriminator 1
	movq	16(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	4(%rdx), %edx
	movl	%edx, %esi
	movq	16(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movl	%edx, %ecx
	subl	%ecx, %esi
	movl	%esi, %edx
	addl	$1, %edx
	movl	%edx, %ecx
	jmp	.L24
.L23:
	.loc 1 64 44 discriminator 2
	movl	$0, %ecx
.L24:
	.loc 1 64 44 discriminator 3
	movl	24(%rbx), %edx
	movl	$0, %esi
	subl	%edx, %ecx
	jno	.L25
	movl	$1, %esi
.L25:
	.loc 1 64 44 discriminator 4
	movl	%esi, %edx
	testl	%edx, %edx
	je	.L27
	.loc 1 64 44 discriminator 5
	leaq	.LC6(%rip), %rax
	movl	$64, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L27:
	.loc 1 64 44 discriminator 7
	movl	%ecx, %edx
	.loc 1 64 13 is_stmt 1 discriminator 8
	cmpl	%eax, %edx
	jge	.L28
	.loc 1 65 25
	movl	$1, %eax
	movb	%al, 29(%rbx)
	.loc 1 66 16
	jmp	.L16
.L28:
	.loc 1 68 26
	movl	24(%rbx), %eax
	cmpl	$2147483647, %eax
	jne	.L29
	.loc 1 68 26 is_stmt 0 discriminator 1
	leaq	.LC6(%rip), %rax
	movl	$68, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L29:
	.loc 1 68 26 discriminator 3
	movl	24(%rbx), %eax
	addl	$1, %eax
	.loc 1 68 38 is_stmt 1 discriminator 4
	movl	24(%rbx), %ecx
	movl	-468(%rbp), %edx
	movl	$0, %esi
	addl	%ecx, %edx
	jno	.L30
	movl	$1, %esi
.L30:
	movl	%edx, %ecx
	.loc 1 68 38 is_stmt 0 discriminator 5
	movl	%esi, %edx
	testl	%edx, %edx
	je	.L32
	.loc 1 68 38 discriminator 6
	leaq	.LC6(%rip), %rax
	movl	$68, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L32:
	.loc 1 68 38 discriminator 8
	movl	%ecx, %edx
	.loc 1 68 30 is_stmt 1 discriminator 9
	cmpl	%eax, %edx
	jl	.L33
	.loc 1 68 30 is_stmt 0 discriminator 10
	movq	16(%rbx), %rcx
	movq	8(%rcx), %rcx
	movl	(%rcx), %ecx
	cmpl	%ecx, %eax
	jl	.L34
	.loc 1 68 30 discriminator 11
	movq	16(%rbx), %rcx
	movq	8(%rcx), %rcx
	movl	4(%rcx), %ecx
	cmpl	%ecx, %edx
	jle	.L33
.L34:
	.loc 1 68 30 discriminator 12
	leaq	.LC6(%rip), %rax
	movl	$68, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L33:
	.loc 1 68 13 is_stmt 1 discriminator 13
	cmpl	%eax, %edx
	.loc 1 68 13 is_stmt 0 discriminator 16
	cmpl	%eax, %edx
	.loc 1 68 13 discriminator 19
	cmpl	%eax, %edx
	.loc 1 68 70 is_stmt 1 discriminator 22
	movl	-468(%rbp), %ecx
	testl	%ecx, %ecx
	jle	.L41
	.loc 1 68 70 is_stmt 0 discriminator 23
	movl	-468(%rbp), %ecx
	cmpl	$2, %ecx
	jle	.L41
	.loc 1 68 70 discriminator 24
	leaq	.LC6(%rip), %rax
	movl	$68, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L41:
	.loc 1 68 60 is_stmt 1 discriminator 25
	cmpl	%eax, %edx
	jl	.L42
	.loc 1 68 60 is_stmt 0 discriminator 26
	movl	%edx, %ecx
	movl	%eax, %esi
	subl	%esi, %ecx
	addl	$1, %ecx
	movl	%ecx, %esi
	jmp	.L43
.L42:
	.loc 1 68 60 discriminator 27
	movl	$0, %esi
.L43:
	.loc 1 68 60 discriminator 28
	movl	-468(%rbp), %ecx
	movl	$0, %edi
	testl	%ecx, %ecx
	cmovs	%edi, %ecx
	cmpl	%ecx, %esi
	je	.L44
	.loc 1 68 60 discriminator 29
	leaq	.LC6(%rip), %rax
	movl	$68, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Length_Check@PLT
.L44:
	.loc 1 68 53 is_stmt 1 discriminator 30
	cmpl	%eax, %edx
	jl	.L45
	.loc 1 68 53 is_stmt 0 discriminator 31
	movslq	%edx, %rcx
	movslq	%eax, %rdx
	subq	%rdx, %rcx
	leaq	1(%rcx), %rdx
	jmp	.L46
.L45:
	.loc 1 68 53 discriminator 32
	movl	$0, %edx
.L46:
	.loc 1 68 53 discriminator 33
	movq	16(%rbx), %rcx
	movq	(%rcx), %rcx
	movslq	%eax, %rsi
	movq	(%rbx), %rax
	subq	%rax, %rsi
	leaq	(%rcx,%rsi), %rax
	leaq	-832(%rbp), %rcx
	addq	$360, %rcx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memmove@PLT
	.loc 1 71 26 is_stmt 1
	movl	24(%rbx), %edx
	movl	-468(%rbp), %eax
	movl	$0, %ecx
	addl	%edx, %eax
	jno	.L47
	movl	$1, %ecx
.L47:
	movl	%eax, %edx
	.loc 1 71 26 is_stmt 0 discriminator 1
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L49
	.loc 1 71 26 discriminator 2
	leaq	.LC6(%rip), %rax
	movl	$71, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L49:
	.loc 1 71 26 discriminator 4
	movl	%edx, %eax
	.loc 1 71 18 is_stmt 1 discriminator 5
	movl	%eax, 24(%rbx)
.LBE7:
.LBE4:
	.loc 1 74 15
	jmp	.L6
.L61:
.LBB9:
	.loc 1 49 13
	nop
	jmp	.L16
.L62:
.LBB8:
	.loc 1 63 36 discriminator 1
	nop
.L16:
.LBE8:
.LBE9:
	.loc 1 75 17
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	fclose@PLT
	.loc 1 75 17 is_stmt 0 discriminator 1
	movl	%eax, -64(%rbp)
	.loc 1 77 26 is_stmt 1
	movzbl	28(%rbx), %eax
	testb	%al, %al
	je	.L50
	.loc 1 77 26 is_stmt 0 discriminator 1
	cmpl	$0, -64(%rbp)
	jne	.L50
	.loc 1 77 26 discriminator 2
	movl	$1, %eax
	jmp	.L51
.L50:
	.loc 1 77 26 discriminator 3
	movl	$0, %eax
.L51:
	.loc 1 77 15 is_stmt 1 discriminator 4
	movb	%al, 28(%rbx)
	.loc 1 78 8
	jmp	.L59
.L57:
	movq	%rax, -872(%rbp)
	movl	$0, -864(%rbp)
.LBB10:
	.loc 1 30 12 discriminator 10
	jmp	.L54
.L4:
	movq	-872(%rbp), %rax
	movq	%rax, -848(%rbp)
	jmp	.L55
.L58:
	movq	%rax, -848(%rbp)
.L55:
	movl	$0, %eax
	jmp	.L56
.L5:
	movq	-848(%rbp), %rax
	movq	%rax, %rdi
	call	_Unwind_Resume@PLT
.L60:
.LBE10:
	.loc 1 31 42 discriminator 1
	nop
.L59:
	.loc 1 78 8
	addq	$840, %rsp
.LEHE3:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.section	.gcc_except_table,"a",@progbits
.LLSDA3:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE3-.LLSDACSB3
.LLSDACSB3:
	.uleb128 .LEHB0-.LFB3
	.uleb128 .LEHE0-.LEHB0
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB1-.LFB3
	.uleb128 .LEHE1-.LEHB1
	.uleb128 .L57-.LFB3
	.uleb128 0
	.uleb128 .LEHB2-.LFB3
	.uleb128 .LEHE2-.LEHB2
	.uleb128 .L58-.LFB3
	.uleb128 0
	.uleb128 .LEHB3-.LFB3
	.uleb128 .LEHE3-.LEHB3
	.uleb128 0
	.uleb128 0
.LLSDACSE3:
	.text
	.size	silver_report_reader__read_report___wrapped_statements.0, .-silver_report_reader__read_report___wrapped_statements.0
	.section	.rodata
	.align 8
.LC7:
	.ascii	"failed precondition from silver_report_reader.ads:28"
	.align 8
.LC8:
	.ascii	"failed precondition from silver_report_reader.ads:29"
	.align 8
.LC9:
	.ascii	"failed postcondition from silver_report_reader.ads:30"
	.align 8
.LC1:
	.long	1
	.long	53
	.text
	.align 2
	.globl	silver_report_reader__read_report
	.type	silver_report_reader__read_report, @function
silver_report_reader__read_report:
.LFB2:
	.loc 1 11 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA2
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB4:
	subq	$136, %rsp
.LEHE4:
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -112(%rbp)
	movq	%rdi, -104(%rbp)
	movq	%rdx, -128(%rbp)
	movq	%rcx, -120(%rbp)
	.loc 1 11 4
	leaq	16(%rbp), %rax
	.loc 1 11 4 is_stmt 0 discriminator 1
	leaq	-112(%rbp), %rdx
	movq	%rax, -64(%rbp)
	leaq	-128(%rbp), %rax
	movq	%rdx, -88(%rbp)
	movq	%rax, -80(%rbp)
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	movq	-104(%rbp), %rdx
	movl	4(%rdx), %edx
.LBB11:
	movq	-120(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movq	%rcx, -96(%rbp)
	movq	-120(%rbp), %rcx
	movl	4(%rcx), %esi
	movq	-120(%rbp), %rcx
	movl	(%rcx), %ecx
	cmpl	%ecx, %esi
	.loc 1 11 4 discriminator 4
	movq	-120(%rbp), %rcx
	movl	4(%rcx), %esi
	movq	-120(%rbp), %rcx
	movl	(%rcx), %ecx
	cmpl	%ecx, %esi
	.loc 1 11 4 discriminator 7
	movq	-120(%rbp), %rcx
	movl	4(%rcx), %esi
	movq	-120(%rbp), %rcx
	movl	(%rcx), %ecx
	cmpl	%ecx, %esi
	.loc 1 11 4 discriminator 10
	cmpl	%eax, %edx
	.loc 1 11 4 discriminator 13
	cmpl	%eax, %edx
	.loc 1 11 4 discriminator 16
	cmpl	%eax, %edx
	.file 2 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_report_reader.ads"
	.loc 2 28 30 is_stmt 1
	movq	-112(%rbp), %rdx
	movq	-104(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
.LEHB5:
	call	silver_platform__valid_path@PLT
	.loc 2 28 30 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 28 15 is_stmt 1 discriminator 1
	testb	%al, %al
	je	.L76
.LBB12:
	.loc 2 28 15 is_stmt 0 discriminator 2
	leaq	.LC7(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rsi
	movq	-152(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L76:
.LBE12:
	.loc 2 28 71 is_stmt 1 discriminator 3
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 28 15 discriminator 3
	cmpl	$1, %eax
	je	.L77
.LBB13:
	.loc 2 28 15 is_stmt 0 discriminator 4
	leaq	.LC7(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rsi
	movq	-136(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L77:
.LBE13:
	.loc 2 29 25 is_stmt 1
	movq	-120(%rbp), %rax
	movl	4(%rax), %edx
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 28 15 discriminator 5
	cmpl	%eax, %edx
	jl	.L78
	.loc 2 29 33 discriminator 1
	movq	-120(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, %ecx
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, %edx
	movl	%ecx, %eax
	subl	%edx, %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L78
	.loc 2 29 25 discriminator 2
	movq	-120(%rbp), %rax
	movl	4(%rax), %edx
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 29 33 discriminator 2
	cmpl	%eax, %edx
	jl	.L79
	.loc 2 29 33 is_stmt 0 discriminator 3
	movq	-120(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, %ecx
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, %edx
	movl	%ecx, %eax
	subl	%edx, %eax
	addl	$1, %eax
	cmpl	$16777216, %eax
	jle	.L79
.L78:
.LBB14:
	.loc 2 28 15 is_stmt 1 discriminator 6
	leaq	.LC8(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L79:
.LBE14:
	.loc 1 11 4 discriminator 19
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
	call	silver_report_reader__read_report___wrapped_statements.0
	.loc 2 30 42
	movq	-120(%rbp), %rax
	movl	4(%rax), %edx
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L80
	.loc 2 30 42 is_stmt 0 discriminator 1
	movq	-120(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, %ecx
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, %edx
	movl	%ecx, %eax
	subl	%edx, %eax
	addl	$1, %eax
	movl	%eax, %edx
	jmp	.L81
.L80:
	.loc 2 30 42 discriminator 2
	movl	$0, %edx
.L81:
	.loc 2 30 33 is_stmt 1 discriminator 3
	movl	-72(%rbp), %eax
	.loc 2 30 28 discriminator 3
	cmpl	%eax, %edx
	jge	.L90
.LBB15:
	.loc 2 30 28 is_stmt 0 discriminator 4
	leaq	.LC9(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.LEHE5:
.L90:
.LBE15:
	.loc 1 11 4 is_stmt 1 discriminator 20
	nop
.LBE11:
	.loc 1 11 4 is_stmt 0 discriminator 21
	movl	-72(%rbp), %eax
	movl	%eax, %edx
	movabsq	$-4294967296, %rax
	andq	%rbx, %rax
	orq	%rdx, %rax
	movq	%rax, %rbx
	movzbl	-67(%rbp), %eax
	movzbl	%al, %eax
	salq	$32, %rax
	movabsq	$-1095216660481, %rdx
	andq	%rbx, %rdx
	orq	%rdx, %rax
	movq	%rax, %rbx
	movzbl	-68(%rbp), %eax
	movzbl	%al, %eax
	salq	$40, %rax
	movabsq	$-280375465082881, %rdx
	andq	%rbx, %rdx
	orq	%rdx, %rax
	movq	%rax, %rbx
	movl	$0, %eax
.L86:
	cmpl	$1, %eax
	je	.L83
	.loc 1 11 4 discriminator 22
	movq	%rbx, %rax
	jmp	.L89
.L87:
	movq	%rax, -168(%rbp)
	movl	$1, %eax
	jmp	.L86
.L83:
	movq	-168(%rbp), %rax
	movq	%rax, %rdi
.LEHB6:
	call	_Unwind_Resume@PLT
.L89:
	.loc 1 11 4
	addq	$136, %rsp
.LEHE6:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.section	.gcc_except_table
.LLSDA2:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE2-.LLSDACSB2
.LLSDACSB2:
	.uleb128 .LEHB4-.LFB2
	.uleb128 .LEHE4-.LEHB4
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB5-.LFB2
	.uleb128 .LEHE5-.LEHB5
	.uleb128 .L87-.LFB2
	.uleb128 0
	.uleb128 .LEHB6-.LFB2
	.uleb128 .LEHE6-.LEHB6
	.uleb128 0
	.uleb128 0
.LLSDACSE2:
	.text
	.size	silver_report_reader__read_report, .-silver_report_reader__read_report
	.globl	silver_report_reader_E
	.data
	.align 2
	.type	silver_report_reader_E, @object
	.size	silver_report_reader_E, 2
silver_report_reader_E:
	.zero	2
	.text
	.align 2
	.type	_GLOBAL__SZ1_silver_report_reader, @function
_GLOBAL__SZ1_silver_report_reader:
.LFB6:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	.cfi_offset 3, -24
	movl	%edi, -20(%rbp)
	movl	%esi, -24(%rbp)
	movl	-24(%rbp), %eax
	cmpl	-20(%rbp), %eax
	jg	.L92
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movl	-24(%rbp), %eax
	cltq
	subq	%rax, %rdx
	leaq	1(%rdx), %rax
	jmp	.L94
.L92:
	movl	$0, %eax
.L94:
	movq	%rax, %rbx
	movq	%rbx, %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE6:
	.size	_GLOBAL__SZ1_silver_report_reader, .-_GLOBAL__SZ1_silver_report_reader
.Letext0:
	.file 3 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_report_projection_types.ads"
	.file 4 "<built-in>"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x533
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x12
	.long	.LASF97
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.quad	.Ltext0
	.quad	.LFE2-.Ltext0
	.long	.Ldebug_line0
	.uleb128 0x13
	.byte	0x8
	.byte	0x2
	.byte	0x16
	.byte	0xe
	.long	0x5f
	.uleb128 0x3
	.long	.LASF2
	.byte	0x2
	.byte	0x17
	.byte	0x2b
	.long	0x5f
	.byte	0
	.uleb128 0x3
	.long	.LASF3
	.byte	0x2
	.byte	0x18
	.byte	0x7
	.long	0x75
	.byte	0x4
	.uleb128 0x3
	.long	.LASF4
	.byte	0x2
	.byte	0x18
	.byte	0x1f
	.long	0x75
	.byte	0x5
	.byte	0
	.uleb128 0x6
	.sleb128 0
	.sleb128 2147483647
	.long	.LASF33
	.long	0x6e
	.uleb128 0x5
	.byte	0x4
	.byte	0x5
	.long	.LASF5
	.uleb128 0x5
	.byte	0x1
	.byte	0x2
	.long	.LASF6
	.uleb128 0x4
	.long	.LASF9
	.byte	0x5
	.long	0x93
	.uleb128 0x1
	.long	.LASF7
	.byte	0
	.uleb128 0x1
	.long	.LASF8
	.byte	0x1
	.byte	0
	.uleb128 0x4
	.long	.LASF10
	.byte	0x6
	.long	0xce
	.uleb128 0x1
	.long	.LASF11
	.byte	0
	.uleb128 0x1
	.long	.LASF12
	.byte	0x1
	.uleb128 0x1
	.long	.LASF13
	.byte	0x2
	.uleb128 0x1
	.long	.LASF14
	.byte	0x3
	.uleb128 0x1
	.long	.LASF15
	.byte	0x4
	.uleb128 0x1
	.long	.LASF16
	.byte	0x5
	.uleb128 0x1
	.long	.LASF17
	.byte	0x6
	.uleb128 0x1
	.long	.LASF18
	.byte	0x7
	.byte	0
	.uleb128 0x4
	.long	.LASF19
	.byte	0x9
	.long	0xf1
	.uleb128 0x1
	.long	.LASF20
	.byte	0
	.uleb128 0x1
	.long	.LASF21
	.byte	0x1
	.uleb128 0x1
	.long	.LASF22
	.byte	0x2
	.uleb128 0x1
	.long	.LASF23
	.byte	0x3
	.byte	0
	.uleb128 0x4
	.long	.LASF24
	.byte	0xa
	.long	0x114
	.uleb128 0x1
	.long	.LASF25
	.byte	0
	.uleb128 0x1
	.long	.LASF26
	.byte	0x1
	.uleb128 0x1
	.long	.LASF27
	.byte	0x2
	.uleb128 0x1
	.long	.LASF28
	.byte	0x3
	.byte	0
	.uleb128 0x14
	.long	.LASF55
	.byte	0x5
	.byte	0x3
	.byte	0xb
	.byte	0x9
	.long	0x163
	.uleb128 0x3
	.long	.LASF29
	.byte	0x3
	.byte	0xc
	.byte	0x7
	.long	0x7c
	.byte	0
	.uleb128 0x3
	.long	.LASF30
	.byte	0x3
	.byte	0xd
	.byte	0x7
	.long	0x93
	.byte	0x1
	.uleb128 0x3
	.long	.LASF31
	.byte	0x3
	.byte	0xe
	.byte	0x7
	.long	0xce
	.byte	0x2
	.uleb128 0x15
	.string	"key"
	.byte	0x3
	.byte	0xf
	.byte	0x7
	.long	0xf1
	.byte	0x3
	.uleb128 0x3
	.long	.LASF32
	.byte	0x3
	.byte	0x10
	.byte	0x7
	.long	0x75
	.byte	0x4
	.byte	0
	.uleb128 0xb
	.long	.LASF81
	.long	0x114
	.long	0x178
	.uleb128 0x9
	.long	0x6e
	.sleb128 64
	.byte	0
	.uleb128 0x6
	.sleb128 0
	.sleb128 64
	.long	.LASF34
	.long	0x6e
	.uleb128 0x4
	.long	.LASF35
	.byte	0x13
	.long	0x1b3
	.uleb128 0x1
	.long	.LASF36
	.byte	0
	.uleb128 0x1
	.long	.LASF37
	.byte	0x1
	.uleb128 0x1
	.long	.LASF38
	.byte	0x2
	.uleb128 0x1
	.long	.LASF39
	.byte	0x3
	.uleb128 0x1
	.long	.LASF40
	.byte	0x4
	.uleb128 0x1
	.long	.LASF41
	.byte	0x5
	.byte	0
	.uleb128 0x4
	.long	.LASF42
	.byte	0x16
	.long	0x1ee
	.uleb128 0x1
	.long	.LASF43
	.byte	0
	.uleb128 0x1
	.long	.LASF44
	.byte	0x1
	.uleb128 0x1
	.long	.LASF45
	.byte	0x2
	.uleb128 0x1
	.long	.LASF46
	.byte	0x3
	.uleb128 0x1
	.long	.LASF47
	.byte	0x4
	.uleb128 0x1
	.long	.LASF48
	.byte	0x5
	.uleb128 0x1
	.long	.LASF49
	.byte	0x6
	.uleb128 0x1
	.long	.LASF50
	.byte	0x7
	.byte	0
	.uleb128 0x4
	.long	.LASF51
	.byte	0x19
	.long	0x20b
	.uleb128 0x1
	.long	.LASF52
	.byte	0
	.uleb128 0x1
	.long	.LASF53
	.byte	0x1
	.uleb128 0x1
	.long	.LASF54
	.byte	0x2
	.byte	0
	.uleb128 0xc
	.long	.LASF56
	.value	0x168
	.byte	0x1b
	.long	0x2f8
	.uleb128 0x3
	.long	.LASF57
	.byte	0x3
	.byte	0x1c
	.byte	0x7
	.long	0x163
	.byte	0
	.uleb128 0x2
	.long	.LASF58
	.byte	0x1d
	.byte	0x7
	.long	0x178
	.value	0x140
	.uleb128 0x2
	.long	.LASF59
	.byte	0x1e
	.byte	0x7
	.long	0x184
	.value	0x144
	.uleb128 0x2
	.long	.LASF60
	.byte	0x1f
	.byte	0x7
	.long	0x1b3
	.value	0x145
	.uleb128 0x2
	.long	.LASF61
	.byte	0x20
	.byte	0x7
	.long	0x1ee
	.value	0x146
	.uleb128 0x2
	.long	.LASF62
	.byte	0x21
	.byte	0x7
	.long	0x265
	.value	0x148
	.uleb128 0x16
	.sleb128 5
	.long	0x6e
	.uleb128 0x2
	.long	.LASF63
	.byte	0x22
	.byte	0x7
	.long	0x278
	.value	0x14c
	.uleb128 0x17
	.sleb128 0
	.sleb128 4
	.long	0x6e
	.uleb128 0x2
	.long	.LASF64
	.byte	0x23
	.byte	0x7
	.long	0x75
	.value	0x150
	.uleb128 0xd
	.long	0x2f8
	.long	0x29c
	.uleb128 0x9
	.long	0x6e
	.sleb128 10
	.byte	0
	.uleb128 0x2
	.long	.LASF65
	.byte	0x24
	.byte	0x7
	.long	0x28c
	.value	0x151
	.uleb128 0x2
	.long	.LASF66
	.byte	0x25
	.byte	0x7
	.long	0x2ff
	.value	0x15c
	.uleb128 0x2
	.long	.LASF67
	.byte	0x26
	.byte	0x7
	.long	0x75
	.value	0x160
	.uleb128 0x2
	.long	.LASF68
	.byte	0x27
	.byte	0x7
	.long	0x75
	.value	0x161
	.uleb128 0x2
	.long	.LASF69
	.byte	0x28
	.byte	0x7
	.long	0x75
	.value	0x162
	.uleb128 0x2
	.long	.LASF70
	.byte	0x28
	.byte	0x10
	.long	0x75
	.value	0x163
	.uleb128 0x2
	.long	.LASF71
	.byte	0x28
	.byte	0x1a
	.long	0x75
	.value	0x164
	.byte	0
	.uleb128 0x5
	.byte	0x1
	.byte	0x8
	.long	.LASF72
	.uleb128 0x6
	.sleb128 0
	.sleb128 11
	.long	.LASF73
	.long	0x6e
	.uleb128 0x5
	.byte	0x8
	.byte	0x7
	.long	.LASF74
	.uleb128 0x6
	.sleb128 -2147483648
	.sleb128 2147483647
	.long	.LASF75
	.long	0x324
	.uleb128 0xa
	.byte	0x4
	.byte	0x5
	.long	.LASF76
	.uleb128 0xa
	.byte	0x8
	.byte	0x5
	.long	.LASF77
	.uleb128 0x5
	.byte	0x1
	.byte	0x7
	.long	.LASF78
	.uleb128 0xa
	.byte	0x1
	.byte	0x8
	.long	.LASF79
	.uleb128 0x5
	.byte	0x8
	.byte	0x7
	.long	.LASF80
	.uleb128 0xb
	.long	.LASF82
	.long	0x2f8
	.long	0x35b
	.uleb128 0x9
	.long	0x6e
	.sleb128 2
	.byte	0
	.uleb128 0x6
	.sleb128 0
	.sleb128 2
	.long	.LASF83
	.long	0x6e
	.uleb128 0xc
	.long	.LASF84
	.value	0x170
	.byte	0x2d
	.long	0x39a
	.uleb128 0x3
	.long	.LASF85
	.byte	0x3
	.byte	0x2e
	.byte	0x7
	.long	0x20b
	.byte	0
	.uleb128 0x2
	.long	.LASF86
	.byte	0x2f
	.byte	0x7
	.long	0x347
	.value	0x168
	.uleb128 0x2
	.long	.LASF87
	.byte	0x30
	.byte	0x7
	.long	0x35b
	.value	0x16c
	.byte	0
	.uleb128 0x18
	.long	.LASF98
	.byte	0x1
	.byte	0x3
	.byte	0x6
	.uleb128 0x19
	.byte	0x1
	.byte	0x9
	.byte	0x4
	.long	0x39a
	.uleb128 0x1a
	.uleb128 0x14
	.byte	0x14
	.byte	0x14
	.byte	0x2c
	.byte	0x28
	.value	0x4
	.byte	0x30
	.byte	0x2f
	.value	0x6
	.byte	0x12
	.byte	0x15
	.byte	0x2
	.byte	0x1c
	.byte	0x23
	.uleb128 0x1
	.byte	0x16
	.byte	0x13
	.byte	0x16
	.byte	0x13
	.uleb128 0x1b
	.long	.LASF99
	.byte	0x1
	.byte	0xb
	.byte	0x4
	.long	0x2e
	.quad	.LFB2
	.quad	.LFE2-.LFB2
	.uleb128 0x1
	.byte	0x9c
	.long	0x4b7
	.uleb128 0x7
	.long	.LASF65
	.byte	0x17
	.byte	0x7
	.long	0x4ff
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x7
	.long	.LASF88
	.byte	0x17
	.byte	0x16
	.long	0x4fa
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x7
	.long	.LASF2
	.byte	0x17
	.byte	0x2b
	.long	0x5f
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x7
	.long	.LASF3
	.byte	0x18
	.byte	0x7
	.long	0x75
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x1d
	.uleb128 0x7
	.long	.LASF4
	.byte	0x18
	.byte	0x1f
	.long	0x75
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x1c
	.uleb128 0x1c
	.quad	.LBB11
	.quad	.LBE11-.LBB11
	.uleb128 0x1d
	.long	.LASF100
	.quad	.LFB3
	.quad	.LFE3-.LFB3
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -856
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x8
	.long	.LASF89
	.byte	0xf
	.byte	0x7
	.long	0x20b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -448
	.uleb128 0x8
	.long	.LASF90
	.byte	0x10
	.byte	0x7
	.long	0x30a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x8
	.long	.LASF91
	.byte	0x11
	.byte	0x7
	.long	0x311
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x8
	.long	.LASF92
	.byte	0x11
	.byte	0xd
	.long	0x311
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x1e
	.long	.LLRL0
	.uleb128 0x8
	.long	.LASF93
	.byte	0x34
	.byte	0xd
	.long	0x366
	.uleb128 0x3
	.byte	0x91
	.sleb128 -848
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x1f
	.long	.LASF94
	.byte	0x10
	.byte	0x4
	.byte	0
	.long	0x4fa
	.uleb128 0xe
	.long	.LASF95
	.long	0x4cd
	.byte	0
	.uleb128 0xf
	.long	0x504
	.uleb128 0x20
	.byte	0x8
	.byte	0x4
	.byte	0
	.long	0x4ef
	.uleb128 0x10
	.string	"LB0"
	.long	0x523
	.byte	0
	.uleb128 0x10
	.string	"UB0"
	.long	0x523
	.byte	0x4
	.byte	0
	.uleb128 0xe
	.long	.LASF96
	.long	0x531
	.byte	0x8
	.byte	0
	.uleb128 0x11
	.long	0x4b7
	.uleb128 0x11
	.long	0x4b7
	.uleb128 0xd
	.long	0x2f8
	.long	0x523
	.uleb128 0x21
	.long	0x6e
	.uleb128 0x6
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x94
	.byte	0x4
	.uleb128 0x8
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x23
	.uleb128 0x4
	.byte	0x94
	.byte	0x4
	.byte	0
	.uleb128 0x22
	.sleb128 2147483647
	.long	.LASF101
	.long	0x6e
	.uleb128 0xf
	.long	0x4d2
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x28
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x1c
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0x5
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3e
	.uleb128 0x21
	.sleb128 7
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0xd
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0x5
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x14
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x15
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x16
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x17
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0xd
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x18
	.uleb128 0x1e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x19
	.uleb128 0x3a
	.byte	0
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x18
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1a
	.uleb128 0x36
	.byte	0
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x1b
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1c
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.byte	0
	.byte	0
	.uleb128 0x1d
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x1e
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x55
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x1f
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x20
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x21
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x18
	.uleb128 0x2f
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x22
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x2c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.LFE2-.Ltext0
	.quad	0
	.quad	0
	.section	.debug_rnglists,"",@progbits
.Ldebug_ranges0:
	.long	.Ldebug_ranges3-.Ldebug_ranges2
.Ldebug_ranges2:
	.value	0x5
	.byte	0x8
	.byte	0
	.long	0
.LLRL0:
	.byte	0x4
	.uleb128 .LBB7-.Ltext0
	.uleb128 .LBE7-.Ltext0
	.byte	0x4
	.uleb128 .LBB8-.Ltext0
	.uleb128 .LBE8-.Ltext0
	.byte	0
.Ldebug_ranges3:
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF42:
	.string	"silver_report_projection_types__number_position"
.LASF83:
	.string	"silver_report_projection_types__emission_length"
.LASF14:
	.string	"silver_report_projection_types__object_value"
.LASF51:
	.string	"silver_report_projection_types__literal_kind"
.LASF95:
	.string	"P_ARRAY"
.LASF35:
	.string	"silver_report_projection_types__lexical_mode"
.LASF46:
	.string	"silver_report_projection_types__after_dot"
.LASF5:
	.string	"integer"
.LASF45:
	.string	"silver_report_projection_types__integer_digits"
.LASF22:
	.string	"silver_report_projection_types__check_list"
.LASF31:
	.string	"role"
.LASF32:
	.string	"keep"
.LASF29:
	.string	"container"
.LASF17:
	.string	"silver_report_projection_types__next_item"
.LASF85:
	.string	"following"
.LASF33:
	.string	"natural"
.LASF28:
	.string	"silver_report_projection_types__tree_key"
.LASF21:
	.string	"silver_report_projection_types__root_object"
.LASF15:
	.string	"silver_report_projection_types__object_separator"
.LASF36:
	.string	"silver_report_projection_types__between_tokens"
.LASF90:
	.string	"file"
.LASF78:
	.string	"system__storage_elements__storage_element"
.LASF71:
	.string	"failed"
.LASF8:
	.string	"silver_report_projection_types__array_container"
.LASF49:
	.string	"silver_report_projection_types__after_exponent_sign"
.LASF3:
	.string	"too_long"
.LASF81:
	.string	"silver_report_projection_types__frames"
.LASF27:
	.string	"silver_report_projection_types__proof_key"
.LASF66:
	.string	"name_length"
.LASF38:
	.string	"silver_report_projection_types__after_escape"
.LASF79:
	.string	"interfaces__c__TcharB"
.LASF11:
	.string	"silver_report_projection_types__first_key"
.LASF37:
	.string	"silver_report_projection_types__in_string"
.LASF82:
	.string	"silver_report_projection_types__emission_bytes"
.LASF20:
	.string	"silver_report_projection_types__ordinary"
.LASF40:
	.string	"silver_report_projection_types__in_number"
.LASF61:
	.string	"literal"
.LASF86:
	.string	"bytes"
.LASF70:
	.string	"finished"
.LASF56:
	.string	"silver_report_projection_types__state"
.LASF24:
	.string	"silver_report_projection_types__key_kind"
.LASF72:
	.string	"character"
.LASF18:
	.string	"silver_report_projection_types__array_separator"
.LASF65:
	.string	"name"
.LASF96:
	.string	"P_BOUNDS"
.LASF55:
	.string	"silver_report_projection_types__frame"
.LASF74:
	.string	"system__address"
.LASF9:
	.string	"silver_report_projection_types__container_kind"
.LASF87:
	.string	"length"
.LASF62:
	.string	"literal_position"
.LASF93:
	.string	"next"
.LASF80:
	.string	"interfaces__c__size_t"
.LASF100:
	.string	"silver_report_reader__read_report___wrapped_statements"
.LASF57:
	.string	"stack"
.LASF89:
	.string	"current"
.LASF2:
	.string	"last"
.LASF16:
	.string	"silver_report_projection_types__first_item"
.LASF69:
	.string	"started"
.LASF92:
	.string	"status"
.LASF10:
	.string	"silver_report_projection_types__position_kind"
.LASF64:
	.string	"string_is_key"
.LASF39:
	.string	"silver_report_projection_types__unicode_escape"
.LASF97:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF12:
	.string	"silver_report_projection_types__next_key"
.LASF59:
	.string	"mode"
.LASF94:
	.string	"string"
.LASF73:
	.string	"silver_report_projection_types__key_length"
.LASF44:
	.string	"silver_report_projection_types__after_zero"
.LASF58:
	.string	"depth"
.LASF41:
	.string	"silver_report_projection_types__in_literal"
.LASF23:
	.string	"silver_report_projection_types__check_record"
.LASF88:
	.string	"buffer"
.LASF101:
	.string	"positive"
.LASF50:
	.string	"silver_report_projection_types__exponent_digits"
.LASF54:
	.string	"silver_report_projection_types__null_literal"
.LASF76:
	.string	"interfaces__c__TintB"
.LASF75:
	.string	"interfaces__c__int"
.LASF34:
	.string	"silver_report_projection_types__depth_range"
.LASF84:
	.string	"silver_report_projection_types__transition"
.LASF77:
	.string	"system__parameters__Tsize_typeB"
.LASF26:
	.string	"silver_report_projection_types__flow_key"
.LASF91:
	.string	"item"
.LASF48:
	.string	"silver_report_projection_types__after_exponent"
.LASF98:
	.string	"silver_libc"
.LASF68:
	.string	"token_keep"
.LASF30:
	.string	"position"
.LASF63:
	.string	"unicode_left"
.LASF25:
	.string	"silver_report_projection_types__other_key"
.LASF60:
	.string	"number"
.LASF13:
	.string	"silver_report_projection_types__colon"
.LASF99:
	.string	"silver_report_reader__read_report"
.LASF53:
	.string	"silver_report_projection_types__false_literal"
.LASF52:
	.string	"silver_report_projection_types__true_literal"
.LASF4:
	.string	"success"
.LASF7:
	.string	"silver_report_projection_types__object_container"
.LASF19:
	.string	"silver_report_projection_types__role_kind"
.LASF47:
	.string	"silver_report_projection_types__fraction_digits"
.LASF6:
	.string	"boolean"
.LASF43:
	.string	"silver_report_projection_types__after_minus"
.LASF67:
	.string	"name_escaped"
	.section	.debug_line_str,"MS",@progbits,1
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_report_reader.adb"
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
	.hidden	DW.ref.__gnat_personality_v0
	.weak	DW.ref.__gnat_personality_v0
	.section	.data.rel.local.DW.ref.__gnat_personality_v0,"awG",@progbits,DW.ref.__gnat_personality_v0,comdat
	.align 8
	.type	DW.ref.__gnat_personality_v0, @object
	.size	DW.ref.__gnat_personality_v0, 8
DW.ref.__gnat_personality_v0:
	.quad	__gnat_personality_v0
	.globl	__gnat_personality_v0
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
