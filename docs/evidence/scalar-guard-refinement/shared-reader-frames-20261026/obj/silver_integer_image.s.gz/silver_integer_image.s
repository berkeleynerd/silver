	.file	"silver_integer_image.ads"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_integer_image.ads"
	.align 2
	.globl	silver_integer_image__length_of
	.type	silver_integer_image__length_of, @function
silver_integer_image__length_of:
.LFB1:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_integer_image.ads"
	.loc 1 9 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movl	%edi, -4(%rbp)
	.loc 1 10 7
	cmpl	$-9, -4(%rbp)
	jl	.L2
	.loc 1 10 21 discriminator 1
	cmpl	$9, -4(%rbp)
	jg	.L2
	.loc 1 10 45 discriminator 2
	movl	$2, %eax
	jmp	.L3
.L2:
	.loc 1 11 7
	cmpl	$-99, -4(%rbp)
	jl	.L4
	.loc 1 11 25 discriminator 1
	cmpl	$99, -4(%rbp)
	jg	.L4
	.loc 1 11 50 discriminator 2
	movl	$3, %eax
	jmp	.L3
.L4:
	.loc 1 12 7
	cmpl	$-999, -4(%rbp)
	jl	.L5
	.loc 1 12 27 discriminator 1
	cmpl	$999, -4(%rbp)
	jg	.L5
	.loc 1 12 54 discriminator 2
	movl	$4, %eax
	jmp	.L3
.L5:
	.loc 1 13 7
	cmpl	$-9999, -4(%rbp)
	jl	.L6
	.loc 1 13 28 discriminator 1
	cmpl	$9999, -4(%rbp)
	jg	.L6
	.loc 1 13 56 discriminator 2
	movl	$5, %eax
	jmp	.L3
.L6:
	.loc 1 14 7
	cmpl	$-99999, -4(%rbp)
	jl	.L7
	.loc 1 14 29 discriminator 1
	cmpl	$99999, -4(%rbp)
	jg	.L7
	.loc 1 14 58 discriminator 2
	movl	$6, %eax
	jmp	.L3
.L7:
	.loc 1 15 7
	cmpl	$-999999, -4(%rbp)
	jl	.L8
	.loc 1 15 31 discriminator 1
	cmpl	$999999, -4(%rbp)
	jg	.L8
	.loc 1 15 62 discriminator 2
	movl	$7, %eax
	jmp	.L3
.L8:
	.loc 1 16 7
	cmpl	$-9999999, -4(%rbp)
	jl	.L9
	.loc 1 16 32 discriminator 1
	cmpl	$9999999, -4(%rbp)
	jg	.L9
	.loc 1 16 64 discriminator 2
	movl	$8, %eax
	jmp	.L3
.L9:
	.loc 1 17 7
	cmpl	$-99999999, -4(%rbp)
	jl	.L10
	.loc 1 17 33 discriminator 1
	cmpl	$99999999, -4(%rbp)
	jg	.L10
	.loc 1 17 66 discriminator 2
	movl	$9, %eax
	jmp	.L3
.L10:
	.loc 1 18 7
	cmpl	$-999999999, -4(%rbp)
	jl	.L11
	.loc 1 18 35 discriminator 1
	cmpl	$999999999, -4(%rbp)
	jg	.L11
	.loc 1 18 70 discriminator 2
	movl	$10, %eax
	jmp	.L3
.L11:
	.loc 1 19 12
	movl	$11, %eax
.L3:
	.loc 1 9 4
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1:
	.size	silver_integer_image__length_of, .-silver_integer_image__length_of
	.align 2
	.globl	silver_integer_image__minimum_length
	.type	silver_integer_image__minimum_length, @function
silver_integer_image__minimum_length:
.LFB2:
	.loc 1 21 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -24(%rbp)
	.loc 1 23 24
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty@PLT
	.loc 1 23 7 discriminator 1
	testb	%al, %al
	je	.L13
	.loc 1 23 48 discriminator 2
	movl	$0, %eax
	jmp	.L14
.L13:
	.loc 1 24 26
	movl	-24(%rbp), %eax
	.loc 1 24 7
	testl	%eax, %eax
	jg	.L15
	.loc 1 24 53 discriminator 1
	movl	-20(%rbp), %eax
	.loc 1 24 31 discriminator 1
	testl	%eax, %eax
	js	.L15
	.loc 1 24 63 discriminator 2
	movl	$2, %eax
	jmp	.L14
.L15:
	.loc 1 25 30
	movl	-24(%rbp), %eax
	movl	%eax, %edi
	call	silver_integer_image__length_of
	movl	%eax, %ebx
	.loc 1 25 56 discriminator 1
	movl	-20(%rbp), %eax
	movl	%eax, %edi
	call	silver_integer_image__length_of
	.loc 1 25 24 discriminator 2
	cmpl	%eax, %ebx
	cmovle	%ebx, %eax
.L14:
	.loc 1 21 4
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	silver_integer_image__minimum_length, .-silver_integer_image__minimum_length
	.align 2
	.globl	silver_integer_image__maximum_length
	.type	silver_integer_image__maximum_length, @function
silver_integer_image__maximum_length:
.LFB3:
	.loc 1 27 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -24(%rbp)
	.loc 1 29 24
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty@PLT
	.loc 1 29 7 discriminator 1
	testb	%al, %al
	je	.L17
	.loc 1 29 48 discriminator 2
	movl	$0, %eax
	jmp	.L18
.L17:
	.loc 1 30 30
	movl	-24(%rbp), %eax
	movl	%eax, %edi
	call	silver_integer_image__length_of
	movl	%eax, %ebx
	.loc 1 30 56 discriminator 1
	movl	-20(%rbp), %eax
	movl	%eax, %edi
	call	silver_integer_image__length_of
	.loc 1 30 24 discriminator 2
	cmpl	%eax, %ebx
	cmovge	%ebx, %eax
.L18:
	.loc 1 27 4
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.size	silver_integer_image__maximum_length, .-silver_integer_image__maximum_length
	.globl	silver_integer_image_E
	.data
	.align 2
	.type	silver_integer_image_E, @object
	.size	silver_integer_image_E, 2
silver_integer_image_E:
	.zero	2
	.text
.Letext0:
	.file 2 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_scalars.ads"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x114
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x6
	.long	.LASF11
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.quad	.Ltext0
	.quad	.Letext0-.Ltext0
	.long	.Ldebug_line0
	.uleb128 0x1
	.sleb128 2
	.sleb128 11
	.long	.LASF2
	.long	0x39
	.uleb128 0x7
	.byte	0x4
	.byte	0x5
	.long	.LASF12
	.uleb128 0x1
	.sleb128 0
	.sleb128 11
	.long	.LASF3
	.long	0x39
	.uleb128 0x1
	.sleb128 -2147483648
	.sleb128 2147483647
	.long	.LASF4
	.long	0x39
	.uleb128 0x3
	.long	0x4b
	.uleb128 0x8
	.long	.LASF13
	.byte	0x8
	.byte	0x2
	.byte	0x9
	.byte	0x9
	.long	0x87
	.uleb128 0x4
	.long	.LASF5
	.byte	0x7
	.long	0x4b
	.byte	0
	.uleb128 0x4
	.long	.LASF6
	.byte	0xe
	.long	0x4b
	.byte	0x4
	.byte	0
	.uleb128 0x3
	.long	0x63
	.uleb128 0x5
	.long	.LASF7
	.byte	0x1b
	.long	0x40
	.quad	.LFB3
	.quad	.LFE3-.LFB3
	.uleb128 0x1
	.byte	0x9c
	.long	0xbb
	.uleb128 0x2
	.long	.LASF9
	.byte	0x1b
	.byte	0x1d
	.long	0x87
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.byte	0
	.uleb128 0x5
	.long	.LASF8
	.byte	0x15
	.long	0x40
	.quad	.LFB2
	.quad	.LFE2-.LFB2
	.uleb128 0x1
	.byte	0x9c
	.long	0xea
	.uleb128 0x2
	.long	.LASF9
	.byte	0x15
	.byte	0x1d
	.long	0x87
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.byte	0
	.uleb128 0x9
	.long	.LASF14
	.byte	0x1
	.byte	0x9
	.byte	0x4
	.long	0x2e
	.quad	.LFB1
	.quad	.LFE1-.LFB1
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x2
	.long	.LASF10
	.byte	0x9
	.byte	0x18
	.long	0x5e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -20
	.byte	0
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0xd
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 10
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x2c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.Letext0-.Ltext0
	.quad	0
	.quad	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF13:
	.string	"silver_scalars__interval"
.LASF11:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF5:
	.string	"lower"
.LASF10:
	.string	"item"
.LASF6:
	.string	"upper"
.LASF14:
	.string	"silver_integer_image__length_of"
.LASF8:
	.string	"silver_integer_image__minimum_length"
.LASF12:
	.string	"integer"
.LASF3:
	.string	"silver_integer_image__possible_length"
.LASF2:
	.string	"silver_integer_image__image_length"
.LASF9:
	.string	"bounds"
.LASF7:
	.string	"silver_integer_image__maximum_length"
.LASF4:
	.string	"silver_scalars__value"
	.section	.debug_line_str,"MS",@progbits,1
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_integer_image.ads"
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
