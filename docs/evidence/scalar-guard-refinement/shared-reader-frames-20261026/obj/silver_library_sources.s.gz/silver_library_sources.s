	.file	"silver_library_sources.ads"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_library_sources.ads"
	.globl	silver_library_sources_E
	.data
	.align 2
	.type	silver_library_sources_E, @object
	.size	silver_library_sources_E, 2
silver_library_sources_E:
	.zero	2
	.globl	silver_library_sources__io_specification
	.section	.rodata
	.align 32
	.type	silver_library_sources__io_specification, @object
	.size	silver_library_sources__io_specification, 2222
silver_library_sources__io_specification:
	.ascii	"with Ada.Text_IO;\npackage Silver_IO with SPARK_Mode => On i"
	.ascii	"s\n   --  Application membership restricts literals separate"
	.ascii	"ly. The executable\n   --  guard makes this implementation s"
	.ascii	"afe for every String argument.\n   Max_Length : constant Pos"
	.ascii	"itive := 4_096;\n   --  Static observations record bytes onl"
	.ascii	"y after successful libc calls.\n   --  GNAT erases this veri"
	.ascii	"fication state and its assertions from execution.\n   Writte"
	.ascii	"n_Bytes : String (1 .. Max_Length + 1) := (others => Charact"
	.ascii	"er'Val (0))\n     with Ghost => Static;\n   Written_Count : "
	.ascii	"Natural range 0 .. Max_Length + 1 := 0 with Ghost => Static;"
	.ascii	"\n   Flushed : Boolean := False with Ghost => Static;\n   Su"
	.ascii	"cceeded : Boolean := False with Ghost => Static;\n   --  Suc"
	.ascii	"ceeded records acceptance of every input byte and LF followe"
	.ascii	"d by a\n   --  successful fflush(NULL). On detected failure,"
	.ascii	" set process exit status 1\n   --  and return normally with "
	.ascii	"Succeeded False. The admitted Main then returns\n   --  with"
	.ascii	" that status. Success leaves the startup success status unch"
	.ascii	"anged.\n   --  Environmental blocking is modeled by Always_T"
	.ascii	"erminates => False.\n   procedure Put_Line (Item : String)\n"
	.ascii	"     with Global => (In_Out => Ada.Text_IO.File_System,\n   "
	.ascii	"                  Output => (Written_Bytes, Written_Count, F"
	.ascii	"lushed, Succeeded)),\n          Always_Terminates => False,\n"
	.ascii	"          Post => (Static => Succeeded = Flushed\n          "
	.ascii	"  and then (if Succeeded then Item'Length <= Max_Length\n   "
	.ascii	"           and then Written_Count = Item'Length + 1\n       "
	.ascii	"       and then Written_Bytes (1 .. Item'Length) = Item\n   "
	.ascii	"           and then Written_Bytes (Written_Count) = Characte"
	.ascii	"r'Val (10)));\n   --  Put has the same completion/failure be"
	.ascii	"havior without appending LF.\n   --  Even an empty Item requ"
	.ascii	"ests a flush; later success never clears failure.\n   proced"
	.ascii	"ure Put (Item : String)\n     with Global => (In_Out => Ada."
	.ascii	"Text_IO.File_System,\n                     Output => (Writte"
	.ascii	"n_Bytes, Written_Count, Flushed, Succeeded)),\n          Alw"
	.ascii	"ays_Terminates => False,\n          Post => (Static => Succe"
	.ascii	"eded = Flushed\n            and then (if Succeeded then Item"
	.ascii	"'Length <= Max_Length\n              and then Written_Count "
	.ascii	"= Item'Length\n              and then Written_Bytes (1 .. It"
	.ascii	"em'Length) = Item));\nend Silver_IO;\n"
	.globl	silver_library_sources__io_implementation
	.align 32
	.type	silver_library_sources__io_implementation, @object
	.size	silver_library_sources__io_implementation, 3358
silver_library_sources__io_implementation:
	.ascii	"with Interfaces.C;\nwith System;\nwith Silver_Output_Libc;\n"
	.ascii	"package body Silver_IO with SPARK_Mode => On is\n   use type"
	.ascii	" Interfaces.C.int;\n   procedure Put_Line (Item : String) is"
	.ascii	"\n      Status : Interfaces.C.int;\n   begin\n      Written_"
	.ascii	"Bytes := (others => Character'Val (0));\n      Written_Count"
	.ascii	" := 0;\n      Flushed := False;\n      Succeeded := False;\n"
	.ascii	"      if Item'Length > Max_Length then\n         Silver_Outp"
	.ascii	"ut_Libc.Set_Exit_Status (1);\n         return;\n      end if"
	.ascii	";\n      --  The input may have any String lower bound; only"
	.ascii	" its length is bounded.\n      for Index in Item'Range loop\n"
	.ascii	"         pragma Loop_Invariant (Static => Written_Count = In"
	.ascii	"dex - Item'First);\n         pragma Loop_Invariant\n        "
	.ascii	"   (Static => (for all Offset in 1 .. Written_Count =>\n    "
	.ascii	"          Written_Bytes (Offset) = Item (Item'First + (Offse"
	.ascii	"t - 1))));\n         Status := Silver_Output_Libc.Put_Byte\n"
	.ascii	"           (Interfaces.C.int (Character'Pos (Item (Index))))"
	.ascii	";\n         if Status /= Interfaces.C.int (Character'Pos (It"
	.ascii	"em (Index))) then\n            Silver_Output_Libc.Set_Exit_S"
	.ascii	"tatus (1);\n            return;\n         end if;\n         "
	.ascii	"Written_Count := Written_Count + 1;\n         Written_Bytes "
	.ascii	"(Written_Count) := Item (Index);\n      end loop;\n      Sta"
	.ascii	"tus := Silver_Output_Libc.Put_Byte (10);\n      if Status /="
	.ascii	" 10 then\n         Silver_Output_Libc.Set_Exit_Status (1);\n"
	.ascii	"         return;\n      end if;\n      Written_Count := Writ"
	.ascii	"ten_Count + 1;\n      Written_Bytes (Written_Count) := Chara"
	.ascii	"cter'Val (10);\n      --  NULL requests flushing of all C ou"
	.ascii	"tput streams. Admitted application\n      --  code has no st"
	.ascii	"ream creation, reassignment or other output operations.\n   "
	.ascii	"   Status := Silver_Output_Libc.Flush (System.Null_Address);"
	.ascii	"\n      if Status /= 0 then\n         Silver_Output_Libc.Set"
	.ascii	"_Exit_Status (1);\n         return;\n      end if;\n      Fl"
	.ascii	"ushed := True;\n      Succeeded := True;\n   end Put_Line;\n"
	.ascii	"   procedure Put (Item : String) is\n      Status : Interfac"
	.ascii	"es.C.int;\n   begin\n      Written_Bytes := (others => Chara"
	.ascii	"cter'Val (0));\n      Written_Count := 0;\n      Flushed := "
	.ascii	"False;\n      Succeeded := False;\n      if Item'Length > Ma"
	.ascii	"x_Length then\n         Silver_Output_Libc.Set_Exit_Status ("
	.ascii	"1);\n         return;\n      end if;\n      --  The input ma"
	.ascii	"y have any String lower bound; only its length is bounded.\n"
	.ascii	"      for Index in Item'Range loop\n         pragma Loop_Inv"
	.ascii	"ariant (Static => Written_Count = Index - Item'First);\n    "
	.ascii	"     pragma Loop_Invariant\n           (Static => (for all O"
	.ascii	"ffset in 1 .. Written_Count =>\n              Written_Bytes "
	.ascii	"(Offset) = Item (Item'First + (Offset - 1))));\n         Sta"
	.ascii	"tus := Silver_Output_Libc.Put_Byte\n           (Interfaces.C"
	.ascii	".int (Character'Pos (Item (Index))));\n         if Status /="
	.ascii	" Interfaces.C.int (Character'Pos (Item (Index))) then\n     "
	.ascii	"       Silver_Output_Libc.Set_Exit_Status (1);\n            "
	.ascii	"return;\n         end if;\n         Written_Count := Written"
	.ascii	"_Count + 1;\n         Written_Bytes (Written_Count) := Item "
	.ascii	"(Index);\n      end loop;\n      --  NULL requests flushing "
	.ascii	"of all C output streams. Admitted application\n      --  cod"
	.ascii	"e has no stream creation, reassignment or other output opera"
	.ascii	"tions.\n      Status := Silver_Output_Libc.Flush (System.Nul"
	.ascii	"l_Address);\n      if Status /= 0 then\n         Silver_Outp"
	.ascii	"ut_Libc.Set_Exit_Status (1);\n         return;\n      end if"
	.ascii	";\n      Flushed := True;\n      Succeeded := True;\n   end "
	.ascii	"Put;\nend Silver_IO;\n"
	.globl	silver_library_sources__imported_interface
	.align 32
	.type	silver_library_sources__imported_interface, @object
	.size	silver_library_sources__imported_interface, 1532
silver_library_sources__imported_interface:
	.ascii	"with Interfaces.C;\nwith Ada.Text_IO;\nwith System;\npackage"
	.ascii	" Silver_Output_Libc with SPARK_Mode => On is\n   --  Direct "
	.ascii	"declarations of existing libc/GNAT, with no Silver-owned C b"
	.ascii	"odies.\n   --  File_System is initialized by Ada.Text_IO ela"
	.ascii	"boration and conservatively\n   --  covers output streams an"
	.ascii	"d process exit, as in the compiler bindings.\n   --  Importe"
	.ascii	"d bodies, byte/status semantics and progress are trusted; se"
	.ascii	"e\n   --  docs/trusted-boundary.md and docs/hello-runtime-ex"
	.ascii	"periment.md.\n   function Put_Byte (Item : Interfaces.C.int)"
	.ascii	" return Interfaces.C.int\n     with Import, Convention => C,"
	.ascii	" External_Name => \"putchar\",\n          Side_Effects, Alwa"
	.ascii	"ys_Terminates => False,\n          Global => (In_Out => Ada."
	.ascii	"Text_IO.File_System);\n   --  A null Stream flushes every op"
	.ascii	"en C output stream. Zero means success.\n   function Flush ("
	.ascii	"Stream : System.Address) return Interfaces.C.int\n     with "
	.ascii	"Import, Convention => C, External_Name => \"fflush\",\n     "
	.ascii	"     Side_Effects, Always_Terminates => False,\n          Gl"
	.ascii	"obal => (In_Out => Ada.Text_IO.File_System);\n   --  The GNA"
	.ascii	"T setter records the status used when Main returns. It retur"
	.ascii	"ns\n   --  normally, performs no stream flush, and does not "
	.ascii	"terminate the process.\n   --  Its bounded assignment and st"
	.ascii	"atus meaning are trusted runtime behavior.\n   procedure Set"
	.ascii	"_Exit_Status (Status : Interfaces.C.int)\n     with Import, "
	.ascii	"Convention => C, External_Name => \"__gnat_set_exit_status\""
	.ascii	",\n          Always_Terminates => True,\n          Global =>"
	.ascii	" (In_Out => Ada.Text_IO.File_System);\nend Silver_Output_Lib"
	.ascii	"c;\n"
	.globl	silver_library_sources__arguments_specification
	.align 32
	.type	silver_library_sources__arguments_specification, @object
	.size	silver_library_sources__arguments_specification, 1129
silver_library_sources__arguments_specification:
	.ascii	"with Ada.Text_IO;\nwith Silver_IO;\n\npackage Silver_Argumen"
	.ascii	"ts with SPARK_Mode => On is\n   --  Both queries observe the"
	.ascii	" immutable GNAT argument vector. An absent\n   --  argument "
	.ascii	"selects Default; one valid argument preserves its exact byte"
	.ascii	"s,\n   --  including the empty String. Invalid input is hand"
	.ascii	"led by the caller's\n   --  required validity guard and Reje"
	.ascii	"ct branch, never printed as a fallback.\n   function Input_I"
	.ascii	"s_Valid return Boolean with Global => null;\n\n   --  Return"
	.ascii	" canonical one-based bounds while preserving the selected by"
	.ascii	"tes.\n   --  This also applies to shifted and null-range Def"
	.ascii	"ault values.\n   function First_Or_Default (Default : String"
	.ascii	") return String\n     with Global => null,\n          Post ="
	.ascii	"> First_Or_Default'Result'First = 1\n            and then Fi"
	.ascii	"rst_Or_Default'Result'Length <= Silver_IO.Max_Length\n      "
	.ascii	"      and then (Input_Is_Valid or else First_Or_Default'Resu"
	.ascii	"lt'Length = 0)\n            and then (for all Ch of First_Or"
	.ascii	"_Default'Result =>\n              Character'Pos (Ch) in 32 ."
	.ascii	". 126);\n\n   procedure Reject\n     with Global => (In_Out "
	.ascii	"=> Ada.Text_IO.File_System), Always_Terminates;\nend Silver_"
	.ascii	"Arguments;\n"
	.globl	silver_library_sources__arguments_implementation
	.align 32
	.type	silver_library_sources__arguments_implementation, @object
	.size	silver_library_sources__arguments_implementation, 1339
silver_library_sources__arguments_implementation:
	.ascii	"with Silver_Runtime;\nwith Silver_Output_Libc;\n\npackage bo"
	.ascii	"dy Silver_Arguments with SPARK_Mode => On is\n   function Is"
	.ascii	"_Message (Item : String) return Boolean is\n     (Item'Lengt"
	.ascii	"h <= Silver_IO.Max_Length\n      and then (for all Ch of Ite"
	.ascii	"m => Character'Pos (Ch) in 32 .. 126));\n\n   function Input"
	.ascii	"_Is_Valid return Boolean is\n   begin\n      if Silver_Runti"
	.ascii	"me.Argument_Count = 0 then\n         return True;\n      els"
	.ascii	"if Silver_Runtime.Argument_Count = 1 then\n         return I"
	.ascii	"s_Message (Silver_Runtime.Argument (1));\n      end if;\n   "
	.ascii	"   return False;\n   end Input_Is_Valid;\n\n   function Firs"
	.ascii	"t_Or_Default (Default : String) return String is\n   begin\n"
	.ascii	"      if not Input_Is_Valid then\n         return \"\";\n   "
	.ascii	"   end if;\n      if Silver_Runtime.Argument_Count = 0 then\n"
	.ascii	"         if Is_Message (Default) then\n            return Re"
	.ascii	"sult : String (1 .. Default'Length) := Default;\n         en"
	.ascii	"d if;\n      elsif Silver_Runtime.Argument_Count = 1 then\n "
	.ascii	"        declare\n            Item : constant String := Silve"
	.ascii	"r_Runtime.Argument (1);\n         begin\n            if Is_M"
	.ascii	"essage (Item) then\n               return Result : String (1"
	.ascii	" .. Item'Length) := Item;\n            end if;\n         end"
	.ascii	";\n      end if;\n      return \"\";\n   end First_Or_Defaul"
	.ascii	"t;\n\n   procedure Reject is\n   begin\n      Silver_Output_"
	.ascii	"Libc.Set_Exit_Status (1);\n   end Reject;\nend Silver_Argume"
	.ascii	"nts;\n"
	.globl	silver_library_sources__runtime_interface
	.align 32
	.type	silver_library_sources__runtime_interface, @object
	.size	silver_library_sources__runtime_interface, 1010
silver_library_sources__runtime_interface:
	.ascii	"with Ada.Command_Line;\n\npackage Silver_Runtime\n  with SPA"
	.ascii	"RK_Mode => On,\n       Abstract_State => (Exit_State with Ex"
	.ascii	"ternal => Async_Readers)\nis\n   --  Explicit models of the "
	.ascii	"existing GNAT runtime entry points. The compiler\n   --  nev"
	.ascii	"er calls Ada.Command_Line.Remove, so its argument vector is "
	.ascii	"immutable.\n   --  The GNAT runtime and its ABI are in the O"
	.ascii	"racle's trusted dependencies.\n   function Argument_Count re"
	.ascii	"turn Natural\n     with Import, Convention => Ada,\n        "
	.ascii	"  External_Name => \"ada__command_line__argument_count\",\n "
	.ascii	"         Global => null;\n\n   function Argument (Number : P"
	.ascii	"ositive) return String\n     with Import, Convention => Ada,"
	.ascii	"\n          External_Name => \"ada__command_line__argument\""
	.ascii	",\n          Global => null,\n          Pre => Number <= Arg"
	.ascii	"ument_Count;\n\n   procedure Set_Exit_Status (Code : Ada.Com"
	.ascii	"mand_Line.Exit_Status)\n     with Import, Convention => C,\n"
	.ascii	"          External_Name => \"__gnat_set_exit_status\",\n    "
	.ascii	"      Global => (Output => Exit_State), Always_Terminates;\n"
	.ascii	"end Silver_Runtime;\n"
	.text
.Letext0:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_library_sources.ads"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x125
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x6
	.long	.LASF10
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.long	.Ldebug_line0
	.uleb128 0x1
	.long	0x3b
	.long	0x2f
	.uleb128 0x2
	.long	0x34
	.sleb128 2222
	.byte	0
	.uleb128 0x3
	.long	0x1e
	.uleb128 0x5
	.byte	0x4
	.byte	0x5
	.long	.LASF2
	.uleb128 0x5
	.byte	0x1
	.byte	0x8
	.long	.LASF3
	.uleb128 0x1
	.long	0x3b
	.long	0x53
	.uleb128 0x2
	.long	0x34
	.sleb128 3358
	.byte	0
	.uleb128 0x3
	.long	0x42
	.uleb128 0x1
	.long	0x3b
	.long	0x69
	.uleb128 0x2
	.long	0x34
	.sleb128 1532
	.byte	0
	.uleb128 0x3
	.long	0x58
	.uleb128 0x1
	.long	0x3b
	.long	0x7f
	.uleb128 0x2
	.long	0x34
	.sleb128 1129
	.byte	0
	.uleb128 0x3
	.long	0x6e
	.uleb128 0x1
	.long	0x3b
	.long	0x95
	.uleb128 0x2
	.long	0x34
	.sleb128 1339
	.byte	0
	.uleb128 0x3
	.long	0x84
	.uleb128 0x1
	.long	0x3b
	.long	0xab
	.uleb128 0x2
	.long	0x34
	.sleb128 1010
	.byte	0
	.uleb128 0x3
	.long	0x9a
	.uleb128 0x4
	.long	.LASF4
	.byte	0x3
	.long	0x2f
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_sources__io_specification
	.uleb128 0x4
	.long	.LASF5
	.byte	0x27
	.long	0x53
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_sources__io_implementation
	.uleb128 0x4
	.long	.LASF6
	.byte	0x5d
	.long	0x69
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_sources__imported_interface
	.uleb128 0x4
	.long	.LASF7
	.byte	0x76
	.long	0x7f
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_sources__arguments_specification
	.uleb128 0x4
	.long	.LASF8
	.byte	0x89
	.long	0x95
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_sources__arguments_implementation
	.uleb128 0x4
	.long	.LASF9
	.byte	0x9f
	.long	0xab
	.uleb128 0x9
	.byte	0x3
	.quad	silver_library_sources__runtime_interface
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x1c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	0
	.quad	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF8:
	.string	"silver_library_sources__arguments_implementation"
.LASF3:
	.string	"character"
.LASF6:
	.string	"silver_library_sources__imported_interface"
.LASF9:
	.string	"silver_library_sources__runtime_interface"
.LASF2:
	.string	"integer"
.LASF5:
	.string	"silver_library_sources__io_implementation"
.LASF4:
	.string	"silver_library_sources__io_specification"
.LASF7:
	.string	"silver_library_sources__arguments_specification"
.LASF10:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
	.section	.debug_line_str,"MS",@progbits,1
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_library_sources.ads"
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
