	.file	"silver.adb"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver.adb"
	.align 2
	.type	silver__failure.1, @function
silver__failure.1:
.LFB2:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver.adb"
	.loc 1 22 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 3, -24
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -32(%rbp)
	movq	%rbx, -24(%rbp)
	movl	%edx, -36(%rbp)
	movq	%r10, -48(%rbp)
	.loc 1 22 4
	movq	-24(%rbp), %rax
	movl	(%rax), %eax
	movq	-24(%rbp), %rdx
	movl	4(%rdx), %edx
.LBB2:
	cmpl	%eax, %edx
	.loc 1 22 4 is_stmt 0 discriminator 3
	cmpl	%eax, %edx
	.loc 1 22 4 discriminator 6
	cmpl	%eax, %edx
	.loc 1 25 7 is_stmt 1
	movq	-32(%rbp), %rdx
	movq	-24(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	ada__text_io__put_line__2@PLT
	.loc 1 26 21
	movl	-36(%rbp), %eax
	movl	%eax, %edi
	call	__gnat_set_exit_status@PLT
	.loc 1 27 8
	nop
.LBE2:
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	silver__failure.1, .-silver__failure.1
	.section	.rodata
.LC46:
	.ascii	"catalogue"
	.align 8
.LC47:
	.ascii	"Usage: silver catalogue | silver {check|compile} SOURCE | si"
	.ascii	"lver run SOURCE [-- ARGUMENTS...]"
.LC48:
	.ascii	"silver.adb"
	.zero	1
.LC49:
	.ascii	"check"
.LC50:
	.ascii	"compile"
.LC51:
	.ascii	"run"
	.align 8
.LC52:
	.ascii	"Infrastructure error: source path is empty, too long, or con"
	.ascii	"tains NUL."
	.align 8
.LC53:
	.ascii	"Infrastructure error: cannot read source file."
	.align 8
.LC54:
	.ascii	"Rejected: source is outside the Silver catalogue."
.LC55:
	.ascii	"Accepted: silver."
	.align 8
.LC0:
	.long	1
	.long	93
	.align 8
.LC1:
	.long	1
	.long	70
	.align 8
.LC2:
	.long	1
	.long	4096
	.align 8
.LC3:
	.long	1
	.long	46
	.align 8
.LC4:
	.long	1
	.long	49
	.align 8
.LC5:
	.long	1
	.long	17
	.text
	.align 2
	.globl	_ada_silver
	.type	_ada_silver, @function
_ada_silver:
.LFB1:
	.loc 1 18 1
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA1
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB0:
	subq	$4472, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	.loc 1 18 1
	leaq	16(%rbp), %rax
	.loc 1 18 1 is_stmt 0 discriminator 1
	movq	%rax, -160(%rbp)
	.loc 1 412 18 is_stmt 1
	movl	$0, %edi
	call	__gnat_set_exit_status@PLT
.LEHE0:
.LBB3:
	leaq	-184(%rbp), %rax
	movq	%rax, %rdi
.LEHB1:
	call	system__secondary_stack__ss_mark@PLT
	.loc 1 413 21
	call	ada__command_line__argument_count@PLT
	.loc 1 413 37 discriminator 1
	cmpl	$1, %eax
	sete	%al
	.loc 1 414 6
	testb	%al, %al
	je	.L10
	.loc 1 414 29 discriminator 1
	movl	$1, %edi
	call	silver_runtime__argument@PLT
.LEHE1:
	movq	%rax, %rcx
	movq	%rdx, %rbx
	.loc 1 414 43 discriminator 2
	movq	%rbx, %rax
	movl	4(%rax), %edx
	movq	%rbx, %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	.loc 1 414 43 is_stmt 0 discriminator 7
	movq	%rbx, %rax
	movl	4(%rax), %edx
	movq	%rbx, %rax
	movl	(%rax), %eax
	subl	%eax, %edx
	cmpl	$8, %edx
	jne	.L13
	.loc 1 414 43 discriminator 8
	leaq	.LC46(%rip), %rax
	movl	$9, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcmp@PLT
	.loc 1 414 43 discriminator 9
	testl	%eax, %eax
	jne	.L13
	.loc 1 414 43 discriminator 10
	movl	$1, %eax
	jmp	.L14
.L13:
	.loc 1 414 43 discriminator 11
	movl	$0, %eax
.L14:
	.loc 1 414 6 is_stmt 1 discriminator 12
	testb	%al, %al
	je	.L10
	.loc 1 414 6 is_stmt 0 discriminator 13
	movl	$1, %r14d
	jmp	.L15
.L10:
	.loc 1 414 6 discriminator 14
	movl	$0, %r14d
.L15:
	.loc 1 414 0 is_stmt 1 discriminator 15
	movl	$1, %ebx
.L69:
	.loc 1 414 0 is_stmt 0 discriminator 16
	leaq	-208(%rbp), %rax
	movq	%rax, %r10
.LEHB2:
	call	silver__B366b___finalizer.0
.LEHE2:
	.loc 1 414 0 discriminator 17
	cmpl	$1, %ebx
	jne	.L16
	.loc 1 414 0 discriminator 19
	movl	$1, %eax
.L71:
	.loc 1 414 0 discriminator 20
	cmpl	$1, %eax
	jne	.L17
	.loc 1 414 0 discriminator 21
	nop
.LBE3:
	.loc 1 413 4 is_stmt 1 discriminator 2
	testb	%r14b, %r14b
	je	.L18
.LEHB3:
	.loc 1 416 23
	call	silver_catalogue__export@PLT
	.loc 1 417 7
	jmp	.L9
.L18:
	.loc 1 419 21
	call	ada__command_line__argument_count@PLT
	.loc 1 419 4 discriminator 1
	cmpl	$1, %eax
	jg	.L20
.LBB4:
	.loc 1 420 7
	leaq	.LC47(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rsi
	movq	%r13, %rcx
	leaq	-208(%rbp), %rax
	movq	%rax, %r10
	movl	$2, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver__failure.1
.LEHE3:
.LBE4:
	.loc 1 421 7
	jmp	.L9
.L20:
	leaq	-208(%rbp), %rax
	movq	%rax, %rdi
.LEHB4:
	call	system__secondary_stack__ss_mark@PLT
.LBB5:
	.loc 1 424 50
	movl	$1, %edi
	call	silver_runtime__argument@PLT
	.loc 1 424 50 is_stmt 0 discriminator 1
	movq	%rax, %r14
	movq	%rdx, %r15
	movq	%r15, %rax
	movl	(%rax), %eax
	movl	%eax, -56(%rbp)
	movq	%r15, %rax
	movl	4(%rax), %eax
	movl	%eax, -60(%rbp)
	.loc 1 424 7 is_stmt 1 discriminator 1
	movl	-56(%rbp), %eax
	cltq
	movq	%rax, -72(%rbp)
	movl	-60(%rbp), %eax
	cmpl	-56(%rbp), %eax
	jl	.L21
	.loc 1 424 7 is_stmt 0 discriminator 2
	movl	-60(%rbp), %eax
	cltq
	movq	%rax, -80(%rbp)
	jmp	.L22
.L21:
	.loc 1 424 7 discriminator 3
	movl	-56(%rbp), %eax
	cltq
	subq	$1, %rax
	movq	%rax, -80(%rbp)
.L22:
	.loc 1 424 7 discriminator 4
	movl	-60(%rbp), %eax
	cmpl	-56(%rbp), %eax
	.loc 1 424 7 discriminator 7
	movl	-60(%rbp), %eax
	cmpl	-56(%rbp), %eax
	.loc 1 424 50 is_stmt 1 discriminator 10
	movl	-60(%rbp), %eax
	cmpl	-56(%rbp), %eax
	jl	.L27
	.loc 1 424 50 is_stmt 0 discriminator 11
	cmpl	$0, -56(%rbp)
	jg	.L27
	.loc 1 424 50 discriminator 12
	leaq	.LC48(%rip), %rax
	movl	$424, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L27:
	.loc 1 424 7 is_stmt 1 discriminator 13
	movq	%r14, -88(%rbp)
	.loc 1 425 47
	movl	$2, %edi
	call	silver_runtime__argument@PLT
	.loc 1 425 47 is_stmt 0 discriminator 1
	movq	%rax, %r12
	movq	%rdx, %r13
	movq	%r13, %rax
	movl	(%rax), %eax
	movl	%eax, -92(%rbp)
	movq	%r13, %rax
	movl	4(%rax), %eax
	movl	%eax, -96(%rbp)
	.loc 1 425 7 is_stmt 1 discriminator 1
	movl	-92(%rbp), %eax
	cltq
	movq	%rax, -104(%rbp)
	movl	-96(%rbp), %eax
	cmpl	-92(%rbp), %eax
	jl	.L28
	.loc 1 425 7 is_stmt 0 discriminator 2
	movl	-96(%rbp), %eax
	cltq
	movq	%rax, -112(%rbp)
	jmp	.L29
.L28:
	.loc 1 425 7 discriminator 3
	movl	-92(%rbp), %eax
	cltq
	subq	$1, %rax
	movq	%rax, -112(%rbp)
.L29:
	.loc 1 425 7 discriminator 4
	movl	-96(%rbp), %eax
	cmpl	-92(%rbp), %eax
	.loc 1 425 7 discriminator 7
	movl	-96(%rbp), %eax
	cmpl	-92(%rbp), %eax
	.loc 1 425 47 is_stmt 1 discriminator 10
	movl	-96(%rbp), %eax
	cmpl	-92(%rbp), %eax
	jl	.L34
	.loc 1 425 47 is_stmt 0 discriminator 11
	cmpl	$0, -92(%rbp)
	jg	.L34
	.loc 1 425 47 discriminator 12
	leaq	.LC48(%rip), %rax
	movl	$425, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L34:
	.loc 1 425 7 is_stmt 1 discriminator 13
	movq	%r12, -120(%rbp)
	.loc 1 430 7
	movl	$2, -52(%rbp)
	.loc 1 432 18
	movl	-60(%rbp), %eax
	subl	-56(%rbp), %eax
	.loc 1 432 7
	cmpl	$4, %eax
	jne	.L35
	.loc 1 432 18 discriminator 1
	movq	%r14, %rcx
	leaq	.LC49(%rip), %rax
	movl	$5, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcmp@PLT
	.loc 1 432 18 is_stmt 0 discriminator 2
	testl	%eax, %eax
	je	.L36
.L35:
	.loc 1 432 46 is_stmt 1 discriminator 3
	movl	-60(%rbp), %eax
	subl	-56(%rbp), %eax
	.loc 1 432 29 discriminator 3
	cmpl	$6, %eax
	jne	.L37
	.loc 1 432 46 discriminator 4
	movq	%r14, %rcx
	leaq	.LC50(%rip), %rax
	movl	$7, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcmp@PLT
	.loc 1 432 46 is_stmt 0 discriminator 5
	testl	%eax, %eax
	je	.L36
.L37:
	.loc 1 432 76 is_stmt 1 discriminator 6
	movl	-60(%rbp), %eax
	subl	-56(%rbp), %eax
	.loc 1 432 59 discriminator 6
	cmpl	$2, %eax
	jne	.L38
	.loc 1 432 76 discriminator 7
	movq	%r14, %rcx
	leaq	.LC51(%rip), %rax
	movl	$3, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcmp@PLT
	.loc 1 432 76 is_stmt 0 discriminator 8
	testl	%eax, %eax
	je	.L36
.L38:
.LBB6:
	.loc 1 433 10 is_stmt 1
	leaq	.LC47(%rip), %rax
	movq	%rax, -4480(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -4472(%rbp)
	movq	-4480(%rbp), %rax
	movq	-4472(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rcx
	leaq	-208(%rbp), %rax
	movq	%rax, %r10
	movl	$2, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver__failure.1
.LBE6:
	.loc 1 434 10
	movl	$0, %ebx
	jmp	.L39
.L36:
	.loc 1 436 24
	call	ada__command_line__argument_count@PLT
	.loc 1 436 7 discriminator 1
	cmpl	$2, %eax
	jle	.L40
.LBB7:
	.loc 1 437 21
	movl	-60(%rbp), %eax
	subl	-56(%rbp), %eax
	.loc 1 437 30
	cmpl	$2, %eax
	jne	.L41
	.loc 1 437 21 discriminator 1
	movq	%r14, %rcx
	leaq	.LC51(%rip), %rax
	movl	$3, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcmp@PLT
	.loc 1 437 21 is_stmt 0 discriminator 2
	testl	%eax, %eax
	jne	.L41
	.loc 1 437 52 is_stmt 1 discriminator 3
	movl	$3, %edi
	call	silver_runtime__argument@PLT
	movq	%rax, %rcx
	movq	%rdx, %rbx
	.loc 1 437 66 discriminator 4
	movq	%rbx, %rax
	movl	4(%rax), %edx
	movq	%rbx, %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	.loc 1 437 66 is_stmt 0 discriminator 9
	movq	%rbx, %rax
	movl	4(%rax), %edx
	movq	%rbx, %rax
	movl	(%rax), %eax
	subl	%eax, %edx
	cmpl	$1, %edx
	jne	.L44
	.loc 1 437 66 discriminator 10
	movq	%rcx, %rax
	movzwl	(%rax), %eax
	.loc 1 437 66 discriminator 11
	cmpw	$11565, %ax
	je	.L45
.L44:
	.loc 1 437 66 discriminator 12
	movl	$1, %eax
	jmp	.L46
.L45:
	.loc 1 437 66 discriminator 13
	movl	$0, %eax
.L46:
	.loc 1 437 30 is_stmt 1 discriminator 14
	testb	%al, %al
	je	.L47
.L41:
	.loc 1 437 30 is_stmt 0 discriminator 15
	movl	$1, %eax
	jmp	.L48
.L47:
	.loc 1 437 30 discriminator 16
	movl	$0, %eax
.L48:
.LBE7:
	.loc 1 437 10 is_stmt 1 discriminator 17
	testb	%al, %al
	je	.L49
.LBB8:
	.loc 1 438 13
	leaq	.LC47(%rip), %rax
	movq	%rax, -4464(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -4456(%rbp)
	movq	-4464(%rbp), %rax
	movq	-4456(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rcx
	leaq	-208(%rbp), %rax
	movq	%rax, %r10
	movl	$2, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver__failure.1
.LBE8:
	.loc 1 439 13
	movl	$0, %ebx
	jmp	.L39
.L49:
	.loc 1 441 25
	movl	$3, -52(%rbp)
.L40:
	.loc 1 443 14
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_platform__valid_path@PLT
	.loc 1 443 14 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 1 443 7 is_stmt 1 discriminator 1
	testb	%al, %al
	je	.L50
.LBB9:
	.loc 1 444 10
	leaq	.LC52(%rip), %rax
	movq	%rax, -4448(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -4440(%rbp)
	movq	-4448(%rbp), %rax
	movq	-4440(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rcx
	leaq	-208(%rbp), %rax
	movq	%rax, %r10
	movl	$3, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver__failure.1
.LBE9:
	.loc 1 445 10
	movl	$0, %ebx
	jmp	.L39
.L50:
.LBB10:
	.loc 1 447 7
	leaq	-4304(%rbp), %rax
	movq	%rax, -4432(%rbp)
	leaq	.LC2(%rip), %rax
	movq	%rax, -4424(%rbp)
	movq	%r12, %rsi
	movq	%r13, %rax
	movq	-4432(%rbp), %rdx
	movq	-4424(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_platform__read_file@PLT
	movq	%rax, %rdx
	.loc 1 447 7 is_stmt 0 discriminator 1
	movl	%edx, -124(%rbp)
	movq	%rdx, %rax
	shrq	$32, %rax
	andb	$-1, %ah
	movb	%al, -125(%rbp)
	movq	%rdx, %rax
	shrq	$40, %rax
	andb	$-1, %ah
	movb	%al, -126(%rbp)
.LBE10:
	.loc 1 448 10 is_stmt 1
	movzbl	-126(%rbp), %eax
	xorl	$1, %eax
	.loc 1 448 7
	testb	%al, %al
	je	.L51
.LBB11:
	.loc 1 449 10
	leaq	.LC53(%rip), %rax
	movq	%rax, -4416(%rbp)
	leaq	.LC3(%rip), %rax
	movq	%rax, -4408(%rbp)
	movq	-4416(%rbp), %rax
	movq	-4408(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rcx
	leaq	-208(%rbp), %rax
	movq	%rax, %r10
	movl	$3, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver__failure.1
.LBE11:
	.loc 1 450 10
	movl	$0, %ebx
	jmp	.L39
.L51:
	.loc 1 452 7
	cmpb	$0, -125(%rbp)
	je	.L52
.LBB12:
	.loc 1 453 10
	leaq	.LC54(%rip), %rax
	movq	%rax, -4400(%rbp)
	leaq	.LC4(%rip), %rax
	movq	%rax, -4392(%rbp)
	movq	-4400(%rbp), %rax
	movq	-4392(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rcx
	leaq	-208(%rbp), %rax
	movq	%rax, %r10
	movl	$2, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver__failure.1
.LBE12:
	.loc 1 454 10
	movl	$0, %ebx
	jmp	.L39
.L52:
	.loc 1 456 61
	movl	-124(%rbp), %edx
	.loc 1 456 58
	testl	%edx, %edx
	jle	.L53
	.loc 1 456 58 is_stmt 0 discriminator 1
	cmpl	$4096, %edx
	jle	.L53
	.loc 1 456 58 discriminator 2
	leaq	.LC48(%rip), %rax
	movl	$456, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L53:
	.loc 1 456 38 is_stmt 1 discriminator 3
	leaq	-4304(%rbp), %rax
	movq	%rax, -4384(%rbp)
	movl	$1, -152(%rbp)
	movl	%edx, -148(%rbp)
	leaq	-152(%rbp), %rax
	movq	%rax, -4376(%rbp)
	movq	-4384(%rbp), %rbx
	movq	-4376(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_profile__accepts@PLT
	.loc 1 456 38 is_stmt 0 discriminator 4
	movb	%al, -127(%rbp)
	.loc 1 457 26 is_stmt 1
	movzbl	-127(%rbp), %eax
	xorl	$1, %eax
	.loc 1 457 44
	testb	%al, %al
	je	.L54
	.loc 1 457 97 discriminator 1
	movl	-124(%rbp), %eax
	.loc 1 457 94 discriminator 1
	testl	%eax, %eax
	jle	.L55
	.loc 1 457 94 is_stmt 0 discriminator 2
	cmpl	$4096, %eax
	jle	.L55
	.loc 1 457 94 discriminator 3
	leaq	.LC48(%rip), %rax
	movl	$457, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L55:
	.loc 1 457 74 is_stmt 1 discriminator 4
	leaq	-4304(%rbp), %rdx
	movq	%rdx, -4368(%rbp)
	movl	$1, -144(%rbp)
	movl	%eax, -140(%rbp)
	leaq	-144(%rbp), %rax
	movq	%rax, -4360(%rbp)
	movq	-4368(%rbp), %rbx
	movq	-4360(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__accepts@PLT
	.loc 1 457 44 discriminator 5
	testb	%al, %al
	je	.L54
	.loc 1 457 44 is_stmt 0 discriminator 6
	movl	$1, %eax
	jmp	.L56
.L54:
	.loc 1 457 44 discriminator 7
	movl	$0, %eax
.L56:
	.loc 1 457 23 is_stmt 1 discriminator 8
	movb	%al, -128(%rbp)
	.loc 1 458 10
	movzbl	-127(%rbp), %eax
	xorl	$1, %eax
	.loc 1 458 7
	testb	%al, %al
	je	.L57
	.loc 1 458 37 discriminator 1
	movzbl	-128(%rbp), %eax
	xorl	$1, %eax
	.loc 1 458 28 discriminator 1
	testb	%al, %al
	je	.L57
.LBB13:
	.loc 1 459 10
	leaq	.LC54(%rip), %rax
	movq	%rax, -4352(%rbp)
	leaq	.LC4(%rip), %rax
	movq	%rax, -4344(%rbp)
	movq	-4352(%rbp), %rax
	movq	-4344(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rcx
	leaq	-208(%rbp), %rax
	movq	%rax, %r10
	movl	$2, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver__failure.1
.LBE13:
	.loc 1 460 10
	movl	$0, %ebx
	jmp	.L39
.L57:
.LBB14:
	.loc 1 462 7
	leaq	.LC55(%rip), %rax
	movq	%rax, -4336(%rbp)
	leaq	.LC5(%rip), %rax
	movq	%rax, -4328(%rbp)
	movq	-4336(%rbp), %rbx
	movq	-4328(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	ada__text_io__put_line__2@PLT
.LBE14:
	.loc 1 463 18
	movl	-60(%rbp), %eax
	subl	-56(%rbp), %eax
	.loc 1 463 7
	cmpl	$4, %eax
	jne	.L58
	.loc 1 463 18 discriminator 1
	movq	%r14, %rcx
	leaq	.LC49(%rip), %rax
	movl	$5, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcmp@PLT
	.loc 1 463 18 is_stmt 0 discriminator 2
	testl	%eax, %eax
	je	.L59
.L58:
	.loc 1 464 32 is_stmt 1
	movl	-124(%rbp), %ebx
	.loc 1 464 29
	testl	%ebx, %ebx
	jle	.L60
	.loc 1 464 29 is_stmt 0 discriminator 1
	cmpl	$4096, %ebx
	jle	.L60
	.loc 1 464 29 discriminator 2
	leaq	.LC48(%rip), %rax
	movl	$464, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L60:
.LBB15:
	.loc 1 464 64 is_stmt 1 discriminator 3
	movl	-60(%rbp), %eax
	subl	-56(%rbp), %eax
	.loc 1 464 10 discriminator 3
	cmpl	$2, %eax
	jne	.L61
	.loc 1 464 64 discriminator 4
	movq	%r14, %rcx
	leaq	.LC51(%rip), %rax
	movl	$3, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcmp@PLT
	.loc 1 464 10 discriminator 5
	testl	%eax, %eax
	jne	.L61
	.loc 1 464 10 is_stmt 0 discriminator 6
	movl	$1, %edx
	jmp	.L62
.L61:
	.loc 1 464 10 discriminator 7
	movl	$0, %edx
.L62:
	.loc 1 464 10 discriminator 8
	leaq	-4304(%rbp), %rax
	movq	%rax, -4320(%rbp)
	movl	$1, -136(%rbp)
	movl	%ebx, -132(%rbp)
	leaq	-136(%rbp), %rax
	movq	%rax, -4312(%rbp)
	movl	-52(%rbp), %ecx
	movzbl	%dl, %edx
	movzbl	-128(%rbp), %eax
	movq	-4320(%rbp), %rbx
	movq	-4312(%rbp), %rsi
	movq	%rbx, %rdi
	movq	%rsi, %r9
	leaq	-208(%rbp), %rsi
	movq	%rsi, %r10
	movl	%ecx, %r8d
	movl	%edx, %ecx
	movl	%eax, %edx
	movq	%r9, %rsi
	call	silver__compile.2
.LEHE4:
.L59:
.LBE15:
	.loc 1 466 0 is_stmt 1
	movl	$2, %ebx
.L39:
	.loc 1 466 0 is_stmt 0 discriminator 1
	leaq	-208(%rbp), %rax
	movq	%rax, %r10
.LEHB5:
	call	silver__B_2___finalizer.14
.LEHE5:
	.loc 1 466 0 discriminator 2
	cmpl	$1, %ebx
	je	.L63
	cmpl	$2, %ebx
	je	.L78
	movl	$0, %eax
	jmp	.L66
.L78:
	.loc 1 466 7 is_stmt 1 discriminator 4
	movl	$2, %eax
.L66:
	.loc 1 466 7 is_stmt 0 discriminator 5
	cmpl	$1, %eax
	je	.L67
	cmpl	$2, %eax
	jne	.L9
	.loc 1 466 7 discriminator 6
	nop
.LBE5:
	.loc 1 467 5 is_stmt 1
	jmp	.L9
.L74:
	movq	%rax, %r15
	movl	$0, %ebx
.LBB16:
	.loc 1 414 6 discriminator 22
	jmp	.L69
.L16:
	movq	%r15, -4488(%rbp)
	jmp	.L70
.L75:
	movq	%rax, -4488(%rbp)
.L70:
	movl	$0, %eax
	jmp	.L71
.L17:
	movq	-4488(%rbp), %rax
	movq	%rax, %rdi
.LEHB6:
	call	_Unwind_Resume@PLT
.L76:
	movq	%rax, -4504(%rbp)
	movl	$1, %ebx
.LBE16:
.LBB17:
	.loc 1 423 4
	jmp	.L39
.L63:
	movq	-4504(%rbp), %rax
	movq	%rax, -4496(%rbp)
	jmp	.L73
.L77:
	movq	%rax, -4496(%rbp)
.L73:
	movl	$1, %eax
	jmp	.L66
.L67:
	movq	-4496(%rbp), %rax
	movq	%rax, %rdi
	call	_Unwind_Resume@PLT
.L9:
.LBE17:
	.loc 1 467 5
	addq	$4472, %rsp
.LEHE6:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1:
	.section	.gcc_except_table,"a",@progbits
.LLSDA1:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE1-.LLSDACSB1
.LLSDACSB1:
	.uleb128 .LEHB0-.LFB1
	.uleb128 .LEHE0-.LEHB0
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB1-.LFB1
	.uleb128 .LEHE1-.LEHB1
	.uleb128 .L74-.LFB1
	.uleb128 0
	.uleb128 .LEHB2-.LFB1
	.uleb128 .LEHE2-.LEHB2
	.uleb128 .L75-.LFB1
	.uleb128 0
	.uleb128 .LEHB3-.LFB1
	.uleb128 .LEHE3-.LEHB3
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB4-.LFB1
	.uleb128 .LEHE4-.LEHB4
	.uleb128 .L76-.LFB1
	.uleb128 0
	.uleb128 .LEHB5-.LFB1
	.uleb128 .LEHE5-.LEHB5
	.uleb128 .L77-.LFB1
	.uleb128 0
	.uleb128 .LEHB6-.LFB1
	.uleb128 .LEHE6-.LEHB6
	.uleb128 0
	.uleb128 0
.LLSDACSE1:
	.text
	.size	_ada_silver, .-_ada_silver
	.align 2
	.type	silver__execute___wrapped_statements.6, @function
silver__execute___wrapped_statements.6:
.LFB4:
	.loc 1 33 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%r10, %rbx
	movq	%r10, -24(%rbp)
	.loc 1 41 14
	movq	8(%rbx), %rax
	movq	(%rbx), %rcx
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rcx, %r10
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver__valid_command.4
	.loc 1 41 14 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 1 41 7 is_stmt 1 discriminator 1
	testb	%al, %al
	je	.L80
	.loc 1 42 18
	movl	$0, %eax
	movb	%al, 16(%rbx)
	.loc 1 43 10
	jmp	.L79
.L80:
	.loc 1 45 7
	movq	8(%rbx), %rax
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_platform__run@PLT
	.loc 1 45 7 is_stmt 0 discriminator 1
	movb	%al, 16(%rbx)
	.loc 1 46 8 is_stmt 1
	nop
.L79:
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	silver__execute___wrapped_statements.6, .-silver__execute___wrapped_statements.6
	.section	.rodata
	.align 8
.LC56:
	.ascii	"failed postcondition from silver.adb:34"
	.align 8
.LC34:
	.long	1
	.long	39
	.text
	.align 2
	.type	silver__execute.5, @function
silver__execute.5:
.LFB3:
	.loc 1 33 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA3
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB7:
	subq	$72, %rsp
.LEHE7:
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -96(%rbp)
	movq	%rdx, -88(%rbp)
	movq	%r10, %rbx
	movq	%r10, -104(%rbp)
	.loc 1 33 4
	leaq	16(%rbp), %rdx
	.loc 1 33 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -56(%rbp)
	movq	%rax, -72(%rbp)
	movq	%rbx, -80(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	movq	-88(%rbp), %rdx
	movl	4(%rdx), %edx
.LBB18:
	cmpl	%eax, %edx
	.loc 1 33 4 discriminator 4
	cmpl	%eax, %edx
	.loc 1 33 4 discriminator 7
	cmpl	%eax, %edx
	.loc 1 33 4 discriminator 10
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
.LEHB8:
	call	silver__execute___wrapped_statements.6
	.loc 1 34 39 is_stmt 1
	movq	-96(%rbp), %rdx
	movq	-88(%rbp), %rax
	movq	%rbx, %r10
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver__valid_command.4
	.loc 1 34 39 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 1 34 32 is_stmt 1 discriminator 1
	testb	%al, %al
	je	.L97
	.loc 1 34 32 is_stmt 0 discriminator 2
	movzbl	-64(%rbp), %eax
	testb	%al, %al
	je	.L97
.LBB19:
	.loc 1 34 32 discriminator 3
	leaq	.LC56(%rip), %r12
	leaq	.LC34(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.LEHE8:
.L97:
.LBE19:
	.loc 1 33 4 is_stmt 1 discriminator 11
	nop
.LBE18:
	.loc 1 33 4 is_stmt 0 discriminator 12
	movzbl	-64(%rbp), %r15d
	movl	$0, %eax
.L93:
	cmpl	$1, %eax
	je	.L90
	.loc 1 33 4 discriminator 13
	movl	%r15d, %eax
	jmp	.L96
.L94:
	movq	%rax, %r14
	movl	$1, %eax
	jmp	.L93
.L90:
	movq	%r14, %rax
	movq	%rax, %rdi
.LEHB9:
	call	_Unwind_Resume@PLT
.L96:
	.loc 1 33 4
	addq	$72, %rsp
.LEHE9:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.section	.gcc_except_table
.LLSDA3:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE3-.LLSDACSB3
.LLSDACSB3:
	.uleb128 .LEHB7-.LFB3
	.uleb128 .LEHE7-.LEHB7
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB8-.LFB3
	.uleb128 .LEHE8-.LEHB8
	.uleb128 .L94-.LFB3
	.uleb128 0
	.uleb128 .LEHB9-.LFB3
	.uleb128 .LEHE9-.LEHB9
	.uleb128 0
	.uleb128 0
.LLSDACSE3:
	.text
	.size	silver__execute.5, .-silver__execute.5
	.align 2
	.type	silver__same_source___wrapped_statements.11, @function
silver__same_source___wrapped_statements.11:
.LFB6:
	.loc 1 48 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 3, -24
	movq	%r10, %rbx
	movq	%r10, -40(%rbp)
.LBB20:
	.loc 1 62 7
	movq	24(%rbx), %rcx
	movq	16(%rbx), %rax
	movq	8(%rax), %rdx
	movq	(%rax), %rax
	movq	(%rcx), %rdi
	movq	8(%rcx), %rsi
	movq	%rdx, %rcx
	movq	%rax, %rdx
	call	silver_platform__read_file@PLT
	.loc 1 62 7 is_stmt 0 discriminator 1
	movl	%eax, %edx
	movl	%edx, 40(%rbx)
	movq	%rax, %rdx
	shrq	$32, %rdx
	andb	$-1, %dh
	movb	%dl, -17(%rbp)
	shrq	$40, %rax
	andb	$-1, %ah
	movb	%al, 44(%rbx)
.LBE20:
	.loc 1 64 9 is_stmt 1
	movzbl	44(%rbx), %eax
	testb	%al, %al
	je	.L99
	.loc 1 63 35
	movzbl	-17(%rbp), %eax
	xorl	$1, %eax
	.loc 1 63 26
	testb	%al, %al
	je	.L99
	.loc 1 64 46 discriminator 1
	movl	40(%rbx), %eax
	.loc 1 64 43 discriminator 1
	movq	16(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %eax
	jl	.L100
	.loc 1 64 43 is_stmt 0 discriminator 2
	movq	16(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	4(%rdx), %edx
	cmpl	%edx, %eax
	jle	.L100
	.loc 1 64 43 discriminator 3
	leaq	.LC48(%rip), %rax
	movl	$64, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L100:
	.loc 1 64 18 is_stmt 1 discriminator 4
	movq	16(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %eax
	.loc 1 64 18 is_stmt 0 discriminator 7
	movq	16(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %eax
	.loc 1 64 18 discriminator 10
	movq	16(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %eax
	jl	.L105
	.loc 1 64 18 discriminator 11
	movslq	%eax, %rcx
	movq	16(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	subq	%rdx, %rcx
	leaq	1(%rcx), %rdx
	jmp	.L106
.L105:
	.loc 1 64 18 discriminator 12
	movl	$0, %edx
.L106:
	.loc 1 64 52 is_stmt 1 discriminator 13
	movq	16(%rbx), %rcx
	movq	8(%rcx), %rcx
	movl	(%rcx), %ecx
	cmpl	%ecx, %eax
	jge	.L107
	.loc 1 64 52 is_stmt 0 discriminator 14
	movl	36(%rbx), %esi
	movl	32(%rbx), %ecx
	cmpl	%ecx, %esi
	jl	.L108
.L107:
	.loc 1 64 52 discriminator 15
	movq	16(%rbx), %rcx
	movq	8(%rcx), %rcx
	movl	(%rcx), %ecx
	cmpl	%ecx, %eax
	jl	.L109
	.loc 1 64 52 discriminator 16
	movslq	%eax, %rcx
	movq	16(%rbx), %rax
	movq	8(%rax), %rax
	movl	(%rax), %eax
	cltq
	subq	%rax, %rcx
	addq	$1, %rcx
	jmp	.L110
.L109:
	.loc 1 64 52 discriminator 17
	movl	$0, %ecx
.L110:
	.loc 1 64 52 discriminator 18
	movl	36(%rbx), %esi
	movl	32(%rbx), %eax
	cmpl	%eax, %esi
	jl	.L111
	.loc 1 64 52 discriminator 19
	movl	36(%rbx), %eax
	movslq	%eax, %rsi
	movl	32(%rbx), %eax
	cltq
	subq	%rax, %rsi
	leaq	1(%rsi), %rax
	jmp	.L112
.L111:
	.loc 1 64 52 discriminator 20
	movl	$0, %eax
.L112:
	.loc 1 64 52 discriminator 21
	cmpq	%rax, %rcx
	jne	.L113
	.loc 1 64 52 discriminator 22
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movq	16(%rbx), %rcx
	movq	(%rcx), %rsi
	movq	16(%rbx), %rcx
	movq	8(%rcx), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rdi
	movq	(%rbx), %rcx
	subq	%rcx, %rdi
	leaq	(%rsi,%rdi), %rcx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcmp@PLT
	.loc 1 64 52 discriminator 23
	testl	%eax, %eax
	jne	.L113
.L108:
	.loc 1 64 52 discriminator 24
	movl	$1, %eax
	jmp	.L114
.L113:
	.loc 1 64 52 discriminator 25
	movl	$0, %eax
.L114:
	.loc 1 64 9 is_stmt 1 discriminator 26
	testb	%al, %al
	je	.L99
	.loc 1 64 9 is_stmt 0 discriminator 27
	movl	$1, %eax
	jmp	.L115
.L99:
	.loc 1 64 9 discriminator 28
	movl	$0, %eax
.L115:
	.loc 1 63 15 is_stmt 1 discriminator 1
	movb	%al, 44(%rbx)
	.loc 1 65 8
	nop
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE6:
	.size	silver__same_source___wrapped_statements.11, .-silver__same_source___wrapped_statements.11
	.section	.rodata
	.align 8
.LC57:
	.ascii	"failed precondition from silver.adb:51"
	.align 8
.LC58:
	.ascii	"failed precondition from silver.adb:52"
	.align 8
.LC59:
	.ascii	"failed postcondition from silver.adb:53"
	.align 8
.LC60:
	.ascii	"failed postcondition from silver.adb:54"
	.align 8
.LC6:
	.long	1
	.long	38
	.text
	.align 2
	.type	silver__same_source.10, @function
silver__same_source.10:
.LFB5:
	.loc 1 48 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA5
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB10:
	subq	$184, %rsp
.LEHE10:
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r11
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r11, %rdi
	movq	%rsi, -128(%rbp)
	movq	%rdi, -120(%rbp)
	movq	%rdx, -144(%rbp)
	movq	%rcx, -136(%rbp)
	movq	%r8, -160(%rbp)
	movq	%r9, -152(%rbp)
	movq	%r10, -168(%rbp)
	.loc 1 48 4
	leaq	16(%rbp), %rdx
	.loc 1 48 4 is_stmt 0 discriminator 1
	leaq	-128(%rbp), %rax
	movq	%rdx, -64(%rbp)
	leaq	-144(%rbp), %rdx
	movq	%rax, -88(%rbp)
	leaq	-160(%rbp), %rax
	movq	%rdx, -104(%rbp)
	movq	%rax, -96(%rbp)
	movq	-136(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -80(%rbp)
	movq	-136(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -76(%rbp)
	movq	-120(%rbp), %rax
	movl	(%rax), %ecx
	movq	-120(%rbp), %rax
	movl	4(%rax), %esi
.LBB21:
	movq	-152(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, -112(%rbp)
	movq	-152(%rbp), %rax
	movl	4(%rax), %edx
	movq	-152(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	.loc 1 48 4 discriminator 4
	movq	-152(%rbp), %rax
	movl	4(%rax), %edx
	movq	-152(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	.loc 1 48 4 discriminator 7
	movq	-152(%rbp), %rax
	movl	4(%rax), %edx
	movq	-152(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	.loc 1 48 4 discriminator 10
	movl	-76(%rbp), %edx
	movl	-80(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 48 4 discriminator 13
	movl	-76(%rbp), %edx
	movl	-80(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 48 4 discriminator 16
	movl	-76(%rbp), %edx
	movl	-80(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 48 4 discriminator 19
	cmpl	%ecx, %esi
	.loc 1 48 4 discriminator 22
	cmpl	%ecx, %esi
	.loc 1 48 4 discriminator 25
	cmpl	%ecx, %esi
	.loc 1 51 18 is_stmt 1
	movq	-128(%rbp), %rdx
	movq	-120(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
.LEHB11:
	call	silver_platform__valid_path@PLT
	.loc 1 51 18 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L136
.LBB22:
	.loc 1 51 18 discriminator 2
	leaq	.LC57(%rip), %rax
	movq	%rax, -224(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rsi
	movq	-216(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L136:
.LBE22:
	.loc 1 51 60 is_stmt 1 discriminator 3
	movq	-152(%rbp), %rax
	movl	(%rax), %eax
	.loc 1 51 18 discriminator 3
	cmpl	$1, %eax
	je	.L137
.LBB23:
	.loc 1 51 18 is_stmt 0 discriminator 4
	leaq	.LC57(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rsi
	movq	-200(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L137:
.LBE23:
	.loc 1 52 33 is_stmt 1
	movq	-152(%rbp), %rax
	movl	(%rax), %eax
	cltq
	leaq	4095(%rax), %rdx
	movq	-152(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	.loc 1 51 18 discriminator 5
	cmpq	%rax, %rdx
	je	.L138
.LBB24:
	.loc 1 51 18 is_stmt 0 discriminator 6
	leaq	.LC58(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rsi
	movq	-184(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L138:
.LBE24:
	.loc 1 48 4 is_stmt 1 discriminator 28
	leaq	-112(%rbp), %rax
	movq	%rax, %r10
	call	silver__same_source___wrapped_statements.11
	.loc 1 53 44
	movq	-152(%rbp), %rax
	movl	4(%rax), %edx
	movq	-152(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L139
	.loc 1 53 44 is_stmt 0 discriminator 1
	movq	-152(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, %ecx
	movq	-152(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, %edx
	movl	%ecx, %eax
	subl	%edx, %eax
	addl	$1, %eax
	movl	%eax, %edx
	jmp	.L140
.L139:
	.loc 1 53 44 discriminator 2
	movl	$0, %edx
.L140:
	.loc 1 53 33 is_stmt 1 discriminator 3
	movl	-72(%rbp), %eax
	.loc 1 53 28 discriminator 3
	cmpl	%eax, %edx
	jge	.L141
.LBB25:
	.loc 1 53 28 is_stmt 0 discriminator 4
	leaq	.LC59(%rip), %r14
	leaq	.LC34(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L141:
.LBE25:
	.loc 1 54 20 is_stmt 1
	movzbl	-68(%rbp), %eax
	testb	%al, %al
	je	.L142
	.loc 1 55 40
	movl	-72(%rbp), %eax
	.loc 1 55 37
	movq	-152(%rbp), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %eax
	jl	.L143
	.loc 1 55 37 is_stmt 0 discriminator 1
	movq	-152(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%edx, %eax
	jle	.L143
	.loc 1 55 37 discriminator 2
	leaq	.LC48(%rip), %rax
	movl	$55, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L143:
	.loc 1 55 12 is_stmt 1 discriminator 3
	movq	-152(%rbp), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %eax
	.loc 1 55 12 is_stmt 0 discriminator 6
	movq	-152(%rbp), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %eax
	.loc 1 55 12 discriminator 9
	movq	-152(%rbp), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %eax
	jl	.L148
	.loc 1 55 12 discriminator 10
	movslq	%eax, %rcx
	movq	-152(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	subq	%rdx, %rcx
	leaq	1(%rcx), %rdx
	jmp	.L149
.L148:
	.loc 1 55 12 discriminator 11
	movl	$0, %edx
.L149:
	.loc 1 55 46 is_stmt 1 discriminator 12
	movq	-152(%rbp), %rcx
	movl	(%rcx), %ecx
	cmpl	%ecx, %eax
	jge	.L150
	.loc 1 55 46 is_stmt 0 discriminator 13
	movl	-76(%rbp), %esi
	movl	-80(%rbp), %ecx
	cmpl	%ecx, %esi
	jl	.L151
.L150:
	.loc 1 55 46 discriminator 14
	movq	-152(%rbp), %rcx
	movl	(%rcx), %ecx
	cmpl	%ecx, %eax
	jl	.L152
	.loc 1 55 46 discriminator 15
	movslq	%eax, %rcx
	movq	-152(%rbp), %rax
	movl	(%rax), %eax
	cltq
	subq	%rax, %rcx
	addq	$1, %rcx
	jmp	.L153
.L152:
	.loc 1 55 46 discriminator 16
	movl	$0, %ecx
.L153:
	.loc 1 55 46 discriminator 17
	movl	-76(%rbp), %esi
	movl	-80(%rbp), %eax
	cmpl	%eax, %esi
	jl	.L154
	.loc 1 55 46 discriminator 18
	movl	-76(%rbp), %eax
	movslq	%eax, %rsi
	movl	-80(%rbp), %eax
	cltq
	subq	%rax, %rsi
	leaq	1(%rsi), %rax
	jmp	.L155
.L154:
	.loc 1 55 46 discriminator 19
	movl	$0, %eax
.L155:
	.loc 1 55 46 discriminator 20
	cmpq	%rax, %rcx
	jne	.L156
	.loc 1 55 46 discriminator 21
	movq	-144(%rbp), %rax
	movq	-160(%rbp), %rsi
	movq	-152(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rdi
	movq	-112(%rbp), %rcx
	subq	%rcx, %rdi
	leaq	(%rsi,%rdi), %rcx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcmp@PLT
	.loc 1 55 46 discriminator 22
	testl	%eax, %eax
	jne	.L156
.L151:
	.loc 1 55 46 discriminator 23
	movl	$1, %eax
	jmp	.L157
.L156:
	.loc 1 55 46 discriminator 24
	movl	$0, %eax
.L157:
	.loc 1 54 20 is_stmt 1 discriminator 1
	xorl	$1, %eax
	jmp	.L158
.L142:
	.loc 1 54 20 is_stmt 0 discriminator 2
	movl	$0, %eax
.L158:
	.loc 1 53 28 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L167
.LBB26:
	.loc 1 53 28 is_stmt 0 discriminator 6
	leaq	.LC60(%rip), %r12
	leaq	.LC34(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.LEHE11:
.L167:
.LBE26:
	.loc 1 48 4 is_stmt 1 discriminator 29
	nop
.LBE21:
	.loc 1 48 4 is_stmt 0 discriminator 30
	movl	-72(%rbp), %eax
	movl	%eax, %edx
	movabsq	$-4294967296, %rax
	andq	%rbx, %rax
	orq	%rdx, %rax
	movq	%rax, %rbx
	movzbl	-68(%rbp), %eax
	movzbl	%al, %eax
	salq	$32, %rax
	movabsq	$-1095216660481, %rdx
	andq	%rbx, %rdx
	orq	%rdx, %rax
	movq	%rax, %rbx
	movl	$0, %eax
.L163:
	cmpl	$1, %eax
	je	.L160
	.loc 1 48 4 discriminator 31
	movq	%rbx, %rax
	jmp	.L166
.L164:
	movq	%rax, -176(%rbp)
	movl	$1, %eax
	jmp	.L163
.L160:
	movq	-176(%rbp), %rax
	movq	%rax, %rdi
.LEHB12:
	call	_Unwind_Resume@PLT
.L166:
	.loc 1 48 4
	addq	$184, %rsp
.LEHE12:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE5:
	.section	.gcc_except_table
.LLSDA5:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE5-.LLSDACSB5
.LLSDACSB5:
	.uleb128 .LEHB10-.LFB5
	.uleb128 .LEHE10-.LEHB10
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB11-.LFB5
	.uleb128 .LEHE11-.LEHB11
	.uleb128 .L164-.LFB5
	.uleb128 0
	.uleb128 .LEHB12-.LFB5
	.uleb128 .LEHE12-.LEHB12
	.uleb128 0
	.uleb128 0
.LLSDACSE5:
	.text
	.size	silver__same_source.10, .-silver__same_source.10
	.section	.rodata
	.align 8
.LC45:
	.long	1
	.long	16777216
	.align 8
.LC14:
	.long	1
	.long	109
	.text
	.align 2
	.type	silver__compile__B_1__read_proof___wrapped_statements.8, @function
silver__compile__B_1__read_proof___wrapped_statements.8:
.LFB9:
	.loc 1 162 10 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -72(%rbp)
	.loc 1 178 13
	movq	(%rbx), %rcx
	movzbl	4913(%rcx), %ecx
	testb	%cl, %cl
	je	.L169
.LBB27:
	.loc 1 179 36
	leaq	silver_report_storage__bytes(%rip), %rsi
	leaq	.LC45(%rip), %rdi
	movq	(%rbx), %rax
	addq	$4804, %rax
	movq	%rax, -96(%rbp)
	leaq	.LC14(%rip), %rax
	movq	%rax, -88(%rbp)
	movq	-96(%rbp), %rax
	movq	-88(%rbp), %rdx
	movq	%rax, %r8
	movq	%rdx, %rax
	movq	%rsi, %rdx
	movq	%rdi, %rcx
	movq	%r8, %rdi
	movq	%rax, %rsi
	call	silver_report_reader__read_report@PLT
	.loc 1 179 36 is_stmt 0 discriminator 1
	movq	(%rbx), %rdx
	movl	%eax, %ecx
	movl	%ecx, 44(%rdx)
	movq	(%rbx), %rdx
	movq	%rax, %rcx
	shrq	$32, %rcx
	andb	$-1, %ch
	movb	%cl, 4803(%rdx)
	movq	(%rbx), %rdx
	shrq	$40, %rax
	andb	$-1, %ah
	movb	%al, 4802(%rdx)
	jmp	.L170
.L169:
.LBE27:
.LBB28:
	.loc 1 183 16 is_stmt 1
	leaq	silver_report_storage__bytes(%rip), %rax
	leaq	.LC45(%rip), %rdx
	movq	(%rbx), %rcx
	addq	$4804, %rcx
	movq	%rcx, %r8
	leaq	.LC14(%rip), %r9
	movq	%r8, %rdi
	movq	%r9, %rsi
	movq	%rdx, %rcx
	movq	%rax, %rdx
	call	silver_platform__read_file@PLT
	.loc 1 183 16 is_stmt 0 discriminator 1
	movq	(%rbx), %rdx
	movl	%eax, %ecx
	movl	%ecx, 44(%rdx)
	movq	(%rbx), %rdx
	movq	%rax, %rcx
	shrq	$32, %rcx
	andb	$-1, %ch
	movb	%cl, 4803(%rdx)
	movq	(%rbx), %rdx
	shrq	$40, %rax
	andb	$-1, %ah
	movb	%al, 4802(%rdx)
.L170:
.LBE28:
	.loc 1 185 29 is_stmt 1
	movq	(%rbx), %rax
	movl	$0, %edx
	movb	%dl, 4801(%rax)
	.loc 1 186 13
	movq	(%rbx), %rax
	movzbl	4802(%rax), %eax
	testb	%al, %al
	je	.L175
	.loc 1 186 37 discriminator 1
	movq	(%rbx), %rax
	movzbl	4803(%rax), %eax
	xorl	$1, %eax
	.loc 1 186 28 discriminator 1
	testb	%al, %al
	je	.L175
	.loc 1 195 36
	movq	(%rbx), %rax
	movzbl	4913(%rax), %eax
	testb	%al, %al
	je	.L172
	.loc 1 197 34
	movq	(%rbx), %rax
	movl	44(%rax), %eax
	.loc 1 197 31
	testl	%eax, %eax
	jle	.L173
	.loc 1 197 31 is_stmt 0 discriminator 1
	cmpl	$16777216, %eax
	jle	.L173
	.loc 1 197 31 discriminator 2
	leaq	.LC48(%rip), %rax
	movl	$197, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L173:
	.loc 1 196 40 is_stmt 1
	leaq	silver_report_storage__bytes(%rip), %r14
	movl	$1, -64(%rbp)
	movl	%eax, -60(%rbp)
	leaq	-64(%rbp), %rax
	movq	%rax, %r15
	movq	(%rbx), %rax
	movzbl	4800(%rax), %eax
	movzbl	%al, %eax
	movq	%r14, %rsi
	movq	%r15, %rcx
	movl	%eax, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver_library_reports__complete_application_proof@PLT
	.loc 1 195 32 discriminator 1
	movq	(%rbx), %rdx
	movb	%al, 4801(%rdx)
	.loc 1 200 14
	jmp	.L175
.L172:
	.loc 1 198 71
	movq	(%rbx), %rax
	movl	44(%rax), %eax
	.loc 1 198 68
	testl	%eax, %eax
	jle	.L174
	.loc 1 198 68 is_stmt 0 discriminator 1
	cmpl	$16777216, %eax
	jle	.L174
	.loc 1 198 68 discriminator 2
	leaq	.LC48(%rip), %rax
	movl	$198, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L174:
	.loc 1 198 36 is_stmt 1 discriminator 3
	leaq	silver_report_storage__bytes(%rip), %r12
	movl	$1, -56(%rbp)
	movl	%eax, -52(%rbp)
	leaq	-56(%rbp), %rax
	movq	%rax, %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_reports__complete_null_proof@PLT
	.loc 1 195 32 discriminator 2
	movq	(%rbx), %rdx
	movb	%al, 4801(%rdx)
.L175:
	.loc 1 200 14 discriminator 1
	nop
	.loc 1 200 14 is_stmt 0
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE9:
	.size	silver__compile__B_1__read_proof___wrapped_statements.8, .-silver__compile__B_1__read_proof___wrapped_statements.8
	.section	.rodata
	.align 8
.LC61:
	.ascii	"failed precondition from silver.adb:163"
	.align 8
.LC62:
	.ascii	"failed postcondition from silver.adb:164"
	.align 8
.LC63:
	.ascii	"failed postcondition from silver.adb:165"
	.align 8
.LC44:
	.long	1
	.long	40
	.text
	.align 2
	.type	silver__compile__B_1__read_proof.7, @function
silver__compile__B_1__read_proof.7:
.LFB8:
	.loc 1 162 10 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -72(%rbp)
	.loc 1 162 10
	leaq	16(%rbp), %rcx
	.loc 1 162 10 is_stmt 0 discriminator 1
	movq	%rcx, -56(%rbp)
	movq	%rbx, -64(%rbp)
	.loc 1 163 24 is_stmt 1
	leaq	4804(%rbx), %rcx
	movq	%rcx, %rax
	leaq	.LC14(%rip), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_platform__valid_path@PLT
	.loc 1 163 24 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L177
.LBB29:
	.loc 1 163 24 discriminator 2
	leaq	.LC61(%rip), %rax
	movq	%rax, -96(%rbp)
	leaq	.LC34(%rip), %rax
	movq	%rax, -88(%rbp)
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L177:
.LBE29:
	.loc 1 162 10 is_stmt 1 discriminator 2
	leaq	-64(%rbp), %rax
	movq	%rax, %r10
	call	silver__compile__B_1__read_proof___wrapped_statements.8
	.loc 1 164 34
	movl	44(%rbx), %eax
	cmpl	$16777216, %eax
	jle	.L178
.LBB30:
	.loc 1 164 34 is_stmt 0 discriminator 1
	leaq	.LC62(%rip), %r14
	leaq	.LC44(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L178:
.LBE30:
	.loc 1 165 26 is_stmt 1
	movzbl	4801(%rbx), %eax
	testb	%al, %al
	je	.L179
	.loc 1 165 62 discriminator 1
	movzbl	4802(%rbx), %eax
	xorl	$1, %eax
	testb	%al, %al
	jne	.L180
	.loc 1 165 62 is_stmt 0 discriminator 2
	movzbl	4803(%rbx), %eax
	testb	%al, %al
	je	.L181
.L180:
	.loc 1 165 62 discriminator 3
	movl	$1, %eax
	jmp	.L183
.L181:
	.loc 1 165 62 discriminator 4
	movl	$0, %eax
	.loc 1 165 26 is_stmt 1 discriminator 5
	jmp	.L183
.L179:
	.loc 1 165 26 is_stmt 0 discriminator 6
	movl	$0, %eax
.L183:
	.loc 1 164 34 is_stmt 1 discriminator 2
	testb	%al, %al
	je	.L185
.LBB31:
	.loc 1 164 34 is_stmt 0 discriminator 3
	leaq	.LC63(%rip), %r12
	leaq	.LC44(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L185:
.LBE31:
	.loc 1 162 10 is_stmt 1 discriminator 4
	nop
	.loc 1 162 10 is_stmt 0
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE8:
	.size	silver__compile__B_1__read_proof.7, .-silver__compile__B_1__read_proof.7
	.section	.rodata
	.align 8
.LC64:
	.ascii	"failed precondition from silver.adb:69"
	.align 8
.LC65:
	.ascii	"failed precondition from silver.adb:70"
	.align 8
.LC66:
	.ascii	"failed precondition from silver.adb:71"
	.align 8
.LC67:
	.ascii	"Infrastructure error: cannot create a fresh build directory."
.LC68:
	.ascii	"/main.adb"
.LC69:
	.ascii	"/program.gpr"
.LC70:
	.ascii	"/obj/gnatprove/main~1.spark"
.LC71:
	.ascii	"/bin/main"
	.align 8
.LC72:
	.ascii	"/home/canto/src/github.com/berkeleynerd/silver/.silver/linux"
	.ascii	"-x86_64/program-"
.LC73:
	.ascii	" --no-loop-unrolling"
	.align 8
.LC74:
	.ascii	" --level=2 --prover=cvc5,z3,altergo --steps=100000 --timeout"
	.ascii	"=0 --memlimit=1000 -j0"
.LC75:
	.ascii	" --checks-as-errors=on"
.LC76:
	.ascii	" -U --mode=all --report=all"
	.align 8
.LC77:
	.ascii	"cd /home/canto/src/github.com/berkeleynerd/silver/.silver/li"
	.ascii	"nux-x86_64/toolchain && unset ALR_CONFIG GPR_CONFIG GPR_PROJ"
	.ascii	"ECT_PATH GPR_PROJECT_PATH_FILE ADA_PROJECT_PATH && ALIRE_SET"
	.ascii	"TINGS_DIR=/home/canto/src/github.com/berkeleynerd/silver/.to"
	.ascii	"ols/linux-x86_64/alire/settings /home/canto/src/github.com/b"
	.ascii	"erkeleynerd/silver/.tools/linux-x86_64/alr/bin/alr -n exec -"
	.ascii	"- /home/canto/src/github.com/berkeleynerd/silver/.silver/lin"
	.ascii	"ux-x86_64/image-tools/bin/gnatprove -P "
.LC78:
	.ascii	"/program.gpr -p"
	.align 8
.LC79:
	.ascii	"cd /home/canto/src/github.com/berkeleynerd/silver/.silver/li"
	.ascii	"nux-x86_64/toolchain && unset ALR_CONFIG GPR_CONFIG GPR_PROJ"
	.ascii	"ECT_PATH GPR_PROJECT_PATH_FILE ADA_PROJECT_PATH && ALIRE_SET"
	.ascii	"TINGS_DIR=/home/canto/src/github.com/berkeleynerd/silver/.to"
	.ascii	"ols/linux-x86_64/alire/settings /home/canto/src/github.com/b"
	.ascii	"erkeleynerd/silver/.tools/linux-x86_64/alr/bin/alr -n exec -"
	.ascii	"- gprbuild -P "
.LC80:
	.ascii	"silver.adb:303"
	.align 8
.LC81:
	.ascii	"Implementation error: invalid build path or source length."
	.align 8
.LC82:
	.ascii	"Infrastructure error: cannot create an identical source snap"
	.ascii	"shot."
	.align 8
.LC83:
	.ascii	"Infrastructure error: cannot create identical runtime librar"
	.ascii	"y snapshots."
	.align 8
.LC84:
	.ascii	"Infrastructure error: cannot write project file."
	.align 8
.LC85:
	.ascii	"Verification failure for admitted Silver: toolchain or imple"
	.ascii	"mentation defect."
	.align 8
.LC86:
	.ascii	"Verification failure for admitted Silver: missing or incompl"
	.ascii	"ete proof evidence."
	.align 8
.LC87:
	.ascii	"Verification failure for admitted Silver: missing or incompl"
	.ascii	"ete runtime library evidence."
	.align 8
.LC88:
	.ascii	"Infrastructure error: runtime library changed during verific"
	.ascii	"ation."
	.align 8
.LC89:
	.ascii	"Infrastructure error: source changed during verification."
	.align 8
.LC90:
	.ascii	"Compilation failure for admitted Silver: toolchain or implem"
	.ascii	"entation defect."
	.align 8
.LC91:
	.ascii	"Infrastructure error: source changed during compilation."
	.align 8
.LC92:
	.ascii	"Infrastructure error: runtime library changed during compila"
	.ascii	"tion."
	.align 8
.LC7:
	.long	1
	.long	60
	.align 8
.LC8:
	.long	1
	.long	9
	.align 8
.LC9:
	.long	1
	.long	82
	.align 8
.LC10:
	.long	1
	.long	91
	.align 8
.LC11:
	.long	1
	.long	12
	.align 8
.LC12:
	.long	1
	.long	94
	.align 8
.LC13:
	.long	1
	.long	27
	.align 8
.LC15:
	.long	77
	.long	82
	.align 8
.LC16:
	.long	1
	.long	76
	.align 8
.LC17:
	.long	1
	.long	20
	.align 8
.LC18:
	.long	1
	.long	22
	.align 8
.LC19:
	.long	1
	.long	459
	.align 8
.LC20:
	.long	1
	.long	15
	.align 8
.LC21:
	.long	1
	.long	374
	.align 8
.LC22:
	.long	1
	.long	471
	.align 8
.LC23:
	.long	1
	.long	14
	.align 8
.LC24:
	.long	1
	.long	58
	.align 8
.LC25:
	.long	1
	.long	65
	.align 8
.LC26:
	.long	1
	.long	72
	.align 8
.LC27:
	.long	1
	.long	48
	.align 8
.LC28:
	.long	1
	.long	77
	.align 8
.LC29:
	.long	1
	.long	79
	.align 8
.LC30:
	.long	1
	.long	89
	.align 8
.LC31:
	.long	1
	.long	66
	.align 8
.LC32:
	.long	1
	.long	57
	.align 8
.LC33:
	.long	1
	.long	56
	.text
	.align 2
	.type	silver__compile.2, @function
silver__compile.2:
.LFB7:
	.loc 1 67 4 is_stmt 1
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA7
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB13:
	subq	$104984, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r9
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r9, %rdi
	movq	%rsi, -103984(%rbp)
	movq	%rdi, -103976(%rbp)
	movb	%dl, -103985(%rbp)
	movb	%cl, -103986(%rbp)
	movl	%r8d, -103992(%rbp)
	movq	%r10, -104008(%rbp)
	movq	%r10, -104000(%rbp)
	.loc 1 67 4
	leaq	16(%rbp), %rdx
	.loc 1 67 4 is_stmt 0 discriminator 1
	leaq	-103984(%rbp), %rax
	movq	%rdx, -216(%rbp)
	movq	%rax, -5128(%rbp)
	movzbl	-103985(%rbp), %eax
	movb	%al, -223(%rbp)
	movzbl	-103986(%rbp), %eax
	movb	%al, -5088(%rbp)
	movl	-103992(%rbp), %eax
	movl	%eax, -5100(%rbp)
	movq	%r10, -5136(%rbp)
	movq	-103976(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -5112(%rbp)
	movq	-103976(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -5108(%rbp)
.LBB32:
	movl	-5108(%rbp), %edx
	movl	-5112(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 67 4 discriminator 4
	movl	-5108(%rbp), %edx
	movl	-5112(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 67 4 discriminator 7
	movl	-5108(%rbp), %edx
	movl	-5112(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 69 44 is_stmt 1
	movl	-5112(%rbp), %eax
	cltq
	leaq	4095(%rax), %rdx
	movl	-5108(%rbp), %eax
	cltq
	.loc 1 69 30
	cmpq	%rax, %rdx
	jge	.L193
.LBB33:
	.loc 1 69 30 is_stmt 0 discriminator 1
	leaq	.LC64(%rip), %r12
	leaq	.LC6(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L193:
.LBE33:
	.loc 1 70 62 is_stmt 1
	call	ada__command_line__argument_count@PLT
	movl	%eax, %edx
	.loc 1 70 45 discriminator 1
	movl	-5100(%rbp), %eax
	cmpl	%edx, %eax
	setle	%al
	xorl	$1, %eax
	.loc 1 69 30 discriminator 2
	testb	%al, %al
	je	.L194
.LBB34:
	.loc 1 69 30 is_stmt 0 discriminator 3
	leaq	.LC65(%rip), %r14
	leaq	.LC6(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L194:
.LBE34:
	.loc 1 71 34 is_stmt 1
	movzbl	-223(%rbp), %eax
	xorl	$1, %eax
	.loc 1 71 31
	testb	%al, %al
	je	.L195
	.loc 1 71 69 discriminator 1
	movq	-103984(%rbp), %rdx
	movq	-103976(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	___ghost_silver_profile__is_member@PLT
	.loc 1 71 31 discriminator 2
	xorl	$1, %eax
	jmp	.L196
.L195:
	.loc 1 71 31 is_stmt 0 discriminator 3
	movl	$0, %eax
.L196:
	.loc 1 69 30 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L197
.LBB35:
	.loc 1 69 30 is_stmt 0 discriminator 5
	leaq	.LC66(%rip), %rax
	movq	%rax, -105024(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -105016(%rbp)
	movq	-105024(%rbp), %rbx
	movq	-105016(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L197:
.LBE35:
	.loc 1 78 7 is_stmt 1
	leaq	-103968(%rbp), %rax
	movl	$0, %esi
	movq	%rax, %rdi
	call	silver_platform__create_workspace@PLT
	.loc 1 78 7 is_stmt 0 discriminator 1
	movb	%al, -337(%rbp)
	.loc 1 79 10 is_stmt 1
	movzbl	-337(%rbp), %eax
	xorl	$1, %eax
	.loc 1 79 7
	testb	%al, %al
	je	.L198
.LBB36:
	.loc 1 80 10
	leaq	.LC67(%rip), %rax
	movq	%rax, -105008(%rbp)
	leaq	.LC7(%rip), %rax
	movq	%rax, -105000(%rbp)
	movq	-105008(%rbp), %rax
	movq	-105000(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	-104008(%rbp), %r10
	movl	$3, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver__failure.1
.LEHE13:
.LBE36:
	.loc 1 81 10
	jmp	.L186
.L198:
.LBB37:
	.loc 1 84 7
	movq	%rsp, %rax
	movq	%rax, -105008(%rbp)
	.loc 1 85 67
	movq	-103984(%rbp), %rdx
	movq	-103976(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
.LEHB14:
	call	silver_output_profile__uses_arguments@PLT
	.loc 1 85 67 is_stmt 0 discriminator 1
	movb	%al, -49(%rbp)
	.loc 1 86 69 is_stmt 1
	movq	-103984(%rbp), %rdx
	movq	-103976(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__uses_assignment@PLT
	.loc 1 86 69 is_stmt 0 discriminator 1
	movb	%al, -50(%rbp)
	.loc 1 88 13 is_stmt 1
	cmpb	$0, -49(%rbp)
	je	.L200
	.loc 1 89 16
	cmpb	$0, -50(%rbp)
	je	.L201
	.loc 1 87 10
	movl	$3, %eax
	movb	%al, -336(%rbp)
	jmp	.L202
.L201:
	.loc 1 87 10 is_stmt 0 discriminator 1
	movl	$1, %eax
	movb	%al, -336(%rbp)
	jmp	.L202
.L200:
	.loc 1 91 13 is_stmt 1
	cmpb	$0, -50(%rbp)
	je	.L203
	.loc 1 87 10 discriminator 2
	movl	$2, %eax
	movb	%al, -336(%rbp)
	jmp	.L202
.L203:
	.loc 1 87 10 is_stmt 0 discriminator 3
	movl	$0, %eax
	movb	%al, -336(%rbp)
.L202:
.LBB38:
	.loc 1 93 50 is_stmt 1
	leaq	.LC68(%rip), %rax
	movq	%rax, -104992(%rbp)
	leaq	.LC8(%rip), %r15
	movq	%r15, -104984(%rbp)
	leaq	-103968(%rbp), %rax
	movq	%rax, -104976(%rbp)
	leaq	.LC9(%rip), %rbx
	movq	%rbx, -104968(%rbp)
	leaq	-5136(%rbp), %rax
	addq	$4236, %rax
	movq	%rax, -104960(%rbp)
	leaq	.LC10(%rip), %r14
	movq	%r14, -104952(%rbp)
	movq	-104960(%rbp), %rax
	movq	-104952(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rax
	movq	-104992(%rbp), %r8
	movq	-104984(%rbp), %r9
	movq	-104976(%rbp), %rdx
	movq	-104968(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	system__concat_2__str_concat_2@PLT
.LBE38:
	.loc 1 93 10 discriminator 1
	leaq	-5136(%rbp), %rax
	addq	$4236, %rax
	movq	%rax, -64(%rbp)
.LBB39:
	.loc 1 94 49
	leaq	.LC69(%rip), %rax
	movq	%rax, -104944(%rbp)
	leaq	.LC11(%rip), %rax
	movq	%rax, -104936(%rbp)
	leaq	-103968(%rbp), %rax
	movq	%rax, -104928(%rbp)
	movq	%rbx, -104920(%rbp)
	leaq	-103776(%rbp), %rax
	movq	%rax, -104912(%rbp)
	leaq	.LC12(%rip), %rax
	movq	%rax, -104904(%rbp)
	movq	-104912(%rbp), %rax
	movq	-104904(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rax
	movq	-104944(%rbp), %r8
	movq	-104936(%rbp), %r9
	movq	-104928(%rbp), %rdx
	movq	-104920(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	system__concat_2__str_concat_2@PLT
.LBE39:
	.loc 1 94 10 discriminator 1
	leaq	-103776(%rbp), %rax
	movq	%rax, -72(%rbp)
.LBB40:
	.loc 1 95 53
	leaq	.LC70(%rip), %rax
	movq	%rax, -104896(%rbp)
	leaq	.LC13(%rip), %rax
	movq	%rax, -104888(%rbp)
	leaq	-103968(%rbp), %rax
	movq	%rax, -104880(%rbp)
	movq	%rbx, -104872(%rbp)
	leaq	-5136(%rbp), %rax
	addq	$4804, %rax
	movq	%rax, -104864(%rbp)
	leaq	.LC14(%rip), %rax
	movq	%rax, -104856(%rbp)
	movq	-104864(%rbp), %rax
	movq	-104856(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rax
	movq	-104896(%rbp), %r8
	movq	-104888(%rbp), %r9
	movq	-104880(%rbp), %rdx
	movq	-104872(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	system__concat_2__str_concat_2@PLT
.LBE40:
	.loc 1 95 10 discriminator 1
	leaq	-5136(%rbp), %rax
	addq	$4804, %rax
	movq	%rax, -80(%rbp)
.LBB41:
	.loc 1 96 52
	leaq	.LC71(%rip), %rax
	movq	%rax, -104848(%rbp)
	movq	%r15, -104840(%rbp)
	leaq	-103968(%rbp), %rax
	movq	%rax, -104832(%rbp)
	movq	%rbx, -104824(%rbp)
	leaq	-5136(%rbp), %rax
	addq	$4145, %rax
	movq	%rax, -104816(%rbp)
	movq	%r14, -104808(%rbp)
	movq	-104816(%rbp), %rax
	movq	-104808(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rax
	movq	-104848(%rbp), %r8
	movq	-104840(%rbp), %r9
	movq	-104832(%rbp), %rdx
	movq	-104824(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	system__concat_2__str_concat_2@PLT
.LBE41:
	.loc 1 96 10 discriminator 1
	leaq	-5136(%rbp), %rax
	addq	$4145, %rax
	movq	%rax, -88(%rbp)
.LBB42:
	.loc 1 101 12
	leaq	-103968(%rbp), %rax
	addq	$76, %rax
	movq	%rax, -104800(%rbp)
	leaq	.LC15(%rip), %rax
	movq	%rax, -104792(%rbp)
	leaq	.LC72(%rip), %rax
	movq	%rax, -104784(%rbp)
	leaq	.LC16(%rip), %rax
	movq	%rax, -104776(%rbp)
	leaq	-103872(%rbp), %rax
	movq	%rax, -104768(%rbp)
	movq	%rbx, -104760(%rbp)
	movq	-104768(%rbp), %rax
	movq	-104760(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rax
	movq	-104800(%rbp), %r8
	movq	-104792(%rbp), %r9
	movq	-104784(%rbp), %rdx
	movq	-104776(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	system__concat_2__str_concat_2@PLT
.LEHE14:
.LBE42:
	.loc 1 99 10
	leaq	-103872(%rbp), %rax
	movq	%rax, -96(%rbp)
	.loc 1 102 10
	movb	$10, -97(%rbp)
	.loc 1 107 13
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	je	.L204
	.loc 1 107 13 is_stmt 0 discriminator 1
	movabsq	$5989913327183077408, %rax
	movabsq	$7585855511416960367, %rdx
	movq	%rax, -103680(%rbp)
	movq	%rdx, -103672(%rbp)
	movabsq	$2334398928754271596, %rax
	movabsq	$7002655869492863528, %rdx
	movq	%rax, -103664(%rbp)
	movq	%rdx, -103656(%rbp)
	movabsq	$7598454517878907492, %rax
	movabsq	$3346008906821629548, %rdx
	movq	%rax, -103648(%rbp)
	movq	%rdx, -103640(%rbp)
	movabsq	$8296228837498512481, %rax
	movabsq	$8028052755697790057, %rdx
	movq	%rax, -103632(%rbp)
	movq	%rdx, -103624(%rbp)
	movabsq	$2459013922735546670, %rax
	movabsq	$8025258841101592947, %rdx
	movq	%rax, -103616(%rbp)
	movq	%rdx, -103608(%rbp)
	movabsq	$7596551625258333301, %rax
	movabsq	$3180231161841345378, %rdx
	movq	%rax, -103600(%rbp)
	movq	%rdx, -103592(%rbp)
	movabsq	$8243124900969259552, %rax
	movabsq	$7954884667833999711, %rdx
	movq	%rax, -103584(%rbp)
	movq	%rdx, -103576(%rbp)
	movabsq	$3180231161841349492, %rax
	movabsq	$8243124900969259552, %rdx
	movq	%rax, -103568(%rbp)
	movq	%rdx, -103560(%rbp)
	movabsq	$7954884667833999711, %rax
	movabsq	$3180212470143677300, %rdx
	movq	%rax, -103552(%rbp)
	movq	%rdx, -103544(%rbp)
	movabsq	$8243124900969259552, %rax
	movabsq	$7308613719082496607, %rdx
	movq	%rax, -103536(%rbp)
	movq	%rdx, -103528(%rbp)
	movabsq	$737228191946793262, %rax
	movq	%rax, -103520(%rbp)
	jmp	.L205
.L204:
	.loc 1 107 13 discriminator 2
	movabsq	$5989913327183077408, %rax
	movabsq	$7585855511416960367, %rdx
	movq	%rax, -103680(%rbp)
	movq	%rdx, -103672(%rbp)
	movabsq	$2334398928754271596, %rax
	movabsq	$7002655869492863528, %rdx
	movq	%rax, -103664(%rbp)
	movq	%rdx, -103656(%rbp)
	movabsq	$737228191661580590, %rax
	movq	%rax, -103650(%rbp)
.L205:
	.loc 1 107 13 discriminator 3
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	.loc 1 107 13 discriminator 6
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	.loc 1 107 13 discriminator 9
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	.loc 1 107 13 discriminator 12
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	.loc 1 107 13 discriminator 15
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	.loc 1 107 13 discriminator 18
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	.loc 1 107 13 discriminator 21
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	.loc 1 107 13 discriminator 24
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	.loc 1 122 27 is_stmt 1
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	je	.L222
	.loc 1 122 27 is_stmt 0 discriminator 1
	movl	$168, %eax
	jmp	.L223
.L222:
	.loc 1 122 27 discriminator 2
	movl	$38, %eax
.L223:
	.loc 1 122 27 discriminator 3
	leal	79(%rax), %r8d
	leal	29(%r8), %r9d
	leal	1(%r9), %ebx
	leal	28(%rbx), %r10d
	leal	1(%r10), %r13d
	leal	26(%r13), %r11d
	leal	1(%r11), %r15d
	leal	20(%r15), %r12d
	leal	1(%r12), %eax
	movl	%eax, -104768(%rbp)
	leal	44(%rax), %r14d
	leal	1(%r14), %eax
	movl	%eax, -104784(%rbp)
	addl	$14, %eax
	movl	%eax, -104800(%rbp)
	addl	$1, %eax
	movl	%eax, -104816(%rbp)
	addl	$22, %eax
	movl	%eax, -104832(%rbp)
	addl	$1, %eax
	movl	%eax, -104848(%rbp)
	addl	$73, %eax
	movl	%eax, -104864(%rbp)
	addl	$1, %eax
	movl	%eax, -104880(%rbp)
	addl	$16, %eax
	movl	%eax, -104896(%rbp)
	addl	$1, %eax
	movl	%eax, -104912(%rbp)
	addl	$12, %eax
	movl	%eax, -104928(%rbp)
	addl	$1, %eax
	movl	%eax, -104(%rbp)
	movl	-104(%rbp), %eax
	cltq
	movq	%rax, -112(%rbp)
	movl	-104(%rbp), %eax
	movslq	%eax, %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %ecx
	movl	$0, %edx
.LEHB15:
	divq	%rcx
.LEHE15:
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	movq	%rax, -120(%rbp)
	.loc 1 122 27 discriminator 4
	movq	-120(%rbp), %rax
	movabsq	$2338603393740665456, %rsi
	movabsq	$2336630925664678480, %rdi
.LEHB16:
	movq	%rsi, (%rax)
	movq	%rdi, 8(%rax)
	movabsq	$8027138708183085929, %rsi
	movabsq	$7022632917730599026, %rdi
	movq	%rsi, 16(%rax)
	movq	%rdi, 24(%rax)
	movabsq	$2334398928754271591, %rsi
	movabsq	$4262976323972047400, %rdi
	movq	%rsi, 32(%rax)
	movq	%rdi, 40(%rax)
	movabsq	$2338053640975032330, %rsi
	movabsq	$4926767995163078483, %rdi
	movq	%rsi, 48(%rax)
	movq	%rdi, 56(%rax)
	movabsq	$7310315402388728132, %rsi
	movabsq	$737228190784825376, %rdi
	movq	%rsi, 63(%rax)
	movq	%rdi, 71(%rax)
.LEHE16:
	.loc 1 122 27 discriminator 5
	movl	$79, %eax
	cmpl	%eax, %r8d
	cmovge	%r8d, %eax
	cltq
	leaq	-79(%rax), %rcx
	movq	-120(%rbp), %rax
	leaq	79(%rax), %rdx
	leaq	-103680(%rbp), %rax
	movl	%ecx, %edi
	movq	%rdx, %rcx
	movq	%rax, %rsi
	cmpl	$64, %edi
	jnb	.L224
	movl	%edi, %eax
	andl	$32, %eax
	testl	%eax, %eax
	je	.L226
.LEHB17:
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rcx)
	movdqu	16(%rsi), %xmm0
	movups	%xmm0, 16(%rcx)
	movl	%edi, %eax
	addq	%rcx, %rax
	leaq	32(%rax), %rdx
	movl	%edi, %eax
	addq	%rsi, %rax
	addq	$32, %rax
	movdqu	-64(%rax), %xmm0
	movups	%xmm0, -64(%rdx)
	movdqu	-48(%rax), %xmm0
	movups	%xmm0, -48(%rdx)
	jmp	.L225
.L226:
	movl	%edi, %eax
	andl	$16, %eax
	testl	%eax, %eax
	je	.L227
	movdqu	(%rsi), %xmm0
	movups	%xmm0, (%rcx)
	movl	%edi, %eax
	addq	%rcx, %rax
	leaq	16(%rax), %rdx
	movl	%edi, %eax
	addq	%rsi, %rax
	addq	$16, %rax
	movdqu	-32(%rax), %xmm0
	movups	%xmm0, -32(%rdx)
	jmp	.L225
.L227:
	movl	%edi, %eax
	andl	$8, %eax
	testl	%eax, %eax
	je	.L228
	movq	(%rsi), %rax
	movq	%rax, (%rcx)
	movl	%edi, %eax
	addq	%rcx, %rax
	leaq	8(%rax), %rdx
	movl	%edi, %eax
	addq	%rsi, %rax
	addq	$8, %rax
	movq	-16(%rax), %rax
	movq	%rax, -16(%rdx)
	jmp	.L225
.L228:
	movl	%edi, %eax
	andl	$4, %eax
	testl	%eax, %eax
	je	.L229
	movl	(%rsi), %eax
	movl	%eax, (%rcx)
	movl	%edi, %eax
	addq	%rcx, %rax
	leaq	4(%rax), %rdx
	movl	%edi, %eax
	addq	%rsi, %rax
	addq	$4, %rax
	movl	-8(%rax), %eax
	movl	%eax, -8(%rdx)
	jmp	.L225
.L229:
	testl	%edi, %edi
	je	.L225
	movzbl	(%rsi), %eax
	movb	%al, (%rcx)
	movl	%edi, %eax
	andl	$2, %eax
	testl	%eax, %eax
	je	.L225
	movl	%edi, %eax
	leaq	(%rcx,%rax), %rdx
	movl	%edi, %eax
	addq	%rsi, %rax
	movzwl	-2(%rax), %eax
	movw	%ax, -2(%rdx)
	jmp	.L225
.L224:
	movl	%edi, %eax
	leaq	(%rcx,%rax), %rdx
	movl	%edi, %eax
	addq	%rsi, %rax
	movdqu	-64(%rax), %xmm0
	movups	%xmm0, -64(%rdx)
	movdqu	-48(%rax), %xmm0
	movups	%xmm0, -48(%rdx)
	movdqu	-32(%rax), %xmm0
	movups	%xmm0, -32(%rdx)
	movdqu	-16(%rax), %xmm0
	movups	%xmm0, -16(%rdx)
	subl	$1, %edi
	cmpl	$64, %edi
	jb	.L225
	andl	$-64, %edi
	movl	$0, %edx
.L231:
	movl	%edx, %eax
	movdqu	(%rsi,%rax), %xmm3
	movdqu	16(%rsi,%rax), %xmm2
	movdqu	32(%rsi,%rax), %xmm1
	movdqu	48(%rsi,%rax), %xmm0
	movups	%xmm3, (%rcx,%rax)
	movups	%xmm2, 16(%rcx,%rax)
	movups	%xmm1, 32(%rcx,%rax)
	movups	%xmm0, 48(%rcx,%rax)
.LEHE17:
	addl	$64, %edx
	cmpl	%edi, %edx
	jb	.L231
	movl	%edx, %eax
	addq	%rax, %rcx
	addq	%rax, %rsi
.L225:
	.loc 1 122 27 discriminator 6
	cmpl	%r9d, %r8d
	.loc 1 122 27 discriminator 9
	cmpl	%r9d, %r8d
	.loc 1 122 27 discriminator 12
	cmpl	%r9d, %r8d
	.loc 1 122 27 discriminator 15
	leal	1(%r8), %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	movabsq	$5557567762955509792, %rsi
	movabsq	$2334398928753944929, %rdi
.LEHB18:
	movq	%rsi, -1(%rax,%rdx)
	movq	%rdi, 7(%rax,%rdx)
	movabsq	$7593470440192894323, %rsi
	movabsq	$4262976328269114990, %rdi
	movq	%rsi, 12(%rax,%rdx)
	movq	%rdi, 20(%rax,%rdx)
	.loc 1 122 27 discriminator 16
	leal	1(%r9), %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	movb	$10, -1(%rax,%rdx)
	.loc 1 122 27 discriminator 17
	cmpl	%r10d, %ebx
	.loc 1 122 27 discriminator 20
	cmpl	%r10d, %ebx
	.loc 1 122 27 discriminator 23
	cmpl	%r10d, %ebx
	.loc 1 122 27 discriminator 26
	leal	1(%rbx), %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	movabsq	$5701682951031365664, %rbx
	movabsq	$7585292625887193698, %rsi
	movq	%rbx, -1(%rax,%rdx)
	movq	%rsi, 7(%rax,%rdx)
	movabsq	$8319591562401308532, %rbx
	movabsq	$4261085168449757285, %rsi
	movq	%rbx, 11(%rax,%rdx)
	movq	%rsi, 19(%rax,%rdx)
	.loc 1 122 27 discriminator 27
	leal	1(%r10), %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	movb	$10, -1(%rax,%rdx)
	.loc 1 122 27 discriminator 28
	cmpl	%r11d, %r13d
	.loc 1 122 27 discriminator 31
	cmpl	%r11d, %r13d
	.loc 1 122 27 discriminator 34
	cmpl	%r11d, %r13d
	.loc 1 122 27 discriminator 37
	leal	1(%r13), %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	movabsq	$4981107010652086304, %rbx
	movabsq	$2338046898937750904, %rsi
	movq	%rbx, -1(%rax,%rdx)
	movq	%rsi, 7(%rax,%rdx)
	movabsq	$8319591562401308515, %rbx
	movabsq	$4261089596342935653, %rsi
	movq	%rbx, 9(%rax,%rdx)
	movq	%rsi, 17(%rax,%rdx)
	.loc 1 122 27 discriminator 38
	leal	1(%r11), %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	movb	$10, -1(%rax,%rdx)
	.loc 1 122 27 discriminator 39
	cmpl	%r12d, %r15d
	.loc 1 122 27 discriminator 42
	cmpl	%r12d, %r15d
	.loc 1 122 27 discriminator 45
	cmpl	%r12d, %r15d
	.loc 1 122 27 discriminator 48
	leal	1(%r15), %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	movabsq	$7019813714331181088, %rbx
	movabsq	$7956010481416693095, %rsi
	movq	%rbx, -1(%rax,%rdx)
	movq	%rsi, 7(%rax,%rdx)
	movl	$1936269415, 15(%rax,%rdx)
	.loc 1 122 27 discriminator 49
	leal	1(%r12), %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	movb	$10, -1(%rax,%rdx)
	.loc 1 122 27 discriminator 50
	movl	-104768(%rbp), %eax
	cmpl	%r14d, %eax
	.loc 1 122 27 discriminator 53
	cmpl	%r14d, %eax
	.loc 1 122 27 discriminator 56
	cmpl	%r14d, %eax
	.loc 1 122 27 discriminator 59
	addl	$1, %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	movabsq	$8027138708184506400, %rbx
	movabsq	$2891444433042153586, %rsi
	movq	%rbx, -1(%rax,%rdx)
	movq	%rsi, 7(%rax,%rdx)
	movabsq	$2317421340868562210, %rbx
	movabsq	$7593470440063202165, %rsi
	movq	%rbx, 15(%rax,%rdx)
	movq	%rsi, 23(%rax,%rdx)
	movabsq	$7233113528283000098, %rcx
	movabsq	$4265226006314361442, %rbx
	movq	%rcx, 27(%rax,%rdx)
	movq	%rbx, 35(%rax,%rdx)
	.loc 1 122 27 discriminator 60
	leal	1(%r14), %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	movb	$10, -1(%rax,%rdx)
	.loc 1 122 27 discriminator 61
	movl	-104784(%rbp), %eax
	movl	-104800(%rbp), %ecx
	cmpl	%ecx, %eax
	.loc 1 122 27 discriminator 64
	cmpl	%ecx, %eax
	.loc 1 122 27 discriminator 67
	cmpl	%ecx, %eax
	.loc 1 122 27 discriminator 70
	addl	$1, %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	movabsq	$5629609959518904352, %rbx
	movq	%rbx, -1(%rax,%rdx)
	movabsq	$4280511369924660768, %rbx
	movq	%rbx, 5(%rax,%rdx)
	.loc 1 122 27 discriminator 71
	movl	%ecx, %eax
	addl	$1, %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	movb	$10, -1(%rax,%rdx)
	.loc 1 122 27 discriminator 72
	movl	-104816(%rbp), %eax
	movl	-104832(%rbp), %edi
	cmpl	%edi, %eax
	.loc 1 122 27 discriminator 75
	cmpl	%edi, %eax
	.loc 1 122 27 discriminator 78
	cmpl	%edi, %eax
	.loc 1 122 27 discriminator 81
	addl	$1, %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	movabsq	$7019813714331181088, %rcx
	movabsq	$7597692896009020775, %rbx
	movq	%rcx, -1(%rax,%rdx)
	movq	%rbx, 7(%rax,%rdx)
	movabsq	$8316213862616295792, %rcx
	movq	%rcx, 13(%rax,%rdx)
	.loc 1 122 27 discriminator 82
	movl	%edi, %eax
	addl	$1, %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	movb	$10, -1(%rax,%rdx)
	.loc 1 122 27 discriminator 83
	movl	-104848(%rbp), %eax
	movl	-104864(%rbp), %edi
	cmpl	%edi, %eax
	.loc 1 122 27 discriminator 86
	cmpl	%edi, %eax
	.loc 1 122 27 discriminator 89
	cmpl	%edi, %eax
	.loc 1 122 27 discriminator 92
	addl	$1, %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	movabsq	$8027138708184506400, %rcx
	movabsq	$7815259820784885874, %rbx
	movq	%rcx, -1(%rax,%rdx)
	movq	%rbx, 7(%rax,%rdx)
	movabsq	$7521983798961201012, %rcx
	movabsq	$7017805734307984229, %rbx
	movq	%rcx, 15(%rax,%rdx)
	movq	%rbx, 23(%rax,%rdx)
	movabsq	$2891422507332544802, %rcx
	movabsq	$3472966224468978978, %rbx
	movq	%rcx, 31(%rax,%rdx)
	movq	%rbx, 39(%rax,%rdx)
	movabsq	$7434636081433293362, %rcx
	movabsq	$2459013922719818094, %rbx
	movq	%rcx, 47(%rax,%rdx)
	movq	%rbx, 55(%rax,%rdx)
	movabsq	$3252197254842381409, %rcx
	movabsq	$4262976384372141671, %rbx
	movq	%rcx, 56(%rax,%rdx)
	movq	%rbx, 64(%rax,%rdx)
	.loc 1 122 27 discriminator 93
	movl	%edi, %eax
	addl	$1, %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	movb	$10, -1(%rax,%rdx)
	.loc 1 122 27 discriminator 94
	movl	-104880(%rbp), %eax
	movl	-104896(%rbp), %edi
	cmpl	%edi, %eax
	.loc 1 122 27 discriminator 97
	cmpl	%edi, %eax
	.loc 1 122 27 discriminator 100
	cmpl	%edi, %eax
	.loc 1 122 27 discriminator 103
	addl	$1, %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	movabsq	$4836976425101697056, %rcx
	movabsq	$4283597711882612079, %rbx
	movq	%rcx, -1(%rax,%rdx)
	movq	%rbx, 7(%rax,%rdx)
	.loc 1 122 27 discriminator 104
	movl	%edi, %eax
	addl	$1, %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	movb	$10, -1(%rax,%rdx)
	.loc 1 122 27 discriminator 105
	movl	-104912(%rbp), %eax
	movl	-104928(%rbp), %ecx
	cmpl	%ecx, %eax
	.loc 1 122 27 discriminator 108
	cmpl	%ecx, %eax
	.loc 1 122 27 discriminator 111
	cmpl	%ecx, %eax
	.loc 1 122 27 discriminator 114
	addl	$1, %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	movabsq	$7453301596787863141, %rbx
	movq	%rbx, -1(%rax,%rdx)
	movl	$997024114, 7(%rax,%rdx)
	.loc 1 122 27 discriminator 115
	movl	%ecx, %eax
	addl	$1, %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	movb	$10, -1(%rax,%rdx)
.LEHE18:
	.loc 1 103 10 is_stmt 1
	movl	-104(%rbp), %eax
	cltq
	movq	%rax, -128(%rbp)
	movq	-120(%rbp), %rax
	movq	%rax, -136(%rbp)
	.loc 1 126 13
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	je	.L293
	.loc 1 126 13 is_stmt 0 discriminator 1
	movabsq	$7597135384357448992, %rax
	movabsq	$8389765627861231470, %rdx
	movq	%rax, -5168(%rbp)
	movq	%rdx, -5160(%rbp)
	movl	$1702194793, -5152(%rbp)
	jmp	.L294
.L293:
	.loc 1 126 13 discriminator 2
	movabsq	$7597135384357448992, %rax
	movabsq	$8030606864703252334, %rdx
	movq	%rax, -5168(%rbp)
	movq	%rdx, -5160(%rbp)
	movb	$114, -5152(%rbp)
.L294:
	.loc 1 126 13 discriminator 3
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	.loc 1 126 13 discriminator 6
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	.loc 1 126 13 discriminator 9
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	.loc 1 126 13 discriminator 12
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	.loc 1 126 13 discriminator 15
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	.loc 1 126 13 discriminator 18
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	.loc 1 126 13 discriminator 21
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	.loc 1 126 13 discriminator 24
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	.loc 1 128 97 is_stmt 1
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	je	.L311
	.loc 1 128 97 is_stmt 0 discriminator 1
	movl	$20, %eax
	jmp	.L312
.L311:
	.loc 1 128 97 discriminator 2
	movl	$17, %eax
.L312:
	.loc 1 128 97 discriminator 3
	addl	$580, %eax
	addl	$22, %eax
	addl	$82, %eax
	addl	$20, %eax
	movl	%eax, -5096(%rbp)
	movl	-5096(%rbp), %eax
	cltq
	movq	%rax, -144(%rbp)
	movl	-5096(%rbp), %eax
	movslq	%eax, %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %ecx
	movl	$0, %edx
.LEHB19:
	divq	%rcx
.LEHE19:
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	.loc 1 128 97 discriminator 4
	movq	%rax, -5120(%rbp)
.LBB43:
	leaq	.LC73(%rip), %rax
	movq	%rax, -104752(%rbp)
	leaq	.LC17(%rip), %rax
	movq	%rax, -104744(%rbp)
	leaq	.LC74(%rip), %rax
	movq	%rax, -104736(%rbp)
	leaq	.LC9(%rip), %rax
	movq	%rax, -104728(%rbp)
	leaq	.LC75(%rip), %rax
	movq	%rax, -104720(%rbp)
	leaq	.LC18(%rip), %rax
	movq	%rax, -104712(%rbp)
	leaq	-5168(%rbp), %rax
	movq	%rax, -104704(%rbp)
	movl	$1, -200(%rbp)
	.loc 1 126 13 is_stmt 1 discriminator 27
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	je	.L313
	.loc 1 126 13 is_stmt 0 discriminator 28
	movl	$20, %eax
	jmp	.L314
.L313:
	.loc 1 126 13 discriminator 29
	movl	$17, %eax
.L314:
	.loc 1 128 97 is_stmt 1 discriminator 5
	movl	%eax, -196(%rbp)
	leaq	-200(%rbp), %rax
	movq	%rax, -104696(%rbp)
	leaq	.LC76(%rip), %rax
	movq	%rax, -104688(%rbp)
	leaq	.LC13(%rip), %rax
	movq	%rax, -104680(%rbp)
	leaq	.LC69(%rip), %rax
	movq	%rax, -104672(%rbp)
	leaq	.LC11(%rip), %rax
	movq	%rax, -104664(%rbp)
	leaq	-103872(%rbp), %rax
	movq	%rax, -104656(%rbp)
	leaq	.LC9(%rip), %rbx
	movq	%rbx, -104648(%rbp)
	leaq	.LC77(%rip), %rax
	movq	%rax, -104640(%rbp)
	leaq	.LC19(%rip), %rax
	movq	%rax, -104632(%rbp)
	movq	-5120(%rbp), %rax
	movq	%rax, -104624(%rbp)
	movl	$1, -192(%rbp)
	movl	-5096(%rbp), %eax
	movl	%eax, -188(%rbp)
	leaq	-192(%rbp), %rax
	movq	%rax, -104616(%rbp)
	movq	-104624(%rbp), %rax
	movq	-104616(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rax
	pushq	-104744(%rbp)
	pushq	-104752(%rbp)
	pushq	-104728(%rbp)
	pushq	-104736(%rbp)
	pushq	-104712(%rbp)
	pushq	-104720(%rbp)
	pushq	-104696(%rbp)
	pushq	-104704(%rbp)
	pushq	-104680(%rbp)
	pushq	-104688(%rbp)
	pushq	-104664(%rbp)
	pushq	-104672(%rbp)
	movq	-104656(%rbp), %r8
	movq	-104648(%rbp), %r9
	movq	-104640(%rbp), %rdx
	movq	-104632(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
.LEHB20:
	.cfi_escape 0x2e,0x60
	call	system__concat_8__str_concat_8@PLT
	addq	$96, %rsp
.LBE43:
	.loc 1 123 10
	movl	-5096(%rbp), %eax
	cltq
	movq	%rax, -152(%rbp)
	movq	-5120(%rbp), %rax
	movq	%rax, -160(%rbp)
.LBB44:
	.loc 1 131 71
	leaq	.LC78(%rip), %rax
	movq	%rax, -104608(%rbp)
	leaq	.LC20(%rip), %rax
	movq	%rax, -104600(%rbp)
	leaq	-103872(%rbp), %rax
	movq	%rax, -104592(%rbp)
	movq	%rbx, -104584(%rbp)
	leaq	.LC79(%rip), %rax
	movq	%rax, -104576(%rbp)
	leaq	.LC21(%rip), %rax
	movq	%rax, -104568(%rbp)
	leaq	-5136(%rbp), %rax
	addq	$4328, %rax
	movq	%rax, -104560(%rbp)
	leaq	.LC22(%rip), %rax
	movq	%rax, -104552(%rbp)
	movq	-104560(%rbp), %rax
	movq	-104552(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rax
	pushq	-104600(%rbp)
	pushq	-104608(%rbp)
	movq	-104592(%rbp), %r8
	movq	-104584(%rbp), %r9
	movq	-104576(%rbp), %rdx
	movq	-104568(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	.cfi_escape 0x2e,0x10
	call	system__concat_3__str_concat_3@PLT
	addq	$16, %rsp
.LBE44:
	.loc 1 130 10
	leaq	-5136(%rbp), %rax
	addq	$4328, %rax
	movq	%rax, -168(%rbp)
	.loc 1 132 10
	leaq	-5087(%rbp), %rcx
	movl	$4096, %eax
	movq	%rax, %rdx
	movl	$0, %esi
	movq	%rcx, %rdi
	call	memset@PLT
	.loc 1 134 10
	movl	$0, %eax
	movl	%eax, -5104(%rbp)
	.loc 1 135 10
	leaq	silver_report_storage__bytes(%rip), %rax
	movq	%rax, -176(%rbp)
	.loc 1 141 22
	leaq	-103504(%rbp), %rax
	movq	%rax, %rcx
	movl	$98304, %eax
	movq	%rax, %rdx
	movl	$0, %esi
	movq	%rcx, %rdi
	call	memset@PLT
	.loc 1 141 12 discriminator 1
	movl	$0, -5200(%rbp)
	movl	$0, -5196(%rbp)
	movl	$0, -5192(%rbp)
	movl	$0, -5188(%rbp)
	movl	$0, -5184(%rbp)
	movl	$0, -5180(%rbp)
	.loc 1 142 10
	movl	$0, %eax
	movb	%al, -809(%rbp)
	.loc 1 303 13
	leaq	-5136(%rbp), %rax
	addq	$4236, %rax
	movq	%rax, -104544(%rbp)
	leaq	.LC10(%rip), %rax
	movq	%rax, -104536(%rbp)
	movq	-104544(%rbp), %rbx
	movq	-104536(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	.cfi_escape 0x2e,0
	call	silver_platform__valid_path@PLT
	.loc 1 303 13 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	jne	.L315
	.loc 1 303 44 is_stmt 1 discriminator 2
	leaq	-103776(%rbp), %rax
	movq	%rax, -104528(%rbp)
	leaq	.LC12(%rip), %rax
	movq	%rax, -104520(%rbp)
	movq	-104528(%rbp), %rbx
	movq	-104520(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_platform__valid_path@PLT
	.loc 1 303 44 is_stmt 0 discriminator 3
	xorl	$1, %eax
	.loc 1 303 35 is_stmt 1 discriminator 3
	testb	%al, %al
	jne	.L315
	.loc 1 304 22
	leaq	-5136(%rbp), %rax
	addq	$4804, %rax
	movq	%rax, -104512(%rbp)
	leaq	.LC14(%rip), %rax
	movq	%rax, -104504(%rbp)
	movq	-104512(%rbp), %rbx
	movq	-104504(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_platform__valid_path@PLT
	.loc 1 304 22 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 1 304 13 is_stmt 1 discriminator 1
	testb	%al, %al
	jne	.L315
	.loc 1 305 36
	movl	-5112(%rbp), %eax
	cltq
	leaq	16777215(%rax), %rdx
	movl	-5108(%rbp), %eax
	cltq
	.loc 1 305 13
	cmpq	%rax, %rdx
	jge	.L316
.L315:
.LBB45:
	.loc 1 303 13 discriminator 4
	leaq	.LC80(%rip), %rax
	movq	%rax, -104496(%rbp)
	leaq	.LC23(%rip), %rax
	movq	%rax, -104488(%rbp)
	movq	-104496(%rbp), %rbx
	movq	-104488(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L316:
.LBE45:
	.loc 1 306 17
	leaq	-5136(%rbp), %rax
	addq	$4236, %rax
	movq	%rax, -104480(%rbp)
	leaq	.LC10(%rip), %rax
	movq	%rax, -104472(%rbp)
	movq	-104480(%rbp), %rbx
	movq	-104472(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_platform__valid_path@PLT
	.loc 1 306 13 discriminator 1
	xorl	$1, %eax
	.loc 1 306 10 discriminator 1
	testb	%al, %al
	jne	.L317
	.loc 1 306 51 discriminator 2
	leaq	-103776(%rbp), %rax
	movq	%rax, -104464(%rbp)
	leaq	.LC12(%rip), %rax
	movq	%rax, -104456(%rbp)
	movq	-104464(%rbp), %rbx
	movq	-104456(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_platform__valid_path@PLT
	.loc 1 306 47 discriminator 3
	xorl	$1, %eax
	.loc 1 306 39 discriminator 3
	testb	%al, %al
	jne	.L317
	.loc 1 307 24
	leaq	-5136(%rbp), %rax
	addq	$4804, %rax
	movq	%rax, -104448(%rbp)
	leaq	.LC14(%rip), %rax
	movq	%rax, -104440(%rbp)
	movq	-104448(%rbp), %rbx
	movq	-104440(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_platform__valid_path@PLT
	.loc 1 307 20 discriminator 1
	xorl	$1, %eax
	.loc 1 307 12 discriminator 1
	testb	%al, %al
	jne	.L317
	.loc 1 308 34
	movl	-5112(%rbp), %eax
	cltq
	leaq	16777215(%rax), %rdx
	movl	-5108(%rbp), %eax
	cltq
	.loc 1 308 12
	cmpq	%rax, %rdx
	jge	.L318
.L317:
.LBB46:
	.loc 1 310 13
	leaq	.LC81(%rip), %rax
	movq	%rax, -104432(%rbp)
	leaq	.LC24(%rip), %rax
	movq	%rax, -104424(%rbp)
	movq	-104432(%rbp), %rax
	movq	-104424(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	-104008(%rbp), %r10
	movl	$3, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver__failure.1
.LBE46:
	.loc 1 311 13
	movl	$0, %eax
	jmp	.L319
.L318:
	.loc 1 313 10
	leaq	-5136(%rbp), %rax
	addq	$4236, %rax
	movq	%rax, -104416(%rbp)
	leaq	.LC10(%rip), %r15
	movq	%r15, -104408(%rbp)
	movq	-103984(%rbp), %rax
	movq	-103976(%rbp), %rdx
	movq	-104416(%rbp), %rbx
	movq	-104408(%rbp), %rsi
	movq	%rbx, %rdi
	movq	%rdx, %rcx
	movq	%rax, %rdx
	call	silver_platform__write_file@PLT
	.loc 1 313 10 is_stmt 0 discriminator 1
	movb	%al, -337(%rbp)
	.loc 1 317 10 is_stmt 1
	movzbl	-337(%rbp), %eax
	testb	%al, %al
	je	.L320
.LBB47:
	.loc 1 318 13
	leaq	-5136(%rbp), %rax
	addq	$49, %rax
	movq	%rax, -104400(%rbp)
	leaq	.LC2(%rip), %rax
	movq	%rax, -104392(%rbp)
	leaq	-5136(%rbp), %rax
	addq	$4236, %rax
	movq	%rax, -104384(%rbp)
	movq	%r15, -104376(%rbp)
	movq	-103984(%rbp), %rax
	movq	-103976(%rbp), %rdx
	movq	-104384(%rbp), %rbx
	movq	-104376(%rbp), %rsi
	movq	%rbx, %rdi
	movq	-104008(%rbp), %r10
	movq	-104400(%rbp), %r8
	movq	-104392(%rbp), %r9
	movq	%rdx, %rcx
	movq	%rax, %rdx
	call	silver__same_source.10
	movq	%rax, %rdx
	.loc 1 318 13 is_stmt 0 discriminator 1
	movl	%edx, %eax
	movl	%eax, -5104(%rbp)
	movq	%rdx, %rax
	shrq	$32, %rax
	andb	$-1, %ah
	movb	%al, -337(%rbp)
.L320:
.LBE47:
	.loc 1 322 13 is_stmt 1
	movzbl	-337(%rbp), %eax
	xorl	$1, %eax
	.loc 1 322 10
	testb	%al, %al
	je	.L321
.LBB48:
	.loc 1 323 13
	leaq	.LC82(%rip), %rax
	movq	%rax, -104368(%rbp)
	leaq	.LC25(%rip), %rax
	movq	%rax, -104360(%rbp)
	movq	-104368(%rbp), %rax
	movq	-104360(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	-104008(%rbp), %r10
	movl	$3, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver__failure.1
.LBE48:
	.loc 1 324 13
	movl	$0, %eax
	jmp	.L319
.L321:
	.loc 1 326 10
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	je	.L322
	.loc 1 327 29
	leaq	-103968(%rbp), %rax
	movq	%rax, -104352(%rbp)
	leaq	.LC9(%rip), %rax
	movq	%rax, -104344(%rbp)
	leaq	-103504(%rbp), %rax
	movq	-104352(%rbp), %rcx
	movq	-104344(%rbp), %rbx
	movq	%rcx, %rsi
	movq	%rbx, %rcx
	movq	%rax, %rdx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver_libraries__capture_and_snapshot@PLT
	.loc 1 327 29 is_stmt 0 discriminator 1
	movb	%al, -337(%rbp)
	.loc 1 334 16 is_stmt 1
	movzbl	-337(%rbp), %eax
	xorl	$1, %eax
	.loc 1 334 13
	testb	%al, %al
	je	.L322
.LBB49:
	.loc 1 335 16
	leaq	.LC83(%rip), %rax
	movq	%rax, -104336(%rbp)
	leaq	.LC26(%rip), %rax
	movq	%rax, -104328(%rbp)
	movq	-104336(%rbp), %rax
	movq	-104328(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	-104008(%rbp), %r10
	movl	$3, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver__failure.1
.LBE49:
	.loc 1 336 16
	movl	$0, %eax
	jmp	.L319
.L322:
	.loc 1 339 10
	movq	-120(%rbp), %rax
	movq	%rax, -104320(%rbp)
	movl	$1, -184(%rbp)
	movl	-104(%rbp), %eax
	movl	%eax, -180(%rbp)
	leaq	-184(%rbp), %rax
	movq	%rax, -104312(%rbp)
	leaq	-103776(%rbp), %rax
	movq	%rax, -104304(%rbp)
	leaq	.LC12(%rip), %rax
	movq	%rax, -104296(%rbp)
	movq	-104304(%rbp), %rax
	movq	-104296(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rax
	movq	-104320(%rbp), %rdx
	movq	-104312(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_platform__write_file@PLT
	.loc 1 339 10 is_stmt 0 discriminator 1
	movb	%al, -337(%rbp)
	.loc 1 343 13 is_stmt 1
	movzbl	-337(%rbp), %eax
	xorl	$1, %eax
	.loc 1 343 10
	testb	%al, %al
	je	.L323
.LBB50:
	.loc 1 344 13
	leaq	.LC84(%rip), %rax
	movq	%rax, -104288(%rbp)
	leaq	.LC27(%rip), %rax
	movq	%rax, -104280(%rbp)
	movq	-104288(%rbp), %rax
	movq	-104280(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	-104008(%rbp), %r10
	movl	$3, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver__failure.1
.LBE50:
	.loc 1 345 13
	movl	$0, %eax
	jmp	.L319
.L323:
	.loc 1 348 10
	leaq	-5136(%rbp), %rax
	movq	%rax, %r10
	call	silver__compile__B_1__prove.3
	.loc 1 349 13
	movzbl	-337(%rbp), %eax
	xorl	$1, %eax
	.loc 1 349 10
	testb	%al, %al
	je	.L324
.LBB51:
	.loc 1 350 13
	leaq	.LC85(%rip), %rax
	movq	%rax, -104272(%rbp)
	leaq	.LC28(%rip), %rax
	movq	%rax, -104264(%rbp)
	movq	-104272(%rbp), %rax
	movq	-104264(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	-104008(%rbp), %r10
	movl	$3, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver__failure.1
.LBE51:
	.loc 1 351 13
	movl	$0, %eax
	jmp	.L319
.L324:
	.loc 1 353 10
	leaq	-5136(%rbp), %rax
	movq	%rax, %r10
	call	silver__compile__B_1__read_proof.7
	.loc 1 354 13
	movzbl	-334(%rbp), %eax
	xorl	$1, %eax
	.loc 1 354 10
	testb	%al, %al
	jne	.L325
	.loc 1 354 29 discriminator 1
	movzbl	-333(%rbp), %eax
	testb	%al, %al
	je	.L326
.L325:
.LBB52:
	.loc 1 355 13
	leaq	.LC86(%rip), %rax
	movq	%rax, -104256(%rbp)
	leaq	.LC29(%rip), %rax
	movq	%rax, -104248(%rbp)
	movq	-104256(%rbp), %rax
	movq	-104248(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	-104008(%rbp), %r10
	movl	$3, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver__failure.1
.LBE52:
	.loc 1 356 13
	movl	$0, %eax
	jmp	.L319
.L326:
	.loc 1 358 13
	movzbl	-335(%rbp), %eax
	xorl	$1, %eax
	.loc 1 358 10
	testb	%al, %al
	je	.L327
.LBB53:
	.loc 1 359 13
	leaq	.LC86(%rip), %rax
	movq	%rax, -104240(%rbp)
	leaq	.LC29(%rip), %rax
	movq	%rax, -104232(%rbp)
	movq	-104240(%rbp), %rax
	movq	-104232(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	-104008(%rbp), %r10
	movl	$3, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver__failure.1
.LBE53:
	.loc 1 360 13
	movl	$0, %eax
	jmp	.L319
.L327:
	.loc 1 362 10
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	je	.L328
	.loc 1 363 29
	leaq	-103968(%rbp), %rax
	movq	%rax, -104224(%rbp)
	leaq	.LC9(%rip), %rax
	movq	%rax, -104216(%rbp)
	movq	-104224(%rbp), %rbx
	movq	-104216(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_libraries__check_proof_evidence@PLT
	.loc 1 363 29 is_stmt 0 discriminator 1
	movb	%al, -809(%rbp)
	.loc 1 364 16 is_stmt 1
	movzbl	-809(%rbp), %eax
	xorl	$1, %eax
	.loc 1 364 13
	testb	%al, %al
	je	.L329
.LBB54:
	.loc 1 365 16
	leaq	.LC87(%rip), %rax
	movq	%rax, -104208(%rbp)
	leaq	.LC30(%rip), %rax
	movq	%rax, -104200(%rbp)
	movq	-104208(%rbp), %rax
	movq	-104200(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	-104008(%rbp), %r10
	movl	$3, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver__failure.1
.LBE54:
	.loc 1 366 16
	movl	$0, %eax
	jmp	.L319
.L329:
	.loc 1 368 29
	leaq	-103968(%rbp), %rax
	movq	%rax, -104192(%rbp)
	leaq	.LC9(%rip), %rax
	movq	%rax, -104184(%rbp)
	leaq	-103504(%rbp), %rax
	movq	-104192(%rbp), %rcx
	movq	-104184(%rbp), %rbx
	movq	%rcx, %rsi
	movq	%rbx, %rcx
	movq	%rax, %rdx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver_libraries__same_sources@PLT
	.loc 1 368 29 is_stmt 0 discriminator 1
	movb	%al, -337(%rbp)
	.loc 1 374 16 is_stmt 1
	movzbl	-337(%rbp), %eax
	xorl	$1, %eax
	.loc 1 374 13
	testb	%al, %al
	je	.L328
.LBB55:
	.loc 1 375 16
	leaq	.LC88(%rip), %rax
	movq	%rax, -104176(%rbp)
	leaq	.LC31(%rip), %rax
	movq	%rax, -104168(%rbp)
	movq	-104176(%rbp), %rax
	movq	-104168(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	-104008(%rbp), %r10
	movl	$3, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver__failure.1
.LBE55:
	.loc 1 376 16
	movl	$0, %eax
	jmp	.L319
.L328:
.LBB56:
	.loc 1 379 10
	leaq	-5136(%rbp), %rax
	addq	$49, %rax
	movq	%rax, -104160(%rbp)
	leaq	.LC2(%rip), %rax
	movq	%rax, -104152(%rbp)
	leaq	-5136(%rbp), %rax
	addq	$4236, %rax
	movq	%rax, -104144(%rbp)
	leaq	.LC10(%rip), %rax
	movq	%rax, -104136(%rbp)
	movq	-103984(%rbp), %rax
	movq	-103976(%rbp), %rdx
	movq	-104144(%rbp), %rbx
	movq	-104136(%rbp), %rsi
	movq	%rbx, %rdi
	movq	-104008(%rbp), %rbx
	movq	%rbx, %r10
	movq	-104160(%rbp), %r8
	movq	-104152(%rbp), %r9
	movq	%rdx, %rcx
	movq	%rax, %rdx
	call	silver__same_source.10
	movq	%rax, %rdx
	.loc 1 379 10 is_stmt 0 discriminator 1
	movl	%edx, %eax
	movl	%eax, -5104(%rbp)
	movq	%rdx, %rax
	shrq	$32, %rax
	andb	$-1, %ah
	movb	%al, -337(%rbp)
.LBE56:
	.loc 1 382 13 is_stmt 1
	movzbl	-337(%rbp), %eax
	xorl	$1, %eax
	.loc 1 382 10
	testb	%al, %al
	je	.L330
.LBB57:
	.loc 1 383 13
	leaq	.LC89(%rip), %rax
	movq	%rax, -104128(%rbp)
	leaq	.LC32(%rip), %rax
	movq	%rax, -104120(%rbp)
	movq	-104128(%rbp), %rax
	movq	-104120(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	%rbx, %r10
	movl	$3, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver__failure.1
.LBE57:
	.loc 1 384 13
	movl	$0, %eax
	jmp	.L319
.L330:
	.loc 1 386 10
	leaq	-5136(%rbp), %rax
	movq	%rax, %r10
	call	silver__compile__B_1__build.9
	.loc 1 387 13
	movzbl	-337(%rbp), %eax
	xorl	$1, %eax
	.loc 1 387 10
	testb	%al, %al
	je	.L331
.LBB58:
	.loc 1 388 13
	leaq	.LC90(%rip), %rax
	movq	%rax, -104112(%rbp)
	leaq	.LC16(%rip), %rax
	movq	%rax, -104104(%rbp)
	movq	-104112(%rbp), %rax
	movq	-104104(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	-104008(%rbp), %r10
	movl	$3, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver__failure.1
.LBE58:
	.loc 1 389 13
	movl	$0, %eax
	jmp	.L319
.L331:
.LBB59:
	.loc 1 391 10
	leaq	-5136(%rbp), %rax
	addq	$49, %rax
	movq	%rax, -104096(%rbp)
	leaq	.LC2(%rip), %rax
	movq	%rax, -104088(%rbp)
	leaq	-5136(%rbp), %rax
	addq	$4236, %rax
	movq	%rax, -104080(%rbp)
	leaq	.LC10(%rip), %rax
	movq	%rax, -104072(%rbp)
	movq	-103984(%rbp), %rax
	movq	-103976(%rbp), %rdx
	movq	-104080(%rbp), %rbx
	movq	-104072(%rbp), %rsi
	movq	%rbx, %rdi
	movq	-104008(%rbp), %rbx
	movq	%rbx, %r10
	movq	-104096(%rbp), %r8
	movq	-104088(%rbp), %r9
	movq	%rdx, %rcx
	movq	%rax, %rdx
	call	silver__same_source.10
	.loc 1 391 10 is_stmt 0 discriminator 1
	movl	%eax, %edx
	movl	%edx, -5104(%rbp)
	shrq	$32, %rax
	andb	$-1, %ah
	movb	%al, -337(%rbp)
.LBE59:
	.loc 1 392 13 is_stmt 1
	movzbl	-337(%rbp), %eax
	xorl	$1, %eax
	.loc 1 392 10
	testb	%al, %al
	je	.L332
.LBB60:
	.loc 1 393 13
	leaq	.LC91(%rip), %rax
	movq	%rax, -104064(%rbp)
	leaq	.LC33(%rip), %rax
	movq	%rax, -104056(%rbp)
	movq	-104064(%rbp), %rax
	movq	-104056(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	%rbx, %r10
	movl	$3, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver__failure.1
.LBE60:
	.loc 1 394 13
	movl	$0, %eax
	jmp	.L319
.L332:
	.loc 1 396 10
	movzbl	-223(%rbp), %eax
	testb	%al, %al
	je	.L333
	.loc 1 397 29
	leaq	-103968(%rbp), %rax
	movq	%rax, -104048(%rbp)
	leaq	.LC9(%rip), %rax
	movq	%rax, -104040(%rbp)
	leaq	-103504(%rbp), %rax
	movq	-104048(%rbp), %rcx
	movq	-104040(%rbp), %rbx
	movq	%rcx, %rsi
	movq	%rbx, %rcx
	movq	%rax, %rdx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver_libraries__same_sources@PLT
	.loc 1 397 29 is_stmt 0 discriminator 1
	movb	%al, -337(%rbp)
	.loc 1 402 16 is_stmt 1
	movzbl	-337(%rbp), %eax
	xorl	$1, %eax
	.loc 1 402 13
	testb	%al, %al
	je	.L333
.LBB61:
	.loc 1 403 16
	leaq	.LC92(%rip), %rax
	movq	%rax, -104032(%rbp)
	leaq	.LC25(%rip), %rax
	movq	%rax, -104024(%rbp)
	movq	-104032(%rbp), %rax
	movq	-104024(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	-104008(%rbp), %r10
	movl	$3, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver__failure.1
.LBE61:
	.loc 1 404 16
	movl	$0, %eax
	jmp	.L319
.L333:
	.loc 1 407 10
	leaq	-5136(%rbp), %rax
	movq	%rax, %r10
	call	silver__compile__B_1__publish.12
.LEHE20:
	.loc 1 408 10
	movl	$2, %eax
.L319:
.LEHB21:
	.loc 1 408 10 is_stmt 0 discriminator 1
	movq	-105008(%rbp), %rsp
	.loc 1 408 10 discriminator 2
	cmpl	$1, %eax
	je	.L334
	cmpl	$2, %eax
	jne	.L186
	.loc 1 408 10 discriminator 3
	nop
.LBE37:
	.loc 1 409 8 is_stmt 1
	jmp	.L186
.L337:
	movq	%rax, -104016(%rbp)
	movl	$1, %eax
	jmp	.L319
.L334:
	movq	-104016(%rbp), %rax
	movq	%rax, %rdi
	call	_Unwind_Resume@PLT
.L186:
.LBE32:
	leaq	-40(%rbp), %rsp
.LEHE21:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE7:
	.section	.gcc_except_table
.LLSDA7:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE7-.LLSDACSB7
.LLSDACSB7:
	.uleb128 .LEHB13-.LFB7
	.uleb128 .LEHE13-.LEHB13
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB14-.LFB7
	.uleb128 .LEHE14-.LEHB14
	.uleb128 .L337-.LFB7
	.uleb128 0
	.uleb128 .LEHB15-.LFB7
	.uleb128 .LEHE15-.LEHB15
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB16-.LFB7
	.uleb128 .LEHE16-.LEHB16
	.uleb128 .L337-.LFB7
	.uleb128 0
	.uleb128 .LEHB17-.LFB7
	.uleb128 .LEHE17-.LEHB17
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB18-.LFB7
	.uleb128 .LEHE18-.LEHB18
	.uleb128 .L337-.LFB7
	.uleb128 0
	.uleb128 .LEHB19-.LFB7
	.uleb128 .LEHE19-.LEHB19
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB20-.LFB7
	.uleb128 .LEHE20-.LEHB20
	.uleb128 .L337-.LFB7
	.uleb128 0
	.uleb128 .LEHB21-.LFB7
	.uleb128 .LEHE21-.LEHB21
	.uleb128 0
	.uleb128 0
.LLSDACSE7:
	.text
	.size	silver__compile.2, .-silver__compile.2
	.section	.rodata
	.align 8
.LC93:
	.ascii	"failed precondition from silver.adb:203"
	.text
	.align 2
	.type	silver__compile__B_1__prove.3, @function
silver__compile__B_1__prove.3:
.LFB10:
	.loc 1 202 10
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -72(%rbp)
	.loc 1 203 36
	movq	16(%rbx), %rcx
	movq	%rcx, %rax
	movl	$1, -64(%rbp)
	movl	40(%rbx), %ecx
	movl	%ecx, -60(%rbp)
	leaq	-64(%rbp), %rcx
	movq	%rcx, %rdx
	movq	(%rbx), %rcx
	movq	%rax, %rsi
	movq	%rdx, %rax
	movq	%rcx, %r10
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver__valid_command.4
	.loc 1 203 36 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L339
.LBB62:
	.loc 1 203 36 discriminator 2
	leaq	.LC93(%rip), %r12
	leaq	.LC34(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L339:
.LBE62:
	.loc 1 210 13 is_stmt 1
	movq	16(%rbx), %rax
	movq	%rax, %r14
	movl	$1, -56(%rbp)
	movl	40(%rbx), %eax
	movl	%eax, -52(%rbp)
	leaq	-56(%rbp), %rax
	movq	%rax, %r15
	movq	(%rbx), %rax
	movq	%r14, %rcx
	movq	%r15, %rdx
	movq	%rax, %r10
	movq	%rcx, %rdi
	movq	%rdx, %rsi
	call	silver__execute.5
	.loc 1 210 13 is_stmt 0 discriminator 1
	movb	%al, 4799(%rbx)
	.loc 1 215 14 is_stmt 1
	nop
	addq	$40, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE10:
	.size	silver__compile__B_1__prove.3, .-silver__compile__B_1__prove.3
	.section	.rodata
	.align 8
.LC94:
	.ascii	"failed precondition from silver.adb:219"
	.align 8
.LC95:
	.ascii	"failed precondition from silver.adb:220"
	.align 8
.LC96:
	.ascii	"failed precondition from silver.adb:221"
	.align 8
.LC97:
	.ascii	"failed precondition from silver.adb:222"
	.align 8
.LC98:
	.ascii	"failed precondition from silver.adb:223"
	.text
	.align 2
	.type	silver__compile__B_1__build.9, @function
silver__compile__B_1__build.9:
.LFB11:
	.loc 1 217 10
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -56(%rbp)
	.loc 1 219 14
	leaq	4328(%rbx), %rax
	movq	%rax, %rsi
	leaq	.LC22(%rip), %rdi
	movq	(%rbx), %rax
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	movq	%rax, %r10
	movq	%rcx, %rdi
	movq	%rdx, %rsi
	call	silver__valid_command.4
	.loc 1 219 14 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L342
.LBB63:
	.loc 1 219 14 discriminator 2
	leaq	.LC94(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC34(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rcx
	movq	-136(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L342:
.LBE63:
	.loc 1 219 14 discriminator 3
	movzbl	4802(%rbx), %eax
	xorl	$1, %eax
	testb	%al, %al
	je	.L343
.LBB64:
	.loc 1 219 14 discriminator 4
	leaq	.LC95(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC34(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rcx
	movq	-120(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L343:
.LBE64:
	.loc 1 219 14 discriminator 5
	movzbl	4803(%rbx), %eax
	testb	%al, %al
	je	.L344
.LBB65:
	.loc 1 219 14 discriminator 6
	leaq	.LC95(%rip), %rax
	movq	%rax, -112(%rbp)
	leaq	.LC34(%rip), %rax
	movq	%rax, -104(%rbp)
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L344:
.LBE65:
	.loc 1 219 14 discriminator 7
	movl	44(%rbx), %eax
	cmpl	$16777216, %eax
	jle	.L345
.LBB66:
	.loc 1 219 14 discriminator 8
	leaq	.LC96(%rip), %rax
	movq	%rax, -96(%rbp)
	leaq	.LC34(%rip), %rax
	movq	%rax, -88(%rbp)
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L345:
.LBE66:
	.loc 1 219 14 discriminator 9
	movzbl	4801(%rbx), %eax
	xorl	$1, %eax
	testb	%al, %al
	je	.L346
.LBB67:
	.loc 1 219 14 discriminator 10
	leaq	.LC97(%rip), %r14
	leaq	.LC34(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L346:
.LBE67:
	.loc 1 223 24 is_stmt 1
	movzbl	4913(%rbx), %eax
	testb	%al, %al
	je	.L347
	.loc 1 223 24 is_stmt 0 discriminator 1
	movzbl	4327(%rbx), %eax
	xorl	$1, %eax
	jmp	.L348
.L347:
	.loc 1 223 24 discriminator 2
	movl	$0, %eax
.L348:
	.loc 1 219 14 is_stmt 1 discriminator 11
	testb	%al, %al
	je	.L349
.LBB68:
	.loc 1 219 14 is_stmt 0 discriminator 12
	leaq	.LC98(%rip), %r12
	leaq	.LC34(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L349:
.LBE68:
	.loc 1 241 13 is_stmt 1
	leaq	4328(%rbx), %rax
	movq	%rax, -80(%rbp)
	leaq	.LC22(%rip), %rax
	movq	%rax, -72(%rbp)
	movq	(%rbx), %rax
	movq	-80(%rbp), %rsi
	movq	-72(%rbp), %rdi
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	movq	%rax, %r10
	movq	%rcx, %rdi
	movq	%rdx, %rsi
	call	silver__execute.5
	.loc 1 241 13 is_stmt 0 discriminator 1
	movb	%al, 4799(%rbx)
	.loc 1 246 14 is_stmt 1
	nop
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE11:
	.size	silver__compile__B_1__build.9, .-silver__compile__B_1__build.9
	.align 2
	.type	silver__compile__B_1__publish__B267b___finalizer.13, @function
silver__compile__B_1__publish__B267b___finalizer.13:
.LFB13:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE13:
	.size	silver__compile__B_1__publish__B267b___finalizer.13, .-silver__compile__B_1__publish__B267b___finalizer.13
	.section	.rodata
	.align 8
.LC99:
	.ascii	"failed precondition from silver.adb:250"
	.align 8
.LC100:
	.ascii	"failed precondition from silver.adb:251"
	.align 8
.LC101:
	.ascii	"failed precondition from silver.adb:252"
	.align 8
.LC102:
	.ascii	"failed precondition from silver.adb:253"
	.align 8
.LC103:
	.ascii	"failed precondition from silver.adb:254"
	.align 8
.LC104:
	.ascii	"failed precondition from silver.adb:255"
	.align 8
.LC105:
	.ascii	"failed precondition from silver.adb:256"
	.align 8
.LC106:
	.ascii	"failed precondition from silver.adb:257"
	.align 8
.LC107:
	.ascii	"failed precondition from silver.adb:258"
	.align 8
.LC108:
	.ascii	"failed precondition from silver.adb:259"
.LC109:
	.ascii	"Source: "
.LC110:
	.ascii	"Proof: "
.LC111:
	.ascii	"Executable: "
	.align 8
.LC112:
	.ascii	"Execution failed: application did not exit normally."
.LC113:
	.ascii	"."
.LC114:
	.ascii	"Execution returned status "
	.align 8
.LC115:
	.ascii	"Execution completed successfully."
	.align 8
.LC35:
	.long	1
	.long	8
	.align 8
.LC36:
	.long	1
	.long	99
	.align 8
.LC37:
	.long	1
	.long	7
	.align 8
.LC38:
	.long	1
	.long	116
	.align 8
.LC39:
	.long	1
	.long	103
	.align 8
.LC40:
	.long	1
	.long	52
	.align 8
.LC41:
	.long	1
	.long	1
	.align 8
.LC42:
	.long	1
	.long	26
	.align 8
.LC43:
	.long	1
	.long	33
	.text
	.align 2
	.type	silver__compile__B_1__publish.12, @function
silver__compile__B_1__publish.12:
.LFB12:
	.loc 1 248 10
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA12
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB22:
	subq	$760, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %r14
	movq	%r10, -264(%rbp)
	.loc 1 248 10
	leaq	16(%rbp), %rax
	.loc 1 248 10 is_stmt 0 discriminator 1
	movq	%rax, -104(%rbp)
	.loc 1 250 14 is_stmt 1
	leaq	4236(%r14), %rax
	movq	%rax, %rcx
	leaq	.LC10(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_platform__valid_path@PLT
	.loc 1 250 14 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L354
.LBB69:
	.loc 1 250 14 discriminator 2
	leaq	.LC99(%rip), %r12
	leaq	.LC34(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L354:
.LBE69:
	.loc 1 250 45 is_stmt 1 discriminator 3
	leaq	4804(%r14), %rax
	movq	%rax, -800(%rbp)
	leaq	.LC14(%rip), %rax
	movq	%rax, -792(%rbp)
	movq	-800(%rbp), %rbx
	movq	-792(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_platform__valid_path@PLT
	.loc 1 250 45 is_stmt 0 discriminator 4
	xorl	$1, %eax
	.loc 1 250 14 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L355
.LBB70:
	.loc 1 250 14 is_stmt 0 discriminator 5
	leaq	.LC99(%rip), %rax
	movq	%rax, -784(%rbp)
	leaq	.LC34(%rip), %rax
	movq	%rax, -776(%rbp)
	movq	-784(%rbp), %rbx
	movq	-776(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L355:
.LBE70:
	.loc 1 251 23 is_stmt 1
	leaq	4145(%r14), %rax
	movq	%rax, -768(%rbp)
	leaq	.LC10(%rip), %rax
	movq	%rax, -760(%rbp)
	movq	-768(%rbp), %rbx
	movq	-760(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_platform__valid_path@PLT
	.loc 1 251 23 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 1 250 14 is_stmt 1 discriminator 6
	testb	%al, %al
	je	.L356
.LBB71:
	.loc 1 250 14 is_stmt 0 discriminator 7
	leaq	.LC100(%rip), %rax
	movq	%rax, -752(%rbp)
	leaq	.LC34(%rip), %rax
	movq	%rax, -744(%rbp)
	movq	-752(%rbp), %rbx
	movq	-744(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L356:
.LBE71:
	.loc 1 252 55 is_stmt 1
	call	ada__command_line__argument_count@PLT
	movl	%eax, %edx
	.loc 1 252 38 discriminator 1
	movl	36(%r14), %eax
	cmpl	%edx, %eax
	setle	%al
	xorl	$1, %eax
	.loc 1 250 14 discriminator 8
	testb	%al, %al
	je	.L357
.LBB72:
	.loc 1 250 14 is_stmt 0 discriminator 9
	leaq	.LC101(%rip), %rax
	movq	%rax, -736(%rbp)
	leaq	.LC34(%rip), %rax
	movq	%rax, -728(%rbp)
	movq	-736(%rbp), %rbx
	movq	-728(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L357:
.LBE72:
	.loc 1 250 14 discriminator 10
	movzbl	4802(%r14), %eax
	xorl	$1, %eax
	testb	%al, %al
	je	.L358
.LBB73:
	.loc 1 250 14 discriminator 11
	leaq	.LC102(%rip), %rax
	movq	%rax, -720(%rbp)
	leaq	.LC34(%rip), %rax
	movq	%rax, -712(%rbp)
	movq	-720(%rbp), %rcx
	movq	-712(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L358:
.LBE73:
	.loc 1 250 14 discriminator 12
	movzbl	4803(%r14), %eax
	testb	%al, %al
	je	.L359
.LBB74:
	.loc 1 250 14 discriminator 13
	leaq	.LC102(%rip), %rax
	movq	%rax, -704(%rbp)
	leaq	.LC34(%rip), %rax
	movq	%rax, -696(%rbp)
	movq	-704(%rbp), %rcx
	movq	-696(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L359:
.LBE74:
	.loc 1 250 14 discriminator 14
	movl	44(%r14), %eax
	cmpl	$16777216, %eax
	jle	.L360
.LBB75:
	.loc 1 250 14 discriminator 15
	leaq	.LC103(%rip), %rax
	movq	%rax, -688(%rbp)
	leaq	.LC34(%rip), %rax
	movq	%rax, -680(%rbp)
	movq	-688(%rbp), %rcx
	movq	-680(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L360:
.LBE75:
	.loc 1 250 14 discriminator 16
	movzbl	4801(%r14), %eax
	xorl	$1, %eax
	testb	%al, %al
	je	.L361
.LBB76:
	.loc 1 250 14 discriminator 17
	leaq	.LC104(%rip), %rax
	movq	%rax, -672(%rbp)
	leaq	.LC34(%rip), %rax
	movq	%rax, -664(%rbp)
	movq	-672(%rbp), %rcx
	movq	-664(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L361:
.LBE76:
	.loc 1 256 24 is_stmt 1
	movzbl	4913(%r14), %eax
	testb	%al, %al
	je	.L362
	.loc 1 256 24 is_stmt 0 discriminator 1
	movzbl	4327(%r14), %eax
	xorl	$1, %eax
	jmp	.L363
.L362:
	.loc 1 256 24 discriminator 2
	movl	$0, %eax
.L363:
	.loc 1 250 14 is_stmt 1 discriminator 18
	testb	%al, %al
	je	.L364
.LBB77:
	.loc 1 250 14 is_stmt 0 discriminator 19
	leaq	.LC105(%rip), %rax
	movq	%rax, -656(%rbp)
	leaq	.LC34(%rip), %rax
	movq	%rax, -648(%rbp)
	movq	-656(%rbp), %rcx
	movq	-648(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L364:
.LBE77:
	.loc 1 257 27 is_stmt 1
	movzbl	4913(%r14), %eax
	xorl	$1, %eax
	.loc 1 257 24
	testb	%al, %al
	je	.L365
	.loc 1 257 62 discriminator 1
	movq	8(%r14), %rax
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	___ghost_silver_profile__is_member@PLT
	.loc 1 257 24 discriminator 2
	xorl	$1, %eax
	jmp	.L366
.L365:
	.loc 1 257 24 is_stmt 0 discriminator 3
	movl	$0, %eax
.L366:
	.loc 1 250 14 is_stmt 1 discriminator 20
	testb	%al, %al
	je	.L367
.LBB78:
	.loc 1 250 14 is_stmt 0 discriminator 21
	leaq	.LC106(%rip), %rax
	movq	%rax, -640(%rbp)
	leaq	.LC34(%rip), %rax
	movq	%rax, -632(%rbp)
	movq	-640(%rbp), %rcx
	movq	-632(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L367:
.LBE78:
	.loc 1 250 14 discriminator 22
	movzbl	4799(%r14), %eax
	xorl	$1, %eax
	testb	%al, %al
	je	.L368
.LBB79:
	.loc 1 250 14 discriminator 23
	leaq	.LC107(%rip), %rax
	movq	%rax, -624(%rbp)
	leaq	.LC34(%rip), %rax
	movq	%rax, -616(%rbp)
	movq	-624(%rbp), %rcx
	movq	-616(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L368:
.LBE79:
	.loc 1 250 14 discriminator 24
	movl	32(%r14), %eax
	cmpl	$4096, %eax
	jle	.L369
.LBB80:
	.loc 1 250 14 discriminator 25
	leaq	.LC107(%rip), %rax
	movq	%rax, -608(%rbp)
	leaq	.LC34(%rip), %rax
	movq	%rax, -600(%rbp)
	movq	-608(%rbp), %rcx
	movq	-600(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L369:
.LBE80:
	.loc 1 259 38 is_stmt 1
	movl	32(%r14), %ecx
	.loc 1 259 35
	testl	%ecx, %ecx
	jle	.L370
	.loc 1 259 35 is_stmt 0 discriminator 1
	cmpl	$4096, %ecx
	jle	.L370
	.loc 1 259 35 discriminator 2
	leaq	.LC48(%rip), %rax
	movl	$259, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L370:
	.loc 1 259 23 is_stmt 1 discriminator 3
	movl	$0, %eax
	testl	%ecx, %ecx
	cmovns	%ecx, %eax
	movslq	%eax, %rsi
	.loc 1 259 53 discriminator 3
	testl	%ecx, %ecx
	jg	.L371
	.loc 1 259 53 is_stmt 0 discriminator 4
	movl	28(%r14), %edx
	movl	24(%r14), %eax
	cmpl	%eax, %edx
	jl	.L372
.L371:
	.loc 1 259 53 discriminator 5
	movl	$0, %eax
	testl	%ecx, %ecx
	cmovns	%ecx, %eax
	movslq	%eax, %rcx
	movl	28(%r14), %edx
	movl	24(%r14), %eax
	cmpl	%eax, %edx
	jl	.L373
	.loc 1 259 53 discriminator 6
	movl	28(%r14), %eax
	movslq	%eax, %rdx
	movl	24(%r14), %eax
	cltq
	subq	%rax, %rdx
	leaq	1(%rdx), %rax
	jmp	.L374
.L373:
	.loc 1 259 53 discriminator 7
	movl	$0, %eax
.L374:
	.loc 1 259 53 discriminator 8
	cmpq	%rcx, %rax
	jne	.L375
	.loc 1 259 53 discriminator 9
	movq	8(%r14), %rax
	movq	(%rax), %rcx
	leaq	49(%r14), %rax
	movq	%rsi, %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcmp@PLT
	.loc 1 259 53 discriminator 10
	testl	%eax, %eax
	jne	.L375
.L372:
	.loc 1 259 53 discriminator 11
	movl	$1, %eax
	jmp	.L376
.L375:
	.loc 1 259 53 discriminator 12
	movl	$0, %eax
.L376:
	.loc 1 259 53 discriminator 13
	xorl	$1, %eax
	.loc 1 250 14 is_stmt 1 discriminator 26
	testb	%al, %al
	je	.L377
.LBB81:
	.loc 1 250 14 is_stmt 0 discriminator 27
	leaq	.LC108(%rip), %rax
	movq	%rax, -592(%rbp)
	leaq	.LC34(%rip), %rax
	movq	%rax, -584(%rbp)
	movq	-592(%rbp), %rcx
	movq	-584(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L377:
.LBE81:
.LBB82:
.LBB83:
	.loc 1 279 34 is_stmt 1
	leaq	4236(%r14), %rax
	movq	%rax, -576(%rbp)
	leaq	.LC10(%rip), %r13
	movq	%r13, -568(%rbp)
	leaq	.LC109(%rip), %rax
	movq	%rax, -560(%rbp)
	leaq	.LC35(%rip), %rax
	movq	%rax, -552(%rbp)
	leaq	-256(%rbp), %rax
	movq	%rax, -544(%rbp)
	leaq	.LC36(%rip), %rbx
	movq	%rbx, -536(%rbp)
	movq	-544(%rbp), %rax
	movq	-536(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rax
	movq	-576(%rbp), %r8
	movq	-568(%rbp), %r9
	movq	-560(%rbp), %rdx
	movq	-552(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	system__concat_2__str_concat_2@PLT
.LBE83:
	.loc 1 279 13 discriminator 1
	leaq	-256(%rbp), %rax
	movq	%rax, -528(%rbp)
	movq	%rbx, -520(%rbp)
	movq	-528(%rbp), %rcx
	movq	-520(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	ada__text_io__put_line__2@PLT
.LBE82:
.LBB84:
.LBB85:
	.loc 1 280 33
	leaq	4804(%r14), %rax
	movq	%rax, -512(%rbp)
	leaq	.LC14(%rip), %rax
	movq	%rax, -504(%rbp)
	leaq	.LC110(%rip), %rax
	movq	%rax, -496(%rbp)
	leaq	.LC37(%rip), %rax
	movq	%rax, -488(%rbp)
	leaq	-256(%rbp), %rax
	movq	%rax, -480(%rbp)
	leaq	.LC38(%rip), %rbx
	movq	%rbx, -472(%rbp)
	movq	-480(%rbp), %rax
	movq	-472(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rax
	movq	-512(%rbp), %r8
	movq	-504(%rbp), %r9
	movq	-496(%rbp), %rdx
	movq	-488(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	system__concat_2__str_concat_2@PLT
.LBE85:
	.loc 1 280 13 discriminator 1
	leaq	-256(%rbp), %rax
	movq	%rax, -464(%rbp)
	movq	%rbx, -456(%rbp)
	movq	-464(%rbp), %rcx
	movq	-456(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	ada__text_io__put_line__2@PLT
.LBE84:
.LBB86:
.LBB87:
	.loc 1 281 38
	leaq	4145(%r14), %rax
	movq	%rax, -448(%rbp)
	movq	%r13, -440(%rbp)
	leaq	.LC111(%rip), %rax
	movq	%rax, -432(%rbp)
	leaq	.LC11(%rip), %rax
	movq	%rax, -424(%rbp)
	leaq	-256(%rbp), %rax
	movq	%rax, -416(%rbp)
	leaq	.LC39(%rip), %rbx
	movq	%rbx, -408(%rbp)
	movq	-416(%rbp), %rax
	movq	-408(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rax
	movq	-448(%rbp), %r8
	movq	-440(%rbp), %r9
	movq	-432(%rbp), %rdx
	movq	-424(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	system__concat_2__str_concat_2@PLT
.LBE87:
	.loc 1 281 13 discriminator 1
	leaq	-256(%rbp), %rax
	movq	%rax, -400(%rbp)
	movq	%rbx, -392(%rbp)
	movq	-400(%rbp), %rcx
	movq	-392(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	ada__text_io__put_line__2@PLT
.LBE86:
	.loc 1 282 13
	movzbl	48(%r14), %eax
	testb	%al, %al
	je	.L395
	.loc 1 283 16
	leaq	4145(%r14), %rax
	movq	%rax, -384(%rbp)
	movq	%r13, -376(%rbp)
	movl	36(%r14), %eax
	movq	-384(%rbp), %rcx
	movq	-376(%rbp), %rbx
	movq	%rcx, %rsi
	movq	%rbx, %rcx
	movl	%eax, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver_platform__run_application@PLT
	.loc 1 283 16 is_stmt 0 discriminator 1
	movl	%eax, -52(%rbp)
	.loc 1 284 16 is_stmt 1
	cmpl	$0, -52(%rbp)
	js	.L379
	.loc 1 284 26 discriminator 1
	cmpl	$255, -52(%rbp)
	jle	.L380
.L379:
.LBB88:
	.loc 1 285 19
	leaq	.LC112(%rip), %rax
	movq	%rax, -368(%rbp)
	leaq	.LC40(%rip), %rax
	movq	%rax, -360(%rbp)
	movq	(%r14), %rax
	movq	-368(%rbp), %rcx
	movq	-360(%rbp), %rbx
	movq	%rcx, %rsi
	movq	%rbx, %rcx
	movq	%rax, %r10
	movl	$3, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver__failure.1
.LBE88:
	.loc 1 286 19
	jmp	.L394
.L380:
	.loc 1 288 30
	movl	-52(%rbp), %eax
	movl	%eax, %edi
	call	__gnat_set_exit_status@PLT
.LEHE22:
	.loc 1 289 16
	cmpl	$0, -52(%rbp)
	je	.L382
	leaq	-128(%rbp), %rax
	movq	%rax, %rdi
.LEHB23:
	call	system__secondary_stack__ss_mark@PLT
.LBB89:
	.loc 1 290 84
	cmpl	$0, -52(%rbp)
	jns	.L383
	.loc 1 290 84 is_stmt 0 discriminator 1
	leaq	.LC48(%rip), %rax
	movl	$290, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L383:
	.loc 1 290 74 is_stmt 1 discriminator 2
	movl	-52(%rbp), %eax
	movl	%eax, %edi
	call	silver_numbers__decimal@PLT
	.loc 1 290 74 is_stmt 0 discriminator 3
	movq	%rax, %r12
	movq	%rdx, %r13
	.loc 1 290 92 is_stmt 1 discriminator 3
	movq	%r13, %rax
	movl	4(%rax), %edx
	movq	%r13, %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L384
	.loc 1 290 92 is_stmt 0 discriminator 4
	movq	%r13, %rax
	movl	4(%rax), %edx
	movq	%r13, %rax
	movl	(%rax), %eax
	subl	%eax, %edx
	leal	1(%rdx), %eax
	jmp	.L385
.L384:
	.loc 1 290 92 discriminator 5
	movl	$0, %eax
.L385:
	.loc 1 290 92 discriminator 6
	addl	$26, %eax
	addl	$1, %eax
	movl	%eax, -56(%rbp)
	movl	-56(%rbp), %eax
	cltq
	movq	%rax, -64(%rbp)
	movl	-56(%rbp), %eax
	cltq
	movl	$1, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_allocate@PLT
	.loc 1 290 92 discriminator 7
	movq	%rax, %rbx
	movq	%rbx, -72(%rbp)
.LBB90:
	leaq	.LC113(%rip), %rax
	movq	%rax, -352(%rbp)
	leaq	.LC41(%rip), %rax
	movq	%rax, -344(%rbp)
	leaq	.LC114(%rip), %rax
	movq	%rax, -336(%rbp)
	leaq	.LC42(%rip), %rax
	movq	%rax, -328(%rbp)
	movq	%rbx, -320(%rbp)
	movl	$1, -88(%rbp)
	movl	-56(%rbp), %eax
	movl	%eax, -84(%rbp)
	leaq	-88(%rbp), %rax
	movq	%rax, -312(%rbp)
	movq	-320(%rbp), %rax
	movq	-312(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rax
	pushq	-344(%rbp)
	pushq	-352(%rbp)
	movq	%r12, %r8
	movq	%r13, %r9
	movq	-336(%rbp), %rdx
	movq	-328(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	.cfi_escape 0x2e,0x10
	call	system__concat_3__str_concat_3@PLT
	addq	$16, %rsp
.LBE90:
	.loc 1 290 19 is_stmt 1 discriminator 8
	movq	%rbx, -304(%rbp)
	movl	$1, -80(%rbp)
	movl	-56(%rbp), %eax
	movl	%eax, -76(%rbp)
	leaq	-80(%rbp), %rax
	movq	%rax, -296(%rbp)
	movq	-304(%rbp), %rsi
	movq	-296(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	.cfi_escape 0x2e,0
	call	ada__text_io__put_line__2@PLT
.LEHE23:
	.loc 1 290 0 discriminator 9
	movl	$1, %ebx
.L389:
	.loc 1 290 0 is_stmt 0 discriminator 10
	leaq	-128(%rbp), %rax
	movq	%rax, %r10
.LEHB24:
	call	silver__compile__B_1__publish__B267b___finalizer.13
.LEHE24:
	.loc 1 290 0 discriminator 11
	cmpl	$1, %ebx
	jne	.L386
	.loc 1 290 0 discriminator 13
	movl	$1, %eax
.L391:
	.loc 1 290 0 discriminator 14
	cmpl	$1, %eax
	jne	.L387
	.loc 1 290 0 discriminator 15
	nop
.LBE89:
	.loc 1 291 19 is_stmt 1
	jmp	.L394
.L382:
.LBB91:
	.loc 1 293 16
	leaq	.LC115(%rip), %rax
	movq	%rax, -288(%rbp)
	leaq	.LC43(%rip), %rax
	movq	%rax, -280(%rbp)
	movq	-288(%rbp), %rcx
	movq	-280(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
.LEHB25:
	call	ada__text_io__put_line__2@PLT
.LBE91:
	.loc 1 295 14
	jmp	.L395
.L392:
	movq	%rax, -272(%rbp)
	movl	$0, %ebx
.LBB92:
	.loc 1 290 19 discriminator 16
	jmp	.L389
.L386:
	movq	-272(%rbp), %r15
	jmp	.L390
.L393:
	movq	%rax, %r15
.L390:
	movl	$0, %eax
	jmp	.L391
.L387:
	movq	%r15, %rax
	movq	%rax, %rdi
	call	_Unwind_Resume@PLT
.L395:
.LBE92:
	.loc 1 295 14
	nop
.L394:
	leaq	-40(%rbp), %rsp
.LEHE25:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE12:
	.section	.gcc_except_table
.LLSDA12:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE12-.LLSDACSB12
.LLSDACSB12:
	.uleb128 .LEHB22-.LFB12
	.uleb128 .LEHE22-.LEHB22
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB23-.LFB12
	.uleb128 .LEHE23-.LEHB23
	.uleb128 .L392-.LFB12
	.uleb128 0
	.uleb128 .LEHB24-.LFB12
	.uleb128 .LEHE24-.LEHB24
	.uleb128 .L393-.LFB12
	.uleb128 0
	.uleb128 .LEHB25-.LFB12
	.uleb128 .LEHE25-.LEHB25
	.uleb128 0
	.uleb128 0
.LLSDACSE12:
	.text
	.size	silver__compile__B_1__publish.12, .-silver__compile__B_1__publish.12
	.align 2
	.type	silver__valid_command.4, @function
silver__valid_command.4:
.LFB14:
	.loc 1 29 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$48, %rsp
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -32(%rbp)
	movq	%rdx, -24(%rbp)
	movq	%r10, -40(%rbp)
	.loc 1 29 4
	movq	-24(%rbp), %rax
	movl	(%rax), %esi
	movq	-24(%rbp), %rax
	movl	4(%rax), %ecx
	movq	-24(%rbp), %rax
	movl	4(%rax), %edx
	movq	-24(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L397
	.loc 1 29 4 is_stmt 0 discriminator 1
	movq	-24(%rbp), %rax
	movl	4(%rax), %edi
	movslq	%edi, %rax
	cqto
	movq	-24(%rbp), %rdi
	movl	(%rdi), %edi
	movslq	%edi, %rdi
	movq	%rdi, %r8
	movq	%rdi, %r9
	sarq	$63, %r9
	subq	%r8, %rax
	sbbq	%r9, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L398
.L397:
	.loc 1 29 4 discriminator 2
	movl	$0, %eax
	movl	$0, %edx
.L398:
.LBB93:
	.loc 1 30 22 is_stmt 1
	movl	%eax, %edi
	.loc 1 31 7
	testl	%edi, %edi
	jle	.L399
	.loc 1 30 22 discriminator 1
	cmpl	$16384, %eax
	jg	.L399
	.loc 1 31 17 discriminator 1
	movl	$1, %r10d
	cmpl	%ecx, %esi
	jg	.L400
.LBB94:
	.loc 1 31 17 is_stmt 0 discriminator 2
	movl	%esi, %eax
.L405:
.LBB95:
	.loc 1 31 17 discriminator 3
	cmpl	%eax, %esi
	jg	.L401
	.loc 1 31 17 discriminator 4
	cmpl	%eax, %ecx
	jge	.L402
.L401:
	.loc 1 31 17 discriminator 5
	leaq	.LC48(%rip), %rax
	movl	$31, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L402:
	.loc 1 31 25 is_stmt 1 discriminator 6
	movq	-32(%rbp), %r8
	movq	-24(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdi
	movslq	%eax, %rdx
	movq	%rdx, %r9
	subq	%rdi, %r9
	leaq	(%r8,%r9), %rdi
	movq	%rdi, -8(%rbp)
	.loc 1 31 49 discriminator 6
	movq	-32(%rbp), %rdi
	movq	-24(%rbp), %r8
	movl	(%r8), %r8d
	movslq	%r8d, %r8
	subq	%r8, %rdx
	movzbl	(%rdi,%rdx), %edx
	.loc 1 31 17 discriminator 6
	testb	%dl, %dl
	jne	.L403
	.loc 1 31 17 is_stmt 0 discriminator 7
	movl	$0, %r10d
	jmp	.L400
.L403:
.LBE95:
	.loc 1 31 17 discriminator 8
	cmpl	%ecx, %eax
	je	.L400
	.loc 1 31 17 discriminator 9
	addl	$1, %eax
	jmp	.L405
.L400:
.LBE94:
	.loc 1 31 7 is_stmt 1 discriminator 10
	testb	%r10b, %r10b
	je	.L399
	.loc 1 31 7 is_stmt 0 discriminator 11
	movl	$1, %eax
	jmp	.L406
.L399:
	.loc 1 31 7 discriminator 12
	movl	$0, %eax
.L406:
.LBE93:
	.loc 1 29 4 is_stmt 1
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE14:
	.size	silver__valid_command.4, .-silver__valid_command.4
	.align 2
	.type	silver__B366b___finalizer.0, @function
silver__B366b___finalizer.0:
.LFB15:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	addq	$24, %rax
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE15:
	.size	silver__B366b___finalizer.0, .-silver__B366b___finalizer.0
	.align 2
	.type	silver__B_2___finalizer.14, @function
silver__B_2___finalizer.14:
.LFB16:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE16:
	.size	silver__B_2___finalizer.14, .-silver__B_2___finalizer.14
.Letext0:
	.file 2 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_library_reports.ads"
	.file 3 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_libraries.ads"
	.file 4 "<built-in>"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0xb24
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x20
	.long	.LASF104
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.long	.LLRL2
	.quad	0
	.long	.Ldebug_line0
	.uleb128 0xe
	.sleb128 -2147483648
	.sleb128 2147483647
	.long	.LASF2
	.long	0x42
	.uleb128 0xf
	.long	0x2a
	.uleb128 0x10
	.byte	0x4
	.long	.LASF26
	.uleb128 0xe
	.sleb128 0
	.sleb128 2147483647
	.long	.LASF3
	.long	0x5c
	.uleb128 0xf
	.long	0x48
	.uleb128 0xa
	.byte	0x4
	.byte	0x5
	.long	.LASF4
	.uleb128 0xa
	.byte	0x1
	.byte	0x2
	.long	.LASF5
	.uleb128 0xf
	.long	0x63
	.uleb128 0xd
	.long	.LASF11
	.long	0x84
	.long	0x84
	.uleb128 0x3
	.long	0x5c
	.sleb128 82
	.byte	0
	.uleb128 0xa
	.byte	0x1
	.byte	0x8
	.long	.LASF6
	.uleb128 0x15
	.long	.LASF13
	.byte	0x2
	.byte	0xc
	.long	0xaf
	.uleb128 0x7
	.long	.LASF7
	.byte	0
	.uleb128 0x7
	.long	.LASF8
	.byte	0x1
	.uleb128 0x7
	.long	.LASF9
	.byte	0x2
	.uleb128 0x7
	.long	.LASF10
	.byte	0x3
	.byte	0
	.uleb128 0x1
	.long	0x84
	.long	0xc2
	.uleb128 0x3
	.long	0x5c
	.sleb128 16777216
	.byte	0
	.uleb128 0xd
	.long	.LASF12
	.long	0x84
	.long	0xd8
	.uleb128 0x3
	.long	0x5c
	.sleb128 16384
	.byte	0
	.uleb128 0x15
	.long	.LASF14
	.byte	0x3
	.byte	0x8
	.long	0x108
	.uleb128 0x7
	.long	.LASF15
	.byte	0
	.uleb128 0x7
	.long	.LASF16
	.byte	0x1
	.uleb128 0x7
	.long	.LASF17
	.byte	0x2
	.uleb128 0x7
	.long	.LASF18
	.byte	0x3
	.uleb128 0x7
	.long	.LASF19
	.byte	0x4
	.uleb128 0x7
	.long	.LASF20
	.byte	0x5
	.byte	0
	.uleb128 0xd
	.long	.LASF21
	.long	0xc2
	.long	0x11b
	.uleb128 0x16
	.long	0xd8
	.byte	0
	.uleb128 0xe
	.sleb128 0
	.sleb128 16384
	.long	.LASF22
	.long	0x5c
	.uleb128 0xd
	.long	.LASF23
	.long	0x11b
	.long	0x13b
	.uleb128 0x16
	.long	0xd8
	.byte	0
	.uleb128 0x21
	.long	.LASF100
	.long	0x18018
	.byte	0x3
	.byte	0xf
	.byte	0x9
	.long	0x169
	.uleb128 0x11
	.long	.LASF24
	.byte	0x3
	.byte	0x10
	.byte	0x7
	.long	0x108
	.byte	0
	.uleb128 0x22
	.long	.LASF25
	.byte	0x3
	.byte	0x11
	.byte	0x7
	.long	0x128
	.long	0x18000
	.byte	0
	.uleb128 0x10
	.byte	0x8
	.long	.LASF27
	.uleb128 0xa
	.byte	0x1
	.byte	0x7
	.long	.LASF28
	.uleb128 0xa
	.byte	0x8
	.byte	0x7
	.long	.LASF29
	.uleb128 0x10
	.byte	0x8
	.long	.LASF30
	.uleb128 0x23
	.long	.LASF105
	.byte	0x1
	.byte	0x12
	.byte	0x1
	.long	.LASF106
	.quad	.LFB1
	.quad	.LFE1-.LFB1
	.uleb128 0x1
	.byte	0x9c
	.long	0xa65
	.uleb128 0x17
	.byte	0x13
	.long	0xa71
	.uleb128 0x17
	.byte	0x14
	.long	0xa78
	.uleb128 0x12
	.long	.LASF44
	.byte	0x16
	.byte	0x4
	.quad	.LFB2
	.quad	.LFE2-.LFB2
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -64
	.byte	0x6
	.byte	0x23
	.uleb128 0x30
	.byte	0x6
	.long	0x1f2
	.uleb128 0x5
	.long	.LASF31
	.byte	0x16
	.byte	0x17
	.long	0xac1
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0x5
	.long	.LASF32
	.byte	0x16
	.byte	0x29
	.long	0x3d
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.byte	0
	.uleb128 0x13
	.long	.LASF34
	.byte	0x1d
	.long	0x63
	.quad	.LFB14
	.quad	.LFE14-.LFB14
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -56
	.byte	0x6
	.byte	0x23
	.uleb128 0x30
	.byte	0x6
	.long	0x248
	.uleb128 0x5
	.long	.LASF33
	.byte	0x1d
	.byte	0x1c
	.long	0xadf
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0xb
	.quad	.LBB95
	.quad	.LBE95-.LBB95
	.uleb128 0x2
	.long	.LASF42
	.byte	0x1f
	.byte	0x19
	.long	0xb16
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.byte	0
	.byte	0
	.uleb128 0x13
	.long	.LASF35
	.byte	0x21
	.long	0x63
	.quad	.LFB3
	.quad	.LFE3-.LFB3
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -120
	.byte	0x6
	.byte	0x23
	.uleb128 0x30
	.byte	0x6
	.long	0x2c1
	.uleb128 0x5
	.long	.LASF33
	.byte	0x21
	.byte	0x17
	.long	0xac6
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x5
	.long	.LASF36
	.byte	0x21
	.byte	0x29
	.long	0x63
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0xb
	.quad	.LBB18
	.quad	.LBE18-.LBB18
	.uleb128 0x18
	.long	.LASF83
	.quad	.LFB4
	.quad	.LFE4-.LFB4
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -40
	.byte	0x6
	.byte	0x23
	.uleb128 0x18
	.byte	0x6
	.byte	0
	.byte	0
	.uleb128 0x24
	.byte	0x8
	.byte	0x1
	.byte	0x30
	.byte	0xe
	.long	0x2e5
	.uleb128 0x11
	.long	.LASF37
	.byte	0x1
	.byte	0x32
	.byte	0x7
	.long	0x48
	.byte	0
	.uleb128 0x11
	.long	.LASF36
	.byte	0x1
	.byte	0x32
	.byte	0x1b
	.long	0x63
	.byte	0x4
	.byte	0
	.uleb128 0x13
	.long	.LASF38
	.byte	0x30
	.long	0x2c1
	.quad	.LFB5
	.quad	.LFE5-.LFB5
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -184
	.byte	0x6
	.byte	0x23
	.uleb128 0x30
	.byte	0x6
	.long	0x39c
	.uleb128 0x5
	.long	.LASF39
	.byte	0x31
	.byte	0x7
	.long	0xad5
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x5
	.long	.LASF40
	.byte	0x31
	.byte	0xd
	.long	0xad0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0x5
	.long	.LASF41
	.byte	0x31
	.byte	0x20
	.long	0xacb
	.uleb128 0x3
	.byte	0x91
	.sleb128 -176
	.uleb128 0x5
	.long	.LASF37
	.byte	0x32
	.byte	0x7
	.long	0x48
	.uleb128 0x5
	.byte	0x91
	.sleb128 -128
	.byte	0x23
	.uleb128 0x28
	.uleb128 0x5
	.long	.LASF36
	.byte	0x32
	.byte	0x1b
	.long	0x63
	.uleb128 0x5
	.byte	0x91
	.sleb128 -128
	.byte	0x23
	.uleb128 0x2c
	.uleb128 0xb
	.quad	.LBB21
	.quad	.LBE21-.LBB21
	.uleb128 0x25
	.long	.LASF107
	.quad	.LFB6
	.quad	.LFE6-.LFB6
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -56
	.byte	0x6
	.byte	0x23
	.uleb128 0x30
	.byte	0x6
	.uleb128 0x2
	.long	.LASF43
	.byte	0x3c
	.byte	0x7
	.long	0x63
	.uleb128 0x2
	.byte	0x91
	.sleb128 -33
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x12
	.long	.LASF45
	.byte	0x43
	.byte	0x4
	.quad	.LFB7
	.quad	.LFE7-.LFB7
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -104016
	.byte	0x6
	.byte	0x23
	.uleb128 0x30
	.byte	0x6
	.long	0x951
	.uleb128 0x5
	.long	.LASF46
	.byte	0x44
	.byte	0x7
	.long	0xada
	.uleb128 0x4
	.byte	0x91
	.sleb128 -104000
	.uleb128 0x5
	.long	.LASF47
	.byte	0x44
	.byte	0x18
	.long	0x6a
	.uleb128 0x6
	.byte	0x91
	.sleb128 -5152
	.byte	0x23
	.uleb128 0x1331
	.uleb128 0x5
	.long	.LASF48
	.byte	0x44
	.byte	0x25
	.long	0x6a
	.uleb128 0x5
	.byte	0x91
	.sleb128 -5152
	.byte	0x23
	.uleb128 0x30
	.uleb128 0x5
	.long	.LASF49
	.byte	0x44
	.byte	0x3a
	.long	0x57
	.uleb128 0x5
	.byte	0x91
	.sleb128 -5152
	.byte	0x23
	.uleb128 0x24
	.uleb128 0xb
	.quad	.LBB32
	.quad	.LBE32-.LBB32
	.uleb128 0x2
	.long	.LASF50
	.byte	0x4b
	.byte	0x7
	.long	0x6f
	.uleb128 0x4
	.byte	0x91
	.sleb128 -103984
	.uleb128 0x2
	.long	.LASF36
	.byte	0x4c
	.byte	0x7
	.long	0x63
	.uleb128 0x6
	.byte	0x91
	.sleb128 -5152
	.byte	0x23
	.uleb128 0x12bf
	.uleb128 0xb
	.quad	.LBB37
	.quad	.LBE37-.LBB37
	.uleb128 0x2
	.long	.LASF51
	.byte	0x55
	.byte	0xa
	.long	0x63
	.uleb128 0x3
	.byte	0x91
	.sleb128 -65
	.uleb128 0x2
	.long	.LASF52
	.byte	0x56
	.byte	0xa
	.long	0x63
	.uleb128 0x3
	.byte	0x91
	.sleb128 -66
	.uleb128 0x2
	.long	.LASF53
	.byte	0x57
	.byte	0xa
	.long	0x8b
	.uleb128 0x6
	.byte	0x91
	.sleb128 -5152
	.byte	0x23
	.uleb128 0x12c0
	.uleb128 0x1
	.long	0x84
	.long	0x48b
	.uleb128 0x3
	.long	0x5c
	.sleb128 91
	.byte	0
	.uleb128 0x4
	.long	.LASF55
	.long	0x47a
	.uleb128 0x6
	.byte	0x91
	.sleb128 -5152
	.byte	0x23
	.uleb128 0x108c
	.uleb128 0x1
	.long	0x84
	.long	0x4ac
	.uleb128 0x3
	.long	0x5c
	.sleb128 91
	.byte	0
	.uleb128 0x2
	.long	.LASF54
	.byte	0x5d
	.byte	0xa
	.long	0x4bb
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x6
	.long	0x49b
	.uleb128 0x1
	.long	0x84
	.long	0x4d1
	.uleb128 0x3
	.long	0x5c
	.sleb128 94
	.byte	0
	.uleb128 0x4
	.long	.LASF56
	.long	0x4c0
	.uleb128 0x4
	.byte	0x91
	.sleb128 -103792
	.uleb128 0x1
	.long	0x84
	.long	0x4f0
	.uleb128 0x3
	.long	0x5c
	.sleb128 94
	.byte	0
	.uleb128 0x2
	.long	.LASF57
	.byte	0x5e
	.byte	0xa
	.long	0x4ff
	.uleb128 0x3
	.byte	0x91
	.sleb128 -88
	.uleb128 0x6
	.long	0x4df
	.uleb128 0x1
	.long	0x84
	.long	0x515
	.uleb128 0x3
	.long	0x5c
	.sleb128 109
	.byte	0
	.uleb128 0x4
	.long	.LASF58
	.long	0x504
	.uleb128 0x6
	.byte	0x91
	.sleb128 -5152
	.byte	0x23
	.uleb128 0x12c4
	.uleb128 0x1
	.long	0x84
	.long	0x536
	.uleb128 0x3
	.long	0x5c
	.sleb128 109
	.byte	0
	.uleb128 0x2
	.long	.LASF59
	.byte	0x5f
	.byte	0xa
	.long	0x545
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x6
	.long	0x525
	.uleb128 0x1
	.long	0x84
	.long	0x55b
	.uleb128 0x3
	.long	0x5c
	.sleb128 91
	.byte	0
	.uleb128 0x4
	.long	.LASF60
	.long	0x54a
	.uleb128 0x6
	.byte	0x91
	.sleb128 -5152
	.byte	0x23
	.uleb128 0x1031
	.uleb128 0x1
	.long	0x84
	.long	0x57c
	.uleb128 0x3
	.long	0x5c
	.sleb128 91
	.byte	0
	.uleb128 0x2
	.long	.LASF61
	.byte	0x60
	.byte	0xa
	.long	0x58b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -104
	.uleb128 0x6
	.long	0x56b
	.uleb128 0x1
	.long	0x84
	.long	0x5a1
	.uleb128 0x3
	.long	0x5c
	.sleb128 82
	.byte	0
	.uleb128 0x4
	.long	.LASF62
	.long	0x590
	.uleb128 0x4
	.byte	0x91
	.sleb128 -103888
	.uleb128 0x1
	.long	0x84
	.long	0x5c0
	.uleb128 0x3
	.long	0x5c
	.sleb128 82
	.byte	0
	.uleb128 0x2
	.long	.LASF63
	.byte	0x63
	.byte	0xa
	.long	0x5cf
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x6
	.long	0x5af
	.uleb128 0x26
	.string	"lf"
	.byte	0x1
	.byte	0x66
	.byte	0xa
	.long	0x84
	.uleb128 0x3
	.byte	0x91
	.sleb128 -113
	.uleb128 0x1
	.long	0x84
	.long	0x5f4
	.uleb128 0x3
	.long	0x5c
	.sleb128 168
	.byte	0
	.uleb128 0x4
	.long	.LASF64
	.long	0x5e3
	.uleb128 0x4
	.byte	0x91
	.sleb128 -103696
	.uleb128 0x4
	.long	.LASF65
	.long	0x5c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -120
	.uleb128 0x1
	.long	0x84
	.long	0x622
	.uleb128 0xc
	.long	0x5c
	.long	0x602
	.byte	0
	.uleb128 0x4
	.long	.LASF66
	.long	0x60f
	.uleb128 0x4
	.byte	0x91
	.sleb128 -136
	.byte	0x6
	.uleb128 0x1
	.long	0x84
	.long	0x643
	.uleb128 0xc
	.long	0x5c
	.long	0x602
	.byte	0
	.uleb128 0x2
	.long	.LASF67
	.byte	0x67
	.byte	0xa
	.long	0x652
	.uleb128 0x3
	.byte	0x91
	.sleb128 -152
	.uleb128 0x6
	.long	0x630
	.uleb128 0x1
	.long	0x84
	.long	0x667
	.uleb128 0x3
	.long	0x5c
	.sleb128 20
	.byte	0
	.uleb128 0x4
	.long	.LASF68
	.long	0x657
	.uleb128 0x3
	.byte	0x91
	.sleb128 -5184
	.uleb128 0x4
	.long	.LASF69
	.long	0x5c
	.uleb128 0x5
	.byte	0x91
	.sleb128 -5152
	.byte	0x23
	.uleb128 0x28
	.uleb128 0x1
	.long	0x84
	.long	0x696
	.uleb128 0xc
	.long	0x5c
	.long	0x674
	.byte	0
	.uleb128 0x4
	.long	.LASF70
	.long	0x683
	.uleb128 0x6
	.byte	0x91
	.sleb128 -5152
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0x1
	.long	0x84
	.long	0x6b9
	.uleb128 0xc
	.long	0x5c
	.long	0x674
	.byte	0
	.uleb128 0x2
	.long	.LASF71
	.byte	0x7b
	.byte	0xa
	.long	0x6c8
	.uleb128 0x3
	.byte	0x91
	.sleb128 -176
	.uleb128 0x6
	.long	0x6a6
	.uleb128 0x1
	.long	0x84
	.long	0x6de
	.uleb128 0x3
	.long	0x5c
	.sleb128 471
	.byte	0
	.uleb128 0x4
	.long	.LASF72
	.long	0x6cd
	.uleb128 0x6
	.byte	0x91
	.sleb128 -5152
	.byte	0x23
	.uleb128 0x10e8
	.uleb128 0x1
	.long	0x84
	.long	0x6ff
	.uleb128 0x3
	.long	0x5c
	.sleb128 471
	.byte	0
	.uleb128 0x2
	.long	.LASF73
	.byte	0x82
	.byte	0xa
	.long	0x70e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -184
	.uleb128 0x6
	.long	0x6ee
	.uleb128 0x1
	.long	0x84
	.long	0x724
	.uleb128 0x3
	.long	0x5c
	.sleb128 4096
	.byte	0
	.uleb128 0x2
	.long	.LASF41
	.byte	0x84
	.byte	0xa
	.long	0x713
	.uleb128 0x5
	.byte	0x91
	.sleb128 -5152
	.byte	0x23
	.uleb128 0x31
	.uleb128 0x2
	.long	.LASF74
	.byte	0x86
	.byte	0xa
	.long	0x48
	.uleb128 0x5
	.byte	0x91
	.sleb128 -5152
	.byte	0x23
	.uleb128 0x20
	.uleb128 0x2
	.long	.LASF75
	.byte	0x87
	.byte	0xa
	.long	0xb1b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -192
	.uleb128 0x2
	.long	.LASF76
	.byte	0x88
	.byte	0xa
	.long	0x48
	.uleb128 0x5
	.byte	0x91
	.sleb128 -5152
	.byte	0x23
	.uleb128 0x2c
	.uleb128 0x2
	.long	.LASF77
	.byte	0x89
	.byte	0xa
	.long	0x63
	.uleb128 0x6
	.byte	0x91
	.sleb128 -5152
	.byte	0x23
	.uleb128 0x12c2
	.uleb128 0x2
	.long	.LASF78
	.byte	0x8a
	.byte	0xa
	.long	0x63
	.uleb128 0x6
	.byte	0x91
	.sleb128 -5152
	.byte	0x23
	.uleb128 0x12c3
	.uleb128 0x2
	.long	.LASF79
	.byte	0x8b
	.byte	0xa
	.long	0x63
	.uleb128 0x6
	.byte	0x91
	.sleb128 -5152
	.byte	0x23
	.uleb128 0x12c1
	.uleb128 0x2
	.long	.LASF80
	.byte	0x8c
	.byte	0xa
	.long	0x13b
	.uleb128 0x4
	.byte	0x91
	.sleb128 -103520
	.uleb128 0x2
	.long	.LASF81
	.byte	0x8e
	.byte	0xa
	.long	0x63
	.uleb128 0x6
	.byte	0x91
	.sleb128 -5152
	.byte	0x23
	.uleb128 0x10e7
	.uleb128 0x12
	.long	.LASF82
	.byte	0xa2
	.byte	0xa
	.quad	.LFB8
	.quad	.LFE8-.LFB8
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0x23
	.uleb128 0x1338
	.byte	0x6
	.long	0x804
	.uleb128 0x18
	.long	.LASF84
	.quad	.LFB9
	.quad	.LFE9-.LFB9
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0
	.uleb128 0x19
	.long	.LASF85
	.byte	0xca
	.quad	.LFB10
	.quad	.LFE10-.LFB10
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0x23
	.uleb128 0x1338
	.byte	0x6
	.uleb128 0x19
	.long	.LASF86
	.byte	0xd9
	.quad	.LFB11
	.quad	.LFE11-.LFB11
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -72
	.byte	0x6
	.byte	0x23
	.uleb128 0x1338
	.byte	0x6
	.uleb128 0x27
	.long	.LASF108
	.byte	0x1
	.byte	0xf8
	.byte	0xa
	.quad	.LFB12
	.quad	.LFE12-.LFB12
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -280
	.byte	0x6
	.byte	0x23
	.uleb128 0x1338
	.byte	0x6
	.uleb128 0x8
	.long	.LASF32
	.value	0x115
	.byte	0xd
	.long	0xb20
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x14
	.quad	.LBB82
	.quad	.LBE82-.LBB82
	.long	0x8ad
	.uleb128 0x1
	.long	0x84
	.long	0x89f
	.uleb128 0x3
	.long	0x5c
	.sleb128 99
	.byte	0
	.uleb128 0x4
	.long	.LASF87
	.long	0x88e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -272
	.byte	0
	.uleb128 0x14
	.quad	.LBB84
	.quad	.LBE84-.LBB84
	.long	0x8e1
	.uleb128 0x1
	.long	0x84
	.long	0x8d3
	.uleb128 0x3
	.long	0x5c
	.sleb128 116
	.byte	0
	.uleb128 0x4
	.long	.LASF88
	.long	0x8c2
	.uleb128 0x3
	.byte	0x91
	.sleb128 -272
	.byte	0
	.uleb128 0x14
	.quad	.LBB86
	.quad	.LBE86-.LBB86
	.long	0x915
	.uleb128 0x1
	.long	0x84
	.long	0x907
	.uleb128 0x3
	.long	0x5c
	.sleb128 103
	.byte	0
	.uleb128 0x4
	.long	.LASF89
	.long	0x8f6
	.uleb128 0x3
	.byte	0x91
	.sleb128 -272
	.byte	0
	.uleb128 0x1a
	.long	.LLRL1
	.uleb128 0x4
	.long	.LASF90
	.long	0x5c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x1
	.long	0x84
	.long	0x93a
	.uleb128 0xc
	.long	0x5c
	.long	0x91a
	.byte	0
	.uleb128 0x4
	.long	.LASF91
	.long	0x947
	.uleb128 0x3
	.byte	0x91
	.sleb128 -88
	.uleb128 0x6
	.long	0x927
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x1a
	.long	.LLRL0
	.uleb128 0x4
	.long	.LASF92
	.long	0x5c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x4
	.long	.LASF93
	.long	0x5c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x1
	.long	0x84
	.long	0x987
	.uleb128 0x1b
	.long	0x5c
	.long	0x956
	.long	0x963
	.byte	0
	.uleb128 0x8
	.long	.LASF33
	.value	0x1a8
	.byte	0x7
	.long	0x997
	.uleb128 0x3
	.byte	0x91
	.sleb128 -104
	.uleb128 0x6
	.long	0x970
	.uleb128 0x4
	.long	.LASF94
	.long	0x5c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -108
	.uleb128 0x4
	.long	.LASF95
	.long	0x5c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	0x84
	.long	0x9cd
	.uleb128 0x1b
	.long	0x5c
	.long	0x99c
	.long	0x9a9
	.byte	0
	.uleb128 0x8
	.long	.LASF39
	.value	0x1a9
	.byte	0x7
	.long	0x9dd
	.uleb128 0x3
	.byte	0x91
	.sleb128 -136
	.uleb128 0x6
	.long	0x9b6
	.uleb128 0x1
	.long	0x84
	.long	0x9f3
	.uleb128 0x3
	.long	0x5c
	.sleb128 4096
	.byte	0
	.uleb128 0x8
	.long	.LASF46
	.value	0x1aa
	.byte	0x7
	.long	0x9e2
	.uleb128 0x3
	.byte	0x91
	.sleb128 -4320
	.uleb128 0x8
	.long	.LASF37
	.value	0x1ab
	.byte	0x7
	.long	0x48
	.uleb128 0x3
	.byte	0x91
	.sleb128 -140
	.uleb128 0x8
	.long	.LASF43
	.value	0x1ac
	.byte	0x7
	.long	0x63
	.uleb128 0x3
	.byte	0x91
	.sleb128 -141
	.uleb128 0x8
	.long	.LASF36
	.value	0x1ac
	.byte	0x11
	.long	0x63
	.uleb128 0x3
	.byte	0x91
	.sleb128 -142
	.uleb128 0x8
	.long	.LASF96
	.value	0x1ad
	.byte	0x7
	.long	0x63
	.uleb128 0x3
	.byte	0x91
	.sleb128 -143
	.uleb128 0x8
	.long	.LASF97
	.value	0x1ad
	.byte	0x16
	.long	0x63
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x8
	.long	.LASF49
	.value	0x1ae
	.byte	0x7
	.long	0x48
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.uleb128 0x28
	.string	"ada"
	.byte	0x1
	.byte	0x1
	.byte	0x6
	.long	0xa78
	.uleb128 0x1c
	.long	.LASF98
	.byte	0x2
	.byte	0
	.uleb128 0x1c
	.long	.LASF99
	.byte	0x5
	.uleb128 0x29
	.long	.LASF101
	.byte	0x10
	.byte	0x4
	.byte	0
	.long	0xac1
	.uleb128 0x1d
	.long	.LASF102
	.long	0xa94
	.byte	0
	.uleb128 0x1e
	.long	0xae4
	.uleb128 0x2a
	.byte	0x8
	.byte	0x4
	.byte	0
	.long	0xab6
	.uleb128 0x1f
	.string	"LB0"
	.long	0xb03
	.byte	0
	.uleb128 0x1f
	.string	"UB0"
	.long	0xb03
	.byte	0x4
	.byte	0
	.uleb128 0x1d
	.long	.LASF103
	.long	0xb11
	.byte	0x8
	.byte	0
	.uleb128 0x9
	.long	0xa7e
	.uleb128 0x9
	.long	0xa7e
	.uleb128 0x9
	.long	0xa7e
	.uleb128 0x9
	.long	0xa7e
	.uleb128 0x9
	.long	0xa7e
	.uleb128 0x9
	.long	0xa7e
	.uleb128 0x9
	.long	0xa7e
	.uleb128 0x1
	.long	0x84
	.long	0xb03
	.uleb128 0x2b
	.long	0x5c
	.uleb128 0x6
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x94
	.byte	0x4
	.uleb128 0x8
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x23
	.uleb128 0x4
	.byte	0x94
	.byte	0x4
	.byte	0
	.uleb128 0x2c
	.sleb128 2147483647
	.long	.LASF109
	.long	0x5c
	.uleb128 0x1e
	.long	0xa99
	.uleb128 0x6
	.long	0x84
	.uleb128 0x6
	.long	0xaf
	.uleb128 0xa
	.byte	0x4
	.byte	0x5
	.long	.LASF4
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x10
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x28
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x1c
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0xd
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0x21
	.sleb128 5
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x14
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x15
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3e
	.uleb128 0x21
	.sleb128 7
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x16
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x2f
	.uleb128 0x21
	.sleb128 5
	.byte	0
	.byte	0
	.uleb128 0x17
	.uleb128 0x3a
	.byte	0
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x18
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x18
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x19
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 10
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x1a
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x55
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x1b
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1c
	.uleb128 0x1e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 6
	.byte	0
	.byte	0
	.uleb128 0x1d
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x1e
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1f
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x20
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x55
	.uleb128 0x17
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x21
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0x6
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x22
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0x6
	.byte	0
	.byte	0
	.uleb128 0x23
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x24
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x25
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x26
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x27
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x28
	.uleb128 0x1e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x29
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x2a
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x2b
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x18
	.uleb128 0x2f
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x2c
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x3c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.LFE11-.Ltext0
	.quad	.LFB12
	.quad	.LFE14-.LFB12
	.quad	0
	.quad	0
	.section	.debug_rnglists,"",@progbits
.Ldebug_ranges0:
	.long	.Ldebug_ranges3-.Ldebug_ranges2
.Ldebug_ranges2:
	.value	0x5
	.byte	0x8
	.byte	0
	.long	0
.LLRL0:
	.byte	0x5
	.quad	.LBB5
	.byte	0x4
	.uleb128 .LBB5-.LBB5
	.uleb128 .LBE5-.LBB5
	.byte	0x4
	.uleb128 .LBB17-.LBB5
	.uleb128 .LBE17-.LBB5
	.byte	0
.LLRL1:
	.byte	0x5
	.quad	.LBB89
	.byte	0x4
	.uleb128 .LBB89-.LBB89
	.uleb128 .LBE89-.LBB89
	.byte	0x4
	.uleb128 .LBB92-.LBB89
	.uleb128 .LBE92-.LBB89
	.byte	0
.LLRL2:
	.byte	0x7
	.quad	.Ltext0
	.uleb128 .LFE11-.Ltext0
	.byte	0x7
	.quad	.LFB12
	.uleb128 .LFE14-.LFB12
	.byte	0
.Ldebug_ranges3:
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF59:
	.string	"report_name"
.LASF102:
	.string	"P_ARRAY"
.LASF60:
	.string	"S53b"
.LASF71:
	.string	"proof_command"
.LASF73:
	.string	"build_command"
.LASF72:
	.string	"S158b"
.LASF74:
	.string	"observed_last"
.LASF26:
	.string	"ada__command_line__Texit_statusB"
.LASF52:
	.string	"assignment_mode"
.LASF57:
	.string	"project"
.LASF81:
	.string	"runtime_evidence_complete"
.LASF105:
	.string	"silver"
.LASF2:
	.string	"ada__command_line__exit_status"
.LASF89:
	.string	"S264b"
.LASF35:
	.string	"silver__execute"
.LASF68:
	.string	"C136b"
.LASF80:
	.string	"library_sources"
.LASF3:
	.string	"natural"
.LASF99:
	.string	"silver_platform"
.LASF49:
	.string	"skip_arguments"
.LASF34:
	.string	"silver__valid_command"
.LASF106:
	.string	"_ada_silver"
.LASF28:
	.string	"system__storage_elements__storage_element"
.LASF4:
	.string	"integer"
.LASF56:
	.string	"S47b"
.LASF29:
	.string	"system__address"
.LASF23:
	.string	"silver_libraries__length_array"
.LASF107:
	.string	"silver__same_source___wrapped_statements"
.LASF58:
	.string	"S50b"
.LASF53:
	.string	"application_kind"
.LASF97:
	.string	"output_accepted"
.LASF43:
	.string	"too_long"
.LASF87:
	.string	"S258b"
.LASF50:
	.string	"directory"
.LASF85:
	.string	"silver__compile__B_1__prove"
.LASF88:
	.string	"S261b"
.LASF30:
	.string	"system__storage_elements__Tstorage_offsetB"
.LASF76:
	.string	"report_last"
.LASF54:
	.string	"snapshot"
.LASF19:
	.string	"silver_libraries__arguments_implementation"
.LASF79:
	.string	"report_complete"
.LASF77:
	.string	"report_read"
.LASF27:
	.string	"system__parameters__Tsize_typeB"
.LASF46:
	.string	"source"
.LASF55:
	.string	"S44b"
.LASF6:
	.string	"character"
.LASF93:
	.string	"B380b"
.LASF39:
	.string	"name"
.LASF103:
	.string	"P_BOUNDS"
.LASF69:
	.string	"silver__compile__B_1__TTS153bSP1___U"
.LASF14:
	.string	"silver_libraries__unit_kind"
.LASF25:
	.string	"lengths"
.LASF63:
	.string	"shell_directory"
.LASF82:
	.string	"silver__compile__B_1__read_proof"
.LASF38:
	.string	"silver__same_source"
.LASF65:
	.string	"silver__compile__B_1__TTS105bSP1___U"
.LASF44:
	.string	"silver__failure"
.LASF45:
	.string	"silver__compile"
.LASF91:
	.string	"S276b"
.LASF7:
	.string	"silver_library_reports__static_output"
.LASF47:
	.string	"output_mode"
.LASF10:
	.string	"silver_library_reports__selected_output"
.LASF37:
	.string	"last"
.LASF108:
	.string	"silver__compile__B_1__publish"
.LASF32:
	.string	"status"
.LASF16:
	.string	"silver_libraries__io_implementation"
.LASF8:
	.string	"silver_library_reports__argument_output"
.LASF41:
	.string	"observed"
.LASF9:
	.string	"silver_library_reports__assigned_output"
.LASF22:
	.string	"silver_libraries__source_length"
.LASF104:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF90:
	.string	"silver__compile__B_1__publish__B267b__TA277bP1___U"
.LASF94:
	.string	"B382b"
.LASF75:
	.string	"report"
.LASF20:
	.string	"silver_libraries__runtime_interface"
.LASF70:
	.string	"S153b"
.LASF95:
	.string	"B386b"
.LASF40:
	.string	"expected"
.LASF11:
	.string	"silver_platform__workspace_path"
.LASF31:
	.string	"message"
.LASF24:
	.string	"bytes"
.LASF86:
	.string	"silver__compile__B_1__build"
.LASF96:
	.string	"null_accepted"
.LASF51:
	.string	"argument_mode"
.LASF64:
	.string	"C63b"
.LASF61:
	.string	"executable"
.LASF67:
	.string	"project_text"
.LASF15:
	.string	"silver_libraries__io_specification"
.LASF17:
	.string	"silver_libraries__imported_interface"
.LASF84:
	.string	"silver__compile__B_1__read_proof___wrapped_statements"
.LASF66:
	.string	"S105b"
.LASF92:
	.string	"B376b"
.LASF42:
	.string	"item"
.LASF78:
	.string	"report_too_long"
.LASF83:
	.string	"silver__execute___wrapped_statements"
.LASF98:
	.string	"text_io"
.LASF21:
	.string	"silver_libraries__buffer_array"
.LASF48:
	.string	"run_after"
.LASF18:
	.string	"silver_libraries__arguments_specification"
.LASF101:
	.string	"string"
.LASF12:
	.string	"silver_libraries__source_buffer"
.LASF36:
	.string	"success"
.LASF13:
	.string	"silver_library_reports__application_kind"
.LASF100:
	.string	"silver_libraries__source_set"
.LASF62:
	.string	"S59b"
.LASF33:
	.string	"command"
.LASF5:
	.string	"boolean"
.LASF109:
	.string	"positive"
	.section	.debug_line_str,"MS",@progbits,1
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver.adb"
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
	.hidden	DW.ref.__gnat_personality_v0
	.weak	DW.ref.__gnat_personality_v0
	.section	.data.rel.local.DW.ref.__gnat_personality_v0,"awG",@progbits,DW.ref.__gnat_personality_v0,comdat
	.align 8
	.type	DW.ref.__gnat_personality_v0, @object
	.size	DW.ref.__gnat_personality_v0, 8
DW.ref.__gnat_personality_v0:
	.quad	__gnat_personality_v0
	.globl	__gnat_personality_v0
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
