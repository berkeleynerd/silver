	.file	"silver_libc.ads"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_libc.ads"
	.globl	silver_libc_E
	.data
	.align 2
	.type	silver_libc_E, @object
	.size	silver_libc_E, 2
silver_libc_E:
	.zero	2
	.text
.Letext0:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_libc.ads"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x128
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x5
	.long	.LASF20
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.long	.Ldebug_line0
	.uleb128 0x6
	.byte	0
	.byte	0xff
	.long	.LASF21
	.long	0x29
	.uleb128 0x3
	.byte	0x1
	.byte	0x8
	.long	.LASF2
	.uleb128 0x4
	.byte	0x8
	.long	.LASF4
	.uleb128 0x7
	.sleb128 -2147483648
	.sleb128 2147483647
	.long	.LASF22
	.long	0x49
	.uleb128 0x3
	.byte	0x4
	.byte	0x5
	.long	.LASF3
	.uleb128 0x4
	.byte	0x4
	.long	.LASF5
	.uleb128 0x2
	.long	.LASF6
	.byte	0xa
	.long	.LASF8
	.long	0x73
	.long	0x73
	.uleb128 0x1
	.long	0x75
	.uleb128 0x1
	.long	0x75
	.byte	0
	.uleb128 0x8
	.byte	0x8
	.uleb128 0x9
	.byte	0x8
	.long	0x1e
	.uleb128 0x2
	.long	.LASF7
	.byte	0xd
	.long	.LASF9
	.long	0x36
	.long	0x93
	.uleb128 0x1
	.long	0x73
	.byte	0
	.uleb128 0x2
	.long	.LASF10
	.byte	0x10
	.long	.LASF11
	.long	0x36
	.long	0xb0
	.uleb128 0x1
	.long	0x36
	.uleb128 0x1
	.long	0x73
	.byte	0
	.uleb128 0x2
	.long	.LASF12
	.byte	0x14
	.long	.LASF13
	.long	0x36
	.long	0xc8
	.uleb128 0x1
	.long	0x73
	.byte	0
	.uleb128 0x2
	.long	.LASF14
	.byte	0x17
	.long	.LASF15
	.long	0x36
	.long	0xe0
	.uleb128 0x1
	.long	0x73
	.byte	0
	.uleb128 0x2
	.long	.LASF16
	.byte	0x1a
	.long	.LASF17
	.long	0x36
	.long	0xf8
	.uleb128 0x1
	.long	0x75
	.byte	0
	.uleb128 0x2
	.long	.LASF18
	.byte	0x1d
	.long	.LASF19
	.long	0x36
	.long	0x115
	.uleb128 0x1
	.long	0x75
	.uleb128 0x1
	.long	0x50
	.byte	0
	.uleb128 0xa
	.long	.LASF23
	.byte	0x1
	.byte	0x21
	.byte	0xd
	.long	.LASF24
	.long	0x73
	.uleb128 0x1
	.long	0x75
	.byte	0
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x5
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 13
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0x21
	.sleb128 7
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0xb
	.uleb128 0x2f
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0xd
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3c
	.uleb128 0x19
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x1c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	0
	.quad	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF19:
	.string	"mkdir"
.LASF10:
	.string	"silver_libc__c_put"
.LASF21:
	.string	"interfaces__c__char"
.LASF20:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF11:
	.string	"fputc"
.LASF15:
	.string	"fclose"
.LASF7:
	.string	"silver_libc__c_get"
.LASF5:
	.string	"interfaces__c__unsigned"
.LASF22:
	.string	"interfaces__c__int"
.LASF3:
	.string	"interfaces__c__TintB"
.LASF8:
	.string	"fopen"
.LASF14:
	.string	"silver_libc__c_close"
.LASF13:
	.string	"ferror"
.LASF17:
	.string	"system"
.LASF12:
	.string	"silver_libc__c_error"
.LASF4:
	.string	"interfaces__c__size_t"
.LASF6:
	.string	"silver_libc__c_open"
.LASF2:
	.string	"interfaces__c__TcharB"
.LASF9:
	.string	"fgetc"
.LASF18:
	.string	"silver_libc__c_mkdir"
.LASF16:
	.string	"silver_libc__c_system"
.LASF24:
	.string	"mkdtemp"
.LASF23:
	.string	"silver_libc__c_mkdtemp"
	.section	.debug_line_str,"MS",@progbits,1
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_libc.ads"
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
