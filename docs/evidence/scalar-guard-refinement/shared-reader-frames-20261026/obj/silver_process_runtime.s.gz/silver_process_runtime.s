	.file	"silver_process_runtime.ads"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_process_runtime.ads"
	.section	.rodata
	.align 8
.LC0:
	.zero	8
	.text
	.align 2
	.globl	silver_process_runtime__argument_listIP
	.type	silver_process_runtime__argument_listIP, @function
silver_process_runtime__argument_listIP:
.LFB1:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	movslq	%eax, %rdx
	movq	-8(%rbp), %rax
	movl	4(%rax), %ecx
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %ecx
	movq	-8(%rbp), %rax
	movl	4(%rax), %ecx
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %ecx
	movq	-8(%rbp), %rax
	movl	4(%rax), %ecx
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %ecx
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	movq	-8(%rbp), %rcx
	movl	4(%rcx), %ecx
	cmpl	%ecx, %eax
	jg	.L10
.L9:
	movq	-16(%rbp), %rsi
	movslq	%eax, %rdi
	movq	%rdi, %r8
	subq	%rdx, %r8
	salq	$4, %r8
	addq	%rsi, %r8
	movq	$0, (%r8)
	subq	%rdx, %rdi
	salq	$4, %rdi
	addq	%rdi, %rsi
	addq	$8, %rsi
	leaq	.LC0(%rip), %rdi
	movq	%rdi, (%rsi)
	cmpl	%ecx, %eax
	je	.L10
	addl	$1, %eax
	jmp	.L9
.L10:
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1:
	.size	silver_process_runtime__argument_listIP, .-silver_process_runtime__argument_listIP
	.section	.rodata
	.align 8
.LC3:
	.ascii	"failed precondition from silver_process_runtime.ads:17"
	.align 8
.LC4:
	.ascii	"failed precondition from silver_process_runtime.ads:18"
	.align 8
.LC5:
	.ascii	"failed precondition from silver_process_runtime.ads:19"
.LC6:
	.ascii	"silver_process_runtime.ads"
	.zero	1
	.align 8
.LC7:
	.ascii	"failed precondition from silver_process_runtime.ads:20"
	.align 8
.LC1:
	.long	1
	.long	54
	.text
	.align 2
	.globl	silver_process_runtime__spawn
	.type	silver_process_runtime__spawn, @function
silver_process_runtime__spawn:
.LFB2:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_process_runtime.ads"
	.loc 1 12 13
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$168, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -112(%rbp)
	movq	%rdi, -104(%rbp)
	movq	%rdx, -128(%rbp)
	movq	%rcx, -120(%rbp)
	.loc 1 12 13
	movq	-120(%rbp), %rax
	movl	(%rax), %ebx
	movq	-120(%rbp), %rax
	movl	4(%rax), %esi
	movl	%esi, -140(%rbp)
	movq	-104(%rbp), %rax
	movl	(%rax), %ecx
	movq	-104(%rbp), %rax
	movl	4(%rax), %edi
.LBB3:
	movslq	%ebx, %rax
	movq	%rax, -136(%rbp)
	cmpl	%ebx, %esi
	.loc 1 12 13 is_stmt 0 discriminator 3
	cmpl	%ebx, %esi
	.loc 1 12 13 discriminator 6
	cmpl	%ebx, %esi
	.loc 1 12 13 discriminator 9
	movslq	%ecx, %r8
	cmpl	%ecx, %edi
	.loc 1 12 13 discriminator 12
	cmpl	%ecx, %edi
	.loc 1 12 13 discriminator 15
	cmpl	%ecx, %edi
	.loc 1 17 18 is_stmt 1
	cmpl	%edi, %ecx
	jle	.L24
.LBB4:
	.loc 1 17 18 is_stmt 0 discriminator 1
	leaq	.LC3(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L24:
.LBE4:
	.loc 1 18 23 is_stmt 1
	movl	$1, %r9d
	cmpl	%edi, %ecx
	jg	.L25
.L28:
.LBB5:
.LBB6:
	.loc 1 18 31 discriminator 2
	movq	-112(%rbp), %rdx
	movslq	%ecx, %rsi
	movq	%rsi, %rax
	subq	%r8, %rax
	addq	%rdx, %rax
	movq	%rax, -56(%rbp)
	.loc 1 18 56 discriminator 2
	movq	-112(%rbp), %rax
	movq	%rsi, %rdx
	subq	%r8, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 18 23 discriminator 2
	testb	%al, %al
	jne	.L26
	.loc 1 18 23 is_stmt 0 discriminator 3
	movl	$0, %r9d
	jmp	.L25
.L26:
.LBE6:
	.loc 1 18 23 discriminator 4
	cmpl	%edi, %ecx
	je	.L25
	.loc 1 18 23 discriminator 5
	addl	$1, %ecx
	jmp	.L28
.L25:
.LBE5:
	.loc 1 18 23 discriminator 6
	movl	%r9d, %eax
	xorl	$1, %eax
	.loc 1 17 18 is_stmt 1 discriminator 2
	testb	%al, %al
	je	.L29
.LBB7:
	.loc 1 17 18 is_stmt 0 discriminator 3
	leaq	.LC4(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L29:
.LBE7:
	.loc 1 17 18 discriminator 4
	cmpl	$1, %ebx
	je	.L30
.LBB8:
	.loc 1 17 18 discriminator 5
	leaq	.LC5(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L30:
.LBE8:
	.loc 1 20 23 is_stmt 1
	movl	$1, %r13d
	movl	-140(%rbp), %eax
	cmpl	%eax, %ebx
	jg	.L31
.L48:
.LBB9:
.LBB10:
	.loc 1 20 31 discriminator 2
	movq	-128(%rbp), %rdx
	movslq	%ebx, %rcx
	movq	%rcx, %rax
	movq	-136(%rbp), %rdi
	subq	%rdi, %rax
	salq	$4, %rax
	addq	%rdx, %rax
	movq	%rax, -64(%rbp)
	.loc 1 20 50 discriminator 2
	movq	-128(%rbp), %rdx
	movq	%rcx, %rax
	subq	%rdi, %rax
	salq	$4, %rax
	addq	%rdx, %rax
	movq	8(%rax), %rdx
	movq	(%rax), %rax
	.loc 1 20 23 discriminator 2
	testq	%rax, %rax
	je	.L32
	.loc 1 21 25
	movl	$1, %r12d
	.loc 1 21 33
	movq	-128(%rbp), %rdx
	movq	%rcx, %rax
	subq	%rdi, %rax
	salq	$4, %rax
	addq	%rdx, %rax
	movq	8(%rax), %rdx
	movq	(%rax), %rax
	testq	%rax, %rax
	jne	.L33
	.loc 1 21 33 is_stmt 0 discriminator 1
	leaq	.LC6(%rip), %rax
	movl	$21, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Access_Check@PLT
.L33:
	.loc 1 21 33 discriminator 2
	movq	-128(%rbp), %rdx
	movq	%rcx, %rax
	movq	-136(%rbp), %rdi
	subq	%rdi, %rax
	salq	$4, %rax
	addq	%rdx, %rax
	movq	8(%rax), %rdx
	movq	(%rax), %rax
	movq	%rdx, %rax
	movl	(%rax), %esi
	movq	-128(%rbp), %rdx
	movq	%rcx, %rax
	subq	%rdi, %rax
	salq	$4, %rax
	addq	%rdx, %rax
	movq	8(%rax), %rdx
	movq	(%rax), %rax
	movq	%rdx, %rax
	movl	4(%rax), %edi
	cmpl	%esi, %edi
	.loc 1 21 33 discriminator 5
	cmpl	%esi, %edi
	.loc 1 21 33 discriminator 8
	cmpl	%esi, %edi
	.loc 1 21 33 discriminator 11
	cmpl	%esi, %edi
	jl	.L40
	.loc 1 21 33 discriminator 12
	testl	%esi, %esi
	jg	.L40
	.loc 1 21 33 discriminator 13
	leaq	.LC6(%rip), %rax
	movl	$21, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L40:
	.loc 1 21 15 is_stmt 1 discriminator 14
	movq	-128(%rbp), %rdx
	movq	%rcx, %rax
	movq	-136(%rbp), %rcx
	subq	%rcx, %rax
	salq	$4, %rax
	addq	%rdx, %rax
	movq	(%rax), %r11
	.loc 1 21 25 discriminator 14
	movq	%r11, -208(%rbp)
	movl	%esi, -96(%rbp)
	movl	%edi, -92(%rbp)
	leaq	-96(%rbp), %rax
	movq	%rax, -200(%rbp)
	movq	-200(%rbp), %rax
	movl	(%rax), %r8d
	movq	%r11, -192(%rbp)
	movl	%esi, -88(%rbp)
	movl	%edi, -84(%rbp)
	leaq	-88(%rbp), %rax
	movq	%rax, -184(%rbp)
	movq	-184(%rbp), %rax
	movl	4(%rax), %r10d
	cmpl	%r10d, %r8d
	jg	.L41
.L45:
.LBB11:
.LBB12:
	.loc 1 21 25 is_stmt 0 discriminator 16
	testl	%r8d, %r8d
	jg	.L42
	.loc 1 21 25 discriminator 17
	leaq	.LC6(%rip), %rax
	movl	$21, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L42:
	.loc 1 21 33 is_stmt 1 discriminator 18
	movq	%r11, -176(%rbp)
	movl	%esi, -80(%rbp)
	movl	%edi, -76(%rbp)
	leaq	-80(%rbp), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %r14
	movq	-168(%rbp), %r15
	movq	%r14, %r9
	movq	%r15, %rax
	movl	(%rax), %eax
	movslq	%eax, %rdx
	movslq	%r8d, %rcx
	movq	%rcx, %rax
	subq	%rdx, %rax
	addq	%r9, %rax
	movq	%rax, -72(%rbp)
	.loc 1 21 53 discriminator 18
	movq	%r14, %r9
	movq	%r15, %rax
	movl	(%rax), %eax
	cltq
	subq	%rax, %rcx
	movq	%rcx, %rdx
	movzbl	(%r9,%rdx), %eax
	.loc 1 21 25 discriminator 18
	testb	%al, %al
	jne	.L43
	.loc 1 21 25 is_stmt 0 discriminator 19
	movl	$0, %r12d
	jmp	.L41
.L43:
.LBE12:
	.loc 1 21 25 discriminator 20
	cmpl	%r10d, %r8d
	je	.L41
	.loc 1 21 25 discriminator 21
	addl	$1, %r8d
	jmp	.L45
.L41:
.LBE11:
	.loc 1 21 25 discriminator 22
	movl	%r12d, %eax
	xorl	$1, %eax
	.loc 1 21 15 is_stmt 1 discriminator 22
	testb	%al, %al
	je	.L46
.L32:
	.loc 1 20 23 discriminator 3
	movl	$0, %r13d
	jmp	.L31
.L46:
.LBE10:
	.loc 1 20 23 is_stmt 0 discriminator 4
	movl	-140(%rbp), %eax
	cmpl	%eax, %ebx
	je	.L31
	.loc 1 20 23 discriminator 5
	addl	$1, %ebx
	jmp	.L48
.L31:
.LBE9:
	.loc 1 20 23 discriminator 6
	movl	%r13d, %eax
	xorl	$1, %eax
	.loc 1 17 18 is_stmt 1 discriminator 6
	testb	%al, %al
	je	.L49
.LBB13:
	.loc 1 17 18 is_stmt 0 discriminator 7
	leaq	.LC7(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L49:
.LBE13:
	.loc 1 12 13 is_stmt 1 discriminator 18
	movq	-128(%rbp), %rax
	movq	-120(%rbp), %rdx
	movq	-112(%rbp), %rdi
	movq	-104(%rbp), %rsi
	movq	%rdx, %rcx
	movq	%rax, %rdx
	call	system__os_lib__spawn__2@PLT
.LBE3:
	.loc 1 12 13 is_stmt 0
	addq	$168, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	silver_process_runtime__spawn, .-silver_process_runtime__spawn
	.align 2
	.type	silver_process_runtime__free_list___wrapped_statements.0, @function
silver_process_runtime__free_list___wrapped_statements.0:
.LFB4:
	.loc 1 25 14 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%r10, %rdx
	movq	%r10, -24(%rbp)
	.loc 1 25 14
	movq	(%rdx), %rax
	movq	(%rdx), %rbx
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__strings__free__2@PLT
	movq	%rax, (%rbx)
	movq	%rdx, 8(%rbx)
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	silver_process_runtime__free_list___wrapped_statements.0, .-silver_process_runtime__free_list___wrapped_statements.0
	.section	.rodata
	.align 8
.LC8:
	.ascii	"failed postcondition from silver_process_runtime.ads:29"
	.align 8
.LC2:
	.long	1
	.long	55
	.text
	.align 2
	.globl	silver_process_runtime__free_list
	.type	silver_process_runtime__free_list, @function
silver_process_runtime__free_list:
.LFB3:
	.loc 1 25 14
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	subq	$32, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -48(%rbp)
	movq	%rdx, -40(%rbp)
	.loc 1 25 14
	leaq	16(%rbp), %rdx
	.loc 1 25 14 is_stmt 0 discriminator 1
	leaq	-48(%rbp), %rax
	movq	%rdx, -24(%rbp)
	movq	%rax, -32(%rbp)
.LBB14:
	leaq	-32(%rbp), %rax
	movq	%rax, %r10
	call	silver_process_runtime__free_list___wrapped_statements.0
	.loc 1 29 24 is_stmt 1
	movq	-48(%rbp), %rax
	.loc 1 29 19
	testq	%rax, %rax
	je	.L57
.LBB15:
	.loc 1 29 19 is_stmt 0 discriminator 1
	leaq	.LC8(%rip), %r12
	leaq	.LC2(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L57:
.LBE15:
	.loc 1 25 14 is_stmt 1 discriminator 2
	nop
.LBE14:
	.loc 1 25 14 is_stmt 0 discriminator 3
	movq	-48(%rbp), %rax
	movq	-40(%rbp), %rdx
	.loc 1 25 14
	addq	$32, %rsp
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.size	silver_process_runtime__free_list, .-silver_process_runtime__free_list
	.globl	silver_process_runtime_E
	.data
	.align 2
	.type	silver_process_runtime_E, @object
	.size	silver_process_runtime_E, 2
silver_process_runtime_E:
	.zero	2
	.text
.Letext0:
	.file 2 "<built-in>"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x24d
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x10
	.long	.LASF15
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.quad	.Ltext0
	.quad	.Letext0-.Ltext0
	.long	.Ldebug_line0
	.uleb128 0x6
	.long	.LASF6
	.byte	0x8
	.long	0x38
	.uleb128 0x11
	.long	.LASF16
	.byte	0x10
	.byte	0x2
	.byte	0
	.long	0x7b
	.uleb128 0x7
	.long	.LASF2
	.long	0x4e
	.byte	0
	.uleb128 0x1
	.long	0x80
	.uleb128 0x12
	.byte	0x8
	.byte	0x2
	.byte	0
	.long	0x70
	.uleb128 0x8
	.string	"LB0"
	.long	0xad
	.byte	0
	.uleb128 0x8
	.string	"UB0"
	.long	0xad
	.byte	0x4
	.byte	0
	.uleb128 0x7
	.long	.LASF3
	.long	0xbb
	.byte	0x8
	.byte	0
	.uleb128 0x9
	.long	0x38
	.uleb128 0xa
	.long	0xa6
	.long	0x9f
	.uleb128 0xb
	.long	0x9f
	.uleb128 0x6
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x94
	.byte	0x4
	.uleb128 0x8
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x23
	.uleb128 0x4
	.byte	0x94
	.byte	0x4
	.byte	0
	.uleb128 0x2
	.byte	0x4
	.byte	0x5
	.long	.LASF4
	.uleb128 0x2
	.byte	0x1
	.byte	0x8
	.long	.LASF5
	.uleb128 0x13
	.sleb128 2147483647
	.long	.LASF17
	.long	0x9f
	.uleb128 0x1
	.long	0x53
	.uleb128 0x14
	.long	.LASF18
	.byte	0x10
	.byte	0x1
	.byte	0x9
	.byte	0x9
	.long	0x105
	.uleb128 0xc
	.long	.LASF2
	.long	0xd7
	.byte	0
	.uleb128 0x1
	.long	0x10a
	.uleb128 0x15
	.byte	0x8
	.byte	0x1
	.byte	0x9
	.byte	0x9
	.long	0xfa
	.uleb128 0xd
	.string	"LB0"
	.long	0xad
	.byte	0
	.uleb128 0xd
	.string	"UB0"
	.long	0xad
	.byte	0x4
	.byte	0
	.uleb128 0xc
	.long	.LASF3
	.long	0x129
	.byte	0x8
	.byte	0
	.uleb128 0x9
	.long	0xc0
	.uleb128 0xa
	.long	0x2e
	.long	0x129
	.uleb128 0xb
	.long	0x9f
	.uleb128 0x6
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x94
	.byte	0x4
	.uleb128 0x8
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x23
	.uleb128 0x4
	.byte	0x94
	.byte	0x4
	.byte	0
	.uleb128 0x1
	.long	0xdc
	.uleb128 0x6
	.long	.LASF7
	.byte	0xa
	.long	0xc0
	.uleb128 0xe
	.long	.LASF8
	.byte	0x19
	.byte	0xe
	.long	0x12e
	.quad	.LFB3
	.quad	.LFE3-.LFB3
	.uleb128 0x1
	.byte	0x9c
	.long	0x198
	.uleb128 0x3
	.long	.LASF10
	.byte	0x19
	.byte	0x19
	.long	0x12e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x4
	.quad	.LBB14
	.quad	.LBE14-.LBB14
	.uleb128 0x16
	.long	.LASF19
	.quad	.LFB4
	.quad	.LFE4-.LFB4
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -40
	.byte	0x6
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0
	.byte	0
	.uleb128 0xe
	.long	.LASF9
	.byte	0xc
	.byte	0xd
	.long	0x23f
	.quad	.LFB2
	.quad	.LFE2-.LFB2
	.uleb128 0x1
	.byte	0x9c
	.long	0x23f
	.uleb128 0x3
	.long	.LASF11
	.byte	0xc
	.byte	0x14
	.long	0x7b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x3
	.long	.LASF10
	.byte	0xc
	.byte	0x2b
	.long	0x105
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x17
	.quad	.LBB6
	.quad	.LBE6-.LBB6
	.long	0x1fc
	.uleb128 0x5
	.long	.LASF12
	.byte	0x12
	.byte	0x1f
	.long	0x246
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.byte	0
	.uleb128 0x4
	.quad	.LBB10
	.quad	.LBE10-.LBB10
	.uleb128 0x5
	.long	.LASF13
	.byte	0x14
	.byte	0x1f
	.long	0x24b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x4
	.quad	.LBB12
	.quad	.LBE12-.LBB12
	.uleb128 0x5
	.long	.LASF14
	.byte	0x15
	.byte	0x21
	.long	0x246
	.uleb128 0x3
	.byte	0x91
	.sleb128 -88
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x2
	.byte	0x4
	.byte	0x5
	.long	.LASF4
	.uleb128 0xf
	.long	0xa6
	.uleb128 0xf
	.long	0x2e
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x16
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x18
	.uleb128 0x2f
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x10
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x14
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x15
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x16
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x17
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x2c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.Letext0-.Ltext0
	.quad	0
	.quad	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF10:
	.string	"args"
.LASF15:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF5:
	.string	"character"
.LASF13:
	.string	"T13s"
.LASF8:
	.string	"silver_process_runtime__free_list"
.LASF12:
	.string	"T11s"
.LASF11:
	.string	"program_name"
.LASF6:
	.string	"silver_process_runtime__string_access"
.LASF19:
	.string	"silver_process_runtime__free_list___wrapped_statements"
.LASF7:
	.string	"silver_process_runtime__argument_list_access"
.LASF2:
	.string	"P_ARRAY"
.LASF17:
	.string	"positive"
.LASF4:
	.string	"integer"
.LASF14:
	.string	"T12s"
.LASF9:
	.string	"silver_process_runtime__spawn"
.LASF3:
	.string	"P_BOUNDS"
.LASF16:
	.string	"string"
.LASF18:
	.string	"silver_process_runtime__argument_list"
	.section	.debug_line_str,"MS",@progbits,1
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_process_runtime.ads"
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
