	.file	"silver_scalar_literals.adb"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_scalar_literals.adb"
	.align 2
	.globl	silver_scalar_literals__literal_resultIP
	.type	silver_scalar_literals__literal_resultIP, @function
silver_scalar_literals__literal_resultIP:
.LFB2:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movl	%esi, %eax
	movq	%rcx, %rdx
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	silver_scalar_literals__literal_resultIP, .-silver_scalar_literals__literal_resultIP
	.section	.rodata
.LC4:
	.ascii	"silver_scalar_literals.adb"
	.zero	1
	.align 8
.LC5:
	.ascii	"Loop_Invariant failed at silver_scalar_literals.adb:62"
	.align 8
.LC6:
	.ascii	"Loop_Invariant failed at silver_scalar_literals.adb:63"
	.align 8
.LC7:
	.ascii	"Loop_Invariant failed at silver_scalar_literals.adb:64"
	.align 8
.LC8:
	.ascii	"Loop_Variant failed at silver_scalar_literals.adb:67"
	.align 8
.LC0:
	.long	1
	.long	54
	.align 8
.LC2:
	.long	1
	.long	52
	.text
	.align 2
	.type	silver_scalar_literals__numeral___wrapped_statements.0, @function
silver_scalar_literals__numeral___wrapped_statements.0:
.LFB4:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_scalar_literals.adb"
	.loc 1 54 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$136, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -88(%rbp)
	.loc 1 54 4
	movl	32(%rbx), %eax
	movl	%eax, -92(%rbp)
	movl	28(%rbx), %r15d
.LBB2:
	.loc 1 56 7
	movl	24(%rbx), %eax
	movl	%eax, -52(%rbp)
	.loc 1 57 7
	movq	$0, -64(%rbp)
	.loc 1 58 7
	movb	$1, -65(%rbp)
	.loc 1 60 7
	cmpl	$0, -52(%rbp)
	jne	.L3
	.loc 1 60 24 discriminator 1
	movq	%r12, %rdx
	movabsq	$-4294967296, %rax
	andq	%rdx, %rax
	movq	%rax, %r12
	movl	$0, %r13d
	jmp	.L4
.L3:
	.loc 1 61 31
	movb	$0, -93(%rbp)
.L35:
.LBB3:
	.loc 1 61 18 discriminator 1
	cmpl	-52(%rbp), %r15d
	jl	.L5
	.loc 1 62 33
	movl	24(%rbx), %eax
	cmpl	%eax, -52(%rbp)
	jl	.L6
	.loc 1 62 63 discriminator 1
	cmpl	$2147483647, %r15d
	jne	.L7
	.loc 1 62 63 is_stmt 0 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$62, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L7:
	.loc 1 62 63 discriminator 4
	leal	1(%r15), %eax
	.loc 1 62 38 is_stmt 1 discriminator 5
	cmpl	-52(%rbp), %eax
	jge	.L8
.L6:
.LBB4:
	.loc 1 62 33 discriminator 6
	leaq	.LC5(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rcx
	movq	-152(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L8:
.LBE4:
	.loc 1 63 33
	movl	24(%rbx), %eax
	cmpl	%eax, -52(%rbp)
	je	.L9
	.loc 1 63 49 discriminator 1
	movl	24(%rbx), %eax
	cmpl	%eax, -52(%rbp)
	jg	.L9
.LBB5:
	.loc 1 63 33 discriminator 2
	leaq	.LC6(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rsi
	movq	-136(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L9:
.LBE5:
	.loc 1 64 33
	movl	24(%rbx), %eax
	cmpl	%eax, -52(%rbp)
	jne	.L10
	.loc 1 64 33 is_stmt 0 discriminator 1
	movzbl	-65(%rbp), %eax
	xorl	$1, %eax
	testb	%al, %al
	je	.L10
.LBB6:
	.loc 1 64 33 discriminator 2
	leaq	.LC7(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rcx
	movq	-120(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L10:
.LBE6:
	.loc 1 67 10 is_stmt 1
	cmpb	$0, -93(%rbp)
	je	.L11
	.loc 1 67 44 discriminator 1
	movl	-164(%rbp), %eax
	movl	%eax, -168(%rbp)
.L11:
	.loc 1 67 44 is_stmt 0 discriminator 2
	movl	-52(%rbp), %eax
	movl	%eax, -164(%rbp)
	.loc 1 67 10 is_stmt 1 discriminator 2
	cmpb	$0, -93(%rbp)
	je	.L12
	.loc 1 67 44 discriminator 3
	movl	-168(%rbp), %esi
	cmpl	%esi, %eax
	jg	.L13
.LBB7:
	.loc 1 67 44 is_stmt 0 discriminator 4
	leaq	.LC8(%rip), %rax
	movq	%rax, -112(%rbp)
	leaq	.LC2(%rip), %rax
	movq	%rax, -104(%rbp)
	movq	-112(%rbp), %rsi
	movq	-104(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L12:
.LBE7:
	.loc 1 67 10 is_stmt 1 discriminator 5
	movb	$1, -93(%rbp)
.L13:
	.loc 1 68 20
	movl	-92(%rbp), %eax
	cmpl	-52(%rbp), %eax
	jg	.L14
	.loc 1 68 20 is_stmt 0 discriminator 1
	cmpl	-52(%rbp), %r15d
	jge	.L15
.L14:
	.loc 1 68 20 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$68, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L15:
	.loc 1 68 13 is_stmt 1 discriminator 3
	movq	16(%rbx), %rax
	movq	(%rax), %rcx
	movl	-52(%rbp), %eax
	movslq	%eax, %rdx
	movq	8(%rbx), %rax
	subq	%rax, %rdx
	movzbl	(%rcx,%rdx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_scalar_literals__digit
	movq	%rax, %rdx
	.loc 1 68 10 discriminator 4
	movq	(%rbx), %rax
	cmpq	%rdx, %rax
	jle	.L16
	.loc 1 69 48
	movl	-92(%rbp), %eax
	cmpl	-52(%rbp), %eax
	jg	.L17
	.loc 1 69 48 is_stmt 0 discriminator 1
	cmpl	-52(%rbp), %r15d
	jge	.L18
.L17:
	.loc 1 69 48 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$69, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L18:
	.loc 1 69 41 is_stmt 1 discriminator 3
	movq	16(%rbx), %rax
	movq	(%rax), %rcx
	movl	-52(%rbp), %eax
	movslq	%eax, %rdx
	movq	8(%rbx), %rax
	subq	%rax, %rdx
	movzbl	(%rcx,%rdx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_scalar_literals__digit
	movq	%rax, %rdx
	.loc 1 69 39 discriminator 4
	movabsq	$-9223372034707292159, %rax
	cmpq	%rax, %rdx
	jge	.L19
	.loc 1 69 39 is_stmt 0 discriminator 5
	leaq	.LC4(%rip), %rax
	movl	$69, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L19:
	.loc 1 69 39 discriminator 7
	movl	$2147483648, %eax
	subq	%rdx, %rax
	.loc 1 69 62 is_stmt 1 discriminator 8
	movq	(%rbx), %rcx
	cqto
	idivq	%rcx
	.loc 1 69 13 discriminator 8
	cmpq	%rax, -64(%rbp)
	jle	.L20
	.loc 1 70 16
	movq	%r12, %rdx
	movabsq	$-4294967296, %rax
	andq	%rdx, %rax
	movq	%rax, %r12
	movl	$0, %r13d
	jmp	.L4
.L20:
	.loc 1 72 44
	movl	-92(%rbp), %eax
	cmpl	-52(%rbp), %eax
	jg	.L21
	.loc 1 72 44 is_stmt 0 discriminator 1
	cmpl	-52(%rbp), %r15d
	jge	.L22
.L21:
	.loc 1 72 44 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$72, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L22:
	.loc 1 72 35 is_stmt 1 discriminator 3
	movq	(%rbx), %rax
	imulq	-64(%rbp), %rax
	movq	%rax, %r14
	.loc 1 72 37 discriminator 3
	movq	16(%rbx), %rax
	movq	(%rax), %rcx
	movl	-52(%rbp), %eax
	movslq	%eax, %rdx
	movq	8(%rbx), %rax
	subq	%rax, %rdx
	movzbl	(%rcx,%rdx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_scalar_literals__digit
	.loc 1 72 35 discriminator 4
	movl	$0, %edx
	addq	%r14, %rax
	jno	.L23
	movl	$1, %edx
.L23:
	movq	%rax, %rcx
	.loc 1 72 35 is_stmt 0 discriminator 5
	movq	%rdx, %rax
	testq	%rax, %rax
	je	.L25
	.loc 1 72 35 discriminator 6
	leaq	.LC4(%rip), %rax
	movl	$72, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L25:
	.loc 1 72 35 discriminator 8
	movq	%rcx, %rdx
	.loc 1 72 35 discriminator 9
	testq	%rdx, %rdx
	js	.L26
	.loc 1 72 35 discriminator 10
	movl	$2147483648, %eax
	cmpq	%rax, %rdx
	jle	.L27
.L26:
	.loc 1 72 35 discriminator 11
	leaq	.LC4(%rip), %rax
	movl	$72, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L27:
	.loc 1 72 19 is_stmt 1 discriminator 12
	movq	%rdx, -64(%rbp)
	.loc 1 73 24
	movb	$0, -65(%rbp)
	jmp	.L28
.L16:
	.loc 1 74 16
	movl	-92(%rbp), %eax
	cmpl	-52(%rbp), %eax
	jg	.L29
	.loc 1 74 16 is_stmt 0 discriminator 1
	cmpl	-52(%rbp), %r15d
	jge	.L30
.L29:
	.loc 1 74 16 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$74, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L30:
	.loc 1 74 28 is_stmt 1 discriminator 3
	movq	16(%rbx), %rax
	movq	(%rax), %rcx
	movl	-52(%rbp), %eax
	movslq	%eax, %rdx
	movq	8(%rbx), %rax
	subq	%rax, %rdx
	movzbl	(%rcx,%rdx), %eax
	.loc 1 74 10 discriminator 3
	cmpb	$95, %al
	jne	.L37
	.loc 1 75 13
	cmpb	$0, -65(%rbp)
	je	.L32
	.loc 1 75 32 discriminator 1
	movq	%r12, %rdx
	movabsq	$-4294967296, %rax
	andq	%rdx, %rax
	movq	%rax, %r12
	movl	$0, %r13d
	jmp	.L4
.L32:
	.loc 1 76 24
	movb	$1, -65(%rbp)
.L28:
	.loc 1 80 23
	movl	-52(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L33
	.loc 1 80 23 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L34
.L33:
	.loc 1 80 23 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$80, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L34:
	.loc 1 80 15 is_stmt 1 discriminator 3
	movl	%eax, -52(%rbp)
.LBE3:
	.loc 1 81 15
	jmp	.L35
.L37:
.LBB8:
	.loc 1 78 13
	nop
.L5:
.LBE8:
	.loc 1 82 7
	cmpb	$0, -65(%rbp)
	je	.L36
	.loc 1 82 26 discriminator 1
	movq	%r12, %rdx
	movabsq	$-4294967296, %rax
	andq	%rdx, %rax
	movq	%rax, %r12
	movl	$0, %r13d
	jmp	.L4
.L36:
	.loc 1 83 7
	movl	-52(%rbp), %eax
	movq	%r12, %rcx
	movabsq	$-4294967296, %rdx
	andq	%rcx, %rdx
	orq	%rdx, %rax
	movq	%rax, %r12
	movq	-64(%rbp), %r13
.L4:
.LBE2:
	.loc 1 84 8
	movl	%r12d, %eax
	movq	%r13, %rdx
	addq	$136, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	silver_scalar_literals__numeral___wrapped_statements.0, .-silver_scalar_literals__numeral___wrapped_statements.0
	.section	.rodata
	.align 8
.LC9:
	.ascii	"failed precondition from silver_scalar_literals.adb:48"
	.align 8
.LC10:
	.ascii	"failed precondition from silver_scalar_literals.adb:49"
	.align 8
.LC11:
	.ascii	"failed postcondition from silver_scalar_literals.adb:50"
	.align 8
.LC1:
	.long	1
	.long	55
	.text
	.align 2
	.type	silver_scalar_literals__numeral, @function
silver_scalar_literals__numeral:
.LFB3:
	.loc 1 54 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %rbx
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%rbx, %rdi
	movq	%rsi, -128(%rbp)
	movq	%rdi, -120(%rbp)
	movl	%edx, -132(%rbp)
	movq	%rcx, -144(%rbp)
	.loc 1 54 4
	leaq	16(%rbp), %rdx
	.loc 1 54 4 is_stmt 0 discriminator 1
	leaq	-128(%rbp), %rax
	movq	%rdx, -56(%rbp)
	movq	%rax, -80(%rbp)
	movl	-132(%rbp), %eax
	movl	%eax, -72(%rbp)
	movq	-144(%rbp), %rax
	movq	%rax, -96(%rbp)
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -64(%rbp)
	movq	-120(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -68(%rbp)
	movl	-68(%rbp), %edx
	movl	-64(%rbp), %eax
	cmpl	%eax, %edx
	jl	.L39
	.loc 1 54 4 discriminator 2
	movl	-68(%rbp), %ecx
	movslq	%ecx, %rax
	cqto
	movl	-64(%rbp), %esi
	movslq	%esi, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L40
.L39:
	.loc 1 54 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L40:
.LBB9:
	.loc 1 54 4 discriminator 4
	movl	-64(%rbp), %ecx
	movslq	%ecx, %rcx
	movq	%rcx, -88(%rbp)
	movl	-68(%rbp), %esi
	movl	-64(%rbp), %ecx
	cmpl	%ecx, %esi
	.loc 1 54 4 discriminator 7
	movl	-68(%rbp), %esi
	movl	-64(%rbp), %ecx
	cmpl	%ecx, %esi
	.loc 1 54 4 discriminator 10
	movl	-68(%rbp), %esi
	movl	-64(%rbp), %ecx
	cmpl	%ecx, %esi
	.loc 1 48 15 is_stmt 1
	movl	-64(%rbp), %ecx
	cmpl	$1, %ecx
	je	.L47
.LBB10:
	.loc 1 48 15 is_stmt 0 discriminator 1
	leaq	.LC9(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L47:
.LBE10:
	.loc 1 48 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 1 48 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L48
	.loc 1 48 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L49
.L48:
.LBB11:
	.loc 1 48 15 discriminator 4
	leaq	.LC9(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L49:
.LBE11:
	.loc 1 49 41
	movl	-68(%rbp), %eax
	cmpl	$2147483647, %eax
	jne	.L50
	.loc 1 49 41 is_stmt 0 discriminator 1
	leaq	.LC4(%rip), %rax
	movl	$49, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L50:
	.loc 1 49 41 discriminator 3
	movl	-68(%rbp), %eax
	leal	1(%rax), %edx
	.loc 1 48 15 is_stmt 1 discriminator 5
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L51
.LBB12:
	.loc 1 48 15 is_stmt 0 discriminator 6
	leaq	.LC10(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L51:
.LBE12:
.LBB13:
	.loc 1 54 4 is_stmt 1 discriminator 13
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
	call	silver_scalar_literals__numeral___wrapped_statements.0
	movl	%eax, %ecx
	movq	%rdx, %rax
	movl	%ecx, -112(%rbp)
	movq	%rax, -104(%rbp)
	.loc 1 50 49
	movl	-112(%rbp), %eax
	.loc 1 50 28
	testl	%eax, %eax
	je	.L52
	.loc 1 51 40
	movl	-112(%rbp), %eax
	.loc 1 51 10
	movl	-72(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L53
	.loc 1 52 42
	movl	-112(%rbp), %eax
	.loc 1 52 55
	movl	-68(%rbp), %edx
	cmpl	$2147483647, %edx
	jne	.L54
	.loc 1 52 55 is_stmt 0 discriminator 1
	leaq	.LC4(%rip), %rax
	movl	$52, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L54:
	.loc 1 52 55 discriminator 3
	movl	-68(%rbp), %edx
	addl	$1, %edx
	.loc 1 52 12 is_stmt 1 discriminator 4
	cmpl	%eax, %edx
	jge	.L52
.L53:
.LBB14:
	.loc 1 50 28 discriminator 1
	leaq	.LC11(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L52:
.LBE14:
	.loc 1 54 4 discriminator 14
	movq	-112(%rbp), %rax
	movq	-104(%rbp), %rdx
	.loc 1 54 4 is_stmt 0 discriminator 16
	movl	%eax, %ecx
.LBE13:
.LBE9:
	.loc 1 54 4
	movl	%ecx, %eax
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.size	silver_scalar_literals__numeral, .-silver_scalar_literals__numeral
	.align 2
	.globl	silver_scalar_literals__mantissa_resultIP
	.type	silver_scalar_literals__mantissa_resultIP, @function
silver_scalar_literals__mantissa_resultIP:
.LFB5:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE5:
	.size	silver_scalar_literals__mantissa_resultIP, .-silver_scalar_literals__mantissa_resultIP
	.align 2
	.type	silver_scalar_literals__read_mantissa___wrapped_statements.1, @function
silver_scalar_literals__read_mantissa___wrapped_statements.1:
.LFB7:
	.loc 1 124 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, -72(%rbp)
	movq	%r10, %rbx
	movq	%r10, -80(%rbp)
	.loc 1 124 4
	movl	24(%rbx), %r13d
	movl	20(%rbx), %r12d
.LBB15:
	.loc 1 125 44
	movq	8(%rbx), %rax
	movl	16(%rbx), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$10, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_scalar_literals__numeral
	movl	%eax, %ecx
	movq	%rdx, %rax
	movl	%ecx, -48(%rbp)
	movq	%rax, -40(%rbp)
	.loc 1 127 24
	movl	-48(%rbp), %eax
	.loc 1 127 7
	testl	%eax, %eax
	jne	.L59
	.loc 1 127 33 discriminator 1
	movq	-72(%rbp), %rax
	movl	$0, (%rax)
	movq	-72(%rbp), %rax
	movq	$0, 8(%rax)
	movq	-72(%rbp), %rax
	movq	$10, 16(%rax)
	jmp	.L58
.L59:
	.loc 1 128 24
	movl	-48(%rbp), %eax
	.loc 1 128 7
	cmpl	%eax, %r12d
	jl	.L61
	.loc 1 128 46 discriminator 1
	movl	-48(%rbp), %eax
	cmpl	%eax, %r13d
	jg	.L62
	.loc 1 128 46 is_stmt 0 discriminator 2
	movl	-48(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L63
.L62:
	.loc 1 128 46 discriminator 3
	leaq	.LC4(%rip), %rax
	movl	$128, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L63:
	.loc 1 128 70 is_stmt 1 discriminator 4
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movl	-48(%rbp), %edx
	movslq	%edx, %rcx
	movq	(%rbx), %rdx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 1 128 76 discriminator 5
	cmpb	$35, %al
	je	.L64
	.loc 1 128 76 is_stmt 0 discriminator 6
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movl	-48(%rbp), %edx
	movslq	%edx, %rcx
	movq	(%rbx), %rdx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 1 128 76 discriminator 7
	cmpb	$58, %al
	jne	.L65
.L64:
	.loc 1 128 76 discriminator 8
	movl	$1, %eax
	jmp	.L66
.L65:
	.loc 1 128 76 discriminator 9
	movl	$0, %eax
.L66:
	.loc 1 128 37 is_stmt 1 discriminator 10
	testb	%al, %al
	je	.L61
	.loc 1 129 23
	movl	-48(%rbp), %eax
	cmpl	%eax, %r13d
	jg	.L67
	.loc 1 129 23 is_stmt 0 discriminator 1
	movl	-48(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L68
.L67:
	.loc 1 129 23 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$129, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L68:
	.loc 1 129 44 is_stmt 1 discriminator 3
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movl	-48(%rbp), %edx
	movslq	%edx, %rcx
	movq	(%rbx), %rdx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 1 129 44 is_stmt 0 discriminator 4
	cmpb	$58, %al
	sete	%al
	xorl	$1, %eax
	.loc 1 129 9 is_stmt 1 discriminator 4
	testb	%al, %al
	jne	.L69
	.loc 1 129 73 discriminator 5
	movl	-48(%rbp), %eax
	.loc 1 129 50 discriminator 5
	cmpl	%eax, %r12d
	jle	.L69
	.loc 1 130 40
	movl	-48(%rbp), %eax
	addl	$1, %eax
	.loc 1 130 20
	cmpl	%eax, %r13d
	jg	.L70
	.loc 1 130 20 is_stmt 0 discriminator 1
	movl	-48(%rbp), %eax
	cmpl	%eax, %r12d
	jg	.L71
.L70:
	.loc 1 130 20 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$130, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L71:
	.loc 1 130 45 is_stmt 1 discriminator 3
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	.loc 1 130 40 discriminator 3
	movl	-48(%rbp), %edx
	addl	$1, %edx
	movslq	%edx, %rcx
	.loc 1 130 45 discriminator 3
	movq	(%rbx), %rdx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 1 130 45 is_stmt 0 discriminator 4
	cmpb	$61, %al
	sete	%al
	xorl	$1, %eax
	.loc 1 130 11 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L61
.L69:
	.loc 1 131 27
	movq	-40(%rbp), %rax
	.loc 1 131 10
	cmpq	$1, %rax
	jle	.L72
	.loc 1 131 27 discriminator 1
	movq	-40(%rbp), %rax
	cmpq	$16, %rax
	jle	.L73
.L72:
	.loc 1 131 52 discriminator 2
	movq	-72(%rbp), %rax
	movl	$0, (%rax)
	movq	-72(%rbp), %rax
	movq	$0, 8(%rax)
	movq	-72(%rbp), %rax
	movq	$10, 16(%rax)
	jmp	.L58
.L73:
.LBB16:
	.loc 1 133 78
	movl	-48(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L74
	.loc 1 133 78 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L75
.L74:
	.loc 1 133 78 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$133, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L75:
	.loc 1 133 90 is_stmt 1 discriminator 3
	movq	-40(%rbp), %rdx
	cmpq	$1, %rdx
	jle	.L76
	.loc 1 133 90 is_stmt 0 discriminator 4
	cmpq	$16, %rdx
	jle	.L77
.L76:
	.loc 1 133 90 discriminator 5
	leaq	.LC4(%rip), %rax
	movl	$133, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L77:
	.loc 1 133 49 is_stmt 1 discriminator 6
	movq	8(%rbx), %rcx
	movq	(%rcx), %rdi
	movq	8(%rcx), %rsi
	movq	%rdx, %rcx
	movl	%eax, %edx
	call	silver_scalar_literals__numeral
	movl	%eax, %ecx
	movq	%rdx, %rax
	movl	%ecx, -64(%rbp)
	movq	%rax, -56(%rbp)
	.loc 1 135 29
	movl	-64(%rbp), %eax
	.loc 1 135 13
	testl	%eax, %eax
	jne	.L78
	.loc 1 135 38 discriminator 1
	movq	-72(%rbp), %rax
	movl	$0, (%rax)
	movq	-72(%rbp), %rax
	movq	$0, 8(%rax)
	movq	-72(%rbp), %rax
	movq	$10, 16(%rax)
	jmp	.L79
.L78:
	.loc 1 136 29
	movl	-64(%rbp), %eax
	.loc 1 136 13
	cmpl	%eax, %r12d
	jl	.L80
	.loc 1 136 49 discriminator 1
	movl	-64(%rbp), %eax
	cmpl	%eax, %r13d
	jg	.L81
	.loc 1 136 49 is_stmt 0 discriminator 2
	movl	-64(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L82
.L81:
	.loc 1 136 49 discriminator 3
	leaq	.LC4(%rip), %rax
	movl	$136, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L82:
	.loc 1 136 72 is_stmt 1 discriminator 4
	movl	-48(%rbp), %eax
	cmpl	%eax, %r13d
	jg	.L83
	.loc 1 136 72 is_stmt 0 discriminator 5
	movl	-48(%rbp), %eax
	cmpl	%eax, %r12d
	jge	.L84
.L83:
	.loc 1 136 72 discriminator 6
	leaq	.LC4(%rip), %rax
	movl	$136, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L84:
	.loc 1 136 69 is_stmt 1 discriminator 7
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movl	-64(%rbp), %edx
	movslq	%edx, %rcx
	movq	(%rbx), %rdx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %ecx
	.loc 1 136 69 is_stmt 0 discriminator 8
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movl	-48(%rbp), %edx
	movslq	%edx, %rsi
	movq	(%rbx), %rdx
	subq	%rdx, %rsi
	movzbl	(%rax,%rsi), %eax
	.loc 1 136 69 discriminator 9
	cmpb	%al, %cl
	setne	%al
	.loc 1 136 41 is_stmt 1 discriminator 9
	testb	%al, %al
	je	.L85
.L80:
	.loc 1 137 16
	movq	-72(%rbp), %rax
	movl	$0, (%rax)
	movq	-72(%rbp), %rax
	movq	$0, 8(%rax)
	movq	-72(%rbp), %rax
	movq	$10, 16(%rax)
	jmp	.L79
.L85:
	.loc 1 139 43
	movl	-64(%rbp), %eax
	leal	1(%rax), %edx
	testl	%edx, %edx
	js	.L86
	.loc 1 139 43 is_stmt 0 discriminator 1
	cmpl	$4097, %edx
	jle	.L87
.L86:
	.loc 1 139 43 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$139, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L87:
	.loc 1 139 86 is_stmt 1 discriminator 3
	movq	-40(%rbp), %rax
	cmpq	$1, %rax
	jle	.L88
	.loc 1 139 86 is_stmt 0 discriminator 4
	cmpq	$16, %rax
	jle	.L89
.L88:
	.loc 1 139 86 discriminator 5
	leaq	.LC4(%rip), %rax
	movl	$139, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L89:
	.loc 1 139 13 is_stmt 1 discriminator 6
	movq	-72(%rbp), %rcx
	movl	%edx, (%rcx)
	movq	-56(%rbp), %rcx
	movq	-72(%rbp), %rdx
	movq	%rcx, 8(%rdx)
	movq	-72(%rbp), %rdx
	movq	%rax, 16(%rdx)
.L79:
.LBE16:
.LBE15:
	.loc 1 143 8
	jmp	.L58
.L61:
.LBB17:
	.loc 1 142 7
	movl	-48(%rbp), %edx
	movq	-72(%rbp), %rax
	movl	%edx, (%rax)
	movq	-40(%rbp), %rdx
	movq	-72(%rbp), %rax
	movq	%rdx, 8(%rax)
	movq	-72(%rbp), %rax
	movq	$10, 16(%rax)
.L58:
.LBE17:
	.loc 1 143 8
	movq	-72(%rbp), %rax
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE7:
	.size	silver_scalar_literals__read_mantissa___wrapped_statements.1, .-silver_scalar_literals__read_mantissa___wrapped_statements.1
	.section	.rodata
	.align 8
.LC12:
	.ascii	"failed precondition from silver_scalar_literals.adb:118"
	.align 8
.LC13:
	.ascii	"failed precondition from silver_scalar_literals.adb:119"
	.align 8
.LC14:
	.ascii	"failed postcondition from silver_scalar_literals.adb:120"
	.align 8
.LC3:
	.long	1
	.long	56
	.text
	.align 2
	.type	silver_scalar_literals__read_mantissa, @function
silver_scalar_literals__read_mantissa:
.LFB6:
	.loc 1 124 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$120, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -136(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -160(%rbp)
	movq	%rdx, -152(%rbp)
	movl	%ecx, -140(%rbp)
	.loc 1 124 4
	leaq	16(%rbp), %rdx
	.loc 1 124 4 is_stmt 0 discriminator 1
	leaq	-160(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -88(%rbp)
	movl	-140(%rbp), %eax
	movl	%eax, -80(%rbp)
	movq	-152(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -72(%rbp)
	movq	-152(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -76(%rbp)
	movl	-76(%rbp), %edx
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jl	.L92
	.loc 1 124 4 discriminator 2
	movl	-76(%rbp), %ecx
	movslq	%ecx, %rax
	cqto
	movl	-72(%rbp), %esi
	movslq	%esi, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L93
.L92:
	.loc 1 124 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L93:
.LBB18:
	.loc 1 124 4 discriminator 4
	movl	-72(%rbp), %ecx
	movslq	%ecx, %rcx
	movq	%rcx, -96(%rbp)
	movl	-76(%rbp), %esi
	movl	-72(%rbp), %ecx
	cmpl	%ecx, %esi
	.loc 1 124 4 discriminator 7
	movl	-76(%rbp), %esi
	movl	-72(%rbp), %ecx
	cmpl	%ecx, %esi
	.loc 1 124 4 discriminator 10
	movl	-76(%rbp), %esi
	movl	-72(%rbp), %ecx
	cmpl	%ecx, %esi
	.loc 1 118 15 is_stmt 1
	movl	-72(%rbp), %ecx
	cmpl	$1, %ecx
	je	.L100
.LBB19:
	.loc 1 118 15 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L100:
.LBE19:
	.loc 1 118 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 1 118 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L101
	.loc 1 118 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L102
.L101:
.LBB20:
	.loc 1 118 15 discriminator 4
	leaq	.LC12(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L102:
.LBE20:
	.loc 1 119 41
	movl	-76(%rbp), %eax
	cmpl	$2147483647, %eax
	jne	.L103
	.loc 1 119 41 is_stmt 0 discriminator 1
	leaq	.LC4(%rip), %rax
	movl	$119, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L103:
	.loc 1 119 41 discriminator 3
	movl	-76(%rbp), %eax
	leal	1(%rax), %edx
	.loc 1 118 15 is_stmt 1 discriminator 5
	movl	-80(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L104
.LBB21:
	.loc 1 118 15 is_stmt 0 discriminator 6
	leaq	.LC13(%rip), %r8
	leaq	.LC1(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L104:
.LBE21:
.LBB22:
	.loc 1 124 4 is_stmt 1 discriminator 13
	leaq	-128(%rbp), %rax
	leaq	-96(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_scalar_literals__read_mantissa___wrapped_statements.1
	.loc 1 120 55
	movl	-128(%rbp), %eax
	.loc 1 120 28
	testl	%eax, %eax
	je	.L105
	.loc 1 121 46
	movl	-128(%rbp), %eax
	.loc 1 121 10
	movl	-80(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L106
	.loc 1 122 48
	movl	-128(%rbp), %eax
	.loc 1 122 61
	movl	-76(%rbp), %edx
	cmpl	$2147483647, %edx
	jne	.L107
	.loc 1 122 61 is_stmt 0 discriminator 1
	leaq	.LC4(%rip), %rax
	movl	$122, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L107:
	.loc 1 122 61 discriminator 3
	movl	-76(%rbp), %edx
	addl	$1, %edx
	.loc 1 122 12 is_stmt 1 discriminator 4
	cmpl	%eax, %edx
	jge	.L105
.L106:
.LBB23:
	.loc 1 120 28 discriminator 1
	leaq	.LC14(%rip), %r12
	leaq	.LC3(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L105:
.LBE23:
	.loc 1 124 4 discriminator 14
	movq	-136(%rbp), %rcx
	movq	-128(%rbp), %rax
	movq	-120(%rbp), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movq	-112(%rbp), %rax
	movq	%rax, 16(%rcx)
.LBE22:
.LBE18:
	.loc 1 124 4 is_stmt 0
	movq	-136(%rbp), %rax
	addq	$120, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE6:
	.size	silver_scalar_literals__read_mantissa, .-silver_scalar_literals__read_mantissa
	.align 2
	.globl	silver_scalar_literals__scale_resultIP
	.type	silver_scalar_literals__scale_resultIP, @function
silver_scalar_literals__scale_resultIP:
.LFB8:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movl	%esi, %eax
	movq	%rcx, %rdx
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE8:
	.size	silver_scalar_literals__scale_resultIP, .-silver_scalar_literals__scale_resultIP
	.align 2
	.type	silver_scalar_literals__power, @function
silver_scalar_literals__power:
.LFB9:
	.loc 1 162 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -56(%rbp)
	movq	%rsi, -64(%rbp)
	movq	%rdx, -72(%rbp)
	.loc 1 163 7
	movq	-64(%rbp), %rax
	movq	%rax, -24(%rbp)
	.loc 1 165 7
	cmpq	$0, -72(%rbp)
	je	.L111
	.loc 1 165 23 discriminator 1
	cmpq	$0, -64(%rbp)
	jne	.L112
.L111:
	.loc 1 166 10
	movb	$1, %cl
	movq	-64(%rbp), %rbx
	jmp	.L113
.L112:
	.loc 1 168 7
	cmpq	$31, -72(%rbp)
	jle	.L114
	.loc 1 168 29 discriminator 1
	movb	$0, %cl
	movl	$0, %ebx
	jmp	.L113
.L114:
	.loc 1 169 11
	movq	-72(%rbp), %rax
	movq	%rax, -40(%rbp)
.LBB24:
	movq	$1, -32(%rbp)
.L119:
	.loc 1 169 11 is_stmt 0 discriminator 1
	movq	-32(%rbp), %rax
	cmpq	-40(%rbp), %rax
	jg	.L115
.LBB25:
	.loc 1 172 36 is_stmt 1
	movl	$2147483648, %eax
	cqto
	idivq	-56(%rbp)
	.loc 1 172 10
	cmpq	%rax, -24(%rbp)
	jle	.L116
	.loc 1 172 48 discriminator 1
	movb	$0, %cl
	movl	$0, %ebx
	jmp	.L113
.L116:
	.loc 1 173 27
	movq	-24(%rbp), %rax
	imulq	-56(%rbp), %rax
	testq	%rax, %rax
	js	.L117
	.loc 1 173 27 is_stmt 0 discriminator 1
	movl	$2147483648, %edx
	cmpq	%rdx, %rax
	jle	.L118
.L117:
	.loc 1 173 27 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$173, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L118:
	.loc 1 173 17 is_stmt 1 discriminator 3
	movq	%rax, -24(%rbp)
.LBE25:
	.loc 1 169 11 discriminator 2
	addq	$1, -32(%rbp)
	.loc 1 174 15
	jmp	.L119
.L115:
.LBE24:
	.loc 1 175 7
	movb	$1, %cl
	movq	-24(%rbp), %rbx
.L113:
	.loc 1 176 8
	movl	%ecx, %eax
	movq	%rbx, %rdx
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE9:
	.size	silver_scalar_literals__power, .-silver_scalar_literals__power
	.align 2
	.type	silver_scalar_literals__exponent_start___wrapped_statements.2, @function
silver_scalar_literals__exponent_start___wrapped_statements.2:
.LFB11:
	.loc 1 183 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	.loc 1 183 4
	movq	(%rax), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %esi
	movq	(%rax), %rdx
	movq	8(%rdx), %rdx
	movl	4(%rdx), %edx
.LBB26:
	.loc 1 184 7
	movl	8(%rax), %ecx
	cmpl	%ecx, %edx
	jl	.L121
	.loc 1 184 41 discriminator 1
	movl	8(%rax), %ecx
	cmpl	%ecx, %esi
	jg	.L122
	.loc 1 184 41 is_stmt 0 discriminator 2
	movl	8(%rax), %ecx
	cmpl	%ecx, %edx
	jge	.L123
.L122:
	.loc 1 184 41 discriminator 3
	leaq	.LC4(%rip), %rax
	movl	$184, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L123:
	.loc 1 184 57 is_stmt 1 discriminator 4
	movq	(%rax), %rdx
	movq	(%rdx), %rdx
	movq	(%rax), %rcx
	movq	8(%rcx), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movl	8(%rax), %esi
	movslq	%esi, %rsi
	subq	%rcx, %rsi
	movzbl	(%rdx,%rsi), %edx
	cmpb	$43, %dl
	sete	%dl
	.loc 1 184 32 discriminator 4
	testb	%dl, %dl
	je	.L121
	.loc 1 184 77 discriminator 5
	movl	8(%rax), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L124
	.loc 1 184 77 is_stmt 0 discriminator 6
	cmpl	$4097, %eax
	jle	.L126
.L124:
	.loc 1 184 77 discriminator 7
	leaq	.LC4(%rip), %rax
	movl	$184, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L121:
	.loc 1 184 86 is_stmt 1 discriminator 9
	movl	8(%rax), %eax
.L126:
.LBE26:
	.loc 1 183 4
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE11:
	.size	silver_scalar_literals__exponent_start___wrapped_statements.2, .-silver_scalar_literals__exponent_start___wrapped_statements.2
	.section	.rodata
	.align 8
.LC15:
	.ascii	"failed precondition from silver_scalar_literals.adb:180"
	.align 8
.LC16:
	.ascii	"failed precondition from silver_scalar_literals.adb:181"
	.align 8
.LC17:
	.ascii	"failed postcondition from silver_scalar_literals.adb:182"
	.text
	.align 2
	.globl	silver_scalar_literals__exponent_start
	.type	silver_scalar_literals__exponent_start, @function
silver_scalar_literals__exponent_start:
.LFB10:
	.loc 1 183 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r14
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r14, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movl	%edx, -100(%rbp)
	.loc 1 183 4
	leaq	16(%rbp), %rdx
	.loc 1 183 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -80(%rbp)
	movl	-100(%rbp), %eax
	movl	%eax, -72(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %r15d
	movq	-88(%rbp), %rax
	movl	4(%rax), %r14d
	movq	-88(%rbp), %rax
	movl	4(%rax), %edx
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L128
	.loc 1 183 4 discriminator 2
	movq	-88(%rbp), %rax
	movl	4(%rax), %esi
	movslq	%esi, %rax
	cqto
	movq	-88(%rbp), %rsi
	movl	(%rsi), %edi
	movl	%edi, -104(%rbp)
	movslq	-104(%rbp), %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L129
.L128:
	.loc 1 183 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L129:
.LBB27:
	.loc 1 180 15 is_stmt 1
	cmpl	$1, %r15d
	je	.L130
.LBB28:
	.loc 1 180 15 is_stmt 0 discriminator 1
	leaq	.LC15(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L130:
.LBE28:
	.loc 1 180 51 is_stmt 1 discriminator 2
	movl	%eax, %esi
	.loc 1 180 15 discriminator 2
	testl	%esi, %esi
	jle	.L131
	.loc 1 180 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L132
.L131:
.LBB29:
	.loc 1 180 15 discriminator 4
	leaq	.LC15(%rip), %r8
	leaq	.LC1(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L132:
.LBE29:
	.loc 1 180 15 is_stmt 0 discriminator 5
	movl	-72(%rbp), %eax
	testl	%eax, %eax
	jle	.L133
	.loc 1 181 46 is_stmt 1
	cmpl	$2147483647, %r14d
	jne	.L134
	.loc 1 181 46 is_stmt 0 discriminator 1
	leaq	.LC4(%rip), %rax
	movl	$181, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L134:
	.loc 1 181 46 discriminator 3
	leal	1(%r14), %edx
	.loc 1 181 28 is_stmt 1 discriminator 4
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L135
.L133:
.LBB30:
	.loc 1 180 15 discriminator 6
	leaq	.LC16(%rip), %rcx
	leaq	.LC1(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L135:
.LBE30:
.LBB31:
	.loc 1 183 4 discriminator 5
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_scalar_literals__exponent_start___wrapped_statements.2
	.loc 1 182 16
	movl	-72(%rbp), %edx
	cmpl	%edx, %eax
	jl	.L136
	.loc 1 182 63 discriminator 1
	cmpl	$2147483647, %r14d
	jne	.L137
	.loc 1 182 63 is_stmt 0 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$182, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L137:
	.loc 1 182 63 discriminator 4
	leal	1(%r14), %edx
	.loc 1 182 38 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L139
.L136:
.LBB32:
	.loc 1 182 16 discriminator 6
	leaq	.LC17(%rip), %r12
	leaq	.LC3(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L139:
.LBE32:
.LBE31:
.LBE27:
	.loc 1 183 4
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE10:
	.size	silver_scalar_literals__exponent_start, .-silver_scalar_literals__exponent_start
	.align 2
	.type	silver_scalar_literals__read_exponent___wrapped_statements.3, @function
silver_scalar_literals__read_exponent___wrapped_statements.3:
.LFB13:
	.loc 1 208 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%r10, %rbx
	movq	%r10, -72(%rbp)
	.loc 1 208 4
	movl	28(%rbx), %ecx
	movl	24(%rbx), %eax
.LBB33:
	.loc 1 210 23
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	.loc 1 210 7
	cmpl	%edx, %eax
	jl	.L141
	.loc 1 210 45 discriminator 1
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	jg	.L142
	.loc 1 210 45 is_stmt 0 discriminator 2
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %eax
	jge	.L143
.L142:
	.loc 1 210 45 discriminator 3
	leaq	.LC4(%rip), %rax
	movl	$210, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L143:
	.loc 1 210 68 is_stmt 1 discriminator 4
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rcx
	movq	(%rbx), %rdx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 1 210 74 discriminator 4
	cmpb	$101, %al
	je	.L144
	.loc 1 210 74 is_stmt 0 discriminator 5
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rcx
	movq	(%rbx), %rdx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$69, %al
	jne	.L145
.L144:
	.loc 1 210 74 discriminator 6
	movl	$1, %eax
	jmp	.L146
.L145:
	.loc 1 210 74 discriminator 7
	movl	$0, %eax
.L146:
	.loc 1 210 36 is_stmt 1 discriminator 8
	testb	%al, %al
	je	.L141
.LBB34:
	.loc 1 213 65
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L147
	.loc 1 213 65 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L148
.L147:
	.loc 1 213 65 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$213, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L148:
	.loc 1 213 15 is_stmt 1 discriminator 3
	movq	8(%rbx), %rdx
	movq	(%rdx), %rsi
	movq	8(%rdx), %rcx
	movl	%eax, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver_scalar_literals__exponent_start
	movl	%eax, %edx
	.loc 1 213 15 is_stmt 0 discriminator 4
	movq	8(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$10, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_scalar_literals__numeral
	movl	%eax, %ecx
	movq	%rdx, %rax
	movl	%ecx, -48(%rbp)
	movq	%rax, -40(%rbp)
	.loc 1 215 31 is_stmt 1
	movl	-48(%rbp), %eax
	.loc 1 215 13
	testl	%eax, %eax
	je	.L149
	.loc 1 215 58 discriminator 1
	movq	-40(%rbp), %rax
	.loc 1 215 35 discriminator 1
	cmpq	$4096, %rax
	jle	.L150
.L149:
	.loc 1 215 78 discriminator 2
	movq	%r12, %rdx
	movabsq	$-4294967296, %rax
	andq	%rdx, %rax
	movq	%rax, %r12
	movl	$0, %r13d
	jmp	.L154
.L150:
.LBB35:
	.loc 1 217 50
	movq	-40(%rbp), %rdx
	movq	16(%rbx), %rax
	movq	8(%rax), %rcx
	movq	16(%rbx), %rax
	movq	16(%rax), %rax
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	silver_scalar_literals__power
	movl	%eax, %ecx
	movq	%rdx, %rax
	movl	%ecx, -64(%rbp)
	movq	%rax, -56(%rbp)
	.loc 1 219 19
	movzbl	-64(%rbp), %eax
	xorl	$1, %eax
	.loc 1 219 16
	testb	%al, %al
	je	.L152
	.loc 1 219 41 discriminator 1
	movq	%r12, %rdx
	movabsq	$-4294967296, %rax
	andq	%rdx, %rax
	movq	%rax, %r12
	movl	$0, %r13d
	jmp	.L154
.L152:
	.loc 1 220 16
	movl	-48(%rbp), %eax
	movl	%eax, %edx
	movq	%r12, %rcx
	movabsq	$-4294967296, %rax
	andq	%rcx, %rax
	orq	%rdx, %rax
	movq	%rax, %r12
	movq	-56(%rbp), %rax
	movq	%rax, %r13
	jmp	.L154
.L141:
.LBE35:
.LBE34:
	.loc 1 224 7
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, %edx
	movq	%r12, %rcx
	movabsq	$-4294967296, %rax
	andq	%rcx, %rax
	orq	%rdx, %rax
	movq	%rax, %r12
	movq	16(%rbx), %rax
	movq	8(%rax), %rax
	movq	%rax, %r13
.L154:
.LBE33:
	.loc 1 225 8
	movl	%r12d, %eax
	movq	%r13, %rdx
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE13:
	.size	silver_scalar_literals__read_exponent___wrapped_statements.3, .-silver_scalar_literals__read_exponent___wrapped_statements.3
	.section	.rodata
	.align 8
.LC18:
	.ascii	"failed precondition from silver_scalar_literals.adb:203"
	.align 8
.LC19:
	.ascii	"failed precondition from silver_scalar_literals.adb:204"
	.align 8
.LC20:
	.ascii	"failed postcondition from silver_scalar_literals.adb:205"
	.text
	.align 2
	.type	silver_scalar_literals__read_exponent, @function
silver_scalar_literals__read_exponent:
.LFB12:
	.loc 1 208 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$96, %rsp
	.cfi_offset 14, -24
	.cfi_offset 13, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r14
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r14, %rdi
	movq	%rsi, -112(%rbp)
	movq	%rdi, -104(%rbp)
	movq	%rdx, -120(%rbp)
	.loc 1 208 4
	leaq	16(%rbp), %rdx
	.loc 1 208 4 is_stmt 0 discriminator 1
	leaq	-112(%rbp), %rax
	movq	%rdx, -48(%rbp)
	movq	%rax, -72(%rbp)
	movq	-120(%rbp), %rax
	movq	%rax, -64(%rbp)
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -52(%rbp)
	movq	-104(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -56(%rbp)
	movl	-56(%rbp), %edx
	movl	-52(%rbp), %eax
	cmpl	%eax, %edx
	jl	.L156
	.loc 1 208 4 discriminator 2
	movl	-56(%rbp), %esi
	movslq	%esi, %rax
	cqto
	movl	-52(%rbp), %r14d
	movslq	%r14d, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L157
.L156:
	.loc 1 208 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L157:
.LBB36:
	.loc 1 208 4 discriminator 4
	movl	-52(%rbp), %esi
	movslq	%esi, %rsi
	movq	%rsi, -80(%rbp)
	movl	-56(%rbp), %edi
	movl	-52(%rbp), %esi
	cmpl	%esi, %edi
	.loc 1 208 4 discriminator 7
	movl	-56(%rbp), %edi
	movl	-52(%rbp), %esi
	cmpl	%esi, %edi
	.loc 1 208 4 discriminator 10
	movl	-56(%rbp), %edi
	movl	-52(%rbp), %esi
	cmpl	%esi, %edi
	.loc 1 203 15 is_stmt 1
	movl	-52(%rbp), %esi
	cmpl	$1, %esi
	je	.L164
.LBB37:
	.loc 1 203 15 is_stmt 0 discriminator 1
	leaq	.LC18(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L164:
.LBE37:
	.loc 1 203 51 is_stmt 1 discriminator 2
	movl	%eax, %esi
	.loc 1 203 15 discriminator 2
	testl	%esi, %esi
	jle	.L165
	.loc 1 203 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L166
.L165:
.LBB38:
	.loc 1 203 15 discriminator 4
	leaq	.LC18(%rip), %r8
	leaq	.LC1(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L166:
.LBE38:
	.loc 1 204 32
	movq	-64(%rbp), %rax
	movl	(%rax), %eax
	.loc 1 203 15 discriminator 5
	testl	%eax, %eax
	jle	.L167
	.loc 1 204 32 discriminator 1
	movq	-64(%rbp), %rax
	movl	(%rax), %eax
	.loc 1 204 50 discriminator 1
	movl	-56(%rbp), %edx
	cmpl	$2147483647, %edx
	jne	.L168
	.loc 1 204 50 is_stmt 0 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$204, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L168:
	.loc 1 204 50 discriminator 4
	movl	-56(%rbp), %edx
	addl	$1, %edx
	.loc 1 204 32 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L169
.L167:
.LBB39:
	.loc 1 203 15 discriminator 6
	leaq	.LC19(%rip), %rcx
	leaq	.LC1(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L169:
.LBE39:
.LBB40:
	.loc 1 208 4 discriminator 13
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_scalar_literals__read_exponent___wrapped_statements.3
	movl	%eax, %ecx
	movq	%rdx, %rax
	movl	%ecx, -96(%rbp)
	movq	%rax, -88(%rbp)
	.loc 1 205 55
	movl	-96(%rbp), %eax
	.loc 1 205 28
	testl	%eax, %eax
	je	.L170
	.loc 1 206 45
	movl	-96(%rbp), %edx
	movq	-64(%rbp), %rax
	movl	(%rax), %eax
	.loc 1 206 10
	cmpl	%eax, %edx
	jl	.L171
	.loc 1 206 45 discriminator 1
	movl	-96(%rbp), %eax
	.loc 1 206 74 discriminator 1
	movl	-56(%rbp), %edx
	cmpl	$2147483647, %edx
	jne	.L172
	.loc 1 206 74 is_stmt 0 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$206, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L172:
	.loc 1 206 74 discriminator 4
	movl	-56(%rbp), %edx
	addl	$1, %edx
	.loc 1 206 45 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L170
.L171:
.LBB41:
	.loc 1 205 28 discriminator 1
	leaq	.LC20(%rip), %r12
	leaq	.LC3(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L170:
.LBE41:
	.loc 1 208 4 discriminator 14
	movq	-96(%rbp), %rax
	movq	-88(%rbp), %rdx
	.loc 1 208 4 is_stmt 0 discriminator 16
	movl	%eax, %ecx
.LBE40:
.LBE36:
	.loc 1 208 4
	movl	%ecx, %eax
	addq	$96, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE12:
	.size	silver_scalar_literals__read_exponent, .-silver_scalar_literals__read_exponent
	.align 2
	.type	silver_scalar_literals__read_integer___wrapped_statements.4, @function
silver_scalar_literals__read_integer___wrapped_statements.4:
.LFB15:
	.loc 1 235 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -104(%rbp)
	.loc 1 235 4
	movl	24(%rbx), %r15d
	movl	20(%rbx), %r14d
.LBB42:
	.loc 1 237 44
	movq	8(%rbx), %rax
	movl	16(%rbx), %ecx
	leaq	-80(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_scalar_literals__read_mantissa
	.loc 1 239 23
	movl	-80(%rbp), %eax
	.loc 1 239 7
	testl	%eax, %eax
	jne	.L175
	.loc 1 239 32 discriminator 1
	movq	%r12, %rdx
	movabsq	$-4294967296, %rax
	andq	%rdx, %rax
	movq	%rax, %r12
	movl	$0, %r13d
	jmp	.L182
.L175:
.LBB43:
	.loc 1 241 46
	movq	8(%rbx), %rax
	leaq	-80(%rbp), %rdx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_literals__read_exponent
	movl	%eax, %ecx
	movq	%rdx, %rax
	movl	%ecx, -96(%rbp)
	movq	%rax, -88(%rbp)
	.loc 1 243 26
	movl	-96(%rbp), %eax
	.loc 1 243 10
	testl	%eax, %eax
	je	.L177
	.loc 1 244 26
	movl	-96(%rbp), %eax
	.loc 1 243 30 discriminator 1
	cmpl	%eax, %r14d
	jl	.L178
	.loc 1 244 73 discriminator 1
	movl	-96(%rbp), %eax
	cmpl	%eax, %r15d
	jg	.L179
	.loc 1 244 73 is_stmt 0 discriminator 2
	movl	-96(%rbp), %eax
	cmpl	%eax, %r14d
	jge	.L180
.L179:
	.loc 1 244 73 discriminator 3
	leaq	.LC4(%rip), %rax
	movl	$244, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L180:
	.loc 1 244 48 is_stmt 1 discriminator 4
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movl	-96(%rbp), %edx
	movslq	%edx, %rcx
	movq	(%rbx), %rdx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 1 244 48 is_stmt 0 discriminator 5
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_identifier_character@PLT
	.loc 1 244 39 is_stmt 1 discriminator 6
	testb	%al, %al
	je	.L178
.L177:
	.loc 1 245 15
	movq	%r12, %rdx
	movabsq	$-4294967296, %rax
	andq	%rdx, %rax
	movq	%rax, %r12
	movl	$0, %r13d
	jmp	.L182
.L178:
	.loc 1 246 10
	movq	-96(%rbp), %r12
	movq	-88(%rbp), %r13
.L182:
.LBE43:
.LBE42:
	.loc 1 248 8
	movl	%r12d, %eax
	movq	%r13, %rdx
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE15:
	.size	silver_scalar_literals__read_integer___wrapped_statements.4, .-silver_scalar_literals__read_integer___wrapped_statements.4
	.section	.rodata
	.align 8
.LC21:
	.ascii	"failed precondition from silver_scalar_literals.ads:31"
.LC22:
	.ascii	"silver_scalar_literals.ads"
	.zero	1
	.align 8
.LC23:
	.ascii	"failed precondition from silver_scalar_literals.ads:32"
	.align 8
.LC24:
	.ascii	"failed postcondition from silver_scalar_literals.ads:33"
	.text
	.align 2
	.globl	silver_scalar_literals__read_integer
	.type	silver_scalar_literals__read_integer, @function
silver_scalar_literals__read_integer:
.LFB14:
	.loc 1 235 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$96, %rsp
	.cfi_offset 14, -24
	.cfi_offset 13, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r14
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r14, %rdi
	movq	%rsi, -112(%rbp)
	movq	%rdi, -104(%rbp)
	movl	%edx, -116(%rbp)
	.loc 1 235 4
	leaq	16(%rbp), %rdx
	.loc 1 235 4 is_stmt 0 discriminator 1
	leaq	-112(%rbp), %rax
	movq	%rdx, -48(%rbp)
	movq	%rax, -72(%rbp)
	movl	-116(%rbp), %eax
	movl	%eax, -64(%rbp)
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -56(%rbp)
	movq	-104(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -60(%rbp)
	movl	-60(%rbp), %edx
	movl	-56(%rbp), %eax
	cmpl	%eax, %edx
	jl	.L184
	.loc 1 235 4 discriminator 2
	movl	-60(%rbp), %esi
	movslq	%esi, %rax
	cqto
	movl	-56(%rbp), %r14d
	movslq	%r14d, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L185
.L184:
	.loc 1 235 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L185:
.LBB44:
	.loc 1 235 4 discriminator 4
	movl	-56(%rbp), %esi
	movslq	%esi, %rsi
	movq	%rsi, -80(%rbp)
	movl	-60(%rbp), %edi
	movl	-56(%rbp), %esi
	cmpl	%esi, %edi
	.loc 1 235 4 discriminator 7
	movl	-60(%rbp), %edi
	movl	-56(%rbp), %esi
	cmpl	%esi, %edi
	.loc 1 235 4 discriminator 10
	movl	-60(%rbp), %edi
	movl	-56(%rbp), %esi
	cmpl	%esi, %edi
	.file 2 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_scalar_literals.ads"
	.loc 2 31 15 is_stmt 1
	movl	-56(%rbp), %esi
	cmpl	$1, %esi
	je	.L192
.LBB45:
	.loc 2 31 15 is_stmt 0 discriminator 1
	leaq	.LC21(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L192:
.LBE45:
	.loc 2 31 51 is_stmt 1 discriminator 2
	movl	%eax, %esi
	.loc 2 31 15 discriminator 2
	testl	%esi, %esi
	jle	.L193
	.loc 2 31 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L194
.L193:
.LBB46:
	.loc 2 31 15 discriminator 4
	leaq	.LC21(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L194:
.LBE46:
	.loc 2 32 41
	movl	-60(%rbp), %eax
	cmpl	$2147483647, %eax
	jne	.L195
	.loc 2 32 41 is_stmt 0 discriminator 1
	leaq	.LC22(%rip), %rax
	movl	$32, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L195:
	.loc 2 32 41 discriminator 3
	movl	-60(%rbp), %eax
	leal	1(%rax), %edx
	.loc 2 31 15 is_stmt 1 discriminator 5
	movl	-64(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L196
.LBB47:
	.loc 2 31 15 is_stmt 0 discriminator 6
	leaq	.LC23(%rip), %rcx
	leaq	.LC0(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L196:
.LBE47:
.LBB48:
	.loc 1 235 4 is_stmt 1 discriminator 13
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_scalar_literals__read_integer___wrapped_statements.4
	movl	%eax, %ecx
	movq	%rdx, %rax
	movl	%ecx, -96(%rbp)
	movq	%rax, -88(%rbp)
	.loc 2 33 54
	movl	-96(%rbp), %eax
	.loc 2 33 28
	testl	%eax, %eax
	je	.L197
	.loc 2 34 45
	movl	-96(%rbp), %eax
	.loc 2 34 10
	movl	-64(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L198
	.loc 2 35 47
	movl	-96(%rbp), %eax
	.loc 2 35 60
	movl	-60(%rbp), %edx
	cmpl	$2147483647, %edx
	jne	.L199
	.loc 2 35 60 is_stmt 0 discriminator 1
	leaq	.LC22(%rip), %rax
	movl	$35, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L199:
	.loc 2 35 60 discriminator 3
	movl	-60(%rbp), %edx
	addl	$1, %edx
	.loc 2 35 12 is_stmt 1 discriminator 4
	cmpl	%eax, %edx
	jge	.L197
.L198:
.LBB49:
	.loc 2 33 28 discriminator 1
	leaq	.LC24(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L197:
.LBE49:
	.loc 1 235 4 discriminator 14
	movq	-96(%rbp), %rax
	movq	-88(%rbp), %rdx
	.loc 1 235 4 is_stmt 0 discriminator 16
	movl	%eax, %ecx
.LBE48:
.LBE44:
	.loc 1 235 4
	movl	%ecx, %eax
	addq	$96, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE14:
	.size	silver_scalar_literals__read_integer, .-silver_scalar_literals__read_integer
	.align 2
	.globl	silver_scalar_literals__digit
	.type	silver_scalar_literals__digit, @function
silver_scalar_literals__digit:
.LFB16:
	.loc 1 2 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movb	%dil, -1(%rbp)
	.loc 1 3 15
	movzbl	-1(%rbp), %eax
	.loc 1 3 7
	cmpb	$47, %al
	jbe	.L202
	.loc 1 3 15 discriminator 1
	movzbl	-1(%rbp), %eax
	cmpb	$57, %al
	ja	.L202
	.loc 1 3 55 discriminator 2
	movzbl	-1(%rbp), %eax
	movzbl	%al, %eax
	subq	$48, %rax
	jmp	.L203
.L202:
	.loc 1 4 18
	movzbl	-1(%rbp), %eax
	.loc 1 4 7
	cmpb	$64, %al
	jbe	.L204
	.loc 1 4 18 discriminator 1
	movzbl	-1(%rbp), %eax
	cmpb	$70, %al
	ja	.L204
	.loc 1 4 82 discriminator 2
	movzbl	-1(%rbp), %eax
	movzbl	%al, %eax
	subq	$55, %rax
	jmp	.L203
.L204:
	.loc 1 5 18
	movzbl	-1(%rbp), %eax
	.loc 1 5 7
	cmpb	$96, %al
	jbe	.L205
	.loc 1 5 18 discriminator 1
	movzbl	-1(%rbp), %eax
	cmpb	$102, %al
	ja	.L205
	.loc 1 5 82 discriminator 2
	movzbl	-1(%rbp), %eax
	movzbl	%al, %eax
	subq	$87, %rax
	jmp	.L203
.L205:
	.loc 1 6 12
	movl	$16, %eax
.L203:
	.loc 1 2 4
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE16:
	.size	silver_scalar_literals__digit, .-silver_scalar_literals__digit
	.globl	silver_scalar_literals_E
	.data
	.align 2
	.type	silver_scalar_literals_E, @object
	.size	silver_scalar_literals_E, 2
silver_scalar_literals_E:
	.zero	2
	.globl	silver_scalar_literals__invalid
	.section	.rodata
	.align 16
	.type	silver_scalar_literals__invalid, @object
	.size	silver_scalar_literals__invalid, 16
silver_scalar_literals__invalid:
	.zero	16
	.globl	silver_scalar_literals__invalid_mantissa
	.align 16
	.type	silver_scalar_literals__invalid_mantissa, @object
	.size	silver_scalar_literals__invalid_mantissa, 24
silver_scalar_literals__invalid_mantissa:
	.long	0
	.zero	4
	.quad	0
	.quad	10
	.globl	silver_scalar_literals__invalid_scale
	.align 16
	.type	silver_scalar_literals__invalid_scale, @object
	.size	silver_scalar_literals__invalid_scale, 16
silver_scalar_literals__invalid_scale:
	.zero	16
	.text
.Letext0:
	.file 3 "<built-in>"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x638
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x11
	.long	.LASF46
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.long	.LLRL1
	.quad	0
	.long	.Ldebug_line0
	.uleb128 0x9
	.sleb128 0
	.sleb128 4097
	.long	.LASF2
	.long	0x3b
	.uleb128 0x4
	.long	0x2a
	.uleb128 0x6
	.byte	0x4
	.byte	0x5
	.long	.LASF4
	.uleb128 0x9
	.sleb128 0
	.sleb128 2147483648
	.long	.LASF3
	.long	0x56
	.uleb128 0x4
	.long	0x42
	.uleb128 0x6
	.byte	0x8
	.byte	0x5
	.long	.LASF5
	.uleb128 0x9
	.sleb128 2
	.sleb128 16
	.long	.LASF6
	.long	0x56
	.uleb128 0x4
	.long	0x5d
	.uleb128 0xa
	.long	.LASF9
	.byte	0x10
	.byte	0x2
	.byte	0xa
	.long	0x92
	.uleb128 0x5
	.long	.LASF7
	.byte	0x2
	.byte	0xb
	.long	0x2a
	.byte	0
	.uleb128 0x5
	.long	.LASF8
	.byte	0x2
	.byte	0xc
	.long	0x42
	.byte	0x8
	.byte	0
	.uleb128 0x4
	.long	0x6d
	.uleb128 0xa
	.long	.LASF10
	.byte	0x18
	.byte	0x1
	.byte	0x56
	.long	0xc8
	.uleb128 0x5
	.long	.LASF7
	.byte	0x1
	.byte	0x57
	.long	0x2a
	.byte	0
	.uleb128 0x5
	.long	.LASF8
	.byte	0x1
	.byte	0x58
	.long	0x42
	.byte	0x8
	.uleb128 0x5
	.long	.LASF11
	.byte	0x1
	.byte	0x59
	.long	0x5d
	.byte	0x10
	.byte	0
	.uleb128 0x4
	.long	0x97
	.uleb128 0xa
	.long	.LASF12
	.byte	0x10
	.byte	0x1
	.byte	0x91
	.long	0xf2
	.uleb128 0x5
	.long	.LASF13
	.byte	0x1
	.byte	0x92
	.long	0xf7
	.byte	0
	.uleb128 0x5
	.long	.LASF8
	.byte	0x1
	.byte	0x93
	.long	0x42
	.byte	0x8
	.byte	0
	.uleb128 0x4
	.long	0xcd
	.uleb128 0x6
	.byte	0x1
	.byte	0x2
	.long	.LASF14
	.uleb128 0xb
	.long	.LASF15
	.byte	0x2
	.byte	0xe
	.long	0x92
	.uleb128 0x9
	.byte	0x3
	.quad	silver_scalar_literals__invalid
	.uleb128 0xb
	.long	.LASF16
	.byte	0x1
	.byte	0x5b
	.long	0xc8
	.uleb128 0x9
	.byte	0x3
	.quad	silver_scalar_literals__invalid_mantissa
	.uleb128 0xb
	.long	.LASF17
	.byte	0x1
	.byte	0x95
	.long	0xf2
	.uleb128 0x9
	.byte	0x3
	.quad	silver_scalar_literals__invalid_scale
	.uleb128 0x12
	.long	.LASF19
	.byte	0x2
	.byte	0x6
	.byte	0x4
	.long	0x154
	.long	0x80000000
	.uleb128 0x6
	.byte	0x10
	.byte	0x5
	.long	.LASF18
	.uleb128 0x4
	.long	0x14d
	.uleb128 0x13
	.long	.LASF20
	.byte	0x2
	.byte	0x7
	.byte	0x4
	.long	0x154
	.value	0x1000
	.uleb128 0x14
	.long	.LASF47
	.byte	0x2
	.byte	0x1
	.byte	0x6
	.uleb128 0x15
	.byte	0x2
	.byte	0x4
	.byte	0x4
	.long	0x167
	.uleb128 0x16
	.long	.LASF22
	.byte	0x1
	.byte	0x2
	.byte	0x4
	.long	0x1a9
	.quad	.LFB16
	.quad	.LFE16-.LFB16
	.uleb128 0x1
	.byte	0x9c
	.long	0x1a9
	.uleb128 0x1
	.long	.LASF24
	.byte	0x1
	.byte	0x2
	.byte	0x14
	.long	0x1b7
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.byte	0
	.uleb128 0x6
	.byte	0x8
	.byte	0x5
	.long	.LASF5
	.uleb128 0x6
	.byte	0x1
	.byte	0x8
	.long	.LASF21
	.uleb128 0x4
	.long	0x1b0
	.uleb128 0xd
	.long	.LASF23
	.byte	0xeb
	.long	0x6d
	.quad	.LFB14
	.quad	.LFE14-.LFB14
	.uleb128 0x1
	.byte	0x9c
	.long	0x277
	.uleb128 0x1
	.long	.LASF25
	.byte	0x2
	.byte	0x1c
	.byte	0x1b
	.long	0x2ce
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x1
	.long	.LASF26
	.byte	0x2
	.byte	0x1c
	.byte	0x2a
	.long	0x36
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x2
	.quad	.LBB44
	.quad	.LBE44-.LBB44
	.uleb128 0x8
	.long	.LASF32
	.long	0x6d
	.quad	.LFB15
	.quad	.LFE15-.LFB15
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -120
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x2
	.quad	.LBB42
	.quad	.LBE42-.LBB42
	.uleb128 0x3
	.long	.LASF27
	.byte	0xed
	.byte	0x7
	.long	0x97
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x2
	.quad	.LBB43
	.quad	.LBE43-.LBB43
	.uleb128 0x3
	.long	.LASF28
	.byte	0xf1
	.byte	0xa
	.long	0x6d
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x17
	.long	.LASF29
	.byte	0x10
	.byte	0x3
	.byte	0
	.long	0x2ba
	.uleb128 0xe
	.long	.LASF30
	.long	0x28d
	.byte	0
	.uleb128 0xf
	.long	0x2d3
	.uleb128 0x18
	.byte	0x8
	.byte	0x3
	.byte	0
	.long	0x2af
	.uleb128 0x10
	.string	"LB0"
	.long	0x2f2
	.byte	0
	.uleb128 0x10
	.string	"UB0"
	.long	0x2f2
	.byte	0x4
	.byte	0
	.uleb128 0xe
	.long	.LASF31
	.long	0x300
	.byte	0x8
	.byte	0
	.uleb128 0x7
	.long	0x277
	.uleb128 0x7
	.long	0x277
	.uleb128 0x7
	.long	0x277
	.uleb128 0x7
	.long	0x277
	.uleb128 0x7
	.long	0x277
	.uleb128 0x19
	.long	0x1b0
	.long	0x2f2
	.uleb128 0x1a
	.long	0x3b
	.uleb128 0x6
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x94
	.byte	0x4
	.uleb128 0x8
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x23
	.uleb128 0x4
	.byte	0x94
	.byte	0x4
	.byte	0
	.uleb128 0x1b
	.sleb128 2147483647
	.long	.LASF48
	.long	0x3b
	.uleb128 0xf
	.long	0x292
	.uleb128 0xc
	.long	.LASF37
	.byte	0xd0
	.long	0x6d
	.quad	.LFB12
	.quad	.LFE12-.LFB12
	.uleb128 0x1
	.byte	0x9c
	.long	0x3bf
	.uleb128 0x1
	.long	.LASF25
	.byte	0x1
	.byte	0xc9
	.byte	0x1c
	.long	0x2c9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x1
	.long	.LASF27
	.byte	0x1
	.byte	0xc9
	.byte	0x2b
	.long	0x3bf
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x2
	.quad	.LBB36
	.quad	.LBE36-.LBB36
	.uleb128 0x8
	.long	.LASF33
	.long	0x6d
	.quad	.LFB13
	.quad	.LFE13-.LFB13
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x2
	.quad	.LBB34
	.quad	.LBE34-.LBB34
	.uleb128 0x3
	.long	.LASF34
	.byte	0xd4
	.byte	0xd
	.long	0x6d
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x2
	.quad	.LBB35
	.quad	.LBE35-.LBB35
	.uleb128 0x3
	.long	.LASF35
	.byte	0xd9
	.byte	0x10
	.long	0xcd
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x1c
	.byte	0x8
	.long	0x97
	.uleb128 0xd
	.long	.LASF36
	.byte	0xb7
	.long	0x2a
	.quad	.LFB10
	.quad	.LFE10-.LFB10
	.uleb128 0x1
	.byte	0x9c
	.long	0x43c
	.uleb128 0x1
	.long	.LASF25
	.byte	0x1
	.byte	0xb2
	.byte	0x1d
	.long	0x2c4
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF26
	.byte	0x1
	.byte	0xb2
	.byte	0x2c
	.long	0x36
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x2
	.quad	.LBB27
	.quad	.LBE27-.LBB27
	.uleb128 0x1d
	.long	.LASF49
	.long	0x2a
	.quad	.LFB11
	.quad	.LFE11-.LFB11
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -24
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.byte	0
	.byte	0
	.uleb128 0xc
	.long	.LASF38
	.byte	0xa2
	.long	0xcd
	.quad	.LFB9
	.quad	.LFE9-.LFB9
	.uleb128 0x1
	.byte	0x9c
	.long	0x4c7
	.uleb128 0x1
	.long	.LASF11
	.byte	0x1
	.byte	0xa0
	.byte	0x14
	.long	0x68
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x1
	.long	.LASF8
	.byte	0x1
	.byte	0xa0
	.byte	0x29
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x1
	.long	.LASF34
	.byte	0x1
	.byte	0xa0
	.byte	0x30
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -88
	.uleb128 0x3
	.long	.LASF28
	.byte	0xa3
	.byte	0x7
	.long	0x42
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x1e
	.long	.LASF50
	.long	0x42
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x2
	.quad	.LBB24
	.quad	.LBE24-.LBB24
	.uleb128 0x3
	.long	.LASF39
	.byte	0xa9
	.byte	0xb
	.long	0x56
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.byte	0
	.byte	0
	.uleb128 0xc
	.long	.LASF40
	.byte	0x7c
	.long	0x97
	.quad	.LFB6
	.quad	.LFE6-.LFB6
	.uleb128 0x1
	.byte	0x9c
	.long	0x575
	.uleb128 0x1
	.long	.LASF25
	.byte	0x1
	.byte	0x74
	.byte	0x1c
	.long	0x2bf
	.uleb128 0x3
	.byte	0x91
	.sleb128 -176
	.uleb128 0x1
	.long	.LASF26
	.byte	0x1
	.byte	0x74
	.byte	0x2b
	.long	0x36
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x2
	.quad	.LBB18
	.quad	.LBE18-.LBB18
	.uleb128 0x8
	.long	.LASF41
	.long	0x97
	.quad	.LFB7
	.quad	.LFE7-.LFB7
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -96
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x1f
	.long	.LLRL0
	.uleb128 0x3
	.long	.LASF42
	.byte	0x7d
	.byte	0x7
	.long	0x6d
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x2
	.quad	.LBB16
	.quad	.LBE16-.LBB16
	.uleb128 0x3
	.long	.LASF27
	.byte	0x85
	.byte	0xd
	.long	0x6d
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x20
	.long	.LASF51
	.byte	0x1
	.byte	0x36
	.byte	0x4
	.long	0x6d
	.quad	.LFB3
	.quad	.LFE3-.LFB3
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x1
	.long	.LASF25
	.byte	0x1
	.byte	0x2d
	.byte	0x16
	.long	0x2ba
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x1
	.long	.LASF26
	.byte	0x1
	.byte	0x2d
	.byte	0x25
	.long	0x36
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x1
	.long	.LASF11
	.byte	0x1
	.byte	0x2d
	.byte	0x42
	.long	0x68
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x2
	.quad	.LBB9
	.quad	.LBE9-.LBB9
	.uleb128 0x8
	.long	.LASF43
	.long	0x6d
	.quad	.LFB4
	.quad	.LFE4-.LFB4
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -104
	.byte	0x6
	.byte	0x23
	.uleb128 0x28
	.byte	0x6
	.uleb128 0x2
	.quad	.LBB2
	.quad	.LBE2-.LBB2
	.uleb128 0x3
	.long	.LASF44
	.byte	0x38
	.byte	0x7
	.long	0x2a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x3
	.long	.LASF8
	.byte	0x39
	.byte	0x7
	.long	0x42
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x3
	.long	.LASF45
	.byte	0x3a
	.byte	0x7
	.long	0xf7
	.uleb128 0x3
	.byte	0x91
	.sleb128 -81
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 7
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0xd
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x55
	.uleb128 0x17
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x27
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x1c
	.uleb128 0x6
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0x27
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x1c
	.uleb128 0x5
	.byte	0
	.byte	0
	.uleb128 0x14
	.uleb128 0x1e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x15
	.uleb128 0x3a
	.byte	0
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x18
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x16
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x17
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x18
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x19
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1a
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x18
	.uleb128 0x2f
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x1b
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1c
	.uleb128 0x10
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1d
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x1e
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x1f
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x55
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x20
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x4c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.LFE3-.Ltext0
	.quad	.LFB7
	.quad	.LFE6-.LFB7
	.quad	.LFB9
	.quad	.Letext0-.LFB9
	.quad	0
	.quad	0
	.section	.debug_rnglists,"",@progbits
.Ldebug_ranges0:
	.long	.Ldebug_ranges3-.Ldebug_ranges2
.Ldebug_ranges2:
	.value	0x5
	.byte	0x8
	.byte	0
	.long	0
.LLRL0:
	.byte	0x5
	.quad	.LBB15
	.byte	0x4
	.uleb128 .LBB15-.LBB15
	.uleb128 .LBE15-.LBB15
	.byte	0x4
	.uleb128 .LBB17-.LBB15
	.uleb128 .LBE17-.LBB15
	.byte	0
.LLRL1:
	.byte	0x7
	.quad	.Ltext0
	.uleb128 .LFE3-.Ltext0
	.byte	0x7
	.quad	.LFB7
	.uleb128 .LFE6-.LFB7
	.byte	0x7
	.quad	.LFB9
	.uleb128 .Letext0-.LFB9
	.byte	0
.Ldebug_ranges3:
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF30:
	.string	"P_ARRAY"
.LASF43:
	.string	"silver_scalar_literals__numeral___wrapped_statements"
.LASF44:
	.string	"next"
.LASF50:
	.string	"silver_scalar_literals__power__L_3__T64b___U"
.LASF22:
	.string	"silver_scalar_literals__digit"
.LASF21:
	.string	"character"
.LASF8:
	.string	"value"
.LASF40:
	.string	"silver_scalar_literals__read_mantissa"
.LASF48:
	.string	"positive"
.LASF3:
	.string	"silver_scalar_literals__literal_value"
.LASF25:
	.string	"text"
.LASF29:
	.string	"string"
.LASF31:
	.string	"P_BOUNDS"
.LASF51:
	.string	"silver_scalar_literals__numeral"
.LASF2:
	.string	"silver_scalar_literals__literal_position"
.LASF32:
	.string	"silver_scalar_literals__read_integer___wrapped_statements"
.LASF49:
	.string	"silver_scalar_literals__exponent_start___wrapped_statements"
.LASF47:
	.string	"silver_profile"
.LASF19:
	.string	"silver_scalar_literals__max_magnitude"
.LASF11:
	.string	"base"
.LASF45:
	.string	"need_digit"
.LASF38:
	.string	"silver_scalar_literals__power"
.LASF36:
	.string	"silver_scalar_literals__exponent_start"
.LASF23:
	.string	"silver_scalar_literals__read_integer"
.LASF26:
	.string	"position"
.LASF16:
	.string	"silver_scalar_literals__invalid_mantissa"
.LASF7:
	.string	"after"
.LASF33:
	.string	"silver_scalar_literals__read_exponent___wrapped_statements"
.LASF28:
	.string	"result"
.LASF12:
	.string	"silver_scalar_literals__scale_result"
.LASF27:
	.string	"number"
.LASF35:
	.string	"scaled"
.LASF39:
	.string	"index"
.LASF5:
	.string	"long_long_integer"
.LASF37:
	.string	"silver_scalar_literals__read_exponent"
.LASF34:
	.string	"exponent"
.LASF42:
	.string	"leading"
.LASF18:
	.string	"universal_integer"
.LASF4:
	.string	"integer"
.LASF6:
	.string	"silver_scalar_literals__literal_base"
.LASF41:
	.string	"silver_scalar_literals__read_mantissa___wrapped_statements"
.LASF9:
	.string	"silver_scalar_literals__literal_result"
.LASF10:
	.string	"silver_scalar_literals__mantissa_result"
.LASF20:
	.string	"silver_scalar_literals__max_exponent"
.LASF24:
	.string	"item"
.LASF46:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF14:
	.string	"boolean"
.LASF17:
	.string	"silver_scalar_literals__invalid_scale"
.LASF15:
	.string	"silver_scalar_literals__invalid"
.LASF13:
	.string	"valid"
	.section	.debug_line_str,"MS",@progbits,1
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_scalar_literals.adb"
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
