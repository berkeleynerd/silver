	.file	"silver_report_projection.adb"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_report_projection.adb"
	.align 2
	.globl	silver_report_projection__complete
	.type	silver_report_projection__complete, @function
silver_report_projection__complete:
.LFB2:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_report_projection.ads"
	.loc 1 17 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	.loc 1 18 7
	movq	-8(%rbp), %rax
	movzbl	356(%rax), %eax
	xorl	$1, %eax
	.loc 1 19 7
	testb	%al, %al
	je	.L2
	.loc 1 18 49 discriminator 1
	movq	-8(%rbp), %rax
	movl	320(%rax), %eax
	.loc 1 18 26 discriminator 1
	testl	%eax, %eax
	jne	.L2
	.loc 1 19 31 discriminator 1
	movq	-8(%rbp), %rax
	movzbl	324(%rax), %eax
	.loc 1 19 7 discriminator 1
	testb	%al, %al
	jne	.L3
	.loc 1 20 18
	movq	-8(%rbp), %rax
	movzbl	355(%rax), %eax
	testb	%al, %al
	jne	.L4
.L3:
	.loc 1 21 31
	movq	-8(%rbp), %rax
	movzbl	324(%rax), %eax
	.loc 1 21 9
	cmpb	$4, %al
	jne	.L2
	.loc 1 22 68
	movq	-8(%rbp), %rax
	movzbl	325(%rax), %eax
	.loc 1 22 11
	cmpb	$1, %al
	je	.L4
	.loc 1 23 45
	movq	-8(%rbp), %rax
	movzbl	325(%rax), %eax
	cmpb	$2, %al
	je	.L4
	.loc 1 24 45
	movq	-8(%rbp), %rax
	movzbl	325(%rax), %eax
	cmpb	$4, %al
	je	.L4
	.loc 1 25 45
	movq	-8(%rbp), %rax
	movzbl	325(%rax), %eax
	cmpb	$7, %al
	jne	.L2
.L4:
	.loc 1 19 7 discriminator 2
	movl	$1, %eax
	jmp	.L5
.L2:
	.loc 1 19 7 is_stmt 0 discriminator 3
	movl	$0, %eax
.L5:
	.loc 1 17 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	silver_report_projection__complete, .-silver_report_projection__complete
	.section	.rodata
	.align 8
.LC3:
	.ascii	"failed precondition from silver_report_projection.adb:19"
.LC4:
	.ascii	"silver_report_projection.adb"
	.zero	1
	.align 8
.LC2:
	.long	1
	.long	56
	.text
	.align 2
	.type	silver_report_projection__advance__emit.6, @function
silver_report_projection__advance__emit.6:
.LFB4:
	.file 2 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_report_projection.adb"
	.loc 2 18 7
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movb	%dil, -17(%rbp)
	movq	%r10, %rax
	movq	%r10, -32(%rbp)
	.loc 2 19 35
	movl	364(%rax), %edx
	.loc 2 19 21
	cmpl	$1, %edx
	jle	.L8
.LBB2:
	.loc 2 19 21 is_stmt 0 discriminator 1
	leaq	.LC3(%rip), %rcx
	leaq	.LC2(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L8:
.LBE2:
	.loc 2 25 41 is_stmt 1
	movl	364(%rax), %edx
	addl	$1, %edx
	testl	%edx, %edx
	js	.L9
	.loc 2 25 41 is_stmt 0 discriminator 1
	cmpl	$2, %edx
	jle	.L10
.L9:
	.loc 2 25 41 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$25, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L10:
	.loc 2 25 24 is_stmt 1 discriminator 3
	movl	%edx, 364(%rax)
	.loc 2 26 30
	movl	364(%rax), %edx
	.loc 2 26 16
	testl	%edx, %edx
	jle	.L11
	.loc 2 26 16 is_stmt 0 discriminator 1
	cmpl	$2, %edx
	jle	.L12
.L11:
	.loc 2 26 16 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$26, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L12:
	.loc 2 26 39 is_stmt 1 discriminator 3
	movslq	%edx, %rdx
	movzbl	-17(%rbp), %ecx
	movb	%cl, 359(%rax,%rdx)
	.loc 2 27 11
	nop
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	silver_report_projection__advance__emit.6, .-silver_report_projection__advance__emit.6
	.section	.rodata
	.align 8
.LC0:
	.zero	8
	.text
	.align 2
	.globl	silver_report_projection__advance
	.type	silver_report_projection__advance, @function
silver_report_projection__advance:
.LFB3:
	.loc 2 11 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA3
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB0:
	subq	$456, %rsp
.LEHE0:
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, -456(%rbp)
	movq	%rsi, -464(%rbp)
	movb	%dl, -465(%rbp)
	.loc 2 11 4
	leaq	16(%rbp), %rax
	.loc 2 11 4 is_stmt 0 discriminator 1
	movq	%rax, -56(%rbp)
	movzbl	-465(%rbp), %eax
	movb	%al, -64(%rbp)
	.loc 2 12 30 is_stmt 1
	movq	-464(%rbp), %rdx
	leaq	-432(%rbp), %rax
	movq	%rdx, %rcx
	movl	$360, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	movw	$8224, -72(%rbp)
	movl	$0, -68(%rbp)
	.loc 2 13 7
	leaq	-432(%rbp), %rax
	movq	%rax, -40(%rbp)
	.loc 2 244 7
	movzbl	-76(%rbp), %eax
	testb	%al, %al
	je	.L15
	.loc 2 244 24 discriminator 1
	movq	-456(%rbp), %rax
	movq	%rax, %rcx
	leaq	-432(%rbp), %rax
	movl	$368, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	movl	$0, %eax
	jmp	.L16
.L15:
	.loc 2 245 13
	movzbl	-108(%rbp), %eax
	cmpb	$5, %al
	jbe	.L17
	.loc 2 245 13 is_stmt 0 discriminator 1
	leaq	.LC4(%rip), %rax
	movl	$245, %esi
	movq	%rax, %rdi
.LEHB1:
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L17:
	.loc 2 245 7 is_stmt 1 discriminator 2
	cmpb	$4, %al
	je	.L18
	cmpb	$4, %al
	ja	.L19
	cmpb	$3, %al
	je	.L20
	cmpb	$3, %al
	ja	.L19
	cmpb	$2, %al
	je	.L21
	cmpb	$2, %al
	ja	.L19
	testb	%al, %al
	je	.L22
	cmpb	$1, %al
	je	.L23
	jmp	.L19
.L22:
	.loc 2 246 33
	leaq	-432(%rbp), %rax
	movq	%rax, %r10
	call	silver_report_projection__advance__between.0
	.loc 2 291 11
	jmp	.L24
.L18:
	.loc 2 247 28
	leaq	-432(%rbp), %rax
	movq	%rax, %r10
	call	silver_report_projection__advance__number_byte.4
	.loc 2 291 11 discriminator 1
	jmp	.L24
.L23:
.LBB3:
	.loc 2 249 13
	movzbl	-79(%rbp), %eax
	testb	%al, %al
	je	.L25
	.loc 2 249 34 discriminator 1
	movzbl	-64(%rbp), %eax
	movsbl	%al, %eax
	leaq	-432(%rbp), %rdx
	movq	%rdx, %r10
	movl	%eax, %edi
	call	silver_report_projection__advance__emit.6
.L25:
	.loc 2 250 37
	movzbl	-64(%rbp), %eax
	.loc 2 250 13
	cmpb	$31, %al
	ja	.L26
	.loc 2 250 56 discriminator 1
	movb	$1, -76(%rbp)
.LBE3:
	.loc 2 291 11 discriminator 2
	jmp	.L65
.L26:
.LBB4:
	.loc 2 251 13
	movzbl	-64(%rbp), %eax
	cmpb	$34, %al
	jne	.L28
	.loc 2 251 35 discriminator 1
	leaq	-432(%rbp), %rax
	movq	%rax, %r10
	call	silver_report_projection__advance__end_string.5
.LBE4:
	.loc 2 291 11 discriminator 2
	jmp	.L65
.L28:
.LBB5:
	.loc 2 252 13
	movzbl	-64(%rbp), %eax
	cmpb	$92, %al
	jne	.L29
	.loc 2 253 23
	movb	$2, -108(%rbp)
	.loc 2 254 31
	movb	$1, -80(%rbp)
.LBE5:
	.loc 2 291 11 discriminator 2
	jmp	.L65
.L29:
.LBB6:
	.loc 2 255 13
	movzbl	-96(%rbp), %eax
	testb	%al, %al
	je	.L65
	.loc 2 255 58 discriminator 1
	movl	-84(%rbp), %eax
	.loc 2 255 35 discriminator 1
	cmpl	$10, %eax
	jg	.L65
	.loc 2 256 47
	movl	-84(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L30
	.loc 2 256 47 is_stmt 0 discriminator 1
	cmpl	$11, %eax
	jle	.L31
.L30:
	.loc 2 256 47 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$256, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L31:
	.loc 2 256 30 is_stmt 1 discriminator 3
	movl	%eax, -84(%rbp)
	.loc 2 257 33
	movl	-84(%rbp), %eax
	.loc 2 257 16
	cmpl	$10, %eax
	jg	.L65
	.loc 2 257 53 discriminator 1
	movl	-84(%rbp), %eax
	.loc 2 257 45 discriminator 1
	testl	%eax, %eax
	jle	.L32
	.loc 2 257 45 is_stmt 0 discriminator 2
	cmpl	$10, %eax
	jle	.L33
.L32:
	.loc 2 257 45 discriminator 3
	leaq	.LC4(%rip), %rax
	movl	$257, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L33:
	.loc 2 257 67 is_stmt 1 discriminator 4
	cltq
	movzbl	-64(%rbp), %edx
	movb	%dl, -96(%rbp,%rax)
.LBE6:
	.loc 2 291 11 discriminator 2
	jmp	.L65
.L21:
	.loc 2 260 13
	movzbl	-79(%rbp), %eax
	testb	%al, %al
	je	.L34
	.loc 2 260 34 discriminator 1
	movzbl	-64(%rbp), %eax
	movsbl	%al, %eax
	leaq	-432(%rbp), %rdx
	movq	%rdx, %r10
	movl	%eax, %edi
	call	silver_report_projection__advance__emit.6
.L34:
	.loc 2 261 13
	movzbl	-64(%rbp), %eax
	cmpb	$117, %al
	jne	.L35
	.loc 2 262 23
	movb	$3, -108(%rbp)
	.loc 2 263 31
	movl	$4, -100(%rbp)
	.loc 2 291 11 discriminator 3
	jmp	.L24
.L35:
	.loc 2 264 13
	movzbl	-64(%rbp), %eax
	cmpb	$34, %al
	je	.L37
	.loc 2 264 33 discriminator 1
	movzbl	-64(%rbp), %eax
	cmpb	$92, %al
	je	.L37
	.loc 2 264 39 discriminator 2
	movzbl	-64(%rbp), %eax
	cmpb	$47, %al
	je	.L37
	.loc 2 264 45 discriminator 3
	movzbl	-64(%rbp), %eax
	cmpb	$98, %al
	je	.L37
	.loc 2 264 51 discriminator 4
	movzbl	-64(%rbp), %eax
	cmpb	$102, %al
	je	.L37
	.loc 2 264 57 discriminator 5
	movzbl	-64(%rbp), %eax
	cmpb	$110, %al
	je	.L37
	.loc 2 264 63 discriminator 6
	movzbl	-64(%rbp), %eax
	cmpb	$114, %al
	je	.L37
	.loc 2 264 69 discriminator 7
	movzbl	-64(%rbp), %eax
	cmpb	$116, %al
	jne	.L38
.L37:
	.loc 2 265 23
	movb	$1, -108(%rbp)
	.loc 2 291 11 discriminator 3
	jmp	.L24
.L38:
	.loc 2 266 27
	movb	$1, -76(%rbp)
	.loc 2 291 11 discriminator 3
	jmp	.L24
.L20:
.LBB7:
	.loc 2 269 13
	movzbl	-79(%rbp), %eax
	testb	%al, %al
	je	.L39
	.loc 2 269 34 discriminator 1
	movzbl	-64(%rbp), %eax
	movsbl	%al, %eax
	leaq	-432(%rbp), %rdx
	movq	%rdx, %r10
	movl	%eax, %edi
	call	silver_report_projection__advance__emit.6
.L39:
	.loc 2 270 20
	movzbl	-64(%rbp), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_report_projection__hex
	.loc 2 270 16 discriminator 1
	xorl	$1, %eax
	.loc 2 270 13 discriminator 1
	testb	%al, %al
	jne	.L40
	.loc 2 270 54 discriminator 2
	movl	-100(%rbp), %eax
	.loc 2 270 31 discriminator 2
	testl	%eax, %eax
	jne	.L41
.L40:
	.loc 2 270 72 discriminator 3
	movb	$1, -76(%rbp)
.LBE7:
	.loc 2 291 11 discriminator 4
	jmp	.L66
.L41:
.LBB8:
	.loc 2 272 49
	movl	-100(%rbp), %eax
	subl	$1, %eax
	testl	%eax, %eax
	js	.L43
	.loc 2 272 49 is_stmt 0 discriminator 1
	cmpl	$4, %eax
	jle	.L44
.L43:
	.loc 2 272 49 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$272, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L44:
	.loc 2 272 31 is_stmt 1 discriminator 3
	movl	%eax, -100(%rbp)
	.loc 2 273 34
	movl	-100(%rbp), %eax
	.loc 2 273 16
	testl	%eax, %eax
	jne	.L66
	.loc 2 273 50 discriminator 1
	movb	$1, -108(%rbp)
.LBE8:
	.loc 2 291 11 discriminator 4
	jmp	.L66
.L19:
	.loc 2 276 13
	movzbl	-79(%rbp), %eax
	testb	%al, %al
	je	.L45
	.loc 2 276 34 discriminator 1
	movzbl	-64(%rbp), %eax
	movsbl	%al, %eax
	leaq	-432(%rbp), %rdx
	movq	%rdx, %r10
	movl	%eax, %edi
	call	silver_report_projection__advance__emit.6
.L45:
.LBB9:
	.loc 2 279 19
	movl	$0, %r12d
	leaq	.LC0(%rip), %r13
	.loc 2 279 25
	movzbl	-106(%rbp), %eax
	cmpb	$2, %al
	jbe	.L46
	.loc 2 279 25 is_stmt 0 discriminator 1
	leaq	.LC4(%rip), %rax
	movl	$279, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L46:
	.loc 2 279 19 is_stmt 1 discriminator 2
	testb	%al, %al
	je	.L47
	cmpb	$1, %al
	je	.L48
	jmp	.L63
.L47:
	.loc 2 279 58 discriminator 3
	leaq	8+C106b___UNC.10(%rip), %r12
	leaq	C106b___UNC.10(%rip), %r13
	.loc 2 279 19 discriminator 3
	jmp	.L50
.L48:
	.loc 2 280 41
	leaq	8+C107b___UNC.9(%rip), %r12
	leaq	C107b___UNC.9(%rip), %r13
	.loc 2 279 19 discriminator 4
	jmp	.L50
.L63:
	.loc 2 280 71 discriminator 1
	leaq	8+C108b___UNC.8(%rip), %r12
	leaq	C108b___UNC.8(%rip), %r13
	.loc 2 279 19 discriminator 5
	nop
.L50:
	.loc 2 278 16
	movq	%r12, %rax
	movq	%r13, %rdx
	movq	%rax, -448(%rbp)
	movq	%rdx, -440(%rbp)
	.loc 2 282 38
	movq	%rdx, %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movl	-104(%rbp), %esi
	movslq	%esi, %rsi
	subq	$1, %rsi
	addq	%rcx, %rsi
	movq	%rdx, %rcx
	movl	4(%rcx), %ecx
	movslq	%ecx, %rcx
	.loc 2 282 16
	cmpq	%rcx, %rsi
	jg	.L51
	.loc 2 283 45
	movl	-104(%rbp), %ecx
	.loc 2 283 34
	movq	%rdx, %rsi
	movl	(%rsi), %esi
	cmpl	%esi, %ecx
	jl	.L52
	.loc 2 283 34 is_stmt 0 discriminator 1
	movq	%rdx, %rsi
	movl	4(%rsi), %esi
	cmpl	%esi, %ecx
	jle	.L53
.L52:
	.loc 2 283 34 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$283, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L53:
	.loc 2 283 31 is_stmt 1 discriminator 3
	movq	%rax, %rdi
	movq	%rdx, %rsi
	movl	(%rsi), %esi
	movslq	%esi, %rsi
	movslq	%ecx, %rcx
	subq	%rsi, %rcx
	movzbl	(%rdi,%rcx), %ecx
	.loc 2 283 31 is_stmt 0 discriminator 4
	movzbl	-64(%rbp), %esi
	cmpb	%cl, %sil
	setne	%cl
	.loc 2 283 18 is_stmt 1 discriminator 4
	testb	%cl, %cl
	je	.L54
.L51:
	.loc 2 284 30
	movb	$1, -76(%rbp)
	jmp	.L55
.L54:
	.loc 2 285 41
	movq	%rdx, %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movl	-104(%rbp), %esi
	movslq	%esi, %rsi
	subq	$1, %rsi
	addq	%rsi, %rcx
	movq	%rdx, %rax
	movl	4(%rax), %eax
	cltq
	.loc 2 285 16
	cmpq	%rax, %rcx
	jne	.L56
	.loc 2 286 26
	movb	$0, -108(%rbp)
	.loc 2 287 19
	leaq	-432(%rbp), %rax
	movq	%rax, %r10
	call	silver_report_projection__advance__end_value.7
	jmp	.L55
.L56:
	.loc 2 288 62
	movl	-104(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L57
	.loc 2 288 62 is_stmt 0 discriminator 1
	cmpl	$5, %eax
	jle	.L58
.L57:
	.loc 2 288 62 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$288, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.LEHE1:
.L58:
	.loc 2 288 40 is_stmt 1 discriminator 3
	movl	%eax, -104(%rbp)
.L55:
.LBE9:
	.loc 2 291 11 discriminator 5
	jmp	.L24
.L65:
	.loc 2 291 11 is_stmt 0 discriminator 2
	nop
	jmp	.L24
.L66:
	.loc 2 291 11 discriminator 4
	nop
.L24:
	.loc 2 292 7 is_stmt 1
	movq	-456(%rbp), %rax
	movq	%rax, %rcx
	leaq	-432(%rbp), %rax
	movl	$368, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	movl	$0, %eax
.L16:
	.loc 2 293 8
	cmpl	$1, %eax
	je	.L59
	jmp	.L64
.L62:
.LBB10:
	.loc 2 290 16 discriminator 1
	movq	%rax, %rbx
	movl	$1, %eax
	jmp	.L16
.L59:
	movq	%rbx, %rax
	movq	%rax, %rdi
.LEHB2:
	call	_Unwind_Resume@PLT
.L64:
.LBE10:
	.loc 2 293 8
	movq	-456(%rbp), %rax
	addq	$456, %rsp
.LEHE2:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.section	.gcc_except_table,"a",@progbits
.LLSDA3:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE3-.LLSDACSB3
.LLSDACSB3:
	.uleb128 .LEHB0-.LFB3
	.uleb128 .LEHE0-.LEHB0
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB1-.LFB3
	.uleb128 .LEHE1-.LEHB1
	.uleb128 .L62-.LFB3
	.uleb128 0
	.uleb128 .LEHB2-.LFB3
	.uleb128 .LEHE2-.LEHB2
	.uleb128 0
	.uleb128 0
.LLSDACSE3:
	.text
	.size	silver_report_projection__advance, .-silver_report_projection__advance
	.align 2
	.type	silver_report_projection__advance__end_value.7, @function
silver_report_projection__advance__end_value.7:
.LFB5:
	.loc 2 29 7
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	.loc 2 35 21
	movl	320(%rax), %edx
	.loc 2 35 10
	testl	%edx, %edx
	jne	.L68
	.loc 2 36 24
	movb	$1, 355(%rax)
	.loc 2 42 11
	jmp	.L77
.L68:
	.loc 2 37 26
	movl	320(%rax), %edx
	.loc 2 37 17
	testl	%edx, %edx
	jle	.L70
	.loc 2 37 17 is_stmt 0 discriminator 1
	cmpl	$64, %edx
	jle	.L71
.L70:
	.loc 2 37 17 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$37, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L71:
	.loc 2 37 44 is_stmt 1 discriminator 3
	movslq	%edx, %rdx
	leaq	-1(%rdx), %rcx
	movq	%rcx, %rdx
	salq	$2, %rdx
	addq	%rcx, %rdx
	addq	%rax, %rdx
	movzbl	(%rdx), %edx
	.loc 2 37 10 discriminator 3
	testb	%dl, %dl
	jne	.L72
	.loc 2 38 23
	movl	320(%rax), %edx
	.loc 2 38 14
	testl	%edx, %edx
	jle	.L73
	.loc 2 38 14 is_stmt 0 discriminator 1
	cmpl	$64, %edx
	jle	.L74
.L73:
	.loc 2 38 14 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$38, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L74:
	.loc 2 38 40 is_stmt 1 discriminator 3
	movslq	%edx, %rdx
	leaq	-1(%rdx), %rcx
	movq	%rcx, %rdx
	salq	$2, %rdx
	addq	%rcx, %rdx
	addq	%rdx, %rax
	addq	$1, %rax
	movb	$4, (%rax)
	.loc 2 42 11
	jmp	.L77
.L72:
	.loc 2 40 23
	movl	320(%rax), %edx
	.loc 2 40 14
	testl	%edx, %edx
	jle	.L75
	.loc 2 40 14 is_stmt 0 discriminator 1
	cmpl	$64, %edx
	jle	.L76
.L75:
	.loc 2 40 14 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$40, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L76:
	.loc 2 40 40 is_stmt 1 discriminator 3
	movslq	%edx, %rdx
	leaq	-1(%rdx), %rcx
	movq	%rcx, %rdx
	salq	$2, %rdx
	addq	%rcx, %rdx
	addq	%rdx, %rax
	addq	$1, %rax
	movb	$7, (%rax)
.L77:
	.loc 2 42 11 discriminator 1
	nop
	.loc 2 42 11 is_stmt 0
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE5:
	.size	silver_report_projection__advance__end_value.7, .-silver_report_projection__advance__end_value.7
	.section	.rodata
.LC5:
	.ascii	"proof"
.LC6:
	.ascii	"check_tree"
	.text
	.align 2
	.type	silver_report_projection__advance__end_string.5, @function
silver_report_projection__advance__end_string.5:
.LFB6:
	.loc 2 44 7 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%r10, %rbx
	movq	%r10, -24(%rbp)
	.loc 2 50 17
	movb	$0, 324(%rbx)
	.loc 2 51 10
	movzbl	336(%rbx), %eax
	testb	%al, %al
	je	.L79
	.loc 2 52 24
	movl	320(%rbx), %eax
	.loc 2 52 13
	testl	%eax, %eax
	jne	.L80
	.loc 2 53 25
	movb	$1, 356(%rbx)
	.loc 2 54 16
	jmp	.L78
.L80:
	.loc 2 56 23
	movl	320(%rbx), %eax
	.loc 2 56 14
	testl	%eax, %eax
	jle	.L82
	.loc 2 56 14 is_stmt 0 discriminator 1
	cmpl	$64, %eax
	jle	.L83
.L82:
	.loc 2 56 14 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$56, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L83:
	.loc 2 56 35 is_stmt 1 discriminator 3
	cltq
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	addq	%rbx, %rax
	addq	$3, %rax
	movb	$0, (%rax)
	.loc 2 57 16
	movzbl	352(%rbx), %eax
	xorl	$1, %eax
	.loc 2 57 13
	testb	%al, %al
	je	.L84
	.loc 2 58 33
	movl	348(%rbx), %eax
	.loc 2 58 16
	cmpl	$4, %eax
	jne	.L85
	.loc 2 58 62 discriminator 1
	movl	337(%rbx), %eax
	cmpl	$2003790950, %eax
	sete	%al
	.loc 2 58 37 discriminator 1
	testb	%al, %al
	je	.L85
	.loc 2 59 29
	movl	320(%rbx), %eax
	.loc 2 59 20
	testl	%eax, %eax
	jle	.L86
	.loc 2 59 20 is_stmt 0 discriminator 1
	cmpl	$64, %eax
	jle	.L87
.L86:
	.loc 2 59 20 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$59, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L87:
	.loc 2 59 41 is_stmt 1 discriminator 3
	cltq
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	addq	%rbx, %rax
	addq	$3, %rax
	movb	$1, (%rax)
	jmp	.L84
.L85:
	.loc 2 60 36
	movl	348(%rbx), %eax
	.loc 2 60 16
	cmpl	$5, %eax
	jne	.L89
	.loc 2 60 65 discriminator 1
	leaq	337(%rbx), %rax
	leaq	.LC5(%rip), %rcx
	movl	$5, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcmp@PLT
	.loc 2 60 65 is_stmt 0 discriminator 2
	testl	%eax, %eax
	sete	%al
	.loc 2 60 40 is_stmt 1 discriminator 2
	testb	%al, %al
	je	.L89
	.loc 2 61 29
	movl	320(%rbx), %eax
	.loc 2 61 20
	testl	%eax, %eax
	jle	.L90
	.loc 2 61 20 is_stmt 0 discriminator 1
	cmpl	$64, %eax
	jle	.L91
.L90:
	.loc 2 61 20 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$61, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L91:
	.loc 2 61 41 is_stmt 1 discriminator 3
	cltq
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	addq	%rbx, %rax
	addq	$3, %rax
	movb	$2, (%rax)
	jmp	.L84
.L89:
	.loc 2 62 36
	movl	348(%rbx), %eax
	.loc 2 62 16
	cmpl	$10, %eax
	jne	.L84
	.loc 2 62 57 discriminator 1
	leaq	337(%rbx), %rax
	leaq	.LC6(%rip), %rcx
	movl	$10, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcmp@PLT
	.loc 2 62 41 discriminator 2
	testl	%eax, %eax
	jne	.L84
	.loc 2 63 29
	movl	320(%rbx), %eax
	.loc 2 63 20
	testl	%eax, %eax
	jle	.L92
	.loc 2 63 20 is_stmt 0 discriminator 1
	cmpl	$64, %eax
	jle	.L93
.L92:
	.loc 2 63 20 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$63, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L93:
	.loc 2 63 41 is_stmt 1 discriminator 3
	cltq
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	addq	%rbx, %rax
	addq	$3, %rax
	movb	$3, (%rax)
.L84:
	.loc 2 66 23
	movl	320(%rbx), %eax
	.loc 2 66 14
	testl	%eax, %eax
	jle	.L94
	.loc 2 66 14 is_stmt 0 discriminator 1
	cmpl	$64, %eax
	jle	.L95
.L94:
	.loc 2 66 14 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$66, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L95:
	.loc 2 66 40 is_stmt 1 discriminator 3
	cltq
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	addq	%rbx, %rax
	addq	$1, %rax
	movb	$2, (%rax)
	.loc 2 70 11
	jmp	.L97
.L79:
	.loc 2 68 13
	movq	%rbx, %r10
	call	silver_report_projection__advance__end_value.7
.L97:
	.loc 2 70 11
	nop
.L78:
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE6:
	.size	silver_report_projection__advance__end_string.5, .-silver_report_projection__advance__end_string.5
	.align 2
	.type	silver_report_projection__advance__start_string.1, @function
silver_report_projection__advance__start_string.1:
.LFB7:
	.loc 2 72 7
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movb	%dil, -1(%rbp)
	movb	%sil, -2(%rbp)
	movq	%r10, %rax
	movq	%r10, -16(%rbp)
	.loc 2 78 17
	movb	$1, 324(%rax)
	.loc 2 79 26
	movzbl	-1(%rbp), %edx
	movb	%dl, 336(%rax)
	.loc 2 80 23
	movzbl	-2(%rbp), %edx
	movb	%dl, 353(%rax)
	.loc 2 81 24
	movl	$0, 348(%rax)
	.loc 2 82 25
	movb	$0, 352(%rax)
	.loc 2 83 17
	movabsq	$2314885530818453536, %rcx
	movq	%rcx, 337(%rax)
	movw	$8224, 345(%rax)
	.loc 2 84 11
	nop
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE7:
	.size	silver_report_projection__advance__start_string.1, .-silver_report_projection__advance__start_string.1
	.section	.rodata
	.align 8
.LC7:
	.ascii	"failed precondition from silver_report_projection.adb:87"
	.text
	.align 2
	.type	silver_report_projection__advance__start_value.2, @function
silver_report_projection__advance__start_value.2:
.LFB8:
	.loc 2 86 7
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 3, -24
	movq	%r10, %rbx
	movq	%r10, -40(%rbp)
	.loc 2 87 35
	movl	364(%rbx), %ecx
	.loc 2 87 21
	testl	%ecx, %ecx
	je	.L101
.LBB11:
	.loc 2 87 21 is_stmt 0 discriminator 1
	leaq	.LC7(%rip), %rsi
	leaq	.LC2(%rip), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L101:
.LBE11:
	.loc 2 87 61 is_stmt 1 discriminator 2
	movzwl	360(%rbx), %ecx
	.loc 2 87 21 discriminator 2
	cmpw	$8224, %cx
	je	.L102
.LBB12:
	.loc 2 87 21 is_stmt 0 discriminator 3
	leaq	.LC7(%rip), %rax
	leaq	.LC2(%rip), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L102:
.LBE12:
	.loc 2 90 37 is_stmt 1
	movq	%rbx, %r10
	call	silver_report_projection__advance__keeping.3
	.loc 2 90 37 is_stmt 0 discriminator 1
	movb	%al, -18(%rbp)
	.loc 2 94 12 is_stmt 1
	cmpb	$0, -18(%rbp)
	je	.L103
	.loc 2 91 62
	movl	320(%rbx), %eax
	.loc 2 91 45
	testl	%eax, %eax
	jle	.L103
	.loc 2 92 31
	movl	320(%rbx), %eax
	.loc 2 92 22
	testl	%eax, %eax
	jle	.L104
	.loc 2 92 22 is_stmt 0 discriminator 1
	cmpl	$64, %eax
	jle	.L105
.L104:
	.loc 2 92 22 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$92, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L105:
	.loc 2 92 44 is_stmt 1 discriminator 3
	cltq
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	addq	%rbx, %rax
	addq	$2, %rax
	movzbl	(%rax), %eax
	cmpb	$3, %al
	sete	%al
	.loc 2 92 12 discriminator 3
	testb	%al, %al
	je	.L103
	.loc 2 93 31
	movl	320(%rbx), %eax
	.loc 2 93 22
	testl	%eax, %eax
	jle	.L106
	.loc 2 93 22 is_stmt 0 discriminator 1
	cmpl	$64, %eax
	jle	.L107
.L106:
	.loc 2 93 22 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$93, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L107:
	.loc 2 93 48 is_stmt 1 discriminator 3
	cltq
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	addq	%rbx, %rax
	addq	$1, %rax
	movzbl	(%rax), %eax
	cmpb	$3, %al
	sete	%al
	.loc 2 93 12 discriminator 3
	testb	%al, %al
	je	.L103
	.loc 2 94 31 discriminator 1
	movl	320(%rbx), %eax
	.loc 2 94 22 discriminator 1
	testl	%eax, %eax
	jle	.L108
	.loc 2 94 22 is_stmt 0 discriminator 2
	cmpl	$64, %eax
	jle	.L109
.L108:
	.loc 2 94 22 discriminator 3
	leaq	.LC4(%rip), %rax
	movl	$94, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L109:
	.loc 2 94 43 is_stmt 1 discriminator 4
	cltq
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	addq	%rbx, %rax
	addq	$3, %rax
	movzbl	(%rax), %eax
	cmpb	$3, %al
	sete	%al
	.loc 2 94 12 discriminator 4
	testb	%al, %al
	je	.L103
	.loc 2 94 12 is_stmt 0 discriminator 5
	movl	$1, %eax
	jmp	.L110
.L103:
	.loc 2 94 12 discriminator 6
	movl	$0, %eax
.L110:
	.loc 2 91 10 is_stmt 1 discriminator 1
	movb	%al, -19(%rbp)
	.loc 2 95 10
	movb	$0, -17(%rbp)
	.loc 2 98 10
	cmpb	$0, -19(%rbp)
	je	.L111
	.loc 2 99 13
	movq	%rbx, %r10
	movl	$123, %edi
	call	silver_report_projection__advance__emit.6
	.loc 2 100 13
	movq	%rbx, %r10
	movl	$125, %edi
	call	silver_report_projection__advance__emit.6
	jmp	.L112
.L111:
	.loc 2 101 10
	cmpb	$0, -18(%rbp)
	je	.L112
	.loc 2 102 13
	movzbl	368(%rbx), %eax
	movsbl	%al, %eax
	movq	%rbx, %r10
	movl	%eax, %edi
	call	silver_report_projection__advance__emit.6
.L112:
	.loc 2 104 20
	movb	$1, 354(%rbx)
	.loc 2 105 10
	movzbl	368(%rbx), %eax
	cmpb	$123, %al
	je	.L113
	.loc 2 105 27 discriminator 1
	movzbl	368(%rbx), %eax
	cmpb	$91, %al
	jne	.L114
.L113:
	.loc 2 106 24
	movl	320(%rbx), %eax
	.loc 2 106 13
	cmpl	$64, %eax
	jne	.L115
	.loc 2 107 25
	movb	$1, 356(%rbx)
	.loc 2 108 16
	jmp	.L100
.L115:
	.loc 2 110 24
	movl	320(%rbx), %eax
	.loc 2 110 13
	testl	%eax, %eax
	jne	.L117
	.loc 2 110 28 discriminator 1
	movzbl	368(%rbx), %eax
	cmpb	$123, %al
	jne	.L117
	.loc 2 111 25
	movb	$1, -17(%rbp)
	jmp	.L118
.L117:
	.loc 2 112 27
	movl	320(%rbx), %eax
	.loc 2 112 13
	testl	%eax, %eax
	jle	.L119
	.loc 2 112 50 discriminator 1
	movl	320(%rbx), %eax
	.loc 2 112 41 discriminator 1
	testl	%eax, %eax
	jle	.L120
	.loc 2 112 41 is_stmt 0 discriminator 2
	cmpl	$64, %eax
	jle	.L121
.L120:
	.loc 2 112 41 discriminator 3
	leaq	.LC4(%rip), %rax
	movl	$112, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L121:
	.loc 2 112 63 is_stmt 1 discriminator 4
	cltq
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	addq	%rbx, %rax
	addq	$2, %rax
	movzbl	(%rax), %eax
	cmpb	$1, %al
	sete	%al
	.loc 2 112 31 discriminator 4
	testb	%al, %al
	je	.L119
	.loc 2 113 34
	movl	320(%rbx), %eax
	.loc 2 113 25
	testl	%eax, %eax
	jle	.L122
	.loc 2 113 25 is_stmt 0 discriminator 1
	cmpl	$64, %eax
	jle	.L123
.L122:
	.loc 2 113 25 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$113, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L123:
	.loc 2 113 51 is_stmt 1 discriminator 3
	cltq
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	addq	%rbx, %rax
	addq	$1, %rax
	movzbl	(%rax), %eax
	cmpb	$3, %al
	sete	%al
	.loc 2 113 15 discriminator 3
	testb	%al, %al
	je	.L119
	.loc 2 114 34
	movl	320(%rbx), %eax
	.loc 2 114 25
	testl	%eax, %eax
	jle	.L124
	.loc 2 114 25 is_stmt 0 discriminator 1
	cmpl	$64, %eax
	jle	.L125
.L124:
	.loc 2 114 25 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$114, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L125:
	.loc 2 114 49 is_stmt 1 discriminator 3
	movslq	%eax, %rdx
	leaq	-1(%rdx), %rcx
	movq	%rcx, %rdx
	salq	$2, %rdx
	addq	%rcx, %rdx
	addq	%rbx, %rdx
	addq	$3, %rdx
	movzbl	(%rdx), %edx
	.loc 2 114 60 discriminator 3
	cmpb	$1, %dl
	je	.L126
	.loc 2 114 60 is_stmt 0 discriminator 4
	cltq
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	addq	%rbx, %rax
	addq	$3, %rax
	movzbl	(%rax), %eax
	cmpb	$2, %al
	jne	.L127
.L126:
	.loc 2 114 60 discriminator 5
	movl	$1, %eax
	jmp	.L128
.L127:
	.loc 2 114 60 discriminator 6
	movl	$0, %eax
.L128:
	.loc 2 114 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L119
	.loc 2 115 15
	movzbl	368(%rbx), %eax
	cmpb	$91, %al
	jne	.L119
	.loc 2 117 25
	movb	$2, -17(%rbp)
	jmp	.L118
.L119:
	.loc 2 118 27
	movl	320(%rbx), %eax
	.loc 2 118 13
	testl	%eax, %eax
	jle	.L118
	.loc 2 118 50 discriminator 1
	movl	320(%rbx), %eax
	.loc 2 118 41 discriminator 1
	testl	%eax, %eax
	jle	.L129
	.loc 2 118 41 is_stmt 0 discriminator 2
	cmpl	$64, %eax
	jle	.L130
.L129:
	.loc 2 118 41 discriminator 3
	leaq	.LC4(%rip), %rax
	movl	$118, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L130:
	.loc 2 118 63 is_stmt 1 discriminator 4
	cltq
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	addq	%rbx, %rax
	addq	$2, %rax
	movzbl	(%rax), %eax
	cmpb	$2, %al
	sete	%al
	.loc 2 118 31 discriminator 4
	testb	%al, %al
	je	.L118
	.loc 2 119 15
	movzbl	368(%rbx), %eax
	cmpb	$123, %al
	jne	.L118
	.loc 2 121 25
	movb	$3, -17(%rbp)
.L118:
	.loc 2 123 32
	movl	320(%rbx), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L131
	.loc 2 123 32 is_stmt 0 discriminator 1
	cmpl	$64, %eax
	jle	.L132
.L131:
	.loc 2 123 32 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$123, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L132:
	.loc 2 123 21 is_stmt 1 discriminator 3
	movl	%eax, 320(%rbx)
	.loc 2 124 23
	movl	320(%rbx), %eax
	.loc 2 124 14
	testl	%eax, %eax
	jle	.L133
	.loc 2 124 14 is_stmt 0 discriminator 1
	cmpl	$64, %eax
	jle	.L134
.L133:
	.loc 2 124 14 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$124, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L134:
	.loc 2 124 31 is_stmt 1 discriminator 3
	cltq
	movzbl	368(%rbx), %edx
	cmpb	$123, %dl
	setne	%dl
	movl	%edx, %r8d
	.loc 2 126 29
	movzbl	368(%rbx), %edx
	cmpb	$123, %dl
	jne	.L135
	.loc 2 126 29 is_stmt 0 discriminator 1
	movl	$0, %edi
	jmp	.L136
.L135:
	.loc 2 126 29 discriminator 2
	movl	$5, %edi
.L136:
	.loc 2 127 65 is_stmt 1
	cmpb	$0, -18(%rbp)
	je	.L137
	.loc 2 127 74 discriminator 1
	movzbl	-19(%rbp), %edx
	xorl	$1, %edx
	.loc 2 127 65 discriminator 1
	testb	%dl, %dl
	je	.L137
	.loc 2 127 65 is_stmt 0 discriminator 2
	movl	$1, %esi
	jmp	.L138
.L137:
	.loc 2 127 65 discriminator 3
	movl	$0, %esi
.L138:
	.loc 2 124 31 is_stmt 1 discriminator 4
	leaq	-1(%rax), %rcx
	movq	%rcx, %rdx
	salq	$2, %rdx
	addq	%rcx, %rdx
	addq	%rbx, %rdx
	movb	%r8b, (%rdx)
	leaq	-1(%rax), %rcx
	movq	%rcx, %rdx
	salq	$2, %rdx
	addq	%rcx, %rdx
	addq	%rbx, %rdx
	addq	$1, %rdx
	movb	%dil, (%rdx)
	leaq	-1(%rax), %rcx
	movq	%rcx, %rdx
	salq	$2, %rdx
	addq	%rcx, %rdx
	addq	%rbx, %rdx
	leaq	2(%rdx), %rcx
	movzbl	-17(%rbp), %edx
	movb	%dl, (%rcx)
	leaq	-1(%rax), %rcx
	movq	%rcx, %rdx
	salq	$2, %rdx
	addq	%rcx, %rdx
	addq	%rbx, %rdx
	addq	$3, %rdx
	movb	$0, (%rdx)
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	addq	%rbx, %rax
	addq	$4, %rax
	movb	%sil, (%rax)
	jmp	.L139
.L114:
	.loc 2 128 10
	movzbl	368(%rbx), %eax
	cmpb	$34, %al
	jne	.L140
	.loc 2 129 13
	cmpb	$0, -18(%rbp)
	je	.L141
	.loc 2 129 48 discriminator 1
	movzbl	-19(%rbp), %eax
	xorl	$1, %eax
	.loc 2 129 13 discriminator 1
	testb	%al, %al
	je	.L141
	.loc 2 129 13 is_stmt 0 discriminator 2
	movl	$1, %eax
	jmp	.L142
.L141:
	.loc 2 129 13 discriminator 3
	movl	$0, %eax
.L142:
	.loc 2 129 13 discriminator 4
	movzbl	%al, %eax
	movq	%rbx, %r10
	movl	%eax, %esi
	movl	$0, %edi
	call	silver_report_projection__advance__start_string.1
	.loc 2 144 11 is_stmt 1
	jmp	.L157
.L140:
	.loc 2 130 10
	movzbl	368(%rbx), %eax
	cmpb	$45, %al
	je	.L143
	.loc 2 130 40 discriminator 1
	movzbl	368(%rbx), %eax
	.loc 2 130 27 discriminator 1
	cmpb	$47, %al
	jbe	.L144
	.loc 2 130 40 discriminator 2
	movzbl	368(%rbx), %eax
	cmpb	$57, %al
	ja	.L144
.L143:
	.loc 2 131 20
	movb	$4, 324(%rbx)
	.loc 2 132 34
	cmpb	$0, -18(%rbp)
	je	.L145
	.loc 2 132 43 discriminator 1
	movzbl	-19(%rbp), %eax
	xorl	$1, %eax
	.loc 2 132 34 discriminator 1
	testb	%al, %al
	je	.L145
	.loc 2 132 34 is_stmt 0 discriminator 2
	movl	$1, %eax
	jmp	.L146
.L145:
	.loc 2 132 34 discriminator 3
	movl	$0, %eax
.L146:
	.loc 2 132 26 is_stmt 1 discriminator 4
	movb	%al, 353(%rbx)
	.loc 2 133 26
	movzbl	368(%rbx), %eax
	cmpb	$45, %al
	je	.L147
	.loc 2 134 26
	movzbl	368(%rbx), %eax
	cmpb	$48, %al
	jne	.L148
	.loc 2 133 26 discriminator 1
	movl	$1, %eax
	jmp	.L149
.L148:
	.loc 2 133 26 is_stmt 0 discriminator 2
	movl	$2, %eax
	jmp	.L149
.L147:
	.loc 2 133 26 discriminator 3
	movl	$0, %eax
.L149:
	.loc 2 133 22 is_stmt 1 discriminator 4
	movb	%al, 325(%rbx)
	jmp	.L139
.L144:
	.loc 2 135 10
	movzbl	368(%rbx), %eax
	cmpb	$116, %al
	je	.L150
	.loc 2 135 30 discriminator 1
	movzbl	368(%rbx), %eax
	cmpb	$102, %al
	je	.L150
	.loc 2 135 36 discriminator 2
	movzbl	368(%rbx), %eax
	cmpb	$110, %al
	jne	.L151
.L150:
	.loc 2 136 20
	movb	$5, 324(%rbx)
	.loc 2 137 34
	cmpb	$0, -18(%rbp)
	je	.L152
	.loc 2 137 43 discriminator 1
	movzbl	-19(%rbp), %eax
	xorl	$1, %eax
	.loc 2 137 34 discriminator 1
	testb	%al, %al
	je	.L152
	.loc 2 137 34 is_stmt 0 discriminator 2
	movl	$1, %eax
	jmp	.L153
.L152:
	.loc 2 137 34 discriminator 3
	movl	$0, %eax
.L153:
	.loc 2 137 26 is_stmt 1 discriminator 4
	movb	%al, 353(%rbx)
	.loc 2 138 27
	movzbl	368(%rbx), %eax
	cmpb	$116, %al
	je	.L154
	.loc 2 139 27
	movzbl	368(%rbx), %eax
	cmpb	$102, %al
	jne	.L155
	.loc 2 138 27 discriminator 1
	movl	$1, %eax
	jmp	.L156
.L155:
	.loc 2 138 27 is_stmt 0 discriminator 2
	movl	$2, %eax
	jmp	.L156
.L154:
	.loc 2 138 27 discriminator 3
	movl	$0, %eax
.L156:
	.loc 2 138 23 is_stmt 1 discriminator 4
	movb	%al, 326(%rbx)
	.loc 2 140 32
	movl	$2, 328(%rbx)
	jmp	.L139
.L151:
	.loc 2 142 22
	movb	$1, 356(%rbx)
	.loc 2 144 11
	jmp	.L157
.L139:
.L157:
	nop
.L100:
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE8:
	.size	silver_report_projection__advance__start_value.2, .-silver_report_projection__advance__start_value.2
	.section	.rodata
	.align 8
.LC8:
	.ascii	"failed precondition from silver_report_projection.adb:147"
	.align 8
.LC1:
	.long	1
	.long	57
	.text
	.align 2
	.type	silver_report_projection__advance__between.0, @function
silver_report_projection__advance__between.0:
.LFB9:
	.loc 2 146 7
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%r10, %rbx
	movq	%r10, -24(%rbp)
	.loc 2 147 35
	movl	364(%rbx), %ecx
	.loc 2 147 21
	testl	%ecx, %ecx
	je	.L159
.LBB13:
	.loc 2 147 21 is_stmt 0 discriminator 1
	leaq	.LC8(%rip), %rsi
	leaq	.LC1(%rip), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L159:
.LBE13:
	.loc 2 147 61 is_stmt 1 discriminator 2
	movzwl	360(%rbx), %ecx
	.loc 2 147 21 discriminator 2
	cmpw	$8224, %cx
	je	.L160
.LBB14:
	.loc 2 147 21 is_stmt 0 discriminator 3
	leaq	.LC8(%rip), %rax
	leaq	.LC1(%rip), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L160:
.LBE14:
	.loc 2 151 13 is_stmt 1
	movzbl	368(%rbx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_report_projection__space
	.loc 2 151 10 discriminator 1
	testb	%al, %al
	je	.L161
	.loc 2 152 16
	movq	%rbx, %r10
	call	silver_report_projection__advance__keeping.3
	.loc 2 152 13 discriminator 1
	testb	%al, %al
	je	.L213
	.loc 2 152 29 discriminator 2
	movzbl	368(%rbx), %eax
	movsbl	%al, %eax
	movq	%rbx, %r10
	movl	%eax, %edi
	call	silver_report_projection__advance__emit.6
	.loc 2 194 11
	jmp	.L213
.L161:
	.loc 2 153 10
	movzbl	355(%rbx), %eax
	testb	%al, %al
	je	.L163
	.loc 2 154 22
	movb	$1, 356(%rbx)
	.loc 2 194 11
	jmp	.L213
.L163:
	.loc 2 155 24
	movl	320(%rbx), %eax
	.loc 2 155 10
	testl	%eax, %eax
	jne	.L164
	.loc 2 156 13
	movzbl	354(%rbx), %eax
	testb	%al, %al
	je	.L165
	.loc 2 156 40 discriminator 1
	movb	$1, 356(%rbx)
	.loc 2 194 11
	jmp	.L213
.L165:
	.loc 2 156 54 discriminator 2
	movq	%rbx, %r10
	call	silver_report_projection__advance__start_value.2
	.loc 2 194 11
	jmp	.L213
.L164:
	.loc 2 157 10
	movzbl	368(%rbx), %eax
	cmpb	$125, %al
	je	.L166
	.loc 2 157 30 discriminator 1
	movzbl	368(%rbx), %eax
	cmpb	$93, %al
	jne	.L167
.L166:
	.loc 2 158 13
	movzbl	368(%rbx), %eax
	cmpb	$125, %al
	jne	.L168
	.loc 2 158 47 discriminator 1
	movl	320(%rbx), %eax
	.loc 2 158 38 discriminator 1
	testl	%eax, %eax
	jle	.L169
	.loc 2 158 38 is_stmt 0 discriminator 2
	cmpl	$64, %eax
	jle	.L170
.L169:
	.loc 2 158 38 discriminator 3
	leaq	.LC4(%rip), %rax
	movl	$158, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L170:
	.loc 2 158 65 is_stmt 1 discriminator 4
	cltq
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	addq	%rbx, %rax
	movzbl	(%rax), %eax
	testb	%al, %al
	sete	%al
	.loc 2 158 28 discriminator 4
	testb	%al, %al
	je	.L168
	.loc 2 159 38
	movl	320(%rbx), %eax
	.loc 2 159 29
	testl	%eax, %eax
	jle	.L171
	.loc 2 159 29 is_stmt 0 discriminator 1
	cmpl	$64, %eax
	jle	.L172
.L171:
	.loc 2 159 29 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$159, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L172:
	.loc 2 159 58 is_stmt 1 discriminator 3
	movslq	%eax, %rdx
	leaq	-1(%rdx), %rcx
	movq	%rcx, %rdx
	salq	$2, %rdx
	addq	%rcx, %rdx
	addq	%rbx, %rdx
	addq	$1, %rdx
	movzbl	(%rdx), %edx
	.loc 2 159 70 discriminator 3
	testb	%dl, %dl
	je	.L173
	.loc 2 159 70 is_stmt 0 discriminator 4
	cltq
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	addq	%rbx, %rax
	addq	$1, %rax
	movzbl	(%rax), %eax
	cmpb	$4, %al
	jne	.L174
.L173:
	.loc 2 159 70 discriminator 5
	movl	$1, %eax
	jmp	.L175
.L174:
	.loc 2 159 70 discriminator 6
	movl	$0, %eax
.L175:
	.loc 2 159 19 is_stmt 1 discriminator 7
	testb	%al, %al
	jne	.L176
.L168:
	.loc 2 160 15
	movzbl	368(%rbx), %eax
	cmpb	$93, %al
	jne	.L177
	.loc 2 160 54 discriminator 1
	movl	320(%rbx), %eax
	.loc 2 160 45 discriminator 1
	testl	%eax, %eax
	jle	.L178
	.loc 2 160 45 is_stmt 0 discriminator 2
	cmpl	$64, %eax
	jle	.L179
.L178:
	.loc 2 160 45 discriminator 3
	leaq	.LC4(%rip), %rax
	movl	$160, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L179:
	.loc 2 160 72 is_stmt 1 discriminator 4
	cltq
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	addq	%rbx, %rax
	movzbl	(%rax), %eax
	cmpb	$1, %al
	sete	%al
	.loc 2 160 35 discriminator 4
	testb	%al, %al
	je	.L177
	.loc 2 161 38
	movl	320(%rbx), %eax
	.loc 2 161 29
	testl	%eax, %eax
	jle	.L180
	.loc 2 161 29 is_stmt 0 discriminator 1
	cmpl	$64, %eax
	jle	.L181
.L180:
	.loc 2 161 29 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$161, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L181:
	.loc 2 161 58 is_stmt 1 discriminator 3
	movslq	%eax, %rdx
	leaq	-1(%rdx), %rcx
	movq	%rcx, %rdx
	salq	$2, %rdx
	addq	%rcx, %rdx
	addq	%rbx, %rdx
	addq	$1, %rdx
	movzbl	(%rdx), %edx
	.loc 2 161 71 discriminator 3
	cmpb	$5, %dl
	je	.L182
	.loc 2 161 71 is_stmt 0 discriminator 4
	cltq
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	addq	%rbx, %rax
	addq	$1, %rax
	movzbl	(%rax), %eax
	cmpb	$7, %al
	jne	.L183
.L182:
	.loc 2 161 71 discriminator 5
	movl	$1, %eax
	jmp	.L184
.L183:
	.loc 2 161 71 discriminator 6
	movl	$0, %eax
.L184:
	.loc 2 161 19 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L177
.L176:
	.loc 2 163 19
	movq	%rbx, %r10
	call	silver_report_projection__advance__keeping.3
	.loc 2 163 16 discriminator 1
	testb	%al, %al
	je	.L185
	.loc 2 163 32 discriminator 2
	movzbl	368(%rbx), %eax
	movsbl	%al, %eax
	movq	%rbx, %r10
	movl	%eax, %edi
	call	silver_report_projection__advance__emit.6
.L185:
	.loc 2 164 35
	movl	320(%rbx), %eax
	subl	$1, %eax
	testl	%eax, %eax
	js	.L186
	.loc 2 164 35 is_stmt 0 discriminator 1
	cmpl	$64, %eax
	jle	.L187
.L186:
	.loc 2 164 35 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$164, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L187:
	.loc 2 164 24 is_stmt 1 discriminator 3
	movl	%eax, 320(%rbx)
	.loc 2 165 16
	movq	%rbx, %r10
	call	silver_report_projection__advance__end_value.7
	.loc 2 158 13 discriminator 5
	jmp	.L162
.L177:
	.loc 2 167 25
	movb	$1, 356(%rbx)
	.loc 2 158 13 discriminator 5
	jmp	.L162
.L167:
	.loc 2 170 28
	movl	320(%rbx), %eax
	.loc 2 170 19
	testl	%eax, %eax
	jle	.L189
	.loc 2 170 19 is_stmt 0 discriminator 1
	cmpl	$64, %eax
	jle	.L190
.L189:
	.loc 2 170 19 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$170, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L190:
	.loc 2 170 35 is_stmt 1 discriminator 3
	cltq
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	addq	%rbx, %rax
	addq	$1, %rax
	movzbl	(%rax), %eax
	cmpb	$7, %al
	jbe	.L191
	.loc 2 170 35 is_stmt 0 discriminator 4
	leaq	.LC4(%rip), %rax
	movl	$170, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L191:
	.loc 2 170 13 is_stmt 1 discriminator 5
	cmpb	$6, %al
	ja	.L192
	cmpb	$5, %al
	jnb	.L193
	cmpb	$3, %al
	je	.L193
	cmpb	$3, %al
	ja	.L192
	cmpb	$1, %al
	jbe	.L194
	cmpb	$2, %al
	je	.L195
	jmp	.L192
.L194:
	.loc 2 172 19
	movzbl	368(%rbx), %eax
	cmpb	$34, %al
	jne	.L196
	.loc 2 173 25
	movq	%rbx, %r10
	call	silver_report_projection__advance__keeping.3
	.loc 2 173 22 discriminator 1
	testb	%al, %al
	je	.L197
	.loc 2 173 38 discriminator 2
	movzbl	368(%rbx), %eax
	movsbl	%al, %eax
	movq	%rbx, %r10
	movl	%eax, %edi
	call	silver_report_projection__advance__emit.6
.L197:
	.loc 2 174 22
	movq	%rbx, %r10
	call	silver_report_projection__advance__keeping.3
	.loc 2 174 22 is_stmt 0 discriminator 1
	movzbl	%al, %eax
	movq	%rbx, %r10
	movl	%eax, %esi
	movl	$1, %edi
	call	silver_report_projection__advance__start_string.1
	.loc 2 192 17 is_stmt 1
	jmp	.L162
.L196:
	.loc 2 175 33
	movb	$1, 356(%rbx)
	.loc 2 192 17
	jmp	.L162
.L195:
.LBB15:
	.loc 2 178 19
	movzbl	368(%rbx), %eax
	cmpb	$58, %al
	jne	.L199
	.loc 2 179 25
	movq	%rbx, %r10
	call	silver_report_projection__advance__keeping.3
	.loc 2 179 22 discriminator 1
	testb	%al, %al
	je	.L200
	.loc 2 179 38 discriminator 2
	movzbl	368(%rbx), %eax
	movsbl	%al, %eax
	movq	%rbx, %r10
	movl	%eax, %edi
	call	silver_report_projection__advance__emit.6
.L200:
	.loc 2 180 32
	movl	320(%rbx), %eax
	.loc 2 180 23
	testl	%eax, %eax
	jle	.L201
	.loc 2 180 23 is_stmt 0 discriminator 1
	cmpl	$64, %eax
	jle	.L202
.L201:
	.loc 2 180 23 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$180, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L202:
	.loc 2 180 49 is_stmt 1 discriminator 3
	cltq
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	addq	%rbx, %rax
	addq	$1, %rax
	movb	$3, (%rax)
.LBE15:
	.loc 2 192 17 discriminator 1
	jmp	.L162
.L199:
.LBB16:
	.loc 2 181 33
	movb	$1, 356(%rbx)
.LBE16:
	.loc 2 192 17 discriminator 1
	jmp	.L162
.L193:
	.loc 2 183 62
	movq	%rbx, %r10
	call	silver_report_projection__advance__start_value.2
	.loc 2 192 17 discriminator 2
	jmp	.L162
.L192:
.LBB17:
	.loc 2 185 19
	movzbl	368(%rbx), %eax
	cmpb	$44, %al
	jne	.L204
	.loc 2 186 25
	movq	%rbx, %r10
	call	silver_report_projection__advance__keeping.3
	.loc 2 186 22 discriminator 1
	testb	%al, %al
	je	.L205
	.loc 2 186 38 discriminator 2
	movzbl	368(%rbx), %eax
	movsbl	%al, %eax
	movq	%rbx, %r10
	movl	%eax, %edi
	call	silver_report_projection__advance__emit.6
.L205:
	.loc 2 187 32
	movl	320(%rbx), %eax
	.loc 2 187 23
	testl	%eax, %eax
	jle	.L206
	.loc 2 187 23 is_stmt 0 discriminator 1
	cmpl	$64, %eax
	jle	.L207
.L206:
	.loc 2 187 23 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$187, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L207:
	.loc 2 188 38 is_stmt 1
	movl	320(%rbx), %edx
	.loc 2 188 29
	testl	%edx, %edx
	jle	.L208
	.loc 2 188 29 is_stmt 0 discriminator 1
	cmpl	$64, %edx
	jle	.L209
.L208:
	.loc 2 188 29 discriminator 2
	leaq	.LC4(%rip), %rax
	movl	$188, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L209:
	.loc 2 188 56 is_stmt 1 discriminator 3
	movslq	%edx, %rdx
	leaq	-1(%rdx), %rcx
	movq	%rcx, %rdx
	salq	$2, %rdx
	addq	%rcx, %rdx
	addq	%rbx, %rdx
	movzbl	(%rdx), %edx
	.loc 2 188 25 discriminator 3
	testb	%dl, %dl
	jne	.L210
	.loc 2 188 25 is_stmt 0 discriminator 4
	movl	$1, %ecx
	jmp	.L211
.L210:
	.loc 2 188 25 discriminator 5
	movl	$6, %ecx
.L211:
	.loc 2 187 49 is_stmt 1 discriminator 3
	cltq
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	addq	%rbx, %rax
	addq	$1, %rax
	movb	%cl, (%rax)
.LBE17:
	.loc 2 192 17 discriminator 3
	jmp	.L214
.L204:
.LBB18:
	.loc 2 190 33
	movb	$1, 356(%rbx)
.L214:
.LBE18:
	.loc 2 192 17 discriminator 3
	nop
.L162:
.L213:
	.loc 2 194 11 discriminator 1
	nop
	.loc 2 194 11 is_stmt 0
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE9:
	.size	silver_report_projection__advance__between.0, .-silver_report_projection__advance__between.0
	.section	.rodata
	.align 8
.LC9:
	.ascii	"failed precondition from silver_report_projection.adb:197"
	.text
	.align 2
	.type	silver_report_projection__advance__number_byte.4, @function
silver_report_projection__advance__number_byte.4:
.LFB10:
	.loc 2 196 7 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 3, -24
	movq	%r10, %rbx
	movq	%r10, -40(%rbp)
	.loc 2 197 35
	movl	364(%rbx), %ecx
	.loc 2 197 21
	testl	%ecx, %ecx
	je	.L216
.LBB19:
	.loc 2 197 21 is_stmt 0 discriminator 1
	leaq	.LC9(%rip), %rsi
	leaq	.LC1(%rip), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L216:
.LBE19:
	.loc 2 197 61 is_stmt 1 discriminator 2
	movzwl	360(%rbx), %ecx
	.loc 2 197 21 discriminator 2
	cmpw	$8224, %cx
	je	.L217
.LBB20:
	.loc 2 197 21 is_stmt 0 discriminator 3
	leaq	.LC9(%rip), %rax
	leaq	.LC1(%rip), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L217:
.LBE20:
	.loc 2 200 10 is_stmt 1
	movb	$0, -17(%rbp)
	.loc 2 202 16
	movzbl	325(%rbx), %eax
	cmpb	$7, %al
	jbe	.L218
	.loc 2 202 16 is_stmt 0 discriminator 1
	leaq	.LC4(%rip), %rax
	movl	$202, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L218:
	.loc 2 202 10 is_stmt 1 discriminator 2
	cmpb	$6, %al
	je	.L219
	cmpb	$6, %al
	ja	.L220
	cmpb	$5, %al
	je	.L221
	cmpb	$5, %al
	ja	.L220
	cmpb	$4, %al
	je	.L222
	cmpb	$4, %al
	ja	.L220
	cmpb	$3, %al
	je	.L223
	cmpb	$3, %al
	ja	.L220
	testb	%al, %al
	je	.L224
	subl	$1, %eax
	cmpb	$1, %al
	ja	.L220
	jmp	.L254
.L224:
	.loc 2 204 16
	movzbl	368(%rbx), %eax
	cmpb	$48, %al
	jne	.L226
	.loc 2 204 44 discriminator 1
	movb	$1, 325(%rbx)
	.loc 2 234 14
	jmp	.L229
.L226:
	.loc 2 205 27
	movzbl	368(%rbx), %eax
	.loc 2 205 16
	cmpb	$48, %al
	jbe	.L228
	.loc 2 205 27 discriminator 1
	movzbl	368(%rbx), %eax
	cmpb	$57, %al
	ja	.L228
	.loc 2 205 55 discriminator 2
	movb	$2, 325(%rbx)
	.loc 2 234 14
	jmp	.L229
.L228:
	.loc 2 206 30
	movb	$1, 356(%rbx)
	.loc 2 234 14
	jmp	.L229
.L254:
.LBB21:
	.loc 2 209 24
	movzbl	368(%rbx), %eax
	.loc 2 209 16
	cmpb	$47, %al
	jbe	.L230
	.loc 2 209 24 discriminator 1
	movzbl	368(%rbx), %eax
	cmpb	$57, %al
	ja	.L230
	.loc 2 209 56 discriminator 2
	movzbl	325(%rbx), %eax
	.loc 2 209 38 discriminator 2
	cmpb	$2, %al
	jne	.L230
	.loc 2 209 78 discriminator 4
	jmp	.L232
.L230:
	.loc 2 210 16
	movzbl	368(%rbx), %eax
	cmpb	$46, %al
	jne	.L233
	.loc 2 210 47 discriminator 1
	movb	$3, 325(%rbx)
.LBE21:
	.loc 2 234 14 discriminator 1
	jmp	.L229
.L233:
.LBB22:
	.loc 2 211 16
	movzbl	368(%rbx), %eax
	cmpb	$101, %al
	je	.L234
	.loc 2 211 36 discriminator 1
	movzbl	368(%rbx), %eax
	cmpb	$69, %al
	jne	.L235
.L234:
	.loc 2 211 54 discriminator 2
	movb	$5, 325(%rbx)
	jmp	.L232
.L235:
	.loc 2 212 30
	movb	$1, -17(%rbp)
.LBE22:
	.loc 2 234 14 discriminator 1
	jmp	.L229
.L232:
	jmp	.L229
.L223:
	.loc 2 215 24
	movzbl	368(%rbx), %eax
	.loc 2 215 16
	cmpb	$47, %al
	jbe	.L236
	.loc 2 215 24 discriminator 1
	movzbl	368(%rbx), %eax
	cmpb	$57, %al
	ja	.L236
	.loc 2 215 52 discriminator 2
	movb	$4, 325(%rbx)
	.loc 2 234 14 discriminator 2
	jmp	.L229
.L236:
	.loc 2 216 30
	movb	$1, 356(%rbx)
	.loc 2 234 14 discriminator 2
	jmp	.L229
.L222:
.LBB23:
	.loc 2 219 24
	movzbl	368(%rbx), %eax
	.loc 2 219 16
	cmpb	$47, %al
	jbe	.L238
	.loc 2 219 24 discriminator 1
	movzbl	368(%rbx), %eax
	cmpb	$57, %al
	ja	.L238
	.loc 2 219 43 discriminator 3
	jmp	.L240
.L238:
	.loc 2 220 16
	movzbl	368(%rbx), %eax
	cmpb	$101, %al
	je	.L241
	.loc 2 220 36 discriminator 1
	movzbl	368(%rbx), %eax
	cmpb	$69, %al
	jne	.L242
.L241:
	.loc 2 220 54 discriminator 2
	movb	$5, 325(%rbx)
	jmp	.L240
.L242:
	.loc 2 221 30
	movb	$1, -17(%rbp)
.LBE23:
	.loc 2 234 14 discriminator 3
	jmp	.L229
.L240:
	jmp	.L229
.L221:
	.loc 2 224 16
	movzbl	368(%rbx), %eax
	cmpb	$43, %al
	je	.L243
	.loc 2 224 33 discriminator 1
	movzbl	368(%rbx), %eax
	cmpb	$45, %al
	jne	.L244
.L243:
	.loc 2 224 51 discriminator 2
	movb	$6, 325(%rbx)
	jmp	.L245
.L244:
	.loc 2 225 27
	movzbl	368(%rbx), %eax
	.loc 2 225 16
	cmpb	$47, %al
	jbe	.L246
	.loc 2 225 27 discriminator 1
	movzbl	368(%rbx), %eax
	cmpb	$57, %al
	ja	.L246
	.loc 2 225 55 discriminator 2
	movb	$7, 325(%rbx)
	jmp	.L245
.L246:
	.loc 2 226 30
	movb	$1, 356(%rbx)
	.loc 2 234 14 discriminator 4
	jmp	.L229
.L245:
	jmp	.L229
.L219:
	.loc 2 229 24
	movzbl	368(%rbx), %eax
	.loc 2 229 16
	cmpb	$47, %al
	jbe	.L247
	.loc 2 229 24 discriminator 1
	movzbl	368(%rbx), %eax
	cmpb	$57, %al
	ja	.L247
	.loc 2 229 52 discriminator 2
	movb	$7, 325(%rbx)
	.loc 2 234 14 discriminator 5
	jmp	.L229
.L247:
	.loc 2 230 30
	movb	$1, 356(%rbx)
	.loc 2 234 14 discriminator 5
	jmp	.L229
.L220:
	.loc 2 233 24
	movzbl	368(%rbx), %eax
	.loc 2 233 16
	cmpb	$47, %al
	jbe	.L249
	.loc 2 233 24 discriminator 1
	movzbl	368(%rbx), %eax
	cmpb	$57, %al
	jbe	.L255
.L249:
	.loc 2 233 56 discriminator 2
	movb	$1, -17(%rbp)
.L255:
	.loc 2 234 14 discriminator 6
	nop
.L229:
	.loc 2 235 10
	cmpb	$0, -17(%rbp)
	je	.L251
	.loc 2 236 20
	movb	$0, 324(%rbx)
	.loc 2 237 13
	movq	%rbx, %r10
	call	silver_report_projection__advance__end_value.7
	.loc 2 238 13
	movq	%rbx, %r10
	call	silver_report_projection__advance__between.0
	.loc 2 242 11
	jmp	.L253
.L251:
	.loc 2 239 10
	movzbl	353(%rbx), %eax
	testb	%al, %al
	je	.L253
	.loc 2 240 13
	movzbl	368(%rbx), %eax
	movsbl	%al, %eax
	movq	%rbx, %r10
	movl	%eax, %edi
	call	silver_report_projection__advance__emit.6
.L253:
	.loc 2 242 11 discriminator 1
	nop
	.loc 2 242 11 is_stmt 0
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE10:
	.size	silver_report_projection__advance__number_byte.4, .-silver_report_projection__advance__number_byte.4
	.align 2
	.type	silver_report_projection__advance__keeping.3, @function
silver_report_projection__advance__keeping.3:
.LFB11:
	.loc 2 15 7 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rdx
	movq	%r10, -8(%rbp)
	.loc 2 16 18
	movl	320(%rdx), %eax
	.loc 2 16 22
	testl	%eax, %eax
	je	.L257
	.loc 2 16 40 discriminator 1
	movl	320(%rdx), %eax
	.loc 2 16 31 discriminator 1
	testl	%eax, %eax
	jle	.L258
	.loc 2 16 31 is_stmt 0 discriminator 2
	cmpl	$64, %eax
	jle	.L259
.L258:
	.loc 2 16 31 discriminator 3
	leaq	.LC4(%rip), %rax
	movl	$16, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L259:
	.loc 2 16 47 is_stmt 1 discriminator 4
	cltq
	leaq	-1(%rax), %rcx
	movq	%rcx, %rax
	salq	$2, %rax
	addq	%rcx, %rax
	addq	%rdx, %rax
	addq	$4, %rax
	movzbl	(%rax), %eax
	.loc 2 16 22 discriminator 4
	testb	%al, %al
	je	.L260
.L257:
	.loc 2 16 22 is_stmt 0 discriminator 5
	movl	$1, %eax
	jmp	.L261
.L260:
	.loc 2 16 22 discriminator 6
	movl	$0, %eax
.L261:
	.loc 2 15 7 is_stmt 1
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE11:
	.size	silver_report_projection__advance__keeping.3, .-silver_report_projection__advance__keeping.3
	.align 2
	.type	silver_report_projection__space, @function
silver_report_projection__space:
.LFB12:
	.loc 2 6 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movb	%dil, -1(%rbp)
	.loc 2 7 68
	cmpb	$32, -1(%rbp)
	je	.L264
	.loc 2 7 27 discriminator 1
	cmpb	$9, -1(%rbp)
	je	.L264
	.loc 2 7 47 discriminator 2
	cmpb	$10, -1(%rbp)
	je	.L264
	.loc 2 7 68 discriminator 3
	cmpb	$13, -1(%rbp)
	jne	.L265
.L264:
	.loc 2 7 68 is_stmt 0 discriminator 4
	movl	$1, %eax
	jmp	.L266
.L265:
	.loc 2 7 68 discriminator 5
	movl	$0, %eax
.L266:
	.loc 2 6 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE12:
	.size	silver_report_projection__space, .-silver_report_projection__space
	.align 2
	.type	silver_report_projection__hex, @function
silver_report_projection__hex:
.LFB13:
	.loc 2 8 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movb	%dil, -1(%rbp)
	.loc 2 9 16
	movzbl	-1(%rbp), %eax
	.loc 2 9 42
	cmpb	$47, %al
	jbe	.L269
	.loc 2 9 16 discriminator 1
	movzbl	-1(%rbp), %eax
	cmpb	$57, %al
	jbe	.L270
.L269:
	.loc 2 9 29 discriminator 2
	movzbl	-1(%rbp), %eax
	cmpb	$64, %al
	jbe	.L271
	.loc 2 9 29 is_stmt 0 discriminator 3
	movzbl	-1(%rbp), %eax
	cmpb	$70, %al
	jbe	.L270
.L271:
	.loc 2 9 42 is_stmt 1 discriminator 4
	movzbl	-1(%rbp), %eax
	cmpb	$96, %al
	jbe	.L272
	.loc 2 9 42 is_stmt 0 discriminator 5
	movzbl	-1(%rbp), %eax
	cmpb	$102, %al
	ja	.L272
.L270:
	.loc 2 9 42 discriminator 6
	movl	$1, %eax
	jmp	.L273
.L272:
	.loc 2 9 42 discriminator 7
	movl	$0, %eax
.L273:
	.loc 2 8 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE13:
	.size	silver_report_projection__hex, .-silver_report_projection__hex
	.align 2
	.globl	silver_report_projection___elabs
	.type	silver_report_projection___elabs, @function
silver_report_projection___elabs:
.LFB1:
	.loc 1 6 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	.loc 1 11 4
	leaq	silver_report_projection__initial_state(%rip), %rax
	leaq	silver_report_projection_types__initial_state(%rip), %rcx
	movl	$360, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 1 27 5
	nop
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1:
	.size	silver_report_projection___elabs, .-silver_report_projection___elabs
	.globl	silver_report_projection_E
	.data
	.align 2
	.type	silver_report_projection_E, @object
	.size	silver_report_projection_E, 2
silver_report_projection_E:
	.zero	2
	.globl	silver_report_projection__initial_state
	.bss
	.align 32
	.type	silver_report_projection__initial_state, @object
	.size	silver_report_projection__initial_state, 360
silver_report_projection__initial_state:
	.zero	360
	.section	.rodata
	.align 8
	.type	C106b___UNC.10, @object
	.size	C106b___UNC.10, 12
C106b___UNC.10:
	.long	1
	.long	4
	.ascii	"true"
	.align 16
	.type	C107b___UNC.9, @object
	.size	C107b___UNC.9, 16
C107b___UNC.9:
	.long	1
	.long	5
	.ascii	"false"
	.zero	3
	.align 8
	.type	C108b___UNC.8, @object
	.size	C108b___UNC.8, 12
C108b___UNC.8:
	.long	1
	.long	4
	.ascii	"null"
	.text
.Letext0:
	.file 3 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_report_projection_types.ads"
	.file 4 "<built-in>"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x64f
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x15
	.long	.LASF98
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.quad	.Ltext0
	.quad	.Letext0-.Ltext0
	.long	.Ldebug_line0
	.uleb128 0x3
	.long	.LASF4
	.byte	0x5
	.long	0x45
	.uleb128 0x1
	.long	.LASF2
	.byte	0
	.uleb128 0x1
	.long	.LASF3
	.byte	0x1
	.byte	0
	.uleb128 0x3
	.long	.LASF5
	.byte	0x6
	.long	0x80
	.uleb128 0x1
	.long	.LASF6
	.byte	0
	.uleb128 0x1
	.long	.LASF7
	.byte	0x1
	.uleb128 0x1
	.long	.LASF8
	.byte	0x2
	.uleb128 0x1
	.long	.LASF9
	.byte	0x3
	.uleb128 0x1
	.long	.LASF10
	.byte	0x4
	.uleb128 0x1
	.long	.LASF11
	.byte	0x5
	.uleb128 0x1
	.long	.LASF12
	.byte	0x6
	.uleb128 0x1
	.long	.LASF13
	.byte	0x7
	.byte	0
	.uleb128 0x3
	.long	.LASF14
	.byte	0x9
	.long	0xa3
	.uleb128 0x1
	.long	.LASF15
	.byte	0
	.uleb128 0x1
	.long	.LASF16
	.byte	0x1
	.uleb128 0x1
	.long	.LASF17
	.byte	0x2
	.uleb128 0x1
	.long	.LASF18
	.byte	0x3
	.byte	0
	.uleb128 0x3
	.long	.LASF19
	.byte	0xa
	.long	0xc6
	.uleb128 0x1
	.long	.LASF20
	.byte	0
	.uleb128 0x1
	.long	.LASF21
	.byte	0x1
	.uleb128 0x1
	.long	.LASF22
	.byte	0x2
	.uleb128 0x1
	.long	.LASF23
	.byte	0x3
	.byte	0
	.uleb128 0x16
	.long	.LASF50
	.byte	0x5
	.byte	0x3
	.byte	0xb
	.byte	0x9
	.long	0x10d
	.uleb128 0x4
	.long	.LASF24
	.byte	0xc
	.long	0x2e
	.byte	0
	.uleb128 0x4
	.long	.LASF25
	.byte	0xd
	.long	0x45
	.byte	0x1
	.uleb128 0x4
	.long	.LASF26
	.byte	0xe
	.long	0x80
	.byte	0x2
	.uleb128 0x17
	.string	"key"
	.byte	0x3
	.byte	0xf
	.byte	0x7
	.long	0xa3
	.byte	0x3
	.uleb128 0x4
	.long	.LASF27
	.byte	0x10
	.long	0x10d
	.byte	0x4
	.byte	0
	.uleb128 0x7
	.byte	0x1
	.byte	0x2
	.long	.LASF28
	.uleb128 0xd
	.long	0x10d
	.uleb128 0x7
	.byte	0x4
	.byte	0x5
	.long	.LASF29
	.uleb128 0xe
	.long	.LASF70
	.long	0xc6
	.long	0x135
	.uleb128 0x8
	.long	0x119
	.sleb128 64
	.byte	0
	.uleb128 0x9
	.sleb128 64
	.long	.LASF68
	.long	0x119
	.uleb128 0x3
	.long	.LASF30
	.byte	0x13
	.long	0x16f
	.uleb128 0x1
	.long	.LASF31
	.byte	0
	.uleb128 0x1
	.long	.LASF32
	.byte	0x1
	.uleb128 0x1
	.long	.LASF33
	.byte	0x2
	.uleb128 0x1
	.long	.LASF34
	.byte	0x3
	.uleb128 0x1
	.long	.LASF35
	.byte	0x4
	.uleb128 0x1
	.long	.LASF36
	.byte	0x5
	.byte	0
	.uleb128 0x3
	.long	.LASF37
	.byte	0x16
	.long	0x1aa
	.uleb128 0x1
	.long	.LASF38
	.byte	0
	.uleb128 0x1
	.long	.LASF39
	.byte	0x1
	.uleb128 0x1
	.long	.LASF40
	.byte	0x2
	.uleb128 0x1
	.long	.LASF41
	.byte	0x3
	.uleb128 0x1
	.long	.LASF42
	.byte	0x4
	.uleb128 0x1
	.long	.LASF43
	.byte	0x5
	.uleb128 0x1
	.long	.LASF44
	.byte	0x6
	.uleb128 0x1
	.long	.LASF45
	.byte	0x7
	.byte	0
	.uleb128 0x3
	.long	.LASF46
	.byte	0x19
	.long	0x1c7
	.uleb128 0x1
	.long	.LASF47
	.byte	0
	.uleb128 0x1
	.long	.LASF48
	.byte	0x1
	.uleb128 0x1
	.long	.LASF49
	.byte	0x2
	.byte	0
	.uleb128 0xf
	.long	.LASF51
	.value	0x168
	.byte	0x1b
	.long	0x2b2
	.uleb128 0x4
	.long	.LASF52
	.byte	0x1c
	.long	0x120
	.byte	0
	.uleb128 0x2
	.long	.LASF53
	.byte	0x1d
	.byte	0x7
	.long	0x135
	.value	0x140
	.uleb128 0x2
	.long	.LASF54
	.byte	0x1e
	.byte	0x7
	.long	0x140
	.value	0x144
	.uleb128 0x2
	.long	.LASF55
	.byte	0x1f
	.byte	0x7
	.long	0x16f
	.value	0x145
	.uleb128 0x2
	.long	.LASF56
	.byte	0x20
	.byte	0x7
	.long	0x1aa
	.value	0x146
	.uleb128 0x2
	.long	.LASF57
	.byte	0x21
	.byte	0x7
	.long	0x21f
	.value	0x148
	.uleb128 0x18
	.sleb128 5
	.long	0x119
	.uleb128 0x2
	.long	.LASF58
	.byte	0x22
	.byte	0x7
	.long	0x232
	.value	0x14c
	.uleb128 0x19
	.sleb128 0
	.sleb128 4
	.long	0x119
	.uleb128 0x2
	.long	.LASF59
	.byte	0x23
	.byte	0x7
	.long	0x10d
	.value	0x150
	.uleb128 0x10
	.long	0x2b2
	.long	0x256
	.uleb128 0x8
	.long	0x119
	.sleb128 10
	.byte	0
	.uleb128 0x2
	.long	.LASF60
	.byte	0x24
	.byte	0x7
	.long	0x246
	.value	0x151
	.uleb128 0x2
	.long	.LASF61
	.byte	0x25
	.byte	0x7
	.long	0x2be
	.value	0x15c
	.uleb128 0x2
	.long	.LASF62
	.byte	0x26
	.byte	0x7
	.long	0x10d
	.value	0x160
	.uleb128 0x2
	.long	.LASF63
	.byte	0x27
	.byte	0x7
	.long	0x10d
	.value	0x161
	.uleb128 0x2
	.long	.LASF64
	.byte	0x28
	.byte	0x7
	.long	0x10d
	.value	0x162
	.uleb128 0x2
	.long	.LASF65
	.byte	0x28
	.byte	0x10
	.long	0x10d
	.value	0x163
	.uleb128 0x2
	.long	.LASF66
	.byte	0x28
	.byte	0x1a
	.long	0x10d
	.value	0x164
	.byte	0
	.uleb128 0x7
	.byte	0x1
	.byte	0x8
	.long	.LASF67
	.uleb128 0xd
	.long	0x2b2
	.uleb128 0x9
	.sleb128 11
	.long	.LASF69
	.long	0x119
	.uleb128 0xe
	.long	.LASF71
	.long	0x2b2
	.long	0x2dc
	.uleb128 0x8
	.long	0x119
	.sleb128 2
	.byte	0
	.uleb128 0x9
	.sleb128 2
	.long	.LASF72
	.long	0x119
	.uleb128 0xf
	.long	.LASF73
	.value	0x170
	.byte	0x2d
	.long	0x318
	.uleb128 0x4
	.long	.LASF74
	.byte	0x2e
	.long	0x1c7
	.byte	0
	.uleb128 0x2
	.long	.LASF75
	.byte	0x2f
	.byte	0x7
	.long	0x2c8
	.value	0x168
	.uleb128 0x2
	.long	.LASF76
	.byte	0x30
	.byte	0x7
	.long	0x2dc
	.value	0x16c
	.byte	0
	.uleb128 0x1a
	.long	.LASF99
	.byte	0x1
	.byte	0xb
	.byte	0x4
	.long	0x1c7
	.uleb128 0x9
	.byte	0x3
	.quad	silver_report_projection__initial_state
	.uleb128 0x1b
	.long	.LASF100
	.byte	0x1
	.byte	0x1
	.byte	0x6
	.uleb128 0x1c
	.byte	0x2
	.byte	0x2
	.byte	0x1
	.long	0x32e
	.uleb128 0x1d
	.long	.LASF101
	.byte	0x1
	.byte	0x6
	.byte	0x1
	.quad	.LFB1
	.quad	.LFE1-.LFB1
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x11
	.long	.LASF77
	.byte	0x8
	.long	0x10d
	.quad	.LFB13
	.quad	.LFE13-.LFB13
	.uleb128 0x1
	.byte	0x9c
	.long	0x385
	.uleb128 0xa
	.string	"c"
	.byte	0x8
	.byte	0x12
	.long	0x2b9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.byte	0
	.uleb128 0x11
	.long	.LASF78
	.byte	0x6
	.long	0x10d
	.quad	.LFB12
	.quad	.LFE12-.LFB12
	.uleb128 0x1
	.byte	0x9c
	.long	0x3b2
	.uleb128 0xa
	.string	"c"
	.byte	0x6
	.byte	0x14
	.long	0x2b9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.byte	0
	.uleb128 0x1e
	.long	.LASF102
	.byte	0x2
	.byte	0xb
	.byte	0x4
	.long	0x2e6
	.quad	.LFB3
	.quad	.LFE3-.LFB3
	.uleb128 0x1
	.byte	0x9c
	.long	0x5a9
	.uleb128 0x5
	.long	.LASF79
	.byte	0x1
	.byte	0xd
	.byte	0x16
	.long	0x5a9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -480
	.uleb128 0x5
	.long	.LASF80
	.byte	0x1
	.byte	0xd
	.byte	0x26
	.long	0x2b9
	.uleb128 0x6
	.byte	0x91
	.sleb128 -448
	.byte	0x23
	.uleb128 0x170
	.uleb128 0x6
	.long	.LASF81
	.byte	0xc
	.byte	0x7
	.long	0x2e6
	.uleb128 0x3
	.byte	0x91
	.sleb128 -448
	.uleb128 0x1f
	.string	"s"
	.byte	0x2
	.byte	0xd
	.byte	0x7
	.long	0x5a9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x20
	.long	.LASF103
	.byte	0x2
	.byte	0xf
	.byte	0x7
	.long	0x10d
	.quad	.LFB11
	.quad	.LFE11-.LFB11
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -24
	.byte	0x6
	.byte	0x23
	.uleb128 0x178
	.byte	0x6
	.uleb128 0xb
	.long	.LASF82
	.byte	0x12
	.quad	.LFB4
	.quad	.LFE4-.LFB4
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -48
	.byte	0x6
	.byte	0x23
	.uleb128 0x178
	.byte	0x6
	.long	0x46a
	.uleb128 0xa
	.string	"c"
	.byte	0x12
	.byte	0x17
	.long	0x2b9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -33
	.byte	0
	.uleb128 0xc
	.long	.LASF83
	.byte	0x1d
	.quad	.LFB5
	.quad	.LFE5-.LFB5
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -24
	.byte	0x6
	.byte	0x23
	.uleb128 0x178
	.byte	0x6
	.uleb128 0xc
	.long	.LASF84
	.byte	0x2c
	.quad	.LFB6
	.quad	.LFE6-.LFB6
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -40
	.byte	0x6
	.byte	0x23
	.uleb128 0x178
	.byte	0x6
	.uleb128 0x21
	.long	.LASF85
	.byte	0x2
	.byte	0x48
	.byte	0x7
	.quad	.LFB7
	.quad	.LFE7-.LFB7
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -32
	.byte	0x6
	.byte	0x23
	.uleb128 0x178
	.byte	0x6
	.long	0x4ef
	.uleb128 0x5
	.long	.LASF86
	.byte	0x2
	.byte	0x48
	.byte	0x1f
	.long	0x114
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.uleb128 0x5
	.long	.LASF27
	.byte	0x2
	.byte	0x48
	.byte	0x31
	.long	0x114
	.uleb128 0x2
	.byte	0x91
	.sleb128 -18
	.byte	0
	.uleb128 0xb
	.long	.LASF87
	.byte	0x56
	.quad	.LFB8
	.quad	.LFE8-.LFB8
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -56
	.byte	0x6
	.byte	0x23
	.uleb128 0x178
	.byte	0x6
	.long	0x53e
	.uleb128 0x6
	.long	.LASF27
	.byte	0x5a
	.byte	0xa
	.long	0x10d
	.uleb128 0x2
	.byte	0x91
	.sleb128 -34
	.uleb128 0x6
	.long	.LASF88
	.byte	0x5b
	.byte	0xa
	.long	0x10d
	.uleb128 0x2
	.byte	0x91
	.sleb128 -35
	.uleb128 0x6
	.long	.LASF89
	.byte	0x5f
	.byte	0xa
	.long	0x80
	.uleb128 0x2
	.byte	0x91
	.sleb128 -33
	.byte	0
	.uleb128 0xc
	.long	.LASF90
	.byte	0x92
	.quad	.LFB9
	.quad	.LFE9-.LFB9
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -40
	.byte	0x6
	.byte	0x23
	.uleb128 0x178
	.byte	0x6
	.uleb128 0xb
	.long	.LASF91
	.byte	0xc4
	.quad	.LFB10
	.quad	.LFE10-.LFB10
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -56
	.byte	0x6
	.byte	0x23
	.uleb128 0x178
	.byte	0x6
	.long	0x591
	.uleb128 0x6
	.long	.LASF92
	.byte	0xc8
	.byte	0xa
	.long	0x10d
	.uleb128 0x2
	.byte	0x91
	.sleb128 -33
	.byte	0
	.uleb128 0x22
	.long	.LLRL0
	.uleb128 0x23
	.long	.LASF93
	.byte	0x2
	.value	0x116
	.byte	0x10
	.long	0x5af
	.uleb128 0x3
	.byte	0x91
	.sleb128 -464
	.byte	0
	.byte	0
	.uleb128 0x24
	.byte	0x8
	.long	0x1c7
	.uleb128 0x25
	.long	.LASF94
	.byte	0x10
	.byte	0x4
	.byte	0
	.long	0x5f2
	.uleb128 0x12
	.long	.LASF95
	.long	0x5c5
	.byte	0
	.uleb128 0x13
	.long	0x5f2
	.uleb128 0x26
	.byte	0x8
	.byte	0x4
	.byte	0
	.long	0x5e7
	.uleb128 0x14
	.string	"LB0"
	.long	0x611
	.byte	0
	.uleb128 0x14
	.string	"UB0"
	.long	0x611
	.byte	0x4
	.byte	0
	.uleb128 0x12
	.long	.LASF96
	.long	0x61f
	.byte	0x8
	.byte	0
	.uleb128 0x10
	.long	0x2b2
	.long	0x611
	.uleb128 0x27
	.long	0x119
	.uleb128 0x6
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x94
	.byte	0x4
	.uleb128 0x8
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x23
	.uleb128 0x4
	.byte	0x94
	.byte	0x4
	.byte	0
	.uleb128 0x28
	.sleb128 2147483647
	.long	.LASF104
	.long	0x119
	.uleb128 0x13
	.long	0x5ca
	.uleb128 0x29
	.long	.LASF105
	.byte	0x1
	.byte	0x11
	.byte	0x4
	.long	0x10d
	.quad	.LFB2
	.quad	.LFE2-.LFB2
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x5
	.long	.LASF97
	.byte	0x1
	.byte	0x11
	.byte	0x17
	.long	0x5a9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.byte	0
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x28
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x1c
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0x5
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3e
	.uleb128 0x21
	.sleb128 7
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 7
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 7
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 7
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0x5
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x14
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x15
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x16
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x17
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x18
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x19
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0xd
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x1a
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x1b
	.uleb128 0x1e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x1c
	.uleb128 0x3a
	.byte	0
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x18
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1d
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x1e
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1f
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x20
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x21
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x22
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x55
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x23
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x24
	.uleb128 0x10
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x25
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x26
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x27
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x18
	.uleb128 0x2f
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x28
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x29
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x2c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.Letext0-.Ltext0
	.quad	0
	.quad	0
	.section	.debug_rnglists,"",@progbits
.Ldebug_ranges0:
	.long	.Ldebug_ranges3-.Ldebug_ranges2
.Ldebug_ranges2:
	.value	0x5
	.byte	0x8
	.byte	0
	.long	0
.LLRL0:
	.byte	0x4
	.uleb128 .LBB9-.Ltext0
	.uleb128 .LBE9-.Ltext0
	.byte	0x4
	.uleb128 .LBB10-.Ltext0
	.uleb128 .LBE10-.Ltext0
	.byte	0
.Ldebug_ranges3:
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF37:
	.string	"silver_report_projection_types__number_position"
.LASF72:
	.string	"silver_report_projection_types__emission_length"
.LASF81:
	.string	"result"
.LASF9:
	.string	"silver_report_projection_types__object_value"
.LASF46:
	.string	"silver_report_projection_types__literal_kind"
.LASF95:
	.string	"P_ARRAY"
.LASF91:
	.string	"silver_report_projection__advance__number_byte"
.LASF41:
	.string	"silver_report_projection_types__after_dot"
.LASF29:
	.string	"integer"
.LASF40:
	.string	"silver_report_projection_types__integer_digits"
.LASF17:
	.string	"silver_report_projection_types__check_list"
.LASF92:
	.string	"terminal"
.LASF88:
	.string	"project"
.LASF26:
	.string	"role"
.LASF86:
	.string	"is_key"
.LASF27:
	.string	"keep"
.LASF24:
	.string	"container"
.LASF12:
	.string	"silver_report_projection_types__next_item"
.LASF74:
	.string	"following"
.LASF30:
	.string	"silver_report_projection_types__lexical_mode"
.LASF23:
	.string	"silver_report_projection_types__tree_key"
.LASF16:
	.string	"silver_report_projection_types__root_object"
.LASF10:
	.string	"silver_report_projection_types__object_separator"
.LASF31:
	.string	"silver_report_projection_types__between_tokens"
.LASF89:
	.string	"new_role"
.LASF66:
	.string	"failed"
.LASF85:
	.string	"silver_report_projection__advance__start_string"
.LASF3:
	.string	"silver_report_projection_types__array_container"
.LASF44:
	.string	"silver_report_projection_types__after_exponent_sign"
.LASF70:
	.string	"silver_report_projection_types__frames"
.LASF22:
	.string	"silver_report_projection_types__proof_key"
.LASF61:
	.string	"name_length"
.LASF33:
	.string	"silver_report_projection_types__after_escape"
.LASF6:
	.string	"silver_report_projection_types__first_key"
.LASF103:
	.string	"silver_report_projection__advance__keeping"
.LASF32:
	.string	"silver_report_projection_types__in_string"
.LASF71:
	.string	"silver_report_projection_types__emission_bytes"
.LASF15:
	.string	"silver_report_projection_types__ordinary"
.LASF35:
	.string	"silver_report_projection_types__in_number"
.LASF56:
	.string	"literal"
.LASF65:
	.string	"finished"
.LASF51:
	.string	"silver_report_projection_types__state"
.LASF19:
	.string	"silver_report_projection_types__key_kind"
.LASF67:
	.string	"character"
.LASF84:
	.string	"silver_report_projection__advance__end_string"
.LASF13:
	.string	"silver_report_projection_types__array_separator"
.LASF60:
	.string	"name"
.LASF96:
	.string	"P_BOUNDS"
.LASF50:
	.string	"silver_report_projection_types__frame"
.LASF4:
	.string	"silver_report_projection_types__container_kind"
.LASF76:
	.string	"length"
.LASF100:
	.string	"silver_report_projection_types"
.LASF57:
	.string	"literal_position"
.LASF82:
	.string	"silver_report_projection__advance__emit"
.LASF79:
	.string	"before"
.LASF52:
	.string	"stack"
.LASF87:
	.string	"silver_report_projection__advance__start_value"
.LASF11:
	.string	"silver_report_projection_types__first_item"
.LASF64:
	.string	"started"
.LASF90:
	.string	"silver_report_projection__advance__between"
.LASF5:
	.string	"silver_report_projection_types__position_kind"
.LASF99:
	.string	"silver_report_projection__initial_state"
.LASF59:
	.string	"string_is_key"
.LASF34:
	.string	"silver_report_projection_types__unicode_escape"
.LASF98:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF7:
	.string	"silver_report_projection_types__next_key"
.LASF54:
	.string	"mode"
.LASF94:
	.string	"string"
.LASF69:
	.string	"silver_report_projection_types__key_length"
.LASF39:
	.string	"silver_report_projection_types__after_zero"
.LASF53:
	.string	"depth"
.LASF36:
	.string	"silver_report_projection_types__in_literal"
.LASF18:
	.string	"silver_report_projection_types__check_record"
.LASF93:
	.string	"expected"
.LASF102:
	.string	"silver_report_projection__advance"
.LASF45:
	.string	"silver_report_projection_types__exponent_digits"
.LASF49:
	.string	"silver_report_projection_types__null_literal"
.LASF75:
	.string	"bytes"
.LASF68:
	.string	"silver_report_projection_types__depth_range"
.LASF73:
	.string	"silver_report_projection_types__transition"
.LASF78:
	.string	"silver_report_projection__space"
.LASF21:
	.string	"silver_report_projection_types__flow_key"
.LASF77:
	.string	"silver_report_projection__hex"
.LASF83:
	.string	"silver_report_projection__advance__end_value"
.LASF80:
	.string	"item"
.LASF101:
	.string	"silver_report_projection___elabs"
.LASF43:
	.string	"silver_report_projection_types__after_exponent"
.LASF63:
	.string	"token_keep"
.LASF97:
	.string	"current"
.LASF25:
	.string	"position"
.LASF58:
	.string	"unicode_left"
.LASF20:
	.string	"silver_report_projection_types__other_key"
.LASF55:
	.string	"number"
.LASF8:
	.string	"silver_report_projection_types__colon"
.LASF48:
	.string	"silver_report_projection_types__false_literal"
.LASF47:
	.string	"silver_report_projection_types__true_literal"
.LASF105:
	.string	"silver_report_projection__complete"
.LASF2:
	.string	"silver_report_projection_types__object_container"
.LASF14:
	.string	"silver_report_projection_types__role_kind"
.LASF42:
	.string	"silver_report_projection_types__fraction_digits"
.LASF28:
	.string	"boolean"
.LASF38:
	.string	"silver_report_projection_types__after_minus"
.LASF104:
	.string	"positive"
.LASF62:
	.string	"name_escaped"
	.section	.debug_line_str,"MS",@progbits,1
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_report_projection.adb"
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
	.hidden	DW.ref.__gnat_personality_v0
	.weak	DW.ref.__gnat_personality_v0
	.section	.data.rel.local.DW.ref.__gnat_personality_v0,"awG",@progbits,DW.ref.__gnat_personality_v0,comdat
	.align 8
	.type	DW.ref.__gnat_personality_v0, @object
	.size	DW.ref.__gnat_personality_v0, 8
DW.ref.__gnat_personality_v0:
	.quad	__gnat_personality_v0
	.globl	__gnat_personality_v0
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
