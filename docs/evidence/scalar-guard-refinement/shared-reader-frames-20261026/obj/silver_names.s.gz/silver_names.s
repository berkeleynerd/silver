	.file	"silver_names.adb"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_names.adb"
	.align 2
	.globl	silver_names__context_resultIP
	.type	silver_names__context_resultIP, @function
silver_names__context_resultIP:
.LFB2:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	silver_names__context_resultIP, .-silver_names__context_resultIP
	.align 2
	.globl	silver_names__operation_kindH
	.type	silver_names__operation_kindH, @function
silver_names__operation_kindH:
.LFB3:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	movq	-8(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L3
	movl	%edx, %ecx
	subl	%eax, %ecx
	leal	1(%rcx), %r11d
	jmp	.L4
.L3:
	movl	$0, %r11d
.L4:
	movslq	%eax, %r9
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	leal	-1(%rax), %r10d
	movl	$0, %esi
	movl	$0, %ecx
	movl	$0, %edx
.L12:
	testl	%edx, %edx
	jg	.L11
	movslq	%edx, %rax
	leaq	0(,%rax,4), %rdi
	leaq	operation_kindP.15(%rip), %rax
	movl	(%rdi,%rax), %eax
	cmpl	%eax, %r11d
	jl	.L11
	movq	-16(%rbp), %rax
	movslq	%edx, %rdi
	leaq	0(,%rdi,4), %r8
	leaq	operation_kindP.15(%rip), %rdi
	movl	(%r8,%rdi), %edi
	addl	%r10d, %edi
	movslq	%edi, %rdi
	subq	%r9, %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %r8d
	movslq	%edx, %rax
	leaq	operation_kindT1.14(%rip), %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %eax
	imull	%r8d, %eax
	leal	(%rsi,%rax), %edi
	movslq	%edi, %rax
	imulq	$780903145, %rax, %rax
	shrq	$32, %rax
	movl	%eax, %esi
	sarl	%esi
	movl	%edi, %eax
	sarl	$31, %eax
	subl	%eax, %esi
	movl	%esi, %eax
	sall	$2, %eax
	addl	%esi, %eax
	addl	%eax, %eax
	addl	%esi, %eax
	movl	%edi, %esi
	subl	%eax, %esi
	movslq	%edx, %rax
	leaq	operation_kindT2.13(%rip), %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %eax
	imull	%r8d, %eax
	leal	(%rcx,%rax), %edi
	movslq	%edi, %rax
	imulq	$780903145, %rax, %rax
	shrq	$32, %rax
	movl	%eax, %ecx
	sarl	%ecx
	movl	%edi, %eax
	sarl	$31, %eax
	subl	%eax, %ecx
	movl	%ecx, %eax
	sall	$2, %eax
	addl	%ecx, %eax
	addl	%eax, %eax
	addl	%ecx, %eax
	movl	%edi, %ecx
	subl	%eax, %ecx
	addl	$1, %edx
	jmp	.L12
.L11:
	movslq	%esi, %rax
	leaq	operation_kindG.12(%rip), %rdx
	movzbl	(%rax,%rdx), %eax
	movzbl	%al, %edx
	movslq	%ecx, %rax
	leaq	operation_kindG.12(%rip), %rcx
	movzbl	(%rax,%rcx), %eax
	movzbl	%al, %eax
	leal	(%rdx,%rax), %ecx
	movslq	%ecx, %rax
	imulq	$1717986919, %rax, %rax
	shrq	$32, %rax
	movl	%eax, %edx
	sarl	%edx
	movl	%ecx, %eax
	sarl	$31, %eax
	subl	%eax, %edx
	movl	%edx, %eax
	sall	$2, %eax
	addl	%edx, %eax
	movl	%ecx, %edx
	subl	%eax, %edx
	movl	%edx, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.size	silver_names__operation_kindH, .-silver_names__operation_kindH
	.section	.rodata
.LC10:
	.ascii	"silver_names.adb"
	.zero	1
	.align 8
.LC11:
	.ascii	"Loop_Invariant failed at silver_names.adb:39"
	.align 8
.LC0:
	.long	1
	.long	44
	.text
	.align 2
	.type	silver_names__take___wrapped_statements.0, @function
silver_names__take___wrapped_statements.0:
.LFB5:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_names.adb"
	.loc 1 28 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$88, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -88(%rbp)
	.loc 1 28 4
	movl	48(%rbx), %r15d
	movl	44(%rbx), %eax
	movl	%eax, -100(%rbp)
	movl	44(%rbx), %edx
	movl	48(%rbx), %eax
	cmpl	%eax, %edx
	jl	.L15
	.loc 1 28 4 is_stmt 0 discriminator 1
	movl	44(%rbx), %ecx
	movslq	%ecx, %rax
	cqto
	movl	48(%rbx), %ecx
	movslq	%ecx, %rcx
	movq	%rcx, %rsi
	movq	%rcx, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %r12
	movq	%rdx, %r13
	jmp	.L16
.L15:
	.loc 1 28 4 discriminator 2
	movl	$0, %r12d
	movl	$0, %r13d
.L16:
	.loc 1 28 4 discriminator 3
	movl	40(%rbx), %eax
	movl	%eax, -92(%rbp)
	movl	36(%rbx), %r14d
.LBB4:
	.loc 1 33 7 is_stmt 1
	movl	32(%rbx), %eax
	testl	%eax, %eax
	jne	.L17
	.loc 1 33 28 discriminator 1
	movl	$0, %eax
	jmp	.L18
.L17:
	.loc 1 34 15
	movl	32(%rbx), %eax
	testl	%eax, %eax
	jle	.L19
	.loc 1 34 15 is_stmt 0 discriminator 1
	movl	32(%rbx), %eax
	cmpl	$4097, %eax
	jle	.L20
.L19:
	.loc 1 34 15 discriminator 2
	leaq	.LC10(%rip), %rax
	movl	$34, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L20:
	.loc 1 34 12 is_stmt 1 discriminator 3
	movl	32(%rbx), %eax
	movl	%eax, -60(%rbp)
	.loc 1 35 7
	movq	24(%rbx), %rax
	movl	-60(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__skip_trivia@PLT
	.loc 1 35 7 is_stmt 0 discriminator 1
	movl	%eax, -60(%rbp)
	.loc 1 36 22 is_stmt 1
	movl	%r12d, %edx
	.loc 1 36 35
	movl	$0, %ecx
	movl	%r14d, %eax
	subl	-60(%rbp), %eax
	jno	.L21
	movl	$1, %ecx
.L21:
	movl	%eax, %esi
	.loc 1 36 35 is_stmt 0 discriminator 1
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L23
	.loc 1 36 35 discriminator 2
	leaq	.LC10(%rip), %rax
	movl	$36, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L23:
	.loc 1 36 35 discriminator 4
	movl	%esi, %eax
	.loc 1 36 43 is_stmt 1 discriminator 5
	cmpl	$2147483647, %eax
	jne	.L24
	.loc 1 36 43 is_stmt 0 discriminator 6
	leaq	.LC10(%rip), %rax
	movl	$36, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L24:
	.loc 1 36 43 discriminator 8
	addl	$1, %eax
	.loc 1 36 7 is_stmt 1 discriminator 9
	cmpl	%edx, %eax
	jge	.L25
	.loc 1 36 52 discriminator 10
	movl	$0, %eax
	jmp	.L18
.L25:
	.loc 1 37 11
	movl	%r15d, -64(%rbp)
	movl	-100(%rbp), %eax
	movl	%eax, -68(%rbp)
	movl	-64(%rbp), %eax
	cmpl	-68(%rbp), %eax
	jg	.L26
.LBB5:
	.loc 1 37 11 is_stmt 0 discriminator 1
	movl	-64(%rbp), %eax
	movl	%eax, -52(%rbp)
.L48:
.LBB6:
	.loc 1 39 13 is_stmt 1
	movb	$1, -93(%rbp)
	.loc 1 39 21
	movl	%r15d, -72(%rbp)
	.loc 1 39 53
	cmpl	$-2147483648, -52(%rbp)
	jne	.L27
	.loc 1 39 21 discriminator 1
	leaq	.LC10(%rip), %rax
	movl	$39, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L27:
	.loc 1 39 21 is_stmt 0 discriminator 3
	movl	-52(%rbp), %eax
	subl	$1, %eax
	movl	%eax, -76(%rbp)
	.loc 1 39 13 is_stmt 1 discriminator 4
	movl	-72(%rbp), %eax
	cmpl	-76(%rbp), %eax
	jg	.L28
.LBB7:
	.loc 1 39 21 discriminator 5
	movl	-72(%rbp), %eax
	movl	%eax, -56(%rbp)
.L39:
.LBB8:
	.loc 1 40 37
	movl	$0, %ecx
	movl	-60(%rbp), %edx
	movl	-56(%rbp), %eax
	addl	%edx, %eax
	jno	.L29
	movl	$1, %ecx
.L29:
	movl	%eax, %edx
	.loc 1 40 37 is_stmt 0 discriminator 1
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L31
	.loc 1 40 37 discriminator 2
	leaq	.LC10(%rip), %rax
	movl	$40, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L31:
	.loc 1 40 37 discriminator 4
	movl	%edx, %eax
	.loc 1 40 49 is_stmt 1 discriminator 5
	cmpl	$-2147483648, %eax
	jne	.L32
	.loc 1 40 49 is_stmt 0 discriminator 6
	leaq	.LC10(%rip), %rax
	movl	$40, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L32:
	.loc 1 40 49 discriminator 8
	subl	$1, %eax
	.loc 1 40 25 is_stmt 1 discriminator 9
	cmpl	%eax, -92(%rbp)
	jg	.L33
	.loc 1 40 25 is_stmt 0 discriminator 10
	cmpl	%eax, %r14d
	jge	.L34
.L33:
	.loc 1 40 25 discriminator 11
	leaq	.LC10(%rip), %rax
	movl	$40, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L34:
	.loc 1 40 57 is_stmt 1 discriminator 12
	cmpl	-56(%rbp), %r15d
	jg	.L35
	.loc 1 40 57 is_stmt 0 discriminator 13
	movl	-100(%rbp), %edi
	cmpl	-56(%rbp), %edi
	jge	.L36
.L35:
	.loc 1 40 57 discriminator 14
	leaq	.LC10(%rip), %rax
	movl	$40, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L36:
	.loc 1 40 14 is_stmt 1 discriminator 15
	movq	24(%rbx), %rdx
	movq	(%rdx), %rdx
	movslq	%eax, %rcx
	movq	16(%rbx), %rax
	subq	%rax, %rcx
	movzbl	(%rdx,%rcx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__lowercase@PLT
	.loc 1 40 55 discriminator 16
	movq	8(%rbx), %rdx
	movq	(%rdx), %rdx
	movl	-56(%rbp), %ecx
	movslq	%ecx, %rsi
	movq	(%rbx), %rcx
	subq	%rcx, %rsi
	movzbl	(%rdx,%rsi), %edx
	.loc 1 39 13 discriminator 6
	cmpb	%dl, %al
	je	.L37
	.loc 1 39 13 is_stmt 0 discriminator 7
	movb	$0, -93(%rbp)
	jmp	.L28
.L37:
.LBE8:
	.loc 1 39 13 discriminator 8
	movl	-56(%rbp), %eax
	cmpl	-76(%rbp), %eax
	je	.L28
	.loc 1 39 13 discriminator 9
	addl	$1, -56(%rbp)
	jmp	.L39
.L28:
.LBE7:
	.loc 1 39 13 discriminator 10
	movzbl	-93(%rbp), %eax
	xorl	$1, %eax
	testb	%al, %al
	je	.L40
.LBB9:
	.loc 1 39 13 discriminator 11
	leaq	.LC11(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L40:
.LBE9:
	.loc 1 41 36 is_stmt 1
	movl	$0, %ecx
	movl	-60(%rbp), %edx
	movl	-52(%rbp), %eax
	addl	%edx, %eax
	jno	.L41
	movl	$1, %ecx
.L41:
	movl	%eax, %edx
	.loc 1 41 36 is_stmt 0 discriminator 1
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L43
	.loc 1 41 36 discriminator 2
	leaq	.LC10(%rip), %rax
	movl	$41, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L43:
	.loc 1 41 36 discriminator 4
	movl	%edx, %eax
	.loc 1 41 45 is_stmt 1 discriminator 5
	cmpl	$-2147483648, %eax
	jne	.L44
	.loc 1 41 45 is_stmt 0 discriminator 6
	leaq	.LC10(%rip), %rax
	movl	$41, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L44:
	.loc 1 41 45 discriminator 8
	subl	$1, %eax
	.loc 1 41 24 is_stmt 1 discriminator 9
	cmpl	%eax, -92(%rbp)
	jg	.L45
	.loc 1 41 24 is_stmt 0 discriminator 10
	cmpl	%eax, %r14d
	jge	.L46
.L45:
	.loc 1 41 24 discriminator 11
	leaq	.LC10(%rip), %rax
	movl	$41, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L46:
	.loc 1 41 13 is_stmt 1 discriminator 12
	movq	24(%rbx), %rdx
	movq	(%rdx), %rdx
	movslq	%eax, %rcx
	movq	16(%rbx), %rax
	subq	%rax, %rcx
	movzbl	(%rdx,%rcx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__lowercase@PLT
	.loc 1 41 51 discriminator 13
	movq	8(%rbx), %rdx
	movq	(%rdx), %rdx
	movl	-52(%rbp), %ecx
	movslq	%ecx, %rsi
	movq	(%rbx), %rcx
	subq	%rcx, %rsi
	movzbl	(%rdx,%rsi), %edx
	.loc 1 41 10 discriminator 13
	cmpb	%dl, %al
	je	.L47
	.loc 1 41 72 discriminator 14
	movl	$0, %eax
	jmp	.L18
.L47:
.LBE6:
	.loc 1 37 11 discriminator 2
	movl	-52(%rbp), %eax
	cmpl	-68(%rbp), %eax
	je	.L26
	.loc 1 37 11 is_stmt 0 discriminator 3
	addl	$1, -52(%rbp)
	.loc 1 42 15 is_stmt 1
	jmp	.L48
.L26:
.LBE5:
	.loc 1 43 7
	movzbl	52(%rbx), %eax
	testb	%al, %al
	je	.L49
	.loc 1 43 32 discriminator 1
	movl	%r12d, %ecx
	movl	$0, %edx
	movl	-60(%rbp), %eax
	addl	%ecx, %eax
	jno	.L50
	movl	$1, %edx
.L50:
	movl	%eax, %ecx
	.loc 1 43 32 is_stmt 0 discriminator 2
	movl	%edx, %eax
	testl	%eax, %eax
	je	.L52
	.loc 1 43 32 discriminator 3
	leaq	.LC10(%rip), %rax
	movl	$43, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L52:
	.loc 1 43 32 discriminator 5
	movl	%ecx, %eax
	.loc 1 43 18 is_stmt 1 discriminator 6
	cmpl	%r14d, %eax
	jg	.L49
	.loc 1 44 54
	movl	%r12d, %ecx
	movl	$0, %edx
	movl	-60(%rbp), %eax
	addl	%ecx, %eax
	jno	.L53
	movl	$1, %edx
.L53:
	movl	%eax, %ecx
	.loc 1 44 54 is_stmt 0 discriminator 1
	movl	%edx, %eax
	testl	%eax, %eax
	je	.L55
	.loc 1 44 54 discriminator 2
	leaq	.LC10(%rip), %rax
	movl	$44, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L55:
	.loc 1 44 54 discriminator 4
	movl	%ecx, %eax
	.loc 1 44 43 is_stmt 1 discriminator 5
	cmpl	%eax, -92(%rbp)
	jg	.L56
	.loc 1 44 43 is_stmt 0 discriminator 6
	cmpl	%eax, %r14d
	jge	.L57
.L56:
	.loc 1 44 43 discriminator 7
	leaq	.LC10(%rip), %rax
	movl	$44, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L57:
	.loc 1 44 18 is_stmt 1 discriminator 8
	movq	24(%rbx), %rdx
	movq	(%rdx), %rdx
	movslq	%eax, %rcx
	movq	16(%rbx), %rax
	subq	%rax, %rcx
	movzbl	(%rdx,%rcx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_identifier_character@PLT
	.loc 1 44 9 discriminator 9
	testb	%al, %al
	je	.L49
	.loc 1 45 12
	movl	$0, %eax
	jmp	.L18
.L49:
	.loc 1 46 19
	movl	%r12d, %ecx
	movl	$0, %edx
	movl	-60(%rbp), %eax
	addl	%ecx, %eax
	jno	.L58
	movl	$1, %edx
.L58:
	movl	%eax, %ecx
	.loc 1 46 19 is_stmt 0 discriminator 1
	movl	%edx, %eax
	testl	%eax, %eax
	je	.L60
	.loc 1 46 19 discriminator 2
	leaq	.LC10(%rip), %rax
	movl	$46, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L60:
	.loc 1 46 19 discriminator 4
	movl	%ecx, %eax
	.loc 1 46 19 discriminator 5
	testl	%eax, %eax
	js	.L61
	.loc 1 46 19 discriminator 6
	cmpl	$4097, %eax
	jle	.L63
.L61:
	.loc 1 46 19 discriminator 7
	leaq	.LC10(%rip), %rax
	movl	$46, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L63:
	.loc 1 46 7 is_stmt 1 discriminator 8
	nop
.L18:
.LBE4:
	.loc 1 47 8
	addq	$88, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE5:
	.size	silver_names__take___wrapped_statements.0, .-silver_names__take___wrapped_statements.0
	.section	.rodata
	.align 8
.LC12:
	.ascii	"failed precondition from silver_names.adb:22"
	.align 8
.LC13:
	.ascii	"failed precondition from silver_names.adb:23"
	.align 8
.LC14:
	.ascii	"failed precondition from silver_names.adb:24"
	.align 8
.LC15:
	.ascii	"failed postcondition from silver_names.adb:25"
	.align 8
.LC1:
	.long	1
	.long	45
	.text
	.align 2
	.globl	silver_names__take
	.type	silver_names__take, @function
silver_names__take:
.LFB4:
	.loc 1 28 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$184, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r10
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r10, %rdi
	movq	%rsi, -128(%rbp)
	movq	%rdi, -120(%rbp)
	movl	%edx, -132(%rbp)
	movq	%rcx, %rax
	movq	%r8, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -160(%rbp)
	movq	%rdx, -152(%rbp)
	movb	%r9b, -133(%rbp)
	.loc 1 28 4
	leaq	16(%rbp), %rdx
	.loc 1 28 4 is_stmt 0 discriminator 1
	leaq	-128(%rbp), %rax
	movq	%rdx, -56(%rbp)
	movq	%rax, -88(%rbp)
	leaq	-160(%rbp), %rax
	movl	-132(%rbp), %edx
	movl	%edx, -80(%rbp)
	movq	%rax, -104(%rbp)
	movzbl	-133(%rbp), %eax
	movb	%al, -60(%rbp)
	movq	-152(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -64(%rbp)
	movq	-152(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -68(%rbp)
	movl	-68(%rbp), %edx
	movl	-64(%rbp), %eax
	cmpl	%eax, %edx
	jl	.L65
	.loc 1 28 4 discriminator 2
	movl	-68(%rbp), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movl	-64(%rbp), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %r8
	movq	%rdx, %r9
	jmp	.L66
.L65:
	.loc 1 28 4 discriminator 3
	movl	$0, %r8d
	movl	$0, %r9d
.L66:
	.loc 1 28 4 discriminator 4
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -72(%rbp)
	movq	-120(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -76(%rbp)
	movl	-76(%rbp), %edx
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jl	.L67
	.loc 1 28 4 discriminator 5
	movl	-76(%rbp), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movl	-72(%rbp), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L68
.L67:
	.loc 1 28 4 discriminator 6
	movl	$0, %ecx
	movl	$0, %ebx
.L68:
.LBB10:
	.loc 1 28 4 discriminator 7
	movl	-64(%rbp), %eax
	cltq
	movq	%rax, -112(%rbp)
	movl	-68(%rbp), %edx
	movl	-64(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 28 4 discriminator 10
	movl	-68(%rbp), %edx
	movl	-64(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 28 4 discriminator 13
	movl	-68(%rbp), %edx
	movl	-64(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 28 4 discriminator 16
	movl	-72(%rbp), %eax
	cltq
	movq	%rax, -96(%rbp)
	movl	-76(%rbp), %edx
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 28 4 discriminator 19
	movl	-76(%rbp), %edx
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 28 4 discriminator 22
	movl	-76(%rbp), %edx
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 22 15 is_stmt 1
	movl	-72(%rbp), %eax
	cmpl	$1, %eax
	je	.L81
.LBB11:
	.loc 1 22 15 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L81:
.LBE11:
	.loc 1 22 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 1 22 15 discriminator 2
	testl	%eax, %eax
	jle	.L82
	.loc 1 22 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L83
.L82:
.LBB12:
	.loc 1 22 15 discriminator 4
	leaq	.LC12(%rip), %rax
	movq	%rax, -224(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rbx
	movq	-216(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L83:
.LBE12:
	.loc 1 23 41
	movl	-76(%rbp), %eax
	cmpl	$2147483647, %eax
	jne	.L84
	.loc 1 23 41 is_stmt 0 discriminator 1
	leaq	.LC10(%rip), %rax
	movl	$23, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L84:
	.loc 1 23 41 discriminator 3
	movl	-76(%rbp), %eax
	leal	1(%rax), %edx
	.loc 1 22 15 is_stmt 1 discriminator 5
	movl	-80(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L85
.LBB13:
	.loc 1 22 15 is_stmt 0 discriminator 6
	leaq	.LC13(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L85:
.LBE13:
	.loc 1 22 15 discriminator 7
	movl	-64(%rbp), %eax
	cmpl	$1, %eax
	je	.L86
.LBB14:
	.loc 1 22 15 discriminator 8
	leaq	.LC13(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L86:
.LBE14:
	.loc 1 24 31 is_stmt 1
	movl	%r8d, %eax
	.loc 1 22 15 discriminator 9
	testl	%eax, %eax
	jle	.L87
	.loc 1 24 31 discriminator 1
	movl	%r8d, %eax
	cmpl	$16, %eax
	jle	.L88
.L87:
.LBB15:
	.loc 1 22 15 discriminator 10
	leaq	.LC14(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L88:
.LBE15:
.LBB16:
	.loc 1 28 4 discriminator 25
	leaq	-112(%rbp), %rax
	movq	%rax, %r10
	call	silver_names__take___wrapped_statements.0
	.loc 1 25 28
	testl	%eax, %eax
	je	.L92
	.loc 1 26 10
	movl	-80(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L90
	.loc 1 26 59 discriminator 1
	movl	-76(%rbp), %edx
	cmpl	$2147483647, %edx
	jne	.L91
	.loc 1 26 59 is_stmt 0 discriminator 2
	leaq	.LC10(%rip), %rax
	movl	$26, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L91:
	.loc 1 26 59 discriminator 4
	movl	-76(%rbp), %edx
	addl	$1, %edx
	.loc 1 26 30 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L92
.L90:
.LBB17:
	.loc 1 25 28 discriminator 1
	leaq	.LC15(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L92:
.LBE17:
.LBE16:
.LBE10:
	.loc 1 28 4
	addq	$184, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	silver_names__take, .-silver_names__take
	.align 2
	.type	silver_names__context_modeH, @function
silver_names__context_modeH:
.LFB6:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	movq	-8(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L94
	movl	%edx, %ecx
	subl	%eax, %ecx
	leal	1(%rcx), %r11d
	jmp	.L95
.L94:
	movl	$0, %r11d
.L95:
	movslq	%eax, %r9
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	leal	-1(%rax), %r10d
	movl	$0, %ecx
	movl	$0, %edx
	movl	$0, %eax
.L103:
	testl	%eax, %eax
	jg	.L102
	movslq	%eax, %rsi
	leaq	0(,%rsi,4), %rdi
	leaq	context_modeP.11(%rip), %rsi
	movl	(%rdi,%rsi), %esi
	cmpl	%esi, %r11d
	jl	.L102
	movq	-16(%rbp), %rsi
	movslq	%eax, %rdi
	leaq	0(,%rdi,4), %r8
	leaq	context_modeP.11(%rip), %rdi
	movl	(%r8,%rdi), %edi
	addl	%r10d, %edi
	movslq	%edi, %rdi
	subq	%r9, %rdi
	movzbl	(%rsi,%rdi), %esi
	movzbl	%sil, %r8d
	movslq	%eax, %rsi
	leaq	context_modeT1.10(%rip), %rdi
	movzbl	(%rsi,%rdi), %esi
	movzbl	%sil, %esi
	imull	%r8d, %esi
	leal	(%rcx,%rsi), %edi
	movslq	%edi, %rcx
	imulq	$2021161081, %rcx, %rcx
	shrq	$32, %rcx
	sarl	$3, %ecx
	movl	%edi, %esi
	sarl	$31, %esi
	subl	%esi, %ecx
	movl	%ecx, %esi
	sall	$4, %esi
	addl	%ecx, %esi
	subl	%esi, %edi
	movl	%edi, %ecx
	movslq	%eax, %rsi
	leaq	context_modeT2.9(%rip), %rdi
	movzbl	(%rsi,%rdi), %esi
	movzbl	%sil, %esi
	imull	%r8d, %esi
	leal	(%rdx,%rsi), %edi
	movslq	%edi, %rdx
	imulq	$2021161081, %rdx, %rdx
	shrq	$32, %rdx
	sarl	$3, %edx
	movl	%edi, %esi
	sarl	$31, %esi
	subl	%esi, %edx
	movl	%edx, %esi
	sall	$4, %esi
	addl	%edx, %esi
	subl	%esi, %edi
	movl	%edi, %edx
	addl	$1, %eax
	jmp	.L103
.L102:
	movslq	%ecx, %rax
	leaq	context_modeG.8(%rip), %rcx
	movzbl	(%rax,%rcx), %eax
	movzbl	%al, %ecx
	movslq	%edx, %rax
	leaq	context_modeG.8(%rip), %rdx
	movzbl	(%rax,%rdx), %eax
	movzbl	%al, %eax
	addl	%eax, %ecx
	movslq	%ecx, %rax
	imulq	$1717986919, %rax, %rax
	shrq	$32, %rax
	movl	%eax, %edx
	sarl	%edx
	movl	%ecx, %eax
	sarl	$31, %eax
	subl	%eax, %edx
	movl	%edx, %eax
	sall	$2, %eax
	addl	%edx, %eax
	subl	%eax, %ecx
	movl	%ecx, %edx
	movl	%edx, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE6:
	.size	silver_names__context_modeH, .-silver_names__context_modeH
	.align 2
	.globl	silver_names__context_stateIP
	.type	silver_names__context_stateIP, @function
silver_names__context_stateIP:
.LFB7:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	.cfi_offset 3, -24
	movq	%rcx, %rax
	movq	%rbx, %rdx
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE7:
	.size	silver_names__context_stateIP, .-silver_names__context_stateIP
	.section	.rodata
.LC16:
	.ascii	"with"
.LC17:
	.ascii	"use"
.LC18:
	.ascii	"silver_io"
.LC19:
	.ascii	"silver_arguments"
.LC20:
	.ascii	";"
.LC21:
	.ascii	","
	.align 8
.LC2:
	.long	1
	.long	4
	.align 8
.LC3:
	.long	1
	.long	3
	.align 8
.LC4:
	.long	1
	.long	9
	.align 8
.LC5:
	.long	1
	.long	16
	.align 8
.LC6:
	.long	1
	.long	1
	.text
	.align 2
	.type	silver_names__context_step___wrapped_statements.1, @function
silver_names__context_step___wrapped_statements.1:
.LFB9:
	.loc 1 69 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$264, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -264(%rbp)
	.loc 1 70 30
	movq	8(%rbx), %rcx
	movl	(%rcx), %ecx
	.loc 1 70 7
	testl	%ecx, %ecx
	jne	.L107
	.loc 1 70 39 discriminator 1
	movq	silver_names__invalid_state(%rip), %rax
	movq	%rax, -120(%rbp)
	movl	8+silver_names__invalid_state(%rip), %eax
	movl	%eax, -112(%rbp)
	jmp	.L144
.L107:
	.loc 1 71 7
	movq	8(%rbx), %rcx
	movzbl	9(%rcx), %ecx
	testb	%cl, %cl
	je	.L109
	.loc 1 71 33 discriminator 1
	movq	8(%rbx), %rax
	movq	(%rax), %rdx
	movq	%rdx, -120(%rbp)
	movl	8(%rax), %eax
	movl	%eax, -112(%rbp)
	jmp	.L144
.L109:
	.loc 1 72 24
	movq	8(%rbx), %rcx
	movzbl	8(%rcx), %ecx
	.loc 1 72 7
	testb	%cl, %cl
	jne	.L110
	.loc 1 73 51
	leaq	.LC16(%rip), %r8
	leaq	.LC2(%rip), %r9
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	movq	(%rbx), %rax
	movq	%r8, %rcx
	movq	%r9, %rdi
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$1, %r9d
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_names__take
	.loc 1 73 51 is_stmt 0 discriminator 1
	movl	%eax, -68(%rbp)
	.loc 1 74 51 is_stmt 1
	leaq	.LC17(%rip), %rax
	movq	%rax, -304(%rbp)
	leaq	.LC3(%rip), %rax
	movq	%rax, -296(%rbp)
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	movq	(%rbx), %rax
	movq	-304(%rbp), %rsi
	movq	-296(%rbp), %rdi
	movq	%rsi, %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$1, %r9d
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_names__take
	.loc 1 74 51 is_stmt 0 discriminator 1
	movl	%eax, -72(%rbp)
	.loc 1 75 17 is_stmt 1
	cmpl	$0, -68(%rbp)
	je	.L111
	.loc 1 76 41
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movq	%rax, -128(%rbp)
	.loc 1 76 67
	movl	-68(%rbp), %eax
	movl	%eax, -128(%rbp)
	.loc 1 76 12
	movq	8(%rbx), %rax
	movq	(%rax), %rdx
	movq	%rdx, -144(%rbp)
	movl	8(%rax), %eax
	movl	%eax, -136(%rbp)
	.loc 1 76 30
	movq	-128(%rbp), %rax
	movq	%rax, -144(%rbp)
	.loc 1 76 80
	movb	$1, -136(%rbp)
	.loc 1 75 17 discriminator 1
	movq	-144(%rbp), %rax
	movq	%rax, -108(%rbp)
	movl	-136(%rbp), %eax
	movl	%eax, -100(%rbp)
	jmp	.L112
.L111:
	.loc 1 77 10
	cmpl	$0, -72(%rbp)
	je	.L113
	.loc 1 78 41
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movq	%rax, -152(%rbp)
	.loc 1 78 67
	movl	-72(%rbp), %eax
	movl	%eax, -152(%rbp)
	.loc 1 78 12
	movq	8(%rbx), %rax
	movq	(%rax), %rdx
	movq	%rdx, -176(%rbp)
	movl	8(%rax), %eax
	movl	%eax, -168(%rbp)
	.loc 1 78 30
	movq	-152(%rbp), %rax
	movq	%rax, -176(%rbp)
	.loc 1 78 80
	movb	$2, -168(%rbp)
	.loc 1 75 17 discriminator 2
	movq	-176(%rbp), %rax
	movq	%rax, -108(%rbp)
	movl	-168(%rbp), %eax
	movl	%eax, -100(%rbp)
	jmp	.L112
.L113:
	.loc 1 79 15
	movq	8(%rbx), %rax
	movq	(%rax), %rdx
	movq	%rdx, -192(%rbp)
	movl	8(%rax), %eax
	movl	%eax, -184(%rbp)
	.loc 1 79 33
	movb	$1, -183(%rbp)
	.loc 1 75 17 discriminator 3
	movq	-192(%rbp), %rax
	movq	%rax, -108(%rbp)
	movl	-184(%rbp), %eax
	movl	%eax, -100(%rbp)
.L112:
	.loc 1 75 17 is_stmt 0 discriminator 4
	leaq	-108(%rbp), %rax
	.loc 1 73 10 is_stmt 1 discriminator 2
	movq	(%rax), %rdx
	movq	%rdx, -120(%rbp)
	movl	8(%rax), %eax
	movl	%eax, -112(%rbp)
	.loc 1 73 10 is_stmt 0 discriminator 3
	jmp	.L144
.L110:
	.loc 1 80 27 is_stmt 1
	movq	8(%rbx), %rcx
	movzbl	8(%rcx), %ecx
	.loc 1 80 7
	cmpb	$1, %cl
	je	.L114
	.loc 1 80 39 discriminator 1
	movq	8(%rbx), %rcx
	movzbl	8(%rcx), %ecx
	cmpb	$2, %cl
	jne	.L115
.L114:
	.loc 1 81 51
	leaq	.LC18(%rip), %rsi
	leaq	.LC4(%rip), %rdi
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	movq	(%rbx), %rax
	movq	%rsi, %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$1, %r9d
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_names__take
	.loc 1 81 51 is_stmt 0 discriminator 1
	movl	%eax, -60(%rbp)
	.loc 1 82 51 is_stmt 1
	leaq	.LC19(%rip), %r14
	leaq	.LC5(%rip), %r15
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	movq	(%rbx), %rax
	movq	%r14, %rcx
	movq	%r15, %rdi
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$1, %r9d
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_names__take
	.loc 1 82 51 is_stmt 0 discriminator 1
	movl	%eax, -64(%rbp)
	.loc 1 83 17 is_stmt 1
	cmpl	$0, -60(%rbp)
	jne	.L116
	.loc 1 83 26 discriminator 1
	cmpl	$0, -64(%rbp)
	je	.L117
.L116:
	.loc 1 84 27
	movq	8(%rbx), %rax
	movzbl	8(%rax), %eax
	.loc 1 84 10
	cmpb	$2, %al
	jne	.L118
	.loc 1 84 38 discriminator 1
	cmpl	$0, -60(%rbp)
	je	.L119
	.loc 1 85 21
	movq	8(%rbx), %rax
	movzbl	4(%rax), %eax
	testb	%al, %al
	je	.L120
.L119:
	.loc 1 86 13
	cmpl	$0, -64(%rbp)
	je	.L118
	.loc 1 86 29 discriminator 1
	movq	8(%rbx), %rax
	movzbl	5(%rax), %eax
	testb	%al, %al
	je	.L120
.L118:
	.loc 1 89 23
	cmpl	$0, -60(%rbp)
	je	.L121
	.loc 1 89 23 is_stmt 0 discriminator 1
	movl	-60(%rbp), %eax
	jmp	.L122
.L121:
	.loc 1 89 23 discriminator 2
	movl	-64(%rbp), %eax
.L122:
	.loc 1 83 17 is_stmt 1 discriminator 2
	movl	%eax, -96(%rbp)
	.loc 1 90 46
	movq	8(%rbx), %rax
	movzbl	4(%rax), %eax
	testb	%al, %al
	jne	.L123
	.loc 1 90 46 is_stmt 0 discriminator 1
	cmpl	$0, -60(%rbp)
	je	.L124
	.loc 1 90 82 is_stmt 1 discriminator 2
	movq	8(%rbx), %rax
	movzbl	8(%rax), %eax
	.loc 1 90 62 discriminator 2
	cmpb	$1, %al
	jne	.L124
.L123:
	.loc 1 90 46 discriminator 3
	movl	$1, %eax
	jmp	.L125
.L124:
	.loc 1 90 46 is_stmt 0 discriminator 4
	movl	$0, %eax
.L125:
	.loc 1 83 17 is_stmt 1 discriminator 3
	movb	%al, -92(%rbp)
	.loc 1 91 60
	movq	8(%rbx), %rax
	movzbl	5(%rax), %eax
	testb	%al, %al
	jne	.L126
	.loc 1 91 60 is_stmt 0 discriminator 1
	cmpl	$0, -64(%rbp)
	je	.L127
	.loc 1 91 96 is_stmt 1 discriminator 2
	movq	8(%rbx), %rax
	movzbl	8(%rax), %eax
	.loc 1 91 76 discriminator 2
	cmpb	$1, %al
	jne	.L127
.L126:
	.loc 1 91 60 discriminator 3
	movl	$1, %eax
	jmp	.L128
.L127:
	.loc 1 91 60 is_stmt 0 discriminator 4
	movl	$0, %eax
.L128:
	.loc 1 83 17 is_stmt 1 discriminator 4
	movb	%al, -91(%rbp)
	.loc 1 92 44
	movq	8(%rbx), %rax
	movzbl	6(%rax), %eax
	testb	%al, %al
	jne	.L129
	.loc 1 92 44 is_stmt 0 discriminator 1
	cmpl	$0, -60(%rbp)
	je	.L130
	.loc 1 92 80 is_stmt 1 discriminator 2
	movq	8(%rbx), %rax
	movzbl	8(%rax), %eax
	.loc 1 92 60 discriminator 2
	cmpb	$2, %al
	jne	.L130
.L129:
	.loc 1 92 44 discriminator 3
	movl	$1, %eax
	jmp	.L131
.L130:
	.loc 1 92 44 is_stmt 0 discriminator 4
	movl	$0, %eax
.L131:
	.loc 1 83 17 is_stmt 1 discriminator 5
	movb	%al, -90(%rbp)
	.loc 1 93 58
	movq	8(%rbx), %rax
	movzbl	7(%rax), %eax
	testb	%al, %al
	jne	.L132
	.loc 1 93 58 is_stmt 0 discriminator 1
	cmpl	$0, -64(%rbp)
	je	.L133
	.loc 1 93 94 is_stmt 1 discriminator 2
	movq	8(%rbx), %rax
	movzbl	8(%rax), %eax
	.loc 1 93 74 discriminator 2
	cmpb	$2, %al
	jne	.L133
.L132:
	.loc 1 93 58 discriminator 3
	movl	$1, %eax
	jmp	.L134
.L133:
	.loc 1 93 58 is_stmt 0 discriminator 4
	movl	$0, %eax
.L134:
	.loc 1 83 17 is_stmt 1 discriminator 6
	movb	%al, -89(%rbp)
	.loc 1 94 35
	movq	8(%rbx), %rax
	movzbl	8(%rax), %eax
	.loc 1 94 21
	cmpb	$1, %al
	jne	.L135
	.loc 1 94 21 is_stmt 0 discriminator 1
	movl	$3, %eax
	jmp	.L136
.L135:
	.loc 1 94 21 discriminator 2
	movl	$4, %eax
.L136:
	.loc 1 83 17 is_stmt 1 discriminator 7
	movb	%al, -88(%rbp)
	movb	$0, -87(%rbp)
	.loc 1 83 17 is_stmt 0 discriminator 9
	jmp	.L138
.L120:
	.loc 1 83 17 discriminator 8
	movl	$0, -96(%rbp)
	movb	$0, -92(%rbp)
	movb	$0, -91(%rbp)
	movb	$0, -90(%rbp)
	movb	$0, -89(%rbp)
	movb	$0, -88(%rbp)
	movb	$1, -87(%rbp)
	.loc 1 83 17 discriminator 9
	jmp	.L138
.L117:
	.loc 1 83 17 discriminator 10
	movl	$0, -96(%rbp)
	movb	$0, -92(%rbp)
	movb	$0, -91(%rbp)
	movb	$0, -90(%rbp)
	movb	$0, -89(%rbp)
	movb	$0, -88(%rbp)
	movb	$1, -87(%rbp)
.L138:
	.loc 1 83 17 discriminator 11
	leaq	-96(%rbp), %rax
	.loc 1 81 10 is_stmt 1 discriminator 2
	movq	(%rax), %rdx
	movq	%rdx, -120(%rbp)
	movl	8(%rax), %eax
	movl	%eax, -112(%rbp)
	.loc 1 81 10 is_stmt 0 discriminator 3
	jmp	.L144
.L115:
	.loc 1 97 51 is_stmt 1
	leaq	.LC20(%rip), %rax
	leaq	.LC6(%rip), %rdx
	movq	8(%rbx), %rcx
	movl	(%rcx), %edi
	movq	(%rbx), %rcx
	movq	%rax, %r8
	movq	(%rcx), %rsi
	movq	8(%rcx), %rax
	movl	$0, %r9d
	movq	%r8, %rcx
	movq	%rdx, %r8
	movl	%edi, %edx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_names__take
	.loc 1 97 51 is_stmt 0 discriminator 1
	movl	%eax, -52(%rbp)
	.loc 1 98 51 is_stmt 1
	leaq	.LC21(%rip), %r12
	leaq	.LC6(%rip), %r13
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	movq	(%rbx), %rax
	movq	%r12, %rcx
	movq	%r13, %rdi
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$0, %r9d
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_names__take
	.loc 1 98 51 is_stmt 0 discriminator 1
	movl	%eax, -56(%rbp)
	.loc 1 99 17 is_stmt 1
	cmpl	$0, -52(%rbp)
	je	.L139
	.loc 1 100 41
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movq	%rax, -200(%rbp)
	.loc 1 100 67
	movl	-52(%rbp), %eax
	movl	%eax, -200(%rbp)
	.loc 1 100 12
	movq	8(%rbx), %rax
	movq	(%rax), %rdx
	movq	%rdx, -224(%rbp)
	movl	8(%rax), %eax
	movl	%eax, -216(%rbp)
	.loc 1 100 30
	movq	-200(%rbp), %rax
	movq	%rax, -224(%rbp)
	.loc 1 100 80
	movb	$0, -216(%rbp)
	.loc 1 99 17 discriminator 1
	movq	-224(%rbp), %rax
	movq	%rax, -84(%rbp)
	movl	-216(%rbp), %eax
	movl	%eax, -76(%rbp)
	jmp	.L140
.L139:
	.loc 1 101 10
	cmpl	$0, -56(%rbp)
	je	.L141
	.loc 1 102 41
	movq	8(%rbx), %rax
	movq	(%rax), %rax
	movq	%rax, -232(%rbp)
	.loc 1 102 67
	movl	-56(%rbp), %eax
	movl	%eax, -232(%rbp)
	.loc 1 102 12
	movq	8(%rbx), %rax
	movq	(%rax), %rdx
	movq	%rdx, -256(%rbp)
	movl	8(%rax), %eax
	movl	%eax, -248(%rbp)
	.loc 1 102 30
	movq	-232(%rbp), %rax
	movq	%rax, -256(%rbp)
	.loc 1 103 37
	movq	8(%rbx), %rax
	movzbl	8(%rax), %eax
	.loc 1 103 23
	cmpb	$3, %al
	jne	.L142
	.loc 1 103 23 is_stmt 0 discriminator 1
	movl	$1, %eax
	jmp	.L143
.L142:
	.loc 1 103 23 discriminator 2
	movl	$2, %eax
.L143:
	.loc 1 103 14 is_stmt 1 discriminator 3
	movb	%al, -248(%rbp)
	.loc 1 99 17 discriminator 2
	movq	-256(%rbp), %rax
	movq	%rax, -84(%rbp)
	movl	-248(%rbp), %eax
	movl	%eax, -76(%rbp)
	jmp	.L140
.L141:
	.loc 1 99 17 is_stmt 0 discriminator 3
	movl	$0, -84(%rbp)
	movb	$0, -80(%rbp)
	movb	$0, -79(%rbp)
	movb	$0, -78(%rbp)
	movb	$0, -77(%rbp)
	movb	$0, -76(%rbp)
	movb	$1, -75(%rbp)
.L140:
	.loc 1 99 17 discriminator 4
	leaq	-84(%rbp), %rax
	.loc 1 97 10 is_stmt 1 discriminator 2
	movq	(%rax), %rdx
	movq	%rdx, -120(%rbp)
	movl	8(%rax), %eax
	movl	%eax, -112(%rbp)
.L144:
	.loc 1 69 4
	movq	-120(%rbp), %rax
	movl	-112(%rbp), %ecx
	movq	%rcx, %rdx
	addq	$264, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE9:
	.size	silver_names__context_step___wrapped_statements.1, .-silver_names__context_step___wrapped_statements.1
	.section	.rodata
	.align 8
.LC22:
	.ascii	"failed precondition from silver_names.adb:63"
	.align 8
.LC23:
	.ascii	"failed precondition from silver_names.adb:64"
	.align 8
.LC24:
	.ascii	"failed postcondition from silver_names.adb:65"
	.align 8
.LC25:
	.ascii	"failed postcondition from silver_names.adb:66"
	.text
	.align 2
	.globl	silver_names__context_step
	.type	silver_names__context_step, @function
silver_names__context_step:
.LFB8:
	.loc 1 69 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$168, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -128(%rbp)
	movq	%rdi, -120(%rbp)
	movq	%rdx, %rax
	movq	%rcx, %rdx
	movq	%rax, -144(%rbp)
	movl	-136(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -136(%rbp)
	.loc 1 69 4
	leaq	16(%rbp), %rax
	.loc 1 69 4 is_stmt 0 discriminator 1
	leaq	-128(%rbp), %rdx
	movq	%rax, -80(%rbp)
	leaq	-144(%rbp), %rax
	movq	%rdx, -96(%rbp)
	movq	%rax, -88(%rbp)
	movq	-120(%rbp), %rax
	movl	(%rax), %r8d
	movq	-120(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -164(%rbp)
	movq	-120(%rbp), %rax
	movl	4(%rax), %edx
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L146
	.loc 1 69 4 discriminator 2
	movq	-120(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L147
.L146:
	.loc 1 69 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L147:
.LBB20:
	.loc 1 63 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L148
.LBB21:
	.loc 1 63 15 is_stmt 0 discriminator 1
	leaq	.LC22(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L148:
.LBE21:
	.loc 1 63 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 1 63 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L149
	.loc 1 63 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L150
.L149:
.LBB22:
	.loc 1 63 15 discriminator 4
	leaq	.LC22(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L150:
.LBE22:
	.loc 1 64 39
	movl	-144(%rbp), %eax
	.loc 1 64 52
	cmpl	$2147483647, -164(%rbp)
	jne	.L151
	.loc 1 64 52 is_stmt 0 discriminator 1
	leaq	.LC10(%rip), %rax
	movl	$64, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L151:
	.loc 1 64 52 discriminator 3
	movl	-164(%rbp), %ecx
	leal	1(%rcx), %edx
	.loc 1 63 15 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L152
.LBB23:
	.loc 1 63 15 is_stmt 0 discriminator 6
	leaq	.LC23(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L152:
.LBE23:
.LBB24:
	.loc 1 69 4 is_stmt 1 discriminator 5
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
	call	silver_names__context_step___wrapped_statements.1
	movq	%rax, -112(%rbp)
	movl	-104(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -104(%rbp)
	.loc 1 65 50
	movl	-112(%rbp), %eax
	.loc 1 65 63
	cmpl	$2147483647, -164(%rbp)
	jne	.L153
	.loc 1 65 63 is_stmt 0 discriminator 1
	leaq	.LC10(%rip), %rax
	movl	$65, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L153:
	.loc 1 65 63 discriminator 3
	movl	-164(%rbp), %edx
	addl	$1, %edx
	.loc 1 65 16 is_stmt 1 discriminator 4
	cmpl	%eax, %edx
	jge	.L154
.LBB25:
	.loc 1 65 16 is_stmt 0 discriminator 5
	leaq	.LC24(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L154:
.LBE25:
	.loc 1 66 54 is_stmt 1
	movl	-112(%rbp), %eax
	.loc 1 65 16 discriminator 6
	testl	%eax, %eax
	je	.L155
	.loc 1 67 12
	movzbl	-103(%rbp), %eax
	xorl	$1, %eax
	testb	%al, %al
	je	.L155
	.loc 1 68 54
	movl	-112(%rbp), %edx
	movl	-144(%rbp), %eax
	.loc 1 68 12
	cmpl	%eax, %edx
	jg	.L155
.LBB26:
	.loc 1 65 16 discriminator 7
	leaq	.LC25(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L155:
.LBE26:
	.loc 1 69 4 discriminator 6
	movq	-112(%rbp), %rax
	movq	%rax, -60(%rbp)
	movl	-104(%rbp), %eax
	movl	%eax, -52(%rbp)
	.loc 1 69 4 is_stmt 0 discriminator 8
	movq	-60(%rbp), %rax
	movl	-52(%rbp), %ecx
	movq	%rcx, %rdx
.LBE24:
.LBE20:
	.loc 1 69 4
	addq	$168, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE8:
	.size	silver_names__context_step, .-silver_names__context_step
	.section	.rodata
	.align 8
.LC26:
	.ascii	"Loop_Invariant failed at silver_names.adb:128"
	.align 8
.LC27:
	.ascii	"Loop_Variant failed at silver_names.adb:130"
	.align 8
.LC28:
	.ascii	"Loop_Variant failed at silver_names.adb:131"
	.align 8
.LC7:
	.long	1
	.long	43
	.text
	.align 2
	.type	silver_names__read_context___wrapped_statements.2, @function
silver_names__read_context___wrapped_statements.2:
.LFB11:
	.loc 1 124 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rax
	movq	%rax, -96(%rbp)
	movq	%r10, -72(%rbp)
	.loc 1 124 4
	movl	8(%rax), %eax
	movl	%eax, -84(%rbp)
.LBB27:
	.loc 1 125 7
	movl	$1, -64(%rbp)
	movb	$0, -60(%rbp)
	movb	$0, -59(%rbp)
	movb	$0, -58(%rbp)
	movb	$0, -57(%rbp)
	movb	$0, -56(%rbp)
	movb	$0, -55(%rbp)
	.loc 1 127 66
	movb	$0, -73(%rbp)
.L167:
	.loc 1 127 33 discriminator 1
	movl	-64(%rbp), %eax
	.loc 1 127 38 discriminator 1
	testl	%eax, %eax
	je	.L158
	.loc 1 127 38 is_stmt 0 discriminator 2
	movzbl	-55(%rbp), %eax
	testb	%al, %al
	jne	.L158
	.loc 1 128 53 is_stmt 1
	movl	-64(%rbp), %edx
	.loc 1 128 66
	cmpl	$2147483647, -84(%rbp)
	jne	.L159
	.loc 1 128 66 is_stmt 0 discriminator 1
	leaq	.LC10(%rip), %rax
	movl	$128, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L159:
	.loc 1 128 66 discriminator 3
	movl	-84(%rbp), %eax
	addl	$1, %eax
	.loc 1 128 33 is_stmt 1 discriminator 4
	cmpl	%edx, %eax
	jge	.L160
.LBB28:
	.loc 1 128 33 is_stmt 0 discriminator 5
	leaq	.LC26(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L160:
.LBE28:
	.loc 1 130 10 is_stmt 1
	cmpb	$0, -73(%rbp)
	je	.L161
	.loc 1 131 26
	movq	%r12, -144(%rbp)
	movq	%r13, -136(%rbp)
	.loc 1 130 57 discriminator 1
	movl	-80(%rbp), %eax
	movl	%eax, -88(%rbp)
.L161:
	.loc 1 130 57 is_stmt 0 discriminator 2
	movl	-64(%rbp), %eax
	movl	%eax, -80(%rbp)
	.loc 1 131 26 is_stmt 1 discriminator 1
	movzbl	-55(%rbp), %eax
	testb	%al, %al
	je	.L162
	.loc 1 131 26 is_stmt 0 discriminator 2
	movl	$0, %r12d
	movl	$0, %r13d
	jmp	.L163
.L162:
	.loc 1 131 26 discriminator 3
	movl	$1, %r12d
	movl	$0, %r13d
.L163:
	.loc 1 130 10 is_stmt 1 discriminator 3
	cmpb	$0, -73(%rbp)
	je	.L164
	.loc 1 130 57 discriminator 4
	movl	-80(%rbp), %eax
	movl	-88(%rbp), %ecx
	cmpl	%ecx, %eax
	je	.L165
	.loc 1 130 57 is_stmt 0 discriminator 5
	cmpl	%ecx, %eax
	jg	.L166
.LBB29:
	.loc 1 130 57 discriminator 6
	leaq	.LC27(%rip), %rax
	movq	%rax, -112(%rbp)
	leaq	.LC7(%rip), %rax
	movq	%rax, -104(%rbp)
	movq	-112(%rbp), %rbx
	movq	-104(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L165:
.LBE29:
	.loc 1 131 26 is_stmt 1 discriminator 4
	movq	-144(%rbp), %rax
	movq	-136(%rbp), %rdx
	movq	%rax, %rdi
	cmpq	%rdi, %r12
	movq	%r13, %rbx
	movq	%rdx, %rax
	sbbq	%rax, %rbx
	jl	.L166
.LBB30:
	.loc 1 131 26 is_stmt 0 discriminator 5
	leaq	.LC28(%rip), %r14
	leaq	.LC7(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L164:
.LBE30:
	.loc 1 130 10 is_stmt 1 discriminator 7
	movb	$1, -73(%rbp)
.L166:
	.loc 1 132 19
	movq	-96(%rbp), %rax
	movq	(%rax), %rdx
	movq	-64(%rbp), %rcx
	movl	-56(%rbp), %eax
	movq	%rax, %rbx
	movq	(%rdx), %rsi
	movq	8(%rdx), %rax
	movq	%rcx, %rdx
	movq	%rbx, %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_names__context_step
	movq	%rax, -64(%rbp)
	movl	-56(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -56(%rbp)
	.loc 1 133 15
	jmp	.L167
.L158:
	.loc 1 134 38
	movl	-64(%rbp), %eax
	.loc 1 134 15
	testl	%eax, %eax
	jne	.L168
	.loc 1 134 47 discriminator 1
	movl	$0, %eax
	jmp	.L170
.L168:
	.loc 1 134 73 discriminator 2
	movq	-64(%rbp), %rax
.L170:
.LBE27:
	.loc 1 135 8
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE11:
	.size	silver_names__read_context___wrapped_statements.2, .-silver_names__read_context___wrapped_statements.2
	.section	.rodata
	.align 8
.LC29:
	.ascii	"failed precondition from silver_names.ads:26"
.LC30:
	.ascii	"silver_names.ads"
	.zero	1
	.align 8
.LC31:
	.ascii	"failed postcondition from silver_names.ads:27"
	.text
	.align 2
	.globl	silver_names__read_context
	.type	silver_names__read_context, @function
silver_names__read_context:
.LFB10:
	.loc 1 124 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -96(%rbp)
	movq	%rdx, -88(%rbp)
	.loc 1 124 4
	leaq	16(%rbp), %rdx
	.loc 1 124 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -48(%rbp)
	movq	%rax, -64(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	movq	-88(%rbp), %rdx
	movl	4(%rdx), %edx
	movl	%edx, -56(%rbp)
	movl	-56(%rbp), %edx
	cmpl	%eax, %edx
	jl	.L172
	.loc 1 124 4 discriminator 2
	movl	-56(%rbp), %edx
	movslq	%edx, %rdx
	movq	%rdx, %rcx
	movq	%rdx, %rbx
	sarq	$63, %rbx
	movslq	%eax, %rdx
	movq	%rdx, %rsi
	movq	%rdx, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rcx
	sbbq	%rdi, %rbx
	addq	$1, %rcx
	adcq	$0, %rbx
	jmp	.L173
.L172:
	.loc 1 124 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L173:
.LBB31:
	.loc 1 124 4 discriminator 4
	movl	-56(%rbp), %edx
	cmpl	%eax, %edx
	.loc 1 124 4 discriminator 7
	movl	-56(%rbp), %edx
	cmpl	%eax, %edx
	.loc 1 124 4 discriminator 10
	movl	-56(%rbp), %edx
	cmpl	%eax, %edx
	.file 2 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_names.ads"
	.loc 2 26 15 is_stmt 1
	cmpl	$1, %eax
	je	.L180
.LBB32:
	.loc 2 26 15 is_stmt 0 discriminator 1
	leaq	.LC29(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L180:
.LBE32:
	.loc 2 26 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 26 15 discriminator 2
	testl	%eax, %eax
	jle	.L181
	.loc 2 26 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L182
.L181:
.LBB33:
	.loc 2 26 15 discriminator 4
	leaq	.LC29(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L182:
.LBE33:
.LBB34:
	.loc 1 124 4 discriminator 13
	leaq	-64(%rbp), %rax
	movq	%rax, %r10
	call	silver_names__read_context___wrapped_statements.2
	movq	%rax, -72(%rbp)
	.loc 2 27 54
	movl	-72(%rbp), %eax
	.loc 2 27 67
	movl	-56(%rbp), %edx
	cmpl	$2147483647, %edx
	jne	.L183
	.loc 2 27 67 is_stmt 0 discriminator 1
	leaq	.LC30(%rip), %rax
	movl	$27, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L183:
	.loc 2 27 67 discriminator 3
	movl	-56(%rbp), %edx
	addl	$1, %edx
	.loc 2 27 28 is_stmt 1 discriminator 4
	cmpl	%eax, %edx
	jge	.L184
.LBB35:
	.loc 2 27 28 is_stmt 0 discriminator 5
	leaq	.LC31(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L184:
.LBE35:
	.loc 1 124 4 is_stmt 1 discriminator 14
	movq	-72(%rbp), %rax
.LBE34:
.LBE31:
	.loc 1 124 4 is_stmt 0
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE10:
	.size	silver_names__read_context, .-silver_names__read_context
	.align 2
	.type	silver_names__context_after___wrapped_statements.3, @function
silver_names__context_after___wrapped_statements.3:
.LFB13:
	.loc 1 137 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 3, -24
	movq	%r10, %rbx
	movq	%r10, -40(%rbp)
	.loc 1 138 52
	movq	(%rbx), %rax
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_names__read_context
	movq	%rax, -24(%rbp)
	.loc 1 139 14
	movzbl	-20(%rbp), %eax
	testb	%al, %al
	je	.L187
	.loc 1 139 65 discriminator 1
	movzbl	-19(%rbp), %eax
	.loc 1 139 33 discriminator 1
	movzbl	8(%rbx), %edx
	cmpb	%al, %dl
	jne	.L187
	.loc 1 138 7 discriminator 1
	movl	-24(%rbp), %eax
	jmp	.L188
.L187:
	.loc 1 138 7 is_stmt 0 discriminator 2
	movl	$0, %eax
.L188:
	.loc 1 137 4 is_stmt 1
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE13:
	.size	silver_names__context_after___wrapped_statements.3, .-silver_names__context_after___wrapped_statements.3
	.section	.rodata
	.align 8
.LC32:
	.ascii	"failed precondition from silver_names.ads:32"
	.align 8
.LC33:
	.ascii	"failed postcondition from silver_names.ads:33"
	.text
	.align 2
	.globl	silver_names__context_after
	.type	silver_names__context_after, @function
silver_names__context_after:
.LFB12:
	.loc 1 137 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$64, %rsp
	.cfi_offset 14, -24
	.cfi_offset 13, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r10
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r10, %rdi
	movq	%rsi, -80(%rbp)
	movq	%rdi, -72(%rbp)
	movb	%dl, -81(%rbp)
	.loc 1 137 4
	leaq	16(%rbp), %rdx
	.loc 1 137 4 is_stmt 0 discriminator 1
	leaq	-80(%rbp), %rax
	movq	%rdx, -48(%rbp)
	movq	%rax, -64(%rbp)
	movzbl	-81(%rbp), %eax
	movb	%al, -56(%rbp)
	movq	-72(%rbp), %rax
	movl	(%rax), %r10d
	movq	-72(%rbp), %rax
	movl	4(%rax), %r14d
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L191
	.loc 1 137 4 discriminator 2
	movq	-72(%rbp), %rax
	movl	4(%rax), %esi
	movslq	%esi, %rax
	cqto
	movq	-72(%rbp), %rsi
	movl	(%rsi), %r11d
	movslq	%r11d, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L192
.L191:
	.loc 1 137 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L192:
.LBB36:
	.loc 2 32 15 is_stmt 1
	cmpl	$1, %r10d
	je	.L193
.LBB37:
	.loc 2 32 15 is_stmt 0 discriminator 1
	leaq	.LC32(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L193:
.LBE37:
	.loc 2 32 51 is_stmt 1 discriminator 2
	movl	%eax, %esi
	.loc 2 32 15 discriminator 2
	testl	%esi, %esi
	jle	.L194
	.loc 2 32 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L195
.L194:
.LBB38:
	.loc 2 32 15 discriminator 4
	leaq	.LC32(%rip), %rcx
	leaq	.LC0(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L195:
.LBE38:
.LBB39:
	.loc 1 137 4 discriminator 5
	leaq	-64(%rbp), %rax
	movq	%rax, %r10
	call	silver_names__context_after___wrapped_statements.3
	.loc 2 33 50
	cmpl	$2147483647, %r14d
	jne	.L196
	.loc 2 33 50 is_stmt 0 discriminator 1
	leaq	.LC30(%rip), %rax
	movl	$33, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L196:
	.loc 2 33 50 discriminator 3
	leal	1(%r14), %edx
	.loc 2 33 16 is_stmt 1 discriminator 4
	cmpl	%eax, %edx
	jge	.L198
.LBB40:
	.loc 2 33 16 is_stmt 0 discriminator 5
	leaq	.LC33(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L198:
.LBE40:
.LBE39:
.LBE36:
	.loc 1 137 4 is_stmt 1
	addq	$64, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE12:
	.size	silver_names__context_after, .-silver_names__context_after
	.align 2
	.type	silver_names__operation_name___wrapped_statements.4, @function
silver_names__operation_name___wrapped_statements.4:
.LFB15:
	.loc 1 145 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	subq	$16, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	movq	%r10, %rax
	movq	%r10, -24(%rbp)
	.loc 1 146 12
	movzbl	(%rax), %edx
	cmpb	$4, %dl
	jbe	.L200
	.loc 1 146 12 is_stmt 0 discriminator 1
	leaq	.LC10(%rip), %rax
	movl	$146, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L200:
	.loc 1 146 12 discriminator 2
	movzbl	(%rax), %edx
	cmpb	$4, %dl
	jbe	.L201
	.loc 1 146 12 discriminator 3
	leaq	.LC10(%rip), %rax
	movl	$146, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L201:
	.loc 1 146 7 is_stmt 1 discriminator 4
	movzbl	(%rax), %eax
	cmpb	$3, %al
	je	.L202
	cmpb	$3, %al
	ja	.L203
	cmpb	$2, %al
	je	.L204
	cmpb	$2, %al
	ja	.L203
	testb	%al, %al
	je	.L205
	cmpb	$1, %al
	je	.L206
	jmp	.L203
.L205:
	.loc 1 147 28
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 147 28 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$8, 4(%rax)
	movabsq	$7308895159447745904, %rcx
	movq	%rcx, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L207
.L206:
	.loc 1 148 36 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 148 36 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$30064, 8(%rax)
	movb	$116, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L207
.L204:
	.loc 1 149 30 is_stmt 1
	movl	$4, %esi
	movl	$24, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 149 30 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$16, 4(%rax)
	movabsq	$8245914396496390502, %rsi
	movabsq	$8389209267074589791, %rdi
	movq	%rsi, 8(%rax)
	movq	%rdi, 16(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L207
.L202:
	.loc 1 150 30 is_stmt 1
	movl	$4, %esi
	movl	$24, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 150 30 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$14, 4(%rax)
	movabsq	$8316283140707479145, %rcx
	movq	%rcx, 8(%rax)
	movabsq	$7235433442201006953, %rcx
	movq	%rcx, 14(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L207
.L203:
	.loc 1 151 28 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 151 28 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$6, 4(%rax)
	movl	$1701471602, 8(%rax)
	movw	$29795, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
.L207:
	.loc 1 145 4 is_stmt 1
	movq	%r12, %rax
	movq	%r13, %rdx
	addq	$16, %rsp
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE15:
	.size	silver_names__operation_name___wrapped_statements.4, .-silver_names__operation_name___wrapped_statements.4
	.section	.rodata
	.align 8
.LC34:
	.ascii	"failed postcondition from silver_names.adb:144"
	.align 8
.LC8:
	.long	1
	.long	46
	.text
	.align 2
	.globl	silver_names__operation_name
	.type	silver_names__operation_name, @function
silver_names__operation_name:
.LFB14:
	.loc 1 145 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movb	%dil, -65(%rbp)
	.loc 1 145 4
	leaq	16(%rbp), %rax
	.loc 1 145 4 is_stmt 0 discriminator 1
	movq	%rax, -56(%rbp)
	movzbl	-65(%rbp), %eax
	movb	%al, -64(%rbp)
.LBB41:
	leaq	-64(%rbp), %rax
	movq	%rax, %r10
	call	silver_names__operation_name___wrapped_statements.4
	.loc 1 145 4 discriminator 2
	movq	%rax, %rcx
	movq	%rdx, %rbx
	movq	%rbx, %rax
	movl	(%rax), %eax
	movq	%rbx, %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	.loc 1 145 4 discriminator 5
	cmpl	%eax, %edx
	.loc 1 145 4 discriminator 8
	cmpl	%eax, %edx
	.loc 1 145 4 discriminator 11
	cmpl	%eax, %edx
	jl	.L215
	.loc 1 145 4 discriminator 12
	testl	%eax, %eax
	jg	.L215
	.loc 1 145 4 discriminator 13
	leaq	.LC10(%rip), %rax
	movl	$145, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L215:
	.loc 1 144 16 is_stmt 1
	cmpl	$1, %eax
	je	.L216
.LBB42:
	.loc 1 144 16 is_stmt 0 discriminator 1
	leaq	.LC34(%rip), %r14
	leaq	.LC8(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L216:
.LBE42:
	.loc 1 144 16 discriminator 2
	cmpl	%eax, %edx
	jl	.L217
	.loc 1 144 86 is_stmt 1 discriminator 3
	movl	%edx, %esi
	movl	%eax, %edi
	subl	%edi, %esi
	addl	$1, %esi
	testl	%esi, %esi
	jle	.L217
	.loc 1 144 86 is_stmt 0 discriminator 4
	cmpl	%eax, %edx
	jl	.L218
	.loc 1 144 86 discriminator 5
	movl	%edx, %esi
	movl	%eax, %edx
	movl	%esi, %eax
	subl	%edx, %eax
	addl	$1, %eax
	cmpl	$16, %eax
	jle	.L218
.L217:
.LBB43:
	.loc 1 144 16 is_stmt 1 discriminator 6
	leaq	.LC34(%rip), %r12
	leaq	.LC8(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L218:
.LBE43:
	.loc 1 145 4 discriminator 14
	movq	%rcx, %rax
	movq	%rbx, %rdx
.LBE41:
	.loc 1 145 4 is_stmt 0
	addq	$40, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE14:
	.size	silver_names__operation_name, .-silver_names__operation_name
	.align 2
	.type	silver_names__operation_after___wrapped_statements__B227b___finalizer.6, @function
silver_names__operation_after___wrapped_statements__B227b___finalizer.6:
.LFB18:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE18:
	.size	silver_names__operation_after___wrapped_statements__B227b___finalizer.6, .-silver_names__operation_after___wrapped_statements__B227b___finalizer.6
	.section	.rodata
.LC35:
	.ascii	"."
	.text
	.align 2
	.type	silver_names__operation_after___wrapped_statements.5, @function
silver_names__operation_after___wrapped_statements.5:
.LFB17:
	.loc 1 153 4 is_stmt 1
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA17
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB0:
	subq	$120, %rsp
.LEHE0:
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -136(%rbp)
.LBB44:
	.loc 1 153 4
	leaq	16(%rbp), %rax
	.loc 1 153 4 is_stmt 0 discriminator 1
	movq	%rax, -104(%rbp)
	leaq	-128(%rbp), %rax
	movq	%rax, %rdi
.LEHB1:
	call	system__secondary_stack__ss_mark@PLT
	.loc 1 156 52 is_stmt 1
	movq	(%rbx), %rax
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_names__read_context
	movq	%rax, -72(%rbp)
	.loc 1 158 18
	movzbl	13(%rbx), %eax
	testb	%al, %al
	je	.L223
	.loc 1 158 45 discriminator 1
	movzbl	13(%rbx), %eax
	cmpb	$1, %al
	jne	.L224
.L223:
	.loc 1 157 15
	movzbl	-68(%rbp), %eax
	movb	%al, -49(%rbp)
	jmp	.L225
.L224:
	.loc 1 157 15 is_stmt 0 discriminator 1
	movzbl	-67(%rbp), %eax
	movb	%al, -49(%rbp)
.L225:
	.loc 1 160 18 is_stmt 1
	movzbl	13(%rbx), %eax
	testb	%al, %al
	je	.L226
	.loc 1 160 45 discriminator 1
	movzbl	13(%rbx), %eax
	cmpb	$1, %al
	jne	.L227
.L226:
	.loc 1 159 15
	movzbl	-66(%rbp), %eax
	movb	%al, -50(%rbp)
	jmp	.L228
.L227:
	.loc 1 159 15 is_stmt 0 discriminator 1
	movzbl	-65(%rbp), %eax
	movb	%al, -50(%rbp)
.L228:
	.loc 1 163 20 is_stmt 1
	movzbl	13(%rbx), %eax
	testb	%al, %al
	je	.L229
	.loc 1 163 47 discriminator 1
	movzbl	13(%rbx), %eax
	cmpb	$1, %al
	jne	.L230
.L229:
	.loc 1 163 20 discriminator 2
	movabsq	$7592913276874025331, %rax
	movq	%rax, -96(%rbp)
	movb	$111, -88(%rbp)
	jmp	.L231
.L230:
	.loc 1 163 20 is_stmt 0 discriminator 3
	movabsq	$7016452524570601843, %rax
	movabsq	$8319395793567311730, %rdx
	movq	%rax, -96(%rbp)
	movq	%rdx, -88(%rbp)
.L231:
	.loc 1 163 20 discriminator 4
	movzbl	13(%rbx), %eax
	testb	%al, %al
	je	.L234
	.loc 1 163 47 is_stmt 1 discriminator 5
	movzbl	13(%rbx), %eax
	cmpb	$1, %al
.L234:
	.loc 1 163 20 discriminator 8
	movzbl	13(%rbx), %eax
	testb	%al, %al
	je	.L237
	.loc 1 163 47 discriminator 9
	movzbl	13(%rbx), %eax
	cmpb	$1, %al
.L237:
	.loc 1 163 20 discriminator 12
	movzbl	13(%rbx), %eax
	testb	%al, %al
	je	.L240
	.loc 1 163 47 discriminator 13
	movzbl	13(%rbx), %eax
	cmpb	$1, %al
.L240:
	.loc 1 163 20 discriminator 16
	movzbl	13(%rbx), %eax
	testb	%al, %al
	je	.L262
	.loc 1 163 47 discriminator 17
	movzbl	13(%rbx), %eax
	cmpb	$1, %al
.L262:
	.loc 1 163 20 discriminator 18
	nop
	.loc 1 161 56
	leaq	.LC35(%rip), %r12
	leaq	.LC6(%rip), %r13
	leaq	-96(%rbp), %rax
	movq	%rax, -160(%rbp)
	movl	$1, -64(%rbp)
	.loc 1 163 20 discriminator 20
	movzbl	13(%rbx), %eax
	testb	%al, %al
	je	.L244
	.loc 1 163 47 discriminator 21
	movzbl	13(%rbx), %eax
	cmpb	$1, %al
	jne	.L245
.L244:
	.loc 1 163 20 discriminator 22
	movl	$9, %eax
	jmp	.L246
.L245:
	.loc 1 163 20 is_stmt 0 discriminator 23
	movl	$16, %eax
.L246:
	.loc 1 161 56 is_stmt 1 discriminator 1
	movl	%eax, -60(%rbp)
	leaq	-64(%rbp), %rax
	movq	%rax, -152(%rbp)
	movq	(%rbx), %rax
	movl	8(%rbx), %edx
	movq	-160(%rbp), %rsi
	movq	-152(%rbp), %rdi
	movq	%rsi, %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$1, %r9d
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_names__take
	movl	%eax, %edx
	.loc 1 161 56 is_stmt 0 discriminator 2
	movq	(%rbx), %rax
	movq	%r12, %rcx
	movq	%r13, %rdi
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$0, %r9d
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_names__take
	.loc 1 161 56 discriminator 3
	movl	%eax, -56(%rbp)
	.loc 1 164 31 is_stmt 1
	movl	-72(%rbp), %eax
	.loc 1 164 14
	testl	%eax, %eax
	je	.L247
	.loc 1 164 35 discriminator 1
	cmpb	$0, -49(%rbp)
	je	.L247
	.loc 1 165 9
	cmpl	$0, -56(%rbp)
	je	.L248
	.loc 1 165 58 discriminator 1
	movzbl	13(%rbx), %eax
	movzbl	%al, %eax
	movl	%eax, %edi
	call	silver_names__operation_name
	.loc 1 165 35 discriminator 2
	movq	(%rbx), %rcx
	movq	%rax, %rdi
	movq	%rdx, %r8
	movl	-56(%rbp), %edx
	movq	(%rcx), %rsi
	movq	8(%rcx), %rax
	movl	$1, %r9d
	movq	%rdi, %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_names__take
	movl	%eax, %r14d
	.loc 1 164 14 discriminator 5
	jmp	.L251
.L248:
	.loc 1 166 9
	cmpb	$0, -50(%rbp)
	je	.L250
	.loc 1 166 29 discriminator 1
	movzbl	12(%rbx), %eax
	xorl	$1, %eax
	.loc 1 166 20 discriminator 1
	testb	%al, %al
	je	.L250
	.loc 1 166 67 discriminator 2
	movzbl	13(%rbx), %eax
	movzbl	%al, %eax
	movl	%eax, %edi
	call	silver_names__operation_name
	.loc 1 166 45 discriminator 3
	movq	(%rbx), %rcx
	movl	8(%rbx), %edi
	movq	%rax, %r8
	movq	(%rcx), %rsi
	movq	8(%rcx), %rax
	movl	$1, %r9d
	movq	%r8, %rcx
	movq	%rdx, %r8
	movl	%edi, %edx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_names__take
.LEHE1:
	movl	%eax, %r14d
	.loc 1 164 14 discriminator 3
	nop
	.loc 1 164 14 is_stmt 0 discriminator 5
	jmp	.L251
.L250:
	.loc 1 164 14 discriminator 4
	movl	$0, %r14d
	.loc 1 164 14 discriminator 5
	jmp	.L251
.L247:
	.loc 1 164 14 discriminator 6
	movl	$0, %r14d
.L251:
	.loc 1 156 7 is_stmt 1 discriminator 1
	movl	$0, %ebx
.L256:
	.loc 1 156 0 discriminator 2
	leaq	-128(%rbp), %rax
	movq	%rax, %r10
.LEHB2:
	call	silver_names__operation_after___wrapped_statements__B227b___finalizer.6
.LEHE2:
	.loc 1 156 0 is_stmt 0 discriminator 3
	cmpl	$1, %ebx
	je	.L252
	movl	$0, %eax
.L258:
	.loc 1 156 0 discriminator 4
	cmpl	$1, %eax
	je	.L253
	.loc 1 156 7 is_stmt 1 discriminator 5
	movl	%r14d, %eax
	jmp	.L261
.L259:
	movq	%rax, -144(%rbp)
	movl	$1, %ebx
	.loc 1 156 7 is_stmt 0 discriminator 6
	jmp	.L256
.L252:
	movq	-144(%rbp), %r15
	jmp	.L257
.L260:
	movq	%rax, %r15
.L257:
	movl	$1, %eax
	jmp	.L258
.L253:
	movq	%r15, %rax
	movq	%rax, %rdi
.LEHB3:
	call	_Unwind_Resume@PLT
.L261:
.LBE44:
	.loc 1 153 4 is_stmt 1
	addq	$120, %rsp
.LEHE3:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE17:
	.section	.gcc_except_table,"a",@progbits
.LLSDA17:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE17-.LLSDACSB17
.LLSDACSB17:
	.uleb128 .LEHB0-.LFB17
	.uleb128 .LEHE0-.LEHB0
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB1-.LFB17
	.uleb128 .LEHE1-.LEHB1
	.uleb128 .L259-.LFB17
	.uleb128 0
	.uleb128 .LEHB2-.LFB17
	.uleb128 .LEHE2-.LEHB2
	.uleb128 .L260-.LFB17
	.uleb128 0
	.uleb128 .LEHB3-.LFB17
	.uleb128 .LEHE3-.LEHB3
	.uleb128 0
	.uleb128 0
.LLSDACSE17:
	.text
	.size	silver_names__operation_after___wrapped_statements.5, .-silver_names__operation_after___wrapped_statements.5
	.section	.rodata
	.align 8
.LC36:
	.ascii	"failed precondition from silver_names.ads:41"
	.align 8
.LC37:
	.ascii	"failed precondition from silver_names.ads:42"
	.align 8
.LC38:
	.ascii	"failed postcondition from silver_names.ads:43"
	.text
	.align 2
	.globl	silver_names__operation_after
	.type	silver_names__operation_after, @function
silver_names__operation_after:
.LFB16:
	.loc 1 153 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$88, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r9
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r9, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movl	%edx, -100(%rbp)
	movb	%cl, -101(%rbp)
	movb	%r8b, -102(%rbp)
	.loc 1 153 4
	leaq	16(%rbp), %rdx
	.loc 1 153 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -80(%rbp)
	movl	-100(%rbp), %eax
	movl	%eax, -72(%rbp)
	movzbl	-101(%rbp), %eax
	movb	%al, -67(%rbp)
	movzbl	-102(%rbp), %eax
	movb	%al, -68(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %r8d
	movq	-88(%rbp), %rax
	movl	4(%rax), %ebx
	movq	-88(%rbp), %rax
	movl	4(%rax), %edx
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L264
	.loc 1 153 4 discriminator 2
	movq	-88(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-88(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movq	%rcx, %rsi
	movq	%rcx, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L265
.L264:
	.loc 1 153 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L265:
.LBB45:
	.loc 2 41 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L266
.LBB46:
	.loc 2 41 15 is_stmt 0 discriminator 1
	leaq	.LC36(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L266:
.LBE46:
	.loc 2 41 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 41 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L267
	.loc 2 41 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L268
.L267:
.LBB47:
	.loc 2 41 15 discriminator 4
	leaq	.LC36(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L268:
.LBE47:
	.loc 2 42 41
	cmpl	$2147483647, %ebx
	jne	.L269
	.loc 2 42 41 is_stmt 0 discriminator 1
	leaq	.LC30(%rip), %rax
	movl	$42, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L269:
	.loc 2 42 41 discriminator 3
	leal	1(%rbx), %edx
	.loc 2 41 15 is_stmt 1 discriminator 5
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L270
.LBB48:
	.loc 2 41 15 is_stmt 0 discriminator 6
	leaq	.LC37(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L270:
.LBE48:
.LBB49:
	.loc 1 153 4 is_stmt 1 discriminator 5
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_names__operation_after___wrapped_statements.5
	.loc 2 43 16
	testl	%eax, %eax
	je	.L274
	.loc 2 44 10
	movl	-72(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L272
	.loc 2 44 70 discriminator 1
	cmpl	$2147483647, %ebx
	jne	.L273
	.loc 2 44 70 is_stmt 0 discriminator 2
	leaq	.LC30(%rip), %rax
	movl	$44, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L273:
	.loc 2 44 70 discriminator 4
	leal	1(%rbx), %edx
	.loc 2 44 41 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L274
.L272:
.LBB50:
	.loc 2 43 16 discriminator 1
	leaq	.LC38(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L274:
.LBE50:
.LBE49:
.LBE45:
	.loc 1 153 4
	addq	$88, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE16:
	.size	silver_names__operation_after, .-silver_names__operation_after
	.section	.rodata
.LC39:
	.ascii	"=>"
	.align 8
.LC9:
	.long	1
	.long	2
	.text
	.align 2
	.type	silver_names__association_after___wrapped_statements.7, @function
silver_names__association_after___wrapped_statements.7:
.LFB20:
	.loc 1 169 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%r10, %rbx
	movq	%r10, -72(%rbp)
	.loc 1 173 32
	movzbl	12(%rbx), %ecx
	testb	%cl, %cl
	je	.L276
	.loc 1 173 32 is_stmt 0 discriminator 1
	movl	$1634100580, -56(%rbp)
	movl	$1953264993, -53(%rbp)
	jmp	.L277
.L276:
	.loc 1 173 32 discriminator 2
	movl	$1835365481, -56(%rbp)
.L277:
	.loc 1 173 32 discriminator 3
	movzbl	12(%rbx), %ecx
	testb	%cl, %cl
	.loc 1 173 32 discriminator 6
	movzbl	12(%rbx), %ecx
	testb	%cl, %cl
	.loc 1 173 32 discriminator 9
	movzbl	12(%rbx), %ecx
	testb	%cl, %cl
	.loc 1 173 32 discriminator 12
	movzbl	12(%rbx), %ecx
	testb	%cl, %cl
	.loc 1 172 52 is_stmt 1
	leaq	.LC39(%rip), %r12
	leaq	.LC9(%rip), %r13
	leaq	-56(%rbp), %rcx
	movq	%rcx, %rax
	movl	$1, -44(%rbp)
	.loc 1 173 32 discriminator 15
	movzbl	12(%rbx), %ecx
	testb	%cl, %cl
	je	.L286
	.loc 1 173 32 is_stmt 0 discriminator 16
	movl	$7, %ecx
	jmp	.L287
.L286:
	.loc 1 173 32 discriminator 17
	movl	$4, %ecx
.L287:
	.loc 1 172 52 is_stmt 1 discriminator 1
	movl	%ecx, -40(%rbp)
	leaq	-44(%rbp), %rcx
	movq	%rcx, %rdx
	movq	(%rbx), %rcx
	movl	8(%rbx), %edi
	movq	%rax, %r8
	movq	(%rcx), %rsi
	movq	8(%rcx), %rax
	movl	$1, %r9d
	movq	%r8, %rcx
	movq	%rdx, %r8
	movl	%edi, %edx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_names__take
	movl	%eax, %edx
	.loc 1 172 52 is_stmt 0 discriminator 2
	movq	(%rbx), %rax
	movq	%r12, %rcx
	movq	%r13, %rdi
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$0, %r9d
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_names__take
	.loc 1 172 52 discriminator 3
	movl	%eax, -36(%rbp)
	.loc 1 174 14 is_stmt 1
	cmpl	$0, -36(%rbp)
	je	.L288
	.loc 1 172 7 discriminator 4
	movl	-36(%rbp), %eax
	.loc 1 172 7 is_stmt 0 discriminator 6
	jmp	.L290
.L288:
	.loc 1 172 7 discriminator 5
	movl	8(%rbx), %eax
.L290:
	.loc 1 169 4 is_stmt 1
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE20:
	.size	silver_names__association_after___wrapped_statements.7, .-silver_names__association_after___wrapped_statements.7
	.section	.rodata
	.align 8
.LC40:
	.ascii	"failed precondition from silver_names.ads:53"
	.align 8
.LC41:
	.ascii	"failed precondition from silver_names.ads:54"
	.align 8
.LC42:
	.ascii	"failed postcondition from silver_names.ads:55"
	.text
	.align 2
	.globl	silver_names__association_after
	.type	silver_names__association_after, @function
silver_names__association_after:
.LFB19:
	.loc 1 169 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %rbx
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%rbx, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movl	%edx, -100(%rbp)
	movb	%cl, -101(%rbp)
	.loc 1 169 4
	leaq	16(%rbp), %rdx
	.loc 1 169 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -80(%rbp)
	movl	-100(%rbp), %eax
	movl	%eax, -72(%rbp)
	movzbl	-101(%rbp), %eax
	movb	%al, -68(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -108(%rbp)
	movq	-88(%rbp), %rax
	movl	4(%rax), %ebx
	movq	-88(%rbp), %rax
	movl	4(%rax), %edx
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L292
	.loc 1 169 4 discriminator 2
	movq	-88(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-88(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movq	%rcx, %rsi
	movq	%rcx, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L293
.L292:
	.loc 1 169 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L293:
.LBB51:
	.loc 2 53 15 is_stmt 1
	cmpl	$1, -108(%rbp)
	je	.L294
.LBB52:
	.loc 2 53 15 is_stmt 0 discriminator 1
	leaq	.LC40(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L294:
.LBE52:
	.loc 2 53 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 53 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L295
	.loc 2 53 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L296
.L295:
.LBB53:
	.loc 2 53 15 discriminator 4
	leaq	.LC40(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L296:
.LBE53:
	.loc 2 54 41
	cmpl	$2147483647, %ebx
	jne	.L297
	.loc 2 54 41 is_stmt 0 discriminator 1
	leaq	.LC30(%rip), %rax
	movl	$54, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L297:
	.loc 2 54 41 discriminator 3
	leal	1(%rbx), %edx
	.loc 2 53 15 is_stmt 1 discriminator 5
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L298
.LBB54:
	.loc 2 53 15 is_stmt 0 discriminator 6
	leaq	.LC41(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L298:
.LBE54:
.LBB55:
	.loc 1 169 4 is_stmt 1 discriminator 5
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_names__association_after___wrapped_statements.7
	.loc 2 55 16
	movl	-72(%rbp), %edx
	cmpl	%edx, %eax
	jl	.L299
	.loc 2 55 66 discriminator 1
	cmpl	$2147483647, %ebx
	jne	.L300
	.loc 2 55 66 is_stmt 0 discriminator 2
	leaq	.LC30(%rip), %rax
	movl	$55, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L300:
	.loc 2 55 66 discriminator 4
	leal	1(%rbx), %edx
	.loc 2 55 41 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L302
.L299:
.LBB56:
	.loc 2 55 16 discriminator 6
	leaq	.LC42(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L302:
.LBE56:
.LBE55:
.LBE51:
	.loc 1 169 4
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE19:
	.size	silver_names__association_after, .-silver_names__association_after
	.globl	silver_names_E
	.data
	.align 2
	.type	silver_names_E, @object
	.size	silver_names_E, 2
silver_names_E:
	.zero	2
	.globl	silver_names__invalid_context
	.section	.rodata
	.align 8
	.type	silver_names__invalid_context, @object
	.size	silver_names__invalid_context, 8
silver_names__invalid_context:
	.zero	8
	.globl	silver_names__operation_kindS
	.align 32
	.type	silver_names__operation_kindS, @object
	.size	silver_names__operation_kindS, 67
silver_names__operation_kindS:
	.ascii	"OUTPUT_CALLPARTIAL_OUTPUT_CALLARGUMENT_CALLVALIDITY_CALLREJE"
	.ascii	"CT_CALL"
	.globl	silver_names__operation_kindN
	.align 8
	.type	silver_names__operation_kindN, @object
	.size	silver_names__operation_kindN, 8
silver_names__operation_kindN:
	.byte	1
	.byte	12
	.byte	31
	.byte	44
	.byte	57
	.byte	68
	.zero	2
	.globl	silver_names__context_modeS
	.align 32
	.type	silver_names__context_modeS, @object
	.size	silver_names__context_modeS, 56
silver_names__context_modeS:
	.ascii	"CLAUSE_STARTWITH_NAMEUSE_NAMEWITH_SEPARATORUSE_SEPARATOR"
	.globl	silver_names__context_modeN
	.align 8
	.type	silver_names__context_modeN, @object
	.size	silver_names__context_modeN, 8
silver_names__context_modeN:
	.byte	1
	.byte	13
	.byte	22
	.byte	30
	.byte	44
	.byte	57
	.zero	2
	.globl	silver_names__initial_state
	.align 16
	.type	silver_names__initial_state, @object
	.size	silver_names__initial_state, 16
silver_names__initial_state:
	.long	1
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.zero	2
	.zero	4
	.globl	silver_names__invalid_state
	.align 16
	.type	silver_names__invalid_state, @object
	.size	silver_names__invalid_state, 16
silver_names__invalid_state:
	.long	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	1
	.zero	2
	.zero	4
	.align 4
	.type	operation_kindP.15, @object
	.size	operation_kindP.15, 4
operation_kindP.15:
	.long	1
	.type	operation_kindT1.14, @object
	.size	operation_kindT1.14, 1
operation_kindT1.14:
	.byte	3
	.type	operation_kindT2.13, @object
	.size	operation_kindT2.13, 1
operation_kindT2.13:
	.byte	9
	.align 16
	.type	operation_kindG.12, @object
	.size	operation_kindG.12, 16
operation_kindG.12:
	.byte	0
	.byte	1
	.byte	0
	.byte	0
	.byte	3
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.byte	1
	.byte	0
	.zero	5
	.align 4
	.type	context_modeP.11, @object
	.size	context_modeP.11, 4
context_modeP.11:
	.long	7
	.type	context_modeT1.10, @object
	.size	context_modeT1.10, 1
context_modeT1.10:
	.byte	16
	.type	context_modeT2.9, @object
	.size	context_modeT2.9, 1
context_modeT2.9:
	.byte	1
	.align 16
	.type	context_modeG.8, @object
	.size	context_modeG.8, 17
context_modeG.8:
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.byte	0
	.byte	0
	.byte	4
	.byte	0
	.byte	1
	.byte	0
	.byte	3
	.text
.Letext0:
	.file 3 "<built-in>"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x769
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x19
	.long	.LASF75
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.long	.LLRL0
	.quad	0
	.long	.Ldebug_line0
	.uleb128 0x1a
	.sleb128 0
	.sleb128 4097
	.long	.LASF76
	.long	0x3b
	.uleb128 0xb
	.long	0x2a
	.uleb128 0xc
	.byte	0x4
	.byte	0x5
	.long	.LASF7
	.uleb128 0xf
	.long	.LASF21
	.byte	0x8
	.byte	0x2
	.byte	0xc
	.long	0x90
	.uleb128 0x5
	.long	.LASF2
	.byte	0x2
	.byte	0xd
	.byte	0x7
	.long	0x2a
	.byte	0
	.uleb128 0x5
	.long	.LASF3
	.byte	0x2
	.byte	0xe
	.byte	0x7
	.long	0x95
	.byte	0x4
	.uleb128 0x5
	.long	.LASF4
	.byte	0x2
	.byte	0xe
	.byte	0x10
	.long	0x95
	.byte	0x5
	.uleb128 0x5
	.long	.LASF5
	.byte	0x2
	.byte	0xe
	.byte	0x20
	.long	0x95
	.byte	0x6
	.uleb128 0x5
	.long	.LASF6
	.byte	0x2
	.byte	0xe
	.byte	0x28
	.long	0x95
	.byte	0x7
	.byte	0
	.uleb128 0xb
	.long	0x42
	.uleb128 0xc
	.byte	0x1
	.byte	0x2
	.long	.LASF8
	.uleb128 0xb
	.long	0x95
	.uleb128 0x10
	.long	.LASF14
	.byte	0x2
	.byte	0x8
	.long	0xcb
	.uleb128 0x3
	.long	.LASF9
	.byte	0
	.uleb128 0x3
	.long	.LASF10
	.byte	0x1
	.uleb128 0x3
	.long	.LASF11
	.byte	0x2
	.uleb128 0x3
	.long	.LASF12
	.byte	0x3
	.uleb128 0x3
	.long	.LASF13
	.byte	0x4
	.byte	0
	.uleb128 0xb
	.long	0xa1
	.uleb128 0x10
	.long	.LASF15
	.byte	0x1
	.byte	0x31
	.long	0xfa
	.uleb128 0x3
	.long	.LASF16
	.byte	0
	.uleb128 0x3
	.long	.LASF17
	.byte	0x1
	.uleb128 0x3
	.long	.LASF18
	.byte	0x2
	.uleb128 0x3
	.long	.LASF19
	.byte	0x3
	.uleb128 0x3
	.long	.LASF20
	.byte	0x4
	.byte	0
	.uleb128 0xf
	.long	.LASF22
	.byte	0xc
	.byte	0x1
	.byte	0x33
	.long	0x12e
	.uleb128 0x5
	.long	.LASF23
	.byte	0x1
	.byte	0x34
	.byte	0x7
	.long	0x42
	.byte	0
	.uleb128 0x5
	.long	.LASF24
	.byte	0x1
	.byte	0x35
	.byte	0x7
	.long	0xd0
	.byte	0x8
	.uleb128 0x5
	.long	.LASF25
	.byte	0x1
	.byte	0x36
	.byte	0x7
	.long	0x95
	.byte	0x9
	.byte	0
	.uleb128 0xb
	.long	0xfa
	.uleb128 0x11
	.sleb128 4097
	.long	.LASF42
	.long	0x3b
	.uleb128 0xc
	.byte	0x8
	.byte	0x7
	.long	.LASF26
	.uleb128 0x12
	.long	.LASF27
	.uleb128 0x12
	.long	.LASF28
	.uleb128 0xc
	.byte	0x1
	.byte	0x7
	.long	.LASF29
	.uleb128 0xd
	.long	.LASF30
	.byte	0x2
	.byte	0x10
	.long	0x90
	.uleb128 0x9
	.byte	0x3
	.quad	silver_names__invalid_context
	.uleb128 0xd
	.long	.LASF31
	.byte	0x1
	.byte	0x38
	.long	0x12e
	.uleb128 0x9
	.byte	0x3
	.quad	silver_names__initial_state
	.uleb128 0xd
	.long	.LASF32
	.byte	0x1
	.byte	0x3a
	.long	0x12e
	.uleb128 0x9
	.byte	0x3
	.quad	silver_names__invalid_state
	.uleb128 0x13
	.long	.LASF33
	.byte	0x1
	.uleb128 0x14
	.byte	0x5
	.long	0x195
	.uleb128 0x13
	.long	.LASF34
	.byte	0x2
	.uleb128 0x14
	.byte	0x6
	.long	0x1a1
	.uleb128 0x7
	.long	.LASF44
	.byte	0xa9
	.long	0x2a
	.quad	.LFB19
	.quad	.LFE19-.LFB19
	.uleb128 0x1
	.byte	0x9c
	.long	0x263
	.uleb128 0x1
	.long	.LASF35
	.byte	0x2
	.byte	0x32
	.byte	0x7
	.long	0x2c4
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF36
	.byte	0x2
	.byte	0x32
	.byte	0x16
	.long	0x36
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF37
	.byte	0x2
	.byte	0x32
	.byte	0x33
	.long	0x9c
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0xc
	.uleb128 0x2
	.quad	.LBB51
	.quad	.LBE51-.LBB51
	.uleb128 0x8
	.long	.LASF48
	.long	0x2a
	.quad	.LFB20
	.quad	.LFE20-.LFB20
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0xe
	.long	0x2e8
	.long	0x245
	.uleb128 0x15
	.long	0x3b
	.sleb128 7
	.byte	0
	.uleb128 0x9
	.long	.LASF53
	.long	0x235
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x4
	.long	.LASF50
	.byte	0xac
	.byte	0xf
	.long	0x2a
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x1b
	.long	.LASF38
	.byte	0x10
	.byte	0x3
	.byte	0
	.long	0x2a6
	.uleb128 0x16
	.long	.LASF39
	.long	0x279
	.byte	0
	.uleb128 0x17
	.long	0x2c9
	.uleb128 0x1c
	.byte	0x8
	.byte	0x3
	.byte	0
	.long	0x29b
	.uleb128 0x18
	.string	"LB0"
	.long	0x2ef
	.byte	0
	.uleb128 0x18
	.string	"UB0"
	.long	0x2ef
	.byte	0x4
	.byte	0
	.uleb128 0x16
	.long	.LASF40
	.long	0x2fd
	.byte	0x8
	.byte	0
	.uleb128 0x6
	.long	0x263
	.uleb128 0x6
	.long	0x263
	.uleb128 0x6
	.long	0x263
	.uleb128 0x6
	.long	0x263
	.uleb128 0x6
	.long	0x263
	.uleb128 0x6
	.long	0x263
	.uleb128 0x6
	.long	0x263
	.uleb128 0xe
	.long	0x2e8
	.long	0x2e8
	.uleb128 0x1d
	.long	0x3b
	.uleb128 0x6
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x94
	.byte	0x4
	.uleb128 0x8
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x23
	.uleb128 0x4
	.byte	0x94
	.byte	0x4
	.byte	0
	.uleb128 0xc
	.byte	0x1
	.byte	0x8
	.long	.LASF41
	.uleb128 0x11
	.sleb128 2147483647
	.long	.LASF43
	.long	0x3b
	.uleb128 0x17
	.long	0x27e
	.uleb128 0x7
	.long	.LASF45
	.byte	0x99
	.long	0x2a
	.quad	.LFB16
	.quad	.LFE16-.LFB16
	.uleb128 0x1
	.byte	0x9c
	.long	0x40a
	.uleb128 0x1
	.long	.LASF35
	.byte	0x2
	.byte	0x26
	.byte	0x7
	.long	0x2bf
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF36
	.byte	0x2
	.byte	0x26
	.byte	0x16
	.long	0x36
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF46
	.byte	0x2
	.byte	0x26
	.byte	0x33
	.long	0xcb
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0xd
	.uleb128 0x1
	.long	.LASF47
	.byte	0x2
	.byte	0x27
	.byte	0x7
	.long	0x9c
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0xc
	.uleb128 0x2
	.quad	.LBB45
	.quad	.LBE45-.LBB45
	.uleb128 0x8
	.long	.LASF49
	.long	0x2a
	.quad	.LFB17
	.quad	.LFE17-.LFB17
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -152
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0x2
	.quad	.LBB44
	.quad	.LBE44-.LBB44
	.uleb128 0x4
	.long	.LASF23
	.byte	0x9c
	.byte	0xf
	.long	0x42
	.uleb128 0x3
	.byte	0x91
	.sleb128 -88
	.uleb128 0x4
	.long	.LASF51
	.byte	0x9d
	.byte	0xf
	.long	0x95
	.uleb128 0x3
	.byte	0x91
	.sleb128 -65
	.uleb128 0x4
	.long	.LASF52
	.byte	0x9f
	.byte	0xf
	.long	0x95
	.uleb128 0x3
	.byte	0x91
	.sleb128 -66
	.uleb128 0xe
	.long	0x2e8
	.long	0x3ea
	.uleb128 0x15
	.long	0x3b
	.sleb128 16
	.byte	0
	.uleb128 0x9
	.long	.LASF54
	.long	0x3da
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x4
	.long	.LASF55
	.byte	0xa1
	.byte	0xf
	.long	0x2a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x7
	.long	.LASF56
	.byte	0x91
	.long	0x263
	.quad	.LFB14
	.quad	.LFE14-.LFB14
	.uleb128 0x1
	.byte	0x9c
	.long	0x45d
	.uleb128 0x1
	.long	.LASF46
	.byte	0x1
	.byte	0x8e
	.byte	0x1d
	.long	0xcb
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x1e
	.long	.LASF77
	.long	0x263
	.quad	.LFB15
	.quad	.LFE15-.LFB15
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -40
	.byte	0x6
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0
	.uleb128 0x7
	.long	.LASF57
	.byte	0x89
	.long	0x2a
	.quad	.LFB12
	.quad	.LFE12-.LFB12
	.uleb128 0x1
	.byte	0x9c
	.long	0x4e3
	.uleb128 0x1
	.long	.LASF35
	.byte	0x2
	.byte	0x1e
	.byte	0x1c
	.long	0x2ba
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF58
	.byte	0x2
	.byte	0x1e
	.byte	0x2b
	.long	0x9c
	.uleb128 0x5
	.byte	0x91
	.sleb128 -80
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x2
	.quad	.LBB36
	.quad	.LBE36-.LBB36
	.uleb128 0x8
	.long	.LASF59
	.long	0x2a
	.quad	.LFB13
	.quad	.LFE13-.LFB13
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -56
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0x4
	.long	.LASF23
	.byte	0x8a
	.byte	0xf
	.long	0x42
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x7
	.long	.LASF60
	.byte	0x7c
	.long	0x42
	.quad	.LFB10
	.quad	.LFE10-.LFB10
	.uleb128 0x1
	.byte	0x9c
	.long	0x56b
	.uleb128 0x1
	.long	.LASF35
	.byte	0x2
	.byte	0x18
	.byte	0x1b
	.long	0x2b5
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x2
	.quad	.LBB31
	.quad	.LBE31-.LBB31
	.uleb128 0x8
	.long	.LASF61
	.long	0x42
	.quad	.LFB11
	.quad	.LFE11-.LFB11
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0x2
	.quad	.LBB27
	.quad	.LBE27-.LBB27
	.uleb128 0x4
	.long	.LASF62
	.byte	0x7d
	.byte	0x7
	.long	0xfa
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x7
	.long	.LASF63
	.byte	0x45
	.long	0xfa
	.quad	.LFB8
	.quad	.LFE8-.LFB8
	.uleb128 0x1
	.byte	0x9c
	.long	0x62a
	.uleb128 0x1
	.long	.LASF35
	.byte	0x1
	.byte	0x3d
	.byte	0x1b
	.long	0x2b0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x1
	.long	.LASF62
	.byte	0x1
	.byte	0x3d
	.byte	0x2a
	.long	0x12e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0x2
	.quad	.LBB20
	.quad	.LBE20-.LBB20
	.uleb128 0x8
	.long	.LASF64
	.long	0xfa
	.quad	.LFB9
	.quad	.LFE9-.LFB9
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -280
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0xa
	.string	"w"
	.byte	0x49
	.long	0x2a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -84
	.uleb128 0xa
	.string	"u"
	.byte	0x4a
	.long	0x2a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -88
	.uleb128 0xa
	.string	"i"
	.byte	0x51
	.long	0x2a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0xa
	.string	"a"
	.byte	0x52
	.long	0x2a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0xa
	.string	"s"
	.byte	0x61
	.long	0x2a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0xa
	.string	"c"
	.byte	0x62
	.long	0x2a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x1f
	.long	.LASF78
	.byte	0x1
	.byte	0x1c
	.byte	0x4
	.long	0x2a
	.quad	.LFB4
	.quad	.LFE4-.LFB4
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x1
	.long	.LASF35
	.byte	0x1
	.byte	0x13
	.byte	0x7
	.long	0x2ab
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x1
	.long	.LASF36
	.byte	0x1
	.byte	0x13
	.byte	0x16
	.long	0x36
	.uleb128 0x5
	.byte	0x91
	.sleb128 -128
	.byte	0x23
	.uleb128 0x20
	.uleb128 0x1
	.long	.LASF65
	.byte	0x1
	.byte	0x13
	.byte	0x33
	.long	0x2a6
	.uleb128 0x3
	.byte	0x91
	.sleb128 -176
	.uleb128 0x1
	.long	.LASF66
	.byte	0x1
	.byte	0x13
	.byte	0x42
	.long	0x9c
	.uleb128 0x5
	.byte	0x91
	.sleb128 -128
	.byte	0x23
	.uleb128 0x34
	.uleb128 0x2
	.quad	.LBB10
	.quad	.LBE10-.LBB10
	.uleb128 0x8
	.long	.LASF67
	.long	0x2a
	.quad	.LFB5
	.quad	.LFE5-.LFB5
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -104
	.byte	0x6
	.byte	0x23
	.uleb128 0x38
	.byte	0x6
	.uleb128 0x2
	.quad	.LBB4
	.quad	.LBE4-.LBB4
	.uleb128 0x4
	.long	.LASF68
	.byte	0x1f
	.byte	0x7
	.long	0x133
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x9
	.long	.LASF69
	.long	0x3b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x9
	.long	.LASF70
	.long	0x3b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -84
	.uleb128 0x2
	.quad	.LBB5
	.quad	.LBE5-.LBB5
	.uleb128 0x4
	.long	.LASF71
	.byte	0x25
	.byte	0xb
	.long	0x3b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x2
	.quad	.LBB6
	.quad	.LBE6-.LBB6
	.uleb128 0x9
	.long	.LASF72
	.long	0x3b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -88
	.uleb128 0x9
	.long	.LASF73
	.long	0x3b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -92
	.uleb128 0x2
	.quad	.LBB7
	.quad	.LBE7-.LBB7
	.uleb128 0x4
	.long	.LASF74
	.byte	0x27
	.byte	0x15
	.long	0x3b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x28
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x1c
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 18
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3e
	.uleb128 0x21
	.sleb128 7
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x3e
	.uleb128 0x21
	.sleb128 5
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0x1e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 6
	.byte	0
	.byte	0
	.uleb128 0x14
	.uleb128 0x3a
	.byte	0
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x18
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x15
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0x16
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x17
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x18
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x19
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x55
	.uleb128 0x17
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x1a
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0xd
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1b
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1c
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1d
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x18
	.uleb128 0x2f
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x1e
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x1f
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x4c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.LFE4-.Ltext0
	.quad	.LFB9
	.quad	.LFE14-.LFB9
	.quad	.LFB17
	.quad	.Letext0-.LFB17
	.quad	0
	.quad	0
	.section	.debug_rnglists,"",@progbits
.Ldebug_ranges0:
	.long	.Ldebug_ranges3-.Ldebug_ranges2
.Ldebug_ranges2:
	.value	0x5
	.byte	0x8
	.byte	0
	.long	0
.LLRL0:
	.byte	0x7
	.quad	.Ltext0
	.uleb128 .LFE4-.Ltext0
	.byte	0x7
	.quad	.LFB9
	.uleb128 .LFE14-.LFB9
	.byte	0x7
	.quad	.LFB17
	.uleb128 .Letext0-.LFB17
	.byte	0
.Ldebug_ranges3:
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF65:
	.string	"word"
.LASF39:
	.string	"P_ARRAY"
.LASF35:
	.string	"text"
.LASF63:
	.string	"silver_names__context_step"
.LASF7:
	.string	"integer"
.LASF62:
	.string	"state"
.LASF71:
	.string	"index"
.LASF53:
	.string	"C249b"
.LASF69:
	.string	"silver_names__take___wrapped_statements__L_1__T11b___L"
.LASF20:
	.string	"silver_names__use_separator"
.LASF14:
	.string	"silver_names__operation_kind"
.LASF70:
	.string	"silver_names__take___wrapped_statements__L_1__T11b___U"
.LASF56:
	.string	"silver_names__operation_name"
.LASF31:
	.string	"silver_names__initial_state"
.LASF24:
	.string	"mode"
.LASF12:
	.string	"silver_names__validity_call"
.LASF76:
	.string	"silver_output_lexical__literal_position"
.LASF13:
	.string	"silver_names__reject_call"
.LASF29:
	.string	"system__storage_elements__storage_element"
.LASF49:
	.string	"silver_names__operation_after___wrapped_statements"
.LASF5:
	.string	"io_use"
.LASF59:
	.string	"silver_names__context_after___wrapped_statements"
.LASF18:
	.string	"silver_names__use_name"
.LASF26:
	.string	"system__address"
.LASF78:
	.string	"silver_names__take"
.LASF51:
	.string	"visible"
.LASF16:
	.string	"silver_names__clause_start"
.LASF74:
	.string	"previous"
.LASF30:
	.string	"silver_names__invalid_context"
.LASF34:
	.string	"silver_output_lexical"
.LASF27:
	.string	"system__storage_elements__Tstorage_offsetB"
.LASF38:
	.string	"string"
.LASF64:
	.string	"silver_names__context_step___wrapped_statements"
.LASF22:
	.string	"silver_names__context_state"
.LASF28:
	.string	"system__parameters__Tsize_typeB"
.LASF23:
	.string	"context"
.LASF41:
	.string	"character"
.LASF54:
	.string	"C219b"
.LASF40:
	.string	"P_BOUNDS"
.LASF44:
	.string	"silver_names__association_after"
.LASF2:
	.string	"after"
.LASF50:
	.string	"named"
.LASF68:
	.string	"next"
.LASF52:
	.string	"used"
.LASF61:
	.string	"silver_names__read_context___wrapped_statements"
.LASF66:
	.string	"is_word"
.LASF3:
	.string	"io_with"
.LASF19:
	.string	"silver_names__with_separator"
.LASF46:
	.string	"operation"
.LASF25:
	.string	"complete"
.LASF60:
	.string	"silver_names__read_context"
.LASF10:
	.string	"silver_names__partial_output_call"
.LASF75:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF11:
	.string	"silver_names__argument_call"
.LASF48:
	.string	"silver_names__association_after___wrapped_statements"
.LASF77:
	.string	"silver_names__operation_name___wrapped_statements"
.LASF42:
	.string	"silver_output_lexical__cursor"
.LASF43:
	.string	"positive"
.LASF37:
	.string	"default"
.LASF15:
	.string	"silver_names__context_mode"
.LASF47:
	.string	"hidden"
.LASF32:
	.string	"silver_names__invalid_state"
.LASF9:
	.string	"silver_names__output_call"
.LASF45:
	.string	"silver_names__operation_after"
.LASF4:
	.string	"arguments_with"
.LASF21:
	.string	"silver_names__context_result"
.LASF55:
	.string	"qualified"
.LASF33:
	.string	"silver_profile"
.LASF36:
	.string	"position"
.LASF72:
	.string	"___ghost_silver_names__take___wrapped_statements__L_1__B17b__L18b__T19b___L"
.LASF17:
	.string	"silver_names__with_name"
.LASF57:
	.string	"silver_names__context_after"
.LASF67:
	.string	"silver_names__take___wrapped_statements"
.LASF58:
	.string	"arguments"
.LASF8:
	.string	"boolean"
.LASF6:
	.string	"arguments_use"
.LASF73:
	.string	"___ghost_silver_names__take___wrapped_statements__L_1__B17b__L18b__T19b___U"
	.section	.debug_line_str,"MS",@progbits,1
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_names.adb"
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
	.hidden	DW.ref.__gnat_personality_v0
	.weak	DW.ref.__gnat_personality_v0
	.section	.data.rel.local.DW.ref.__gnat_personality_v0,"awG",@progbits,DW.ref.__gnat_personality_v0,comdat
	.align 8
	.type	DW.ref.__gnat_personality_v0, @object
	.size	DW.ref.__gnat_personality_v0, 8
DW.ref.__gnat_personality_v0:
	.quad	__gnat_personality_v0
	.globl	__gnat_personality_v0
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
