	.file	"silver_scalars.ads"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_scalars.ads"
	.align 2
	.globl	silver_scalars__intervalIP
	.type	silver_scalars__intervalIP, @function
silver_scalars__intervalIP:
.LFB1:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1:
	.size	silver_scalars__intervalIP, .-silver_scalars__intervalIP
	.align 2
	.globl	silver_scalars__comparisonH
	.type	silver_scalars__comparisonH, @function
silver_scalars__comparisonH:
.LFB2:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	movq	-8(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L3
	movl	%edx, %ecx
	subl	%eax, %ecx
	leal	1(%rcx), %r11d
	jmp	.L4
.L3:
	movl	$0, %r11d
.L4:
	movslq	%eax, %r9
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	leal	-1(%rax), %r10d
	movl	$0, %esi
	movl	$0, %ecx
	movl	$0, %edx
.L12:
	cmpl	$1, %edx
	jg	.L11
	movslq	%edx, %rax
	leaq	0(,%rax,4), %rdi
	leaq	comparisonP.3(%rip), %rax
	movl	(%rdi,%rax), %eax
	cmpl	%eax, %r11d
	jl	.L11
	movq	-16(%rbp), %rax
	movslq	%edx, %rdi
	leaq	0(,%rdi,4), %r8
	leaq	comparisonP.3(%rip), %rdi
	movl	(%r8,%rdi), %edi
	addl	%r10d, %edi
	movslq	%edi, %rdi
	subq	%r9, %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %r8d
	movslq	%edx, %rax
	leaq	comparisonT1.2(%rip), %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %eax
	imull	%r8d, %eax
	leal	(%rsi,%rax), %edi
	movslq	%edi, %rax
	imulq	$1321528399, %rax, %rax
	shrq	$32, %rax
	movl	%eax, %esi
	sarl	$2, %esi
	movl	%edi, %eax
	sarl	$31, %eax
	subl	%eax, %esi
	movl	%esi, %eax
	addl	%eax, %eax
	addl	%esi, %eax
	sall	$2, %eax
	addl	%esi, %eax
	movl	%edi, %esi
	subl	%eax, %esi
	movslq	%edx, %rax
	leaq	comparisonT2.1(%rip), %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %eax
	imull	%r8d, %eax
	leal	(%rcx,%rax), %edi
	movslq	%edi, %rax
	imulq	$1321528399, %rax, %rax
	shrq	$32, %rax
	movl	%eax, %ecx
	sarl	$2, %ecx
	movl	%edi, %eax
	sarl	$31, %eax
	subl	%eax, %ecx
	movl	%ecx, %eax
	addl	%eax, %eax
	addl	%ecx, %eax
	sall	$2, %eax
	addl	%ecx, %eax
	movl	%edi, %ecx
	subl	%eax, %ecx
	addl	$1, %edx
	jmp	.L12
.L11:
	movslq	%esi, %rax
	leaq	comparisonG.0(%rip), %rdx
	movzbl	(%rax,%rdx), %eax
	movzbl	%al, %edx
	movslq	%ecx, %rax
	leaq	comparisonG.0(%rip), %rcx
	movzbl	(%rax,%rcx), %eax
	movzbl	%al, %eax
	leal	(%rdx,%rax), %ecx
	movslq	%ecx, %rax
	imulq	$715827883, %rax, %rax
	shrq	$32, %rax
	movq	%rax, %rdx
	movl	%ecx, %eax
	sarl	$31, %eax
	subl	%eax, %edx
	movl	%edx, %eax
	addl	%eax, %eax
	addl	%edx, %eax
	addl	%eax, %eax
	movl	%ecx, %edx
	subl	%eax, %edx
	movl	%edx, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	silver_scalars__comparisonH, .-silver_scalars__comparisonH
	.align 2
	.globl	silver_scalars__check_resultIP
	.type	silver_scalars__check_resultIP, @function
silver_scalars__check_resultIP:
.LFB3:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	.cfi_offset 3, -24
	movq	%rcx, %rax
	movq	%rbx, %rdx
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.size	silver_scalars__check_resultIP, .-silver_scalars__check_resultIP
	.align 2
	.globl	silver_scalars__is_empty
	.type	silver_scalars__is_empty, @function
silver_scalars__is_empty:
.LFB4:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_scalars.ads"
	.loc 1 14 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	.loc 1 15 20
	movl	-8(%rbp), %edx
	movl	-4(%rbp), %eax
	cmpl	%eax, %edx
	setg	%al
	.loc 1 14 4
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	silver_scalars__is_empty, .-silver_scalars__is_empty
	.align 2
	.globl	silver_scalars__contains
	.type	silver_scalars__contains, @function
silver_scalars__contains:
.LFB5:
	.loc 1 16 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movl	%esi, -12(%rbp)
	.loc 1 17 12
	movl	-8(%rbp), %eax
	.loc 1 17 28
	cmpl	%eax, -12(%rbp)
	jl	.L18
	.loc 1 17 42 discriminator 1
	movl	-4(%rbp), %eax
	.loc 1 17 28 discriminator 1
	cmpl	%eax, -12(%rbp)
	jg	.L18
	.loc 1 17 28 is_stmt 0 discriminator 2
	movl	$1, %eax
	jmp	.L19
.L18:
	.loc 1 17 28 discriminator 3
	movl	$0, %eax
.L19:
	.loc 1 16 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE5:
	.size	silver_scalars__contains, .-silver_scalars__contains
	.align 2
	.globl	silver_scalars__singleton
	.type	silver_scalars__singleton, @function
silver_scalars__singleton:
.LFB6:
	.loc 1 18 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movl	%edi, -4(%rbp)
	.loc 1 18 58
	movl	-4(%rbp), %eax
	movabsq	$-4294967296, %rcx
	andq	%rcx, %rdx
	orq	%rdx, %rax
	movq	%rax, %rdx
	movl	-4(%rbp), %eax
	salq	$32, %rax
	movl	%edx, %edx
	orq	%rdx, %rax
	movq	%rax, %rdx
	.loc 1 18 58 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	.loc 1 18 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE6:
	.size	silver_scalars__singleton, .-silver_scalars__singleton
	.align 2
	.globl	silver_scalars__normalize
	.type	silver_scalars__normalize, @function
silver_scalars__normalize:
.LFB7:
	.loc 1 19 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	.loc 1 20 10
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty
	.loc 1 20 7 discriminator 1
	testb	%al, %al
	je	.L24
	.loc 1 20 33 discriminator 2
	movl	$0, %eax
	movabsq	$-4294967296, %rdx
	andq	%rdx, %rax
	orq	$1, %rax
	jmp	.L25
.L24:
	.loc 1 20 44 discriminator 3
	movq	-8(%rbp), %rax
.L25:
	.loc 1 19 4
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE7:
	.size	silver_scalars__normalize, .-silver_scalars__normalize
	.align 2
	.globl	silver_scalars__join
	.type	silver_scalars__join, @function
silver_scalars__join:
.LFB8:
	.loc 1 21 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -24(%rbp)
	movq	%rsi, -32(%rbp)
	.loc 1 22 10
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty
	.loc 1 22 7 discriminator 1
	testb	%al, %al
	je	.L27
	.loc 1 22 31 discriminator 2
	movq	-32(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__normalize
	movq	%rax, %rbx
	.loc 1 22 31 is_stmt 0 discriminator 3
	jmp	.L28
.L27:
	.loc 1 23 13 is_stmt 1
	movq	-32(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty
	.loc 1 23 7 discriminator 1
	testb	%al, %al
	je	.L29
	.loc 1 23 35 discriminator 2
	movq	-24(%rbp), %rbx
	jmp	.L28
.L29:
	.loc 1 24 18
	movl	-24(%rbp), %edx
	movl	-32(%rbp), %eax
	cmpl	%eax, %edx
	cmovle	%edx, %eax
	.loc 1 24 12
	movl	%eax, %edx
	movabsq	$-4294967296, %rax
	andq	%rbx, %rax
	orq	%rdx, %rax
	movq	%rax, %rbx
	.loc 1 25 18
	movl	-20(%rbp), %edx
	movl	-28(%rbp), %eax
	cmpl	%eax, %edx
	cmovge	%edx, %eax
	.loc 1 24 12
	movl	%eax, %eax
	salq	$32, %rax
	movl	%ebx, %edx
	orq	%rdx, %rax
	movq	%rax, %rbx
.L28:
	.loc 1 21 4
	movq	%rbx, %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE8:
	.size	silver_scalars__join, .-silver_scalars__join
	.align 2
	.globl	silver_scalars__intersect
	.type	silver_scalars__intersect, @function
silver_scalars__intersect:
.LFB9:
	.loc 1 26 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	.loc 1 27 24
	movl	-8(%rbp), %ecx
	movl	-16(%rbp), %eax
	cmpl	%eax, %ecx
	cmovge	%ecx, %eax
	.loc 1 27 7
	movl	%eax, %ecx
	movabsq	$-4294967296, %rax
	andq	%rdx, %rax
	orq	%rcx, %rax
	movq	%rax, %rdx
	.loc 1 28 24
	movl	-4(%rbp), %ecx
	movl	-12(%rbp), %eax
	cmpl	%eax, %ecx
	cmovle	%ecx, %eax
	.loc 1 27 7
	movl	%eax, %eax
	salq	$32, %rax
	movl	%edx, %edx
	orq	%rdx, %rax
	movq	%rax, %rdx
	movq	%rdx, %rdi
	call	silver_scalars__normalize
	.loc 1 26 4
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE9:
	.size	silver_scalars__intersect, .-silver_scalars__intersect
	.section	.rodata
.LC0:
	.ascii	"silver_scalars.ads"
	.zero	1
	.text
	.align 2
	.globl	silver_scalars__compare
	.type	silver_scalars__compare, @function
silver_scalars__compare:
.LFB10:
	.loc 1 31 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movb	%dil, -1(%rbp)
	movl	%esi, -8(%rbp)
	movl	%edx, -12(%rbp)
	.loc 1 32 12
	cmpb	$5, -1(%rbp)
	jbe	.L33
	.loc 1 32 12 is_stmt 0 discriminator 1
	leaq	.LC0(%rip), %rax
	movl	$32, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L33:
	.loc 1 32 12 discriminator 2
	cmpb	$5, -1(%rbp)
	jbe	.L34
	.loc 1 32 12 discriminator 3
	leaq	.LC0(%rip), %rax
	movl	$32, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L34:
	.loc 1 32 7 is_stmt 1 discriminator 4
	cmpb	$4, -1(%rbp)
	je	.L35
	cmpb	$4, -1(%rbp)
	ja	.L36
	cmpb	$3, -1(%rbp)
	je	.L37
	cmpb	$3, -1(%rbp)
	ja	.L36
	cmpb	$2, -1(%rbp)
	je	.L38
	cmpb	$2, -1(%rbp)
	ja	.L36
	cmpb	$0, -1(%rbp)
	je	.L39
	cmpb	$1, -1(%rbp)
	je	.L40
	jmp	.L36
.L39:
	.loc 1 33 28
	movl	-8(%rbp), %eax
	cmpl	-12(%rbp), %eax
	sete	%al
	jmp	.L41
.L40:
	.loc 1 34 30
	movl	-8(%rbp), %eax
	cmpl	-12(%rbp), %eax
	setne	%al
	jmp	.L41
.L38:
	.loc 1 35 27
	movl	-8(%rbp), %eax
	cmpl	-12(%rbp), %eax
	setl	%al
	jmp	.L41
.L37:
	.loc 1 36 33
	movl	-8(%rbp), %eax
	cmpl	-12(%rbp), %eax
	setle	%al
	jmp	.L41
.L35:
	.loc 1 37 30
	movl	-8(%rbp), %eax
	cmpl	-12(%rbp), %eax
	setg	%al
	jmp	.L41
.L36:
	.loc 1 38 36
	movl	-8(%rbp), %eax
	cmpl	-12(%rbp), %eax
	setge	%al
.L41:
	.loc 1 31 4
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE10:
	.size	silver_scalars__compare, .-silver_scalars__compare
	.align 2
	.globl	silver_scalars__complement
	.type	silver_scalars__complement, @function
silver_scalars__complement:
.LFB11:
	.loc 1 39 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movb	%dil, -1(%rbp)
	.loc 1 40 12
	cmpb	$5, -1(%rbp)
	jbe	.L43
	.loc 1 40 12 is_stmt 0 discriminator 1
	leaq	.LC0(%rip), %rax
	movl	$40, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L43:
	.loc 1 40 12 discriminator 2
	cmpb	$5, -1(%rbp)
	jbe	.L44
	.loc 1 40 12 discriminator 3
	leaq	.LC0(%rip), %rax
	movl	$40, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L44:
	.loc 1 40 7 is_stmt 1 discriminator 4
	cmpb	$4, -1(%rbp)
	je	.L45
	cmpb	$4, -1(%rbp)
	ja	.L46
	cmpb	$3, -1(%rbp)
	je	.L47
	cmpb	$3, -1(%rbp)
	ja	.L46
	cmpb	$2, -1(%rbp)
	je	.L48
	cmpb	$2, -1(%rbp)
	ja	.L46
	cmpb	$0, -1(%rbp)
	je	.L49
	cmpb	$1, -1(%rbp)
	je	.L50
	jmp	.L46
.L49:
	.loc 1 41 23
	movl	$1, %eax
	jmp	.L51
.L50:
	.loc 1 41 48 discriminator 1
	movl	$0, %eax
	jmp	.L51
.L48:
	.loc 1 42 22
	movl	$5, %eax
	jmp	.L51
.L47:
	.loc 1 42 56 discriminator 1
	movl	$4, %eax
	jmp	.L51
.L45:
	.loc 1 43 25
	movl	$3, %eax
	jmp	.L51
.L46:
	.loc 1 43 59 discriminator 1
	movl	$2, %eax
.L51:
	.loc 1 39 4
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE11:
	.size	silver_scalars__complement, .-silver_scalars__complement
	.align 2
	.globl	silver_scalars__swap
	.type	silver_scalars__swap, @function
silver_scalars__swap:
.LFB12:
	.loc 1 44 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movb	%dil, -1(%rbp)
	.loc 1 45 12
	cmpb	$5, -1(%rbp)
	jbe	.L53
	.loc 1 45 12 is_stmt 0 discriminator 1
	leaq	.LC0(%rip), %rax
	movl	$45, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L53:
	.loc 1 45 12 discriminator 2
	cmpb	$5, -1(%rbp)
	jbe	.L54
	.loc 1 45 12 discriminator 3
	leaq	.LC0(%rip), %rax
	movl	$45, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L54:
	.loc 1 45 7 is_stmt 1 discriminator 4
	cmpb	$4, -1(%rbp)
	je	.L55
	cmpb	$4, -1(%rbp)
	ja	.L56
	cmpb	$3, -1(%rbp)
	je	.L57
	cmpb	$3, -1(%rbp)
	ja	.L56
	cmpb	$2, -1(%rbp)
	je	.L58
	cmpb	$2, -1(%rbp)
	ja	.L56
	cmpb	$0, -1(%rbp)
	je	.L59
	cmpb	$1, -1(%rbp)
	je	.L60
	jmp	.L56
.L59:
	.loc 1 46 23
	movl	$0, %eax
	jmp	.L61
.L60:
	.loc 1 46 46 discriminator 1
	movl	$1, %eax
	jmp	.L61
.L58:
	.loc 1 47 22
	movl	$4, %eax
	jmp	.L61
.L57:
	.loc 1 47 50 discriminator 1
	movl	$5, %eax
	jmp	.L61
.L55:
	.loc 1 48 25
	movl	$2, %eax
	jmp	.L61
.L56:
	.loc 1 48 53 discriminator 1
	movl	$3, %eax
.L61:
	.loc 1 44 4
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE12:
	.size	silver_scalars__swap, .-silver_scalars__swap
	.align 2
	.globl	silver_scalars__below
	.type	silver_scalars__below, @function
silver_scalars__below:
.LFB13:
	.loc 1 49 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movl	%esi, -12(%rbp)
	.loc 1 50 7
	cmpl	$-2147483648, -12(%rbp)
	jne	.L63
	.loc 1 50 39 discriminator 1
	movl	$0, %eax
	movabsq	$-4294967296, %rdx
	andq	%rdx, %rax
	orq	$1, %rax
	jmp	.L64
.L63:
	.loc 1 51 12
	movabsq	$-4294967296, %rdx
	andq	%rax, %rdx
	movl	$2147483648, %eax
	orq	%rdx, %rax
	.loc 1 51 55
	cmpl	$-2147483648, -12(%rbp)
	jne	.L65
	.loc 1 51 55 is_stmt 0 discriminator 1
	leaq	.LC0(%rip), %rax
	movl	$51, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L65:
	.loc 1 51 55 discriminator 3
	movl	-12(%rbp), %edx
	subl	$1, %edx
	.loc 1 51 12 is_stmt 1 discriminator 4
	movl	%edx, %edx
	salq	$32, %rdx
	movl	%eax, %eax
	orq	%rdx, %rax
	movq	-8(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	silver_scalars__intersect
.L64:
	.loc 1 49 4
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE13:
	.size	silver_scalars__below, .-silver_scalars__below
	.align 2
	.globl	silver_scalars__above
	.type	silver_scalars__above, @function
silver_scalars__above:
.LFB14:
	.loc 1 52 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movl	%esi, -12(%rbp)
	.loc 1 53 7
	cmpl	$2147483647, -12(%rbp)
	jne	.L67
	.loc 1 53 38 discriminator 1
	movl	$0, %eax
	movabsq	$-4294967296, %rdx
	andq	%rdx, %rax
	orq	$1, %rax
	jmp	.L68
.L67:
	.loc 1 54 42
	cmpl	$2147483647, -12(%rbp)
	jne	.L69
	.loc 1 54 42 is_stmt 0 discriminator 1
	leaq	.LC0(%rip), %rax
	movl	$54, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L69:
	.loc 1 54 42 discriminator 3
	movl	-12(%rbp), %edx
	addl	$1, %edx
	.loc 1 54 12 is_stmt 1 discriminator 4
	movl	%edx, %edx
	movabsq	$-4294967296, %rcx
	andq	%rcx, %rax
	orq	%rdx, %rax
	movl	%eax, %edx
	movabsq	$9223372032559808512, %rax
	orq	%rdx, %rax
	movq	-8(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	silver_scalars__intersect
.L68:
	.loc 1 52 4
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE14:
	.size	silver_scalars__above, .-silver_scalars__above
	.align 2
	.globl	silver_scalars__refine_true
	.type	silver_scalars__refine_true, @function
silver_scalars__refine_true:
.LFB15:
	.loc 1 55 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -24(%rbp)
	movb	%sil, -25(%rbp)
	movl	%edx, -32(%rbp)
	.loc 1 58 12
	cmpb	$5, -25(%rbp)
	jbe	.L71
	.loc 1 58 12 is_stmt 0 discriminator 1
	leaq	.LC0(%rip), %rax
	movl	$58, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L71:
	.loc 1 58 12 discriminator 2
	cmpb	$5, -25(%rbp)
	jbe	.L72
	.loc 1 58 12 discriminator 3
	leaq	.LC0(%rip), %rax
	movl	$58, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L72:
	.loc 1 58 7 is_stmt 1 discriminator 4
	cmpb	$4, -25(%rbp)
	je	.L73
	cmpb	$4, -25(%rbp)
	ja	.L74
	cmpb	$3, -25(%rbp)
	je	.L75
	cmpb	$3, -25(%rbp)
	ja	.L74
	cmpb	$2, -25(%rbp)
	je	.L76
	cmpb	$2, -25(%rbp)
	ja	.L74
	cmpb	$0, -25(%rbp)
	je	.L77
	cmpb	$1, -25(%rbp)
	je	.L78
	jmp	.L74
.L77:
	.loc 1 59 42
	movl	-32(%rbp), %eax
	movl	%eax, %edi
	call	silver_scalars__singleton
	movq	%rax, %rdx
	.loc 1 59 23 discriminator 1
	movq	-24(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__intersect
	.loc 1 59 23 is_stmt 0 discriminator 2
	jmp	.L80
.L78:
	.loc 1 60 58 is_stmt 1
	movl	-32(%rbp), %edx
	movq	-24(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_scalars__above
	movq	%rax, %rbx
	.loc 1 60 31 discriminator 1
	movl	-32(%rbp), %edx
	movq	-24(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_scalars__below
	.loc 1 60 25 discriminator 2
	movq	%rbx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__join
	.loc 1 60 25 is_stmt 0 discriminator 3
	jmp	.L80
.L76:
	.loc 1 61 22 is_stmt 1
	movl	-32(%rbp), %edx
	movq	-24(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_scalars__below
	.loc 1 61 22 is_stmt 0 discriminator 1
	jmp	.L80
.L75:
	.loc 1 62 28 is_stmt 1
	movabsq	$-4294967296, %rax
	andq	%rax, %rcx
	movq	%rcx, %rdx
	movl	$2147483648, %eax
	orq	%rdx, %rax
	movq	%rax, %rcx
	movl	-32(%rbp), %eax
	salq	$32, %rax
	movl	%ecx, %edx
	orq	%rdx, %rax
	movq	%rax, %rcx
	movq	-24(%rbp), %rax
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__intersect
	.loc 1 62 28 is_stmt 0 discriminator 1
	jmp	.L80
.L73:
	.loc 1 63 25 is_stmt 1
	movl	-32(%rbp), %edx
	movq	-24(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_scalars__above
	.loc 1 63 25 is_stmt 0 discriminator 1
	jmp	.L80
.L74:
	.loc 1 64 31 is_stmt 1
	movl	-32(%rbp), %edx
	movabsq	$-4294967296, %rcx
	andq	%rcx, %rax
	orq	%rdx, %rax
	movl	%eax, %edx
	movabsq	$9223372032559808512, %rax
	orq	%rdx, %rax
	movq	-24(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	silver_scalars__intersect
.L80:
	.loc 1 55 4
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE15:
	.size	silver_scalars__refine_true, .-silver_scalars__refine_true
	.align 2
	.globl	silver_scalars__refine
	.type	silver_scalars__refine, @function
silver_scalars__refine:
.LFB16:
	.loc 1 65 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movb	%sil, -9(%rbp)
	movl	%edx, -16(%rbp)
	movb	%cl, -10(%rbp)
	.loc 1 68 7
	cmpb	$0, -10(%rbp)
	je	.L82
	.loc 1 68 7 is_stmt 0 discriminator 1
	movzbl	-9(%rbp), %eax
	jmp	.L83
.L82:
	.loc 1 69 47 is_stmt 1
	movzbl	-9(%rbp), %eax
	movl	%eax, %edi
	call	silver_scalars__complement
.L83:
	.loc 1 68 7 discriminator 3
	movl	-16(%rbp), %edx
	movzbl	%al, %ecx
	movq	-8(%rbp), %rax
	movl	%ecx, %esi
	movq	%rax, %rdi
	call	silver_scalars__refine_true
	.loc 1 65 4
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE16:
	.size	silver_scalars__refine, .-silver_scalars__refine
	.align 2
	.globl	silver_scalars__in_range
	.type	silver_scalars__in_range, @function
silver_scalars__in_range:
.LFB17:
	.loc 1 77 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	.loc 1 78 23
	cmpq	$-2147483648, -8(%rbp)
	jl	.L86
	.loc 1 78 23 is_stmt 0 discriminator 1
	cmpq	$2147483647, -8(%rbp)
	jg	.L86
	.loc 1 78 23 discriminator 2
	movl	$1, %eax
	jmp	.L87
.L86:
	.loc 1 78 23 discriminator 3
	movl	$0, %eax
.L87:
	.loc 1 77 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE17:
	.size	silver_scalars__in_range, .-silver_scalars__in_range
	.align 2
	.globl	silver_scalars__checked
	.type	silver_scalars__checked, @function
silver_scalars__checked:
.LFB18:
	.loc 1 82 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$48, %rsp
	movq	%rdi, -24(%rbp)
	movq	%rsi, -32(%rbp)
	.loc 1 83 7
	movq	-24(%rbp), %rax
	cmpq	-32(%rbp), %rax
	jle	.L90
	.loc 1 83 29 discriminator 1
	movq	silver_scalars__unreachable(%rip), %rax
	movq	%rax, -12(%rbp)
	movl	8+silver_scalars__unreachable(%rip), %eax
	movl	%eax, -4(%rbp)
	jmp	.L91
.L90:
	.loc 1 84 13
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__in_range
	.loc 1 84 7 discriminator 1
	testb	%al, %al
	je	.L92
	.loc 1 84 39 discriminator 2
	movq	-32(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__in_range
	.loc 1 84 30 discriminator 3
	testb	%al, %al
	je	.L92
	.loc 1 85 27
	cmpq	$-2147483648, -24(%rbp)
	jl	.L93
	.loc 1 85 27 is_stmt 0 discriminator 1
	cmpq	$2147483647, -24(%rbp)
	jle	.L94
.L93:
	.loc 1 85 27 discriminator 2
	leaq	.LC0(%rip), %rax
	movl	$85, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L94:
	.loc 1 85 42 is_stmt 1 discriminator 3
	cmpq	$-2147483648, -32(%rbp)
	jl	.L95
	.loc 1 85 42 is_stmt 0 discriminator 4
	cmpq	$2147483647, -32(%rbp)
	jle	.L96
.L95:
	.loc 1 85 42 discriminator 5
	leaq	.LC0(%rip), %rax
	movl	$85, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L96:
	.loc 1 85 12 is_stmt 1 discriminator 6
	movb	$1, -12(%rbp)
	movq	-24(%rbp), %rax
	movl	%eax, -8(%rbp)
	movq	-32(%rbp), %rax
	movl	%eax, -4(%rbp)
	jmp	.L91
.L92:
	.loc 1 85 56 discriminator 7
	movq	silver_scalars__invalid(%rip), %rax
	movq	%rax, -12(%rbp)
	movl	8+silver_scalars__invalid(%rip), %eax
	movl	%eax, -4(%rbp)
.L91:
	.loc 1 82 4
	movq	-12(%rbp), %rax
	movl	-4(%rbp), %ecx
	movq	%rcx, %rdx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE18:
	.size	silver_scalars__checked, .-silver_scalars__checked
	.align 2
	.globl	silver_scalars__add
	.type	silver_scalars__add, @function
silver_scalars__add:
.LFB19:
	.loc 1 86 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$48, %rsp
	movq	%rdi, -24(%rbp)
	movq	%rsi, -32(%rbp)
	.loc 1 87 10
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty
	.loc 1 87 7 discriminator 1
	testb	%al, %al
	jne	.L98
	.loc 1 87 34 discriminator 2
	movq	-32(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty
	.loc 1 87 26 discriminator 3
	testb	%al, %al
	je	.L99
.L98:
	.loc 1 87 56 discriminator 4
	movq	silver_scalars__unreachable(%rip), %rax
	movq	%rax, -12(%rbp)
	movl	8+silver_scalars__unreachable(%rip), %eax
	movl	%eax, -4(%rbp)
	jmp	.L100
.L99:
	.loc 1 88 12
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movl	-28(%rbp), %eax
	cltq
	.loc 1 89 39
	addq	%rax, %rdx
	.loc 1 88 12
	movl	-24(%rbp), %eax
	movslq	%eax, %rcx
	movl	-32(%rbp), %eax
	cltq
	.loc 1 88 39
	addq	%rcx, %rax
	.loc 1 88 12
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__checked
	movq	%rax, -12(%rbp)
	movl	-4(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -4(%rbp)
.L100:
	.loc 1 86 4
	movq	-12(%rbp), %rax
	movl	-4(%rbp), %ecx
	movq	%rcx, %rdx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE19:
	.size	silver_scalars__add, .-silver_scalars__add
	.align 2
	.globl	silver_scalars__subtract
	.type	silver_scalars__subtract, @function
silver_scalars__subtract:
.LFB20:
	.loc 1 90 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$48, %rsp
	movq	%rdi, -24(%rbp)
	movq	%rsi, -32(%rbp)
	.loc 1 91 10
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty
	.loc 1 91 7 discriminator 1
	testb	%al, %al
	jne	.L102
	.loc 1 91 34 discriminator 2
	movq	-32(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty
	.loc 1 91 26 discriminator 3
	testb	%al, %al
	je	.L103
.L102:
	.loc 1 91 56 discriminator 4
	movq	silver_scalars__unreachable(%rip), %rax
	movq	%rax, -12(%rbp)
	movl	8+silver_scalars__unreachable(%rip), %eax
	movl	%eax, -4(%rbp)
	jmp	.L104
.L103:
	.loc 1 92 12
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movl	-32(%rbp), %eax
	cltq
	.loc 1 93 39
	subq	%rax, %rdx
	.loc 1 92 12
	movl	-24(%rbp), %eax
	cltq
	movl	-28(%rbp), %ecx
	movslq	%ecx, %rcx
	.loc 1 92 39
	subq	%rcx, %rax
	.loc 1 92 12
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__checked
	movq	%rax, -12(%rbp)
	movl	-4(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -4(%rbp)
.L104:
	.loc 1 90 4
	movq	-12(%rbp), %rax
	movl	-4(%rbp), %ecx
	movq	%rcx, %rdx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE20:
	.size	silver_scalars__subtract, .-silver_scalars__subtract
	.align 2
	.globl	silver_scalars__negate
	.type	silver_scalars__negate, @function
silver_scalars__negate:
.LFB21:
	.loc 1 94 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$48, %rsp
	movq	%rdi, -24(%rbp)
	.loc 1 95 10
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty
	.loc 1 95 7 discriminator 1
	testb	%al, %al
	je	.L106
	.loc 1 95 34 discriminator 2
	movq	silver_scalars__unreachable(%rip), %rax
	movq	%rax, -12(%rbp)
	movl	8+silver_scalars__unreachable(%rip), %eax
	movl	%eax, -4(%rbp)
	jmp	.L107
.L106:
	.loc 1 96 44
	movl	-24(%rbp), %eax
	cltq
	.loc 1 96 12
	negq	%rax
	movq	%rax, %rdx
	.loc 1 96 21
	movl	-20(%rbp), %eax
	cltq
	.loc 1 96 12
	negq	%rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__checked
	movq	%rax, -12(%rbp)
	movl	-4(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -4(%rbp)
.L107:
	.loc 1 94 4
	movq	-12(%rbp), %rax
	movl	-4(%rbp), %ecx
	movq	%rcx, %rdx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE21:
	.size	silver_scalars__negate, .-silver_scalars__negate
	.align 2
	.globl	silver_scalars__product_minimum
	.type	silver_scalars__product_minimum, @function
silver_scalars__product_minimum:
.LFB22:
	.loc 1 97 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	.loc 1 98 45
	movl	-8(%rbp), %eax
	movslq	%eax, %rdx
	movl	-16(%rbp), %eax
	cltq
	imulq	%rax, %rdx
	.loc 1 99 44
	movl	-8(%rbp), %eax
	movslq	%eax, %rcx
	movl	-12(%rbp), %eax
	cltq
	imulq	%rcx, %rax
	.loc 1 98 21
	cmpq	%rax, %rdx
	cmovg	%rax, %rdx
	.loc 1 100 45
	movl	-4(%rbp), %eax
	movslq	%eax, %rcx
	movl	-16(%rbp), %eax
	cltq
	imulq	%rax, %rcx
	.loc 1 101 44
	movl	-4(%rbp), %eax
	movslq	%eax, %rsi
	movl	-12(%rbp), %eax
	cltq
	imulq	%rsi, %rax
	.loc 1 100 21
	cmpq	%rax, %rcx
	cmovle	%rcx, %rax
	.loc 1 98 11
	cmpq	%rax, %rdx
	cmovle	%rdx, %rax
	.loc 1 97 4
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE22:
	.size	silver_scalars__product_minimum, .-silver_scalars__product_minimum
	.align 2
	.globl	silver_scalars__product_maximum
	.type	silver_scalars__product_maximum, @function
silver_scalars__product_maximum:
.LFB23:
	.loc 1 102 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	.loc 1 103 45
	movl	-8(%rbp), %eax
	movslq	%eax, %rdx
	movl	-16(%rbp), %eax
	cltq
	imulq	%rax, %rdx
	.loc 1 104 44
	movl	-8(%rbp), %eax
	movslq	%eax, %rcx
	movl	-12(%rbp), %eax
	cltq
	imulq	%rcx, %rax
	.loc 1 103 21
	cmpq	%rax, %rdx
	cmovl	%rax, %rdx
	.loc 1 105 45
	movl	-4(%rbp), %eax
	movslq	%eax, %rcx
	movl	-16(%rbp), %eax
	cltq
	imulq	%rax, %rcx
	.loc 1 106 44
	movl	-4(%rbp), %eax
	movslq	%eax, %rsi
	movl	-12(%rbp), %eax
	cltq
	imulq	%rsi, %rax
	.loc 1 105 21
	cmpq	%rax, %rcx
	cmovge	%rcx, %rax
	.loc 1 103 11
	cmpq	%rax, %rdx
	cmovge	%rdx, %rax
	.loc 1 102 4
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE23:
	.size	silver_scalars__product_maximum, .-silver_scalars__product_maximum
	.align 2
	.globl	silver_scalars__multiply
	.type	silver_scalars__multiply, @function
silver_scalars__multiply:
.LFB24:
	.loc 1 107 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -40(%rbp)
	movq	%rsi, -48(%rbp)
	.loc 1 108 10
	movq	-40(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty
	.loc 1 108 7 discriminator 1
	testb	%al, %al
	jne	.L113
	.loc 1 108 34 discriminator 2
	movq	-48(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty
	.loc 1 108 26 discriminator 3
	testb	%al, %al
	je	.L114
.L113:
	.loc 1 108 56 discriminator 4
	movq	silver_scalars__unreachable(%rip), %rax
	movq	%rax, -28(%rbp)
	movl	8+silver_scalars__unreachable(%rip), %eax
	movl	%eax, -20(%rbp)
	jmp	.L115
.L114:
	.loc 1 109 12
	movq	-48(%rbp), %rdx
	movq	-40(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__product_maximum
	movq	%rax, %rbx
	.loc 1 109 12 is_stmt 0 discriminator 1
	movq	-48(%rbp), %rdx
	movq	-40(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__product_minimum
	.loc 1 109 12 discriminator 2
	movq	%rbx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__checked
	movq	%rax, -28(%rbp)
	movl	-20(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -20(%rbp)
.L115:
	.loc 1 107 4 is_stmt 1
	movq	-28(%rbp), %rax
	movl	-20(%rbp), %ecx
	movq	%rcx, %rdx
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE24:
	.size	silver_scalars__multiply, .-silver_scalars__multiply
	.align 2
	.globl	silver_scalars__quotient_minimum
	.type	silver_scalars__quotient_minimum, @function
silver_scalars__quotient_minimum:
.LFB25:
	.loc 1 110 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	.loc 1 111 22
	movl	-16(%rbp), %eax
	.loc 1 111 7
	testl	%eax, %eax
	je	.L117
	.loc 1 111 46 discriminator 1
	movl	-12(%rbp), %eax
	.loc 1 111 26 discriminator 1
	testl	%eax, %eax
	jne	.L118
.L117:
	.loc 1 111 55 discriminator 2
	movl	$0, %eax
	jmp	.L119
.L118:
	.loc 1 112 50
	movl	-16(%rbp), %eax
	testl	%eax, %eax
	jne	.L120
	.loc 1 112 50 is_stmt 0 discriminator 1
	leaq	.LC0(%rip), %rax
	movl	$112, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Divide_By_Zero@PLT
.L120:
	.loc 1 113 44 is_stmt 1
	movl	-12(%rbp), %eax
	testl	%eax, %eax
	jne	.L121
	.loc 1 113 44 is_stmt 0 discriminator 1
	leaq	.LC0(%rip), %rax
	movl	$113, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Divide_By_Zero@PLT
.L121:
	.loc 1 114 45 is_stmt 1
	movl	-16(%rbp), %eax
	testl	%eax, %eax
	jne	.L122
	.loc 1 114 45 is_stmt 0 discriminator 1
	leaq	.LC0(%rip), %rax
	movl	$114, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Divide_By_Zero@PLT
.L122:
	.loc 1 115 44 is_stmt 1
	movl	-12(%rbp), %eax
	testl	%eax, %eax
	jne	.L123
	.loc 1 115 44 is_stmt 0 discriminator 1
	leaq	.LC0(%rip), %rax
	movl	$115, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Divide_By_Zero@PLT
.L123:
	.loc 1 112 50 is_stmt 1 discriminator 2
	movl	-8(%rbp), %eax
	cltq
	movl	-16(%rbp), %edx
	movslq	%edx, %rdi
	cqto
	idivq	%rdi
	movq	%rax, %rcx
	.loc 1 113 44 discriminator 2
	movl	-8(%rbp), %eax
	cltq
	movl	-12(%rbp), %edx
	movslq	%edx, %rdi
	cqto
	idivq	%rdi
	.loc 1 112 26 discriminator 2
	cmpq	%rax, %rcx
	cmovg	%rax, %rcx
	.loc 1 114 45 discriminator 2
	movl	-4(%rbp), %eax
	cltq
	movl	-16(%rbp), %edx
	movslq	%edx, %rsi
	cqto
	idivq	%rsi
	movq	%rax, %rsi
	.loc 1 115 44 discriminator 2
	movl	-4(%rbp), %eax
	cltq
	movl	-12(%rbp), %edx
	movslq	%edx, %rdi
	cqto
	idivq	%rdi
	.loc 1 114 21 discriminator 2
	cmpq	%rax, %rsi
	cmovle	%rsi, %rax
	.loc 1 112 16 discriminator 2
	cmpq	%rax, %rcx
	cmovle	%rcx, %rax
.L119:
	.loc 1 110 4
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE25:
	.size	silver_scalars__quotient_minimum, .-silver_scalars__quotient_minimum
	.align 2
	.globl	silver_scalars__quotient_maximum
	.type	silver_scalars__quotient_maximum, @function
silver_scalars__quotient_maximum:
.LFB26:
	.loc 1 116 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	.loc 1 117 22
	movl	-16(%rbp), %eax
	.loc 1 117 7
	testl	%eax, %eax
	je	.L125
	.loc 1 117 46 discriminator 1
	movl	-12(%rbp), %eax
	.loc 1 117 26 discriminator 1
	testl	%eax, %eax
	jne	.L126
.L125:
	.loc 1 117 55 discriminator 2
	movl	$0, %eax
	jmp	.L127
.L126:
	.loc 1 118 50
	movl	-16(%rbp), %eax
	testl	%eax, %eax
	jne	.L128
	.loc 1 118 50 is_stmt 0 discriminator 1
	leaq	.LC0(%rip), %rax
	movl	$118, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Divide_By_Zero@PLT
.L128:
	.loc 1 119 44 is_stmt 1
	movl	-12(%rbp), %eax
	testl	%eax, %eax
	jne	.L129
	.loc 1 119 44 is_stmt 0 discriminator 1
	leaq	.LC0(%rip), %rax
	movl	$119, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Divide_By_Zero@PLT
.L129:
	.loc 1 120 45 is_stmt 1
	movl	-16(%rbp), %eax
	testl	%eax, %eax
	jne	.L130
	.loc 1 120 45 is_stmt 0 discriminator 1
	leaq	.LC0(%rip), %rax
	movl	$120, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Divide_By_Zero@PLT
.L130:
	.loc 1 121 44 is_stmt 1
	movl	-12(%rbp), %eax
	testl	%eax, %eax
	jne	.L131
	.loc 1 121 44 is_stmt 0 discriminator 1
	leaq	.LC0(%rip), %rax
	movl	$121, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Divide_By_Zero@PLT
.L131:
	.loc 1 118 50 is_stmt 1 discriminator 2
	movl	-8(%rbp), %eax
	cltq
	movl	-16(%rbp), %edx
	movslq	%edx, %rdi
	cqto
	idivq	%rdi
	movq	%rax, %rcx
	.loc 1 119 44 discriminator 2
	movl	-8(%rbp), %eax
	cltq
	movl	-12(%rbp), %edx
	movslq	%edx, %rdi
	cqto
	idivq	%rdi
	.loc 1 118 26 discriminator 2
	cmpq	%rax, %rcx
	cmovl	%rax, %rcx
	.loc 1 120 45 discriminator 2
	movl	-4(%rbp), %eax
	cltq
	movl	-16(%rbp), %edx
	movslq	%edx, %rsi
	cqto
	idivq	%rsi
	movq	%rax, %rsi
	.loc 1 121 44 discriminator 2
	movl	-4(%rbp), %eax
	cltq
	movl	-12(%rbp), %edx
	movslq	%edx, %rdi
	cqto
	idivq	%rdi
	.loc 1 120 21 discriminator 2
	cmpq	%rax, %rsi
	cmovge	%rsi, %rax
	.loc 1 118 16 discriminator 2
	cmpq	%rax, %rcx
	cmovge	%rcx, %rax
.L127:
	.loc 1 116 4
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE26:
	.size	silver_scalars__quotient_maximum, .-silver_scalars__quotient_maximum
	.align 2
	.globl	silver_scalars__divide
	.type	silver_scalars__divide, @function
silver_scalars__divide:
.LFB27:
	.loc 1 124 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -40(%rbp)
	movq	%rsi, -48(%rbp)
	.loc 1 125 10
	movq	-48(%rbp), %rax
	movl	$0, %esi
	movq	%rax, %rdi
	call	silver_scalars__contains
	.loc 1 125 7 discriminator 1
	testb	%al, %al
	je	.L133
	.loc 1 125 35 discriminator 2
	movq	silver_scalars__invalid(%rip), %rax
	movq	%rax, -28(%rbp)
	movl	8+silver_scalars__invalid(%rip), %eax
	movl	%eax, -20(%rbp)
	jmp	.L134
.L133:
	.loc 1 126 13
	movq	-40(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty
	.loc 1 126 7 discriminator 1
	testb	%al, %al
	jne	.L135
	.loc 1 126 37 discriminator 2
	movq	-48(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty
	.loc 1 126 29 discriminator 3
	testb	%al, %al
	je	.L136
.L135:
	.loc 1 126 59 discriminator 4
	movq	silver_scalars__unreachable(%rip), %rax
	movq	%rax, -28(%rbp)
	movl	8+silver_scalars__unreachable(%rip), %eax
	movl	%eax, -20(%rbp)
	jmp	.L134
.L136:
	.loc 1 127 12
	movq	-48(%rbp), %rdx
	movq	-40(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__quotient_maximum
	movq	%rax, %rbx
	.loc 1 127 12 is_stmt 0 discriminator 1
	movq	-48(%rbp), %rdx
	movq	-40(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__quotient_minimum
	.loc 1 127 12 discriminator 2
	movq	%rbx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__checked
	movq	%rax, -28(%rbp)
	movl	-20(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -20(%rbp)
.L134:
	.loc 1 124 4 is_stmt 1
	movq	-28(%rbp), %rax
	movl	-20(%rbp), %ecx
	movq	%rcx, %rdx
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE27:
	.size	silver_scalars__divide, .-silver_scalars__divide
	.align 2
	.globl	silver_scalars__modulo
	.type	silver_scalars__modulo, @function
silver_scalars__modulo:
.LFB28:
	.loc 1 128 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$48, %rsp
	movq	%rdi, -24(%rbp)
	movq	%rsi, -32(%rbp)
	.loc 1 129 10
	movq	-32(%rbp), %rax
	movl	$0, %esi
	movq	%rax, %rdi
	call	silver_scalars__contains
	.loc 1 129 7 discriminator 1
	testb	%al, %al
	je	.L138
	.loc 1 129 35 discriminator 2
	movq	silver_scalars__invalid(%rip), %rax
	movq	%rax, -12(%rbp)
	movl	8+silver_scalars__invalid(%rip), %eax
	movl	%eax, -4(%rbp)
	jmp	.L139
.L138:
	.loc 1 130 13
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty
	.loc 1 130 7 discriminator 1
	testb	%al, %al
	jne	.L140
	.loc 1 130 37 discriminator 2
	movq	-32(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty
	.loc 1 130 29 discriminator 3
	testb	%al, %al
	je	.L141
.L140:
	.loc 1 130 59 discriminator 4
	movq	silver_scalars__unreachable(%rip), %rax
	movq	%rax, -12(%rbp)
	movl	8+silver_scalars__unreachable(%rip), %eax
	movl	%eax, -4(%rbp)
	jmp	.L139
.L141:
	.loc 1 131 24
	movl	-24(%rbp), %edx
	movl	-20(%rbp), %eax
	.loc 1 131 7
	cmpl	%eax, %edx
	jne	.L142
	.loc 1 131 58 discriminator 1
	movl	-32(%rbp), %edx
	movl	-28(%rbp), %eax
	.loc 1 131 37 discriminator 1
	cmpl	%eax, %edx
	jne	.L142
	.loc 1 132 36
	movl	-32(%rbp), %eax
	testl	%eax, %eax
	jne	.L143
	.loc 1 132 36 is_stmt 0 discriminator 1
	leaq	.LC0(%rip), %rax
	movl	$132, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Divide_By_Zero@PLT
.L143:
	.loc 1 133 36 is_stmt 1
	movl	-32(%rbp), %eax
	testl	%eax, %eax
	jne	.L144
	.loc 1 133 36 is_stmt 0 discriminator 1
	leaq	.LC0(%rip), %rax
	movl	$133, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Divide_By_Zero@PLT
.L144:
	.loc 1 132 9 is_stmt 1 discriminator 2
	movl	-24(%rbp), %eax
	movslq	%eax, %rdi
	movl	-32(%rbp), %eax
	movslq	%eax, %rsi
	.loc 1 133 36 discriminator 2
	movq	%rdi, %rax
	cqto
	idivq	%rsi
	movq	%rdx, %rcx
	testq	%rcx, %rcx
	je	.L145
	movq	%rdi, %rax
	xorq	%rsi, %rax
	testq	%rax, %rax
	jns	.L145
	addq	%rsi, %rcx
.L145:
	.loc 1 132 9 discriminator 2
	movl	-24(%rbp), %eax
	movslq	%eax, %rdi
	movl	-32(%rbp), %eax
	movslq	%eax, %rsi
	.loc 1 132 36 discriminator 2
	movq	%rdi, %rax
	cqto
	idivq	%rsi
	testq	%rdx, %rdx
	je	.L146
	movq	%rdi, %rax
	xorq	%rsi, %rax
	testq	%rax, %rax
	jns	.L146
	addq	%rsi, %rdx
.L146:
	.loc 1 132 9 discriminator 2
	movq	%rcx, %rsi
	movq	%rdx, %rdi
	call	silver_scalars__checked
	movq	%rax, -12(%rbp)
	movl	-4(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -4(%rbp)
	.loc 1 132 9 is_stmt 0 discriminator 3
	jmp	.L139
.L142:
	.loc 1 134 25 is_stmt 1
	movl	-32(%rbp), %eax
	.loc 1 134 7
	testl	%eax, %eax
	jle	.L147
	.loc 1 134 34 discriminator 1
	movl	-28(%rbp), %eax
	cltq
	.loc 1 134 65 discriminator 1
	subq	$1, %rax
	.loc 1 134 34 discriminator 1
	movq	%rax, %rsi
	movl	$0, %edi
	call	silver_scalars__checked
	movq	%rax, -12(%rbp)
	movl	-4(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -4(%rbp)
	.loc 1 134 34 is_stmt 0 discriminator 2
	jmp	.L139
.L147:
	.loc 1 135 12 is_stmt 1
	movl	-32(%rbp), %eax
	cltq
	.loc 1 135 40
	addq	$1, %rax
	.loc 1 135 12
	movl	$0, %esi
	movq	%rax, %rdi
	call	silver_scalars__checked
	movq	%rax, -12(%rbp)
	movl	-4(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -4(%rbp)
.L139:
	.loc 1 128 4
	movq	-12(%rbp), %rax
	movl	-4(%rbp), %ecx
	movq	%rcx, %rdx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE28:
	.size	silver_scalars__modulo, .-silver_scalars__modulo
	.align 2
	.globl	silver_scalars__remainder_limit
	.type	silver_scalars__remainder_limit, @function
silver_scalars__remainder_limit:
.LFB29:
	.loc 1 136 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	.loc 1 137 11
	movl	-8(%rbp), %eax
	movl	%eax, %edx
	negl	%edx
	cmovns	%edx, %eax
	movl	%eax, %edx
	movl	-4(%rbp), %eax
	movl	%eax, %ecx
	negl	%ecx
	cmovns	%ecx, %eax
	movl	%eax, %eax
	cmpq	%rax, %rdx
	cmovge	%rdx, %rax
	.loc 1 137 65
	subq	$1, %rax
	.loc 1 136 4
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE29:
	.size	silver_scalars__remainder_limit, .-silver_scalars__remainder_limit
	.align 2
	.globl	silver_scalars__remainder
	.type	silver_scalars__remainder, @function
silver_scalars__remainder:
.LFB30:
	.loc 1 138 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r12
	pushq	%rbx
	subq	$48, %rsp
	.cfi_offset 12, -24
	.cfi_offset 3, -32
	movq	%rdi, -40(%rbp)
	movq	%rsi, -48(%rbp)
	.loc 1 139 10
	movq	-48(%rbp), %rax
	movl	$0, %esi
	movq	%rax, %rdi
	call	silver_scalars__contains
	.loc 1 139 7 discriminator 1
	testb	%al, %al
	je	.L151
	.loc 1 139 35 discriminator 2
	movq	silver_scalars__invalid(%rip), %rax
	movq	%rax, -28(%rbp)
	movl	8+silver_scalars__invalid(%rip), %eax
	movl	%eax, -20(%rbp)
	jmp	.L152
.L151:
	.loc 1 140 13
	movq	-40(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty
	.loc 1 140 7 discriminator 1
	testb	%al, %al
	jne	.L153
	.loc 1 140 37 discriminator 2
	movq	-48(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty
	.loc 1 140 29 discriminator 3
	testb	%al, %al
	je	.L154
.L153:
	.loc 1 140 59 discriminator 4
	movq	silver_scalars__unreachable(%rip), %rax
	movq	%rax, -28(%rbp)
	movl	8+silver_scalars__unreachable(%rip), %eax
	movl	%eax, -20(%rbp)
	jmp	.L152
.L154:
	.loc 1 141 24
	movl	-40(%rbp), %edx
	movl	-36(%rbp), %eax
	.loc 1 141 7
	cmpl	%eax, %edx
	jne	.L155
	.loc 1 141 58 discriminator 1
	movl	-48(%rbp), %edx
	movl	-44(%rbp), %eax
	.loc 1 141 37 discriminator 1
	cmpl	%eax, %edx
	jne	.L155
	.loc 1 142 36
	movl	-48(%rbp), %eax
	testl	%eax, %eax
	jne	.L156
	.loc 1 142 36 is_stmt 0 discriminator 1
	leaq	.LC0(%rip), %rax
	movl	$142, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Divide_By_Zero@PLT
.L156:
	.loc 1 143 36 is_stmt 1
	movl	-48(%rbp), %eax
	testl	%eax, %eax
	jne	.L157
	.loc 1 143 36 is_stmt 0 discriminator 1
	leaq	.LC0(%rip), %rax
	movl	$143, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Divide_By_Zero@PLT
.L157:
	.loc 1 143 36 discriminator 2
	movl	-48(%rbp), %eax
	.loc 1 142 9 is_stmt 1 discriminator 2
	cmpl	$-1, %eax
	je	.L158
	.loc 1 143 36 discriminator 3
	movl	-40(%rbp), %eax
	cltq
	movl	-48(%rbp), %edx
	movslq	%edx, %rbx
	.loc 1 142 9 discriminator 3
	cqto
	idivq	%rbx
	movq	%rdx, %rcx
	jmp	.L159
.L158:
	.loc 1 142 9 is_stmt 0 discriminator 4
	movl	$0, %ecx
.L159:
	.loc 1 142 36 is_stmt 1 discriminator 5
	movl	-48(%rbp), %eax
	.loc 1 142 9 discriminator 5
	cmpl	$-1, %eax
	je	.L160
	.loc 1 142 36 discriminator 6
	movl	-40(%rbp), %eax
	cltq
	movl	-48(%rbp), %edx
	movslq	%edx, %rbx
	.loc 1 142 9 discriminator 6
	cqto
	idivq	%rbx
	movq	%rdx, %rsi
	movq	%rsi, %rax
	jmp	.L161
.L160:
	.loc 1 142 9 is_stmt 0 discriminator 7
	movl	$0, %eax
.L161:
	.loc 1 142 9 discriminator 8
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__checked
	movq	%rax, -28(%rbp)
	movl	-20(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -20(%rbp)
	.loc 1 142 9 discriminator 9
	jmp	.L152
.L155:
	.loc 1 146 25 is_stmt 1
	movl	-36(%rbp), %eax
	.loc 1 144 12
	testl	%eax, %eax
	jle	.L162
	.loc 1 146 38 discriminator 1
	movl	-36(%rbp), %eax
	movslq	%eax, %rbx
	.loc 1 146 63 discriminator 1
	movq	-48(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__remainder_limit
	.loc 1 146 38 discriminator 2
	cmpq	%rax, %rbx
	cmovle	%rbx, %rax
	movq	%rax, %r12
	jmp	.L163
.L162:
	.loc 1 144 12 discriminator 2
	movl	$0, %r12d
.L163:
	.loc 1 145 25
	movl	-40(%rbp), %eax
	.loc 1 144 12 discriminator 3
	testl	%eax, %eax
	jns	.L164
	.loc 1 145 38 discriminator 1
	movl	-40(%rbp), %eax
	movslq	%eax, %rbx
	.loc 1 145 64 discriminator 1
	movq	-48(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__remainder_limit
	.loc 1 145 63 discriminator 2
	movabsq	$-9223372036854775808, %rdx
	cmpq	%rdx, %rax
	jne	.L165
	.loc 1 145 63 is_stmt 0 discriminator 3
	leaq	.LC0(%rip), %rax
	movl	$145, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L165:
	.loc 1 145 63 discriminator 5
	negq	%rax
	.loc 1 145 38 is_stmt 1 discriminator 6
	cmpq	%rbx, %rax
	cmovl	%rbx, %rax
	jmp	.L166
.L164:
	.loc 1 144 12 discriminator 5
	movl	$0, %eax
.L166:
	.loc 1 144 12 is_stmt 0 discriminator 6
	movq	%r12, %rsi
	movq	%rax, %rdi
	call	silver_scalars__checked
	movq	%rax, -28(%rbp)
	movl	-20(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -20(%rbp)
.L152:
	.loc 1 138 4 is_stmt 1
	movq	-28(%rbp), %rax
	movl	-20(%rbp), %ecx
	movq	%rcx, %rdx
	addq	$48, %rsp
	popq	%rbx
	popq	%r12
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE30:
	.size	silver_scalars__remainder, .-silver_scalars__remainder
	.globl	silver_scalars_E
	.data
	.align 2
	.type	silver_scalars_E, @object
	.size	silver_scalars_E, 2
silver_scalars_E:
	.zero	2
	.globl	silver_scalars__minimum
	.section	.rodata
	.align 8
	.type	silver_scalars__minimum, @object
	.size	silver_scalars__minimum, 8
silver_scalars__minimum:
	.quad	-2147483648
	.globl	silver_scalars__maximum
	.align 8
	.type	silver_scalars__maximum, @object
	.size	silver_scalars__maximum, 8
silver_scalars__maximum:
	.quad	2147483647
	.globl	silver_scalars__empty
	.align 8
	.type	silver_scalars__empty, @object
	.size	silver_scalars__empty, 8
silver_scalars__empty:
	.long	1
	.long	0
	.globl	silver_scalars__full
	.align 8
	.type	silver_scalars__full, @object
	.size	silver_scalars__full, 8
silver_scalars__full:
	.long	-2147483648
	.long	2147483647
	.globl	silver_scalars__comparisonS
	.align 32
	.type	silver_scalars__comparisonS, @object
	.size	silver_scalars__comparisonS, 46
silver_scalars__comparisonS:
	.ascii	"EQUALUNEQUALLESSLESS_EQUALGREATERGREATER_EQUAL"
	.globl	silver_scalars__comparisonN
	.align 8
	.type	silver_scalars__comparisonN, @object
	.size	silver_scalars__comparisonN, 8
silver_scalars__comparisonN:
	.byte	1
	.byte	6
	.byte	13
	.byte	17
	.byte	27
	.byte	34
	.byte	47
	.zero	1
	.globl	silver_scalars__invalid
	.align 16
	.type	silver_scalars__invalid, @object
	.size	silver_scalars__invalid, 16
silver_scalars__invalid:
	.byte	0
	.zero	3
	.long	1
	.long	0
	.zero	4
	.globl	silver_scalars__unreachable
	.align 16
	.type	silver_scalars__unreachable, @object
	.size	silver_scalars__unreachable, 16
silver_scalars__unreachable:
	.byte	1
	.zero	3
	.long	1
	.long	0
	.zero	4
	.align 8
	.type	comparisonP.3, @object
	.size	comparisonP.3, 8
comparisonP.3:
	.long	1
	.long	8
	.align 2
	.type	comparisonT1.2, @object
	.size	comparisonT1.2, 2
comparisonT1.2:
	.byte	3
	.byte	8
	.align 2
	.type	comparisonT2.1, @object
	.size	comparisonT2.1, 2
comparisonT2.1:
	.byte	2
	.byte	0
	.align 16
	.type	comparisonG.0, @object
	.size	comparisonG.0, 16
comparisonG.0:
	.byte	0
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	4
	.byte	0
	.byte	4
	.byte	0
	.byte	4
	.byte	0
	.byte	5
	.byte	0
	.zero	3
	.text
.Letext0:
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x7b6
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0xb
	.long	.LASF58
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.quad	.Ltext0
	.quad	.Letext0-.Ltext0
	.long	.Ldebug_line0
	.uleb128 0x3
	.long	.LASF2
	.byte	0x6
	.long	0x5f
	.uleb128 0x9
	.byte	0x3
	.quad	silver_scalars__minimum
	.uleb128 0x9
	.sleb128 -9223372036854775808
	.sleb128 9223372036854775807
	.long	.LASF4
	.long	0x64
	.uleb128 0x4
	.long	0x42
	.uleb128 0x8
	.byte	0x8
	.byte	0x5
	.long	.LASF6
	.uleb128 0x3
	.long	.LASF3
	.byte	0x7
	.long	0x5f
	.uleb128 0x9
	.byte	0x3
	.quad	silver_scalars__maximum
	.uleb128 0x9
	.sleb128 -2147483648
	.sleb128 2147483647
	.long	.LASF5
	.long	0x97
	.uleb128 0x4
	.long	0x7f
	.uleb128 0x8
	.byte	0x4
	.byte	0x5
	.long	.LASF7
	.uleb128 0xa
	.long	.LASF16
	.byte	0x8
	.byte	0x9
	.long	0xc2
	.uleb128 0x7
	.long	.LASF8
	.byte	0xa
	.byte	0x7
	.long	0x7f
	.byte	0
	.uleb128 0x7
	.long	.LASF9
	.byte	0xa
	.byte	0xe
	.long	0x7f
	.byte	0x4
	.byte	0
	.uleb128 0x4
	.long	0x9e
	.uleb128 0xc
	.long	.LASF59
	.byte	0x7
	.byte	0x1
	.byte	0x1
	.byte	0x1e
	.byte	0x9
	.long	0xfa
	.uleb128 0x5
	.long	.LASF10
	.byte	0
	.uleb128 0x5
	.long	.LASF11
	.byte	0x1
	.uleb128 0x5
	.long	.LASF12
	.byte	0x2
	.uleb128 0x5
	.long	.LASF13
	.byte	0x3
	.uleb128 0x5
	.long	.LASF14
	.byte	0x4
	.uleb128 0x5
	.long	.LASF15
	.byte	0x5
	.byte	0
	.uleb128 0x4
	.long	0xc7
	.uleb128 0xa
	.long	.LASF17
	.byte	0xc
	.byte	0x47
	.long	0x123
	.uleb128 0x7
	.long	.LASF18
	.byte	0x48
	.byte	0x7
	.long	0x128
	.byte	0
	.uleb128 0x7
	.long	.LASF19
	.byte	0x49
	.byte	0x7
	.long	0x9e
	.byte	0x4
	.byte	0
	.uleb128 0x4
	.long	0xff
	.uleb128 0x8
	.byte	0x1
	.byte	0x2
	.long	.LASF20
	.uleb128 0x4
	.long	0x128
	.uleb128 0x3
	.long	.LASF21
	.byte	0xc
	.long	0xc2
	.uleb128 0x9
	.byte	0x3
	.quad	silver_scalars__empty
	.uleb128 0x3
	.long	.LASF22
	.byte	0xd
	.long	0xc2
	.uleb128 0x9
	.byte	0x3
	.quad	silver_scalars__full
	.uleb128 0x3
	.long	.LASF23
	.byte	0x4b
	.long	0x123
	.uleb128 0x9
	.byte	0x3
	.quad	silver_scalars__invalid
	.uleb128 0x3
	.long	.LASF24
	.byte	0x4c
	.long	0x123
	.uleb128 0x9
	.byte	0x3
	.quad	silver_scalars__unreachable
	.uleb128 0x2
	.long	.LASF27
	.byte	0x8a
	.long	0xff
	.quad	.LFB30
	.quad	.LFE30-.LFB30
	.uleb128 0x1
	.byte	0x9c
	.long	0x1c1
	.uleb128 0x1
	.long	.LASF25
	.byte	0x8a
	.byte	0x18
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x1
	.long	.LASF26
	.byte	0x8a
	.byte	0x1e
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.byte	0
	.uleb128 0x6
	.long	.LASF28
	.byte	0x88
	.long	0x42
	.quad	.LFB29
	.quad	.LFE29-.LFB29
	.uleb128 0x1
	.byte	0x9c
	.long	0x1f0
	.uleb128 0x1
	.long	.LASF26
	.byte	0x88
	.byte	0x1e
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.byte	0
	.uleb128 0x2
	.long	.LASF29
	.byte	0x80
	.long	0xff
	.quad	.LFB28
	.quad	.LFE28-.LFB28
	.uleb128 0x1
	.byte	0x9c
	.long	0x22d
	.uleb128 0x1
	.long	.LASF25
	.byte	0x80
	.byte	0x15
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x1
	.long	.LASF26
	.byte	0x80
	.byte	0x1b
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.byte	0
	.uleb128 0x2
	.long	.LASF30
	.byte	0x7c
	.long	0xff
	.quad	.LFB27
	.quad	.LFE27-.LFB27
	.uleb128 0x1
	.byte	0x9c
	.long	0x26a
	.uleb128 0x1
	.long	.LASF25
	.byte	0x7c
	.byte	0x15
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x1
	.long	.LASF26
	.byte	0x7c
	.byte	0x1b
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.byte	0
	.uleb128 0x2
	.long	.LASF31
	.byte	0x74
	.long	0x42
	.quad	.LFB26
	.quad	.LFE26-.LFB26
	.uleb128 0x1
	.byte	0x9c
	.long	0x2a7
	.uleb128 0x1
	.long	.LASF25
	.byte	0x74
	.byte	0x1f
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0x1
	.long	.LASF26
	.byte	0x74
	.byte	0x25
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -32
	.byte	0
	.uleb128 0x2
	.long	.LASF32
	.byte	0x6e
	.long	0x42
	.quad	.LFB25
	.quad	.LFE25-.LFB25
	.uleb128 0x1
	.byte	0x9c
	.long	0x2e4
	.uleb128 0x1
	.long	.LASF25
	.byte	0x6e
	.byte	0x1f
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0x1
	.long	.LASF26
	.byte	0x6e
	.byte	0x25
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -32
	.byte	0
	.uleb128 0x2
	.long	.LASF33
	.byte	0x6b
	.long	0xff
	.quad	.LFB24
	.quad	.LFE24-.LFB24
	.uleb128 0x1
	.byte	0x9c
	.long	0x321
	.uleb128 0x1
	.long	.LASF25
	.byte	0x6b
	.byte	0x17
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x1
	.long	.LASF26
	.byte	0x6b
	.byte	0x1d
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.byte	0
	.uleb128 0x6
	.long	.LASF34
	.byte	0x66
	.long	0x42
	.quad	.LFB23
	.quad	.LFE23-.LFB23
	.uleb128 0x1
	.byte	0x9c
	.long	0x35e
	.uleb128 0x1
	.long	.LASF25
	.byte	0x66
	.byte	0x1e
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0x1
	.long	.LASF26
	.byte	0x66
	.byte	0x24
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -32
	.byte	0
	.uleb128 0x6
	.long	.LASF35
	.byte	0x61
	.long	0x42
	.quad	.LFB22
	.quad	.LFE22-.LFB22
	.uleb128 0x1
	.byte	0x9c
	.long	0x39b
	.uleb128 0x1
	.long	.LASF25
	.byte	0x61
	.byte	0x1e
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0x1
	.long	.LASF26
	.byte	0x61
	.byte	0x24
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -32
	.byte	0
	.uleb128 0x2
	.long	.LASF36
	.byte	0x5e
	.long	0xff
	.quad	.LFB21
	.quad	.LFE21-.LFB21
	.uleb128 0x1
	.byte	0x9c
	.long	0x3ca
	.uleb128 0x1
	.long	.LASF37
	.byte	0x5e
	.byte	0x15
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.byte	0
	.uleb128 0x2
	.long	.LASF38
	.byte	0x5a
	.long	0xff
	.quad	.LFB20
	.quad	.LFE20-.LFB20
	.uleb128 0x1
	.byte	0x9c
	.long	0x407
	.uleb128 0x1
	.long	.LASF25
	.byte	0x5a
	.byte	0x17
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x1
	.long	.LASF26
	.byte	0x5a
	.byte	0x1d
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.byte	0
	.uleb128 0x2
	.long	.LASF39
	.byte	0x56
	.long	0xff
	.quad	.LFB19
	.quad	.LFE19-.LFB19
	.uleb128 0x1
	.byte	0x9c
	.long	0x444
	.uleb128 0x1
	.long	.LASF25
	.byte	0x56
	.byte	0x12
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x1
	.long	.LASF26
	.byte	0x56
	.byte	0x18
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.byte	0
	.uleb128 0x2
	.long	.LASF40
	.byte	0x52
	.long	0xff
	.quad	.LFB18
	.quad	.LFE18-.LFB18
	.uleb128 0x1
	.byte	0x9c
	.long	0x481
	.uleb128 0x1
	.long	.LASF8
	.byte	0x52
	.byte	0x16
	.long	0x5f
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x1
	.long	.LASF9
	.byte	0x52
	.byte	0x1d
	.long	0x5f
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.byte	0
	.uleb128 0x6
	.long	.LASF41
	.byte	0x4d
	.long	0x128
	.quad	.LFB17
	.quad	.LFE17-.LFB17
	.uleb128 0x1
	.byte	0x9c
	.long	0x4b0
	.uleb128 0x1
	.long	.LASF42
	.byte	0x4d
	.byte	0x17
	.long	0x5f
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.byte	0
	.uleb128 0x2
	.long	.LASF43
	.byte	0x41
	.long	0x9e
	.quad	.LFB16
	.quad	.LFE16-.LFB16
	.uleb128 0x1
	.byte	0x9c
	.long	0x509
	.uleb128 0x1
	.long	.LASF19
	.byte	0x42
	.byte	0x7
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0x1
	.long	.LASF44
	.byte	0x42
	.byte	0x1a
	.long	0xfa
	.uleb128 0x2
	.byte	0x91
	.sleb128 -25
	.uleb128 0x1
	.long	.LASF45
	.byte	0x42
	.byte	0x31
	.long	0x92
	.uleb128 0x2
	.byte	0x91
	.sleb128 -32
	.uleb128 0x1
	.long	.LASF46
	.byte	0x42
	.byte	0x44
	.long	0x12f
	.uleb128 0x2
	.byte	0x91
	.sleb128 -26
	.byte	0
	.uleb128 0x2
	.long	.LASF47
	.byte	0x37
	.long	0x9e
	.quad	.LFB15
	.quad	.LFE15-.LFB15
	.uleb128 0x1
	.byte	0x9c
	.long	0x554
	.uleb128 0x1
	.long	.LASF19
	.byte	0x38
	.byte	0x7
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x1
	.long	.LASF44
	.byte	0x38
	.byte	0x1a
	.long	0xfa
	.uleb128 0x2
	.byte	0x91
	.sleb128 -41
	.uleb128 0x1
	.long	.LASF45
	.byte	0x38
	.byte	0x31
	.long	0x92
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.byte	0
	.uleb128 0x2
	.long	.LASF48
	.byte	0x34
	.long	0x9e
	.quad	.LFB14
	.quad	.LFE14-.LFB14
	.uleb128 0x1
	.byte	0x9c
	.long	0x591
	.uleb128 0x1
	.long	.LASF19
	.byte	0x34
	.byte	0x14
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0x1
	.long	.LASF45
	.byte	0x34
	.byte	0x27
	.long	0x92
	.uleb128 0x2
	.byte	0x91
	.sleb128 -28
	.byte	0
	.uleb128 0x2
	.long	.LASF49
	.byte	0x31
	.long	0x9e
	.quad	.LFB13
	.quad	.LFE13-.LFB13
	.uleb128 0x1
	.byte	0x9c
	.long	0x5ce
	.uleb128 0x1
	.long	.LASF19
	.byte	0x31
	.byte	0x14
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0x1
	.long	.LASF45
	.byte	0x31
	.byte	0x27
	.long	0x92
	.uleb128 0x2
	.byte	0x91
	.sleb128 -28
	.byte	0
	.uleb128 0x2
	.long	.LASF50
	.byte	0x2c
	.long	0xc7
	.quad	.LFB12
	.quad	.LFE12-.LFB12
	.uleb128 0x1
	.byte	0x9c
	.long	0x5fd
	.uleb128 0x1
	.long	.LASF44
	.byte	0x2c
	.byte	0x13
	.long	0xfa
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.byte	0
	.uleb128 0x2
	.long	.LASF51
	.byte	0x27
	.long	0xc7
	.quad	.LFB11
	.quad	.LFE11-.LFB11
	.uleb128 0x1
	.byte	0x9c
	.long	0x62c
	.uleb128 0x1
	.long	.LASF44
	.byte	0x27
	.byte	0x19
	.long	0xfa
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.byte	0
	.uleb128 0x2
	.long	.LASF52
	.byte	0x1f
	.long	0x128
	.quad	.LFB10
	.quad	.LFE10-.LFB10
	.uleb128 0x1
	.byte	0x9c
	.long	0x677
	.uleb128 0x1
	.long	.LASF44
	.byte	0x1f
	.byte	0x16
	.long	0xfa
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.uleb128 0x1
	.long	.LASF25
	.byte	0x1f
	.byte	0x2d
	.long	0x92
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0x1
	.long	.LASF26
	.byte	0x1f
	.byte	0x33
	.long	0x92
	.uleb128 0x2
	.byte	0x91
	.sleb128 -28
	.byte	0
	.uleb128 0x2
	.long	.LASF53
	.byte	0x1a
	.long	0x9e
	.quad	.LFB9
	.quad	.LFE9-.LFB9
	.uleb128 0x1
	.byte	0x9c
	.long	0x6b4
	.uleb128 0x1
	.long	.LASF25
	.byte	0x1a
	.byte	0x18
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0x1
	.long	.LASF26
	.byte	0x1a
	.byte	0x1e
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -32
	.byte	0
	.uleb128 0x2
	.long	.LASF54
	.byte	0x15
	.long	0x9e
	.quad	.LFB8
	.quad	.LFE8-.LFB8
	.uleb128 0x1
	.byte	0x9c
	.long	0x6f1
	.uleb128 0x1
	.long	.LASF25
	.byte	0x15
	.byte	0x13
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x1
	.long	.LASF26
	.byte	0x15
	.byte	0x19
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.byte	0
	.uleb128 0x2
	.long	.LASF55
	.byte	0x13
	.long	0x9e
	.quad	.LFB7
	.quad	.LFE7-.LFB7
	.uleb128 0x1
	.byte	0x9c
	.long	0x720
	.uleb128 0x1
	.long	.LASF19
	.byte	0x13
	.byte	0x18
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.byte	0
	.uleb128 0x6
	.long	.LASF56
	.byte	0x12
	.long	0x9e
	.quad	.LFB6
	.quad	.LFE6-.LFB6
	.uleb128 0x1
	.byte	0x9c
	.long	0x74f
	.uleb128 0x1
	.long	.LASF42
	.byte	0x12
	.byte	0x18
	.long	0x92
	.uleb128 0x2
	.byte	0x91
	.sleb128 -20
	.byte	0
	.uleb128 0x6
	.long	.LASF57
	.byte	0x10
	.long	0x128
	.quad	.LFB5
	.quad	.LFE5-.LFB5
	.uleb128 0x1
	.byte	0x9c
	.long	0x78c
	.uleb128 0x1
	.long	.LASF19
	.byte	0x10
	.byte	0x17
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0x1
	.long	.LASF42
	.byte	0x10
	.byte	0x2a
	.long	0x92
	.uleb128 0x2
	.byte	0x91
	.sleb128 -28
	.byte	0
	.uleb128 0xd
	.long	.LASF60
	.byte	0x1
	.byte	0xe
	.byte	0x4
	.long	0x128
	.quad	.LFB4
	.quad	.LFE4-.LFB4
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x1
	.long	.LASF19
	.byte	0xe
	.byte	0x17
	.long	0xc2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.byte	0
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x28
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x1c
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0xd
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x2c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.Letext0-.Ltext0
	.quad	0
	.quad	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF32:
	.string	"silver_scalars__quotient_minimum"
.LASF10:
	.string	"silver_scalars__equal"
.LASF29:
	.string	"silver_scalars__modulo"
.LASF28:
	.string	"silver_scalars__remainder_limit"
.LASF16:
	.string	"silver_scalars__interval"
.LASF22:
	.string	"silver_scalars__full"
.LASF49:
	.string	"silver_scalars__below"
.LASF9:
	.string	"upper"
.LASF41:
	.string	"silver_scalars__in_range"
.LASF25:
	.string	"left"
.LASF5:
	.string	"silver_scalars__value"
.LASF60:
	.string	"silver_scalars__is_empty"
.LASF11:
	.string	"silver_scalars__unequal"
.LASF14:
	.string	"silver_scalars__greater"
.LASF17:
	.string	"silver_scalars__check_result"
.LASF8:
	.string	"lower"
.LASF4:
	.string	"silver_scalars__wide"
.LASF34:
	.string	"silver_scalars__product_maximum"
.LASF30:
	.string	"silver_scalars__divide"
.LASF35:
	.string	"silver_scalars__product_minimum"
.LASF45:
	.string	"threshold"
.LASF26:
	.string	"right"
.LASF43:
	.string	"silver_scalars__refine"
.LASF13:
	.string	"silver_scalars__less_equal"
.LASF57:
	.string	"silver_scalars__contains"
.LASF31:
	.string	"silver_scalars__quotient_maximum"
.LASF44:
	.string	"operator"
.LASF23:
	.string	"silver_scalars__invalid"
.LASF55:
	.string	"silver_scalars__normalize"
.LASF47:
	.string	"silver_scalars__refine_true"
.LASF12:
	.string	"silver_scalars__less"
.LASF21:
	.string	"silver_scalars__empty"
.LASF38:
	.string	"silver_scalars__subtract"
.LASF37:
	.string	"operand"
.LASF36:
	.string	"silver_scalars__negate"
.LASF24:
	.string	"silver_scalars__unreachable"
.LASF3:
	.string	"silver_scalars__maximum"
.LASF59:
	.string	"silver_scalars__comparison"
.LASF2:
	.string	"silver_scalars__minimum"
.LASF50:
	.string	"silver_scalars__swap"
.LASF6:
	.string	"long_long_integer"
.LASF54:
	.string	"silver_scalars__join"
.LASF48:
	.string	"silver_scalars__above"
.LASF19:
	.string	"bounds"
.LASF56:
	.string	"silver_scalars__singleton"
.LASF15:
	.string	"silver_scalars__greater_equal"
.LASF7:
	.string	"integer"
.LASF46:
	.string	"truth"
.LASF40:
	.string	"silver_scalars__checked"
.LASF53:
	.string	"silver_scalars__intersect"
.LASF33:
	.string	"silver_scalars__multiply"
.LASF52:
	.string	"silver_scalars__compare"
.LASF42:
	.string	"item"
.LASF51:
	.string	"silver_scalars__complement"
.LASF58:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF20:
	.string	"boolean"
.LASF27:
	.string	"silver_scalars__remainder"
.LASF18:
	.string	"safe"
.LASF39:
	.string	"silver_scalars__add"
	.section	.debug_line_str,"MS",@progbits,1
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_scalars.ads"
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
