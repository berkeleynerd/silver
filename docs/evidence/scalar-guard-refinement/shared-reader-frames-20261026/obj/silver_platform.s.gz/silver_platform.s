	.file	"silver_platform.adb"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_platform.adb"
	.section	.rodata
.LC9:
	.ascii	"silver_platform.ads"
	.zero	1
	.text
	.align 2
	.globl	silver_platform__valid_path
	.type	silver_platform__valid_path, @function
silver_platform__valid_path:
.LFB2:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_platform.ads"
	.loc 1 28 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -32(%rbp)
	movq	%rdx, -24(%rbp)
	.loc 1 28 4
	movq	-24(%rbp), %rax
	movl	(%rax), %esi
	movq	-24(%rbp), %rax
	movl	4(%rax), %ecx
	movq	-24(%rbp), %rax
	movl	4(%rax), %edx
	movq	-24(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L2
	.loc 1 28 4 is_stmt 0 discriminator 1
	movq	-24(%rbp), %rax
	movl	4(%rax), %edi
	movslq	%edi, %rax
	cqto
	movq	-24(%rbp), %rdi
	movl	(%rdi), %edi
	movslq	%edi, %rdi
	movq	%rdi, %r8
	movq	%rdi, %r9
	sarq	$63, %r9
	subq	%r8, %rax
	sbbq	%r9, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L3
.L2:
	.loc 1 28 4 discriminator 2
	movl	$0, %eax
	movl	$0, %edx
.L3:
.LBB2:
	.loc 1 29 19 is_stmt 1
	movl	%eax, %edi
	.loc 1 30 7
	testl	%edi, %edi
	jle	.L4
	.loc 1 29 19 discriminator 1
	cmpl	$4096, %eax
	jg	.L4
	.loc 1 30 17 discriminator 1
	movl	$1, %r10d
	cmpl	%ecx, %esi
	jg	.L5
.LBB3:
	.loc 1 30 17 is_stmt 0 discriminator 2
	movl	%esi, %eax
.L10:
.LBB4:
	.loc 1 30 17 discriminator 3
	cmpl	%eax, %esi
	jg	.L6
	.loc 1 30 17 discriminator 4
	cmpl	%eax, %ecx
	jge	.L7
.L6:
	.loc 1 30 17 discriminator 5
	leaq	.LC9(%rip), %rax
	movl	$30, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L7:
	.loc 1 30 25 is_stmt 1 discriminator 6
	movq	-32(%rbp), %r8
	movq	-24(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdi
	movslq	%eax, %rdx
	movq	%rdx, %r9
	subq	%rdi, %r9
	leaq	(%r8,%r9), %rdi
	movq	%rdi, -8(%rbp)
	.loc 1 30 46 discriminator 6
	movq	-32(%rbp), %rdi
	movq	-24(%rbp), %r8
	movl	(%r8), %r8d
	movslq	%r8d, %r8
	subq	%r8, %rdx
	movzbl	(%rdi,%rdx), %edx
	.loc 1 30 17 discriminator 6
	testb	%dl, %dl
	jne	.L8
	.loc 1 30 17 is_stmt 0 discriminator 7
	movl	$0, %r10d
	jmp	.L5
.L8:
.LBE4:
	.loc 1 30 17 discriminator 8
	cmpl	%ecx, %eax
	je	.L5
	.loc 1 30 17 discriminator 9
	addl	$1, %eax
	jmp	.L10
.L5:
.LBE3:
	.loc 1 30 7 is_stmt 1 discriminator 10
	testb	%r10b, %r10b
	je	.L4
	.loc 1 30 7 is_stmt 0 discriminator 11
	movl	$1, %eax
	jmp	.L11
.L4:
	.loc 1 30 7 discriminator 12
	movl	$0, %eax
.L11:
.LBE2:
	.loc 1 28 4 is_stmt 1
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	silver_platform__valid_path, .-silver_platform__valid_path
	.align 2
	.type	silver_platform__observed_get, @function
silver_platform__observed_get:
.LFB3:
	.file 2 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_platform.adb"
	.loc 2 17 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, -24(%rbp)
	.loc 2 28 15
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	fgetc@PLT
	.loc 2 28 12 discriminator 1
	movl	%eax, -4(%rbp)
	.loc 2 30 15
	movl	-4(%rbp), %eax
	.loc 2 30 7
	testl	%eax, %eax
	.loc 2 34 8 discriminator 1
	movl	-4(%rbp), %eax
	.loc 2 34 8 is_stmt 0
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.size	silver_platform__observed_get, .-silver_platform__observed_get
	.section	.rodata
	.align 8
.LC10:
	.ascii	"failed precondition from silver_platform.adb:38"
	.align 8
.LC0:
	.long	1
	.long	47
	.text
	.align 2
	.type	silver_platform__observed_put, @function
silver_platform__observed_put:
.LFB4:
	.loc 2 36 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, -24(%rbp)
	movl	%esi, -28(%rbp)
	.loc 2 38 30
	cmpl	$0, -28(%rbp)
	js	.L18
	.loc 2 38 35 discriminator 1
	cmpl	$255, -28(%rbp)
	jle	.L19
.L18:
.LBB5:
	.loc 2 38 30 discriminator 2
	leaq	.LC10(%rip), %rax
	leaq	.LC0(%rip), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L19:
.LBE5:
	.loc 2 48 17
	movq	-24(%rbp), %rdx
	movl	-28(%rbp), %eax
	movq	%rdx, %rsi
	movl	%eax, %edi
	call	fputc@PLT
	.loc 2 48 14 discriminator 1
	movl	%eax, -4(%rbp)
	.loc 2 53 8 discriminator 1
	movl	-4(%rbp), %eax
	.loc 2 53 8 is_stmt 0
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	silver_platform__observed_put, .-silver_platform__observed_put
	.align 2
	.type	silver_platform__read_file___wrapped_statements__B24b___finalizer.1, @function
silver_platform__read_file___wrapped_statements__B24b___finalizer.1:
.LFB7:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE7:
	.size	silver_platform__read_file___wrapped_statements__B24b___finalizer.1, .-silver_platform__read_file___wrapped_statements__B24b___finalizer.1
	.section	.rodata
.LC11:
	.ascii	"rb"
.LC12:
	.ascii	"silver_platform.adb"
	.zero	1
	.align 8
.LC13:
	.ascii	"Loop_Invariant failed at silver_platform.adb:78"
	.align 8
.LC2:
	.long	1
	.long	2
	.text
	.align 2
	.type	silver_platform__read_file___wrapped_statements.0, @function
silver_platform__read_file___wrapped_statements.0:
.LFB6:
	.loc 2 55 4 is_stmt 1
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA6
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB0:
	subq	$104, %rsp
.LEHE0:
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -120(%rbp)
	.loc 2 55 4
	leaq	16(%rbp), %rax
	.loc 2 55 4 is_stmt 0 discriminator 1
	movq	%rax, -88(%rbp)
	.loc 2 61 7 is_stmt 1
	movb	$0, -57(%rbp)
	.loc 2 63 17
	movq	16(%rbx), %rax
	movq	8(%rax), %rax
	movl	(%rax), %edx
	movq	16(%rbx), %rax
	movq	8(%rax), %rax
	movl	4(%rax), %eax
	movl	%edx, %esi
	movl	%eax, %edi
	call	_GLOBAL__SZ1_silver_platform
	movq	%rax, %rdx
	.loc 2 63 17 is_stmt 0 discriminator 1
	movq	16(%rbx), %rax
	movq	(%rax), %rax
	movl	$0, %esi
	movq	%rax, %rdi
	call	memset@PLT
	.loc 2 64 12 is_stmt 1
	movl	$0, %eax
	movl	%eax, 24(%rbx)
	.loc 2 65 16
	movl	$0, %eax
	movb	%al, 29(%rbx)
	.loc 2 66 15
	movl	$0, %eax
	movb	%al, 28(%rbx)
.LBB6:
	leaq	-112(%rbp), %rax
	movq	%rax, %rdi
.LEHB1:
	call	system__secondary_stack__ss_mark@PLT
.LBB7:
	.loc 2 71 61
	leaq	.LC11(%rip), %r14
	leaq	.LC2(%rip), %r15
	movq	%r14, %rcx
	movq	%r15, %rax
	movl	$1, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	interfaces__c__to_c__2@PLT
	.loc 2 71 15 discriminator 1
	movq	%rax, %r14
	.loc 2 71 35 discriminator 1
	movq	8(%rbx), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movl	$1, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	interfaces__c__to_c__2@PLT
	.loc 2 71 15 discriminator 2
	movq	%r14, %rsi
	movq	%rax, %rdi
	call	fopen@PLT
.LEHE1:
	.loc 2 71 12 discriminator 3
	movq	%rax, -56(%rbp)
.LBE7:
	.loc 2 71 0 discriminator 3
	movl	$1, %r14d
.L46:
	.loc 2 71 0 is_stmt 0 discriminator 4
	leaq	-112(%rbp), %rax
	movq	%rax, %r10
.LEHB2:
	call	silver_platform__read_file___wrapped_statements__B24b___finalizer.1
.LEHE2:
	.loc 2 71 0 discriminator 5
	cmpl	$1, %r14d
	jne	.L24
	.loc 2 71 0 discriminator 7
	movl	$1, %eax
.L48:
	.loc 2 71 0 discriminator 8
	cmpl	$1, %eax
	jne	.L25
	.loc 2 71 0 discriminator 9
	nop
.LBE6:
	.loc 2 72 7 is_stmt 1
	cmpq	$0, -56(%rbp)
	je	.L52
	.loc 2 76 15
	movl	$1, %eax
	movb	%al, 28(%rbx)
	.loc 2 77 11
	movq	16(%rbx), %rax
	movq	8(%rax), %rax
	movl	(%rax), %eax
	movl	%eax, -68(%rbp)
	movq	16(%rbx), %rax
	movq	8(%rax), %rax
	movl	4(%rax), %eax
	movl	%eax, -72(%rbp)
	movl	-68(%rbp), %eax
	cmpl	-72(%rbp), %eax
	jg	.L28
.LBB8:
	.loc 2 77 11 is_stmt 0 discriminator 1
	movl	-68(%rbp), %eax
	movl	%eax, -64(%rbp)
.L38:
	.loc 2 78 46 is_stmt 1
	cmpl	$-2147483648, -64(%rbp)
	jne	.L29
	.loc 2 78 46 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$78, %esi
	movq	%rax, %rdi
.LEHB3:
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L29:
	.loc 2 78 46 discriminator 3
	movl	-64(%rbp), %eax
	leal	-1(%rax), %edx
	.loc 2 78 38 is_stmt 1 discriminator 4
	movl	24(%rbx), %eax
	.loc 2 78 33 discriminator 4
	cmpl	%eax, %edx
	je	.L30
.LBB9:
	.loc 2 78 33 is_stmt 0 discriminator 5
	leaq	.LC13(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L30:
.LBE9:
	.loc 2 81 10 is_stmt 1
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	silver_platform__observed_get
	.loc 2 81 10 is_stmt 0 discriminator 1
	movl	%eax, -76(%rbp)
	.loc 2 82 10 is_stmt 1
	cmpl	$-1, -76(%rbp)
	jne	.L31
	.loc 2 83 23
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	ferror@PLT
	.loc 2 83 23 is_stmt 0 discriminator 1
	movl	%eax, -80(%rbp)
	.loc 2 84 31 is_stmt 1
	cmpl	$0, -80(%rbp)
	sete	%al
	.loc 2 84 21
	movb	%al, 28(%rbx)
	.loc 2 85 25
	movb	$1, -57(%rbp)
	.loc 2 86 13
	jmp	.L28
.L31:
	.loc 2 87 10
	cmpl	$0, -76(%rbp)
	js	.L33
	.loc 2 87 21 discriminator 1
	cmpl	$255, -76(%rbp)
	jle	.L34
.L33:
	.loc 2 88 21
	movl	$0, %eax
	movb	%al, 28(%rbx)
	.loc 2 89 13
	jmp	.L28
.L34:
	.loc 2 91 43
	cmpl	$0, -76(%rbp)
	js	.L35
	.loc 2 91 43 is_stmt 0 discriminator 1
	cmpl	$255, -76(%rbp)
	jle	.L36
.L35:
	.loc 2 91 43 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$91, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L36:
	.loc 2 91 25 is_stmt 1 discriminator 3
	movq	16(%rbx), %rax
	movq	(%rax), %rax
	movl	-64(%rbp), %edx
	movslq	%edx, %rcx
	movl	-76(%rbp), %edx
	movl	%edx, %esi
	movq	(%rbx), %rdx
	subq	%rdx, %rcx
	movb	%sil, (%rax,%rcx)
	.loc 2 92 18
	cmpl	$0, -64(%rbp)
	jns	.L37
	.loc 2 92 18 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$92, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L37:
	.loc 2 92 15 is_stmt 1 discriminator 2
	movl	-64(%rbp), %eax
	movl	%eax, 24(%rbx)
	.loc 2 77 11 discriminator 2
	movl	-64(%rbp), %eax
	cmpl	-72(%rbp), %eax
	je	.L28
	.loc 2 77 11 is_stmt 0 discriminator 3
	addl	$1, -64(%rbp)
	.loc 2 93 15 is_stmt 1
	jmp	.L38
.L28:
.LBE8:
	.loc 2 95 7
	movzbl	28(%rbx), %eax
	testb	%al, %al
	je	.L39
	.loc 2 95 27 discriminator 1
	movzbl	-57(%rbp), %eax
	xorl	$1, %eax
	.loc 2 95 18 discriminator 1
	testb	%al, %al
	je	.L39
	.loc 2 96 10
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	silver_platform__observed_get
	.loc 2 96 10 is_stmt 0 discriminator 1
	movl	%eax, -76(%rbp)
	.loc 2 97 10 is_stmt 1
	cmpl	$-1, -76(%rbp)
	jne	.L40
	.loc 2 98 23
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	ferror@PLT
	.loc 2 98 23 is_stmt 0 discriminator 1
	movl	%eax, -80(%rbp)
	.loc 2 99 31 is_stmt 1
	cmpl	$0, -80(%rbp)
	sete	%al
	.loc 2 99 21
	movb	%al, 28(%rbx)
	jmp	.L39
.L40:
	.loc 2 100 10
	cmpl	$0, -76(%rbp)
	js	.L42
	.loc 2 100 21 discriminator 1
	cmpl	$255, -76(%rbp)
	jg	.L42
	.loc 2 101 22
	movl	$1, %eax
	movb	%al, 29(%rbx)
	jmp	.L39
.L42:
	.loc 2 103 21
	movl	$0, %eax
	movb	%al, 28(%rbx)
.L39:
	.loc 2 106 17
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	fclose@PLT
	.loc 2 106 17 is_stmt 0 discriminator 1
	movl	%eax, -80(%rbp)
	.loc 2 108 26 is_stmt 1
	movzbl	28(%rbx), %eax
	testb	%al, %al
	je	.L43
	.loc 2 108 26 is_stmt 0 discriminator 1
	cmpl	$0, -80(%rbp)
	jne	.L43
	.loc 2 108 26 discriminator 2
	movl	$1, %eax
	jmp	.L44
.L43:
	.loc 2 108 26 discriminator 3
	movl	$0, %eax
.L44:
	.loc 2 108 15 is_stmt 1 discriminator 4
	movb	%al, 28(%rbx)
	.loc 2 109 8
	jmp	.L51
.L49:
	movq	%rax, -136(%rbp)
	movl	$0, %r14d
.LBB10:
	.loc 2 71 12 discriminator 10
	jmp	.L46
.L24:
	movq	-136(%rbp), %rax
	movq	%rax, -128(%rbp)
	jmp	.L47
.L50:
	movq	%rax, -128(%rbp)
.L47:
	movl	$0, %eax
	jmp	.L48
.L25:
	movq	-128(%rbp), %rax
	movq	%rax, %rdi
	call	_Unwind_Resume@PLT
.L52:
.LBE10:
	.loc 2 73 10
	nop
.L51:
	.loc 2 109 8
	addq	$104, %rsp
.LEHE3:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE6:
	.section	.gcc_except_table,"a",@progbits
.LLSDA6:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE6-.LLSDACSB6
.LLSDACSB6:
	.uleb128 .LEHB0-.LFB6
	.uleb128 .LEHE0-.LEHB0
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB1-.LFB6
	.uleb128 .LEHE1-.LEHB1
	.uleb128 .L49-.LFB6
	.uleb128 0
	.uleb128 .LEHB2-.LFB6
	.uleb128 .LEHE2-.LEHB2
	.uleb128 .L50-.LFB6
	.uleb128 0
	.uleb128 .LEHB3-.LFB6
	.uleb128 .LEHE3-.LEHB3
	.uleb128 0
	.uleb128 0
.LLSDACSE6:
	.text
	.size	silver_platform__read_file___wrapped_statements.0, .-silver_platform__read_file___wrapped_statements.0
	.section	.rodata
	.align 8
.LC14:
	.ascii	"failed precondition from silver_platform.ads:37"
	.align 8
.LC15:
	.ascii	"failed precondition from silver_platform.ads:38"
	.align 8
.LC16:
	.ascii	"failed postcondition from silver_platform.ads:39"
	.align 8
.LC1:
	.long	1
	.long	48
	.text
	.align 2
	.globl	silver_platform__read_file
	.type	silver_platform__read_file, @function
silver_platform__read_file:
.LFB5:
	.loc 2 55 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA5
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB4:
	subq	$136, %rsp
.LEHE4:
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -112(%rbp)
	movq	%rdi, -104(%rbp)
	movq	%rdx, -128(%rbp)
	movq	%rcx, -120(%rbp)
	.loc 2 55 4
	leaq	16(%rbp), %rax
	.loc 2 55 4 is_stmt 0 discriminator 1
	leaq	-112(%rbp), %rdx
	movq	%rax, -64(%rbp)
	leaq	-128(%rbp), %rax
	movq	%rdx, -88(%rbp)
	movq	%rax, -80(%rbp)
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	movq	-104(%rbp), %rdx
	movl	4(%rdx), %edx
.LBB11:
	movq	-120(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movq	%rcx, -96(%rbp)
	movq	-120(%rbp), %rcx
	movl	4(%rcx), %esi
	movq	-120(%rbp), %rcx
	movl	(%rcx), %ecx
	cmpl	%ecx, %esi
	.loc 2 55 4 discriminator 4
	movq	-120(%rbp), %rcx
	movl	4(%rcx), %esi
	movq	-120(%rbp), %rcx
	movl	(%rcx), %ecx
	cmpl	%ecx, %esi
	.loc 2 55 4 discriminator 7
	movq	-120(%rbp), %rcx
	movl	4(%rcx), %esi
	movq	-120(%rbp), %rcx
	movl	(%rcx), %ecx
	cmpl	%ecx, %esi
	.loc 2 55 4 discriminator 10
	cmpl	%eax, %edx
	.loc 2 55 4 discriminator 13
	cmpl	%eax, %edx
	.loc 2 55 4 discriminator 16
	cmpl	%eax, %edx
	.loc 1 37 18 is_stmt 1
	movq	-112(%rbp), %rdx
	movq	-104(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
.LEHB5:
	call	silver_platform__valid_path
	.loc 1 37 18 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L66
.LBB12:
	.loc 1 37 18 discriminator 2
	leaq	.LC14(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rsi
	movq	-152(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L66:
.LBE12:
	.loc 1 37 58 is_stmt 1 discriminator 3
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	.loc 1 37 18 discriminator 3
	cmpl	$1, %eax
	je	.L67
.LBB13:
	.loc 1 37 18 is_stmt 0 discriminator 4
	leaq	.LC14(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rsi
	movq	-136(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L67:
.LBE13:
	.loc 1 38 28 is_stmt 1
	movq	-120(%rbp), %rax
	movl	4(%rax), %edx
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	.loc 1 37 18 discriminator 5
	cmpl	%eax, %edx
	jl	.L68
	.loc 1 38 36 discriminator 1
	movq	-120(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, %ecx
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, %edx
	movl	%ecx, %eax
	subl	%edx, %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L68
	.loc 1 38 28 discriminator 2
	movq	-120(%rbp), %rax
	movl	4(%rax), %edx
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	.loc 1 38 36 discriminator 2
	cmpl	%eax, %edx
	jl	.L69
	.loc 1 38 36 is_stmt 0 discriminator 3
	movq	-120(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, %ecx
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, %edx
	movl	%ecx, %eax
	subl	%edx, %eax
	addl	$1, %eax
	cmpl	$16777216, %eax
	jle	.L69
.L68:
.LBB14:
	.loc 1 37 18 is_stmt 1 discriminator 6
	leaq	.LC15(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L69:
.LBE14:
	.loc 2 55 4 discriminator 19
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
	call	silver_platform__read_file___wrapped_statements.0
	.loc 1 39 45
	movq	-120(%rbp), %rax
	movl	4(%rax), %edx
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L70
	.loc 1 39 45 is_stmt 0 discriminator 1
	movq	-120(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, %ecx
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, %edx
	movl	%ecx, %eax
	subl	%edx, %eax
	addl	$1, %eax
	movl	%eax, %edx
	jmp	.L71
.L70:
	.loc 1 39 45 discriminator 2
	movl	$0, %edx
.L71:
	.loc 1 39 36 is_stmt 1 discriminator 3
	movl	-72(%rbp), %eax
	.loc 1 39 31 discriminator 3
	cmpl	%eax, %edx
	jge	.L80
.LBB15:
	.loc 1 39 31 is_stmt 0 discriminator 4
	leaq	.LC16(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.LEHE5:
.L80:
.LBE15:
	.loc 2 55 4 is_stmt 1 discriminator 20
	nop
.LBE11:
	.loc 2 55 4 is_stmt 0 discriminator 21
	movl	-72(%rbp), %eax
	movl	%eax, %edx
	movabsq	$-4294967296, %rax
	andq	%rbx, %rax
	orq	%rdx, %rax
	movq	%rax, %rbx
	movzbl	-67(%rbp), %eax
	movzbl	%al, %eax
	salq	$32, %rax
	movabsq	$-1095216660481, %rdx
	andq	%rbx, %rdx
	orq	%rdx, %rax
	movq	%rax, %rbx
	movzbl	-68(%rbp), %eax
	movzbl	%al, %eax
	salq	$40, %rax
	movabsq	$-280375465082881, %rdx
	andq	%rbx, %rdx
	orq	%rdx, %rax
	movq	%rax, %rbx
	movl	$0, %eax
.L76:
	cmpl	$1, %eax
	je	.L73
	.loc 2 55 4 discriminator 22
	movq	%rbx, %rax
	jmp	.L79
.L77:
	movq	%rax, -168(%rbp)
	movl	$1, %eax
	jmp	.L76
.L73:
	movq	-168(%rbp), %rax
	movq	%rax, %rdi
.LEHB6:
	call	_Unwind_Resume@PLT
.L79:
	.loc 2 55 4
	addq	$136, %rsp
.LEHE6:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE5:
	.section	.gcc_except_table
.LLSDA5:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE5-.LLSDACSB5
.LLSDACSB5:
	.uleb128 .LEHB4-.LFB5
	.uleb128 .LEHE4-.LEHB4
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB5-.LFB5
	.uleb128 .LEHE5-.LEHB5
	.uleb128 .L77-.LFB5
	.uleb128 0
	.uleb128 .LEHB6-.LFB5
	.uleb128 .LEHE6-.LEHB6
	.uleb128 0
	.uleb128 0
.LLSDACSE5:
	.text
	.size	silver_platform__read_file, .-silver_platform__read_file
	.align 2
	.type	silver_platform__write_file__B48b___finalizer.2, @function
silver_platform__write_file__B48b___finalizer.2:
.LFB9:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE9:
	.size	silver_platform__write_file__B48b___finalizer.2, .-silver_platform__write_file__B48b___finalizer.2
	.section	.rodata
	.align 8
.LC17:
	.ascii	"failed precondition from silver_platform.ads:48"
	.align 8
.LC18:
	.ascii	"failed precondition from silver_platform.ads:49"
.LC19:
	.ascii	"wb"
	.text
	.align 2
	.globl	silver_platform__write_file
	.type	silver_platform__write_file, @function
silver_platform__write_file:
.LFB8:
	.loc 2 111 4 is_stmt 1
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA8
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB7:
	subq	$152, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -128(%rbp)
	movq	%rdi, -120(%rbp)
	movq	%rdx, -144(%rbp)
	movq	%rcx, -136(%rbp)
	.loc 2 111 4
	leaq	16(%rbp), %rax
	.loc 2 111 4 is_stmt 0 discriminator 1
	movq	%rax, -88(%rbp)
	movq	-136(%rbp), %rax
	movl	(%rax), %ebx
	movq	-136(%rbp), %rax
	movl	4(%rax), %r12d
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	movq	-120(%rbp), %rdx
	movl	4(%rdx), %edx
.LBB16:
	movslq	%ebx, %r13
	cmpl	%ebx, %r12d
	.loc 2 111 4 discriminator 4
	cmpl	%ebx, %r12d
	.loc 2 111 4 discriminator 7
	cmpl	%ebx, %r12d
	.loc 2 111 4 discriminator 10
	cmpl	%eax, %edx
	.loc 2 111 4 discriminator 13
	cmpl	%eax, %edx
	.loc 2 111 4 discriminator 16
	cmpl	%eax, %edx
	.loc 1 48 18 is_stmt 1
	movq	-128(%rbp), %rdx
	movq	-120(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_platform__valid_path
	.loc 1 48 18 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L96
.LBB17:
	.loc 1 48 18 discriminator 2
	leaq	.LC17(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rcx
	movq	-168(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L96:
.LBE17:
	.loc 1 49 38 is_stmt 1
	movslq	%ebx, %rax
	leaq	16777215(%rax), %rdx
	movslq	%r12d, %rax
	.loc 1 48 18 discriminator 3
	cmpq	%rax, %rdx
	jge	.L97
.LBB18:
	.loc 1 48 18 is_stmt 0 discriminator 4
	leaq	.LC18(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rcx
	movq	-152(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.LEHE7:
.L97:
.LBE18:
	.loc 2 116 15 is_stmt 1
	movb	$0, -73(%rbp)
	leaq	-112(%rbp), %rax
	movq	%rax, %rdi
.LEHB8:
	call	system__secondary_stack__ss_mark@PLT
.LBB19:
.LBB20:
	.loc 2 120 61
	leaq	.LC19(%rip), %r14
	leaq	.LC2(%rip), %r15
	movq	%r14, %rcx
	movq	%r15, %rax
	movl	$1, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	interfaces__c__to_c__2@PLT
	.loc 2 120 15 discriminator 1
	movq	%rax, %r14
	.loc 2 120 35 discriminator 1
	movq	-128(%rbp), %rcx
	movq	-120(%rbp), %rax
	movl	$1, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	interfaces__c__to_c__2@PLT
	.loc 2 120 15 discriminator 2
	movq	%r14, %rsi
	movq	%rax, %rdi
	call	fopen@PLT
.LEHE8:
	.loc 2 120 12 discriminator 3
	movq	%rax, -56(%rbp)
.LBE20:
	.loc 2 120 0 discriminator 3
	movl	$1, %r14d
.L110:
	.loc 2 120 0 is_stmt 0 discriminator 4
	leaq	-112(%rbp), %rax
	movq	%rax, %r10
.LEHB9:
	call	silver_platform__write_file__B48b___finalizer.2
.LEHE9:
	.loc 2 120 0 discriminator 5
	cmpl	$1, %r14d
	jne	.L98
	.loc 2 120 0 discriminator 7
	movl	$1, %eax
.L112:
	.loc 2 120 0 discriminator 8
	cmpl	$1, %eax
	jne	.L99
	.loc 2 120 0 discriminator 9
	nop
.LBE19:
	.loc 2 121 7 is_stmt 1
	cmpq	$0, -56(%rbp)
	je	.L116
	.loc 2 124 15
	movb	$1, -73(%rbp)
	.loc 2 125 11
	movl	%ebx, -64(%rbp)
	movl	%r12d, -68(%rbp)
	movl	-64(%rbp), %eax
	cmpl	-68(%rbp), %eax
	jg	.L102
.LBB21:
	.loc 2 125 11 is_stmt 0 discriminator 1
	movl	-64(%rbp), %eax
	movl	%eax, -60(%rbp)
.L105:
	.loc 2 130 10 is_stmt 1
	movq	-144(%rbp), %rax
	movl	-60(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
.LEHB10:
	movzbl	(%rax,%rdx), %eax
	.loc 2 130 10 is_stmt 0 discriminator 1
	movzbl	%al, %edx
	movq	-56(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_platform__observed_put
	.loc 2 130 10 discriminator 2
	movl	%eax, -72(%rbp)
	.loc 2 132 20 is_stmt 1
	movq	-144(%rbp), %rax
	movl	-60(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 2 132 20 is_stmt 0 discriminator 1
	movzbl	%al, %eax
	.loc 2 132 10 is_stmt 1 discriminator 1
	cmpl	%eax, -72(%rbp)
	je	.L103
	.loc 2 133 21
	movb	$0, -73(%rbp)
	.loc 2 134 13
	jmp	.L102
.L103:
	.loc 2 125 11 discriminator 2
	movl	-60(%rbp), %eax
	cmpl	-68(%rbp), %eax
	je	.L102
	.loc 2 125 11 is_stmt 0 discriminator 3
	addl	$1, -60(%rbp)
	.loc 2 136 15 is_stmt 1
	jmp	.L105
.L102:
.LBE21:
	.loc 2 137 17
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	fclose@PLT
	.loc 2 137 17 is_stmt 0 discriminator 1
	movl	%eax, -72(%rbp)
	.loc 2 139 26 is_stmt 1
	movzbl	-73(%rbp), %eax
	testb	%al, %al
	je	.L106
	.loc 2 139 26 is_stmt 0 discriminator 1
	cmpl	$0, -72(%rbp)
	jne	.L106
	.loc 2 139 26 discriminator 2
	movl	$1, %eax
	jmp	.L107
.L106:
	.loc 2 139 26 discriminator 3
	movl	$0, %eax
.L107:
	.loc 2 139 15 is_stmt 1 discriminator 4
	movb	%al, -73(%rbp)
	.loc 2 140 8
	jmp	.L101
.L116:
	.loc 2 122 10
	nop
.L101:
.LBE16:
	.loc 2 140 8 discriminator 1
	movzbl	-73(%rbp), %eax
	.loc 2 140 8 is_stmt 0 discriminator 3
	jmp	.L115
.L113:
	movq	%rax, -192(%rbp)
	movl	$0, %r14d
.LBB23:
.LBB22:
	.loc 2 120 12 is_stmt 1 discriminator 10
	jmp	.L110
.L98:
	movq	-192(%rbp), %rax
	movq	%rax, -184(%rbp)
	jmp	.L111
.L114:
	movq	%rax, -184(%rbp)
.L111:
	movl	$0, %eax
	jmp	.L112
.L99:
	movq	-184(%rbp), %rax
	movq	%rax, %rdi
	call	_Unwind_Resume@PLT
.L115:
.LBE22:
.LBE23:
	.loc 2 140 8
	addq	$152, %rsp
.LEHE10:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE8:
	.section	.gcc_except_table
.LLSDA8:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE8-.LLSDACSB8
.LLSDACSB8:
	.uleb128 .LEHB7-.LFB8
	.uleb128 .LEHE7-.LEHB7
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB8-.LFB8
	.uleb128 .LEHE8-.LEHB8
	.uleb128 .L113-.LFB8
	.uleb128 0
	.uleb128 .LEHB9-.LFB8
	.uleb128 .LEHE9-.LEHB9
	.uleb128 .L114-.LFB8
	.uleb128 0
	.uleb128 .LEHB10-.LFB8
	.uleb128 .LEHE10-.LEHB10
	.uleb128 0
	.uleb128 0
.LLSDACSE8:
	.text
	.size	silver_platform__write_file, .-silver_platform__write_file
	.align 2
	.type	silver_platform__run__B72b___finalizer.3, @function
silver_platform__run__B72b___finalizer.3:
.LFB11:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE11:
	.size	silver_platform__run__B72b___finalizer.3, .-silver_platform__run__B72b___finalizer.3
	.section	.rodata
	.align 8
.LC20:
	.ascii	"failed precondition from silver_platform.ads:57"
	.align 8
.LC21:
	.ascii	"failed precondition from silver_platform.ads:58"
	.text
	.align 2
	.globl	silver_platform__run
	.type	silver_platform__run, @function
silver_platform__run:
.LFB10:
	.loc 2 142 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA10
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB11:
	subq	$88, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -112(%rbp)
	movq	%rdx, -104(%rbp)
	.loc 2 142 4
	leaq	16(%rbp), %rax
	.loc 2 142 4 is_stmt 0 discriminator 1
	movq	%rax, -72(%rbp)
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	movq	-104(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L120
	.loc 2 142 4 discriminator 2
	movslq	%edx, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	movslq	%eax, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rcx
	sbbq	%rdi, %rbx
	addq	$1, %rcx
	adcq	$0, %rbx
	jmp	.L121
.L120:
	.loc 2 142 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L121:
.LBB24:
	.loc 2 142 4 discriminator 4
	movslq	%eax, %rsi
	cmpl	%eax, %edx
	.loc 2 142 4 discriminator 7
	cmpl	%eax, %edx
	.loc 2 142 4 discriminator 10
	cmpl	%eax, %edx
	.loc 1 57 33 is_stmt 1
	movl	%ecx, %edi
	.loc 1 57 18
	testl	%edi, %edi
	jle	.L128
	.loc 1 57 33 discriminator 1
	cmpl	$16384, %ecx
	jle	.L129
.L128:
.LBB25:
	.loc 1 57 18 discriminator 2
	leaq	.LC20(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L129:
.LBE25:
	.loc 1 58 23
	movl	$1, %r11d
	cmpl	%edx, %eax
	jg	.L130
.L133:
.LBB26:
.LBB27:
	.loc 1 58 31 discriminator 2
	movq	-112(%rbp), %rdi
	movslq	%eax, %rcx
	movq	%rcx, %r10
	subq	%rsi, %r10
	addq	%r10, %rdi
	movq	%rdi, -48(%rbp)
	.loc 1 58 55 discriminator 2
	movq	-112(%rbp), %rdi
	subq	%rsi, %rcx
	movzbl	(%rdi,%rcx), %ecx
	.loc 1 58 23 discriminator 3
	testb	%cl, %cl
	jne	.L131
	.loc 1 58 23 is_stmt 0 discriminator 4
	movl	$0, %r11d
	jmp	.L130
.L131:
.LBE27:
	.loc 1 58 23 discriminator 5
	cmpl	%edx, %eax
	je	.L130
	.loc 1 58 23 discriminator 6
	addl	$1, %eax
	jmp	.L133
.L130:
.LBE26:
	.loc 1 58 23 discriminator 7
	movl	%r11d, %eax
	xorl	$1, %eax
	.loc 1 57 18 is_stmt 1 discriminator 3
	testb	%al, %al
	je	.L134
.LBB28:
	.loc 1 57 18 is_stmt 0 discriminator 4
	leaq	.LC21(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.LEHE11:
.L134:
	leaq	-96(%rbp), %rax
	movq	%rax, %rdi
.LEHB12:
	call	system__secondary_stack__ss_mark@PLT
.LBE28:
.LBB29:
	.loc 2 145 39 is_stmt 1
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movl	$1, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	interfaces__c__to_c__2@PLT
	.loc 2 145 17 discriminator 1
	movq	%rax, %rdi
	call	system@PLT
.LEHE12:
	.loc 2 145 17 is_stmt 0 discriminator 2
	movl	%eax, -36(%rbp)
	.loc 2 145 0 is_stmt 1 discriminator 2
	movl	$1, %ebx
.L139:
	.loc 2 145 0 is_stmt 0 discriminator 3
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
.LEHB13:
	call	silver_platform__run__B72b___finalizer.3
.LEHE13:
	.loc 2 145 0 discriminator 4
	cmpl	$1, %ebx
	jne	.L135
	.loc 2 145 0 discriminator 6
	movl	$1, %eax
.L141:
	.loc 2 145 0 discriminator 7
	cmpl	$1, %eax
	jne	.L136
	.loc 2 145 0 discriminator 8
	nop
.LBE29:
	.loc 2 150 25 is_stmt 1
	cmpl	$0, -36(%rbp)
	sete	%al
	.loc 2 150 15
	movb	%al, -49(%rbp)
	.loc 2 151 8
	nop
.LBE24:
	.loc 2 151 8 is_stmt 0 discriminator 1
	movzbl	-49(%rbp), %eax
	.loc 2 151 8 discriminator 3
	jmp	.L144
.L142:
	movq	%rax, %r13
	movl	$0, %ebx
.LBB31:
.LBB30:
	.loc 2 145 14 is_stmt 1 discriminator 9
	jmp	.L139
.L135:
	movq	%r13, %r12
	jmp	.L140
.L143:
	movq	%rax, %r12
.L140:
	movl	$0, %eax
	jmp	.L141
.L136:
	movq	%r12, %rax
	movq	%rax, %rdi
.LEHB14:
	call	_Unwind_Resume@PLT
.L144:
.LBE30:
.LBE31:
	.loc 2 151 8
	addq	$88, %rsp
.LEHE14:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE10:
	.section	.gcc_except_table
.LLSDA10:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE10-.LLSDACSB10
.LLSDACSB10:
	.uleb128 .LEHB11-.LFB10
	.uleb128 .LEHE11-.LEHB11
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB12-.LFB10
	.uleb128 .LEHE12-.LEHB12
	.uleb128 .L142-.LFB10
	.uleb128 0
	.uleb128 .LEHB13-.LFB10
	.uleb128 .LEHE13-.LEHB13
	.uleb128 .L143-.LFB10
	.uleb128 0
	.uleb128 .LEHB14-.LFB10
	.uleb128 .LEHE14-.LEHB14
	.uleb128 0
	.uleb128 0
.LLSDACSE10:
	.text
	.size	silver_platform__run, .-silver_platform__run
	.align 2
	.type	silver_platform__run_application__B_4___finalizer.4, @function
silver_platform__run_application__B_4___finalizer.4:
.LFB13:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE13:
	.size	silver_platform__run_application__B_4___finalizer.4, .-silver_platform__run_application__B_4___finalizer.4
	.section	.rodata
	.align 8
.LC22:
	.ascii	"failed precondition from silver_platform.ads:67"
	.align 8
.LC23:
	.ascii	"failed precondition from silver_platform.ads:68"
.LC24:
	.ascii	"silver_platform.adb:179"
.LC25:
	.ascii	"silver_platform.adb:191"
	.align 8
.LC3:
	.zero	8
	.align 8
.LC4:
	.long	1
	.long	23
	.text
	.align 2
	.globl	silver_platform__run_application
	.type	silver_platform__run_application, @function
silver_platform__run_application:
.LFB12:
	.loc 2 153 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA12
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB15:
	subq	$232, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -176(%rbp)
	movq	%rbx, -168(%rbp)
	movl	%edx, -180(%rbp)
	.loc 2 153 4
	leaq	16(%rbp), %rax
	.loc 2 153 4 is_stmt 0 discriminator 1
	movq	%rax, -120(%rbp)
	movq	-168(%rbp), %rax
	movl	(%rax), %edx
	movq	-168(%rbp), %rax
	movl	4(%rax), %eax
.LBB32:
	cmpl	%edx, %eax
	.loc 2 153 4 discriminator 4
	cmpl	%edx, %eax
	.loc 2 153 4 discriminator 7
	cmpl	%edx, %eax
	.loc 1 67 18 is_stmt 1
	movq	-176(%rbp), %rdx
	movq	-168(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_platform__valid_path
	.loc 1 67 18 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L154
.LBB33:
	.loc 1 67 18 discriminator 2
	leaq	.LC22(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L154:
.LBE33:
	.loc 1 68 54 is_stmt 1
	call	ada__command_line__argument_count@PLT
	.loc 1 68 37 discriminator 1
	cmpl	%eax, -180(%rbp)
	setle	%al
	xorl	$1, %eax
	.loc 1 67 18 discriminator 3
	testb	%al, %al
	je	.L155
.LBB34:
	.loc 1 67 18 is_stmt 0 discriminator 4
	leaq	.LC23(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L155:
.LBE34:
	.loc 2 158 47 is_stmt 1
	call	ada__command_line__argument_count@PLT
	.loc 2 158 63 discriminator 1
	movl	$0, %edx
	subl	-180(%rbp), %eax
	jno	.L156
	movl	$1, %edx
.L156:
	movl	%eax, %ecx
	.loc 2 158 63 is_stmt 0 discriminator 2
	movl	%edx, %eax
	testl	%eax, %eax
	je	.L158
	.loc 2 158 63 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$158, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L158:
	.loc 2 158 63 discriminator 5
	movl	%ecx, %ebx
	.loc 2 158 9 is_stmt 1 discriminator 6
	movl	$0, %eax
	testl	%ebx, %ebx
	cmovns	%ebx, %eax
	cltq
	salq	$4, %rax
	addq	$8, %rax
	movq	%rax, %rdi
	call	__gnat_malloc@PLT
	.loc 2 158 9 is_stmt 0 discriminator 7
	movl	$1, (%rax)
	movl	%ebx, 4(%rax)
	leaq	8(%rax), %rdx
	movq	%rdx, -256(%rbp)
	movq	%rax, -248(%rbp)
	movq	-256(%rbp), %rsi
	movq	-248(%rbp), %rdi
	.loc 2 158 27 is_stmt 1 discriminator 7
	testl	%ebx, %ebx
	jle	.L159
.LBB35:
	.loc 2 158 27 is_stmt 0 discriminator 8
	movl	$1, %ecx
.L160:
	.loc 2 158 27 discriminator 9
	movq	%rsi, %r8
	movslq	%ecx, %rdx
	leaq	-1(%rdx), %rax
	salq	$4, %rax
	addq	%r8, %rax
	movq	$0, (%rax)
	.loc 2 158 27 discriminator 10
	leaq	-1(%rdx), %rax
	salq	$4, %rax
	addq	%r8, %rax
	addq	$8, %rax
	leaq	.LC3(%rip), %rdx
	movq	%rdx, (%rax)
	.loc 2 158 27 discriminator 11
	cmpl	%ebx, %ecx
	je	.L159
	.loc 2 158 27 discriminator 12
	addl	$1, %ecx
	jmp	.L160
.L159:
.LBE35:
	.loc 2 157 7 is_stmt 1
	movq	%rsi, -160(%rbp)
	movq	%rdi, -152(%rbp)
	.loc 2 160 14
	movl	$-1, -108(%rbp)
	.loc 2 162 20
	movq	-160(%rbp), %rax
	testq	%rax, %rax
	jne	.L161
	.loc 2 162 20 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$162, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Access_Check@PLT
.LEHE15:
.L161:
	.loc 2 162 24 is_stmt 1 discriminator 2
	movq	-152(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -56(%rbp)
	movq	-152(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -60(%rbp)
	.loc 2 162 11 discriminator 2
	movl	-56(%rbp), %eax
	cmpl	-60(%rbp), %eax
	jg	.L162
.LBB36:
	.loc 2 162 11 is_stmt 0 discriminator 3
	movl	-56(%rbp), %eax
	movl	%eax, -52(%rbp)
.L200:
	leaq	-144(%rbp), %rax
	movq	%rax, %rdi
.LEHB16:
	call	system__secondary_stack__ss_mark@PLT
.LBB37:
	.loc 2 173 70 is_stmt 1
	movl	$0, %ecx
	movl	-52(%rbp), %edx
	movl	-180(%rbp), %eax
	addl	%edx, %eax
	jno	.L163
	movl	$1, %ecx
.L163:
	movl	%eax, %edx
	.loc 2 173 70 is_stmt 0 discriminator 1
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L165
	.loc 2 173 70 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$173, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L165:
	.loc 2 173 70 discriminator 4
	movl	%edx, %eax
	.loc 2 173 70 discriminator 5
	testl	%eax, %eax
	jg	.L166
	.loc 2 173 70 discriminator 6
	leaq	.LC12(%rip), %rax
	movl	$173, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L166:
	.loc 2 173 53 is_stmt 1 discriminator 7
	movl	%eax, %edi
	call	silver_runtime__argument@PLT
	.loc 2 173 53 is_stmt 0 discriminator 8
	movq	%rax, %r12
	movq	%rdx, %r13
	movq	%r13, %rax
	movl	(%rax), %eax
	movl	%eax, -64(%rbp)
	movq	%r13, %rax
	movl	4(%rax), %eax
	movl	%eax, -68(%rbp)
	.loc 2 173 13 is_stmt 1 discriminator 8
	movl	-64(%rbp), %eax
	cltq
	movq	%rax, -80(%rbp)
	movl	-68(%rbp), %eax
	cmpl	-64(%rbp), %eax
	jl	.L167
	.loc 2 173 13 is_stmt 0 discriminator 9
	movl	-68(%rbp), %eax
	cltq
	movq	%rax, -88(%rbp)
	jmp	.L168
.L167:
	.loc 2 173 13 discriminator 10
	movl	-64(%rbp), %eax
	cltq
	subq	$1, %rax
	movq	%rax, -88(%rbp)
.L168:
	.loc 2 173 13 discriminator 11
	movl	-68(%rbp), %eax
	cmpl	-64(%rbp), %eax
	.loc 2 173 13 discriminator 14
	movl	-68(%rbp), %eax
	cmpl	-64(%rbp), %eax
	jl	.L171
	.loc 2 173 13 discriminator 15
	movl	-68(%rbp), %eax
	movslq	%eax, %rdx
	movl	-64(%rbp), %eax
	cltq
	subq	%rax, %rdx
	leaq	1(%rdx), %r14
	jmp	.L172
.L171:
	.loc 2 173 13 discriminator 16
	movl	$0, %r14d
.L172:
	.loc 2 173 53 is_stmt 1 discriminator 17
	movl	-68(%rbp), %eax
	cmpl	-64(%rbp), %eax
	jl	.L173
	.loc 2 173 53 is_stmt 0 discriminator 18
	cmpl	$0, -64(%rbp)
	jg	.L173
	.loc 2 173 53 discriminator 19
	leaq	.LC12(%rip), %rax
	movl	$173, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L173:
	.loc 2 173 13 is_stmt 1 discriminator 20
	movq	%r12, -96(%rbp)
	.loc 2 177 17
	movl	$0, %edi
	movl	-64(%rbp), %eax
	cmpl	-68(%rbp), %eax
	jg	.L174
.LBB38:
	.loc 2 177 17 is_stmt 0 discriminator 1
	movl	-64(%rbp), %edx
.L177:
.LBB39:
	.loc 2 177 26 is_stmt 1 discriminator 2
	movq	%r12, %rsi
	movslq	%edx, %rcx
	movq	%rcx, %rax
	subq	-80(%rbp), %rax
	addq	%rsi, %rax
	movq	%rax, -104(%rbp)
	.loc 2 177 43 discriminator 2
	movq	%r12, %rsi
	movq	%rcx, %rax
	subq	-80(%rbp), %rax
	movzbl	(%rsi,%rax), %eax
	.loc 2 177 17 discriminator 3
	testb	%al, %al
	jne	.L175
	.loc 2 177 17 is_stmt 0 discriminator 4
	movl	$1, %edi
	jmp	.L174
.L175:
.LBE39:
	.loc 2 177 17 discriminator 5
	cmpl	-68(%rbp), %edx
	je	.L174
	.loc 2 177 17 discriminator 6
	addl	$1, %edx
	jmp	.L177
.L174:
.LBE38:
	.loc 2 177 13 is_stmt 1 discriminator 7
	testb	%dil, %dil
	je	.L178
	.loc 2 178 16
	movq	-160(%rbp), %rdx
	movq	-152(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_process_runtime__free_list@PLT
	movq	%rax, -160(%rbp)
	movq	%rdx, -152(%rbp)
	.loc 2 179 36
	movq	-160(%rbp), %rax
	.loc 2 179 31
	testq	%rax, %rax
	je	.L179
.LBB40:
	.loc 2 179 31 is_stmt 0 discriminator 1
	leaq	.LC24(%rip), %rax
	movq	%rax, -240(%rbp)
	leaq	.LC4(%rip), %rax
	movq	%rax, -232(%rbp)
	movq	-240(%rbp), %rbx
	movq	-232(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L179:
.LBE40:
	.loc 2 180 16 is_stmt 1
	movl	$0, %ebx
	jmp	.L180
.L178:
	.loc 2 182 13
	movq	-160(%rbp), %rax
	testq	%rax, %rax
	jne	.L181
	.loc 2 182 13 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$182, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Access_Check@PLT
.L181:
	.loc 2 182 13 discriminator 2
	movq	-152(%rbp), %rax
	movl	(%rax), %edx
	movq	-152(%rbp), %rax
	movl	4(%rax), %eax
	cmpl	%edx, -52(%rbp)
	jl	.L182
	.loc 2 182 13 discriminator 3
	cmpl	%eax, -52(%rbp)
	jle	.L183
.L182:
	.loc 2 182 13 discriminator 4
	leaq	.LC12(%rip), %rax
	movl	$182, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L183:
	movl	-68(%rbp), %eax
	cmpl	-64(%rbp), %eax
	movl	-68(%rbp), %eax
	cmpl	-64(%rbp), %eax
	movl	-68(%rbp), %eax
	cmpl	-64(%rbp), %eax
	movl	-68(%rbp), %eax
	cmpl	-64(%rbp), %eax
	.loc 2 182 29 is_stmt 1 discriminator 5
	movl	-68(%rbp), %eax
	cmpl	-64(%rbp), %eax
	jl	.L192
	.loc 2 182 29 is_stmt 0 discriminator 6
	movl	-68(%rbp), %eax
	movslq	%eax, %rdx
	movl	-64(%rbp), %eax
	cltq
	subq	%rax, %rdx
	leaq	12(%rdx), %rax
	andq	$-4, %rax
	jmp	.L193
.L192:
	.loc 2 182 29 discriminator 7
	movl	$8, %eax
.L193:
	.loc 2 182 29 discriminator 8
	movq	%rax, %rdi
	call	__gnat_malloc@PLT
	movq	%rax, %rbx
	.loc 2 182 29 discriminator 9
	movl	-64(%rbp), %eax
	movl	%eax, (%rbx)
	movl	-68(%rbp), %eax
	movl	%eax, 4(%rbx)
	movq	%r12, %rdx
	leaq	8(%rbx), %rax
	movq	%rdx, %rcx
	movq	%r14, %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 182 29 discriminator 10
	leaq	8(%rbx), %rax
	movq	%rax, -224(%rbp)
	movq	%rbx, %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rcx
	movq	-216(%rbp), %rbx
	.loc 2 182 26 is_stmt 1 discriminator 10
	movq	-160(%rbp), %rdx
	movq	-152(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movl	-52(%rbp), %esi
	movslq	%esi, %rsi
	subq	%rax, %rsi
	movq	%rsi, %rax
	salq	$4, %rax
	addq	%rdx, %rax
	movq	%rcx, (%rax)
	movq	%rbx, 8(%rax)
.LEHE16:
	.loc 2 183 0
	movl	$2, %ebx
.L180:
	.loc 2 183 0 is_stmt 0 discriminator 1
	leaq	-144(%rbp), %rax
	movq	%rax, %r10
.LEHB17:
	call	silver_platform__run_application__B_4___finalizer.4
.LEHE17:
	.loc 2 183 0 discriminator 2
	cmpl	$1, %ebx
	je	.L194
	cmpl	$2, %ebx
	je	.L209
	movl	$0, %eax
	jmp	.L197
.L209:
	.loc 2 183 13 is_stmt 1 discriminator 4
	movl	$2, %eax
.L197:
	.loc 2 183 13 is_stmt 0 discriminator 5
	cmpl	$1, %eax
	je	.L198
	cmpl	$2, %eax
	jne	.L199
	.loc 2 183 13 discriminator 6
	nop
.LBE37:
	.loc 2 162 11 is_stmt 1 discriminator 4
	movl	-52(%rbp), %eax
	cmpl	-60(%rbp), %eax
	je	.L162
	.loc 2 162 11 is_stmt 0 discriminator 5
	addl	$1, -52(%rbp)
	.loc 2 184 15 is_stmt 1
	jmp	.L200
.L162:
.LBE36:
	.loc 2 188 41
	movq	-160(%rbp), %rax
	testq	%rax, %rax
	jne	.L201
	.loc 2 188 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$188, %esi
	movq	%rax, %rdi
.LEHB18:
	call	__gnat_rcheck_CE_Access_Check@PLT
.L201:
	.loc 2 188 17 is_stmt 1 discriminator 2
	movq	-160(%rbp), %rax
	movq	-152(%rbp), %rdx
	movq	-176(%rbp), %rdi
	movq	-168(%rbp), %rsi
	movq	%rdx, %rcx
	movq	%rax, %rdx
	call	silver_process_runtime__spawn@PLT
	.loc 2 188 14 discriminator 3
	movl	%eax, -108(%rbp)
	.loc 2 190 7
	movq	-160(%rbp), %rdx
	movq	-152(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_process_runtime__free_list@PLT
	movq	%rax, -160(%rbp)
	movq	%rdx, -152(%rbp)
	.loc 2 191 27
	movq	-160(%rbp), %rax
	.loc 2 191 22
	testq	%rax, %rax
	je	.L199
.LBB42:
	.loc 2 191 22 is_stmt 0 discriminator 1
	leaq	.LC25(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC4(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rcx
	movq	-200(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L199:
.LBE42:
.LBE32:
	.loc 2 192 8 is_stmt 1 discriminator 2
	movl	-108(%rbp), %eax
	.loc 2 192 8 is_stmt 0 discriminator 4
	jmp	.L210
.L207:
	movq	%rax, -264(%rbp)
	movl	$1, %ebx
.LBB44:
.LBB43:
.LBB41:
	.loc 2 172 10 is_stmt 1
	jmp	.L180
.L194:
	movq	-264(%rbp), %rax
	movq	%rax, -192(%rbp)
	jmp	.L206
.L208:
	movq	%rax, -192(%rbp)
.L206:
	movl	$1, %eax
	jmp	.L197
.L198:
	movq	-192(%rbp), %rax
	movq	%rax, %rdi
	call	_Unwind_Resume@PLT
.L210:
.LBE41:
.LBE43:
.LBE44:
	.loc 2 192 8
	addq	$232, %rsp
.LEHE18:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE12:
	.section	.gcc_except_table
.LLSDA12:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE12-.LLSDACSB12
.LLSDACSB12:
	.uleb128 .LEHB15-.LFB12
	.uleb128 .LEHE15-.LEHB15
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB16-.LFB12
	.uleb128 .LEHE16-.LEHB16
	.uleb128 .L207-.LFB12
	.uleb128 0
	.uleb128 .LEHB17-.LFB12
	.uleb128 .LEHE17-.LEHB17
	.uleb128 .L208-.LFB12
	.uleb128 0
	.uleb128 .LEHB18-.LFB12
	.uleb128 .LEHE18-.LEHB18
	.uleb128 0
	.uleb128 0
.LLSDACSE12:
	.text
	.size	silver_platform__run_application, .-silver_platform__run_application
	.align 2
	.type	silver_platform__create_workspace___wrapped_statements___finalizer.6, @function
silver_platform__create_workspace___wrapped_statements___finalizer.6:
.LFB16:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE16:
	.size	silver_platform__create_workspace___wrapped_statements___finalizer.6, .-silver_platform__create_workspace___wrapped_statements___finalizer.6
	.section	.rodata
.LC26:
	.ascii	"XXXXXX"
	.align 8
.LC28:
	.ascii	"Loop_Invariant failed at silver_platform.adb:223"
	.align 8
.LC6:
	.long	1
	.long	6
	.align 8
.LC7:
	.long	1
	.long	54
	.align 8
.LC8:
	.long	1
	.long	67
	.align 8
.LC5:
	.long	1
	.long	82
	.text
	.align 2
	.type	silver_platform__create_workspace___wrapped_statements.5, @function
silver_platform__create_workspace___wrapped_statements.5:
.LFB15:
	.loc 2 194 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA15
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB19:
	subq	$296, %rsp
.LEHE19:
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%rbx, -224(%rbp)
	movq	%r10, -216(%rbp)
	.loc 2 194 4
	leaq	16(%rbp), %rax
	.loc 2 194 4 is_stmt 0 discriminator 1
	movq	%rax, -184(%rbp)
	leaq	-208(%rbp), %rax
	movq	%rax, %rdi
.LEHB20:
	call	system__secondary_stack__ss_mark@PLT
	.loc 2 198 10 is_stmt 1
	movl	$0, %r12d
	leaq	.LC3(%rip), %r13
	movzbl	9(%rbx), %eax
	testb	%al, %al
	je	.L214
	.loc 2 198 28 discriminator 1
	leaq	8+C189b___UNC.8(%rip), %r12
	leaq	C189b___UNC.8(%rip), %r13
	jmp	.L215
.L214:
	.loc 2 198 56 discriminator 2
	leaq	8+C190b___UNC.7(%rip), %r12
	leaq	C190b___UNC.7(%rip), %r13
.L215:
	.loc 2 197 7
	movq	%r12, -176(%rbp)
	movq	%r13, -168(%rbp)
	.loc 2 199 71
	movq	%r13, %rax
	movl	4(%rax), %edx
	movq	%r13, %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L216
	.loc 2 199 71 is_stmt 0 discriminator 1
	movq	%r13, %rax
	movl	4(%rax), %edx
	movq	%r13, %rax
	movl	(%rax), %eax
	subl	%eax, %edx
	leal	1(%rdx), %eax
	jmp	.L217
.L216:
	.loc 2 199 71 discriminator 2
	movl	$0, %eax
.L217:
	.loc 2 199 71 discriminator 3
	leal	6(%rax), %edx
	testl	%eax, %eax
	je	.L218
	.loc 2 199 71 discriminator 4
	movq	%r13, %rax
	movl	(%rax), %eax
	movl	%eax, -52(%rbp)
	jmp	.L219
.L218:
	.loc 2 199 71 discriminator 5
	movl	$1, -52(%rbp)
.L219:
	.loc 2 199 71 discriminator 6
	subl	$1, %edx
	movl	-52(%rbp), %eax
	addl	%edx, %eax
	movl	%eax, -64(%rbp)
	movl	-52(%rbp), %eax
	cltq
	movq	%rax, -72(%rbp)
	movl	-64(%rbp), %eax
	cltq
	movq	%rax, -80(%rbp)
	movl	-64(%rbp), %eax
	movslq	%eax, %rdx
	movl	-52(%rbp), %eax
	cltq
	subq	%rax, %rdx
	leaq	1(%rdx), %rax
	movl	$1, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_allocate@PLT
	.loc 2 199 71 discriminator 7
	movq	%rax, %rbx
	movq	%rbx, -88(%rbp)
.LBB45:
	leaq	.LC26(%rip), %r14
	leaq	.LC6(%rip), %r15
	movq	%rbx, -320(%rbp)
	movl	-52(%rbp), %eax
	movl	%eax, -156(%rbp)
	movl	-64(%rbp), %eax
	movl	%eax, -152(%rbp)
	leaq	-156(%rbp), %rax
	movq	%rax, -312(%rbp)
	movq	-320(%rbp), %rax
	movq	-312(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rdx, %rax
	movq	%r14, %r8
	movq	%r15, %r9
	movq	%r12, %rdx
	movq	%r13, %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	system__concat_2__str_concat_2@PLT
.LBE45:
	.loc 2 199 57 is_stmt 1 discriminator 8
	movq	%rbx, -304(%rbp)
	movl	-52(%rbp), %eax
	movl	%eax, -148(%rbp)
	movl	-64(%rbp), %eax
	movl	%eax, -144(%rbp)
	leaq	-148(%rbp), %rax
	movq	%rax, -296(%rbp)
	movq	-304(%rbp), %rax
	movq	-296(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movl	$1, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	interfaces__c__to_c__2@PLT
.LEHE20:
	.loc 2 199 57 is_stmt 0 discriminator 9
	movq	%rax, %r14
	movq	%rdx, %r15
	movq	%r15, %rax
	movq	(%rax), %rax
	movq	%rax, -96(%rbp)
	movq	%r15, %rax
	movq	8(%rax), %rax
	movq	%rax, -104(%rbp)
	.loc 2 199 7 is_stmt 1 discriminator 9
	movq	-104(%rbp), %rax
	cmpq	-96(%rbp), %rax
	jnb	.L220
	.loc 2 199 7 is_stmt 0 discriminator 10
	movq	-96(%rbp), %rax
	subq	$1, %rax
	movq	%rax, -112(%rbp)
	jmp	.L221
.L220:
	.loc 2 199 7 discriminator 11
	movq	-104(%rbp), %rax
	movq	%rax, -112(%rbp)
.L221:
	.loc 2 199 7 discriminator 12
	movq	-104(%rbp), %rax
	cmpq	-96(%rbp), %rax
	.loc 2 199 7 discriminator 15
	movq	-104(%rbp), %rax
	cmpq	-96(%rbp), %rax
	.loc 2 199 57 is_stmt 1 discriminator 18
	movq	%r15, %rax
	movq	(%rax), %rbx
	movq	%r15, %rax
	movq	8(%rax), %rax
	movq	%rax, -304(%rbp)
	cmpq	%rbx, %rax
	.loc 2 199 57 is_stmt 0 discriminator 21
	cmpq	%rbx, %rax
	.loc 2 199 57 discriminator 24
	cmpq	%rbx, %rax
	.loc 2 199 7 is_stmt 1 discriminator 27
	movq	%r14, -120(%rbp)
	.loc 2 203 15
	movq	-224(%rbp), %rdi
	movq	(%rdi), %rax
	movl	$538976288, %edx
	movd	%edx, %xmm1
	pshufd	$0, %xmm1, %xmm0
.LEHB21:
	movups	%xmm0, (%rax)
	movups	%xmm0, 16(%rax)
	movups	%xmm0, 32(%rax)
	movups	%xmm0, 48(%rax)
	movups	%xmm0, 64(%rax)
	movd	%xmm0, %ecx
	movw	%cx, 80(%rax)
.LEHE21:
	.loc 2 204 15
	movl	$0, %eax
	movb	%al, 8(%rdi)
	.loc 2 205 38
	leaq	silver_build__artifacts_directory(%rip), %rax
	movq	%rax, -288(%rbp)
	leaq	.LC7(%rip), %rax
	movq	%rax, -280(%rbp)
	movq	-288(%rbp), %rax
	movq	-280(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movl	$1, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
.LEHB22:
	call	interfaces__c__to_c__2@PLT
	.loc 2 205 17 discriminator 1
	movl	$448, %esi
	movq	%rax, %rdi
	call	mkdir@PLT
	.loc 2 205 17 is_stmt 0 discriminator 2
	movl	%eax, -124(%rbp)
	.loc 2 208 7 is_stmt 1
	cmpl	$0, -124(%rbp)
	je	.L232
	.loc 2 208 22 discriminator 1
	cmpl	$-1, -124(%rbp)
	je	.L232
	.loc 2 209 10
	movl	$0, %ebx
	jmp	.L233
.L232:
	.loc 2 211 38
	leaq	silver_build__root_directory(%rip), %rax
	movq	%rax, -272(%rbp)
	leaq	.LC8(%rip), %rax
	movq	%rax, -264(%rbp)
	movq	-272(%rbp), %rax
	movq	-264(%rbp), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movl	$1, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	interfaces__c__to_c__2@PLT
	.loc 2 211 17 discriminator 1
	movl	$448, %esi
	movq	%rax, %rdi
	call	mkdir@PLT
	.loc 2 211 17 is_stmt 0 discriminator 2
	movl	%eax, -124(%rbp)
	.loc 2 212 7 is_stmt 1
	cmpl	$0, -124(%rbp)
	je	.L234
	.loc 2 212 22 discriminator 1
	cmpl	$-1, -124(%rbp)
	je	.L234
	.loc 2 213 10
	movl	$0, %ebx
	jmp	.L233
.L234:
	.loc 2 215 28
	cmpq	-96(%rbp), %rbx
	jne	.L235
	.loc 2 215 28 is_stmt 0 discriminator 1
	movq	-304(%rbp), %rax
	cmpq	-104(%rbp), %rax
	je	.L236
.L235:
	.loc 2 215 28 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$215, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L236:
	.loc 2 215 17 is_stmt 1 discriminator 3
	movq	%r14, %rax
	movq	%rax, %rdi
	call	mkdtemp@PLT
	.loc 2 215 14 discriminator 4
	movq	%rax, -136(%rbp)
	.loc 2 216 7
	cmpq	$0, -136(%rbp)
	je	.L237
	.loc 2 217 17
	movq	-104(%rbp), %rax
	cmpq	-96(%rbp), %rax
	jnb	.L238
	.loc 2 217 17 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$217, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L238:
	.loc 2 217 42 is_stmt 1 discriminator 2
	movq	%r14, %rdx
	movq	-104(%rbp), %rax
	subq	-96(%rbp), %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 217 42 is_stmt 0 discriminator 3
	testb	%al, %al
	setne	%al
	.loc 2 217 9 is_stmt 1 discriminator 3
	testb	%al, %al
	je	.L239
.L237:
	.loc 2 219 10
	movl	$0, %ebx
	jmp	.L233
.L239:
.LBB46:
	.loc 2 221 11
	movl	$1, -56(%rbp)
.L246:
	.loc 2 221 11 is_stmt 0 discriminator 1
	cmpl	$82, -56(%rbp)
	jg	.L240
	.loc 2 223 13 is_stmt 1
	cmpq	$0, -96(%rbp)
	jne	.L241
	.loc 2 224 13
	cmpq	$82, -104(%rbp)
	je	.L242
.L241:
.LBB47:
	.loc 2 223 13 discriminator 1
	leaq	.LC28(%rip), %rax
	movq	%rax, -256(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -248(%rbp)
	movq	-256(%rbp), %rbx
	movq	-248(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L242:
.LBE47:
	.loc 2 225 69
	cmpl	$0, -56(%rbp)
	jg	.L243
	.loc 2 225 69 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$225, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L243:
	.loc 2 225 84 is_stmt 1 discriminator 3
	movl	-56(%rbp), %eax
	subl	$1, %eax
	.loc 2 225 69 discriminator 3
	cltq
	.loc 2 225 47 discriminator 4
	cmpq	-96(%rbp), %rax
	jb	.L244
	.loc 2 225 47 is_stmt 0 discriminator 5
	cmpq	%rax, -104(%rbp)
	jnb	.L245
.L244:
	.loc 2 225 47 discriminator 6
	leaq	.LC12(%rip), %rax
	movl	$225, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L245:
	.loc 2 225 38 is_stmt 1 discriminator 7
	movq	%r14, %rdx
	.loc 2 225 84 discriminator 7
	movl	-56(%rbp), %eax
	subl	$1, %eax
	cltq
	.loc 2 225 38 discriminator 7
	subq	-96(%rbp), %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 225 23 discriminator 8
	movl	-56(%rbp), %edx
	movslq	%edx, %rbx
	.loc 2 225 38 discriminator 8
	movsbl	%al, %eax
	movl	%eax, %edi
	call	interfaces__c__to_ada@PLT
	.loc 2 225 23 discriminator 9
	movq	-224(%rbp), %rdi
	movq	(%rdi), %rdx
	movb	%al, -1(%rdx,%rbx)
	.loc 2 221 11 discriminator 2
	addl	$1, -56(%rbp)
	.loc 2 226 15
	jmp	.L246
.L240:
.LBE46:
	.loc 2 229 18
	movq	-224(%rbp), %rax
	movq	(%rax), %rax
	movq	%rax, -240(%rbp)
	leaq	.LC5(%rip), %rax
	movq	%rax, -232(%rbp)
	movq	-240(%rbp), %rbx
	movq	-232(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_platform__valid_path
	.loc 2 230 9
	testb	%al, %al
	je	.L247
	.loc 2 229 53 discriminator 2
	movq	%r13, %rax
	movl	4(%rax), %eax
	testl	%eax, %eax
	jle	.L248
	.loc 2 229 53 is_stmt 0 discriminator 3
	movq	%r13, %rax
	movl	4(%rax), %eax
	cmpl	$82, %eax
	jle	.L248
	.loc 2 229 53 discriminator 4
	leaq	.LC12(%rip), %rax
	movl	$229, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L248:
	.loc 2 229 45 is_stmt 1 discriminator 5
	movq	%r13, %rax
	movl	4(%rax), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovns	%eax, %edx
	movslq	%edx, %rdx
	.loc 2 229 69 discriminator 5
	testl	%eax, %eax
	jg	.L249
	.loc 2 229 69 is_stmt 0 discriminator 7
	movq	%r13, %rcx
	movl	4(%rcx), %esi
	movq	%r13, %rcx
	movl	(%rcx), %ecx
	cmpl	%ecx, %esi
	jl	.L250
.L249:
	.loc 2 229 69 discriminator 9
	movl	$0, %ecx
	testl	%eax, %eax
	cmovs	%ecx, %eax
	cltq
	movq	%r13, %rcx
	movl	4(%rcx), %esi
	movq	%r13, %rcx
	movl	(%rcx), %ecx
	cmpl	%ecx, %esi
	jl	.L251
	.loc 2 229 69 discriminator 10
	movq	%r13, %rcx
	movl	4(%rcx), %ecx
	movslq	%ecx, %rsi
	movq	%r13, %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	subq	%rcx, %rsi
	leaq	1(%rsi), %rcx
	jmp	.L252
.L251:
	.loc 2 229 69 discriminator 11
	movl	$0, %ecx
.L252:
	.loc 2 229 69 discriminator 12
	cmpq	%rax, %rcx
	jne	.L253
	.loc 2 229 69 discriminator 13
	movq	%r12, %rcx
	movq	-224(%rbp), %rax
	movq	(%rax), %rax
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcmp@PLT
	.loc 2 229 69 discriminator 14
	testl	%eax, %eax
	jne	.L253
.L250:
	.loc 2 229 69 discriminator 15
	movl	$1, %eax
	jmp	.L254
.L253:
	.loc 2 229 69 discriminator 16
	movl	$0, %eax
.L254:
	.loc 2 229 36 is_stmt 1 discriminator 17
	testb	%al, %al
	je	.L247
	.loc 2 230 19 discriminator 1
	movl	$1, %ecx
	.loc 2 230 27 discriminator 1
	movq	%r13, %rax
	movl	4(%rax), %eax
	.loc 2 230 48 discriminator 2
	cmpl	$2147483647, %eax
	jne	.L255
	.loc 2 230 27 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$230, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L255:
	.loc 2 230 27 is_stmt 0 discriminator 5
	movq	%r13, %rax
	movl	4(%rax), %eax
	.loc 2 230 27 discriminator 6
	addl	$1, %eax
	movl	%eax, -140(%rbp)
.LBB48:
	.loc 2 230 27 discriminator 7
	movl	-140(%rbp), %eax
	movl	%eax, -60(%rbp)
.L262:
	.loc 2 230 19 is_stmt 1 discriminator 8
	cmpl	$82, -60(%rbp)
	jg	.L256
	.loc 2 231 11
	cmpl	$0, -60(%rbp)
	jg	.L257
	.loc 2 231 11 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$231, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L257:
	.loc 2 231 31 is_stmt 1 discriminator 2
	movl	-60(%rbp), %eax
	cltq
	movq	-224(%rbp), %rdi
	movq	(%rdi), %rdx
	movzbl	-1(%rdx,%rax), %eax
	.loc 2 230 19 discriminator 9
	cmpb	$96, %al
	jbe	.L258
	.loc 2 231 31 discriminator 4
	movl	-60(%rbp), %eax
	cltq
	movq	(%rdi), %rdx
	movzbl	-1(%rdx,%rax), %eax
	.loc 2 231 31 is_stmt 0 discriminator 5
	cmpb	$122, %al
	jbe	.L259
.L258:
	.loc 2 231 44 is_stmt 1 discriminator 6
	movl	-60(%rbp), %eax
	cltq
	movq	-224(%rbp), %rbx
	movq	(%rbx), %rdx
	movzbl	-1(%rdx,%rax), %eax
	.loc 2 231 44 is_stmt 0 discriminator 7
	cmpb	$64, %al
	jbe	.L260
	.loc 2 231 44 discriminator 8
	movl	-60(%rbp), %eax
	cltq
	movq	(%rbx), %rdx
	movzbl	-1(%rdx,%rax), %eax
	.loc 2 231 44 discriminator 9
	cmpb	$90, %al
	jbe	.L259
.L260:
	.loc 2 231 57 is_stmt 1 discriminator 10
	movl	-60(%rbp), %eax
	cltq
	movq	-224(%rbp), %rsi
	movq	(%rsi), %rdx
	movzbl	-1(%rdx,%rax), %eax
	.loc 2 231 57 is_stmt 0 discriminator 11
	cmpb	$47, %al
	jbe	.L261
	.loc 2 231 57 discriminator 12
	movl	-60(%rbp), %eax
	cltq
	movq	(%rsi), %rdx
	movzbl	-1(%rdx,%rax), %eax
.LEHE22:
	.loc 2 231 57 discriminator 13
	cmpb	$57, %al
	jbe	.L259
.L261:
	.loc 2 230 19 is_stmt 1 discriminator 10
	movl	$0, %ecx
	jmp	.L256
.L259:
	.loc 2 230 19 is_stmt 0 discriminator 11
	addl	$1, -60(%rbp)
	jmp	.L262
.L256:
.LBE48:
	.loc 2 230 9 is_stmt 1 discriminator 12
	testb	%cl, %cl
	je	.L247
	.loc 2 230 9 is_stmt 0 discriminator 13
	movl	$1, %eax
	jmp	.L263
.L247:
	.loc 2 230 9 discriminator 14
	movl	$0, %eax
.L263:
	.loc 2 229 15 is_stmt 1 discriminator 18
	movq	-224(%rbp), %rbx
	movb	%al, 8(%rbx)
	.loc 2 232 8
	movl	$0, %ebx
.L233:
	.loc 2 232 0 discriminator 1
	leaq	-208(%rbp), %rax
	movq	%rax, %r10
.LEHB23:
	call	silver_platform__create_workspace___wrapped_statements___finalizer.6
.LEHE23:
	.loc 2 232 0 is_stmt 0 discriminator 2
	cmpl	$1, %ebx
	je	.L264
	movl	$0, %eax
.L269:
	.loc 2 232 8 is_stmt 1 discriminator 3
	cmpl	$1, %eax
	je	.L265
	.loc 2 232 8 is_stmt 0
	jmp	.L272
.L270:
	movq	%rax, -336(%rbp)
	movl	$1, %ebx
	.loc 2 194 4 is_stmt 1 discriminator 2
	jmp	.L233
.L264:
	movq	-336(%rbp), %rax
	movq	%rax, -328(%rbp)
	jmp	.L268
.L271:
	movq	%rax, -328(%rbp)
.L268:
	movl	$1, %eax
	jmp	.L269
.L265:
	movq	-328(%rbp), %rax
	movq	%rax, %rdi
.LEHB24:
	call	_Unwind_Resume@PLT
.L272:
	.loc 2 232 8
	addq	$296, %rsp
.LEHE24:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE15:
	.section	.gcc_except_table
.LLSDA15:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE15-.LLSDACSB15
.LLSDACSB15:
	.uleb128 .LEHB19-.LFB15
	.uleb128 .LEHE19-.LEHB19
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB20-.LFB15
	.uleb128 .LEHE20-.LEHB20
	.uleb128 .L270-.LFB15
	.uleb128 0
	.uleb128 .LEHB21-.LFB15
	.uleb128 .LEHE21-.LEHB21
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB22-.LFB15
	.uleb128 .LEHE22-.LEHB22
	.uleb128 .L270-.LFB15
	.uleb128 0
	.uleb128 .LEHB23-.LFB15
	.uleb128 .LEHE23-.LEHB23
	.uleb128 .L271-.LFB15
	.uleb128 0
	.uleb128 .LEHB24-.LFB15
	.uleb128 .LEHE24-.LEHB24
	.uleb128 0
	.uleb128 0
.LLSDACSE15:
	.text
	.size	silver_platform__create_workspace___wrapped_statements.5, .-silver_platform__create_workspace___wrapped_statements.5
	.section	.rodata
	.align 8
.LC29:
	.ascii	"failed postcondition from silver_platform.ads:77"
	.text
	.align 2
	.globl	silver_platform__create_workspace
	.type	silver_platform__create_workspace, @function
silver_platform__create_workspace:
.LFB14:
	.loc 2 194 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA14
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB25:
	subq	$136, %rsp
.LEHE25:
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -168(%rbp)
	movb	%sil, -169(%rbp)
	.loc 2 194 4
	leaq	16(%rbp), %rax
	.loc 2 194 4 is_stmt 0 discriminator 1
	movq	%rax, -64(%rbp)
	movq	-168(%rbp), %rax
	movq	%rax, -80(%rbp)
	movzbl	-169(%rbp), %eax
	movb	%al, -71(%rbp)
.LBB49:
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
.LEHB26:
	call	silver_platform__create_workspace___wrapped_statements.5
	.loc 1 77 20 is_stmt 1
	movzbl	-72(%rbp), %eax
	testb	%al, %al
	je	.L274
	.loc 1 77 36 discriminator 1
	movq	-80(%rbp), %rax
	movq	%rax, %r14
	leaq	.LC5(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_platform__valid_path
	.loc 1 77 36 is_stmt 0 discriminator 2
	xorl	$1, %eax
	.loc 1 80 20 is_stmt 1
	testb	%al, %al
	jne	.L275
	.loc 1 79 23
	movzbl	-71(%rbp), %eax
	testb	%al, %al
	je	.L276
	.loc 1 79 23 is_stmt 0 discriminator 1
	movq	silver_platform__image_workspace_prefix(%rip), %rax
	movq	8+silver_platform__image_workspace_prefix(%rip), %rdx
	movq	%rax, -160(%rbp)
	movq	%rdx, -152(%rbp)
	movq	16+silver_platform__image_workspace_prefix(%rip), %rax
	movq	24+silver_platform__image_workspace_prefix(%rip), %rdx
	movq	%rax, -144(%rbp)
	movq	%rdx, -136(%rbp)
	movq	32+silver_platform__image_workspace_prefix(%rip), %rax
	movq	40+silver_platform__image_workspace_prefix(%rip), %rdx
	movq	%rax, -128(%rbp)
	movq	%rdx, -120(%rbp)
	movq	48+silver_platform__image_workspace_prefix(%rip), %rax
	movq	56+silver_platform__image_workspace_prefix(%rip), %rdx
	movq	%rax, -112(%rbp)
	movq	%rdx, -104(%rbp)
	movq	60+silver_platform__image_workspace_prefix(%rip), %rax
	movq	68+silver_platform__image_workspace_prefix(%rip), %rdx
	movq	%rax, -100(%rbp)
	movq	%rdx, -92(%rbp)
	jmp	.L277
.L276:
	.loc 1 79 23 discriminator 2
	movq	silver_platform__workspace_prefix(%rip), %rax
	movq	8+silver_platform__workspace_prefix(%rip), %rdx
	movq	%rax, -160(%rbp)
	movq	%rdx, -152(%rbp)
	movq	16+silver_platform__workspace_prefix(%rip), %rax
	movq	24+silver_platform__workspace_prefix(%rip), %rdx
	movq	%rax, -144(%rbp)
	movq	%rdx, -136(%rbp)
	movq	32+silver_platform__workspace_prefix(%rip), %rax
	movq	40+silver_platform__workspace_prefix(%rip), %rdx
	movq	%rax, -128(%rbp)
	movq	%rdx, -120(%rbp)
	movq	48+silver_platform__workspace_prefix(%rip), %rax
	movq	56+silver_platform__workspace_prefix(%rip), %rdx
	movq	%rax, -112(%rbp)
	movq	%rdx, -104(%rbp)
	movq	60+silver_platform__workspace_prefix(%rip), %rax
	movq	68+silver_platform__workspace_prefix(%rip), %rdx
	movq	%rax, -100(%rbp)
	movq	%rdx, -92(%rbp)
.L277:
	.loc 1 78 65 is_stmt 1
	movq	-80(%rbp), %rax
	movq	%rax, %rcx
	leaq	-160(%rbp), %rax
	movl	$76, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcmp@PLT
	.loc 1 78 65 is_stmt 0 discriminator 1
	testl	%eax, %eax
	sete	%al
	xorl	$1, %eax
	.loc 1 78 20 is_stmt 1 discriminator 1
	testb	%al, %al
	jne	.L275
	.loc 1 80 30 discriminator 1
	movl	$1, %ecx
.LBB50:
	.loc 1 80 38 discriminator 1
	movl	$77, -52(%rbp)
.L283:
	.loc 1 80 30 discriminator 2
	cmpl	$82, -52(%rbp)
	jg	.L278
	.loc 1 81 42
	movl	-52(%rbp), %eax
	cltq
	movq	-80(%rbp), %rdx
	movzbl	-1(%rdx,%rax), %eax
	.loc 1 80 30 discriminator 3
	cmpb	$96, %al
	jbe	.L279
	.loc 1 81 42 discriminator 2
	movl	-52(%rbp), %eax
	cltq
	movq	-80(%rbp), %rdx
	movzbl	-1(%rdx,%rax), %eax
	.loc 1 81 42 is_stmt 0 discriminator 3
	cmpb	$122, %al
	jbe	.L280
.L279:
	.loc 1 81 55 is_stmt 1 discriminator 4
	movl	-52(%rbp), %eax
	cltq
	movq	-80(%rbp), %rdx
	movzbl	-1(%rdx,%rax), %eax
	.loc 1 81 55 is_stmt 0 discriminator 5
	cmpb	$64, %al
	jbe	.L281
	.loc 1 81 55 discriminator 6
	movl	-52(%rbp), %eax
	cltq
	movq	-80(%rbp), %rdx
	movzbl	-1(%rdx,%rax), %eax
	.loc 1 81 55 discriminator 7
	cmpb	$90, %al
	jbe	.L280
.L281:
	.loc 1 81 68 is_stmt 1 discriminator 8
	movl	-52(%rbp), %eax
	cltq
	movq	-80(%rbp), %rdx
	movzbl	-1(%rdx,%rax), %eax
	.loc 1 81 68 is_stmt 0 discriminator 9
	cmpb	$47, %al
	jbe	.L282
	.loc 1 81 68 discriminator 10
	movl	-52(%rbp), %eax
	cltq
	movq	-80(%rbp), %rdx
	movzbl	-1(%rdx,%rax), %eax
	.loc 1 81 68 discriminator 11
	cmpb	$57, %al
	jbe	.L280
.L282:
	.loc 1 80 30 is_stmt 1 discriminator 4
	movl	$0, %ecx
	jmp	.L278
.L280:
	.loc 1 80 30 is_stmt 0 discriminator 5
	addl	$1, -52(%rbp)
	jmp	.L283
.L278:
.LBE50:
	.loc 1 80 30 discriminator 6
	movl	%ecx, %eax
	xorl	$1, %eax
	.loc 1 80 20 is_stmt 1 discriminator 6
	testb	%al, %al
	je	.L284
.L275:
	.loc 1 80 20 is_stmt 0 discriminator 7
	movl	$1, %eax
	jmp	.L286
.L284:
	.loc 1 80 20 discriminator 8
	movl	$0, %eax
	.loc 1 77 20 is_stmt 1 discriminator 3
	jmp	.L286
.L274:
	.loc 1 77 20 is_stmt 0 discriminator 4
	movl	$0, %eax
.L286:
	.loc 1 77 20 discriminator 5
	testb	%al, %al
	je	.L295
.LBB51:
	.loc 1 77 20 discriminator 6
	leaq	.LC29(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.LEHE26:
.L295:
.LBE51:
	.loc 2 194 4 is_stmt 1 discriminator 2
	nop
.LBE49:
	.loc 2 194 4 is_stmt 0 discriminator 4
	movzbl	-72(%rbp), %eax
	movb	%al, -170(%rbp)
	movl	$0, %eax
.L291:
	cmpl	$1, %eax
	je	.L288
	.loc 2 194 4 discriminator 5
	movzbl	-170(%rbp), %eax
	jmp	.L294
.L292:
	movq	%rax, %rbx
	movl	$1, %eax
	jmp	.L291
.L288:
	movq	%rbx, %rax
	movq	%rax, %rdi
.LEHB27:
	call	_Unwind_Resume@PLT
.L294:
	.loc 2 194 4
	addq	$136, %rsp
.LEHE27:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE14:
	.section	.gcc_except_table
.LLSDA14:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE14-.LLSDACSB14
.LLSDACSB14:
	.uleb128 .LEHB25-.LFB14
	.uleb128 .LEHE25-.LEHB25
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB26-.LFB14
	.uleb128 .LEHE26-.LEHB26
	.uleb128 .L292-.LFB14
	.uleb128 0
	.uleb128 .LEHB27-.LFB14
	.uleb128 .LEHE27-.LEHB27
	.uleb128 0
	.uleb128 0
.LLSDACSE14:
	.text
	.size	silver_platform__create_workspace, .-silver_platform__create_workspace
	.globl	silver_platform_E
	.data
	.align 2
	.type	silver_platform_E, @object
	.size	silver_platform_E, 2
silver_platform_E:
	.zero	2
	.globl	silver_platform__max_path_length
	.section	.rodata
	.align 4
	.type	silver_platform__max_path_length, @object
	.size	silver_platform__max_path_length, 4
silver_platform__max_path_length:
	.long	4096
	.globl	silver_platform__max_file_length
	.align 4
	.type	silver_platform__max_file_length, @object
	.size	silver_platform__max_file_length, 4
silver_platform__max_file_length:
	.long	16777216
	.globl	silver_platform__workspace_prefix
	.align 32
	.type	silver_platform__workspace_prefix, @object
	.size	silver_platform__workspace_prefix, 76
silver_platform__workspace_prefix:
	.ascii	"/home/canto/src/github.com/berkeleynerd/silver/.silver/linux"
	.ascii	"-x86_64/program-"
	.globl	silver_platform__image_workspace_prefix
	.align 32
	.type	silver_platform__image_workspace_prefix, @object
	.size	silver_platform__image_workspace_prefix, 76
silver_platform__image_workspace_prefix:
	.ascii	"/home/canto/src/github.com/berkeleynerd/silver/.silver/linux"
	.ascii	"-x86_64/imagews-"
	.text
	.align 2
	.type	_GLOBAL__SZ1_silver_platform, @function
_GLOBAL__SZ1_silver_platform:
.LFB18:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	.cfi_offset 3, -24
	movl	%edi, -20(%rbp)
	movl	%esi, -24(%rbp)
	movl	-24(%rbp), %eax
	cmpl	-20(%rbp), %eax
	jg	.L297
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movl	-24(%rbp), %eax
	cltq
	subq	%rax, %rdx
	leaq	1(%rdx), %rax
	jmp	.L299
.L297:
	movl	$0, %eax
.L299:
	movq	%rax, %rbx
	movq	%rbx, %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE18:
	.size	_GLOBAL__SZ1_silver_platform, .-_GLOBAL__SZ1_silver_platform
	.section	.rodata
	.align 32
	.type	C189b___UNC.8, @object
	.size	C189b___UNC.8, 84
C189b___UNC.8:
	.long	1
	.long	76
	.ascii	"/home/canto/src/github.com/berkeleynerd/silver/.silver/linux"
	.ascii	"-x86_64/imagews-"
	.align 32
	.type	C190b___UNC.7, @object
	.size	C190b___UNC.7, 84
C190b___UNC.7:
	.long	1
	.long	76
	.ascii	"/home/canto/src/github.com/berkeleynerd/silver/.silver/linux"
	.ascii	"-x86_64/program-"
	.text
.Letext0:
	.file 3 "<built-in>"
	.file 4 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_process_runtime.ads"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x8d4
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x1c
	.long	.LASF68
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.long	.LLRL5
	.quad	0
	.long	.Ldebug_line0
	.uleb128 0xd
	.long	.LASF2
	.byte	0x9
	.long	0x4c
	.uleb128 0x9
	.byte	0x3
	.quad	silver_platform__max_path_length
	.uleb128 0x1d
	.sleb128 2147483647
	.long	.LASF69
	.long	0x51
	.uleb128 0x8
	.long	0x3e
	.uleb128 0x6
	.byte	0x4
	.byte	0x5
	.long	.LASF7
	.uleb128 0xd
	.long	.LASF3
	.byte	0xa
	.long	0x4c
	.uleb128 0x9
	.byte	0x3
	.quad	silver_platform__max_file_length
	.uleb128 0x12
	.byte	0x1
	.byte	0x20
	.byte	0xe
	.long	0x9c
	.uleb128 0x9
	.long	.LASF4
	.byte	0x1
	.byte	0x21
	.byte	0x2b
	.long	0x9c
	.byte	0
	.uleb128 0x9
	.long	.LASF5
	.byte	0x1
	.byte	0x22
	.byte	0x7
	.long	0xab
	.byte	0x4
	.uleb128 0x9
	.long	.LASF6
	.byte	0x1
	.byte	0x22
	.byte	0x1f
	.long	0xab
	.byte	0x5
	.byte	0
	.uleb128 0x13
	.sleb128 0
	.long	.LASF11
	.long	0x51
	.uleb128 0x8
	.long	0x9c
	.uleb128 0x6
	.byte	0x1
	.byte	0x2
	.long	.LASF8
	.uleb128 0x8
	.long	0xab
	.uleb128 0x7
	.long	0xcd
	.long	0xc8
	.uleb128 0xe
	.long	0x51
	.sleb128 76
	.byte	0
	.uleb128 0x4
	.long	0xb7
	.uleb128 0x6
	.byte	0x1
	.byte	0x8
	.long	.LASF9
	.uleb128 0x7
	.long	0xcd
	.long	0xe5
	.uleb128 0xe
	.long	0x51
	.sleb128 76
	.byte	0
	.uleb128 0x4
	.long	0xd4
	.uleb128 0x1e
	.long	.LASF70
	.long	0xcd
	.long	0xff
	.uleb128 0xe
	.long	0x51
	.sleb128 82
	.byte	0
	.uleb128 0x6
	.byte	0x8
	.byte	0x7
	.long	.LASF10
	.uleb128 0x8
	.long	0xff
	.uleb128 0x13
	.sleb128 -2147483648
	.long	.LASF12
	.long	0x11e
	.uleb128 0x8
	.long	0x10b
	.uleb128 0xf
	.byte	0x4
	.byte	0x5
	.long	.LASF13
	.uleb128 0xf
	.byte	0x8
	.byte	0x5
	.long	.LASF14
	.uleb128 0x6
	.byte	0x1
	.byte	0x7
	.long	.LASF15
	.uleb128 0x1f
	.byte	0
	.byte	0xff
	.long	.LASF71
	.long	0x13e
	.uleb128 0xf
	.byte	0x1
	.byte	0x8
	.long	.LASF16
	.uleb128 0x6
	.byte	0x8
	.byte	0x7
	.long	.LASF17
	.uleb128 0x14
	.long	.LASF20
	.byte	0x8
	.long	0x156
	.uleb128 0x20
	.long	.LASF72
	.byte	0x10
	.byte	0x3
	.byte	0
	.long	0x199
	.uleb128 0x15
	.long	.LASF18
	.long	0x16c
	.byte	0
	.uleb128 0x10
	.long	0x1bc
	.uleb128 0x21
	.byte	0x8
	.byte	0x3
	.byte	0
	.long	0x18e
	.uleb128 0x16
	.string	"LB0"
	.long	0x3e
	.byte	0
	.uleb128 0x16
	.string	"UB0"
	.long	0x3e
	.byte	0x4
	.byte	0
	.uleb128 0x15
	.long	.LASF19
	.long	0x1db
	.byte	0x8
	.byte	0
	.uleb128 0x4
	.long	0x156
	.uleb128 0x4
	.long	0x156
	.uleb128 0x4
	.long	0x156
	.uleb128 0x4
	.long	0x156
	.uleb128 0x4
	.long	0x156
	.uleb128 0x4
	.long	0x156
	.uleb128 0x4
	.long	0x156
	.uleb128 0x7
	.long	0xcd
	.long	0x1db
	.uleb128 0x17
	.long	0x51
	.uleb128 0x6
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x94
	.byte	0x4
	.uleb128 0x8
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x23
	.uleb128 0x4
	.byte	0x94
	.byte	0x4
	.byte	0
	.uleb128 0x10
	.long	0x171
	.uleb128 0x22
	.long	.LASF73
	.byte	0x10
	.byte	0x4
	.byte	0x9
	.byte	0x9
	.long	0x22a
	.uleb128 0x9
	.long	.LASF18
	.byte	0x4
	.byte	0x8
	.byte	0x9
	.long	0x1fa
	.byte	0
	.uleb128 0x10
	.long	0x22a
	.uleb128 0x12
	.byte	0x4
	.byte	0x8
	.byte	0x9
	.long	0x21c
	.uleb128 0x18
	.string	"LB0"
	.long	0x3e
	.byte	0
	.uleb128 0x18
	.string	"UB0"
	.long	0x3e
	.byte	0x4
	.byte	0
	.uleb128 0x9
	.long	.LASF19
	.byte	0x4
	.byte	0x8
	.byte	0x9
	.long	0x249
	.byte	0x8
	.byte	0
	.uleb128 0x7
	.long	0x14c
	.long	0x249
	.uleb128 0x17
	.long	0x51
	.uleb128 0x6
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x94
	.byte	0x4
	.uleb128 0x8
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x23
	.uleb128 0x4
	.byte	0x94
	.byte	0x4
	.byte	0
	.uleb128 0x10
	.long	0x1ff
	.uleb128 0x14
	.long	.LASF21
	.byte	0xa
	.long	0x1e0
	.uleb128 0xf
	.byte	0x8
	.byte	0x5
	.long	.LASF22
	.uleb128 0x6
	.byte	0x4
	.byte	0x7
	.long	.LASF23
	.uleb128 0xd
	.long	.LASF24
	.byte	0x47
	.long	0xc8
	.uleb128 0x9
	.byte	0x3
	.quad	silver_platform__workspace_prefix
	.uleb128 0xd
	.long	.LASF25
	.byte	0x48
	.long	0xe5
	.uleb128 0x9
	.byte	0x3
	.quad	silver_platform__image_workspace_prefix
	.uleb128 0x19
	.long	.LASF51
	.byte	0x1
	.uleb128 0x1a
	.byte	0xf
	.byte	0x4
	.long	0x28e
	.uleb128 0x23
	.uleb128 0x14
	.byte	0x14
	.byte	0x14
	.byte	0x2c
	.byte	0x28
	.value	0x4
	.byte	0x30
	.byte	0x2f
	.value	0x6
	.byte	0x12
	.byte	0x15
	.byte	0x2
	.byte	0x1c
	.byte	0x23
	.uleb128 0x1
	.byte	0x16
	.byte	0x13
	.byte	0x16
	.byte	0x13
	.uleb128 0xa
	.long	.LASF41
	.byte	0xc2
	.long	0xab
	.quad	.LFB14
	.quad	.LFE14-.LFB14
	.uleb128 0x1
	.byte	0x9c
	.long	0x48a
	.uleb128 0x1
	.long	.LASF26
	.byte	0x1
	.byte	0x4b
	.byte	0x7
	.long	0x48a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF27
	.byte	0x1
	.byte	0x4b
	.byte	0x39
	.long	0xb2
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x9
	.uleb128 0x1
	.long	.LASF6
	.byte	0x1
	.byte	0x4b
	.byte	0x22
	.long	0xab
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x5
	.quad	.LBB49
	.quad	.LBE49-.LBB49
	.uleb128 0x24
	.long	.LASF74
	.quad	.LFB15
	.quad	.LFE15-.LFB15
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -232
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.long	0x448
	.uleb128 0x2
	.long	.LASF33
	.byte	0x2
	.byte	0xc5
	.byte	0x7
	.long	0x156
	.uleb128 0x3
	.byte	0x91
	.sleb128 -192
	.uleb128 0x3
	.long	.LASF28
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x3
	.long	.LASF29
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x7
	.long	0xcd
	.long	0x37a
	.uleb128 0x11
	.long	0x51
	.long	0x349
	.long	0x356
	.byte	0
	.uleb128 0x3
	.long	.LASF30
	.long	0x387
	.uleb128 0x3
	.byte	0x91
	.sleb128 -104
	.uleb128 0xb
	.long	0x363
	.uleb128 0x3
	.long	.LASF31
	.long	0x145
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x3
	.long	.LASF32
	.long	0x145
	.uleb128 0x3
	.byte	0x91
	.sleb128 -120
	.uleb128 0x7
	.long	0x133
	.long	0x3bd
	.uleb128 0x11
	.long	0x145
	.long	0x38c
	.long	0x399
	.byte	0
	.uleb128 0x2
	.long	.LASF34
	.byte	0x2
	.byte	0xc7
	.byte	0x7
	.long	0x3cd
	.uleb128 0x3
	.byte	0x91
	.sleb128 -136
	.uleb128 0xb
	.long	0x3a6
	.uleb128 0x2
	.long	.LASF35
	.byte	0x2
	.byte	0xc8
	.byte	0x7
	.long	0xff
	.uleb128 0x3
	.byte	0x91
	.sleb128 -152
	.uleb128 0x2
	.long	.LASF36
	.byte	0x2
	.byte	0xc9
	.byte	0x7
	.long	0x10b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -140
	.uleb128 0x3
	.long	.LASF37
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -156
	.uleb128 0x25
	.quad	.LBB46
	.quad	.LBE46-.LBB46
	.long	0x425
	.uleb128 0x2
	.long	.LASF38
	.byte	0x2
	.byte	0xdd
	.byte	0xb
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.byte	0
	.uleb128 0x5
	.quad	.LBB48
	.quad	.LBE48-.LBB48
	.uleb128 0x2
	.long	.LASF38
	.byte	0x2
	.byte	0xe6
	.byte	0x1b
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.byte	0
	.byte	0
	.uleb128 0x7
	.long	0xcd
	.long	0x459
	.uleb128 0xe
	.long	0x51
	.sleb128 76
	.byte	0
	.uleb128 0x3
	.long	.LASF39
	.long	0x448
	.uleb128 0x3
	.byte	0x91
	.sleb128 -176
	.uleb128 0x5
	.quad	.LBB50
	.quad	.LBE50-.LBB50
	.uleb128 0x2
	.long	.LASF40
	.byte	0x1
	.byte	0x50
	.byte	0x26
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0xb
	.long	0xea
	.uleb128 0xa
	.long	.LASF42
	.byte	0x99
	.long	0x59a
	.quad	.LFB12
	.quad	.LFE12-.LFB12
	.uleb128 0x1
	.byte	0x9c
	.long	0x59a
	.uleb128 0x1
	.long	.LASF43
	.byte	0x1
	.byte	0x40
	.byte	0x7
	.long	0x1b7
	.uleb128 0x3
	.byte	0x91
	.sleb128 -192
	.uleb128 0x1
	.long	.LASF44
	.byte	0x1
	.byte	0x40
	.byte	0x1c
	.long	0xa6
	.uleb128 0x3
	.byte	0x91
	.sleb128 -196
	.uleb128 0x1
	.long	.LASF36
	.byte	0x1
	.byte	0x40
	.byte	0x36
	.long	0x59a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -124
	.uleb128 0xc
	.long	.LLRL2
	.uleb128 0x1a
	.byte	0x9c
	.byte	0x7
	.long	0x5a1
	.uleb128 0x2
	.long	.LASF45
	.byte	0x2
	.byte	0x9d
	.byte	0x7
	.long	0x24e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -176
	.uleb128 0x3
	.long	.LASF46
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x3
	.long	.LASF47
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0xc
	.long	.LLRL3
	.uleb128 0x2
	.long	.LASF38
	.byte	0x2
	.byte	0xa2
	.byte	0xb
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0xc
	.long	.LLRL4
	.uleb128 0x3
	.long	.LASF48
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x3
	.long	.LASF49
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -84
	.uleb128 0x7
	.long	0xcd
	.long	0x560
	.uleb128 0x11
	.long	0x51
	.long	0x52f
	.long	0x53c
	.byte	0
	.uleb128 0x2
	.long	.LASF50
	.byte	0x2
	.byte	0xad
	.byte	0xd
	.long	0x570
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0xb
	.long	0x549
	.uleb128 0x5
	.quad	.LBB39
	.quad	.LBE39-.LBB39
	.uleb128 0x26
	.string	"ch"
	.byte	0x2
	.byte	0xb1
	.byte	0x1a
	.long	0x5a7
	.uleb128 0x3
	.byte	0x91
	.sleb128 -120
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.byte	0x4
	.byte	0x5
	.long	.LASF7
	.uleb128 0x19
	.long	.LASF52
	.byte	0x2
	.uleb128 0xb
	.long	0xcd
	.uleb128 0xa
	.long	.LASF53
	.byte	0x8e
	.long	0xab
	.quad	.LFB10
	.quad	.LFE10-.LFB10
	.uleb128 0x1
	.byte	0x9c
	.long	0x623
	.uleb128 0x1
	.long	.LASF54
	.byte	0x1
	.byte	0x36
	.byte	0x13
	.long	0x1b2
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x1
	.long	.LASF6
	.byte	0x1
	.byte	0x36
	.byte	0x25
	.long	0xab
	.uleb128 0x3
	.byte	0x91
	.sleb128 -65
	.uleb128 0xc
	.long	.LLRL1
	.uleb128 0x2
	.long	.LASF36
	.byte	0x2
	.byte	0x8f
	.byte	0x7
	.long	0x10b
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.uleb128 0x5
	.quad	.LBB27
	.quad	.LBE27-.LBB27
	.uleb128 0x2
	.long	.LASF55
	.byte	0x1
	.byte	0x3a
	.byte	0x1f
	.long	0x5a7
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0xa
	.long	.LASF56
	.byte	0x6f
	.long	0xab
	.quad	.LFB8
	.quad	.LFE8-.LFB8
	.uleb128 0x1
	.byte	0x9c
	.long	0x6d6
	.uleb128 0x1
	.long	.LASF26
	.byte	0x1
	.byte	0x2d
	.byte	0x1a
	.long	0x1ad
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x1
	.long	.LASF57
	.byte	0x1
	.byte	0x2d
	.byte	0x29
	.long	0x1a8
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0x1
	.long	.LASF6
	.byte	0x1
	.byte	0x2d
	.byte	0x3c
	.long	0xab
	.uleb128 0x3
	.byte	0x91
	.sleb128 -89
	.uleb128 0xc
	.long	.LLRL0
	.uleb128 0x2
	.long	.LASF58
	.byte	0x2
	.byte	0x71
	.byte	0x7
	.long	0xff
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x2
	.long	.LASF36
	.byte	0x2
	.byte	0x72
	.byte	0x7
	.long	0x10b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -88
	.uleb128 0x3
	.long	.LASF59
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x3
	.long	.LASF60
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -84
	.uleb128 0x5
	.quad	.LBB21
	.quad	.LBE21-.LBB21
	.uleb128 0x2
	.long	.LASF38
	.byte	0x2
	.byte	0x7d
	.byte	0xb
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0xa
	.long	.LASF61
	.byte	0x37
	.long	0x6c
	.quad	.LFB5
	.quad	.LFE5-.LFB5
	.uleb128 0x1
	.byte	0x9c
	.long	0x7fb
	.uleb128 0x1
	.long	.LASF26
	.byte	0x1
	.byte	0x21
	.byte	0x7
	.long	0x1a3
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x1
	.long	.LASF62
	.byte	0x1
	.byte	0x21
	.byte	0x16
	.long	0x19e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x1
	.long	.LASF4
	.byte	0x1
	.byte	0x21
	.byte	0x2b
	.long	0x9c
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x1
	.long	.LASF5
	.byte	0x1
	.byte	0x22
	.byte	0x7
	.long	0xab
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x1d
	.uleb128 0x1
	.long	.LASF6
	.byte	0x1
	.byte	0x22
	.byte	0x1f
	.long	0xab
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x1c
	.uleb128 0x5
	.quad	.LBB11
	.quad	.LBE11-.LBB11
	.uleb128 0x27
	.long	.LASF75
	.quad	.LFB6
	.quad	.LFE6-.LFB6
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -136
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x2
	.long	.LASF58
	.byte	0x2
	.byte	0x3b
	.byte	0x7
	.long	0xff
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x2
	.long	.LASF50
	.byte	0x2
	.byte	0x3c
	.byte	0x7
	.long	0x10b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -92
	.uleb128 0x2
	.long	.LASF36
	.byte	0x2
	.byte	0x3c
	.byte	0xd
	.long	0x10b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x2
	.long	.LASF63
	.byte	0x2
	.byte	0x3d
	.byte	0x7
	.long	0xab
	.uleb128 0x3
	.byte	0x91
	.sleb128 -73
	.uleb128 0x3
	.long	.LASF64
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -84
	.uleb128 0x3
	.long	.LASF65
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -88
	.uleb128 0x5
	.quad	.LBB8
	.quad	.LBE8-.LBB8
	.uleb128 0x2
	.long	.LASF38
	.byte	0x2
	.byte	0x4d
	.byte	0xb
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x1b
	.long	.LASF66
	.byte	0x24
	.long	0x10b
	.quad	.LFB4
	.quad	.LFE4-.LFB4
	.uleb128 0x1
	.byte	0x9c
	.long	0x849
	.uleb128 0x1
	.long	.LASF58
	.byte	0x2
	.byte	0x25
	.byte	0x7
	.long	0x106
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x1
	.long	.LASF50
	.byte	0x2
	.byte	0x25
	.byte	0x1e
	.long	0x119
	.uleb128 0x2
	.byte	0x91
	.sleb128 -44
	.uleb128 0x1
	.long	.LASF36
	.byte	0x2
	.byte	0x25
	.byte	0x37
	.long	0x10b
	.uleb128 0x2
	.byte	0x91
	.sleb128 -20
	.byte	0
	.uleb128 0x1b
	.long	.LASF67
	.byte	0x11
	.long	0x10b
	.quad	.LFB3
	.quad	.LFE3-.LFB3
	.uleb128 0x1
	.byte	0x9c
	.long	0x888
	.uleb128 0x1
	.long	.LASF58
	.byte	0x2
	.byte	0x11
	.byte	0x1c
	.long	0x106
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x1
	.long	.LASF50
	.byte	0x2
	.byte	0x11
	.byte	0x33
	.long	0x10b
	.uleb128 0x2
	.byte	0x91
	.sleb128 -20
	.byte	0
	.uleb128 0x28
	.long	.LASF76
	.byte	0x1
	.byte	0x1c
	.byte	0x4
	.long	0xab
	.quad	.LFB2
	.quad	.LFE2-.LFB2
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x1
	.long	.LASF26
	.byte	0x1
	.byte	0x1c
	.byte	0x19
	.long	0x199
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0x5
	.quad	.LBB4
	.quad	.LBE4-.LBB4
	.uleb128 0x2
	.long	.LASF50
	.byte	0x1
	.byte	0x1e
	.byte	0x19
	.long	0x5a7
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x10
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x55
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0xd
	.uleb128 0x2f
	.uleb128 0x21
	.sleb128 2147483647
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x14
	.uleb128 0x16
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x15
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x16
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x17
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x18
	.uleb128 0x2f
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x18
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x19
	.uleb128 0x1e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 6
	.byte	0
	.byte	0
	.uleb128 0x1a
	.uleb128 0x3a
	.byte	0
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x18
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1b
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1c
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x55
	.uleb128 0x17
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x1d
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1e
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1f
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0xb
	.uleb128 0x2f
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x20
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x21
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x22
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x23
	.uleb128 0x36
	.byte	0
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x24
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x25
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x26
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x27
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x28
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x7c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.LFE4-.Ltext0
	.quad	.LFB6
	.quad	.LFE5-.LFB6
	.quad	.LFB8
	.quad	.LFE8-.LFB8
	.quad	.LFB10
	.quad	.LFE10-.LFB10
	.quad	.LFB12
	.quad	.LFE12-.LFB12
	.quad	.LFB15
	.quad	.LFE14-.LFB15
	.quad	0
	.quad	0
	.section	.debug_rnglists,"",@progbits
.Ldebug_ranges0:
	.long	.Ldebug_ranges3-.Ldebug_ranges2
.Ldebug_ranges2:
	.value	0x5
	.byte	0x8
	.byte	0
	.long	0
.LLRL0:
	.byte	0x5
	.quad	.LBB16
	.byte	0x4
	.uleb128 .LBB16-.LBB16
	.uleb128 .LBE16-.LBB16
	.byte	0x4
	.uleb128 .LBB23-.LBB16
	.uleb128 .LBE23-.LBB16
	.byte	0
.LLRL1:
	.byte	0x5
	.quad	.LBB24
	.byte	0x4
	.uleb128 .LBB24-.LBB24
	.uleb128 .LBE24-.LBB24
	.byte	0x4
	.uleb128 .LBB31-.LBB24
	.uleb128 .LBE31-.LBB24
	.byte	0
.LLRL2:
	.byte	0x5
	.quad	.LBB32
	.byte	0x4
	.uleb128 .LBB32-.LBB32
	.uleb128 .LBE32-.LBB32
	.byte	0x4
	.uleb128 .LBB44-.LBB32
	.uleb128 .LBE44-.LBB32
	.byte	0
.LLRL3:
	.byte	0x5
	.quad	.LBB36
	.byte	0x4
	.uleb128 .LBB36-.LBB36
	.uleb128 .LBE36-.LBB36
	.byte	0x4
	.uleb128 .LBB43-.LBB36
	.uleb128 .LBE43-.LBB36
	.byte	0
.LLRL4:
	.byte	0x5
	.quad	.LBB37
	.byte	0x4
	.uleb128 .LBB37-.LBB37
	.uleb128 .LBE37-.LBB37
	.byte	0x4
	.uleb128 .LBB41-.LBB37
	.uleb128 .LBE41-.LBB37
	.byte	0
.LLRL5:
	.byte	0x7
	.quad	.Ltext0
	.uleb128 .LFE4-.Ltext0
	.byte	0x7
	.quad	.LFB6
	.uleb128 .LFE5-.LFB6
	.byte	0x7
	.quad	.LFB8
	.uleb128 .LFE8-.LFB8
	.byte	0x7
	.quad	.LFB10
	.uleb128 .LFE10-.LFB10
	.byte	0x7
	.quad	.LFB12
	.uleb128 .LFE12-.LFB12
	.byte	0x7
	.quad	.LFB15
	.uleb128 .LFE14-.LFB15
	.byte	0
.Ldebug_ranges3:
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF52:
	.string	"silver_process_runtime"
.LASF35:
	.string	"result"
.LASF39:
	.string	"C245b"
.LASF18:
	.string	"P_ARRAY"
.LASF40:
	.string	"T188b"
.LASF7:
	.string	"integer"
.LASF28:
	.string	"L203b"
.LASF61:
	.string	"silver_platform__read_file"
.LASF76:
	.string	"silver_platform__valid_path"
.LASF47:
	.string	"R96b"
.LASF66:
	.string	"silver_platform__observed_put"
.LASF11:
	.string	"natural"
.LASF44:
	.string	"skip_arguments"
.LASF58:
	.string	"file"
.LASF31:
	.string	"B209b"
.LASF15:
	.string	"system__storage_elements__storage_element"
.LASF57:
	.string	"contents"
.LASF49:
	.string	"B151b"
.LASF10:
	.string	"system__address"
.LASF38:
	.string	"index"
.LASF5:
	.string	"too_long"
.LASF20:
	.string	"silver_process_runtime__string_access"
.LASF55:
	.string	"T62b"
.LASF42:
	.string	"silver_platform__run_application"
.LASF41:
	.string	"silver_platform__create_workspace"
.LASF16:
	.string	"interfaces__c__TcharB"
.LASF25:
	.string	"silver_platform__image_workspace_prefix"
.LASF22:
	.string	"system__storage_elements__Tstorage_offsetB"
.LASF72:
	.string	"string"
.LASF14:
	.string	"system__parameters__Tsize_typeB"
.LASF33:
	.string	"prefix"
.LASF71:
	.string	"interfaces__c__char"
.LASF64:
	.string	"silver_platform__read_file___wrapped_statements__L_1__T28b___L"
.LASF9:
	.string	"character"
.LASF23:
	.string	"interfaces__c__unsigned"
.LASF26:
	.string	"name"
.LASF19:
	.string	"P_BOUNDS"
.LASF32:
	.string	"B213b"
.LASF29:
	.string	"silver_platform__create_workspace___wrapped_statements__TA205bP1___U"
.LASF34:
	.string	"template"
.LASF73:
	.string	"silver_process_runtime__argument_list"
.LASF56:
	.string	"silver_platform__write_file"
.LASF17:
	.string	"interfaces__c__size_t"
.LASF27:
	.string	"for_image"
.LASF59:
	.string	"silver_platform__write_file__L_2__T52b___L"
.LASF45:
	.string	"args"
.LASF60:
	.string	"silver_platform__write_file__L_2__T52b___U"
.LASF4:
	.string	"last"
.LASF36:
	.string	"status"
.LASF68:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF63:
	.string	"reached_end"
.LASF62:
	.string	"buffer"
.LASF69:
	.string	"positive"
.LASF24:
	.string	"silver_platform__workspace_prefix"
.LASF70:
	.string	"silver_platform__workspace_path"
.LASF13:
	.string	"interfaces__c__TintB"
.LASF21:
	.string	"silver_process_runtime__argument_list_access"
.LASF12:
	.string	"interfaces__c__int"
.LASF3:
	.string	"silver_platform__max_file_length"
.LASF43:
	.string	"executable"
.LASF30:
	.string	"S204b"
.LASF50:
	.string	"item"
.LASF46:
	.string	"R95b"
.LASF51:
	.string	"silver_libc"
.LASF74:
	.string	"silver_platform__create_workspace___wrapped_statements"
.LASF75:
	.string	"silver_platform__read_file___wrapped_statements"
.LASF67:
	.string	"silver_platform__observed_get"
.LASF2:
	.string	"silver_platform__max_path_length"
.LASF48:
	.string	"B147b"
.LASF6:
	.string	"success"
.LASF65:
	.string	"silver_platform__read_file___wrapped_statements__L_1__T28b___U"
.LASF54:
	.string	"command"
.LASF37:
	.string	"silver_platform__create_workspace___wrapped_statements__B236b__L237b__T238b___L"
.LASF8:
	.string	"boolean"
.LASF53:
	.string	"silver_platform__run"
	.section	.debug_line_str,"MS",@progbits,1
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_platform.adb"
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
	.hidden	DW.ref.__gnat_personality_v0
	.weak	DW.ref.__gnat_personality_v0
	.section	.data.rel.local.DW.ref.__gnat_personality_v0,"awG",@progbits,DW.ref.__gnat_personality_v0,comdat
	.align 8
	.type	DW.ref.__gnat_personality_v0, @object
	.size	DW.ref.__gnat_personality_v0, 8
DW.ref.__gnat_personality_v0:
	.quad	__gnat_personality_v0
	.globl	__gnat_personality_v0
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
