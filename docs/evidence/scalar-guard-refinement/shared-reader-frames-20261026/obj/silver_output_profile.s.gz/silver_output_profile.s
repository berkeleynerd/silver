	.file	"silver_output_profile.adb"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_output_profile.adb"
	.align 2
	.globl	silver_output_profile__token_kindH
	.type	silver_output_profile__token_kindH, @function
silver_output_profile__token_kindH:
.LFB2:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	movq	-8(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L2
	movl	%edx, %ecx
	subl	%eax, %ecx
	leal	1(%rcx), %r11d
	jmp	.L3
.L2:
	movl	$0, %r11d
.L3:
	movslq	%eax, %r9
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	leal	-1(%rax), %r10d
	movl	$0, %ecx
	movl	$0, %edx
	movl	$0, %eax
.L11:
	cmpl	$4, %eax
	jg	.L10
	movslq	%eax, %rsi
	leaq	0(,%rsi,4), %rdi
	leaq	token_kindP.55(%rip), %rsi
	movl	(%rdi,%rsi), %esi
	cmpl	%esi, %r11d
	jl	.L10
	movq	-16(%rbp), %rsi
	movslq	%eax, %rdi
	leaq	0(,%rdi,4), %r8
	leaq	token_kindP.55(%rip), %rdi
	movl	(%r8,%rdi), %edi
	addl	%r10d, %edi
	movslq	%edi, %rdi
	subq	%r9, %rdi
	movzbl	(%rsi,%rdi), %esi
	movzbl	%sil, %edi
	movslq	%eax, %rsi
	leaq	token_kindT1.54(%rip), %r8
	movzbl	(%rsi,%r8), %esi
	movzbl	%sil, %esi
	imull	%edi, %esi
	addl	%ecx, %esi
	movslq	%esi, %rcx
	imulq	$1154949189, %rcx, %rcx
	shrq	$32, %rcx
	sarl	$5, %ecx
	movl	%esi, %r8d
	sarl	$31, %r8d
	subl	%r8d, %ecx
	imull	$119, %ecx, %r8d
	movl	%esi, %ecx
	subl	%r8d, %ecx
	movslq	%eax, %rsi
	leaq	token_kindT2.53(%rip), %r8
	movzbl	(%rsi,%r8), %esi
	movzbl	%sil, %esi
	imull	%edi, %esi
	addl	%edx, %esi
	movslq	%esi, %rdx
	imulq	$1154949189, %rdx, %rdx
	shrq	$32, %rdx
	sarl	$5, %edx
	movl	%esi, %edi
	sarl	$31, %edi
	subl	%edi, %edx
	imull	$119, %edx, %edi
	movl	%esi, %edx
	subl	%edi, %edx
	addl	$1, %eax
	jmp	.L11
.L10:
	movslq	%ecx, %rax
	leaq	token_kindG.52(%rip), %rcx
	movzbl	(%rax,%rcx), %eax
	movzbl	%al, %ecx
	movslq	%edx, %rax
	leaq	token_kindG.52(%rip), %rdx
	movzbl	(%rax,%rdx), %eax
	movzbl	%al, %eax
	addl	%ecx, %eax
	movslq	%eax, %rdx
	imulq	$582368447, %rdx, %rdx
	shrq	$32, %rdx
	sarl	$3, %edx
	movl	%eax, %ecx
	sarl	$31, %ecx
	subl	%ecx, %edx
	imull	$59, %edx, %ecx
	subl	%ecx, %eax
	movl	%eax, %edx
	movl	%edx, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	silver_output_profile__token_kindH, .-silver_output_profile__token_kindH
	.align 2
	.globl	silver_output_profile__token_sequenceIP
	.type	silver_output_profile__token_sequenceIP, @function
silver_output_profile__token_sequenceIP:
.LFB3:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.size	silver_output_profile__token_sequenceIP, .-silver_output_profile__token_sequenceIP
	.align 2
	.globl	silver_output_profile__is_argument_form
	.type	silver_output_profile__is_argument_form, @function
silver_output_profile__is_argument_form:
.LFB4:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_output_profile.ads"
	.loc 1 48 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movb	%dil, -1(%rbp)
	.loc 1 49 12
	cmpb	$1, -1(%rbp)
	sete	%al
	.loc 1 48 4
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	silver_output_profile__is_argument_form, .-silver_output_profile__is_argument_form
	.align 2
	.type	silver_output_profile__is_word_token___wrapped_statements.0, @function
silver_output_profile__is_word_token___wrapped_statements.0:
.LFB6:
	.file 2 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_output_profile.adb"
	.loc 2 26 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	.loc 2 31 86
	movzbl	(%rax), %edx
	cmpb	$10, %dl
	jbe	.L18
	.loc 2 27 46
	movzbl	(%rax), %edx
	cmpb	$17, %dl
	je	.L18
	.loc 2 27 65 discriminator 1
	movzbl	(%rax), %edx
	cmpb	$18, %dl
	je	.L18
	.loc 2 28 11
	movzbl	(%rax), %edx
	cmpb	$20, %dl
	je	.L18
	.loc 2 28 28 discriminator 1
	movzbl	(%rax), %edx
	cmpb	$21, %dl
	je	.L18
	.loc 2 28 52 discriminator 2
	movzbl	(%rax), %edx
	cmpb	$22, %dl
	je	.L18
	.loc 2 29 11
	movzbl	(%rax), %edx
	cmpb	$23, %dl
	je	.L18
	.loc 2 29 33 discriminator 1
	movzbl	(%rax), %edx
	cmpb	$24, %dl
	je	.L18
	.loc 2 29 48 discriminator 2
	movzbl	(%rax), %edx
	cmpb	$25, %dl
	je	.L18
	.loc 2 29 63 discriminator 3
	movzbl	(%rax), %edx
	cmpb	$26, %dl
	je	.L18
	.loc 2 29 79 discriminator 4
	movzbl	(%rax), %edx
	cmpb	$27, %dl
	je	.L18
	.loc 2 30 11
	movzbl	(%rax), %edx
	cmpb	$29, %dl
	je	.L18
	.loc 2 30 25 discriminator 1
	movzbl	(%rax), %edx
	cmpb	$37, %dl
	je	.L18
	.loc 2 30 39 discriminator 2
	movzbl	(%rax), %edx
	cmpb	$30, %dl
	je	.L18
	.loc 2 30 52 discriminator 3
	movzbl	(%rax), %edx
	cmpb	$31, %dl
	je	.L18
	.loc 2 30 66 discriminator 4
	movzbl	(%rax), %edx
	cmpb	$49, %dl
	je	.L18
	.loc 2 31 11 discriminator 1
	movzbl	(%rax), %edx
	cmpb	$52, %dl
	je	.L18
	.loc 2 31 26 discriminator 2
	movzbl	(%rax), %edx
	cmpb	$53, %dl
	je	.L18
	.loc 2 31 40 discriminator 3
	movzbl	(%rax), %edx
	cmpb	$54, %dl
	je	.L18
	.loc 2 31 53 discriminator 4
	movzbl	(%rax), %edx
	cmpb	$55, %dl
	je	.L18
	.loc 2 31 71 discriminator 5
	movzbl	(%rax), %edx
	cmpb	$56, %dl
	je	.L18
	.loc 2 31 86 discriminator 6
	movzbl	(%rax), %eax
	cmpb	$58, %al
	jne	.L19
.L18:
	.loc 2 31 86 is_stmt 0 discriminator 7
	movl	$1, %eax
	jmp	.L20
.L19:
	.loc 2 31 86 discriminator 8
	movl	$0, %eax
.L20:
	.loc 2 26 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE6:
	.size	silver_output_profile__is_word_token___wrapped_statements.0, .-silver_output_profile__is_word_token___wrapped_statements.0
	.section	.rodata
	.align 8
.LC11:
	.ascii	"failed postcondition from silver_output_profile.ads:33"
	.align 8
.LC0:
	.long	1
	.long	54
	.text
	.align 2
	.globl	silver_output_profile__is_word_token
	.type	silver_output_profile__is_word_token, @function
silver_output_profile__is_word_token:
.LFB5:
	.loc 2 26 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	subq	$32, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	movb	%dil, -33(%rbp)
	.loc 2 26 4
	leaq	16(%rbp), %rax
	.loc 2 26 4 is_stmt 0 discriminator 1
	movq	%rax, -24(%rbp)
	movzbl	-33(%rbp), %eax
	movb	%al, -32(%rbp)
.LBB4:
	leaq	-32(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__is_word_token___wrapped_statements.0
	.loc 1 34 10 is_stmt 1
	movzbl	-32(%rbp), %edx
	cmpb	$10, %dl
	jbe	.L23
	.loc 1 34 10 is_stmt 0 discriminator 1
	movzbl	-32(%rbp), %edx
	cmpb	$17, %dl
	je	.L23
	.loc 1 34 46 is_stmt 1 discriminator 2
	movzbl	-32(%rbp), %edx
	cmpb	$18, %dl
	je	.L23
	.loc 1 34 60 discriminator 3
	movzbl	-32(%rbp), %edx
	cmpb	$20, %dl
	je	.L23
	.loc 1 35 14
	movzbl	-32(%rbp), %edx
	cmpb	$21, %dl
	je	.L23
	.loc 1 35 38 discriminator 1
	movzbl	-32(%rbp), %edx
	cmpb	$22, %dl
	je	.L23
	.loc 1 35 51 discriminator 2
	movzbl	-32(%rbp), %edx
	cmpb	$23, %dl
	je	.L23
	.loc 1 36 14
	movzbl	-32(%rbp), %edx
	cmpb	$24, %dl
	je	.L23
	.loc 1 36 29 discriminator 1
	movzbl	-32(%rbp), %edx
	cmpb	$25, %dl
	je	.L23
	.loc 1 36 44 discriminator 2
	movzbl	-32(%rbp), %edx
	cmpb	$26, %dl
	je	.L23
	.loc 1 36 60 discriminator 3
	movzbl	-32(%rbp), %edx
	cmpb	$27, %dl
	je	.L23
	.loc 1 36 74 discriminator 4
	movzbl	-32(%rbp), %edx
	cmpb	$29, %dl
	je	.L23
	.loc 1 36 88 discriminator 5
	movzbl	-32(%rbp), %edx
	cmpb	$37, %dl
	je	.L23
	.loc 1 37 14
	movzbl	-32(%rbp), %edx
	cmpb	$30, %dl
	je	.L23
	.loc 1 37 27 discriminator 1
	movzbl	-32(%rbp), %edx
	cmpb	$31, %dl
	je	.L23
	.loc 1 37 41 discriminator 2
	movzbl	-32(%rbp), %edx
	cmpb	$49, %dl
	je	.L23
	.loc 1 37 56 discriminator 3
	movzbl	-32(%rbp), %edx
	cmpb	$52, %dl
	je	.L23
	.loc 1 38 14
	movzbl	-32(%rbp), %edx
	cmpb	$53, %dl
	je	.L23
	.loc 1 38 28 discriminator 1
	movzbl	-32(%rbp), %edx
	cmpb	$54, %dl
	je	.L23
	.loc 1 38 41 discriminator 2
	movzbl	-32(%rbp), %edx
	cmpb	$55, %dl
	je	.L23
	.loc 1 38 59 discriminator 3
	movzbl	-32(%rbp), %edx
	cmpb	$56, %dl
	je	.L23
	.loc 1 38 74 discriminator 4
	movzbl	-32(%rbp), %edx
	cmpb	$58, %dl
	jne	.L24
.L23:
	.loc 1 34 10 discriminator 4
	movl	$1, %edx
	jmp	.L25
.L24:
	.loc 1 34 10 is_stmt 0 discriminator 5
	movl	$0, %edx
.L25:
	.loc 1 33 16 is_stmt 1
	cmpb	%al, %dl
	je	.L27
.LBB5:
	.loc 1 33 16 is_stmt 0 discriminator 1
	leaq	.LC11(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L27:
.LBE5:
.LBE4:
	.loc 2 26 4 is_stmt 1
	addq	$32, %rsp
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE5:
	.size	silver_output_profile__is_word_token, .-silver_output_profile__is_word_token
	.section	.rodata
.LC12:
	.ascii	"silver_output_profile.adb"
	.zero	1
	.text
	.align 2
	.type	silver_output_profile__spelling___wrapped_statements.1, @function
silver_output_profile__spelling___wrapped_statements.1:
.LFB8:
	.loc 2 33 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	subq	$16, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	movq	%r10, %rax
	movq	%r10, -24(%rbp)
	.loc 2 34 12
	movzbl	(%rax), %edx
	cmpb	$58, %dl
	jbe	.L29
	.loc 2 34 12 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$34, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L29:
	.loc 2 34 12 discriminator 2
	movzbl	(%rax), %edx
	cmpb	$58, %dl
	jbe	.L30
	.loc 2 34 12 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$34, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L30:
	.loc 2 34 7 is_stmt 1 discriminator 4
	movzbl	(%rax), %eax
	cmpb	$58, %al
	je	.L31
	cmpb	$58, %al
	ja	.L32
	cmpb	$57, %al
	je	.L33
	cmpb	$57, %al
	ja	.L32
	cmpb	$56, %al
	je	.L34
	cmpb	$56, %al
	ja	.L32
	cmpb	$55, %al
	je	.L35
	cmpb	$55, %al
	ja	.L32
	cmpb	$54, %al
	je	.L36
	cmpb	$54, %al
	ja	.L32
	cmpb	$53, %al
	je	.L37
	cmpb	$53, %al
	ja	.L32
	cmpb	$52, %al
	je	.L38
	cmpb	$52, %al
	ja	.L32
	cmpb	$49, %al
	je	.L39
	cmpb	$49, %al
	ja	.L32
	cmpb	$40, %al
	je	.L40
	cmpb	$40, %al
	ja	.L32
	cmpb	$39, %al
	je	.L41
	cmpb	$39, %al
	ja	.L32
	cmpb	$38, %al
	je	.L42
	cmpb	$38, %al
	ja	.L32
	cmpb	$37, %al
	je	.L43
	cmpb	$37, %al
	ja	.L32
	cmpb	$36, %al
	je	.L44
	cmpb	$36, %al
	ja	.L32
	cmpb	$35, %al
	je	.L45
	cmpb	$35, %al
	ja	.L32
	cmpb	$34, %al
	je	.L46
	cmpb	$34, %al
	ja	.L32
	cmpb	$33, %al
	je	.L47
	cmpb	$33, %al
	ja	.L32
	cmpb	$32, %al
	je	.L48
	cmpb	$32, %al
	ja	.L32
	cmpb	$31, %al
	je	.L49
	cmpb	$31, %al
	ja	.L32
	cmpb	$30, %al
	je	.L50
	cmpb	$30, %al
	ja	.L32
	cmpb	$29, %al
	je	.L51
	cmpb	$29, %al
	ja	.L32
	cmpb	$28, %al
	je	.L52
	cmpb	$28, %al
	ja	.L32
	cmpb	$27, %al
	je	.L53
	cmpb	$27, %al
	ja	.L32
	cmpb	$26, %al
	je	.L54
	cmpb	$26, %al
	ja	.L32
	cmpb	$25, %al
	je	.L55
	cmpb	$25, %al
	ja	.L32
	cmpb	$24, %al
	je	.L56
	cmpb	$24, %al
	ja	.L32
	cmpb	$23, %al
	je	.L57
	cmpb	$23, %al
	ja	.L32
	cmpb	$22, %al
	je	.L58
	cmpb	$22, %al
	ja	.L32
	cmpb	$21, %al
	je	.L59
	cmpb	$21, %al
	ja	.L32
	cmpb	$20, %al
	je	.L60
	cmpb	$20, %al
	ja	.L32
	cmpb	$19, %al
	je	.L61
	cmpb	$19, %al
	ja	.L32
	cmpb	$18, %al
	je	.L62
	cmpb	$18, %al
	ja	.L32
	cmpb	$17, %al
	je	.L63
	cmpb	$17, %al
	ja	.L32
	cmpb	$16, %al
	je	.L64
	cmpb	$16, %al
	ja	.L32
	cmpb	$15, %al
	je	.L65
	cmpb	$15, %al
	ja	.L32
	cmpb	$14, %al
	je	.L66
	cmpb	$14, %al
	ja	.L32
	cmpb	$13, %al
	je	.L67
	cmpb	$13, %al
	ja	.L32
	cmpb	$12, %al
	je	.L68
	cmpb	$12, %al
	ja	.L32
	cmpb	$11, %al
	je	.L69
	cmpb	$11, %al
	ja	.L32
	cmpb	$10, %al
	je	.L70
	cmpb	$10, %al
	ja	.L32
	cmpb	$9, %al
	je	.L71
	cmpb	$9, %al
	ja	.L32
	cmpb	$8, %al
	je	.L72
	cmpb	$8, %al
	ja	.L32
	cmpb	$7, %al
	je	.L73
	cmpb	$7, %al
	ja	.L32
	cmpb	$6, %al
	je	.L74
	cmpb	$6, %al
	ja	.L32
	cmpb	$5, %al
	je	.L75
	cmpb	$5, %al
	ja	.L32
	cmpb	$4, %al
	je	.L76
	cmpb	$4, %al
	ja	.L32
	cmpb	$3, %al
	je	.L77
	cmpb	$3, %al
	ja	.L32
	cmpb	$2, %al
	je	.L78
	cmpb	$2, %al
	ja	.L32
	testb	%al, %al
	je	.L79
	cmpb	$1, %al
	je	.L80
	jmp	.L32
.L79:
	.loc 2 35 31
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 35 31 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1752459639, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L80:
	.loc 2 36 26 is_stmt 1
	movl	$4, %esi
	movl	$20, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 36 26 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$9, 4(%rax)
	movabsq	$7592913276874025331, %rcx
	movq	%rcx, 8(%rax)
	movb	$111, 16(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L78:
	.loc 2 37 36 is_stmt 1
	movl	$4, %esi
	movl	$20, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 37 36 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$9, 4(%rax)
	movabsq	$8247608679221654128, %rcx
	movq	%rcx, 8(%rax)
	movb	$101, 16(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L77:
	.loc 2 38 28 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 38 28 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1852399981, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L76:
	.loc 2 39 29 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 39 29 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$2, 4(%rax)
	movw	$29545, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L75:
	.loc 2 40 33 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 40 33 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$6, 4(%rax)
	movl	$1734439536, 8(%rax)
	movw	$24941, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L74:
	.loc 2 41 34 is_stmt 1
	movl	$4, %esi
	movl	$20, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 41 34 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$10, 4(%rax)
	movabsq	$8029178625756590195, %rcx
	movq	%rcx, 8(%rax)
	movw	$25956, 16(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L73:
	.loc 2 42 26 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 42 26 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$2, 4(%rax)
	movw	$28271, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L72:
	.loc 2 43 32 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 43 32 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$5, 4(%rax)
	movl	$1768383842, 8(%rax)
	movb	$110, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L71:
	.loc 2 44 32 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 44 32 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$8, 4(%rax)
	movabsq	$7308895159447745904, %rcx
	movq	%rcx, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L70:
	.loc 2 45 30 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 45 30 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$28261, 8(%rax)
	movb	$100, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L69:
	.loc 2 46 35 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 46 35 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$1, 4(%rax)
	movb	$40, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L68:
	.loc 2 47 36 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 47 36 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$1, 4(%rax)
	movb	$41, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L67:
	.loc 2 48 28 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 48 28 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$1, 4(%rax)
	movb	$59, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L66:
	.loc 2 49 22 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 49 22 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$1, 4(%rax)
	movb	$46, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L65:
	.loc 2 50 33 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 50 33 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$1, 4(%rax)
	movb	$34, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L64:
	.loc 2 51 24 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 51 24 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$1, 4(%rax)
	movb	$58, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L63:
	.loc 2 52 35 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 52 35 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$8, 4(%rax)
	movabsq	$8389750308618530659, %rcx
	movq	%rcx, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L62:
	.loc 2 53 30 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 53 30 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$6, 4(%rax)
	movl	$1769108595, 8(%rax)
	movw	$26478, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L61:
	.loc 2 54 29 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 54 29 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$2, 4(%rax)
	movw	$15674, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L60:
	.loc 2 55 33 is_stmt 1
	movl	$4, %esi
	movl	$24, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 55 33 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$16, 4(%rax)
	movabsq	$7016452524570601843, %rsi
	movabsq	$8319395793567311730, %rdi
	movq	%rsi, 8(%rax)
	movq	%rdi, 16(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L59:
	.loc 2 56 40 is_stmt 1
	movl	$4, %esi
	movl	$24, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 56 40 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$16, 4(%rax)
	movabsq	$8245914396496390502, %rsi
	movabsq	$8389209267074589791, %rdi
	movq	%rsi, 8(%rax)
	movq	%rdi, 16(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L58:
	.loc 2 57 29 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 57 29 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$2, 4(%rax)
	movw	$26217, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L57:
	.loc 2 58 38 is_stmt 1
	movl	$4, %esi
	movl	$24, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 58 38 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$14, 4(%rax)
	movabsq	$8316283140707479145, %rcx
	movq	%rcx, 8(%rax)
	movabsq	$7235433442201006953, %rcx
	movq	%rcx, 14(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L56:
	.loc 2 59 31 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 59 31 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1852139636, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L55:
	.loc 2 60 31 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 60 31 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1702063205, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L54:
	.loc 2 61 32 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 61 32 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$5, 4(%rax)
	movl	$1769172069, 8(%rax)
	movb	$102, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L53:
	.loc 2 62 30 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 62 30 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$6, 4(%rax)
	movl	$1701471602, 8(%rax)
	movw	$29795, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L52:
	.loc 2 63 28 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 63 28 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$1, 4(%rax)
	movb	$38, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L51:
	.loc 2 64 30 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 64 30 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$28257, 8(%rax)
	movb	$100, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L50:
	.loc 2 65 29 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 65 29 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$2, 4(%rax)
	movw	$29295, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L49:
	.loc 2 66 30 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 66 30 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$28526, 8(%rax)
	movb	$116, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L48:
	.loc 2 67 28 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 67 28 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$2, 4(%rax)
	movw	$15663, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L47:
	.loc 2 68 23 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 68 23 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$1, 4(%rax)
	movb	$60, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L46:
	.loc 2 69 26 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 69 26 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$1, 4(%rax)
	movb	$62, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L45:
	.loc 2 70 32 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 70 32 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$2, 4(%rax)
	movw	$15678, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L44:
	.loc 2 71 29 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 71 29 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$1, 4(%rax)
	movb	$39, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L43:
	.loc 2 72 30 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 72 30 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$6, 4(%rax)
	movl	$1735288172, 8(%rax)
	movw	$26740, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L42:
	.loc 2 73 29 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 73 29 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$2, 4(%rax)
	movw	$15676, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L41:
	.loc 2 74 35 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 74 35 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$1, 4(%rax)
	movb	$48, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L40:
	.loc 2 75 24 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 75 24 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$1, 4(%rax)
	movb	$61, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L39:
	.loc 2 76 31 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 76 31 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1819047278, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L38:
	.loc 2 77 31 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 77 31 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$7, 4(%rax)
	movl	$1702129257, 8(%rax)
	movl	$1919248229, 11(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L37:
	.loc 2 78 30 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 78 30 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$28518, 8(%rax)
	movb	$114, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L36:
	.loc 2 79 29 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 79 29 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$2, 4(%rax)
	movw	$28265, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L35:
	.loc 2 80 34 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 80 34 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$7, 4(%rax)
	movl	$1702258034, 8(%rax)
	movl	$1702064741, 11(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L34:
	.loc 2 81 31 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 81 31 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1886351212, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L33:
	.loc 2 82 34 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 82 34 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$2, 4(%rax)
	movw	$11822, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L31:
	.loc 2 83 32 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 83 32 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$5, 4(%rax)
	movl	$1735287154, 8(%rax)
	movb	$101, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L81
.L32:
	.loc 2 86 91 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 86 91 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$1, 4(%rax)
	movb	$95, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
.L81:
	.loc 2 33 4 is_stmt 1
	movq	%r12, %rax
	movq	%r13, %rdx
	addq	$16, %rsp
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE8:
	.size	silver_output_profile__spelling___wrapped_statements.1, .-silver_output_profile__spelling___wrapped_statements.1
	.section	.rodata
	.align 8
.LC13:
	.ascii	"failed postcondition from silver_output_profile.ads:52"
	.align 8
.LC14:
	.ascii	"failed postcondition from silver_output_profile.ads:53"
	.text
	.align 2
	.globl	silver_output_profile__spelling
	.type	silver_output_profile__spelling, @function
silver_output_profile__spelling:
.LFB7:
	.loc 2 33 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movb	%dil, -65(%rbp)
	.loc 2 33 4
	leaq	16(%rbp), %rax
	.loc 2 33 4 is_stmt 0 discriminator 1
	movq	%rax, -56(%rbp)
	movzbl	-65(%rbp), %eax
	movb	%al, -64(%rbp)
.LBB6:
	leaq	-64(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__spelling___wrapped_statements.1
	.loc 2 33 4 discriminator 2
	movq	%rax, %rcx
	movq	%rdx, %rbx
	movq	%rbx, %rax
	movl	(%rax), %eax
	movq	%rbx, %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	.loc 2 33 4 discriminator 5
	cmpl	%eax, %edx
	.loc 2 33 4 discriminator 8
	cmpl	%eax, %edx
	.loc 2 33 4 discriminator 11
	cmpl	%eax, %edx
	jl	.L89
	.loc 2 33 4 discriminator 12
	testl	%eax, %eax
	jg	.L89
	.loc 2 33 4 discriminator 13
	leaq	.LC12(%rip), %rax
	movl	$33, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L89:
	.loc 1 52 16 is_stmt 1
	cmpl	$1, %eax
	je	.L90
.LBB7:
	.loc 1 52 16 is_stmt 0 discriminator 1
	leaq	.LC13(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L90:
.LBE7:
	.loc 1 52 16 discriminator 2
	cmpl	%eax, %edx
	jl	.L91
	.loc 1 53 42 is_stmt 1
	movl	%edx, %esi
	movl	%eax, %edi
	subl	%edi, %esi
	addl	$1, %esi
	testl	%esi, %esi
	jle	.L91
	.loc 1 53 42 is_stmt 0 discriminator 1
	cmpl	%eax, %edx
	jl	.L92
	.loc 1 53 42 discriminator 2
	movl	%edx, %esi
	movl	%eax, %edx
	movl	%esi, %eax
	subl	%edx, %eax
	addl	$1, %eax
	cmpl	$16, %eax
	jle	.L92
.L91:
.LBB8:
	.loc 1 52 16 is_stmt 1 discriminator 3
	leaq	.LC14(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L92:
.LBE8:
	.loc 2 33 4 discriminator 14
	movq	%rcx, %rax
	movq	%rbx, %rdx
.LBE6:
	.loc 2 33 4 is_stmt 0
	addq	$40, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE7:
	.size	silver_output_profile__spelling, .-silver_output_profile__spelling
	.align 2
	.type	silver_output_profile__tokens___wrapped_statements.2, @function
silver_output_profile__tokens___wrapped_statements.2:
.LFB10:
	.loc 2 88 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	subq	$16, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	movq	%r10, %rax
	movq	%r10, -24(%rbp)
	.loc 2 89 12
	movzbl	(%rax), %edx
	cmpb	$1, %dl
	jbe	.L95
	.loc 2 89 12 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$89, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L95:
	.loc 2 89 7 is_stmt 1 discriminator 2
	movzbl	(%rax), %eax
	testb	%al, %al
	jne	.L96
	.loc 2 91 10
	movl	$4, %esi
	movl	$24, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 91 10 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$16, 4(%rax)
	movb	$51, 8(%rax)
	movb	$2, 9(%rax)
	movb	$3, 10(%rax)
	movb	$4, 11(%rax)
	movb	$5, 12(%rax)
	movb	$6, 13(%rax)
	movb	$11, 14(%rax)
	movb	$7, 15(%rax)
	movb	$12, 16(%rax)
	movb	$13, 17(%rax)
	movb	$42, 18(%rax)
	movb	$8, 19(%rax)
	movb	$50, 20(%rax)
	movb	$10, 21(%rax)
	movb	$3, 22(%rax)
	movb	$13, 23(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L97
.L96:
	.loc 2 96 10 is_stmt 1
	movl	$4, %esi
	movl	$28, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 96 10 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$17, 4(%rax)
	movb	$51, 8(%rax)
	movb	$2, 9(%rax)
	movb	$3, 10(%rax)
	movb	$4, 11(%rax)
	movb	$5, 12(%rax)
	movb	$6, 13(%rax)
	movb	$11, 14(%rax)
	movb	$7, 15(%rax)
	movb	$12, 16(%rax)
	movb	$13, 17(%rax)
	movb	$41, 18(%rax)
	movb	$42, 19(%rax)
	movb	$8, 20(%rax)
	movb	$50, 21(%rax)
	movb	$10, 22(%rax)
	movb	$3, 23(%rax)
	movb	$13, 24(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
.L97:
	.loc 2 88 4 is_stmt 1
	movq	%r12, %rax
	movq	%r13, %rdx
	addq	$16, %rsp
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE10:
	.size	silver_output_profile__tokens___wrapped_statements.2, .-silver_output_profile__tokens___wrapped_statements.2
	.section	.rodata
	.align 8
.LC15:
	.ascii	"failed postcondition from silver_output_profile.ads:46"
	.align 8
.LC16:
	.ascii	"failed postcondition from silver_output_profile.ads:47"
	.text
	.align 2
	.globl	silver_output_profile__tokens
	.type	silver_output_profile__tokens, @function
silver_output_profile__tokens:
.LFB9:
	.loc 2 88 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movb	%dil, -65(%rbp)
	.loc 2 88 4
	leaq	16(%rbp), %rax
	.loc 2 88 4 is_stmt 0 discriminator 1
	movq	%rax, -56(%rbp)
	movzbl	-65(%rbp), %eax
	movb	%al, -64(%rbp)
.LBB9:
	leaq	-64(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__tokens___wrapped_statements.2
	.loc 2 88 4 discriminator 2
	movq	%rax, %rcx
	movq	%rdx, %rbx
	movq	%rbx, %rax
	movl	(%rax), %eax
	movq	%rbx, %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	.loc 2 88 4 discriminator 5
	cmpl	%eax, %edx
	.loc 2 88 4 discriminator 8
	cmpl	%eax, %edx
	.loc 2 88 4 discriminator 11
	cmpl	%eax, %edx
	jl	.L105
	.loc 2 88 4 discriminator 12
	testl	%eax, %eax
	jg	.L105
	.loc 2 88 4 discriminator 13
	leaq	.LC12(%rip), %rax
	movl	$88, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L105:
	.loc 1 46 16 is_stmt 1
	cmpl	$1, %eax
	je	.L106
.LBB10:
	.loc 1 46 16 is_stmt 0 discriminator 1
	leaq	.LC15(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L106:
.LBE10:
	.loc 1 46 16 discriminator 2
	cmpl	%eax, %edx
	jl	.L107
	.loc 1 47 40 is_stmt 1
	movl	%edx, %esi
	movl	%eax, %edi
	subl	%edi, %esi
	addl	$1, %esi
	testl	%esi, %esi
	jle	.L107
	.loc 1 47 40 is_stmt 0 discriminator 1
	cmpl	%eax, %edx
	jl	.L108
	.loc 1 47 40 discriminator 2
	movl	%edx, %esi
	movl	%eax, %edx
	movl	%esi, %eax
	subl	%edx, %eax
	addl	$1, %eax
	cmpl	$100, %eax
	jle	.L108
.L107:
.LBB11:
	.loc 1 46 16 is_stmt 1 discriminator 3
	leaq	.LC16(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L108:
.LBE11:
	.loc 2 88 4 discriminator 14
	movq	%rcx, %rax
	movq	%rbx, %rdx
.LBE9:
	.loc 2 88 4 is_stmt 0
	addq	$40, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE9:
	.size	silver_output_profile__tokens, .-silver_output_profile__tokens
	.align 2
	.type	silver_output_profile__normalized___wrapped_statements.3, @function
silver_output_profile__normalized___wrapped_statements.3:
.LFB12:
	.loc 2 101 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rcx
	movq	%r10, -88(%rbp)
	.loc 2 101 4
	movl	12(%rcx), %edx
	movl	8(%rcx), %eax
	cmpl	%eax, %edx
	jl	.L111
	.loc 2 101 4 is_stmt 0 discriminator 1
	movl	12(%rcx), %esi
	movslq	%esi, %rax
	cqto
	movl	8(%rcx), %r8d
	movslq	%r8d, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L112
.L111:
	.loc 2 101 4 discriminator 2
	movl	$0, %eax
	movl	$0, %edx
.L112:
	movq	%rsp, %rsi
	movq	%rsi, %r15
.LBB12:
	.loc 2 107 7 is_stmt 1
	movl	%eax, -52(%rbp)
	movl	-52(%rbp), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	cltq
	movq	%rax, -64(%rbp)
	movl	-52(%rbp), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	movslq	%eax, %r14
	.loc 2 107 54
	movl	-52(%rbp), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	cltq
	movl	12(%rcx), %esi
	movl	8(%rcx), %edx
	cmpl	%edx, %esi
	jl	.L113
	.loc 2 107 54 is_stmt 0 discriminator 1
	movl	12(%rcx), %edx
	movslq	%edx, %rsi
	movl	8(%rcx), %edx
	movslq	%edx, %rdx
	subq	%rdx, %rsi
	movq	%rsi, %rdx
	addq	$1, %rdx
	jmp	.L114
.L113:
	.loc 2 107 54 discriminator 2
	movl	$0, %edx
.L114:
	.loc 2 107 54 discriminator 3
	cmpq	%rax, %rdx
	je	.L115
	.loc 2 107 54 discriminator 4
	leaq	.LC12(%rip), %rax
	movl	$107, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Length_Check@PLT
.L115:
	.loc 2 107 7 is_stmt 1 discriminator 5
	movl	-52(%rbp), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	cltq
	movl	$16, %edx
	subq	$1, %rdx
	addq	%rdx, %rax
	movl	$16, %edi
	movl	$0, %edx
	divq	%rdi
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	movq	%rax, -72(%rbp)
	.loc 2 107 7 is_stmt 0 discriminator 6
	movq	(%rcx), %rax
	movq	(%rax), %rax
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r14, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 109 7 is_stmt 1
	movl	-52(%rbp), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	cltq
	addq	$11, %rax
	andq	$-4, %rax
	movl	$4, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rbx
	.loc 2 109 7 is_stmt 0 discriminator 1
	movq	%rbx, %rax
	movl	$1, (%rax)
	movl	-52(%rbp), %edx
	movl	%edx, 4(%rax)
	leaq	8(%rax), %rdx
	movq	-72(%rbp), %rax
	movq	%rdx, %rcx
	movq	%r14, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 109 7 discriminator 2
	movq	%rbx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rbx, %rax
	movq	%rax, %r13
	.loc 2 110 8 is_stmt 1
	movq	%r15, %rsp
	.loc 2 109 7 discriminator 3
	movq	%r12, %rax
	movq	%r13, %rdx
.LBE12:
	.loc 2 110 8
	leaq	-40(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE12:
	.size	silver_output_profile__normalized___wrapped_statements.3, .-silver_output_profile__normalized___wrapped_statements.3
	.section	.rodata
	.align 8
.LC17:
	.ascii	"failed precondition from silver_output_profile.adb:102"
	.align 8
.LC18:
	.ascii	"failed postcondition from silver_output_profile.adb:103"
	.align 8
.LC19:
	.ascii	"failed postcondition from silver_output_profile.adb:104"
	.align 8
.LC20:
	.ascii	"failed postcondition from silver_output_profile.adb:105"
	.align 8
.LC1:
	.long	1
	.long	55
	.text
	.align 2
	.globl	silver_output_profile__normalized
	.type	silver_output_profile__normalized, @function
silver_output_profile__normalized:
.LFB11:
	.loc 2 101 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rcx
	movq	%rcx, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -96(%rbp)
	movq	%rbx, -88(%rbp)
	.loc 2 101 4
	leaq	16(%rbp), %rsi
	.loc 2 101 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rcx
	movq	%rsi, -64(%rbp)
	movq	%rcx, -80(%rbp)
	movq	-88(%rbp), %rcx
	movl	(%rcx), %ecx
	movl	%ecx, -72(%rbp)
	movq	-88(%rbp), %rcx
	movl	4(%rcx), %ecx
	movl	%ecx, -68(%rbp)
	movl	-68(%rbp), %esi
	movl	-72(%rbp), %ecx
	cmpl	%ecx, %esi
	jl	.L118
	.loc 2 101 4 discriminator 2
	movl	-68(%rbp), %esi
	movslq	%esi, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	movl	-72(%rbp), %r8d
	movslq	%r8d, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rcx
	sbbq	%rdi, %rbx
	addq	$1, %rcx
	adcq	$0, %rbx
	movq	%rcx, -128(%rbp)
	movq	%rbx, -120(%rbp)
	jmp	.L119
.L118:
	.loc 2 101 4 discriminator 3
	movq	$0, -128(%rbp)
	movq	$0, -120(%rbp)
.L119:
.LBB13:
	.loc 2 101 4 discriminator 4
	movl	-68(%rbp), %esi
	movl	-72(%rbp), %ecx
	cmpl	%ecx, %esi
	.loc 2 101 4 discriminator 7
	movl	-68(%rbp), %esi
	movl	-72(%rbp), %ecx
	cmpl	%ecx, %esi
	.loc 2 101 4 discriminator 10
	movl	-68(%rbp), %esi
	movl	-72(%rbp), %ecx
	cmpl	%ecx, %esi
	.loc 2 102 48 is_stmt 1
	movl	-72(%rbp), %ecx
	movslq	%ecx, %rcx
	leaq	4095(%rcx), %rsi
	movl	-68(%rbp), %ecx
	movslq	%ecx, %rcx
	.loc 2 102 34
	cmpq	%rcx, %rsi
	jge	.L126
.LBB14:
	.loc 2 102 34 is_stmt 0 discriminator 1
	leaq	.LC17(%rip), %rax
	leaq	.LC0(%rip), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L126:
.LBE14:
.LBB15:
	.loc 2 101 4 is_stmt 1 discriminator 13
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__normalized___wrapped_statements.3
	.loc 2 101 4 is_stmt 0 discriminator 14
	movq	%rax, %rbx
	movq	%rdx, %rsi
	movq	%rbx, -112(%rbp)
	movq	%rsi, -104(%rbp)
	movq	%rsi, %rax
	movl	(%rax), %eax
	movq	%rsi, %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	.loc 2 101 4 discriminator 17
	cmpl	%eax, %edx
	.loc 2 101 4 discriminator 20
	cmpl	%eax, %edx
	jl	.L131
	.loc 2 101 4 discriminator 21
	movslq	%edx, %rsi
	movslq	%eax, %rcx
	subq	%rcx, %rsi
	leaq	1(%rsi), %rcx
	jmp	.L132
.L131:
	.loc 2 101 4 discriminator 22
	movl	$0, %ecx
.L132:
	.loc 2 101 4 discriminator 23
	cmpl	%eax, %edx
	jl	.L133
	.loc 2 101 4 discriminator 24
	testl	%eax, %eax
	jg	.L133
	.loc 2 101 4 discriminator 25
	leaq	.LC12(%rip), %rax
	movl	$101, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L133:
	.loc 2 103 16 is_stmt 1
	cmpl	$1, %eax
	je	.L134
.LBB16:
	.loc 2 103 16 is_stmt 0 discriminator 1
	leaq	.LC18(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L134:
.LBE16:
	.loc 2 104 36 is_stmt 1
	cmpl	%eax, %edx
	jl	.L135
	.loc 2 104 36 is_stmt 0 discriminator 1
	movl	%edx, %esi
	movl	%eax, %edi
	subl	%edi, %esi
	addl	$1, %esi
	movl	%esi, %edi
	jmp	.L136
.L135:
	.loc 2 104 36 discriminator 2
	movl	$0, %edi
.L136:
	.loc 2 104 44 is_stmt 1 discriminator 3
	movl	-128(%rbp), %esi
	.loc 2 103 16 discriminator 2
	cmpl	%esi, %edi
	je	.L137
.LBB17:
	.loc 2 103 16 is_stmt 0 discriminator 3
	leaq	.LC19(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L137:
.LBE17:
	.loc 2 103 16 discriminator 4
	cmpl	%eax, %edx
	jge	.L138
	.loc 2 105 37 is_stmt 1
	movl	-68(%rbp), %edi
	movl	-72(%rbp), %esi
	cmpl	%esi, %edi
	jl	.L139
.L138:
	.loc 2 105 37 is_stmt 0 discriminator 1
	cmpl	%eax, %edx
	jl	.L140
	.loc 2 105 37 discriminator 2
	movslq	%edx, %rdx
	cltq
	subq	%rax, %rdx
	addq	$1, %rdx
	jmp	.L141
.L140:
	.loc 2 105 37 discriminator 3
	movl	$0, %edx
.L141:
	.loc 2 105 37 discriminator 4
	movl	-68(%rbp), %esi
	movl	-72(%rbp), %eax
	cmpl	%eax, %esi
	jl	.L142
	.loc 2 105 37 discriminator 5
	movl	-68(%rbp), %eax
	movslq	%eax, %rsi
	movl	-72(%rbp), %eax
	cltq
	subq	%rax, %rsi
	leaq	1(%rsi), %rax
	jmp	.L143
.L142:
	.loc 2 105 37 discriminator 6
	movl	$0, %eax
.L143:
	.loc 2 105 37 discriminator 7
	cmpq	%rax, %rdx
	jne	.L144
	.loc 2 105 37 discriminator 8
	movq	-96(%rbp), %rax
	movq	-112(%rbp), %rdi
	movq	%rcx, %rdx
	movq	%rax, %rsi
	call	memcmp@PLT
	.loc 2 105 37 discriminator 9
	testl	%eax, %eax
	je	.L139
.L144:
.LBB18:
	.loc 2 103 16 is_stmt 1 discriminator 5
	leaq	.LC20(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L139:
.LBE18:
	.loc 2 101 4 discriminator 26
	movq	-112(%rbp), %rax
	movq	-104(%rbp), %rdx
.LBE15:
.LBE13:
	.loc 2 101 4 is_stmt 0
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE11:
	.size	silver_output_profile__normalized, .-silver_output_profile__normalized
	.align 2
	.globl	silver_output_profile__binding_infoIP
	.type	silver_output_profile__binding_infoIP, @function
silver_output_profile__binding_infoIP:
.LFB13:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE13:
	.size	silver_output_profile__binding_infoIP, .-silver_output_profile__binding_infoIP
	.align 2
	.globl	silver_output_profile__Tbinding_arrayBIP
	.type	silver_output_profile__Tbinding_arrayBIP, @function
silver_output_profile__Tbinding_arrayBIP:
.LFB14:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE14:
	.size	silver_output_profile__Tbinding_arrayBIP, .-silver_output_profile__Tbinding_arrayBIP
	.align 2
	.globl	silver_output_profile__binding_environmentIP
	.type	silver_output_profile__binding_environmentIP, @function
silver_output_profile__binding_environmentIP:
.LFB15:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE15:
	.size	silver_output_profile__binding_environmentIP, .-silver_output_profile__binding_environmentIP
	.section	.rodata
	.align 8
.LC21:
	.ascii	"failed precondition from silver_output_profile.adb:135"
	.text
	.align 2
	.globl	silver_output_profile__valid_names
	.type	silver_output_profile__valid_names, @function
silver_output_profile__valid_names:
.LFB16:
	.loc 2 136 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r12
	pushq	%rbx
	subq	$48, %rsp
	.cfi_offset 12, -24
	.cfi_offset 3, -32
	movq	%rdi, %rax
	movq	%rsi, %r10
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r10, %rdi
	movq	%rsi, -48(%rbp)
	movq	%rdi, -40(%rbp)
	movq	%rdx, -56(%rbp)
	.loc 2 136 4
	movq	-40(%rbp), %rax
	movl	(%rax), %r10d
	movq	-40(%rbp), %rax
	movl	4(%rax), %r12d
	movq	-40(%rbp), %rax
	movl	4(%rax), %edx
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L153
	.loc 2 136 4 is_stmt 0 discriminator 1
	movq	-40(%rbp), %rax
	movl	4(%rax), %esi
	movslq	%esi, %rax
	cqto
	movq	-40(%rbp), %rsi
	movl	(%rsi), %r11d
	movslq	%r11d, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L154
.L153:
	.loc 2 136 4 discriminator 2
	movl	$0, %eax
	movl	$0, %edx
.L154:
.LBB19:
	.loc 2 135 15 is_stmt 1
	cmpl	$1, %r10d
	je	.L155
.LBB20:
	.loc 2 135 15 is_stmt 0 discriminator 1
	leaq	.LC21(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L155:
.LBE20:
	.loc 2 135 51 is_stmt 1 discriminator 2
	movl	%eax, %esi
	.loc 2 135 15 discriminator 2
	testl	%esi, %esi
	jle	.L156
	.loc 2 135 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L157
.L156:
.LBB21:
	.loc 2 135 15 discriminator 4
	leaq	.LC21(%rip), %rcx
	leaq	.LC0(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L157:
.LBE21:
	.loc 2 137 7
	movl	$1, %ebx
	.loc 2 137 30
	movq	-56(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -24(%rbp)
	movl	-24(%rbp), %eax
	cmpl	$341, %eax
	jbe	.L158
	.loc 2 137 30 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$137, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L158:
.LBB22:
	.loc 2 137 15 is_stmt 1 discriminator 2
	movl	$1, -20(%rbp)
.L163:
	.loc 2 137 7 discriminator 3
	movl	-20(%rbp), %eax
	cmpl	-24(%rbp), %eax
	jg	.L164
.LBB23:
	.loc 2 138 31
	movl	-20(%rbp), %eax
	cltq
	movq	-56(%rbp), %rcx
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$2, %rax
	addq	%rcx, %rax
	addq	$4, %rax
	movl	(%rax), %eax
	.loc 2 137 7 discriminator 4
	testl	%eax, %eax
	jle	.L160
	.loc 2 139 18
	movl	-20(%rbp), %eax
	cltq
	movq	-56(%rbp), %rcx
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$2, %rax
	addq	%rcx, %rax
	addq	$8, %rax
	movl	(%rax), %ecx
	movl	-20(%rbp), %eax
	cltq
	movq	-56(%rbp), %rsi
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$2, %rax
	addq	%rsi, %rax
	addq	$4, %rax
	movl	(%rax), %edx
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__valid_name_state@PLT
	.loc 2 139 18 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 139 9 is_stmt 1 discriminator 1
	testb	%al, %al
	jne	.L160
	.loc 2 140 46
	movl	-20(%rbp), %eax
	cltq
	movq	-56(%rbp), %rcx
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$2, %rax
	addq	%rcx, %rax
	addq	$12, %rax
	movl	(%rax), %eax
	.loc 2 140 59
	cmpl	$2147483647, %r12d
	jne	.L161
	.loc 2 140 59 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$140, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L161:
	.loc 2 140 59 discriminator 3
	leal	1(%r12), %edx
	.loc 2 140 9 is_stmt 1 discriminator 4
	cmpl	%eax, %edx
	jge	.L162
.L160:
	.loc 2 137 7 discriminator 5
	movl	$0, %ebx
.LBE23:
.LBE22:
	.loc 2 137 7 is_stmt 0 discriminator 7
	jmp	.L164
.L162:
.LBB24:
	.loc 2 137 7 discriminator 6
	addl	$1, -20(%rbp)
	jmp	.L163
.L164:
.LBE24:
	.loc 2 137 7 discriminator 8
	movl	%ebx, %eax
.LBE19:
	.loc 2 136 4 is_stmt 1
	addq	$48, %rsp
	popq	%rbx
	popq	%r12
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE16:
	.size	silver_output_profile__valid_names, .-silver_output_profile__valid_names
	.align 2
	.globl	silver_output_profile__parser_stateIP
	.type	silver_output_profile__parser_stateIP, @function
silver_output_profile__parser_stateIP:
.LFB17:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE17:
	.size	silver_output_profile__parser_stateIP, .-silver_output_profile__parser_stateIP
	.section	.rodata
	.align 8
.LC22:
	.ascii	"failed precondition from silver_output_profile.adb:172"
	.text
	.align 2
	.globl	silver_output_profile__valid_state
	.type	silver_output_profile__valid_state, @function
silver_output_profile__valid_state:
.LFB18:
	.loc 2 173 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r12
	pushq	%rbx
	subq	$32, %rsp
	.cfi_offset 12, -24
	.cfi_offset 3, -32
	movq	%rdi, %rax
	movq	%rsi, %r10
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r10, %rdi
	movq	%rsi, -32(%rbp)
	movq	%rdi, -24(%rbp)
	movq	%rdx, -40(%rbp)
	.loc 2 173 4
	movq	-24(%rbp), %rax
	movl	(%rax), %r11d
	movq	-24(%rbp), %rax
	movl	4(%rax), %r10d
	movq	-24(%rbp), %rax
	movl	4(%rax), %edx
	movq	-24(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L168
	.loc 2 173 4 is_stmt 0 discriminator 1
	movq	-24(%rbp), %rax
	movl	4(%rax), %esi
	movslq	%esi, %rax
	cqto
	movq	-24(%rbp), %rsi
	movl	(%rsi), %r12d
	movslq	%r12d, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L169
.L168:
	.loc 2 173 4 discriminator 2
	movl	$0, %eax
	movl	$0, %edx
.L169:
.LBB25:
	.loc 2 172 15 is_stmt 1
	cmpl	$1, %r11d
	je	.L170
.LBB26:
	.loc 2 172 15 is_stmt 0 discriminator 1
	leaq	.LC22(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L170:
.LBE26:
	.loc 2 172 51 is_stmt 1 discriminator 2
	movl	%eax, %esi
	.loc 2 172 15 discriminator 2
	testl	%esi, %esi
	jle	.L171
	.loc 2 172 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L172
.L171:
.LBB27:
	.loc 2 172 15 discriminator 4
	leaq	.LC22(%rip), %rcx
	leaq	.LC0(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L172:
.LBE27:
	.loc 2 174 22
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 174 35
	cmpl	$2147483647, %r10d
	jne	.L173
	.loc 2 174 35 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$174, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L173:
	.loc 2 174 35 discriminator 3
	leal	1(%r10), %edx
	.loc 2 180 7 is_stmt 1
	cmpl	%eax, %edx
	jl	.L174
	.loc 2 175 16
	movq	-40(%rbp), %rax
	leaq	4(%rax), %rdx
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_names
	.loc 2 175 7 discriminator 1
	testb	%al, %al
	je	.L174
	.loc 2 176 34
	movq	-40(%rbp), %rax
	leaq	6828(%rax), %rdx
	movq	-32(%rbp), %rcx
	movq	-24(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__valid_environment@PLT
	.loc 2 176 7 discriminator 1
	testb	%al, %al
	je	.L174
	.loc 2 177 16
	movq	-40(%rbp), %rax
	addq	$6828, %rax
	movq	%rax, %rdi
	call	silver_output_profile__valid_mutable_bounds
	.loc 2 177 7 discriminator 1
	testb	%al, %al
	je	.L174
	.loc 2 178 16
	movq	-40(%rbp), %rax
	movl	6828(%rax), %eax
	movq	-40(%rbp), %rdx
	addq	$6828, %rdx
	movl	%eax, %esi
	movq	%rdx, %rdi
	call	silver_output_profile__valid_declaration_values
	.loc 2 178 7 discriminator 1
	testb	%al, %al
	je	.L174
	.loc 2 179 16
	movq	-40(%rbp), %rax
	movl	17748(%rax), %ecx
	movq	-40(%rbp), %rax
	movl	17744(%rax), %edx
	movq	-32(%rbp), %rsi
	movq	-24(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__valid_name_state@PLT
	.loc 2 179 7 discriminator 1
	testb	%al, %al
	je	.L174
	.loc 2 180 29 discriminator 1
	movq	-40(%rbp), %rax
	movl	17752(%rax), %edx
	movq	-40(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 180 7 discriminator 1
	cmpl	%eax, %edx
	jg	.L174
	.loc 2 180 7 is_stmt 0 discriminator 2
	movl	$1, %eax
	jmp	.L175
.L174:
	.loc 2 180 7 discriminator 3
	movl	$0, %eax
.L175:
.LBE25:
	.loc 2 173 4 is_stmt 1
	addq	$32, %rsp
	popq	%rbx
	popq	%r12
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE18:
	.size	silver_output_profile__valid_state, .-silver_output_profile__valid_state
	.section	.rodata
	.align 8
.LC23:
	.ascii	"failed precondition from silver_output_profile.adb:186"
	.align 8
.LC24:
	.ascii	"failed precondition from silver_output_profile.adb:187"
	.text
	.align 2
	.globl	silver_output_profile__skip_at
	.type	silver_output_profile__skip_at, @function
silver_output_profile__skip_at:
.LFB19:
	.loc 2 191 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -64(%rbp)
	movq	%rbx, -56(%rbp)
	movl	%edx, -68(%rbp)
	.loc 2 191 4
	movq	-56(%rbp), %rax
	movl	(%rax), %edx
	movq	-56(%rbp), %rax
	movl	4(%rax), %eax
	cmpl	%edx, %eax
	jl	.L178
	.loc 2 191 4 is_stmt 0 discriminator 1
	movslq	%eax, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	movslq	%edx, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rcx
	sbbq	%rdi, %rbx
	addq	$1, %rcx
	adcq	$0, %rbx
	jmp	.L179
.L178:
	.loc 2 191 4 discriminator 2
	movl	$0, %ecx
	movl	$0, %ebx
.L179:
.LBB28:
	.loc 2 191 4 discriminator 3
	cmpl	%edx, %eax
	.loc 2 191 4 discriminator 6
	cmpl	%edx, %eax
	.loc 2 191 4 discriminator 9
	cmpl	%edx, %eax
	.loc 2 186 15 is_stmt 1
	cmpl	$1, %edx
	je	.L186
.LBB29:
	.loc 2 186 15 is_stmt 0 discriminator 1
	leaq	.LC23(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L186:
.LBE29:
	.loc 2 186 51 is_stmt 1 discriminator 2
	movl	%ecx, %edx
	.loc 2 186 15 discriminator 2
	testl	%edx, %edx
	jle	.L187
	.loc 2 186 51 discriminator 3
	movl	%ecx, %edx
	cmpl	$4096, %edx
	jle	.L188
.L187:
.LBB30:
	.loc 2 186 15 discriminator 4
	leaq	.LC23(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L188:
.LBE30:
	.loc 2 187 41
	cmpl	$2147483647, %eax
	jne	.L189
	.loc 2 187 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$187, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L189:
	.loc 2 187 41 discriminator 3
	addl	$1, %eax
	.loc 2 186 15 is_stmt 1 discriminator 5
	cmpl	-68(%rbp), %eax
	jge	.L190
.LBB31:
	.loc 2 186 15 is_stmt 0 discriminator 6
	leaq	.LC24(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L190:
.LBE31:
	.loc 2 194 7 is_stmt 1
	cmpl	$0, -68(%rbp)
	jne	.L191
	.loc 2 194 28 discriminator 1
	movl	$0, %eax
	jmp	.L192
.L191:
	.loc 2 195 15
	cmpl	$0, -68(%rbp)
	jle	.L193
	.loc 2 195 15 is_stmt 0 discriminator 1
	cmpl	$4097, -68(%rbp)
	jle	.L194
.L193:
	.loc 2 195 15 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$195, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L194:
	.loc 2 195 12 is_stmt 1 discriminator 3
	movl	-68(%rbp), %eax
	movl	%eax, -36(%rbp)
	.loc 2 196 7
	movl	-36(%rbp), %edx
	movq	-64(%rbp), %rcx
	movq	-56(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__skip_trivia@PLT
	.loc 2 196 7 is_stmt 0 discriminator 1
	movl	%eax, -36(%rbp)
	.loc 2 197 7 is_stmt 1
	movl	-36(%rbp), %eax
.L192:
.LBE28:
	.loc 2 198 8
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE19:
	.size	silver_output_profile__skip_at, .-silver_output_profile__skip_at
	.section	.rodata
	.align 8
.LC25:
	.ascii	"failed precondition from silver_output_profile.adb:202"
	.align 8
.LC26:
	.ascii	"failed precondition from silver_output_profile.adb:203"
	.text
	.align 2
	.globl	silver_output_profile__name_after
	.type	silver_output_profile__name_after, @function
silver_output_profile__name_after:
.LFB20:
	.loc 2 208 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -64(%rbp)
	movq	%rbx, -56(%rbp)
	movl	%edx, -68(%rbp)
	.loc 2 208 4
	movq	-56(%rbp), %rax
	movl	(%rax), %edx
	movq	-56(%rbp), %rax
	movl	4(%rax), %eax
	cmpl	%edx, %eax
	jl	.L196
	.loc 2 208 4 is_stmt 0 discriminator 1
	movslq	%eax, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	movslq	%edx, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rcx
	sbbq	%rdi, %rbx
	addq	$1, %rcx
	adcq	$0, %rbx
	jmp	.L197
.L196:
	.loc 2 208 4 discriminator 2
	movl	$0, %ecx
	movl	$0, %ebx
.L197:
.LBB32:
	.loc 2 208 4 discriminator 3
	cmpl	%edx, %eax
	.loc 2 208 4 discriminator 6
	cmpl	%edx, %eax
	.loc 2 208 4 discriminator 9
	cmpl	%edx, %eax
	.loc 2 202 15 is_stmt 1
	cmpl	$1, %edx
	je	.L204
.LBB33:
	.loc 2 202 15 is_stmt 0 discriminator 1
	leaq	.LC25(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L204:
.LBE33:
	.loc 2 202 51 is_stmt 1 discriminator 2
	movl	%ecx, %edx
	.loc 2 202 15 discriminator 2
	testl	%edx, %edx
	jle	.L205
	.loc 2 202 51 discriminator 3
	movl	%ecx, %edx
	cmpl	$4096, %edx
	jle	.L206
.L205:
.LBB34:
	.loc 2 202 15 discriminator 4
	leaq	.LC25(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L206:
.LBE34:
	.loc 2 203 41
	cmpl	$2147483647, %eax
	jne	.L207
	.loc 2 203 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$203, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L207:
	.loc 2 203 41 discriminator 3
	addl	$1, %eax
	.loc 2 202 15 is_stmt 1 discriminator 5
	cmpl	-68(%rbp), %eax
	jge	.L208
.LBB35:
	.loc 2 202 15 is_stmt 0 discriminator 6
	leaq	.LC26(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L208:
.LBE35:
	.loc 2 212 7 is_stmt 1
	cmpl	$0, -68(%rbp)
	jne	.L209
	.loc 2 212 28 discriminator 1
	movl	$0, %eax
	jmp	.L210
.L209:
	.loc 2 213 15
	cmpl	$0, -68(%rbp)
	jle	.L211
	.loc 2 213 15 is_stmt 0 discriminator 1
	cmpl	$4097, -68(%rbp)
	jle	.L212
.L211:
	.loc 2 213 15 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$213, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L212:
	.loc 2 213 12 is_stmt 1 discriminator 3
	movl	-68(%rbp), %eax
	movl	%eax, -36(%rbp)
.LBB36:
	.loc 2 214 7
	movl	-36(%rbp), %edx
	movq	-64(%rbp), %rcx
	movq	-56(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__match_identifier@PLT
	.loc 2 214 7 is_stmt 0 discriminator 1
	movl	%eax, -36(%rbp)
	shrq	$32, %rax
	andb	$-1, %ah
	movb	%al, -37(%rbp)
.LBE36:
	.loc 2 215 15 is_stmt 1
	cmpb	$0, -37(%rbp)
	je	.L213
	.loc 2 215 31 discriminator 1
	movl	-36(%rbp), %eax
	jmp	.L210
.L213:
	.loc 2 215 41 discriminator 2
	movl	$0, %eax
.L210:
.LBE32:
	.loc 2 216 8
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE20:
	.size	silver_output_profile__name_after, .-silver_output_profile__name_after
	.align 2
	.type	silver_output_profile__match_token___finalizer.4, @function
silver_output_profile__match_token___finalizer.4:
.LFB22:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE22:
	.size	silver_output_profile__match_token___finalizer.4, .-silver_output_profile__match_token___finalizer.4
	.section	.rodata
	.align 8
.LC27:
	.ascii	"failed precondition from silver_output_profile.adb:237"
	.align 8
.LC28:
	.ascii	"failed precondition from silver_output_profile.adb:238"
	.text
	.align 2
	.type	silver_output_profile__match_token, @function
silver_output_profile__match_token:
.LFB21:
	.loc 2 233 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA21
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB0:
	subq	$184, %rsp
.LEHE0:
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -144(%rbp)
	movq	%rdi, -136(%rbp)
	movl	%edx, -148(%rbp)
	movb	%cl, -149(%rbp)
	.loc 2 233 4
	leaq	16(%rbp), %rax
	.loc 2 233 4 is_stmt 0 discriminator 1
	movq	%rax, -104(%rbp)
	movq	-136(%rbp), %rax
	movl	(%rax), %r14d
	movq	-136(%rbp), %rax
	movl	4(%rax), %ebx
	cmpl	%r14d, %ebx
	jl	.L217
	.loc 2 233 4 discriminator 2
	movslq	%ebx, %rax
	cqto
	movslq	%r14d, %rcx
	movq	%rcx, %rsi
	movq	%rcx, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %r12
	movq	%rdx, %r13
	jmp	.L218
.L217:
	.loc 2 233 4 discriminator 3
	movl	$0, %r12d
	movl	$0, %r13d
.L218:
	leaq	-128(%rbp), %rax
	movq	%rax, %rdi
.LEHB1:
	call	system__secondary_stack__ss_mark@PLT
	movslq	%r14d, %r15
	cmpl	%r14d, %ebx
	cmpl	%r14d, %ebx
	cmpl	%r14d, %ebx
.LBB37:
	.loc 2 237 15 is_stmt 1
	cmpl	$1, %r14d
	je	.L225
.LBB38:
	.loc 2 237 15 is_stmt 0 discriminator 1
	leaq	.LC27(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L225:
.LBE38:
	.loc 2 237 51 is_stmt 1 discriminator 2
	movl	%r12d, %eax
	.loc 2 237 15 discriminator 2
	testl	%eax, %eax
	jle	.L226
	.loc 2 237 51 discriminator 3
	movl	%r12d, %eax
	cmpl	$4096, %eax
	jle	.L227
.L226:
.LBB39:
	.loc 2 237 15 discriminator 4
	leaq	.LC27(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L227:
.LBE39:
	.loc 2 238 41
	cmpl	$2147483647, %ebx
	jne	.L228
	.loc 2 238 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$238, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L228:
	.loc 2 238 41 discriminator 3
	leal	1(%rbx), %eax
	.loc 2 237 15 is_stmt 1 discriminator 5
	cmpl	-148(%rbp), %eax
	jge	.L229
.LBB40:
	.loc 2 237 15 is_stmt 0 discriminator 6
	leaq	.LC28(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rcx
	movq	-168(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L229:
.LBE40:
	.loc 2 245 33 is_stmt 1
	movzbl	-149(%rbp), %eax
	movl	%eax, %edi
	call	silver_output_profile__spelling
	.loc 2 245 33 is_stmt 0 discriminator 1
	movq	%rax, %r12
	movq	%rdx, %r13
	movq	%r13, %rax
	movl	(%rax), %eax
	movl	%eax, -56(%rbp)
	movq	%r13, %rax
	movl	4(%rax), %eax
	movl	%eax, -60(%rbp)
	.loc 2 245 7 is_stmt 1 discriminator 1
	movl	-56(%rbp), %eax
	cltq
	movq	%rax, -72(%rbp)
	movl	-60(%rbp), %eax
	cmpl	-56(%rbp), %eax
	jl	.L230
	.loc 2 245 7 is_stmt 0 discriminator 2
	movl	-60(%rbp), %eax
	cltq
	movq	%rax, -80(%rbp)
	jmp	.L231
.L230:
	.loc 2 245 7 discriminator 3
	movl	-56(%rbp), %eax
	cltq
	subq	$1, %rax
	movq	%rax, -80(%rbp)
.L231:
	.loc 2 245 7 discriminator 4
	movl	-60(%rbp), %eax
	cmpl	-56(%rbp), %eax
	.loc 2 245 7 discriminator 7
	movl	-60(%rbp), %eax
	cmpl	-56(%rbp), %eax
	.loc 2 245 33 is_stmt 1 discriminator 10
	movl	-60(%rbp), %eax
	cmpl	-56(%rbp), %eax
	jl	.L236
	.loc 2 245 33 is_stmt 0 discriminator 11
	cmpl	$0, -56(%rbp)
	jg	.L236
	.loc 2 245 33 discriminator 12
	leaq	.LC12(%rip), %rax
	movl	$245, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L236:
	.loc 2 245 7 is_stmt 1 discriminator 13
	movq	%r12, -88(%rbp)
	.loc 2 247 15
	movb	$0, -89(%rbp)
	.loc 2 248 14
	movl	-60(%rbp), %eax
	cmpl	-56(%rbp), %eax
	jl	.L237
	.loc 2 248 14 is_stmt 0 discriminator 1
	movl	-60(%rbp), %eax
	movslq	%eax, %rdx
	movl	-56(%rbp), %eax
	cltq
	subq	%rax, %rdx
	movq	%rdx, %rax
	addq	$1, %rax
	jmp	.L238
.L237:
	.loc 2 248 14 discriminator 2
	movl	$0, %eax
.L238:
	.loc 2 248 14 discriminator 3
	cmpq	$2147483647, %rax
	jle	.L239
	.loc 2 248 14 discriminator 4
	leaq	.LC12(%rip), %rax
	movl	$248, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L239:
	.loc 2 248 22 is_stmt 1 discriminator 5
	movl	%eax, %edx
	.loc 2 248 35 discriminator 5
	movl	$0, %ecx
	movl	%ebx, %eax
	subl	-148(%rbp), %eax
	jno	.L240
	movl	$1, %ecx
.L240:
	movl	%eax, %esi
	.loc 2 248 35 is_stmt 0 discriminator 6
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L242
	.loc 2 248 35 discriminator 7
	leaq	.LC12(%rip), %rax
	movl	$248, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L242:
	.loc 2 248 35 discriminator 9
	movl	%esi, %eax
	.loc 2 248 47 is_stmt 1 discriminator 10
	cmpl	$2147483647, %eax
	jne	.L243
	.loc 2 248 47 is_stmt 0 discriminator 11
	leaq	.LC12(%rip), %rax
	movl	$248, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L243:
	.loc 2 248 47 discriminator 13
	addl	$1, %eax
	.loc 2 248 7 is_stmt 1 discriminator 14
	cmpl	%edx, %eax
	jge	.L244
	.loc 2 248 56 discriminator 15
	movl	$0, %ebx
	jmp	.L245
.L244:
	.loc 2 249 11
	movl	-56(%rbp), %eax
	cmpl	-60(%rbp), %eax
	jg	.L246
.LBB41:
	.loc 2 249 11 is_stmt 0 discriminator 1
	movl	-56(%rbp), %eax
	movl	%eax, -52(%rbp)
.L254:
.LBB42:
	.loc 2 253 40 is_stmt 1
	movl	$0, %ecx
	movl	-148(%rbp), %edx
	movl	-52(%rbp), %eax
	addl	%edx, %eax
	jno	.L247
	movl	$1, %ecx
.L247:
	movl	%eax, %edx
	.loc 2 253 40 is_stmt 0 discriminator 1
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L249
	.loc 2 253 40 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$253, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L249:
	.loc 2 253 40 discriminator 4
	movl	%edx, %eax
	.loc 2 253 49 is_stmt 1 discriminator 5
	cmpl	$-2147483648, %eax
	jne	.L250
	.loc 2 253 49 is_stmt 0 discriminator 6
	leaq	.LC12(%rip), %rax
	movl	$253, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L250:
	.loc 2 253 49 discriminator 8
	subl	$1, %eax
	.loc 2 253 24 is_stmt 1 discriminator 9
	cmpl	%eax, %r14d
	jg	.L251
	.loc 2 253 24 is_stmt 0 discriminator 10
	cmpl	%eax, %ebx
	jge	.L252
.L251:
	.loc 2 253 24 discriminator 11
	leaq	.LC12(%rip), %rax
	movl	$253, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L252:
	.loc 2 253 13 is_stmt 1 discriminator 12
	movq	-144(%rbp), %rdx
	cltq
	subq	%r15, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 253 13 is_stmt 0 discriminator 13
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__lowercase@PLT
	.loc 2 253 55 is_stmt 1 discriminator 14
	movq	%r12, %rcx
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	subq	-72(%rbp), %rdx
	movzbl	(%rcx,%rdx), %edx
	.loc 2 253 10 discriminator 15
	cmpb	%dl, %al
	je	.L253
	.loc 2 254 13
	movl	$0, %ebx
	jmp	.L245
.L253:
.LBE42:
	.loc 2 249 11 discriminator 2
	movl	-52(%rbp), %eax
	cmpl	-60(%rbp), %eax
	je	.L246
	.loc 2 249 11 is_stmt 0 discriminator 3
	addl	$1, -52(%rbp)
	.loc 2 256 15 is_stmt 1
	jmp	.L254
.L246:
.LBE41:
	.loc 2 257 10
	movzbl	-149(%rbp), %eax
	movl	%eax, %edi
	call	silver_output_profile__is_word_token
	.loc 2 257 7 discriminator 1
	testb	%al, %al
	je	.L255
	.loc 2 257 56 discriminator 2
	movl	-60(%rbp), %eax
	cmpl	-56(%rbp), %eax
	jl	.L256
	.loc 2 257 56 is_stmt 0 discriminator 3
	movl	-60(%rbp), %eax
	movslq	%eax, %rdx
	movl	-56(%rbp), %eax
	cltq
	subq	%rax, %rdx
	movq	%rdx, %rax
	addq	$1, %rax
	jmp	.L257
.L256:
	.loc 2 257 56 discriminator 4
	movl	$0, %eax
.L257:
	.loc 2 257 56 discriminator 5
	cmpq	$2147483647, %rax
	jle	.L258
	.loc 2 257 56 discriminator 6
	leaq	.LC12(%rip), %rax
	movl	$257, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L258:
	.loc 2 257 50 is_stmt 1 discriminator 7
	movl	%eax, %ecx
	movl	$0, %edx
	movl	-148(%rbp), %eax
	addl	%ecx, %eax
	jno	.L259
	movl	$1, %edx
.L259:
	movl	%eax, %ecx
	.loc 2 257 50 is_stmt 0 discriminator 8
	movl	%edx, %eax
	testl	%eax, %eax
	je	.L261
	.loc 2 257 50 discriminator 9
	leaq	.LC12(%rip), %rax
	movl	$257, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L261:
	.loc 2 257 50 discriminator 11
	movl	%ecx, %eax
	.loc 2 257 64 is_stmt 1 discriminator 12
	cmpl	%ebx, %eax
	setle	%al
	.loc 2 257 32 discriminator 12
	testb	%al, %al
	je	.L255
	.loc 2 258 64
	movl	-60(%rbp), %eax
	cmpl	-56(%rbp), %eax
	jl	.L262
	.loc 2 258 64 is_stmt 0 discriminator 1
	movl	-60(%rbp), %eax
	movslq	%eax, %rdx
	movl	-56(%rbp), %eax
	cltq
	subq	%rax, %rdx
	movq	%rdx, %rax
	addq	$1, %rax
	jmp	.L263
.L262:
	.loc 2 258 64 discriminator 2
	movl	$0, %eax
.L263:
	.loc 2 258 64 discriminator 3
	cmpq	$2147483647, %rax
	jle	.L264
	.loc 2 258 64 discriminator 4
	leaq	.LC12(%rip), %rax
	movl	$258, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L264:
	.loc 2 258 58 is_stmt 1 discriminator 5
	movl	%eax, %ecx
	movl	$0, %edx
	movl	-148(%rbp), %eax
	addl	%ecx, %eax
	jno	.L265
	movl	$1, %edx
.L265:
	movl	%eax, %ecx
	.loc 2 258 58 is_stmt 0 discriminator 6
	movl	%edx, %eax
	testl	%eax, %eax
	je	.L267
	.loc 2 258 58 discriminator 7
	leaq	.LC12(%rip), %rax
	movl	$258, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L267:
	.loc 2 258 58 discriminator 9
	movl	%ecx, %eax
	.loc 2 258 43 is_stmt 1 discriminator 10
	cmpl	%eax, %r14d
	jg	.L268
	.loc 2 258 43 is_stmt 0 discriminator 11
	cmpl	%eax, %ebx
	jge	.L269
.L268:
	.loc 2 258 43 discriminator 12
	leaq	.LC12(%rip), %rax
	movl	$258, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L269:
	.loc 2 258 18 is_stmt 1 discriminator 13
	movq	-144(%rbp), %rdx
	cltq
	subq	%r15, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 258 18 is_stmt 0 discriminator 14
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_identifier_character@PLT
	.loc 2 258 9 is_stmt 1 discriminator 15
	testb	%al, %al
	je	.L255
	.loc 2 259 12
	movl	$0, %ebx
	jmp	.L245
.L255:
	.loc 2 260 34
	movl	-60(%rbp), %eax
	cmpl	-56(%rbp), %eax
	jl	.L270
	.loc 2 260 34 is_stmt 0 discriminator 1
	movl	-60(%rbp), %eax
	movslq	%eax, %rdx
	movl	-56(%rbp), %eax
	cltq
	subq	%rax, %rdx
	movq	%rdx, %rax
	addq	$1, %rax
	jmp	.L271
.L270:
	.loc 2 260 34 discriminator 2
	movl	$0, %eax
.L271:
	.loc 2 260 34 discriminator 3
	cmpq	$2147483647, %rax
	jle	.L272
	.loc 2 260 34 discriminator 4
	leaq	.LC12(%rip), %rax
	movl	$260, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L272:
	.loc 2 260 28 is_stmt 1 discriminator 5
	movl	%eax, %ecx
	movl	$0, %edx
	movl	-148(%rbp), %eax
	addl	%ecx, %eax
	jno	.L273
	movl	$1, %edx
.L273:
	movl	%eax, %ecx
	.loc 2 260 28 is_stmt 0 discriminator 6
	movl	%edx, %eax
	testl	%eax, %eax
	je	.L275
	.loc 2 260 28 discriminator 7
	leaq	.LC12(%rip), %rax
	movl	$260, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L275:
	.loc 2 260 28 discriminator 9
	movl	%ecx, %eax
	.loc 2 260 28 discriminator 10
	testl	%eax, %eax
	jle	.L276
	.loc 2 260 28 discriminator 11
	cmpl	$4097, %eax
	jle	.L277
.L276:
	.loc 2 260 28 discriminator 12
	leaq	.LC12(%rip), %rax
	movl	$260, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.LEHE1:
.L277:
	.loc 2 260 16 is_stmt 1 discriminator 13
	movl	%eax, -148(%rbp)
	.loc 2 261 15
	movb	$1, -89(%rbp)
	.loc 2 262 8
	movl	$0, %ebx
.L245:
	.loc 2 262 0 discriminator 1
	leaq	-128(%rbp), %rax
	movq	%rax, %r10
.LEHB2:
	call	silver_output_profile__match_token___finalizer.4
.LEHE2:
	.loc 2 262 0 is_stmt 0 discriminator 2
	cmpl	$1, %ebx
	je	.L278
	movl	$0, %eax
.L284:
	.loc 2 262 8 is_stmt 1 discriminator 3
	cmpl	$1, %eax
	je	.L279
.LBE37:
	.loc 2 262 8 is_stmt 0 discriminator 4
	movl	-148(%rbp), %eax
	movabsq	$-4294967296, %rdx
	andq	-224(%rbp), %rdx
	orq	%rdx, %rax
	movq	%rax, %rcx
	movzbl	-89(%rbp), %eax
	movzbl	%al, %eax
	salq	$32, %rax
	movabsq	$-1095216660481, %rdx
	andq	%rcx, %rdx
	orq	%rdx, %rax
	.loc 2 262 8 discriminator 6
	jmp	.L287
.L285:
	movq	%rax, -216(%rbp)
	movl	$1, %ebx
.LBB43:
	.loc 2 233 4 is_stmt 1 discriminator 5
	jmp	.L245
.L278:
	movq	-216(%rbp), %rax
	movq	%rax, -160(%rbp)
	jmp	.L283
.L286:
	movq	%rax, -160(%rbp)
.L283:
	movl	$1, %eax
	jmp	.L284
.L279:
	movq	-160(%rbp), %rax
	movq	%rax, %rdi
.LEHB3:
	call	_Unwind_Resume@PLT
.L287:
.LBE43:
	.loc 2 262 8
	addq	$184, %rsp
.LEHE3:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE21:
	.section	.gcc_except_table,"a",@progbits
.LLSDA21:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE21-.LLSDACSB21
.LLSDACSB21:
	.uleb128 .LEHB0-.LFB21
	.uleb128 .LEHE0-.LEHB0
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB1-.LFB21
	.uleb128 .LEHE1-.LEHB1
	.uleb128 .L285-.LFB21
	.uleb128 0
	.uleb128 .LEHB2-.LFB21
	.uleb128 .LEHE2-.LEHB2
	.uleb128 .L286-.LFB21
	.uleb128 0
	.uleb128 .LEHB3-.LFB21
	.uleb128 .LEHE3-.LEHB3
	.uleb128 0
	.uleb128 0
.LLSDACSE21:
	.text
	.size	silver_output_profile__match_token, .-silver_output_profile__match_token
	.section	.rodata
	.align 8
.LC29:
	.ascii	"failed precondition from silver_output_profile.adb:268"
	.align 8
.LC30:
	.ascii	"failed precondition from silver_output_profile.adb:269"
	.text
	.align 2
	.globl	silver_output_profile__take_token
	.type	silver_output_profile__take_token, @function
silver_output_profile__take_token:
.LFB23:
	.loc 2 273 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, %rax
	movq	%rsi, %rbx
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%rbx, %rdi
	movq	%rsi, -64(%rbp)
	movq	%rdi, -56(%rbp)
	movl	%edx, -68(%rbp)
	movb	%cl, -69(%rbp)
	.loc 2 273 4
	movq	-56(%rbp), %rax
	movl	(%rax), %edx
	movq	-56(%rbp), %rax
	movl	4(%rax), %eax
	cmpl	%edx, %eax
	jl	.L289
	.loc 2 273 4 is_stmt 0 discriminator 1
	movslq	%eax, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	movslq	%edx, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rcx
	sbbq	%rdi, %rbx
	addq	$1, %rcx
	adcq	$0, %rbx
	jmp	.L290
.L289:
	.loc 2 273 4 discriminator 2
	movl	$0, %ecx
	movl	$0, %ebx
.L290:
.LBB44:
	.loc 2 273 4 discriminator 3
	cmpl	%edx, %eax
	.loc 2 273 4 discriminator 6
	cmpl	%edx, %eax
	.loc 2 273 4 discriminator 9
	cmpl	%edx, %eax
	.loc 2 268 15 is_stmt 1
	cmpl	$1, %edx
	je	.L297
.LBB45:
	.loc 2 268 15 is_stmt 0 discriminator 1
	leaq	.LC29(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L297:
.LBE45:
	.loc 2 268 51 is_stmt 1 discriminator 2
	movl	%ecx, %edx
	.loc 2 268 15 discriminator 2
	testl	%edx, %edx
	jle	.L298
	.loc 2 268 51 discriminator 3
	movl	%ecx, %edx
	cmpl	$4096, %edx
	jle	.L299
.L298:
.LBB46:
	.loc 2 268 15 discriminator 4
	leaq	.LC29(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L299:
.LBE46:
	.loc 2 269 41
	cmpl	$2147483647, %eax
	jne	.L300
	.loc 2 269 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$269, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L300:
	.loc 2 269 41 discriminator 3
	addl	$1, %eax
	.loc 2 268 15 is_stmt 1 discriminator 5
	cmpl	-68(%rbp), %eax
	jge	.L301
.LBB47:
	.loc 2 268 15 is_stmt 0 discriminator 6
	leaq	.LC30(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L301:
.LBE47:
	.loc 2 280 7 is_stmt 1
	cmpl	$0, -68(%rbp)
	jne	.L302
	.loc 2 280 28 discriminator 1
	movl	$0, %eax
	jmp	.L303
.L302:
	.loc 2 281 15
	cmpl	$0, -68(%rbp)
	jle	.L304
	.loc 2 281 15 is_stmt 0 discriminator 1
	cmpl	$4097, -68(%rbp)
	jle	.L305
.L304:
	.loc 2 281 15 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$281, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L305:
	.loc 2 281 12 is_stmt 1 discriminator 3
	movl	-68(%rbp), %eax
	movl	%eax, -36(%rbp)
	.loc 2 282 7
	movl	-36(%rbp), %edx
	movq	-64(%rbp), %rcx
	movq	-56(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__skip_trivia@PLT
	.loc 2 282 7 is_stmt 0 discriminator 1
	movl	%eax, -36(%rbp)
.LBB48:
	.loc 2 283 7 is_stmt 1
	movzbl	-69(%rbp), %ecx
	movl	-36(%rbp), %edx
	movq	-64(%rbp), %rsi
	movq	-56(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__match_token
	.loc 2 283 7 is_stmt 0 discriminator 1
	movl	%eax, -36(%rbp)
	shrq	$32, %rax
	andb	$-1, %ah
	movb	%al, -37(%rbp)
.LBE48:
	.loc 2 284 15 is_stmt 1
	cmpb	$0, -37(%rbp)
	je	.L306
	.loc 2 284 31 discriminator 1
	movl	-36(%rbp), %eax
	jmp	.L303
.L306:
	.loc 2 284 41 discriminator 2
	movl	$0, %eax
.L303:
.LBE44:
	.loc 2 285 8
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE23:
	.size	silver_output_profile__take_token, .-silver_output_profile__take_token
	.section	.rodata
	.align 8
.LC31:
	.ascii	"failed precondition from silver_output_profile.adb:308"
	.align 8
.LC32:
	.ascii	"failed precondition from silver_output_profile.adb:309"
	.align 8
.LC33:
	.ascii	"failed precondition from silver_output_profile.adb:310"
	.align 8
.LC34:
	.ascii	"Loop_Invariant failed at silver_output_profile.adb:323"
	.align 8
.LC35:
	.ascii	"Loop_Variant failed at silver_output_profile.adb:327"
	.align 8
.LC2:
	.long	1
	.long	52
	.text
	.align 2
	.globl	silver_output_profile__lookup_name
	.type	silver_output_profile__lookup_name, @function
silver_output_profile__lookup_name:
.LFB24:
	.loc 2 315 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$152, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r9
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r9, %rdi
	movq	%rsi, -80(%rbp)
	movq	%rdi, -72(%rbp)
	movq	%rdx, -88(%rbp)
	movl	%ecx, -92(%rbp)
	movl	%r8d, -96(%rbp)
	.loc 2 315 4
	movq	-72(%rbp), %rax
	movl	(%rax), %r8d
	movq	-72(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%r8d, %r12d
	jl	.L308
	.loc 2 315 4 is_stmt 0 discriminator 1
	movslq	%r12d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r8d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L309
.L308:
	.loc 2 315 4 discriminator 2
	movl	$0, %ecx
	movl	$0, %ebx
.L309:
.LBB49:
	.loc 2 315 4 discriminator 3
	cmpl	%r8d, %r12d
	.loc 2 315 4 discriminator 6
	cmpl	%r8d, %r12d
	.loc 2 315 4 discriminator 9
	cmpl	%r8d, %r12d
	.loc 2 308 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L316
.LBB50:
	.loc 2 308 15 is_stmt 0 discriminator 1
	leaq	.LC31(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L316:
.LBE50:
	.loc 2 308 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 308 15 discriminator 2
	testl	%eax, %eax
	jle	.L317
	.loc 2 308 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L318
.L317:
.LBB51:
	.loc 2 308 15 discriminator 4
	leaq	.LC31(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L318:
.LBE51:
	.loc 2 309 19
	movq	-88(%rbp), %rax
	movq	-80(%rbp), %rsi
	movq	-72(%rbp), %rcx
	movq	%rax, %rdx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver_output_profile__valid_names
	.loc 2 309 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 308 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L319
.LBB52:
	.loc 2 308 15 is_stmt 0 discriminator 6
	leaq	.LC32(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L319:
.LBE52:
	.loc 2 310 38 is_stmt 1
	cmpl	$2147483647, %r12d
	jne	.L320
	.loc 2 310 38 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$310, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L320:
	.loc 2 310 38 discriminator 3
	leal	1(%r12), %eax
	.loc 2 308 15 is_stmt 1 discriminator 7
	cmpl	-92(%rbp), %eax
	jge	.L321
.LBB53:
	.loc 2 308 15 is_stmt 0 discriminator 8
	leaq	.LC33(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L321:
.LBE53:
	.loc 2 310 70 is_stmt 1 discriminator 4
	cmpl	$2147483647, %r12d
	jne	.L322
	.loc 2 310 70 is_stmt 0 discriminator 5
	leaq	.LC12(%rip), %rax
	movl	$310, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L322:
	.loc 2 310 70 discriminator 7
	leal	1(%r12), %eax
	.loc 2 308 15 is_stmt 1 discriminator 9
	cmpl	-96(%rbp), %eax
	jge	.L323
.LBB54:
	.loc 2 308 15 is_stmt 0 discriminator 10
	leaq	.LC33(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L323:
.LBE54:
	.loc 2 319 7 is_stmt 1
	movl	$1, -52(%rbp)
	.loc 2 321 7
	cmpl	$0, -92(%rbp)
	je	.L324
	.loc 2 321 20 discriminator 1
	movl	-96(%rbp), %eax
	cmpl	-92(%rbp), %eax
	jg	.L325
.L324:
	.loc 2 321 48 discriminator 2
	movl	$0, %eax
	jmp	.L326
.L325:
	.loc 2 322 34
	movl	$0, %ebx
.L348:
.LBB55:
	.loc 2 322 19 discriminator 1
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, -52(%rbp)
	jg	.L327
	.loc 2 323 54
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	addl	$1, %eax
	.loc 2 323 33
	cmpl	%eax, -52(%rbp)
	jle	.L328
.LBB56:
	.loc 2 323 33 is_stmt 0 discriminator 1
	leaq	.LC34(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L328:
.LBE56:
	.loc 2 327 10 is_stmt 1
	testb	%bl, %bl
	je	.L329
	.loc 2 327 44 discriminator 1
	movl	%r13d, -180(%rbp)
.L329:
	.loc 2 327 44 is_stmt 0 discriminator 2
	movl	-52(%rbp), %r13d
	.loc 2 327 10 is_stmt 1 discriminator 2
	testb	%bl, %bl
	je	.L330
	.loc 2 327 44 discriminator 3
	movl	-180(%rbp), %eax
	cmpl	%eax, %r13d
	jg	.L331
.LBB57:
	.loc 2 327 44 is_stmt 0 discriminator 4
	leaq	.LC35(%rip), %rax
	movq	%rax, -112(%rbp)
	leaq	.LC2(%rip), %rax
	movq	%rax, -104(%rbp)
	movq	-112(%rbp), %rbx
	movq	-104(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L330:
.LBE57:
	.loc 2 327 10 is_stmt 1 discriminator 5
	movl	$1, %ebx
.L331:
	.loc 2 328 36
	cmpl	$0, -52(%rbp)
	jle	.L332
	.loc 2 328 36 is_stmt 0 discriminator 1
	cmpl	$341, -52(%rbp)
	jle	.L333
.L332:
	.loc 2 328 36 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$328, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L333:
	.loc 2 328 63 is_stmt 1 discriminator 3
	cmpl	$0, -52(%rbp)
	jle	.L334
	.loc 2 328 63 is_stmt 0 discriminator 4
	cmpl	$341, -52(%rbp)
	jle	.L335
.L334:
	.loc 2 328 63 discriminator 5
	leaq	.LC12(%rip), %rax
	movl	$328, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L335:
	.loc 2 328 50 is_stmt 1 discriminator 6
	movl	-52(%rbp), %eax
	cltq
	movq	-88(%rbp), %rcx
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$2, %rax
	addq	%rcx, %rax
	addq	$4, %rax
	movl	(%rax), %edx
	testl	%edx, %edx
	jle	.L336
	.loc 2 328 50 is_stmt 0 discriminator 7
	cmpl	$4097, %edx
	jle	.L337
.L336:
	.loc 2 328 50 discriminator 8
	leaq	.LC12(%rip), %rax
	movl	$328, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L337:
	.loc 2 328 77 is_stmt 1 discriminator 9
	movl	-52(%rbp), %eax
	cltq
	movq	-88(%rbp), %rsi
	leaq	-1(%rax), %rcx
	movq	%rcx, %rax
	salq	$2, %rax
	addq	%rcx, %rax
	salq	$2, %rax
	addq	%rsi, %rax
	addq	$8, %rax
	movl	(%rax), %eax
	testl	%eax, %eax
	jle	.L338
	.loc 2 328 77 is_stmt 0 discriminator 10
	cmpl	$4097, %eax
	jle	.L339
.L338:
	.loc 2 328 77 discriminator 11
	leaq	.LC12(%rip), %rax
	movl	$328, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L339:
	.loc 2 328 85 is_stmt 1 discriminator 12
	cmpl	$0, -92(%rbp)
	jle	.L340
	.loc 2 328 85 is_stmt 0 discriminator 13
	cmpl	$4097, -92(%rbp)
	jle	.L341
.L340:
	.loc 2 328 85 discriminator 14
	leaq	.LC12(%rip), %rax
	movl	$328, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L341:
	.loc 2 328 92 is_stmt 1 discriminator 15
	cmpl	$0, -96(%rbp)
	jle	.L342
	.loc 2 328 92 is_stmt 0 discriminator 16
	cmpl	$4097, -96(%rbp)
	jle	.L343
.L342:
	.loc 2 328 92 discriminator 17
	leaq	.LC12(%rip), %rax
	movl	$328, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L343:
	.loc 2 328 13 is_stmt 1 discriminator 18
	movl	-96(%rbp), %r8d
	movl	-92(%rbp), %ecx
	movq	-80(%rbp), %rdi
	movq	-72(%rbp), %rsi
	movl	%r8d, %r9d
	movl	%ecx, %r8d
	movl	%eax, %ecx
	call	silver_output_lexical__equal_name@PLT
	.loc 2 328 10 discriminator 19
	testb	%al, %al
	je	.L344
	.loc 2 329 22
	cmpl	$0, -52(%rbp)
	js	.L345
	.loc 2 329 22 is_stmt 0 discriminator 1
	cmpl	$341, -52(%rbp)
	jle	.L346
.L345:
	.loc 2 329 22 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$329, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L346:
	.loc 2 329 15 is_stmt 1 discriminator 3
	movl	-52(%rbp), %eax
	jmp	.L326
.L344:
	.loc 2 330 25
	cmpl	$2147483647, -52(%rbp)
	jne	.L347
	.loc 2 330 16 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$330, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L347:
	.loc 2 330 16 is_stmt 0 discriminator 3
	addl	$1, -52(%rbp)
.LBE55:
	.loc 2 331 15 is_stmt 1
	jmp	.L348
.L327:
	.loc 2 332 7
	movl	$0, %eax
.L326:
.LBE49:
	.loc 2 333 8
	addq	$152, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE24:
	.size	silver_output_profile__lookup_name, .-silver_output_profile__lookup_name
	.align 2
	.type	silver_output_profile__call_after___wrapped_statements.5, @function
silver_output_profile__call_after___wrapped_statements.5:
.LFB26:
	.loc 2 345 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 3, -24
	movq	%r10, %rbx
	movq	%r10, -40(%rbp)
	.loc 2 349 52
	movq	16(%rbx), %rax
	movl	24(%rbx), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__skip_at
	.loc 2 349 52 is_stmt 0 discriminator 1
	movl	%eax, -20(%rbp)
	.loc 2 350 52 is_stmt 1
	movq	16(%rbx), %rax
	movl	-20(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__name_after
	.loc 2 350 52 is_stmt 0 discriminator 1
	movl	%eax, -24(%rbp)
	.loc 2 352 37 is_stmt 1
	movq	16(%rbx), %rax
	movq	8(%rbx), %rdx
	movl	-24(%rbp), %edi
	movl	-20(%rbp), %ecx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__lookup_name
	.loc 2 352 83 discriminator 1
	testl	%eax, %eax
	setne	%al
	.loc 2 351 18
	testb	%al, %al
	jne	.L350
	.loc 2 353 37
	movq	16(%rbx), %rax
	movq	(%rbx), %rdx
	movl	-24(%rbp), %edi
	movl	-20(%rbp), %ecx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__lookup@PLT
	.loc 2 353 80 discriminator 1
	testl	%eax, %eax
	setne	%al
	.loc 2 351 18 discriminator 1
	testb	%al, %al
	je	.L351
.L350:
	.loc 2 351 18 is_stmt 0 discriminator 2
	movl	$1, %esi
	jmp	.L352
.L351:
	.loc 2 351 18 discriminator 3
	movl	$0, %esi
.L352:
	.loc 2 351 18 discriminator 4
	movq	16(%rbx), %rax
	movl	24(%rbx), %edx
	movzbl	28(%rbx), %ecx
	movzbl	%sil, %edi
	movzbl	%cl, %ecx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_names__operation_after@PLT
	.loc 2 345 4 is_stmt 1
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE26:
	.size	silver_output_profile__call_after___wrapped_statements.5, .-silver_output_profile__call_after___wrapped_statements.5
	.section	.rodata
	.align 8
.LC36:
	.ascii	"failed precondition from silver_output_profile.adb:340"
	.align 8
.LC37:
	.ascii	"failed precondition from silver_output_profile.adb:341"
	.align 8
.LC38:
	.ascii	"failed precondition from silver_output_profile.adb:342"
	.align 8
.LC39:
	.ascii	"failed postcondition from silver_output_profile.adb:343"
	.text
	.align 2
	.globl	silver_output_profile__call_after
	.type	silver_output_profile__call_after, @function
silver_output_profile__call_after:
.LFB25:
	.loc 2 345 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$176, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r10
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r10, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movq	%rdx, -104(%rbp)
	movl	%ecx, -108(%rbp)
	movb	%r8b, -109(%rbp)
	movq	%r9, -120(%rbp)
	.loc 2 345 4
	leaq	16(%rbp), %rdx
	.loc 2 345 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -48(%rbp)
	movq	%rax, -64(%rbp)
	movq	-104(%rbp), %rax
	movq	%rax, -72(%rbp)
	movl	-108(%rbp), %eax
	movl	%eax, -56(%rbp)
	movzbl	-109(%rbp), %eax
	movb	%al, -52(%rbp)
	movq	-120(%rbp), %rax
	movq	%rax, -80(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %r8d
	movq	-88(%rbp), %rax
	movl	4(%rax), %r12d
	movq	-88(%rbp), %rax
	movl	4(%rax), %edx
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L355
	.loc 2 345 4 discriminator 2
	movq	-88(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L356
.L355:
	.loc 2 345 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L356:
.LBB58:
	.loc 2 340 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L357
.LBB59:
	.loc 2 340 15 is_stmt 0 discriminator 1
	leaq	.LC36(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L357:
.LBE59:
	.loc 2 340 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 340 15 discriminator 2
	testl	%eax, %eax
	jle	.L358
	.loc 2 340 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L359
.L358:
.LBB60:
	.loc 2 340 15 discriminator 4
	leaq	.LC36(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L359:
.LBE60:
	.loc 2 341 19
	movq	-72(%rbp), %rdx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_names
	.loc 2 341 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 340 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L360
.LBB61:
	.loc 2 340 15 is_stmt 0 discriminator 6
	leaq	.LC37(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L360:
.LBE61:
	.loc 2 342 37 is_stmt 1
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__valid_environment@PLT
	.loc 2 342 37 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 340 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L361
.LBB62:
	.loc 2 340 15 is_stmt 0 discriminator 8
	leaq	.LC38(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L361:
.LBE62:
	.loc 2 342 108 is_stmt 1 discriminator 2
	cmpl	$2147483647, %r12d
	jne	.L362
	.loc 2 342 108 is_stmt 0 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$342, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L362:
	.loc 2 342 108 discriminator 5
	leal	1(%r12), %edx
	.loc 2 340 15 is_stmt 1 discriminator 9
	movl	-56(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L363
.LBB63:
	.loc 2 340 15 is_stmt 0 discriminator 10
	leaq	.LC38(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rcx
	movq	-136(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L363:
.LBE63:
.LBB64:
	.loc 2 345 4 is_stmt 1 discriminator 5
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__call_after___wrapped_statements.5
	.loc 2 343 16
	testl	%eax, %eax
	je	.L367
	.loc 2 344 10
	movl	-56(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L365
	.loc 2 344 65 discriminator 1
	cmpl	$2147483647, %r12d
	jne	.L366
	.loc 2 344 65 is_stmt 0 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$344, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L366:
	.loc 2 344 65 discriminator 4
	leal	1(%r12), %edx
	.loc 2 344 36 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L367
.L365:
.LBB65:
	.loc 2 343 16 discriminator 1
	leaq	.LC39(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L367:
.LBE65:
.LBE64:
.LBE58:
	.loc 2 345 4
	addq	$176, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE25:
	.size	silver_output_profile__call_after, .-silver_output_profile__call_after
	.align 2
	.globl	silver_output_profile__value_resultIP
	.type	silver_output_profile__value_resultIP, @function
silver_output_profile__value_resultIP:
.LFB27:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE27:
	.size	silver_output_profile__value_resultIP, .-silver_output_profile__value_resultIP
	.section	.rodata
	.align 8
.LC40:
	.ascii	"failed precondition from silver_output_profile.adb:366"
	.align 8
.LC41:
	.ascii	"failed precondition from silver_output_profile.adb:367"
	.text
	.align 2
	.globl	silver_output_profile__literal_at
	.type	silver_output_profile__literal_at, @function
silver_output_profile__literal_at:
.LFB28:
	.loc 2 382 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, -56(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -80(%rbp)
	movq	%rdx, -72(%rbp)
	movl	%ecx, -60(%rbp)
	.loc 2 382 4
	movq	-72(%rbp), %rax
	movl	(%rax), %edx
	movq	-72(%rbp), %rax
	movl	4(%rax), %eax
	cmpl	%edx, %eax
	jl	.L371
	.loc 2 382 4 is_stmt 0 discriminator 1
	movslq	%eax, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	movslq	%edx, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rcx
	sbbq	%rdi, %rbx
	addq	$1, %rcx
	adcq	$0, %rbx
	jmp	.L372
.L371:
	.loc 2 382 4 discriminator 2
	movl	$0, %ecx
	movl	$0, %ebx
.L372:
.LBB66:
	.loc 2 382 4 discriminator 3
	cmpl	%edx, %eax
	.loc 2 382 4 discriminator 6
	cmpl	%edx, %eax
	.loc 2 382 4 discriminator 9
	cmpl	%edx, %eax
	.loc 2 366 15 is_stmt 1
	cmpl	$1, %edx
	je	.L379
.LBB67:
	.loc 2 366 15 is_stmt 0 discriminator 1
	leaq	.LC40(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L379:
.LBE67:
	.loc 2 366 51 is_stmt 1 discriminator 2
	movl	%ecx, %edx
	.loc 2 366 15 discriminator 2
	testl	%edx, %edx
	jle	.L380
	.loc 2 366 51 discriminator 3
	movl	%ecx, %edx
	cmpl	$4096, %edx
	jle	.L381
.L380:
.LBB68:
	.loc 2 366 15 discriminator 4
	leaq	.LC40(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L381:
.LBE68:
	.loc 2 367 41
	cmpl	$2147483647, %eax
	jne	.L382
	.loc 2 367 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$367, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L382:
	.loc 2 367 41 discriminator 3
	addl	$1, %eax
	.loc 2 366 15 is_stmt 1 discriminator 5
	cmpl	-60(%rbp), %eax
	jge	.L383
.LBB69:
	.loc 2 366 15 is_stmt 0 discriminator 6
	leaq	.LC41(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L383:
.LBE69:
	.loc 2 387 7 is_stmt 1
	cmpl	$0, -60(%rbp)
	jne	.L384
	.loc 2 387 28 discriminator 1
	movq	-56(%rbp), %rax
	movl	$0, (%rax)
	movq	-56(%rbp), %rax
	movl	$0, 4(%rax)
	movq	-56(%rbp), %rax
	movl	$0, 8(%rax)
	movq	-56(%rbp), %rax
	movl	$0, 12(%rax)
	movq	-56(%rbp), %rax
	movb	$0, 16(%rax)
	movq	-56(%rbp), %rax
	movb	$0, 17(%rax)
	movq	-56(%rbp), %rax
	movb	$0, 18(%rax)
	movq	-56(%rbp), %rax
	movl	$0, 20(%rax)
	jmp	.L385
.L384:
	.loc 2 388 15
	cmpl	$0, -60(%rbp)
	jle	.L386
	.loc 2 388 15 is_stmt 0 discriminator 1
	cmpl	$4097, -60(%rbp)
	jle	.L387
.L386:
	.loc 2 388 15 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$388, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L387:
	.loc 2 388 12 is_stmt 1 discriminator 3
	movl	-60(%rbp), %eax
	movl	%eax, -36(%rbp)
.LBB70:
	.loc 2 389 7
	movl	-36(%rbp), %edx
	movq	-80(%rbp), %rcx
	movq	-72(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__match_sized_literal@PLT
	.loc 2 389 7 is_stmt 0 discriminator 1
	movl	%eax, -36(%rbp)
	movq	%rax, %rcx
	shrq	$32, %rcx
	andb	$-1, %ch
	movb	%cl, -37(%rbp)
	movl	%edx, -44(%rbp)
.LBE70:
	.loc 2 390 10 is_stmt 1
	movzbl	-37(%rbp), %eax
	xorl	$1, %eax
	.loc 2 390 7
	testb	%al, %al
	je	.L388
	.loc 2 390 27 discriminator 1
	movq	-56(%rbp), %rax
	movl	$0, (%rax)
	movq	-56(%rbp), %rax
	movl	$0, 4(%rax)
	movq	-56(%rbp), %rax
	movl	$0, 8(%rax)
	movq	-56(%rbp), %rax
	movl	$0, 12(%rax)
	movq	-56(%rbp), %rax
	movb	$0, 16(%rax)
	movq	-56(%rbp), %rax
	movb	$0, 17(%rax)
	movq	-56(%rbp), %rax
	movb	$0, 18(%rax)
	movq	-56(%rbp), %rax
	movl	$0, 20(%rax)
	jmp	.L385
.L388:
	.loc 2 391 54
	movl	-60(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L389
	.loc 2 391 54 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L390
.L389:
	.loc 2 391 54 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$391, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L390:
	.loc 2 391 7 is_stmt 1 discriminator 3
	movq	-56(%rbp), %rdx
	movl	-36(%rbp), %ecx
	movl	%ecx, (%rdx)
	movq	-56(%rbp), %rdx
	movl	%eax, 4(%rdx)
	movq	-56(%rbp), %rax
	movl	-44(%rbp), %edx
	movl	%edx, 8(%rax)
	movq	-56(%rbp), %rax
	movl	-44(%rbp), %edx
	movl	%edx, 12(%rax)
	movq	-56(%rbp), %rax
	movb	$0, 16(%rax)
	movq	-56(%rbp), %rax
	movb	$0, 17(%rax)
	movq	-56(%rbp), %rax
	movb	$0, 18(%rax)
	movq	-56(%rbp), %rax
	movl	$0, 20(%rax)
.L385:
.LBE66:
	.loc 2 394 8
	movq	-56(%rbp), %rax
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE28:
	.size	silver_output_profile__literal_at, .-silver_output_profile__literal_at
	.section	.rodata
	.align 8
.LC42:
	.ascii	"failed precondition from silver_output_profile.adb:434"
	.align 8
.LC43:
	.ascii	"Loop_Invariant failed at silver_output_profile.adb:441"
	.align 8
.LC44:
	.ascii	"Loop_Variant failed at silver_output_profile.adb:444"
.LC45:
	.ascii	"mod"
.LC46:
	.ascii	"rem"
	.align 8
.LC3:
	.long	1
	.long	3
	.text
	.align 2
	.globl	silver_output_profile__within_work_budget
	.type	silver_output_profile__within_work_budget, @function
silver_output_profile__within_work_budget:
.LFB29:
	.loc 2 436 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$168, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -128(%rbp)
	movq	%rdx, -120(%rbp)
	.loc 2 436 4
	movq	-120(%rbp), %rax
	movl	(%rax), %r13d
	movq	-120(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%r13d, %r12d
	jl	.L392
	.loc 2 436 4 is_stmt 0 discriminator 1
	movslq	%r12d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r13d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L393
.L392:
	.loc 2 436 4 discriminator 2
	movl	$0, %ecx
	movl	$0, %ebx
.L393:
.LBB71:
	.loc 2 436 4 discriminator 3
	movslq	%r13d, %r14
	cmpl	%r13d, %r12d
	.loc 2 436 4 discriminator 6
	cmpl	%r13d, %r12d
	.loc 2 436 4 discriminator 9
	cmpl	%r13d, %r12d
	.loc 2 434 15 is_stmt 1
	cmpl	$1, %r13d
	je	.L400
.LBB72:
	.loc 2 434 15 is_stmt 0 discriminator 1
	leaq	.LC42(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L400:
.LBE72:
	.loc 2 434 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 434 15 discriminator 2
	testl	%eax, %eax
	jle	.L401
	.loc 2 434 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L402
.L401:
.LBB73:
	.loc 2 434 15 discriminator 4
	leaq	.LC42(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L402:
.LBE73:
	.loc 2 437 7
	movl	$1, -52(%rbp)
	.loc 2 438 7
	movl	$63, -56(%rbp)
	.loc 2 440 7
	movl	$0, %ebx
.L455:
	.loc 2 441 55
	cmpl	$2147483647, %r12d
	jne	.L403
	.loc 2 441 55 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$441, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L403:
	.loc 2 441 55 discriminator 3
	leal	1(%r12), %eax
	.loc 2 441 33 is_stmt 1 discriminator 4
	cmpl	-52(%rbp), %eax
	jge	.L404
.LBB74:
	.loc 2 441 33 is_stmt 0 discriminator 5
	leaq	.LC43(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L404:
.LBE74:
	.loc 2 444 10 is_stmt 1
	testb	%bl, %bl
	je	.L405
	.loc 2 444 44 discriminator 1
	movl	%r15d, -196(%rbp)
.L405:
	.loc 2 444 44 is_stmt 0 discriminator 2
	movl	-52(%rbp), %r15d
	.loc 2 444 10 is_stmt 1 discriminator 2
	testb	%bl, %bl
	je	.L406
	.loc 2 444 44 discriminator 3
	movl	-196(%rbp), %eax
	cmpl	%eax, %r15d
	jg	.L407
.LBB75:
	.loc 2 444 44 is_stmt 0 discriminator 4
	leaq	.LC44(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC2(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L406:
.LBE75:
	.loc 2 444 10 is_stmt 1 discriminator 5
	movl	$1, %ebx
.L407:
.LBB76:
	.loc 2 446 50
	movl	-52(%rbp), %edx
	movq	-128(%rbp), %rcx
	movq	-120(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__skip_at
	.loc 2 446 50 is_stmt 0 discriminator 1
	movl	%eax, -60(%rbp)
	.loc 2 447 47 is_stmt 1
	leaq	-96(%rbp), %rdi
	movl	-60(%rbp), %ecx
	movq	-128(%rbp), %rdx
	movq	-120(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__literal_at
	.loc 2 448 55
	movl	-60(%rbp), %edx
	movq	-128(%rbp), %rcx
	movq	-120(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__name_after
	.loc 2 448 55 is_stmt 0 discriminator 1
	movl	%eax, -64(%rbp)
	.loc 2 450 37 is_stmt 1
	movl	-60(%rbp), %edx
	movq	-128(%rbp), %rcx
	movq	-120(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_literals__read_integer@PLT
	movl	%eax, %ecx
	movq	%rdx, %rax
	movl	%ecx, -112(%rbp)
	movq	%rax, -104(%rbp)
	.loc 2 452 13
	cmpl	$0, -60(%rbp)
	jne	.L408
	.loc 2 452 31 discriminator 1
	movl	$0, %eax
	jmp	.L456
.L408:
	.loc 2 453 13
	cmpl	-60(%rbp), %r12d
	jge	.L410
	.loc 2 453 39 discriminator 1
	movl	$1, %eax
	jmp	.L456
.L410:
	.loc 2 454 16
	cmpl	-60(%rbp), %r13d
	jg	.L411
	.loc 2 454 16 is_stmt 0 discriminator 1
	cmpl	-60(%rbp), %r12d
	jge	.L412
.L411:
	.loc 2 454 16 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$454, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L412:
	.loc 2 454 29 is_stmt 1 discriminator 3
	movq	-128(%rbp), %rdx
	movl	-60(%rbp), %eax
	cltq
	subq	%r14, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 454 13 discriminator 4
	cmpb	$34, %al
	jne	.L413
	.loc 2 455 32
	movl	-96(%rbp), %eax
	.loc 2 455 16
	testl	%eax, %eax
	jne	.L414
	.loc 2 455 41 discriminator 1
	movl	$0, %eax
	jmp	.L456
.L414:
	.loc 2 456 34
	movl	-96(%rbp), %eax
	testl	%eax, %eax
	jle	.L415
	.loc 2 456 34 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L416
.L415:
	.loc 2 456 34 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$456, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L416:
	.loc 2 456 25 is_stmt 1 discriminator 3
	movl	%eax, -52(%rbp)
	jmp	.L455
.L413:
	.loc 2 457 13
	cmpl	$0, -64(%rbp)
	je	.L418
	.loc 2 458 34
	cmpl	$0, -60(%rbp)
	jle	.L419
	.loc 2 458 34 is_stmt 0 discriminator 1
	cmpl	$4097, -60(%rbp)
	jle	.L420
.L419:
	.loc 2 458 34 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$458, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L420:
	.loc 2 458 41 is_stmt 1 discriminator 3
	cmpl	$0, -64(%rbp)
	jle	.L421
	.loc 2 458 41 is_stmt 0 discriminator 4
	cmpl	$4097, -64(%rbp)
	jle	.L422
.L421:
	.loc 2 458 41 discriminator 5
	leaq	.LC12(%rip), %rax
	movl	$458, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L422:
	.loc 2 458 19 is_stmt 1 discriminator 6
	leaq	.LC45(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC3(%rip), %rax
	movq	%rax, -152(%rbp)
	movl	-64(%rbp), %ecx
	movl	-60(%rbp), %edx
	movq	-128(%rbp), %rsi
	movq	-120(%rbp), %rax
	movq	-160(%rbp), %r8
	movq	-152(%rbp), %r9
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__name_is@PLT
	.loc 2 458 16 discriminator 7
	testb	%al, %al
	jne	.L423
	.loc 2 458 83 discriminator 8
	cmpl	$0, -60(%rbp)
	jle	.L424
	.loc 2 458 83 is_stmt 0 discriminator 9
	cmpl	$4097, -60(%rbp)
	jle	.L425
.L424:
	.loc 2 458 83 discriminator 10
	leaq	.LC12(%rip), %rax
	movl	$458, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L425:
	.loc 2 458 90 is_stmt 1 discriminator 11
	cmpl	$0, -64(%rbp)
	jle	.L426
	.loc 2 458 90 is_stmt 0 discriminator 12
	cmpl	$4097, -64(%rbp)
	jle	.L427
.L426:
	.loc 2 458 90 discriminator 13
	leaq	.LC12(%rip), %rax
	movl	$458, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L427:
	.loc 2 458 68 is_stmt 1 discriminator 14
	leaq	.LC46(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC3(%rip), %rax
	movq	%rax, -136(%rbp)
	movl	-64(%rbp), %ecx
	movl	-60(%rbp), %edx
	movq	-128(%rbp), %rsi
	movq	-120(%rbp), %rax
	movq	-144(%rbp), %r8
	movq	-136(%rbp), %r9
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__name_is@PLT
	.loc 2 458 60 discriminator 15
	testb	%al, %al
	je	.L428
.L423:
	.loc 2 459 19
	cmpl	$0, -56(%rbp)
	jne	.L429
	.loc 2 459 41 discriminator 1
	movl	$0, %eax
	jmp	.L456
.L429:
	.loc 2 460 42
	movl	-56(%rbp), %eax
	subl	$1, %eax
	testl	%eax, %eax
	js	.L430
	.loc 2 460 42 is_stmt 0 discriminator 1
	cmpl	$63, %eax
	jle	.L431
.L430:
	.loc 2 460 42 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$460, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L431:
	.loc 2 460 29 is_stmt 1 discriminator 3
	movl	%eax, -56(%rbp)
.L428:
	.loc 2 462 28
	cmpl	$0, -64(%rbp)
	jle	.L432
	.loc 2 462 28 is_stmt 0 discriminator 1
	cmpl	$4097, -64(%rbp)
	jle	.L433
.L432:
	.loc 2 462 28 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$462, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L433:
	.loc 2 462 25 is_stmt 1 discriminator 3
	movl	-64(%rbp), %eax
	movl	%eax, -52(%rbp)
	jmp	.L455
.L418:
	.loc 2 463 32
	movl	-112(%rbp), %eax
	.loc 2 463 13
	testl	%eax, %eax
	je	.L434
	.loc 2 464 34
	movl	-112(%rbp), %eax
	testl	%eax, %eax
	jle	.L435
	.loc 2 464 34 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L436
.L435:
	.loc 2 464 34 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$464, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L436:
	.loc 2 464 25 is_stmt 1 discriminator 3
	movl	%eax, -52(%rbp)
	jmp	.L455
.L434:
	.loc 2 465 19
	cmpl	-60(%rbp), %r13d
	jg	.L437
	.loc 2 465 19 is_stmt 0 discriminator 1
	cmpl	-60(%rbp), %r12d
	jge	.L438
.L437:
	.loc 2 465 19 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$465, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L438:
	.loc 2 465 32 is_stmt 1 discriminator 3
	movq	-128(%rbp), %rdx
	movl	-60(%rbp), %eax
	cltq
	subq	%r14, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 465 32 is_stmt 0 discriminator 4
	cmpb	$47, %al
	sete	%al
	.loc 2 465 13 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L439
	.loc 2 465 38 discriminator 5
	cmpl	-60(%rbp), %r12d
	jle	.L439
	.loc 2 465 86 discriminator 6
	movl	-60(%rbp), %eax
	addl	$1, %eax
	.loc 2 465 74 discriminator 6
	cmpl	%eax, %r13d
	jg	.L440
	.loc 2 465 74 is_stmt 0 discriminator 7
	cmpl	-60(%rbp), %r12d
	jg	.L441
.L440:
	.loc 2 465 74 discriminator 8
	leaq	.LC12(%rip), %rax
	movl	$465, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L441:
	.loc 2 465 91 is_stmt 1 discriminator 9
	movq	-128(%rbp), %rdx
	.loc 2 465 86 discriminator 9
	movl	-60(%rbp), %eax
	addl	$1, %eax
	cltq
	.loc 2 465 91 discriminator 9
	subq	%r14, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 465 91 is_stmt 0 discriminator 10
	cmpb	$61, %al
	sete	%al
	.loc 2 465 65 is_stmt 1 discriminator 10
	testb	%al, %al
	je	.L439
	.loc 2 466 34
	movl	-60(%rbp), %eax
	addl	$2, %eax
	testl	%eax, %eax
	jle	.L442
	.loc 2 466 34 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L443
.L442:
	.loc 2 466 34 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$466, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L443:
	.loc 2 466 25 is_stmt 1 discriminator 3
	movl	%eax, -52(%rbp)
	jmp	.L417
.L439:
	.loc 2 467 19
	cmpl	-60(%rbp), %r13d
	jg	.L444
	.loc 2 467 19 is_stmt 0 discriminator 1
	cmpl	-60(%rbp), %r12d
	jge	.L445
.L444:
	.loc 2 467 19 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$467, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L445:
	.loc 2 467 35 is_stmt 1 discriminator 3
	movq	-128(%rbp), %rdx
	movl	-60(%rbp), %eax
	cltq
	subq	%r14, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 467 13 discriminator 4
	cmpb	$38, %al
	je	.L446
	.loc 2 467 41 discriminator 5
	movq	-128(%rbp), %rdx
	movl	-60(%rbp), %eax
	cltq
	subq	%r14, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 467 41 is_stmt 0 discriminator 6
	cmpb	$43, %al
	je	.L446
	.loc 2 467 47 is_stmt 1 discriminator 7
	movq	-128(%rbp), %rdx
	movl	-60(%rbp), %eax
	cltq
	subq	%r14, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 467 47 is_stmt 0 discriminator 8
	cmpb	$45, %al
	je	.L446
	.loc 2 467 53 is_stmt 1 discriminator 9
	movq	-128(%rbp), %rdx
	movl	-60(%rbp), %eax
	cltq
	subq	%r14, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 467 53 is_stmt 0 discriminator 10
	cmpb	$42, %al
	je	.L446
	.loc 2 467 59 is_stmt 1 discriminator 11
	movq	-128(%rbp), %rdx
	movl	-60(%rbp), %eax
	cltq
	subq	%r14, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 467 59 is_stmt 0 discriminator 12
	cmpb	$47, %al
	jne	.L447
.L446:
	.loc 2 468 16 is_stmt 1
	cmpl	$0, -56(%rbp)
	jne	.L448
	.loc 2 468 38 discriminator 1
	movl	$0, %eax
	jmp	.L456
.L448:
	.loc 2 469 34
	movl	-60(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L449
	.loc 2 469 34 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L450
.L449:
	.loc 2 469 34 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$469, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L450:
	.loc 2 469 25 is_stmt 1 discriminator 3
	movl	%eax, -52(%rbp)
	.loc 2 470 39
	movl	-56(%rbp), %eax
	subl	$1, %eax
	testl	%eax, %eax
	js	.L451
	.loc 2 470 39 is_stmt 0 discriminator 1
	cmpl	$63, %eax
	jle	.L452
.L451:
	.loc 2 470 39 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$470, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L452:
	.loc 2 470 26 is_stmt 1 discriminator 3
	movl	%eax, -56(%rbp)
	jmp	.L417
.L447:
	.loc 2 472 34
	movl	-60(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L453
	.loc 2 472 34 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L454
.L453:
	.loc 2 472 34 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$472, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L454:
	.loc 2 472 25 is_stmt 1 discriminator 3
	movl	%eax, -52(%rbp)
.L417:
.LBE76:
	.loc 2 475 15
	jmp	.L455
.L456:
.LBE71:
	.loc 2 476 8
	addq	$168, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE29:
	.size	silver_output_profile__within_work_budget, .-silver_output_profile__within_work_budget
	.section	.rodata
.LC47:
	.ascii	"image"
	.align 8
.LC4:
	.long	1
	.long	5
	.text
	.align 2
	.type	silver_output_profile__image_at___wrapped_statements.6, @function
silver_output_profile__image_at___wrapped_statements.6:
.LFB31:
	.loc 2 490 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$136, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, -152(%rbp)
	movq	%r10, %rbx
	movq	%r10, -160(%rbp)
	.loc 2 494 52
	movq	16(%rbx), %rax
	movl	24(%rbx), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__skip_at
	.loc 2 494 52 is_stmt 0 discriminator 1
	movl	%eax, -36(%rbp)
	.loc 2 495 57 is_stmt 1
	movq	16(%rbx), %rax
	movl	-36(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$52, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 495 57 is_stmt 0 discriminator 1
	movl	%eax, -40(%rbp)
	.loc 2 497 17 is_stmt 1
	movq	16(%rbx), %rax
	movl	-40(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$36, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	movl	%eax, %edx
	.loc 2 497 17 is_stmt 0 discriminator 1
	movq	16(%rbx), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__skip_at
	.loc 2 497 17 discriminator 2
	movl	%eax, -44(%rbp)
	.loc 2 498 62 is_stmt 1
	movq	16(%rbx), %rax
	movl	-44(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__name_after
	.loc 2 498 62 is_stmt 0 discriminator 1
	movl	%eax, -48(%rbp)
	.loc 2 500 35 is_stmt 1
	movq	16(%rbx), %rax
	movl	-48(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$11, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	movl	%eax, %ecx
	.loc 2 500 35 is_stmt 0 discriminator 1
	movq	16(%rbx), %rax
	movq	8(%rbx), %rsi
	leaq	-144(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	pushq	$1
	pushq	$0
	movl	$0, %r9d
	movq	%rsi, %r8
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_scalar_expressions__read_expression@PLT
	addq	$16, %rsp
	.loc 2 502 56 is_stmt 1
	movl	-144(%rbp), %edx
	movq	16(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$12, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 502 56 is_stmt 0 discriminator 1
	movl	%eax, -52(%rbp)
	.loc 2 504 28 is_stmt 1
	movzbl	28(%rbx), %eax
	xorl	$1, %eax
	.loc 2 504 10
	testb	%al, %al
	je	.L458
	.loc 2 504 28 discriminator 1
	cmpl	$0, -40(%rbp)
	je	.L458
	.loc 2 505 20
	movq	16(%rbx), %rax
	movq	(%rbx), %rdx
	movl	-40(%rbp), %edi
	movl	-36(%rbp), %ecx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__lookup_name
	.loc 2 505 65 discriminator 1
	testl	%eax, %eax
	setne	%al
	xorl	$1, %eax
	.loc 2 505 12 discriminator 1
	testb	%al, %al
	je	.L458
	.loc 2 506 38
	movq	16(%rbx), %rax
	movq	8(%rbx), %rdx
	movl	-40(%rbp), %edi
	movl	-36(%rbp), %ecx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__lookup@PLT
	.loc 2 506 86 discriminator 1
	testl	%eax, %eax
	setne	%al
	xorl	$1, %eax
	.loc 2 506 12 discriminator 1
	testb	%al, %al
	je	.L458
	.loc 2 507 12
	cmpl	$0, -44(%rbp)
	je	.L458
	.loc 2 507 40 discriminator 1
	movl	-48(%rbp), %eax
	cmpl	-44(%rbp), %eax
	jle	.L458
	.loc 2 508 39
	cmpl	$0, -44(%rbp)
	jle	.L459
	.loc 2 508 39 is_stmt 0 discriminator 1
	cmpl	$4097, -44(%rbp)
	jle	.L460
.L459:
	.loc 2 508 39 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$508, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L460:
	.loc 2 508 56 is_stmt 1 discriminator 3
	cmpl	$0, -48(%rbp)
	jle	.L461
	.loc 2 508 56 is_stmt 0 discriminator 4
	cmpl	$4097, -48(%rbp)
	jle	.L462
.L461:
	.loc 2 508 56 discriminator 5
	leaq	.LC12(%rip), %rax
	movl	$508, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L462:
	.loc 2 508 24 is_stmt 1 discriminator 6
	leaq	.LC47(%rip), %r12
	leaq	.LC4(%rip), %r13
	movq	16(%rbx), %rax
	movl	-48(%rbp), %ecx
	movl	-44(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%r12, %r8
	movq	%r13, %r9
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__name_is@PLT
	.loc 2 508 20 discriminator 7
	xorl	$1, %eax
	xorl	$1, %eax
	.loc 2 508 12 discriminator 7
	testb	%al, %al
	je	.L458
	.loc 2 509 12
	movl	24(%rbx), %eax
	cmpl	%eax, -52(%rbp)
	jle	.L458
	.loc 2 511 15
	movl	-52(%rbp), %eax
	movl	%eax, -80(%rbp)
	movl	$0, -76(%rbp)
	.loc 2 512 43
	movq	-140(%rbp), %rax
	movq	%rax, %rdi
	call	silver_integer_image__minimum_length@PLT
	.loc 2 511 15 discriminator 1
	movl	%eax, -72(%rbp)
	.loc 2 513 42
	movq	-140(%rbp), %rax
	movq	%rax, %rdi
	call	silver_integer_image__maximum_length@PLT
	.loc 2 511 15 discriminator 2
	movl	%eax, -68(%rbp)
	movb	$0, -64(%rbp)
	movb	$1, -63(%rbp)
	.loc 2 515 34
	movq	-140(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty@PLT
	.loc 2 511 15 discriminator 3
	movb	%al, -62(%rbp)
	movl	$0, -60(%rbp)
	leaq	-80(%rbp), %rcx
	.loc 2 504 10 discriminator 2
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -112(%rbp)
	movq	%rdx, -104(%rbp)
	movq	16(%rcx), %rax
	movq	%rax, -96(%rbp)
	.loc 2 504 10 is_stmt 0 discriminator 3
	jmp	.L463
.L458:
	.loc 2 504 10 discriminator 4
	movl	$0, -112(%rbp)
	movl	$0, -108(%rbp)
	movl	$0, -104(%rbp)
	movl	$0, -100(%rbp)
	movb	$0, -96(%rbp)
	movb	$0, -95(%rbp)
	movb	$0, -94(%rbp)
	movl	$0, -92(%rbp)
.L463:
	.loc 2 504 10 discriminator 5
	leaq	-112(%rbp), %rsi
	.loc 2 494 7 is_stmt 1 discriminator 2
	movq	-152(%rbp), %rcx
	movq	(%rsi), %rax
	movq	8(%rsi), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movq	16(%rsi), %rax
	movq	%rax, 16(%rcx)
	.loc 2 490 4
	movq	-152(%rbp), %rax
	leaq	-24(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE31:
	.size	silver_output_profile__image_at___wrapped_statements.6, .-silver_output_profile__image_at___wrapped_statements.6
	.section	.rodata
	.align 8
.LC48:
	.ascii	"failed precondition from silver_output_profile.adb:483"
	.align 8
.LC49:
	.ascii	"failed precondition from silver_output_profile.adb:484"
	.align 8
.LC50:
	.ascii	"failed precondition from silver_output_profile.adb:485"
	.align 8
.LC51:
	.ascii	"failed postcondition from silver_output_profile.adb:486"
	.align 8
.LC52:
	.ascii	"failed postcondition from silver_output_profile.adb:487"
	.align 8
.LC53:
	.ascii	"failed postcondition from silver_output_profile.adb:488"
	.text
	.align 2
	.globl	silver_output_profile__image_at
	.type	silver_output_profile__image_at, @function
silver_output_profile__image_at:
.LFB30:
	.loc 2 490 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$224, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, -120(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -144(%rbp)
	movq	%rdx, -136(%rbp)
	movl	%ecx, -124(%rbp)
	movq	%r8, -152(%rbp)
	movq	%r9, -160(%rbp)
	.loc 2 490 4
	leaq	16(%rbp), %rdx
	.loc 2 490 4 is_stmt 0 discriminator 1
	leaq	-144(%rbp), %rax
	movq	%rdx, -48(%rbp)
	movq	%rax, -64(%rbp)
	movl	-124(%rbp), %eax
	movl	%eax, -56(%rbp)
	movq	-152(%rbp), %rax
	movq	%rax, -80(%rbp)
	movq	-160(%rbp), %rax
	movq	%rax, -72(%rbp)
	movzbl	16(%rbp), %eax
	movb	%al, -52(%rbp)
	movq	-136(%rbp), %rax
	movl	(%rax), %r8d
	movq	-136(%rbp), %rax
	movl	4(%rax), %r12d
	movq	-136(%rbp), %rax
	movl	4(%rax), %edx
	movq	-136(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L466
	.loc 2 490 4 discriminator 2
	movq	-136(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-136(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L467
.L466:
	.loc 2 490 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L467:
.LBB77:
	.loc 2 483 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L468
.LBB78:
	.loc 2 483 15 is_stmt 0 discriminator 1
	leaq	.LC48(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L468:
.LBE78:
	.loc 2 483 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 483 15 discriminator 2
	testl	%eax, %eax
	jle	.L469
	.loc 2 483 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L470
.L469:
.LBB79:
	.loc 2 483 15 discriminator 4
	leaq	.LC48(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L470:
.LBE79:
	.loc 2 484 41
	cmpl	$2147483647, %r12d
	jne	.L471
	.loc 2 484 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$484, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L471:
	.loc 2 484 41 discriminator 3
	leal	1(%r12), %edx
	.loc 2 483 15 is_stmt 1 discriminator 5
	movl	-56(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L472
.LBB80:
	.loc 2 483 15 is_stmt 0 discriminator 6
	leaq	.LC49(%rip), %rax
	movq	%rax, -256(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -248(%rbp)
	movq	-256(%rbp), %rbx
	movq	-248(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L472:
.LBE80:
	.loc 2 484 54 is_stmt 1 discriminator 4
	movq	-80(%rbp), %rdx
	movq	-144(%rbp), %rcx
	movq	-136(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_names
	.loc 2 484 54 is_stmt 0 discriminator 5
	xorl	$1, %eax
	.loc 2 483 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L473
.LBB81:
	.loc 2 483 15 is_stmt 0 discriminator 8
	leaq	.LC49(%rip), %rax
	movq	%rax, -240(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -232(%rbp)
	movq	-240(%rbp), %rbx
	movq	-232(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L473:
.LBE81:
	.loc 2 485 37 is_stmt 1
	movq	-72(%rbp), %rdx
	movq	-144(%rbp), %rcx
	movq	-136(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__valid_environment@PLT
	.loc 2 485 37 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 483 15 is_stmt 1 discriminator 9
	testb	%al, %al
	je	.L474
.LBB82:
	.loc 2 483 15 is_stmt 0 discriminator 10
	leaq	.LC50(%rip), %rax
	movq	%rax, -224(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rbx
	movq	-216(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L474:
.LBE82:
.LBB83:
	.loc 2 490 4 is_stmt 1 discriminator 5
	leaq	-112(%rbp), %rax
	leaq	-80(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_output_profile__image_at___wrapped_statements.6
	.loc 2 486 44
	movl	-108(%rbp), %eax
	.loc 2 486 16
	testl	%eax, %eax
	je	.L475
.LBB84:
	.loc 2 486 16 is_stmt 0 discriminator 1
	leaq	.LC51(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L475:
.LBE84:
	.loc 2 487 45 is_stmt 1
	movl	-92(%rbp), %eax
	.loc 2 486 16 discriminator 2
	testl	%eax, %eax
	je	.L476
.LBB85:
	.loc 2 486 16 is_stmt 0 discriminator 3
	leaq	.LC52(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L476:
.LBE85:
	.loc 2 488 42 is_stmt 1
	movl	-112(%rbp), %eax
	.loc 2 486 16 discriminator 4
	testl	%eax, %eax
	je	.L477
	.loc 2 489 42
	movl	-112(%rbp), %eax
	.loc 2 489 12
	movl	-56(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L478
	.loc 2 489 42 discriminator 1
	movl	-112(%rbp), %eax
	.loc 2 489 71 discriminator 1
	cmpl	$2147483647, %r12d
	jne	.L479
	.loc 2 489 71 is_stmt 0 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$489, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L479:
	.loc 2 489 71 discriminator 4
	leal	1(%r12), %edx
	.loc 2 489 42 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L477
.L478:
.LBB86:
	.loc 2 486 16 discriminator 5
	leaq	.LC53(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rcx
	movq	-168(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L477:
.LBE86:
	.loc 2 490 4 discriminator 6
	movq	-120(%rbp), %rcx
	movq	-112(%rbp), %rax
	movq	-104(%rbp), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movq	-96(%rbp), %rax
	movq	%rax, 16(%rcx)
.LBE83:
.LBE77:
	.loc 2 490 4 is_stmt 0
	movq	-120(%rbp), %rax
	addq	$224, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE30:
	.size	silver_output_profile__image_at, .-silver_output_profile__image_at
	.align 2
	.type	silver_output_profile__value_at___wrapped_statements.7, @function
silver_output_profile__value_at___wrapped_statements.7:
.LFB33:
	.loc 2 530 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$168, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -168(%rbp)
	movq	%r10, %rbx
	movq	%r10, -176(%rbp)
	.loc 2 535 52
	movq	16(%rbx), %rax
	movl	24(%rbx), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__skip_at
	.loc 2 535 52 is_stmt 0 discriminator 1
	movl	%eax, -20(%rbp)
	.loc 2 536 49 is_stmt 1
	movq	16(%rbx), %rax
	leaq	-128(%rbp), %rdi
	movl	-20(%rbp), %ecx
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__literal_at
	.loc 2 537 52
	movq	16(%rbx), %rax
	movl	-20(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__name_after
	.loc 2 537 52 is_stmt 0 discriminator 1
	movl	%eax, -24(%rbp)
	.loc 2 538 49 is_stmt 1
	movq	16(%rbx), %rax
	movq	8(%rbx), %rdx
	movl	-24(%rbp), %edi
	movl	-20(%rbp), %ecx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__lookup_name
	.loc 2 538 49 is_stmt 0 discriminator 1
	movl	%eax, -28(%rbp)
	.loc 2 540 26 is_stmt 1
	movl	-128(%rbp), %eax
	.loc 2 540 10
	testl	%eax, %eax
	jne	.L482
	.loc 2 541 10
	cmpl	$0, -28(%rbp)
	je	.L483
	.loc 2 542 39
	movq	16(%rbx), %rax
	movq	(%rbx), %rdx
	movl	-24(%rbp), %edi
	movl	-20(%rbp), %ecx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__lookup@PLT
	.loc 2 542 82 discriminator 1
	testl	%eax, %eax
	sete	%al
	.loc 2 542 12 discriminator 1
	testb	%al, %al
	je	.L483
	.loc 2 543 49
	cmpl	$0, -28(%rbp)
	jle	.L484
	.loc 2 543 49 is_stmt 0 discriminator 1
	cmpl	$341, -28(%rbp)
	jle	.L485
.L484:
	.loc 2 543 49 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$543, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L485:
	.loc 2 544 36 is_stmt 1
	cmpl	$0, -28(%rbp)
	jle	.L486
	.loc 2 544 36 is_stmt 0 discriminator 1
	cmpl	$341, -28(%rbp)
	jle	.L487
.L486:
	.loc 2 544 36 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$544, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L487:
	.loc 2 545 35 is_stmt 1
	cmpl	$0, -28(%rbp)
	jle	.L488
	.loc 2 545 35 is_stmt 0 discriminator 1
	cmpl	$341, -28(%rbp)
	jle	.L489
.L488:
	.loc 2 545 35 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$545, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L489:
	.loc 2 546 34 is_stmt 1
	cmpl	$0, -28(%rbp)
	jle	.L490
	.loc 2 546 34 is_stmt 0 discriminator 1
	cmpl	$341, -28(%rbp)
	jle	.L491
.L490:
	.loc 2 546 34 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$546, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L491:
	.loc 2 543 12 is_stmt 1 discriminator 3
	movl	-24(%rbp), %eax
	movl	%eax, -64(%rbp)
	movl	-28(%rbp), %eax
	cltq
	movq	8(%rbx), %rcx
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$2, %rax
	addq	%rcx, %rax
	addq	$12, %rax
	movl	(%rax), %eax
	.loc 2 543 12 is_stmt 0 discriminator 4
	movl	%eax, -60(%rbp)
	movl	-28(%rbp), %eax
	cltq
	movq	8(%rbx), %rcx
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$2, %rax
	addq	%rcx, %rax
	addq	$16, %rax
	movl	(%rax), %eax
	.loc 2 543 12 discriminator 5
	movl	%eax, -56(%rbp)
	movl	-28(%rbp), %eax
	cltq
	movq	8(%rbx), %rcx
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$2, %rax
	addq	%rcx, %rax
	addq	$16, %rax
	movl	(%rax), %eax
	.loc 2 543 12 discriminator 6
	movl	%eax, -52(%rbp)
	movl	-28(%rbp), %eax
	movslq	%eax, %rdx
	movq	8(%rbx), %rcx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$2, %rax
	addq	%rcx, %rax
	movzbl	(%rax), %eax
	.loc 2 543 12 discriminator 7
	movb	%al, -48(%rbp)
	movb	$1, -47(%rbp)
	movb	$0, -46(%rbp)
	movl	-28(%rbp), %eax
	movl	%eax, -44(%rbp)
	leaq	-64(%rbp), %rcx
	.loc 2 540 10 is_stmt 1 discriminator 1
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -96(%rbp)
	movq	%rdx, -88(%rbp)
	movq	16(%rcx), %rax
	movq	%rax, -80(%rbp)
	.loc 2 540 10 is_stmt 0 discriminator 2
	jmp	.L493
.L483:
	.loc 2 548 15 is_stmt 1
	movq	16(%rbx), %rax
	movl	24(%rbx), %ecx
	movq	8(%rbx), %r8
	movq	(%rbx), %r9
	movzbl	28(%rbx), %esi
	leaq	-160(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	subq	$8, %rsp
	movzbl	%sil, %esi
	pushq	%rsi
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__image_at
	addq	$16, %rsp
	.loc 2 548 15 is_stmt 0 discriminator 1
	leaq	-160(%rbp), %rcx
	.loc 2 540 10 is_stmt 1 discriminator 3
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -96(%rbp)
	movq	%rdx, -88(%rbp)
	movq	16(%rcx), %rax
	movq	%rax, -80(%rbp)
	jmp	.L493
.L482:
	.loc 2 540 10 is_stmt 0 discriminator 4
	movq	-128(%rbp), %rax
	movq	-120(%rbp), %rdx
	movq	%rax, -96(%rbp)
	movq	%rdx, -88(%rbp)
	movq	-112(%rbp), %rax
	movq	%rax, -80(%rbp)
.L493:
	.loc 2 540 10 discriminator 5
	leaq	-96(%rbp), %rsi
	.loc 2 535 7 is_stmt 1 discriminator 2
	movq	-168(%rbp), %rcx
	movq	(%rsi), %rax
	movq	8(%rsi), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movq	16(%rsi), %rax
	movq	%rax, 16(%rcx)
	.loc 2 530 4
	movq	-168(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE33:
	.size	silver_output_profile__value_at___wrapped_statements.7, .-silver_output_profile__value_at___wrapped_statements.7
	.section	.rodata
	.align 8
.LC54:
	.ascii	"failed precondition from silver_output_profile.adb:523"
	.align 8
.LC55:
	.ascii	"failed precondition from silver_output_profile.adb:524"
	.align 8
.LC56:
	.ascii	"failed precondition from silver_output_profile.adb:525"
	.align 8
.LC57:
	.ascii	"failed postcondition from silver_output_profile.adb:526"
	.align 8
.LC58:
	.ascii	"failed postcondition from silver_output_profile.adb:527"
	.align 8
.LC59:
	.ascii	"failed postcondition from silver_output_profile.adb:528"
	.text
	.align 2
	.globl	silver_output_profile__value_at
	.type	silver_output_profile__value_at, @function
silver_output_profile__value_at:
.LFB32:
	.loc 2 530 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$224, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, -120(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -144(%rbp)
	movq	%rdx, -136(%rbp)
	movl	%ecx, -124(%rbp)
	movq	%r8, -152(%rbp)
	movq	%r9, -160(%rbp)
	.loc 2 530 4
	leaq	16(%rbp), %rdx
	.loc 2 530 4 is_stmt 0 discriminator 1
	leaq	-144(%rbp), %rax
	movq	%rdx, -48(%rbp)
	movq	%rax, -64(%rbp)
	movl	-124(%rbp), %eax
	movl	%eax, -56(%rbp)
	movq	-152(%rbp), %rax
	movq	%rax, -72(%rbp)
	movq	-160(%rbp), %rax
	movq	%rax, -80(%rbp)
	movzbl	16(%rbp), %eax
	movb	%al, -52(%rbp)
	movq	-136(%rbp), %rax
	movl	(%rax), %r8d
	movq	-136(%rbp), %rax
	movl	4(%rax), %r12d
	movq	-136(%rbp), %rax
	movl	4(%rax), %edx
	movq	-136(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L496
	.loc 2 530 4 discriminator 2
	movq	-136(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-136(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L497
.L496:
	.loc 2 530 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L497:
.LBB87:
	.loc 2 523 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L498
.LBB88:
	.loc 2 523 15 is_stmt 0 discriminator 1
	leaq	.LC54(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L498:
.LBE88:
	.loc 2 523 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 523 15 discriminator 2
	testl	%eax, %eax
	jle	.L499
	.loc 2 523 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L500
.L499:
.LBB89:
	.loc 2 523 15 discriminator 4
	leaq	.LC54(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L500:
.LBE89:
	.loc 2 524 41
	cmpl	$2147483647, %r12d
	jne	.L501
	.loc 2 524 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$524, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L501:
	.loc 2 524 41 discriminator 3
	leal	1(%r12), %edx
	.loc 2 523 15 is_stmt 1 discriminator 5
	movl	-56(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L502
.LBB90:
	.loc 2 523 15 is_stmt 0 discriminator 6
	leaq	.LC55(%rip), %rax
	movq	%rax, -256(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -248(%rbp)
	movq	-256(%rbp), %rbx
	movq	-248(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L502:
.LBE90:
	.loc 2 524 54 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	-144(%rbp), %rcx
	movq	-136(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_names
	.loc 2 524 54 is_stmt 0 discriminator 5
	xorl	$1, %eax
	.loc 2 523 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L503
.LBB91:
	.loc 2 523 15 is_stmt 0 discriminator 8
	leaq	.LC55(%rip), %rax
	movq	%rax, -240(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -232(%rbp)
	movq	-240(%rbp), %rbx
	movq	-232(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L503:
.LBE91:
	.loc 2 525 37 is_stmt 1
	movq	-80(%rbp), %rdx
	movq	-144(%rbp), %rcx
	movq	-136(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__valid_environment@PLT
	.loc 2 525 37 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 523 15 is_stmt 1 discriminator 9
	testb	%al, %al
	je	.L504
.LBB92:
	.loc 2 523 15 is_stmt 0 discriminator 10
	leaq	.LC56(%rip), %rax
	movq	%rax, -224(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rbx
	movq	-216(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L504:
.LBE92:
.LBB93:
	.loc 2 530 4 is_stmt 1 discriminator 5
	leaq	-112(%rbp), %rax
	leaq	-80(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_output_profile__value_at___wrapped_statements.7
	.loc 2 526 44
	movl	-108(%rbp), %eax
	.loc 2 526 57
	cmpl	$2147483647, %r12d
	jne	.L505
	.loc 2 526 57 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$526, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L505:
	.loc 2 526 57 discriminator 3
	leal	1(%r12), %edx
	.loc 2 526 16 is_stmt 1 discriminator 4
	cmpl	%eax, %edx
	jge	.L506
.LBB94:
	.loc 2 526 16 is_stmt 0 discriminator 5
	leaq	.LC57(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L506:
.LBE94:
	.loc 2 527 45 is_stmt 1
	movl	-92(%rbp), %edx
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 526 16 discriminator 6
	cmpl	%eax, %edx
	jle	.L507
.LBB95:
	.loc 2 526 16 is_stmt 0 discriminator 7
	leaq	.LC58(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L507:
.LBE95:
	.loc 2 528 42 is_stmt 1
	movl	-112(%rbp), %eax
	.loc 2 526 16 discriminator 8
	testl	%eax, %eax
	je	.L508
	.loc 2 529 42
	movl	-112(%rbp), %eax
	.loc 2 529 12
	movl	-56(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L509
	.loc 2 529 42 discriminator 1
	movl	-112(%rbp), %eax
	.loc 2 529 71 discriminator 1
	cmpl	$2147483647, %r12d
	jne	.L510
	.loc 2 529 71 is_stmt 0 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$529, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L510:
	.loc 2 529 71 discriminator 4
	leal	1(%r12), %edx
	.loc 2 529 42 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L508
.L509:
.LBB96:
	.loc 2 526 16 discriminator 9
	leaq	.LC59(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rcx
	movq	-168(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L508:
.LBE96:
	.loc 2 530 4 discriminator 6
	movq	-120(%rbp), %rcx
	movq	-112(%rbp), %rax
	movq	-104(%rbp), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movq	-96(%rbp), %rax
	movq	%rax, 16(%rcx)
.LBE93:
.LBE87:
	.loc 2 530 4 is_stmt 0
	movq	-120(%rbp), %rax
	addq	$224, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE32:
	.size	silver_output_profile__value_at, .-silver_output_profile__value_at
	.align 2
	.globl	silver_output_profile__expression_resultIP
	.type	silver_output_profile__expression_resultIP, @function
silver_output_profile__expression_resultIP:
.LFB34:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE34:
	.size	silver_output_profile__expression_resultIP, .-silver_output_profile__expression_resultIP
	.align 2
	.globl	silver_output_profile__expression_stateIP
	.type	silver_output_profile__expression_stateIP, @function
silver_output_profile__expression_stateIP:
.LFB35:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE35:
	.size	silver_output_profile__expression_stateIP, .-silver_output_profile__expression_stateIP
	.section	.rodata
	.align 8
.LC60:
	.ascii	"failed precondition from silver_output_profile.adb:578"
	.text
	.align 2
	.globl	silver_output_profile__valid_expression_state
	.type	silver_output_profile__valid_expression_state, @function
silver_output_profile__valid_expression_state:
.LFB36:
	.loc 2 579 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r12
	pushq	%rbx
	subq	$32, %rsp
	.cfi_offset 12, -24
	.cfi_offset 3, -32
	movq	%rdi, %rax
	movq	%rsi, %r10
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r10, %rdi
	movq	%rsi, -32(%rbp)
	movq	%rdi, -24(%rbp)
	movq	%rdx, -40(%rbp)
	.loc 2 579 4
	movq	-24(%rbp), %rax
	movl	(%rax), %r11d
	movq	-24(%rbp), %rax
	movl	4(%rax), %r10d
	movq	-24(%rbp), %rax
	movl	4(%rax), %edx
	movq	-24(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L517
	.loc 2 579 4 is_stmt 0 discriminator 1
	movq	-24(%rbp), %rax
	movl	4(%rax), %esi
	movslq	%esi, %rax
	cqto
	movq	-24(%rbp), %rsi
	movl	(%rsi), %r12d
	movslq	%r12d, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L518
.L517:
	.loc 2 579 4 discriminator 2
	movl	$0, %eax
	movl	$0, %edx
.L518:
	.loc 2 578 15 is_stmt 1
	cmpl	$1, %r11d
	je	.L519
.LBB97:
	.loc 2 578 15 is_stmt 0 discriminator 1
	leaq	.LC60(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L519:
.LBE97:
	.loc 2 578 51 is_stmt 1 discriminator 2
	movl	%eax, %esi
	.loc 2 578 15 discriminator 2
	testl	%esi, %esi
	jle	.L520
	.loc 2 578 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L521
.L520:
.LBB98:
	.loc 2 578 15 discriminator 4
	leaq	.LC60(%rip), %rcx
	leaq	.LC0(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L521:
.LBE98:
	.loc 2 581 22
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 581 35
	cmpl	$2147483647, %r10d
	jne	.L522
	.loc 2 581 35 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$581, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L522:
	.loc 2 581 35 discriminator 3
	leal	1(%r10), %edx
	.loc 2 583 7 is_stmt 1
	cmpl	%eax, %edx
	jl	.L523
	.loc 2 582 36
	movq	-40(%rbp), %rax
	movl	12(%rax), %edx
	movq	-40(%rbp), %rax
	movl	16(%rax), %eax
	.loc 2 582 7
	cmpl	%eax, %edx
	jg	.L523
	.loc 2 583 32 discriminator 1
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 583 7 discriminator 1
	testl	%eax, %eax
	je	.L524
	.loc 2 583 56 discriminator 2
	movq	-40(%rbp), %rax
	movl	20(%rax), %edx
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 583 36 discriminator 2
	cmpl	%eax, %edx
	jge	.L523
.L524:
	.loc 2 583 7 discriminator 3
	movl	$1, %eax
	jmp	.L525
.L523:
	.loc 2 583 7 is_stmt 0 discriminator 4
	movl	$0, %eax
.L525:
	.loc 2 579 4 is_stmt 1
	addq	$32, %rsp
	popq	%rbx
	popq	%r12
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE36:
	.size	silver_output_profile__valid_expression_state, .-silver_output_profile__valid_expression_state
	.align 2
	.type	silver_output_profile__expression_step___wrapped_statements.8, @function
silver_output_profile__expression_step___wrapped_statements.8:
.LFB38:
	.loc 2 599 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$264, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -264(%rbp)
	movq	%r10, %rbx
	movq	%r10, -272(%rbp)
	.loc 2 605 17
	movq	24(%rbx), %rax
	movl	(%rax), %edx
	movq	16(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$11, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 605 17 is_stmt 0 discriminator 1
	movl	%eax, -20(%rbp)
	.loc 2 606 47 is_stmt 1
	movq	24(%rbx), %rax
	movl	(%rax), %ecx
	movq	16(%rbx), %rax
	movq	8(%rbx), %r8
	movq	(%rbx), %r9
	movzbl	32(%rbx), %esi
	leaq	-96(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	subq	$8, %rsp
	movzbl	%sil, %esi
	pushq	%rsi
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__value_at
	addq	$16, %rsp
	.loc 2 608 17
	movq	24(%rbx), %rax
	movl	(%rax), %edx
	movq	16(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$28, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 608 17 is_stmt 0 discriminator 1
	movl	%eax, -24(%rbp)
	.loc 2 610 17 is_stmt 1
	movq	24(%rbx), %rax
	movl	(%rax), %edx
	movq	16(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$12, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 610 17 is_stmt 0 discriminator 1
	movl	%eax, -28(%rbp)
	.loc 2 612 28 is_stmt 1
	movq	24(%rbx), %rax
	movl	(%rax), %eax
	.loc 2 612 10
	testl	%eax, %eax
	je	.L528
	.loc 2 612 10 is_stmt 0 discriminator 1
	movq	24(%rbx), %rax
	movzbl	26(%rax), %eax
	.loc 2 613 10 is_stmt 1
	testb	%al, %al
	je	.L529
	.loc 2 612 10 discriminator 2
	movq	24(%rbx), %rcx
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -64(%rbp)
	movq	%rdx, -56(%rbp)
	movq	12(%rcx), %rax
	movq	20(%rcx), %rdx
	movq	%rax, -52(%rbp)
	movq	%rdx, -44(%rbp)
	jmp	.L565
.L529:
	.loc 2 612 10 is_stmt 0 discriminator 3
	movq	24(%rbx), %rax
	movzbl	25(%rax), %eax
	.loc 2 614 10 is_stmt 1
	testb	%al, %al
	je	.L531
	.loc 2 615 13
	cmpl	$0, -20(%rbp)
	je	.L532
	.loc 2 616 15
	movq	24(%rbx), %rcx
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -128(%rbp)
	movq	%rdx, -120(%rbp)
	movq	12(%rcx), %rax
	movq	20(%rcx), %rdx
	movq	%rax, -116(%rbp)
	movq	%rdx, -108(%rbp)
	.loc 2 616 33
	movl	-20(%rbp), %eax
	movl	%eax, -128(%rbp)
	.loc 2 616 78
	movq	24(%rbx), %rax
	movl	20(%rax), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L533
	.loc 2 616 78 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L534
.L533:
	.loc 2 616 78 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$616, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L534:
	.loc 2 616 57 is_stmt 1 discriminator 3
	movl	%eax, -108(%rbp)
	.loc 2 612 10 discriminator 4
	movq	-128(%rbp), %rax
	movq	-120(%rbp), %rdx
	movq	%rax, -64(%rbp)
	movq	%rdx, -56(%rbp)
	movq	-116(%rbp), %rax
	movq	-108(%rbp), %rdx
	movq	%rax, -52(%rbp)
	movq	%rdx, -44(%rbp)
	jmp	.L565
.L532:
	.loc 2 617 34
	movq	24(%rbx), %rax
	movl	16(%rax), %eax
	.loc 2 617 13
	cmpl	$64, %eax
	je	.L536
	.loc 2 617 79 discriminator 1
	movl	-96(%rbp), %eax
	.loc 2 617 60 discriminator 1
	testl	%eax, %eax
	je	.L536
	.loc 2 618 42
	movl	-84(%rbp), %ecx
	.loc 2 618 62
	movq	24(%rbx), %rax
	movl	8(%rax), %eax
	movl	$4096, %edx
	subl	%eax, %edx
	.loc 2 618 15
	cmpl	%edx, %ecx
	jg	.L536
	.loc 2 619 43
	movl	-88(%rbp), %ecx
	.loc 2 619 63
	movq	24(%rbx), %rax
	movl	4(%rax), %eax
	movl	$4096, %edx
	subl	%eax, %edx
	.loc 2 619 15
	cmpl	%edx, %ecx
	jg	.L536
	.loc 2 621 18
	movq	24(%rbx), %rcx
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -160(%rbp)
	movq	%rdx, -152(%rbp)
	movq	12(%rcx), %rax
	movq	20(%rcx), %rdx
	movq	%rax, -148(%rbp)
	movq	%rdx, -140(%rbp)
	.loc 2 621 36
	movl	-96(%rbp), %eax
	movl	%eax, -160(%rbp)
	.loc 2 622 54
	movq	24(%rbx), %rax
	movl	4(%rax), %edx
	movl	-88(%rbp), %eax
	addl	%edx, %eax
	testl	%eax, %eax
	js	.L537
	.loc 2 622 54 is_stmt 0 discriminator 1
	cmpl	$4096, %eax
	jle	.L538
.L537:
	.loc 2 622 54 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$622, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L538:
	.loc 2 622 15 is_stmt 1 discriminator 3
	movl	%eax, -156(%rbp)
	.loc 2 623 52
	movq	24(%rbx), %rax
	movl	8(%rax), %edx
	movl	-84(%rbp), %eax
	addl	%edx, %eax
	testl	%eax, %eax
	js	.L539
	.loc 2 623 52 is_stmt 0 discriminator 1
	cmpl	$4096, %eax
	jle	.L540
.L539:
	.loc 2 623 52 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$623, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L540:
	.loc 2 623 15 is_stmt 1 discriminator 3
	movl	%eax, -152(%rbp)
	.loc 2 624 52
	movq	24(%rbx), %rax
	movl	12(%rax), %edx
	movzbl	-80(%rbp), %eax
	testb	%al, %al
	je	.L541
	.loc 2 624 52 is_stmt 0 discriminator 1
	movl	$1, %ecx
	jmp	.L542
.L541:
	.loc 2 624 52 discriminator 2
	movl	$0, %ecx
.L542:
	.loc 2 624 52 discriminator 3
	movl	$0, %eax
	addl	%ecx, %edx
	jno	.L543
	movl	$1, %eax
.L543:
	.loc 2 624 52 discriminator 4
	testl	%eax, %eax
	je	.L545
	.loc 2 624 52 discriminator 5
	leaq	.LC12(%rip), %rax
	movl	$624, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L545:
	.loc 2 624 52 discriminator 7
	movq	24(%rbx), %rax
	movl	12(%rax), %edx
	movzbl	-80(%rbp), %eax
	testb	%al, %al
	je	.L546
	.loc 2 624 52 discriminator 8
	movl	$1, %eax
	jmp	.L547
.L546:
	.loc 2 624 52 discriminator 9
	movl	$0, %eax
.L547:
	.loc 2 624 52 discriminator 10
	addl	%edx, %eax
	.loc 2 624 52 discriminator 12
	testl	%eax, %eax
	js	.L550
	.loc 2 624 52 discriminator 13
	cmpl	$64, %eax
	jle	.L551
.L550:
	.loc 2 624 52 discriminator 14
	leaq	.LC12(%rip), %rax
	movl	$624, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L551:
	.loc 2 624 15 is_stmt 1 discriminator 15
	movl	%eax, -148(%rbp)
	.loc 2 625 42
	movq	24(%rbx), %rax
	movl	16(%rax), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L552
	.loc 2 625 42 is_stmt 0 discriminator 1
	cmpl	$64, %eax
	jle	.L553
.L552:
	.loc 2 625 42 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$625, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L553:
	.loc 2 625 15 is_stmt 1 discriminator 3
	movl	%eax, -144(%rbp)
	.loc 2 626 46
	movq	24(%rbx), %rax
	movzbl	24(%rax), %eax
	testb	%al, %al
	jne	.L554
	.loc 2 626 46 is_stmt 0 discriminator 1
	movzbl	-79(%rbp), %eax
	testb	%al, %al
	je	.L555
.L554:
	.loc 2 626 46 discriminator 2
	movl	$1, %eax
	jmp	.L556
.L555:
	.loc 2 626 46 discriminator 3
	movl	$0, %eax
.L556:
	.loc 2 626 15 is_stmt 1 discriminator 4
	movb	%al, -136(%rbp)
	.loc 2 627 48
	movq	24(%rbx), %rax
	movzbl	27(%rax), %eax
	testb	%al, %al
	jne	.L557
	.loc 2 627 48 is_stmt 0 discriminator 1
	movzbl	-78(%rbp), %eax
	testb	%al, %al
	je	.L558
.L557:
	.loc 2 627 48 discriminator 2
	movl	$1, %eax
	jmp	.L559
.L558:
	.loc 2 627 48 discriminator 3
	movl	$0, %eax
.L559:
	.loc 2 627 15 is_stmt 1 discriminator 4
	movb	%al, -133(%rbp)
	.loc 2 628 15
	movb	$0, -135(%rbp)
	.loc 2 612 10 discriminator 5
	movq	-160(%rbp), %rax
	movq	-152(%rbp), %rdx
	movq	%rax, -64(%rbp)
	movq	%rdx, -56(%rbp)
	movq	-148(%rbp), %rax
	movq	-140(%rbp), %rdx
	movq	%rax, -52(%rbp)
	movq	%rdx, -44(%rbp)
	jmp	.L565
.L536:
	.loc 2 612 10 is_stmt 0 discriminator 6
	movl	$0, -64(%rbp)
	movl	$0, -60(%rbp)
	movl	$0, -56(%rbp)
	movl	$0, -52(%rbp)
	movl	$0, -48(%rbp)
	movl	$0, -44(%rbp)
	movb	$0, -40(%rbp)
	movb	$1, -39(%rbp)
	movb	$0, -38(%rbp)
	movb	$0, -37(%rbp)
	jmp	.L565
.L531:
	.loc 2 629 10 is_stmt 1
	cmpl	$0, -24(%rbp)
	je	.L560
	.loc 2 630 12
	movq	24(%rbx), %rcx
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -192(%rbp)
	movq	%rdx, -184(%rbp)
	movq	12(%rcx), %rax
	movq	20(%rcx), %rdx
	movq	%rax, -180(%rbp)
	movq	%rdx, -172(%rbp)
	.loc 2 630 30
	movl	-24(%rbp), %eax
	movl	%eax, -192(%rbp)
	.loc 2 630 54
	movb	$1, -167(%rbp)
	.loc 2 612 10 discriminator 7
	movq	-192(%rbp), %rax
	movq	-184(%rbp), %rdx
	movq	%rax, -64(%rbp)
	movq	%rdx, -56(%rbp)
	movq	-180(%rbp), %rax
	movq	-172(%rbp), %rdx
	movq	%rax, -52(%rbp)
	movq	%rdx, -44(%rbp)
	jmp	.L565
.L560:
	.loc 2 631 10
	cmpl	$0, -28(%rbp)
	je	.L561
	.loc 2 631 54 discriminator 1
	movq	24(%rbx), %rax
	movl	20(%rax), %eax
	.loc 2 631 33 discriminator 1
	testl	%eax, %eax
	je	.L561
	.loc 2 632 12
	movq	24(%rbx), %rcx
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -224(%rbp)
	movq	%rdx, -216(%rbp)
	movq	12(%rcx), %rax
	movq	20(%rcx), %rdx
	movq	%rax, -212(%rbp)
	movq	%rdx, -204(%rbp)
	.loc 2 632 30
	movl	-28(%rbp), %eax
	movl	%eax, -224(%rbp)
	.loc 2 632 76
	movq	24(%rbx), %rax
	movl	20(%rax), %eax
	subl	$1, %eax
	testl	%eax, %eax
	js	.L562
	.loc 2 632 76 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L563
.L562:
	.loc 2 632 76 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$632, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L563:
	.loc 2 632 55 is_stmt 1 discriminator 3
	movl	%eax, -204(%rbp)
	.loc 2 612 10 discriminator 8
	movq	-224(%rbp), %rax
	movq	-216(%rbp), %rdx
	movq	%rax, -64(%rbp)
	movq	%rdx, -56(%rbp)
	movq	-212(%rbp), %rax
	movq	-204(%rbp), %rdx
	movq	%rax, -52(%rbp)
	movq	%rdx, -44(%rbp)
	jmp	.L565
.L561:
	.loc 2 633 28
	movq	24(%rbx), %rax
	movl	20(%rax), %eax
	.loc 2 633 10
	testl	%eax, %eax
	jne	.L564
	.loc 2 633 37 discriminator 1
	movq	24(%rbx), %rcx
	movq	(%rcx), %rax
	movq	8(%rcx), %rdx
	movq	%rax, -256(%rbp)
	movq	%rdx, -248(%rbp)
	movq	12(%rcx), %rax
	movq	20(%rcx), %rdx
	movq	%rax, -244(%rbp)
	movq	%rdx, -236(%rbp)
	.loc 2 633 55 discriminator 1
	movb	$1, -230(%rbp)
	.loc 2 612 10 discriminator 9
	movq	-256(%rbp), %rax
	movq	-248(%rbp), %rdx
	movq	%rax, -64(%rbp)
	movq	%rdx, -56(%rbp)
	movq	-244(%rbp), %rax
	movq	-236(%rbp), %rdx
	movq	%rax, -52(%rbp)
	movq	%rdx, -44(%rbp)
	jmp	.L565
.L564:
	.loc 2 612 10 is_stmt 0 discriminator 10
	movl	$0, -64(%rbp)
	movl	$0, -60(%rbp)
	movl	$0, -56(%rbp)
	movl	$0, -52(%rbp)
	movl	$0, -48(%rbp)
	movl	$0, -44(%rbp)
	movb	$0, -40(%rbp)
	movb	$1, -39(%rbp)
	movb	$0, -38(%rbp)
	movb	$0, -37(%rbp)
	jmp	.L565
.L528:
	.loc 2 612 10 discriminator 11
	movl	$0, -64(%rbp)
	movl	$0, -60(%rbp)
	movl	$0, -56(%rbp)
	movl	$0, -52(%rbp)
	movl	$0, -48(%rbp)
	movl	$0, -44(%rbp)
	movb	$0, -40(%rbp)
	movb	$1, -39(%rbp)
	movb	$0, -38(%rbp)
	movb	$0, -37(%rbp)
.L565:
	.loc 2 612 10 discriminator 12
	leaq	-64(%rbp), %rsi
	.loc 2 604 7 is_stmt 1
	movq	-264(%rbp), %rcx
	movq	(%rsi), %rax
	movq	8(%rsi), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movq	12(%rsi), %rax
	movq	20(%rsi), %rdx
	movq	%rax, 12(%rcx)
	movq	%rdx, 20(%rcx)
	.loc 2 599 4
	movq	-264(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE38:
	.size	silver_output_profile__expression_step___wrapped_statements.8, .-silver_output_profile__expression_step___wrapped_statements.8
	.section	.rodata
	.align 8
.LC61:
	.ascii	"failed precondition from silver_output_profile.adb:591"
	.align 8
.LC62:
	.ascii	"failed precondition from silver_output_profile.adb:592"
	.align 8
.LC63:
	.ascii	"failed precondition from silver_output_profile.adb:593"
	.align 8
.LC64:
	.ascii	"failed precondition from silver_output_profile.adb:594"
	.align 8
.LC65:
	.ascii	"failed postcondition from silver_output_profile.adb:595"
	.align 8
.LC66:
	.ascii	"failed postcondition from silver_output_profile.adb:596"
	.text
	.align 2
	.globl	silver_output_profile__expression_step
	.type	silver_output_profile__expression_step, @function
silver_output_profile__expression_step:
.LFB37:
	.loc 2 599 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$200, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -136(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -160(%rbp)
	movq	%rdx, -152(%rbp)
	movq	%rcx, -144(%rbp)
	movq	%r8, -168(%rbp)
	movq	%r9, -176(%rbp)
	.loc 2 599 4
	leaq	16(%rbp), %rdx
	.loc 2 599 4 is_stmt 0 discriminator 1
	leaq	-160(%rbp), %rax
	movq	%rdx, -56(%rbp)
	movq	%rax, -80(%rbp)
	movq	-144(%rbp), %rax
	movq	%rax, -88(%rbp)
	movq	-168(%rbp), %rax
	movq	%rax, -72(%rbp)
	movq	-176(%rbp), %rax
	movq	%rax, -96(%rbp)
	movzbl	16(%rbp), %eax
	movb	%al, -64(%rbp)
	movq	-152(%rbp), %rax
	movl	(%rax), %r8d
	movq	-152(%rbp), %rax
	movl	4(%rax), %edx
	movq	-152(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L568
	.loc 2 599 4 discriminator 2
	movq	-152(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-152(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L569
.L568:
	.loc 2 599 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L569:
.LBB99:
	.loc 2 591 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L570
.LBB100:
	.loc 2 591 15 is_stmt 0 discriminator 1
	leaq	.LC61(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L570:
.LBE100:
	.loc 2 591 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 591 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L571
	.loc 2 591 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L572
.L571:
.LBB101:
	.loc 2 591 15 discriminator 4
	leaq	.LC61(%rip), %rax
	movq	%rax, -240(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -232(%rbp)
	movq	-240(%rbp), %rbx
	movq	-232(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L572:
.LBE101:
	.loc 2 592 19
	movq	-88(%rbp), %rdx
	movq	-160(%rbp), %rcx
	movq	-152(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_names
	.loc 2 592 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 591 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L573
.LBB102:
	.loc 2 591 15 is_stmt 0 discriminator 6
	leaq	.LC62(%rip), %rax
	movq	%rax, -224(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rbx
	movq	-216(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L573:
.LBE102:
	.loc 2 593 37 is_stmt 1
	movq	-96(%rbp), %rdx
	movq	-160(%rbp), %rcx
	movq	-152(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__valid_environment@PLT
	.loc 2 593 37 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 591 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L574
.LBB103:
	.loc 2 591 15 is_stmt 0 discriminator 8
	leaq	.LC63(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L574:
.LBE103:
	.loc 2 594 19 is_stmt 1
	movq	-72(%rbp), %rdx
	movq	-160(%rbp), %rcx
	movq	-152(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_expression_state
	.loc 2 594 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 591 15 is_stmt 1 discriminator 9
	testb	%al, %al
	je	.L575
.LBB104:
	.loc 2 591 15 is_stmt 0 discriminator 10
	leaq	.LC64(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L575:
.LBE104:
.LBB105:
	.loc 2 599 4 is_stmt 1 discriminator 5
	leaq	-128(%rbp), %rax
	leaq	-96(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_output_profile__expression_step___wrapped_statements.8
.LBB106:
	.loc 2 595 16
	leaq	-128(%rbp), %rdx
	movq	-160(%rbp), %rcx
	movq	-152(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_expression_state
	.loc 2 595 16 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L576
.LBB107:
	.loc 2 595 16 discriminator 2
	leaq	.LC65(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L576:
.LBE107:
	.loc 2 596 52 is_stmt 1
	movl	-128(%rbp), %eax
	.loc 2 595 16 discriminator 3
	testl	%eax, %eax
	je	.L577
	.loc 2 597 12
	movzbl	-102(%rbp), %eax
	xorl	$1, %eax
	testb	%al, %al
	je	.L577
	.loc 2 598 52
	movl	-128(%rbp), %edx
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 598 12
	cmpl	%eax, %edx
	jg	.L577
.LBB108:
	.loc 2 595 16 discriminator 4
	leaq	.LC66(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L577:
.LBE108:
.LBE106:
	.loc 2 599 4 discriminator 6
	movq	-136(%rbp), %rcx
	movq	-128(%rbp), %rax
	movq	-120(%rbp), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movq	-116(%rbp), %rax
	movq	-108(%rbp), %rdx
	movq	%rax, 12(%rcx)
	movq	%rdx, 20(%rcx)
.LBE105:
.LBE99:
	.loc 2 599 4 is_stmt 0
	movq	-136(%rbp), %rax
	addq	$200, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE37:
	.size	silver_output_profile__expression_step, .-silver_output_profile__expression_step
	.section	.rodata
	.align 8
.LC67:
	.ascii	"failed precondition from silver_output_profile.adb:673"
	.align 8
.LC68:
	.ascii	"failed precondition from silver_output_profile.adb:674"
	.align 8
.LC69:
	.ascii	"failed precondition from silver_output_profile.adb:675"
	.align 8
.LC70:
	.ascii	"Loop_Invariant failed at silver_output_profile.adb:693"
	.align 8
.LC71:
	.ascii	"Loop_Invariant failed at silver_output_profile.adb:694"
	.align 8
.LC72:
	.ascii	"Loop_Invariant failed at silver_output_profile.adb:696"
	.align 8
.LC73:
	.ascii	"Loop_Invariant failed at silver_output_profile.adb:698"
	.align 8
.LC74:
	.ascii	"Loop_Variant failed at silver_output_profile.adb:705"
	.text
	.align 2
	.globl	silver_output_profile__expression_at
	.type	silver_output_profile__expression_at, @function
silver_output_profile__expression_at:
.LFB39:
	.loc 2 682 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$248, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -88(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -112(%rbp)
	movq	%rdx, -104(%rbp)
	movl	%ecx, -92(%rbp)
	movq	%r8, -120(%rbp)
	movq	%r9, -128(%rbp)
	.loc 2 682 4
	movq	-104(%rbp), %rax
	movl	(%rax), %r8d
	movq	-104(%rbp), %rax
	movl	4(%rax), %r9d
	cmpl	%r8d, %r9d
	jl	.L580
	.loc 2 682 4 is_stmt 0 discriminator 1
	movslq	%r9d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r8d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L581
.L580:
	.loc 2 682 4 discriminator 2
	movl	$0, %ecx
	movl	$0, %ebx
.L581:
.LBB109:
	.loc 2 682 4 discriminator 3
	cmpl	%r8d, %r9d
	.loc 2 682 4 discriminator 6
	cmpl	%r8d, %r9d
	.loc 2 682 4 discriminator 9
	cmpl	%r8d, %r9d
	.loc 2 673 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L588
.LBB110:
	.loc 2 673 15 is_stmt 0 discriminator 1
	leaq	.LC67(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L588:
.LBE110:
	.loc 2 673 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 673 15 discriminator 2
	testl	%eax, %eax
	jle	.L589
	.loc 2 673 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L590
.L589:
.LBB111:
	.loc 2 673 15 discriminator 4
	leaq	.LC67(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L590:
.LBE111:
	.loc 2 674 41
	cmpl	$2147483647, %r9d
	jne	.L591
	.loc 2 674 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$674, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L591:
	.loc 2 674 41 discriminator 3
	leal	1(%r9), %eax
	.loc 2 673 15 is_stmt 1 discriminator 5
	cmpl	-92(%rbp), %eax
	jge	.L592
.LBB112:
	.loc 2 673 15 is_stmt 0 discriminator 6
	leaq	.LC68(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L592:
.LBE112:
	.loc 2 674 54 is_stmt 1 discriminator 4
	movq	-120(%rbp), %rdx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_names
	.loc 2 674 54 is_stmt 0 discriminator 5
	xorl	$1, %eax
	.loc 2 673 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L593
.LBB113:
	.loc 2 673 15 is_stmt 0 discriminator 8
	leaq	.LC68(%rip), %rax
	movq	%rax, -272(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -264(%rbp)
	movq	-272(%rbp), %rbx
	movq	-264(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L593:
.LBE113:
	.loc 2 675 37 is_stmt 1
	movq	-128(%rbp), %rdx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__valid_environment@PLT
	.loc 2 675 37 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 673 15 is_stmt 1 discriminator 9
	testb	%al, %al
	je	.L594
.LBB114:
	.loc 2 673 15 is_stmt 0 discriminator 10
	leaq	.LC69(%rip), %rax
	movq	%rax, -256(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -248(%rbp)
	movq	-256(%rbp), %rbx
	movq	-248(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L594:
.LBE114:
	.loc 2 687 7 is_stmt 1
	movl	-92(%rbp), %eax
	movl	%eax, -80(%rbp)
	movl	$0, -76(%rbp)
	movl	$0, -72(%rbp)
	movl	$0, -68(%rbp)
	movl	$0, -64(%rbp)
	movl	$0, -60(%rbp)
	movb	$0, -56(%rbp)
	movb	$1, -55(%rbp)
	movb	$0, -54(%rbp)
	movb	$0, -53(%rbp)
	.loc 2 692 61
	movl	$0, %ebx
.L605:
	.loc 2 692 28 discriminator 1
	movl	-80(%rbp), %eax
	.loc 2 692 33 discriminator 1
	testl	%eax, %eax
	je	.L595
	.loc 2 692 33 is_stmt 0 discriminator 2
	movzbl	-54(%rbp), %eax
	testb	%al, %al
	jne	.L595
	.loc 2 693 33 is_stmt 1
	leaq	-80(%rbp), %rax
	movq	-112(%rbp), %rsi
	movq	-104(%rbp), %rcx
	movq	%rax, %rdx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver_output_profile__valid_expression_state
	.loc 2 693 33 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L596
.LBB115:
	.loc 2 693 33 discriminator 2
	leaq	.LC70(%rip), %rax
	movq	%rax, -240(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -232(%rbp)
	movq	-240(%rbp), %rbx
	movq	-232(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L596:
.LBE115:
	.loc 2 694 48 is_stmt 1
	movl	-80(%rbp), %eax
	.loc 2 694 33
	cmpl	%eax, -92(%rbp)
	jle	.L597
.LBB116:
	.loc 2 694 33 is_stmt 0 discriminator 1
	leaq	.LC71(%rip), %rax
	movq	%rax, -224(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rbx
	movq	-216(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L597:
.LBE116:
	.loc 2 696 13 is_stmt 1
	movzbl	-55(%rbp), %eax
	xorl	$1, %eax
	testb	%al, %al
	je	.L598
	.loc 2 696 59 discriminator 1
	movl	-80(%rbp), %eax
	.loc 2 696 13 discriminator 1
	cmpl	%eax, -92(%rbp)
	jl	.L598
.LBB117:
	.loc 2 696 13 is_stmt 0 discriminator 2
	leaq	.LC72(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L598:
.LBE117:
	.loc 2 698 13 is_stmt 1
	movzbl	-54(%rbp), %eax
	testb	%al, %al
	je	.L599
	.loc 2 698 13 is_stmt 0 discriminator 1
	movzbl	-55(%rbp), %eax
	jmp	.L600
.L599:
	.loc 2 698 13 discriminator 2
	movl	$0, %eax
.L600:
	.loc 2 698 13 discriminator 3
	testb	%al, %al
	je	.L601
.LBB118:
	.loc 2 698 13 discriminator 4
	leaq	.LC73(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rcx
	movq	-184(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L601:
.LBE118:
	.loc 2 705 10 is_stmt 1
	testb	%bl, %bl
	je	.L602
	.loc 2 705 49 discriminator 1
	movl	-96(%rbp), %eax
	movl	%eax, -276(%rbp)
.L602:
	.loc 2 705 49 is_stmt 0 discriminator 2
	movl	-80(%rbp), %eax
	movl	%eax, -96(%rbp)
	.loc 2 705 10 is_stmt 1 discriminator 2
	testb	%bl, %bl
	je	.L603
	.loc 2 705 49 discriminator 3
	movl	-276(%rbp), %edi
	cmpl	%edi, %eax
	jg	.L604
.LBB119:
	.loc 2 705 49 is_stmt 0 discriminator 4
	leaq	.LC74(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC2(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rcx
	movq	-168(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L603:
.LBE119:
	.loc 2 705 10 is_stmt 1 discriminator 5
	movl	$1, %ebx
.L604:
	.loc 2 706 19
	leaq	-160(%rbp), %r10
	movq	-128(%rbp), %r8
	leaq	-80(%rbp), %rdi
	movq	-120(%rbp), %rcx
	movq	-112(%rbp), %rsi
	movq	-104(%rbp), %rdx
	subq	$8, %rsp
	movzbl	16(%rbp), %eax
	pushq	%rax
	movq	%r8, %r9
	movq	%rdi, %r8
	movq	%r10, %rdi
	call	silver_output_profile__expression_step
	addq	$16, %rsp
	movq	-160(%rbp), %rax
	movq	-152(%rbp), %rdx
	movq	%rax, -80(%rbp)
	movq	%rdx, -72(%rbp)
	movq	-148(%rbp), %rax
	movq	-140(%rbp), %rdx
	movq	%rax, -68(%rbp)
	movq	%rdx, -60(%rbp)
	.loc 2 707 15
	jmp	.L605
.L595:
	.loc 2 708 25
	movl	-80(%rbp), %eax
	.loc 2 708 7
	testl	%eax, %eax
	jne	.L606
	.loc 2 708 34 discriminator 1
	movq	-88(%rbp), %rax
	movl	$0, (%rax)
	movq	-88(%rbp), %rax
	movl	$0, 4(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 8(%rax)
	movq	-88(%rbp), %rax
	movl	$0, 12(%rax)
	movq	-88(%rbp), %rax
	movb	$0, 16(%rax)
	movq	-88(%rbp), %rax
	movb	$0, 17(%rax)
	jmp	.L608
.L606:
	.loc 2 709 7
	movl	-80(%rbp), %edx
	movq	-88(%rbp), %rax
	movl	%edx, (%rax)
	movl	-76(%rbp), %edx
	movq	-88(%rbp), %rax
	movl	%edx, 4(%rax)
	movl	-72(%rbp), %edx
	movq	-88(%rbp), %rax
	movl	%edx, 8(%rax)
	movl	-68(%rbp), %edx
	movq	-88(%rbp), %rax
	movl	%edx, 12(%rax)
	movzbl	-56(%rbp), %edx
	movq	-88(%rbp), %rax
	movb	%dl, 16(%rax)
	movzbl	-53(%rbp), %edx
	movq	-88(%rbp), %rax
	movb	%dl, 17(%rax)
.L608:
.LBE109:
	.loc 2 711 8
	movq	-88(%rbp), %rax
	leaq	-40(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE39:
	.size	silver_output_profile__expression_at, .-silver_output_profile__expression_at
	.align 2
	.globl	silver_output_profile__fits
	.type	silver_output_profile__fits, @function
silver_output_profile__fits:
.LFB40:
	.loc 2 715 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movl	%esi, -12(%rbp)
	.loc 2 716 19
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 717 7
	testl	%eax, %eax
	je	.L610
	.loc 2 717 7 is_stmt 0 discriminator 1
	movq	-8(%rbp), %rax
	movzbl	17(%rax), %eax
	testb	%al, %al
	jne	.L611
	.loc 2 718 37 is_stmt 1
	movq	-8(%rbp), %rax
	movl	8(%rax), %edx
	.loc 2 718 59
	movq	-8(%rbp), %rax
	movl	12(%rax), %eax
	imull	-12(%rbp), %eax
	.loc 2 718 37
	addl	%edx, %eax
	.loc 2 718 9
	cmpl	$4096, %eax
	jg	.L610
.L611:
	.loc 2 717 7 discriminator 2
	movl	$1, %eax
	jmp	.L612
.L610:
	.loc 2 717 7 is_stmt 0 discriminator 3
	movl	$0, %eax
.L612:
	.loc 2 715 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE40:
	.size	silver_output_profile__fits, .-silver_output_profile__fits
	.section	.rodata
	.align 8
.LC75:
	.ascii	"failed precondition from silver_output_profile.adb:724"
	.align 8
.LC76:
	.ascii	"failed precondition from silver_output_profile.adb:725"
	.align 8
.LC77:
	.ascii	"failed precondition from silver_output_profile.adb:726"
	.text
	.align 2
	.globl	silver_output_profile__new_name_allowed
	.type	silver_output_profile__new_name_allowed, @function
silver_output_profile__new_name_allowed:
.LFB41:
	.loc 2 727 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$112, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r10
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r10, %rdi
	movq	%rsi, -48(%rbp)
	movq	%rdi, -40(%rbp)
	movq	%rdx, -56(%rbp)
	movl	%ecx, -60(%rbp)
	movl	%r8d, -64(%rbp)
	movb	%r9b, -65(%rbp)
	.loc 2 727 4
	movq	-40(%rbp), %rax
	movl	(%rax), %r8d
	movq	-40(%rbp), %rax
	movl	4(%rax), %r12d
	movq	-40(%rbp), %rax
	movl	4(%rax), %edx
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L615
	.loc 2 727 4 is_stmt 0 discriminator 1
	movq	-40(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L616
.L615:
	.loc 2 727 4 discriminator 2
	movl	$0, %eax
	movl	$0, %edx
.L616:
.LBB120:
	.loc 2 724 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L617
.LBB121:
	.loc 2 724 15 is_stmt 0 discriminator 1
	leaq	.LC75(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L617:
.LBE121:
	.loc 2 724 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 724 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L618
	.loc 2 724 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L619
.L618:
.LBB122:
	.loc 2 724 15 discriminator 4
	leaq	.LC75(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L619:
.LBE122:
	.loc 2 725 19
	movq	-56(%rbp), %rdx
	movq	-48(%rbp), %rcx
	movq	-40(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 725 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 724 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L620
.LBB123:
	.loc 2 724 15 is_stmt 0 discriminator 6
	leaq	.LC76(%rip), %rax
	movq	%rax, -112(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -104(%rbp)
	movq	-112(%rbp), %rbx
	movq	-104(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L620:
.LBE123:
	.loc 2 726 38 is_stmt 1
	cmpl	$2147483647, %r12d
	jne	.L621
	.loc 2 726 38 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$726, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L621:
	.loc 2 726 38 discriminator 3
	leal	1(%r12), %eax
	.loc 2 724 15 is_stmt 1 discriminator 7
	cmpl	-60(%rbp), %eax
	jge	.L622
.LBB124:
	.loc 2 724 15 is_stmt 0 discriminator 8
	leaq	.LC77(%rip), %rax
	movq	%rax, -96(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -88(%rbp)
	movq	-96(%rbp), %rbx
	movq	-88(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L622:
.LBE124:
	.loc 2 726 70 is_stmt 1 discriminator 4
	cmpl	$2147483647, %r12d
	jne	.L623
	.loc 2 726 70 is_stmt 0 discriminator 5
	leaq	.LC12(%rip), %rax
	movl	$726, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L623:
	.loc 2 726 70 discriminator 7
	leal	1(%r12), %eax
	.loc 2 724 15 is_stmt 1 discriminator 9
	cmpl	-64(%rbp), %eax
	jge	.L624
.LBB125:
	.loc 2 724 15 is_stmt 0 discriminator 10
	leaq	.LC77(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L624:
.LBE125:
	.loc 2 734 7 is_stmt 1
	cmpl	$0, -60(%rbp)
	je	.L625
	.loc 2 730 18
	movl	-64(%rbp), %eax
	cmpl	-60(%rbp), %eax
	jle	.L625
	.loc 2 731 42
	cmpl	$0, -60(%rbp)
	jle	.L626
	.loc 2 731 42 is_stmt 0 discriminator 1
	cmpl	$4097, -60(%rbp)
	jle	.L627
.L626:
	.loc 2 731 42 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$731, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L627:
	.loc 2 731 49 is_stmt 1 discriminator 3
	cmpl	$0, -64(%rbp)
	jle	.L628
	.loc 2 731 49 is_stmt 0 discriminator 4
	cmpl	$4097, -64(%rbp)
	jle	.L629
.L628:
	.loc 2 731 49 discriminator 5
	leaq	.LC12(%rip), %rax
	movl	$731, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L629:
	.loc 2 731 20 is_stmt 1 discriminator 6
	movl	-64(%rbp), %ecx
	movl	-60(%rbp), %edx
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__forbidden_name@PLT
	.loc 2 731 16 discriminator 7
	xorl	$1, %eax
	.loc 2 731 7 discriminator 7
	testb	%al, %al
	je	.L625
	.loc 2 732 17
	movzbl	-65(%rbp), %eax
	xorl	$1, %eax
	.loc 2 732 7
	testb	%al, %al
	jne	.L630
	.loc 2 732 74 discriminator 1
	cmpl	$0, -60(%rbp)
	jle	.L631
	.loc 2 732 74 is_stmt 0 discriminator 2
	cmpl	$4097, -60(%rbp)
	jle	.L632
.L631:
	.loc 2 732 74 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$732, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L632:
	.loc 2 732 81 is_stmt 1 discriminator 4
	cmpl	$0, -64(%rbp)
	jle	.L633
	.loc 2 732 81 is_stmt 0 discriminator 5
	cmpl	$4097, -64(%rbp)
	jle	.L634
.L633:
	.loc 2 732 81 discriminator 6
	leaq	.LC12(%rip), %rax
	movl	$732, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L634:
	.loc 2 732 43 is_stmt 1 discriminator 7
	movl	-64(%rbp), %ecx
	movl	-60(%rbp), %edx
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__forbidden_argument_name@PLT
	.loc 2 732 39 discriminator 8
	xorl	$1, %eax
	.loc 2 732 31 discriminator 8
	testb	%al, %al
	je	.L625
.L630:
	.loc 2 733 16
	movq	-56(%rbp), %rax
	leaq	4(%rax), %rdi
	movl	-64(%rbp), %ecx
	movl	-60(%rbp), %edx
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movl	%ecx, %r8d
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__lookup_name
	.loc 2 733 62 discriminator 1
	testl	%eax, %eax
	sete	%al
	.loc 2 733 7 discriminator 1
	testb	%al, %al
	je	.L625
	.loc 2 734 34 discriminator 1
	movq	-56(%rbp), %rax
	leaq	6828(%rax), %rdi
	movl	-64(%rbp), %ecx
	movl	-60(%rbp), %edx
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movl	%ecx, %r8d
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__lookup@PLT
	.loc 2 734 83 discriminator 2
	testl	%eax, %eax
	sete	%al
	.loc 2 734 7 discriminator 2
	testb	%al, %al
	je	.L625
	.loc 2 734 7 is_stmt 0 discriminator 3
	movl	$1, %eax
	jmp	.L635
.L625:
	.loc 2 734 7 discriminator 4
	movl	$0, %eax
.L635:
.LBE120:
	.loc 2 727 4 is_stmt 1
	addq	$112, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE41:
	.size	silver_output_profile__new_name_allowed, .-silver_output_profile__new_name_allowed
	.section	.rodata
	.align 8
.LC78:
	.ascii	"failed precondition from silver_output_profile.adb:741"
	.text
	.align 2
	.globl	silver_output_profile__add_binding
	.type	silver_output_profile__add_binding, @function
silver_output_profile__add_binding:
.LFB42:
	.loc 2 742 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24648, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -24616(%rbp)
	movq	%rsi, -24624(%rbp)
	movl	%edx, -24628(%rbp)
	movl	%ecx, -24632(%rbp)
	movq	%r8, -24640(%rbp)
	movb	%r9b, -24641(%rbp)
	.loc 2 741 33
	movq	-24624(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 741 15
	cmpl	$340, %eax
	jle	.L638
.LBB126:
	.loc 2 741 15 is_stmt 0 discriminator 1
	leaq	.LC78(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L638:
.LBE126:
	.loc 2 747 46 is_stmt 1
	movq	-24624(%rbp), %rax
	movl	4(%rax), %eax
	leal	1(%rax), %ebx
	testl	%ebx, %ebx
	js	.L639
	.loc 2 747 46 is_stmt 0 discriminator 1
	cmpl	$341, %ebx
	jle	.L640
.L639:
	.loc 2 747 46 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$747, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L640:
	.loc 2 748 20 is_stmt 1
	movq	-24624(%rbp), %rdx
	leaq	-6848(%rbp), %rax
	leaq	8(%rdx), %rcx
	movl	$6820, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 748 68
	movq	-24624(%rbp), %rax
	movl	4(%rax), %eax
	testl	%eax, %eax
	js	.L641
	.loc 2 748 68 is_stmt 0 discriminator 1
	movq	-24624(%rbp), %rax
	movl	4(%rax), %eax
	cmpl	$340, %eax
	jle	.L642
.L641:
	.loc 2 748 68 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$748, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L642:
	.loc 2 748 68 discriminator 3
	movq	-24624(%rbp), %rax
	movl	4(%rax), %eax
	addl	$1, %eax
	cltq
	movq	-24640(%rbp), %rdx
	movl	4(%rdx), %r8d
	movq	-24640(%rbp), %rdx
	movl	12(%rdx), %edi
	movq	-24640(%rbp), %rdx
	movzbl	16(%rdx), %esi
	leaq	-1(%rax), %rcx
	movq	%rcx, %rdx
	salq	$2, %rdx
	addq	%rcx, %rdx
	salq	$2, %rdx
	leaq	-16(%rdx), %rcx
	leaq	(%rcx,%rbp), %rdx
	leaq	-6832(%rdx), %rcx
	movl	-24628(%rbp), %edx
	movl	%edx, (%rcx)
	.loc 2 748 68 discriminator 4
	leaq	-1(%rax), %rcx
	movq	%rcx, %rdx
	salq	$2, %rdx
	addq	%rcx, %rdx
	salq	$2, %rdx
	leaq	-16(%rdx), %rcx
	leaq	(%rcx,%rbp), %rdx
	leaq	-6828(%rdx), %rcx
	movl	-24632(%rbp), %edx
	movl	%edx, (%rcx)
	.loc 2 748 68 discriminator 5
	leaq	-1(%rax), %rcx
	movq	%rcx, %rdx
	salq	$2, %rdx
	addq	%rcx, %rdx
	salq	$2, %rdx
	leaq	-16(%rdx), %rcx
	leaq	(%rcx,%rbp), %rdx
	subq	$6824, %rdx
	movl	%r8d, (%rdx)
	.loc 2 748 68 discriminator 6
	leaq	-1(%rax), %rcx
	movq	%rcx, %rdx
	salq	$2, %rdx
	addq	%rcx, %rdx
	salq	$2, %rdx
	leaq	-16(%rdx), %rcx
	leaq	(%rcx,%rbp), %rdx
	subq	$6820, %rdx
	movl	%edi, (%rdx)
	.loc 2 748 68 discriminator 7
	movq	%rax, %rdx
	salq	$2, %rdx
	addq	%rax, %rdx
	salq	$2, %rdx
	leaq	-16(%rdx), %rdi
	leaq	(%rdi,%rbp), %rdx
	subq	$6836, %rdx
	movb	%sil, (%rdx)
	.loc 2 748 68 discriminator 8
	movq	%rax, %rdx
	salq	$2, %rdx
	addq	%rax, %rdx
	leaq	0(,%rdx,4), %rax
	movq	%rax, %rdx
	leaq	-16(%rdx), %rax
	addq	%rbp, %rax
	leaq	-6835(%rax), %rdx
	movzbl	-24641(%rbp), %eax
	movb	%al, (%rdx)
	.loc 2 746 6 is_stmt 1
	movq	-24624(%rbp), %rdx
	leaq	-24608(%rbp), %rax
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 746 24
	movl	16(%rbp), %eax
	movl	%eax, -24608(%rbp)
	.loc 2 747 9 discriminator 3
	movl	%ebx, -24604(%rbp)
	leaq	-24600(%rbp), %rax
	leaq	-6848(%rbp), %rcx
	movl	$6820, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 746 6
	movq	-24616(%rbp), %rax
	movq	%rax, %rcx
	leaq	-24608(%rbp), %rax
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 742 4
	movq	-24616(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE42:
	.size	silver_output_profile__add_binding, .-silver_output_profile__add_binding
	.align 2
	.globl	silver_output_profile__scalar_constraint_resultIP
	.type	silver_output_profile__scalar_constraint_resultIP, @function
silver_output_profile__scalar_constraint_resultIP:
.LFB43:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	.cfi_offset 3, -24
	movq	%rcx, %rax
	movq	%rbx, %rdx
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE43:
	.size	silver_output_profile__scalar_constraint_resultIP, .-silver_output_profile__scalar_constraint_resultIP
	.align 2
	.type	silver_output_profile__scalar_constraint_at___wrapped_statements.9, @function
silver_output_profile__scalar_constraint_at___wrapped_statements.9:
.LFB45:
	.loc 2 766 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$136, %rsp
	.cfi_offset 3, -24
	movq	%r10, %rbx
	movq	%r10, -120(%rbp)
	.loc 2 769 58
	movq	8(%rbx), %rax
	movl	16(%rbx), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$58, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 769 58 is_stmt 0 discriminator 1
	movl	%eax, -20(%rbp)
	.loc 2 771 27 is_stmt 1
	movq	8(%rbx), %rax
	movq	(%rbx), %rsi
	leaq	-80(%rbp), %rdi
	movl	-20(%rbp), %ecx
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	pushq	$1
	pushq	$0
	movl	$0, %r9d
	movq	%rsi, %r8
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_scalar_expressions__read_expression@PLT
	addq	$16, %rsp
	.loc 2 773 9
	movl	-80(%rbp), %edx
	movq	8(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$57, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 773 9 is_stmt 0 discriminator 1
	movl	%eax, -24(%rbp)
	.loc 2 775 27 is_stmt 1
	movq	8(%rbx), %rax
	movq	(%rbx), %rsi
	leaq	-112(%rbp), %rdi
	movl	-24(%rbp), %ecx
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	pushq	$1
	pushq	$0
	movl	$0, %r9d
	movq	%rsi, %r8
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_scalar_expressions__read_expression@PLT
	addq	$16, %rsp
	.loc 2 778 10
	cmpl	$0, -20(%rbp)
	jne	.L646
	.loc 2 778 10 is_stmt 0 discriminator 1
	movl	16(%rbx), %eax
	movl	%eax, -36(%rbp)
	movl	$-2147483648, -32(%rbp)
	movl	$2147483647, -28(%rbp)
	jmp	.L647
.L646:
	.loc 2 779 26 is_stmt 1
	movl	-80(%rbp), %eax
	.loc 2 779 10
	testl	%eax, %eax
	je	.L648
	.loc 2 779 30 discriminator 1
	cmpl	$0, -24(%rbp)
	je	.L648
	.loc 2 779 77 discriminator 2
	movl	-112(%rbp), %eax
	.loc 2 779 58 discriminator 2
	testl	%eax, %eax
	je	.L648
	.loc 2 780 12
	movzbl	-64(%rbp), %eax
	testb	%al, %al
	je	.L648
	.loc 2 780 35 discriminator 1
	movzbl	-96(%rbp), %eax
	testb	%al, %al
	je	.L648
	.loc 2 781 27
	movq	-76(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty@PLT
	.loc 2 781 27 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 781 12 is_stmt 1 discriminator 1
	testb	%al, %al
	je	.L648
	.loc 2 781 65 discriminator 2
	movq	-108(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty@PLT
	.loc 2 781 65 is_stmt 0 discriminator 3
	xorl	$1, %eax
	.loc 2 781 50 is_stmt 1 discriminator 3
	testb	%al, %al
	je	.L648
	.loc 2 782 37
	movl	-76(%rbp), %edx
	movl	-72(%rbp), %eax
	.loc 2 782 12
	cmpl	%eax, %edx
	jne	.L648
	.loc 2 783 38
	movl	-108(%rbp), %edx
	movl	-104(%rbp), %eax
	.loc 2 783 12
	cmpl	%eax, %edx
	jne	.L648
	.loc 2 784 38
	movl	-108(%rbp), %edx
	movl	-76(%rbp), %eax
	.loc 2 784 12
	cmpl	%eax, %edx
	jl	.L648
	.loc 2 778 10 discriminator 2
	movl	-112(%rbp), %eax
	movl	%eax, -36(%rbp)
	movl	-76(%rbp), %eax
	movl	%eax, -32(%rbp)
	movl	-108(%rbp), %eax
	movl	%eax, -28(%rbp)
	jmp	.L647
.L648:
	.loc 2 778 10 is_stmt 0 discriminator 3
	movl	$0, -36(%rbp)
	movl	$1, -32(%rbp)
	movl	$0, -28(%rbp)
.L647:
	.loc 2 778 10 discriminator 4
	leaq	-36(%rbp), %rax
	.loc 2 769 7 is_stmt 1 discriminator 2
	movq	(%rax), %rdx
	movq	%rdx, -48(%rbp)
	movl	8(%rax), %eax
	movl	%eax, -40(%rbp)
	.loc 2 769 7 is_stmt 0 discriminator 4
	movq	-48(%rbp), %rax
	movl	-40(%rbp), %ecx
	movq	%rcx, %rdx
	.loc 2 766 4 is_stmt 1
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE45:
	.size	silver_output_profile__scalar_constraint_at___wrapped_statements.9, .-silver_output_profile__scalar_constraint_at___wrapped_statements.9
	.section	.rodata
	.align 8
.LC79:
	.ascii	"failed precondition from silver_output_profile.adb:761"
	.align 8
.LC80:
	.ascii	"failed precondition from silver_output_profile.adb:762"
	.align 8
.LC81:
	.ascii	"failed precondition from silver_output_profile.adb:763"
	.align 8
.LC82:
	.ascii	"failed postcondition from silver_output_profile.adb:764"
	.text
	.align 2
	.globl	silver_output_profile__scalar_constraint_at
	.type	silver_output_profile__scalar_constraint_at, @function
silver_output_profile__scalar_constraint_at:
.LFB44:
	.loc 2 766 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$152, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -128(%rbp)
	movq	%rdi, -120(%rbp)
	movl	%edx, -132(%rbp)
	movq	%rcx, -144(%rbp)
	.loc 2 766 4
	leaq	16(%rbp), %rdx
	.loc 2 766 4 is_stmt 0 discriminator 1
	leaq	-128(%rbp), %rax
	movq	%rdx, -72(%rbp)
	movq	%rax, -88(%rbp)
	movl	-132(%rbp), %eax
	movl	%eax, -80(%rbp)
	movq	-144(%rbp), %rax
	movq	%rax, -96(%rbp)
	movq	-120(%rbp), %rax
	movl	(%rax), %r8d
	movq	-120(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -136(%rbp)
	movq	-120(%rbp), %rax
	movl	4(%rax), %edx
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L651
	.loc 2 766 4 discriminator 2
	movq	-120(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L652
.L651:
	.loc 2 766 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L652:
.LBB127:
	.loc 2 761 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L653
.LBB128:
	.loc 2 761 15 is_stmt 0 discriminator 1
	leaq	.LC79(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L653:
.LBE128:
	.loc 2 761 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 761 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L654
	.loc 2 761 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L655
.L654:
.LBB129:
	.loc 2 761 15 discriminator 4
	leaq	.LC79(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L655:
.LBE129:
	.loc 2 762 41
	cmpl	$2147483647, -136(%rbp)
	jne	.L656
	.loc 2 762 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$762, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L656:
	.loc 2 762 41 discriminator 3
	movl	-136(%rbp), %eax
	leal	1(%rax), %edx
	.loc 2 761 15 is_stmt 1 discriminator 5
	movl	-80(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L657
.LBB130:
	.loc 2 761 15 is_stmt 0 discriminator 6
	leaq	.LC80(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L657:
.LBE130:
	.loc 2 763 37 is_stmt 1
	movq	-96(%rbp), %rdx
	movq	-128(%rbp), %rcx
	movq	-120(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__valid_environment@PLT
	.loc 2 763 37 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 761 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L658
.LBB131:
	.loc 2 761 15 is_stmt 0 discriminator 8
	leaq	.LC81(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L658:
.LBE131:
.LBB132:
	.loc 2 766 4 is_stmt 1 discriminator 5
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__scalar_constraint_at___wrapped_statements.9
	movq	%rax, -112(%rbp)
	movl	-104(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -104(%rbp)
	.loc 2 764 50
	movl	-112(%rbp), %eax
	.loc 2 764 16
	testl	%eax, %eax
	je	.L659
	.loc 2 765 52
	movl	-112(%rbp), %eax
	.loc 2 765 10
	movl	-80(%rbp), %edx
	cmpl	%eax, %edx
	jg	.L660
	.loc 2 765 52 discriminator 1
	movl	-112(%rbp), %eax
	.loc 2 765 77 discriminator 1
	cmpl	$2147483647, -136(%rbp)
	jne	.L661
	.loc 2 765 77 is_stmt 0 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$765, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L661:
	.loc 2 765 77 discriminator 4
	movl	-136(%rbp), %edx
	addl	$1, %edx
	.loc 2 765 52 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L659
.L660:
.LBB133:
	.loc 2 764 16 discriminator 1
	leaq	.LC82(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L659:
.LBE133:
	.loc 2 766 4 discriminator 6
	movq	-112(%rbp), %rax
	movq	%rax, -60(%rbp)
	movl	-104(%rbp), %eax
	movl	%eax, -52(%rbp)
	.loc 2 766 4 is_stmt 0 discriminator 8
	movq	-60(%rbp), %rax
	movl	-52(%rbp), %ecx
	movq	%rcx, %rdx
.LBE132:
.LBE127:
	.loc 2 766 4
	addq	$152, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE44:
	.size	silver_output_profile__scalar_constraint_at, .-silver_output_profile__scalar_constraint_at
	.section	.rodata
.LC83:
	.ascii	"integer"
	.align 8
.LC5:
	.long	1
	.long	7
	.text
	.align 2
	.type	silver_output_profile__scalar_declaration_at___wrapped_statements.10, @function
silver_output_profile__scalar_declaration_at___wrapped_statements.10:
.LFB47:
	.loc 2 796 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$46576, %rsp
	.cfi_offset 14, -24
	.cfi_offset 13, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, -35672(%rbp)
	movq	%r10, %rbx
	movq	%r10, -35680(%rbp)
	.loc 2 798 52
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	movq	(%rbx), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__skip_at
	.loc 2 798 52 is_stmt 0 discriminator 1
	movl	%eax, -36(%rbp)
	.loc 2 799 44 is_stmt 1
	movq	(%rbx), %rax
	movl	-36(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__name_after
	.loc 2 799 44 is_stmt 0 discriminator 1
	movl	%eax, -40(%rbp)
	.loc 2 800 50 is_stmt 1
	movq	(%rbx), %rax
	movl	-40(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$16, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 800 50 is_stmt 0 discriminator 1
	movl	%eax, -44(%rbp)
	.loc 2 801 53 is_stmt 1
	movq	(%rbx), %rax
	movl	-44(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$17, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 801 53 is_stmt 0 discriminator 1
	movl	%eax, -48(%rbp)
	.loc 2 802 49 is_stmt 1
	cmpl	$0, -48(%rbp)
	je	.L664
	.loc 2 802 49 is_stmt 0 discriminator 1
	movl	-48(%rbp), %eax
	jmp	.L665
.L664:
	.loc 2 802 49 discriminator 2
	movl	-44(%rbp), %eax
.L665:
	.loc 2 802 49 discriminator 3
	movq	(%rbx), %rdx
	movq	(%rdx), %rsi
	movq	8(%rdx), %rcx
	movl	%eax, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver_output_profile__skip_at
	.loc 2 802 49 discriminator 4
	movl	%eax, -52(%rbp)
	.loc 2 804 49 is_stmt 1
	movq	(%rbx), %rax
	movl	-52(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$52, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 804 49 is_stmt 0 discriminator 1
	movl	%eax, -56(%rbp)
	.loc 2 806 9 is_stmt 1
	movq	8(%rbx), %rax
	leaq	6828(%rax), %rcx
	movq	(%rbx), %rax
	movl	-56(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__scalar_constraint_at
	movq	%rax, -17840(%rbp)
	movl	-17832(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -17832(%rbp)
	.loc 2 808 27
	movq	8(%rbx), %rax
	leaq	6828(%rax), %r14
	movl	-17840(%rbp), %edx
	movq	(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$19, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	movl	%eax, %ecx
	.loc 2 808 27 is_stmt 0 discriminator 1
	movq	(%rbx), %rax
	leaq	-17872(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	pushq	$1
	pushq	$0
	movl	$0, %r9d
	movq	%r14, %r8
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_scalar_expressions__read_expression@PLT
	addq	$16, %rsp
	.loc 2 810 48 is_stmt 1
	movl	-17872(%rbp), %edx
	movq	(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$13, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 810 48 is_stmt 0 discriminator 1
	movl	%eax, -60(%rbp)
	.loc 2 812 17 is_stmt 1
	movq	(%rbx), %rax
	movq	8(%rbx), %rdx
	movzbl	16(%rbx), %ecx
	movzbl	%cl, %r8d
	movl	-40(%rbp), %edi
	movl	-36(%rbp), %ecx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%r8d, %r9d
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__new_name_allowed
	.loc 2 812 13 discriminator 1
	xorl	$1, %eax
	xorl	$1, %eax
	.loc 2 812 10 discriminator 1
	testb	%al, %al
	je	.L666
	.loc 2 813 9
	cmpl	$0, -56(%rbp)
	je	.L666
	.loc 2 813 57 discriminator 1
	movl	-17840(%rbp), %eax
	.loc 2 813 32 discriminator 1
	testl	%eax, %eax
	je	.L666
	.loc 2 813 79 discriminator 2
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	.loc 2 813 61 discriminator 2
	cmpl	%eax, -60(%rbp)
	jle	.L666
	.loc 2 814 42
	movq	8(%rbx), %rax
	movl	6828(%rax), %eax
	.loc 2 814 9
	cmpl	$341, %eax
	je	.L666
	.loc 2 815 24
	movq	-17868(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty@PLT
	.loc 2 815 24 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 815 9 is_stmt 1 discriminator 1
	testb	%al, %al
	je	.L666
	.loc 2 815 76 discriminator 2
	movl	-17868(%rbp), %edx
	movl	-17864(%rbp), %eax
	.loc 2 815 49 discriminator 2
	cmpl	%eax, %edx
	jne	.L666
	.loc 2 816 36
	movl	-17868(%rbp), %edx
	movl	-17836(%rbp), %eax
	.loc 2 816 9
	cmpl	%eax, %edx
	jl	.L666
	.loc 2 817 41
	movl	-17832(%rbp), %edx
	movl	-17864(%rbp), %eax
	.loc 2 817 9
	cmpl	%eax, %edx
	jl	.L666
	.loc 2 818 32
	cmpl	$0, -36(%rbp)
	jle	.L667
	.loc 2 818 32 is_stmt 0 discriminator 1
	cmpl	$4097, -36(%rbp)
	jle	.L668
.L667:
	.loc 2 818 32 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$818, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L668:
	.loc 2 818 39 is_stmt 1 discriminator 3
	cmpl	$0, -40(%rbp)
	jle	.L669
	.loc 2 818 39 is_stmt 0 discriminator 4
	cmpl	$4097, -40(%rbp)
	jle	.L670
.L669:
	.loc 2 818 39 discriminator 5
	leaq	.LC12(%rip), %rax
	movl	$818, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L670:
	.loc 2 818 17 is_stmt 1 discriminator 6
	leaq	.LC83(%rip), %r12
	leaq	.LC5(%rip), %r13
	movq	(%rbx), %rax
	movl	-40(%rbp), %ecx
	movl	-36(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%r12, %r8
	movq	%r13, %r9
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__name_is@PLT
	.loc 2 818 17 is_stmt 0 discriminator 7
	xorl	$1, %eax
	.loc 2 818 9 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L666
	.loc 2 819 17
	movq	8(%rbx), %rax
	leaq	4(%rax), %rdi
	movq	(%rbx), %rax
	movl	-56(%rbp), %ecx
	movl	-52(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%ecx, %r8d
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__lookup_name
	.loc 2 819 73 discriminator 1
	testl	%eax, %eax
	setne	%al
	xorl	$1, %eax
	.loc 2 819 9 discriminator 1
	testb	%al, %al
	je	.L666
	.loc 2 820 35
	movq	8(%rbx), %rax
	leaq	6828(%rax), %rdi
	movq	(%rbx), %rax
	movl	-56(%rbp), %ecx
	movl	-52(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%ecx, %r8d
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__lookup@PLT
	.loc 2 820 94 discriminator 1
	testl	%eax, %eax
	setne	%al
	xorl	$1, %eax
	.loc 2 820 9 discriminator 1
	testb	%al, %al
	je	.L666
	.loc 2 822 15
	movq	8(%rbx), %rdx
	leaq	-35632(%rbp), %rax
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 822 33
	movl	-60(%rbp), %eax
	movl	%eax, -35632(%rbp)
.LBB134:
	.loc 2 825 12
	movl	-36(%rbp), %eax
	movl	%eax, -35664(%rbp)
	movl	-40(%rbp), %eax
	movl	%eax, -35660(%rbp)
	movq	-17868(%rbp), %rax
	movq	%rax, -35656(%rbp)
	.loc 2 825 61
	cmpl	$0, -48(%rbp)
	je	.L671
	.loc 2 825 61 is_stmt 0 discriminator 1
	movzbl	-17856(%rbp), %eax
	testb	%al, %al
	je	.L671
	.loc 2 825 61 discriminator 2
	movl	$1, %eax
	jmp	.L672
.L671:
	.loc 2 825 61 discriminator 3
	movl	$0, %eax
.L672:
	.loc 2 825 12 is_stmt 1 discriminator 4
	movb	%al, -35648(%rbp)
	movq	-17836(%rbp), %rax
	movq	%rax, -35644(%rbp)
	.loc 2 826 47
	cmpl	$0, -48(%rbp)
	sete	%al
	.loc 2 825 12 discriminator 4
	movb	%al, -35636(%rbp)
	.loc 2 823 43
	movq	8(%rbx), %rax
	leaq	6828(%rax), %rcx
	leaq	-46608(%rbp), %rax
	leaq	-35664(%rbp), %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	silver_scalar_expressions__append@PLT
	leaq	-28804(%rbp), %rax
	leaq	-46608(%rbp), %rcx
	movl	$10916, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
.LBE134:
	.loc 2 812 10 discriminator 2
	leaq	-17824(%rbp), %rax
	leaq	-35632(%rbp), %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	jmp	.L673
.L666:
	.loc 2 812 10 is_stmt 0 discriminator 3
	leaq	-17824(%rbp), %rax
	leaq	silver_output_profile__invalid_state(%rip), %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
.L673:
	.loc 2 812 10 discriminator 4
	leaq	-17824(%rbp), %rax
	.loc 2 798 7 is_stmt 1 discriminator 2
	movq	-35672(%rbp), %rdx
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 796 4
	movq	-35672(%rbp), %rax
	leaq	-32(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE47:
	.size	silver_output_profile__scalar_declaration_at___wrapped_statements.10, .-silver_output_profile__scalar_declaration_at___wrapped_statements.10
	.section	.rodata
	.align 8
.LC84:
	.ascii	"failed precondition from silver_output_profile.adb:791"
	.align 8
.LC85:
	.ascii	"failed precondition from silver_output_profile.adb:792"
	.align 8
.LC86:
	.ascii	"failed postcondition from silver_output_profile.adb:793"
	.align 8
.LC87:
	.ascii	"failed postcondition from silver_output_profile.adb:794"
	.text
	.align 2
	.globl	silver_output_profile__scalar_declaration_at
	.type	silver_output_profile__scalar_declaration_at, @function
silver_output_profile__scalar_declaration_at:
.LFB46:
	.loc 2 796 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	subq	$17872, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	movq	%rdi, -17832(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -17856(%rbp)
	movq	%rdx, -17848(%rbp)
	movq	%rcx, -17840(%rbp)
	movb	%r8b, -17857(%rbp)
	.loc 2 796 4
	leaq	16(%rbp), %rdx
	.loc 2 796 4 is_stmt 0 discriminator 1
	leaq	-17856(%rbp), %rax
	movq	%rdx, -40(%rbp)
	movq	%rax, -64(%rbp)
	movq	-17840(%rbp), %rax
	movq	%rax, -56(%rbp)
	movzbl	-17857(%rbp), %eax
	movb	%al, -48(%rbp)
	movq	-17848(%rbp), %rax
	movl	(%rax), %r8d
	movq	-17848(%rbp), %rax
	movl	4(%rax), %edx
	movq	-17848(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L676
	.loc 2 796 4 discriminator 2
	movq	-17848(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-17848(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movq	%rcx, %rsi
	movq	%rcx, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L677
.L676:
	.loc 2 796 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L677:
.LBB135:
	.loc 2 791 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L678
.LBB136:
	.loc 2 791 15 is_stmt 0 discriminator 1
	leaq	.LC84(%rip), %rax
	movq	%rax, -17904(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -17896(%rbp)
	movq	-17904(%rbp), %rsi
	movq	-17896(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L678:
.LBE136:
	.loc 2 791 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 791 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L679
	.loc 2 791 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L680
.L679:
.LBB137:
	.loc 2 791 15 discriminator 4
	leaq	.LC84(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L680:
.LBE137:
	.loc 2 792 19
	movq	-56(%rbp), %rdx
	movq	-17856(%rbp), %rcx
	movq	-17848(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 792 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 791 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L681
.LBB138:
	.loc 2 791 15 is_stmt 0 discriminator 6
	leaq	.LC85(%rip), %rax
	movq	%rax, -17888(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -17880(%rbp)
	movq	-17888(%rbp), %rsi
	movq	-17880(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L681:
.LBE138:
.LBB139:
	.loc 2 796 4 is_stmt 1 discriminator 5
	leaq	-17824(%rbp), %rax
	leaq	-64(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_output_profile__scalar_declaration_at___wrapped_statements.10
.LBB140:
	.loc 2 793 16
	leaq	-17824(%rbp), %rdx
	movq	-17856(%rbp), %rcx
	movq	-17848(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 793 16 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L682
.LBB141:
	.loc 2 793 16 discriminator 2
	leaq	.LC86(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L682:
.LBE141:
	.loc 2 794 58 is_stmt 1
	movl	-17824(%rbp), %eax
	.loc 2 793 16 discriminator 3
	testl	%eax, %eax
	je	.L683
	.loc 2 795 58
	movl	-17824(%rbp), %edx
	movq	-56(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 795 12
	cmpl	%eax, %edx
	jg	.L683
.LBB142:
	.loc 2 793 16 discriminator 4
	leaq	.LC87(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L683:
.LBE142:
.LBE140:
	.loc 2 796 4 discriminator 6
	movq	-17832(%rbp), %rax
	movq	%rax, %rcx
	leaq	-17824(%rbp), %rax
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE139:
.LBE135:
	.loc 2 796 4 is_stmt 0
	movq	-17832(%rbp), %rax
	addq	$17872, %rsp
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE46:
	.size	silver_output_profile__scalar_declaration_at, .-silver_output_profile__scalar_declaration_at
	.align 2
	.type	silver_output_profile__string_declaration_at___wrapped_statements.11, @function
silver_output_profile__string_declaration_at___wrapped_statements.11:
.LFB49:
	.loc 2 836 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$35632, %rsp
	.cfi_offset 14, -24
	.cfi_offset 13, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, -35656(%rbp)
	movq	%r10, %rbx
	movq	%r10, -35664(%rbp)
	.loc 2 838 52
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	movq	(%rbx), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__skip_at
	.loc 2 838 52 is_stmt 0 discriminator 1
	movl	%eax, -36(%rbp)
	.loc 2 839 52 is_stmt 1
	movq	(%rbx), %rax
	movl	-36(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__name_after
	.loc 2 839 52 is_stmt 0 discriminator 1
	movl	%eax, -40(%rbp)
	.loc 2 840 58 is_stmt 1
	movq	(%rbx), %rax
	movl	-40(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$16, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 840 58 is_stmt 0 discriminator 1
	movl	%eax, -44(%rbp)
	.loc 2 841 61 is_stmt 1
	movq	(%rbx), %rax
	movl	-44(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$17, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 841 61 is_stmt 0 discriminator 1
	movl	%eax, -48(%rbp)
	.loc 2 842 57 is_stmt 1
	cmpl	$0, -48(%rbp)
	je	.L686
	.loc 2 842 57 is_stmt 0 discriminator 1
	movl	-48(%rbp), %eax
	jmp	.L687
.L686:
	.loc 2 842 57 discriminator 2
	movl	-44(%rbp), %eax
.L687:
	.loc 2 842 57 discriminator 3
	movq	(%rbx), %rdx
	movq	(%rdx), %rdi
	movq	8(%rdx), %rsi
	movl	$18, %ecx
	movl	%eax, %edx
	call	silver_output_profile__take_token
	.loc 2 842 57 discriminator 4
	movl	%eax, -52(%rbp)
	.loc 2 844 53 is_stmt 1
	cmpl	$0, -36(%rbp)
	je	.L688
	.loc 2 846 29
	movl	-40(%rbp), %eax
	cmpl	-36(%rbp), %eax
	jle	.L688
	.loc 2 847 29
	movq	(%rbx), %rax
	movl	-36(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$52, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 847 68 discriminator 1
	cmpl	%eax, -40(%rbp)
	sete	%al
	.loc 2 844 53 discriminator 1
	testb	%al, %al
	je	.L688
	.loc 2 844 53 is_stmt 0 discriminator 2
	movl	$1, %r14d
	jmp	.L689
.L688:
	.loc 2 844 53 discriminator 3
	movl	$0, %r14d
.L689:
	.loc 2 844 53 discriminator 4
	movq	8(%rbx), %rax
	leaq	6828(%rax), %r13
	movq	8(%rbx), %rax
	leaq	4(%rax), %r12
	movq	(%rbx), %rax
	movl	-52(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$19, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	movl	%eax, %esi
	.loc 2 844 53 discriminator 5
	movq	(%rbx), %rax
	leaq	-17856(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	subq	$8, %rsp
	movzbl	%r14b, %ecx
	pushq	%rcx
	movq	%r13, %r9
	movq	%r12, %r8
	movl	%esi, %ecx
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__expression_at
	addq	$16, %rsp
	.loc 2 848 56 is_stmt 1
	movl	-17856(%rbp), %edx
	movq	(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$13, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 848 56 is_stmt 0 discriminator 1
	movl	%eax, -56(%rbp)
	.loc 2 850 17 is_stmt 1
	movq	(%rbx), %rax
	movq	8(%rbx), %rdx
	movzbl	16(%rbx), %ecx
	movzbl	%cl, %r8d
	movl	-40(%rbp), %edi
	movl	-36(%rbp), %ecx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%r8d, %r9d
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__new_name_allowed
	.loc 2 850 13 discriminator 1
	xorl	$1, %eax
	xorl	$1, %eax
	.loc 2 850 10 discriminator 1
	testb	%al, %al
	je	.L690
	.loc 2 851 12
	cmpl	$0, -56(%rbp)
	je	.L690
	.loc 2 851 60 discriminator 1
	movq	8(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 851 34 discriminator 1
	cmpl	$341, %eax
	je	.L690
	.loc 2 852 24
	leaq	-17856(%rbp), %rax
	movl	$4096, %esi
	movq	%rax, %rdi
	call	silver_output_profile__fits
	.loc 2 852 20 discriminator 1
	xorl	$1, %eax
	xorl	$1, %eax
	.loc 2 852 12 discriminator 1
	testb	%al, %al
	je	.L690
	.loc 2 853 12
	movzbl	-17839(%rbp), %eax
	xorl	$1, %eax
	testb	%al, %al
	je	.L690
	.loc 2 853 67 discriminator 1
	movl	-17852(%rbp), %edx
	movl	-17848(%rbp), %eax
	.loc 2 853 38 discriminator 1
	cmpl	%eax, %edx
	jne	.L690
.LBB143:
	.loc 2 855 15
	cmpl	$0, -48(%rbp)
	sete	%dl
	.loc 2 856 12
	movl	-17856(%rbp), %eax
	movl	%eax, -35648(%rbp)
	movl	$0, -35644(%rbp)
	movl	-17852(%rbp), %eax
	movl	%eax, -35640(%rbp)
	movl	-17848(%rbp), %eax
	movl	%eax, -35636(%rbp)
	.loc 2 857 87
	movl	-17844(%rbp), %eax
	cmpl	$1, %eax
	sete	%al
	.loc 2 856 12
	movb	%al, -35632(%rbp)
	movzbl	-17840(%rbp), %eax
	movb	%al, -35631(%rbp)
	movzbl	-17839(%rbp), %eax
	movb	%al, -35630(%rbp)
	movl	$0, -35628(%rbp)
	.loc 2 855 15
	movq	8(%rbx), %rsi
	leaq	-35616(%rbp), %rax
	movzbl	%dl, %r9d
	leaq	-35648(%rbp), %r8
	movl	-40(%rbp), %ecx
	movl	-36(%rbp), %edx
	subq	$8, %rsp
	movl	-56(%rbp), %edi
	pushq	%rdi
	movq	%rax, %rdi
	call	silver_output_profile__add_binding
	addq	$16, %rsp
.LBE143:
	.loc 2 855 15 is_stmt 0 discriminator 1
	leaq	-35616(%rbp), %rdx
	.loc 2 850 10 is_stmt 1 discriminator 2
	leaq	-17824(%rbp), %rax
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 850 10 is_stmt 0 discriminator 3
	jmp	.L691
.L690:
	.loc 2 850 10 discriminator 4
	leaq	-17824(%rbp), %rax
	leaq	silver_output_profile__invalid_state(%rip), %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
.L691:
	.loc 2 850 10 discriminator 5
	leaq	-17824(%rbp), %rax
	.loc 2 838 7 is_stmt 1 discriminator 2
	movq	-35656(%rbp), %rdx
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 836 4
	movq	-35656(%rbp), %rax
	leaq	-32(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE49:
	.size	silver_output_profile__string_declaration_at___wrapped_statements.11, .-silver_output_profile__string_declaration_at___wrapped_statements.11
	.section	.rodata
	.align 8
.LC88:
	.ascii	"failed precondition from silver_output_profile.adb:831"
	.align 8
.LC89:
	.ascii	"failed precondition from silver_output_profile.adb:832"
	.align 8
.LC90:
	.ascii	"failed postcondition from silver_output_profile.adb:833"
	.align 8
.LC91:
	.ascii	"failed postcondition from silver_output_profile.adb:834"
	.text
	.align 2
	.globl	silver_output_profile__string_declaration_at
	.type	silver_output_profile__string_declaration_at, @function
silver_output_profile__string_declaration_at:
.LFB48:
	.loc 2 836 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	subq	$17872, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	movq	%rdi, -17832(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -17856(%rbp)
	movq	%rdx, -17848(%rbp)
	movq	%rcx, -17840(%rbp)
	movb	%r8b, -17857(%rbp)
	.loc 2 836 4
	leaq	16(%rbp), %rdx
	.loc 2 836 4 is_stmt 0 discriminator 1
	leaq	-17856(%rbp), %rax
	movq	%rdx, -40(%rbp)
	movq	%rax, -64(%rbp)
	movq	-17840(%rbp), %rax
	movq	%rax, -56(%rbp)
	movzbl	-17857(%rbp), %eax
	movb	%al, -48(%rbp)
	movq	-17848(%rbp), %rax
	movl	(%rax), %r8d
	movq	-17848(%rbp), %rax
	movl	4(%rax), %edx
	movq	-17848(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L694
	.loc 2 836 4 discriminator 2
	movq	-17848(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-17848(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movq	%rcx, %rsi
	movq	%rcx, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L695
.L694:
	.loc 2 836 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L695:
.LBB144:
	.loc 2 831 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L696
.LBB145:
	.loc 2 831 15 is_stmt 0 discriminator 1
	leaq	.LC88(%rip), %rax
	movq	%rax, -17904(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -17896(%rbp)
	movq	-17904(%rbp), %rsi
	movq	-17896(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L696:
.LBE145:
	.loc 2 831 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 831 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L697
	.loc 2 831 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L698
.L697:
.LBB146:
	.loc 2 831 15 discriminator 4
	leaq	.LC88(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L698:
.LBE146:
	.loc 2 832 19
	movq	-56(%rbp), %rdx
	movq	-17856(%rbp), %rcx
	movq	-17848(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 832 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 831 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L699
.LBB147:
	.loc 2 831 15 is_stmt 0 discriminator 6
	leaq	.LC89(%rip), %rax
	movq	%rax, -17888(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -17880(%rbp)
	movq	-17888(%rbp), %rsi
	movq	-17880(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L699:
.LBE147:
.LBB148:
	.loc 2 836 4 is_stmt 1 discriminator 5
	leaq	-17824(%rbp), %rax
	leaq	-64(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_output_profile__string_declaration_at___wrapped_statements.11
.LBB149:
	.loc 2 833 16
	leaq	-17824(%rbp), %rdx
	movq	-17856(%rbp), %rcx
	movq	-17848(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 833 16 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L700
.LBB150:
	.loc 2 833 16 discriminator 2
	leaq	.LC90(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L700:
.LBE150:
	.loc 2 834 58 is_stmt 1
	movl	-17824(%rbp), %eax
	.loc 2 833 16 discriminator 3
	testl	%eax, %eax
	je	.L701
	.loc 2 835 58
	movl	-17824(%rbp), %edx
	movq	-56(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 835 12
	cmpl	%eax, %edx
	jg	.L701
.LBB151:
	.loc 2 833 16 discriminator 4
	leaq	.LC91(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L701:
.LBE151:
.LBE149:
	.loc 2 836 4 discriminator 6
	movq	-17832(%rbp), %rax
	movq	%rax, %rcx
	leaq	-17824(%rbp), %rax
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE148:
.LBE144:
	.loc 2 836 4 is_stmt 0
	movq	-17832(%rbp), %rax
	addq	$17872, %rsp
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE48:
	.size	silver_output_profile__string_declaration_at, .-silver_output_profile__string_declaration_at
	.align 2
	.type	silver_output_profile__declaration_at___wrapped_statements.12, @function
silver_output_profile__declaration_at___wrapped_statements.12:
.LFB51:
	.loc 2 870 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$53304, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -53304(%rbp)
	movq	%r10, %rbx
	movq	%r10, -53312(%rbp)
	.loc 2 872 55
	movq	8(%rbx), %rax
	movq	(%rbx), %rcx
	movzbl	16(%rbx), %edx
	leaq	-35536(%rbp), %rdi
	movzbl	%dl, %esi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movl	%esi, %r8d
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__scalar_declaration_at
	.loc 2 873 39
	movl	-35536(%rbp), %eax
	.loc 2 873 14
	testl	%eax, %eax
	jne	.L704
	.loc 2 874 19
	movq	8(%rbx), %rax
	movq	(%rbx), %rcx
	movzbl	16(%rbx), %edx
	leaq	-53296(%rbp), %rdi
	movzbl	%dl, %esi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movl	%esi, %r8d
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__string_declaration_at
	.loc 2 874 19 is_stmt 0 discriminator 1
	leaq	-53296(%rbp), %rdx
	.loc 2 873 14 is_stmt 1 discriminator 1
	leaq	-17776(%rbp), %rax
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	jmp	.L705
.L704:
	.loc 2 873 14 is_stmt 0 discriminator 2
	leaq	-17776(%rbp), %rax
	leaq	-35536(%rbp), %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
.L705:
	.loc 2 873 14 discriminator 3
	leaq	-17776(%rbp), %rax
	.loc 2 872 7 is_stmt 1 discriminator 1
	movq	-53304(%rbp), %rdx
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 870 4
	movq	-53304(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE51:
	.size	silver_output_profile__declaration_at___wrapped_statements.12, .-silver_output_profile__declaration_at___wrapped_statements.12
	.section	.rodata
	.align 8
.LC92:
	.ascii	"failed precondition from silver_output_profile.adb:865"
	.align 8
.LC93:
	.ascii	"failed precondition from silver_output_profile.adb:866"
	.align 8
.LC94:
	.ascii	"failed postcondition from silver_output_profile.adb:867"
	.align 8
.LC95:
	.ascii	"failed postcondition from silver_output_profile.adb:868"
	.text
	.align 2
	.globl	silver_output_profile__declaration_at
	.type	silver_output_profile__declaration_at, @function
silver_output_profile__declaration_at:
.LFB50:
	.loc 2 870 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	subq	$17872, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	movq	%rdi, -17832(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -17856(%rbp)
	movq	%rdx, -17848(%rbp)
	movq	%rcx, -17840(%rbp)
	movb	%r8b, -17857(%rbp)
	.loc 2 870 4
	leaq	16(%rbp), %rdx
	.loc 2 870 4 is_stmt 0 discriminator 1
	leaq	-17856(%rbp), %rax
	movq	%rdx, -40(%rbp)
	movq	%rax, -56(%rbp)
	movq	-17840(%rbp), %rax
	movq	%rax, -64(%rbp)
	movzbl	-17857(%rbp), %eax
	movb	%al, -48(%rbp)
	movq	-17848(%rbp), %rax
	movl	(%rax), %r8d
	movq	-17848(%rbp), %rax
	movl	4(%rax), %edx
	movq	-17848(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L708
	.loc 2 870 4 discriminator 2
	movq	-17848(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-17848(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movq	%rcx, %rsi
	movq	%rcx, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L709
.L708:
	.loc 2 870 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L709:
.LBB152:
	.loc 2 865 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L710
.LBB153:
	.loc 2 865 15 is_stmt 0 discriminator 1
	leaq	.LC92(%rip), %rax
	movq	%rax, -17904(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -17896(%rbp)
	movq	-17904(%rbp), %rsi
	movq	-17896(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L710:
.LBE153:
	.loc 2 865 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 865 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L711
	.loc 2 865 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L712
.L711:
.LBB154:
	.loc 2 865 15 discriminator 4
	leaq	.LC92(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L712:
.LBE154:
	.loc 2 866 19
	movq	-64(%rbp), %rdx
	movq	-17856(%rbp), %rcx
	movq	-17848(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 866 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 865 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L713
.LBB155:
	.loc 2 865 15 is_stmt 0 discriminator 6
	leaq	.LC93(%rip), %rax
	movq	%rax, -17888(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -17880(%rbp)
	movq	-17888(%rbp), %rsi
	movq	-17880(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L713:
.LBE155:
.LBB156:
	.loc 2 870 4 is_stmt 1 discriminator 5
	leaq	-17824(%rbp), %rax
	leaq	-64(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_output_profile__declaration_at___wrapped_statements.12
.LBB157:
	.loc 2 867 16
	leaq	-17824(%rbp), %rdx
	movq	-17856(%rbp), %rcx
	movq	-17848(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 867 16 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L714
.LBB158:
	.loc 2 867 16 discriminator 2
	leaq	.LC94(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L714:
.LBE158:
	.loc 2 868 51 is_stmt 1
	movl	-17824(%rbp), %eax
	.loc 2 867 16 discriminator 3
	testl	%eax, %eax
	je	.L715
	.loc 2 869 51
	movl	-17824(%rbp), %edx
	movq	-64(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 869 12
	cmpl	%eax, %edx
	jg	.L715
.LBB159:
	.loc 2 867 16 discriminator 4
	leaq	.LC95(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L715:
.LBE159:
.LBE157:
	.loc 2 870 4 discriminator 6
	movq	-17832(%rbp), %rax
	movq	%rax, %rcx
	leaq	-17824(%rbp), %rax
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE156:
.LBE152:
	.loc 2 870 4 is_stmt 0
	movq	-17832(%rbp), %rax
	addq	$17872, %rsp
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE50:
	.size	silver_output_profile__declaration_at, .-silver_output_profile__declaration_at
	.align 2
	.type	silver_output_profile__argument_at___wrapped_statements.13, @function
silver_output_profile__argument_at___wrapped_statements.13:
.LFB53:
	.loc 2 881 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$35640, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -35640(%rbp)
	movq	%r10, %rbx
	movq	%r10, -35648(%rbp)
	.loc 2 882 52
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	movq	(%rbx), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__skip_at
	.loc 2 882 52 is_stmt 0 discriminator 1
	movl	%eax, -20(%rbp)
	.loc 2 883 52 is_stmt 1
	movq	(%rbx), %rax
	movl	-20(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__name_after
	.loc 2 883 52 is_stmt 0 discriminator 1
	movl	%eax, -24(%rbp)
	.loc 2 884 52 is_stmt 1
	movq	(%rbx), %rax
	movl	-24(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$16, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	movl	%eax, %edx
	.loc 2 884 52 is_stmt 0 discriminator 1
	movq	(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$17, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	movl	%eax, %edx
	.loc 2 884 52 discriminator 2
	movq	(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$18, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	movl	%eax, %edx
	.loc 2 884 52 discriminator 3
	movq	(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$19, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 884 52 discriminator 4
	movl	%eax, -28(%rbp)
	.loc 2 888 17 is_stmt 1
	cmpl	$0, -20(%rbp)
	je	.L718
	.loc 2 887 55
	movl	-24(%rbp), %eax
	cmpl	-20(%rbp), %eax
	jle	.L718
	.loc 2 888 26 discriminator 1
	movq	(%rbx), %rax
	movl	-20(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$21, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 888 74 discriminator 2
	cmpl	%eax, -24(%rbp)
	sete	%al
	.loc 2 888 17 discriminator 2
	testb	%al, %al
	je	.L718
	.loc 2 888 17 is_stmt 0 discriminator 3
	movl	$1, %eax
	jmp	.L719
.L718:
	.loc 2 888 17 discriminator 4
	movl	$0, %eax
.L719:
	.loc 2 887 15 is_stmt 1 discriminator 1
	movb	%al, -29(%rbp)
	.loc 2 889 58
	movq	(%rbx), %rax
	movzbl	-29(%rbp), %ecx
	movl	-28(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%ecx, %r8d
	movl	$2, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_names__operation_after@PLT
	movl	%eax, %edx
	.loc 2 889 58 is_stmt 0 discriminator 1
	movq	(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$11, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	movl	%eax, %edx
	.loc 2 889 58 discriminator 2
	movq	(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$1, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_names__association_after@PLT
	.loc 2 889 58 discriminator 3
	movl	%eax, -36(%rbp)
	.loc 2 892 56 is_stmt 1
	movq	(%rbx), %rax
	movl	-36(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__skip_at
	movl	%eax, %ecx
	.loc 2 892 56 is_stmt 0 discriminator 1
	movq	(%rbx), %rax
	leaq	-17840(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__literal_at
	.loc 2 893 56 is_stmt 1
	movl	-17840(%rbp), %edx
	movq	(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$12, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	movl	%eax, %edx
	.loc 2 893 56 is_stmt 0 discriminator 1
	movq	(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$13, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 893 56 discriminator 2
	movl	%eax, -40(%rbp)
	.loc 2 896 17 is_stmt 1
	movq	(%rbx), %rax
	movq	8(%rbx), %rdx
	movl	-24(%rbp), %edi
	movl	-20(%rbp), %ecx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$1, %r9d
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__new_name_allowed
	.loc 2 896 13 discriminator 1
	xorl	$1, %eax
	xorl	$1, %eax
	.loc 2 896 10 discriminator 1
	testb	%al, %al
	je	.L720
	.loc 2 897 12
	cmpl	$0, -40(%rbp)
	je	.L720
	.loc 2 897 60 discriminator 1
	movq	8(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 897 34 discriminator 1
	testl	%eax, %eax
	jne	.L720
	.loc 2 900 12
	movl	-40(%rbp), %eax
	movl	%eax, -17872(%rbp)
	movl	$0, -17868(%rbp)
	movl	$0, -17864(%rbp)
	movl	$0, -17860(%rbp)
	movb	$1, -17856(%rbp)
	movb	$1, -17855(%rbp)
	movb	$0, -17854(%rbp)
	movl	$0, -17852(%rbp)
	.loc 2 899 16
	movq	8(%rbx), %rsi
	leaq	-35632(%rbp), %rax
	leaq	-17872(%rbp), %r8
	movl	-24(%rbp), %ecx
	movl	-20(%rbp), %edx
	subq	$8, %rsp
	movl	-40(%rbp), %edi
	pushq	%rdi
	movl	$0, %r9d
	movq	%rax, %rdi
	call	silver_output_profile__add_binding
	addq	$16, %rsp
	.loc 2 902 23
	movl	-20(%rbp), %eax
	movl	%eax, -17888(%rbp)
	.loc 2 902 47
	movl	-24(%rbp), %eax
	movl	%eax, -17884(%rbp)
	.loc 2 896 10 discriminator 2
	leaq	-17808(%rbp), %rax
	leaq	-35632(%rbp), %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	jmp	.L721
.L720:
	.loc 2 896 10 is_stmt 0 discriminator 3
	leaq	-17808(%rbp), %rax
	leaq	silver_output_profile__invalid_state(%rip), %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
.L721:
	.loc 2 896 10 discriminator 4
	leaq	-17808(%rbp), %rax
	.loc 2 882 7 is_stmt 1 discriminator 2
	movq	-35640(%rbp), %rdx
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 881 4
	movq	-35640(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE53:
	.size	silver_output_profile__argument_at___wrapped_statements.13, .-silver_output_profile__argument_at___wrapped_statements.13
	.section	.rodata
	.align 8
.LC96:
	.ascii	"failed precondition from silver_output_profile.adb:878"
	.align 8
.LC97:
	.ascii	"failed precondition from silver_output_profile.adb:879"
	.align 8
.LC98:
	.ascii	"failed postcondition from silver_output_profile.adb:880"
	.text
	.align 2
	.globl	silver_output_profile__argument_at
	.type	silver_output_profile__argument_at, @function
silver_output_profile__argument_at:
.LFB52:
	.loc 2 881 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$17832, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -17848(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -17872(%rbp)
	movq	%rdx, -17864(%rbp)
	movq	%rcx, -17856(%rbp)
	.loc 2 881 4
	leaq	16(%rbp), %rdx
	.loc 2 881 4 is_stmt 0 discriminator 1
	leaq	-17872(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -80(%rbp)
	movq	-17856(%rbp), %rax
	movq	%rax, -72(%rbp)
	movq	-17864(%rbp), %rax
	movl	(%rax), %esi
	movq	-17864(%rbp), %rax
	movl	4(%rax), %edx
	movq	-17864(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L724
	.loc 2 881 4 discriminator 2
	movq	-17864(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-17864(%rbp), %rcx
	movl	(%rcx), %edi
	movslq	%edi, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L725
.L724:
	.loc 2 881 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L725:
.LBB160:
	.loc 2 878 15 is_stmt 1
	cmpl	$1, %esi
	je	.L726
.LBB161:
	.loc 2 878 15 is_stmt 0 discriminator 1
	leaq	.LC96(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L726:
.LBE161:
	.loc 2 878 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 878 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L727
	.loc 2 878 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L728
.L727:
.LBB162:
	.loc 2 878 15 discriminator 4
	leaq	.LC96(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L728:
.LBE162:
	.loc 2 879 19
	movq	-72(%rbp), %rdx
	movq	-17872(%rbp), %rcx
	movq	-17864(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 879 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 878 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L729
.LBB163:
	.loc 2 878 15 is_stmt 0 discriminator 6
	leaq	.LC97(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L729:
.LBE163:
.LBB164:
	.loc 2 881 4 is_stmt 1 discriminator 5
	leaq	-17840(%rbp), %rax
	leaq	-80(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_output_profile__argument_at___wrapped_statements.13
	.loc 2 880 16
	leaq	-17840(%rbp), %rdx
	movq	-17872(%rbp), %rcx
	movq	-17864(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 880 16 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L730
.LBB165:
	.loc 2 880 16 discriminator 2
	leaq	.LC98(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L730:
.LBE165:
	.loc 2 881 4 is_stmt 1 discriminator 6
	movq	-17848(%rbp), %rax
	movq	%rax, %rcx
	leaq	-17840(%rbp), %rax
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE164:
.LBE160:
	.loc 2 881 4 is_stmt 0
	movq	-17848(%rbp), %rax
	addq	$17832, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE52:
	.size	silver_output_profile__argument_at, .-silver_output_profile__argument_at
	.section	.rodata
	.align 8
.LC99:
	.ascii	"failed precondition from silver_output_profile.adb:921"
	.align 8
.LC100:
	.ascii	"failed precondition from silver_output_profile.adb:922"
	.align 8
.LC101:
	.ascii	"Loop_Invariant failed at silver_output_profile.adb:930"
	.align 8
.LC102:
	.ascii	"Loop_Variant failed at silver_output_profile.adb:933"
	.text
	.align 2
	.globl	silver_output_profile__read_declarations
	.type	silver_output_profile__read_declarations, @function
silver_output_profile__read_declarations:
.LFB54:
	.loc 2 925 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$35624, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -17816(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -17840(%rbp)
	movq	%rdx, -17832(%rbp)
	movq	%rcx, -17824(%rbp)
	movb	%r8b, -17841(%rbp)
	.loc 2 925 4
	movq	-17832(%rbp), %rax
	movl	(%rax), %r8d
	movq	-17832(%rbp), %rax
	movl	4(%rax), %r9d
	cmpl	%r8d, %r9d
	jl	.L733
	.loc 2 925 4 is_stmt 0 discriminator 1
	movslq	%r9d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r8d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L734
.L733:
	.loc 2 925 4 discriminator 2
	movl	$0, %ecx
	movl	$0, %ebx
.L734:
.LBB166:
	.loc 2 925 4 discriminator 3
	cmpl	%r8d, %r9d
	.loc 2 925 4 discriminator 6
	cmpl	%r8d, %r9d
	.loc 2 925 4 discriminator 9
	cmpl	%r8d, %r9d
	.loc 2 921 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L741
.LBB167:
	.loc 2 921 15 is_stmt 0 discriminator 1
	leaq	.LC99(%rip), %rax
	movq	%rax, -35648(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -35640(%rbp)
	movq	-35648(%rbp), %rbx
	movq	-35640(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L741:
.LBE167:
	.loc 2 921 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 921 15 discriminator 2
	testl	%eax, %eax
	jle	.L742
	.loc 2 921 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L743
.L742:
.LBB168:
	.loc 2 921 15 discriminator 4
	leaq	.LC99(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L743:
.LBE168:
	.loc 2 922 19
	movq	-17824(%rbp), %rdx
	movq	-17840(%rbp), %rcx
	movq	-17832(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 922 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 921 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L744
.LBB169:
	.loc 2 921 15 is_stmt 0 discriminator 6
	leaq	.LC100(%rip), %rax
	movq	%rax, -35632(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -35624(%rbp)
	movq	-35632(%rbp), %rbx
	movq	-35624(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L744:
.LBE169:
	.loc 2 927 7 is_stmt 1
	movq	-17824(%rbp), %rdx
	leaq	-17808(%rbp), %rax
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 929 34
	movl	$0, %ebx
.L752:
	.loc 2 929 29 discriminator 1
	movl	-17808(%rbp), %eax
	testl	%eax, %eax
	je	.L745
	.loc 2 930 33
	leaq	-17808(%rbp), %rdx
	movq	-17840(%rbp), %rcx
	movq	-17832(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 930 33 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L746
.LBB170:
	.loc 2 930 33 discriminator 2
	leaq	.LC101(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L746:
.LBE170:
	.loc 2 933 10 is_stmt 1
	testb	%bl, %bl
	je	.L747
	.loc 2 933 50 discriminator 1
	movl	-35652(%rbp), %eax
	movl	%eax, -35656(%rbp)
.L747:
	.loc 2 933 50 is_stmt 0 discriminator 2
	movl	-17808(%rbp), %eax
	movl	%eax, -35652(%rbp)
	.loc 2 933 10 is_stmt 1 discriminator 2
	testb	%bl, %bl
	je	.L748
	.loc 2 933 50 discriminator 3
	movl	-35656(%rbp), %edi
	cmpl	%edi, %eax
	jg	.L749
.LBB171:
	.loc 2 933 50 is_stmt 0 discriminator 4
	leaq	.LC102(%rip), %r12
	leaq	.LC2(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L748:
.LBE171:
	.loc 2 933 10 is_stmt 1 discriminator 5
	movl	$1, %ebx
.L749:
	.loc 2 934 13
	movl	-17808(%rbp), %edx
	movq	-17840(%rbp), %rsi
	movq	-17832(%rbp), %rax
	movl	$8, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 934 10 discriminator 1
	testl	%eax, %eax
	je	.L750
	.loc 2 934 73 discriminator 2
	movq	-17816(%rbp), %rax
	movq	%rax, %rcx
	leaq	-17808(%rbp), %rax
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	jmp	.L753
.L750:
	.loc 2 935 20
	leaq	-35616(%rbp), %rax
	movzbl	-17841(%rbp), %edi
	leaq	-17808(%rbp), %rcx
	movq	-17840(%rbp), %rsi
	movq	-17832(%rbp), %rdx
	movl	%edi, %r8d
	movq	%rax, %rdi
	call	silver_output_profile__declaration_at
	leaq	-17808(%rbp), %rax
	leaq	-35616(%rbp), %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 936 15
	jmp	.L752
.L745:
	.loc 2 937 7
	movq	-17816(%rbp), %rax
	movq	%rax, %rcx
	leaq	silver_output_profile__invalid_state(%rip), %rax
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.L753:
.LBE166:
	.loc 2 938 8
	movq	-17816(%rbp), %rax
	addq	$35624, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE54:
	.size	silver_output_profile__read_declarations, .-silver_output_profile__read_declarations
	.align 2
	.type	silver_output_profile__target_at___wrapped_statements.14, @function
silver_output_profile__target_at___wrapped_statements.14:
.LFB56:
	.loc 2 946 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$35560, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -35560(%rbp)
	movq	%r10, %rbx
	movq	%r10, -35568(%rbp)
	.loc 2 948 52
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	movq	(%rbx), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__skip_at
	.loc 2 948 52 is_stmt 0 discriminator 1
	movl	%eax, -20(%rbp)
	.loc 2 949 52 is_stmt 1
	movq	(%rbx), %rax
	movl	-20(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__name_after
	.loc 2 949 52 is_stmt 0 discriminator 1
	movl	%eax, -24(%rbp)
	.loc 2 950 49 is_stmt 1
	movq	8(%rbx), %rax
	leaq	4(%rax), %rdi
	movq	(%rbx), %rax
	movl	-24(%rbp), %ecx
	movl	-20(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%ecx, %r8d
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__lookup_name
	.loc 2 950 49 is_stmt 0 discriminator 1
	movl	%eax, -28(%rbp)
	.loc 2 952 10 is_stmt 1
	cmpl	$0, -28(%rbp)
	je	.L755
	.loc 2 953 38
	movq	8(%rbx), %rax
	leaq	6828(%rax), %rdi
	movq	(%rbx), %rax
	movl	-24(%rbp), %ecx
	movl	-20(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%ecx, %r8d
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__lookup@PLT
	.loc 2 953 87 discriminator 1
	testl	%eax, %eax
	setne	%al
	xorl	$1, %eax
	.loc 2 953 12 discriminator 1
	testb	%al, %al
	je	.L755
	.loc 2 954 35
	cmpl	$0, -28(%rbp)
	jle	.L756
	.loc 2 954 35 is_stmt 0 discriminator 1
	cmpl	$341, -28(%rbp)
	jle	.L757
.L756:
	.loc 2 954 35 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$954, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L757:
	.loc 2 954 20 is_stmt 1 discriminator 3
	movl	-28(%rbp), %eax
	movslq	%eax, %rdx
	movq	8(%rbx), %rcx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$2, %rax
	addq	%rcx, %rax
	addq	$5, %rax
	movzbl	(%rax), %eax
	.loc 2 954 20 is_stmt 0 discriminator 4
	xorl	$1, %eax
	xorl	$1, %eax
	.loc 2 954 12 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L755
	.loc 2 955 33
	movzbl	16(%rbx), %eax
	xorl	$1, %eax
	.loc 2 955 12
	testb	%al, %al
	jne	.L758
	.loc 2 955 48 discriminator 1
	movq	8(%rbx), %rax
	movl	17752(%rax), %eax
	.loc 2 955 33 discriminator 1
	cmpl	%eax, -28(%rbp)
	jne	.L755
.L758:
	.loc 2 957 15
	movq	8(%rbx), %rdx
	leaq	-35552(%rbp), %rax
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 957 33
	movl	-24(%rbp), %eax
	movl	%eax, -35552(%rbp)
	.loc 2 957 52
	movl	-28(%rbp), %eax
	movl	%eax, -17800(%rbp)
	.loc 2 952 10 discriminator 1
	leaq	-17792(%rbp), %rax
	leaq	-35552(%rbp), %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	jmp	.L759
.L755:
	.loc 2 952 10 is_stmt 0 discriminator 2
	leaq	-17792(%rbp), %rax
	leaq	silver_output_profile__invalid_state(%rip), %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
.L759:
	.loc 2 952 10 discriminator 3
	leaq	-17792(%rbp), %rax
	.loc 2 948 7 is_stmt 1 discriminator 2
	movq	-35560(%rbp), %rdx
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 946 4
	movq	-35560(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE56:
	.size	silver_output_profile__target_at___wrapped_statements.14, .-silver_output_profile__target_at___wrapped_statements.14
	.section	.rodata
	.align 8
.LC103:
	.ascii	"failed precondition from silver_output_profile.adb:943"
	.align 8
.LC104:
	.ascii	"failed precondition from silver_output_profile.adb:944"
	.align 8
.LC105:
	.ascii	"failed postcondition from silver_output_profile.adb:945"
	.text
	.align 2
	.globl	silver_output_profile__target_at
	.type	silver_output_profile__target_at, @function
silver_output_profile__target_at:
.LFB55:
	.loc 2 946 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$17864, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -17848(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -17872(%rbp)
	movq	%rdx, -17864(%rbp)
	movq	%rcx, -17856(%rbp)
	movb	%r8b, -17873(%rbp)
	.loc 2 946 4
	leaq	16(%rbp), %rdx
	.loc 2 946 4 is_stmt 0 discriminator 1
	leaq	-17872(%rbp), %rax
	movq	%rdx, -56(%rbp)
	movq	%rax, -80(%rbp)
	movq	-17856(%rbp), %rax
	movq	%rax, -72(%rbp)
	movzbl	-17873(%rbp), %eax
	movb	%al, -64(%rbp)
	movq	-17864(%rbp), %rax
	movl	(%rax), %esi
	movq	-17864(%rbp), %rax
	movl	4(%rax), %edx
	movq	-17864(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L762
	.loc 2 946 4 discriminator 2
	movq	-17864(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-17864(%rbp), %rcx
	movl	(%rcx), %edi
	movslq	%edi, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L763
.L762:
	.loc 2 946 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L763:
.LBB172:
	.loc 2 943 15 is_stmt 1
	cmpl	$1, %esi
	je	.L764
.LBB173:
	.loc 2 943 15 is_stmt 0 discriminator 1
	leaq	.LC103(%rip), %rax
	movq	%rax, -17904(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -17896(%rbp)
	movq	-17904(%rbp), %rbx
	movq	-17896(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L764:
.LBE173:
	.loc 2 943 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 943 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L765
	.loc 2 943 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L766
.L765:
.LBB174:
	.loc 2 943 15 discriminator 4
	leaq	.LC103(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L766:
.LBE174:
	.loc 2 944 19
	movq	-72(%rbp), %rdx
	movq	-17872(%rbp), %rcx
	movq	-17864(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 944 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 943 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L767
.LBB175:
	.loc 2 943 15 is_stmt 0 discriminator 6
	leaq	.LC104(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L767:
.LBE175:
.LBB176:
	.loc 2 946 4 is_stmt 1 discriminator 5
	leaq	-17840(%rbp), %rax
	leaq	-80(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_output_profile__target_at___wrapped_statements.14
	.loc 2 945 16
	leaq	-17840(%rbp), %rdx
	movq	-17872(%rbp), %rcx
	movq	-17864(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 945 16 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L768
.LBB177:
	.loc 2 945 16 discriminator 2
	leaq	.LC105(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L768:
.LBE177:
	.loc 2 946 4 is_stmt 1 discriminator 6
	movq	-17848(%rbp), %rax
	movq	%rax, %rcx
	leaq	-17840(%rbp), %rax
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE176:
.LBE172:
	.loc 2 946 4 is_stmt 0
	movq	-17848(%rbp), %rax
	addq	$17864, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE55:
	.size	silver_output_profile__target_at, .-silver_output_profile__target_at
	.align 2
	.type	silver_output_profile__dynamic_at___wrapped_statements.15, @function
silver_output_profile__dynamic_at___wrapped_statements.15:
.LFB58:
	.loc 2 964 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$35560, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -35560(%rbp)
	movq	%r10, %rbx
	movq	%r10, -35568(%rbp)
	.loc 2 965 52
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	movq	(%rbx), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__skip_at
	.loc 2 965 52 is_stmt 0 discriminator 1
	movl	%eax, -20(%rbp)
	.loc 2 966 52 is_stmt 1
	movq	(%rbx), %rax
	movl	-20(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__name_after
	.loc 2 966 52 is_stmt 0 discriminator 1
	movl	%eax, -24(%rbp)
	.loc 2 968 10 is_stmt 1
	cmpl	$0, -20(%rbp)
	je	.L771
	.loc 2 968 23 discriminator 1
	cmpl	$0, -24(%rbp)
	je	.L771
	.loc 2 968 69 discriminator 2
	movq	8(%rbx), %rax
	movl	17744(%rax), %eax
	.loc 2 968 41 discriminator 2
	testl	%eax, %eax
	je	.L771
	.loc 2 969 47
	movq	8(%rbx), %rax
	movl	17744(%rax), %eax
	testl	%eax, %eax
	jle	.L772
	.loc 2 969 47 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L773
.L772:
	.loc 2 969 47 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$969, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L773:
	.loc 2 969 68 is_stmt 1 discriminator 3
	movq	8(%rbx), %rdx
	movl	17748(%rdx), %edx
	testl	%edx, %edx
	jle	.L774
	.loc 2 969 68 is_stmt 0 discriminator 4
	cmpl	$4097, %edx
	jle	.L775
.L774:
	.loc 2 969 68 discriminator 5
	leaq	.LC12(%rip), %rax
	movl	$969, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L775:
	.loc 2 969 84 is_stmt 1 discriminator 6
	cmpl	$0, -20(%rbp)
	jle	.L776
	.loc 2 969 84 is_stmt 0 discriminator 7
	cmpl	$4097, -20(%rbp)
	jle	.L777
.L776:
	.loc 2 969 84 discriminator 8
	leaq	.LC12(%rip), %rax
	movl	$969, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L777:
	.loc 2 969 91 is_stmt 1 discriminator 9
	cmpl	$0, -24(%rbp)
	jle	.L778
	.loc 2 969 91 is_stmt 0 discriminator 10
	cmpl	$4097, -24(%rbp)
	jle	.L779
.L778:
	.loc 2 969 91 discriminator 11
	leaq	.LC12(%rip), %rax
	movl	$969, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L779:
	.loc 2 969 24 is_stmt 1 discriminator 12
	movq	(%rbx), %rcx
	movl	-24(%rbp), %r9d
	movl	-20(%rbp), %r8d
	movq	(%rcx), %rdi
	movq	8(%rcx), %rsi
	movl	%edx, %ecx
	movl	%eax, %edx
	call	silver_output_lexical__equal_name@PLT
	.loc 2 969 20 discriminator 13
	xorl	$1, %eax
	xorl	$1, %eax
	.loc 2 969 12 discriminator 13
	testb	%al, %al
	je	.L771
	.loc 2 970 34
	movq	8(%rbx), %rdx
	leaq	-35552(%rbp), %rax
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 970 52
	movl	-24(%rbp), %eax
	movl	%eax, -35552(%rbp)
	.loc 2 968 10 discriminator 3
	leaq	-17792(%rbp), %rax
	leaq	-35552(%rbp), %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	jmp	.L780
.L771:
	.loc 2 968 10 is_stmt 0 discriminator 4
	leaq	-17792(%rbp), %rax
	leaq	silver_output_profile__invalid_state(%rip), %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
.L780:
	.loc 2 968 10 discriminator 5
	leaq	-17792(%rbp), %rax
	.loc 2 965 7 is_stmt 1 discriminator 2
	movq	-35560(%rbp), %rdx
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 964 4
	movq	-35560(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE58:
	.size	silver_output_profile__dynamic_at___wrapped_statements.15, .-silver_output_profile__dynamic_at___wrapped_statements.15
	.section	.rodata
	.align 8
.LC106:
	.ascii	"failed precondition from silver_output_profile.adb:961"
	.align 8
.LC107:
	.ascii	"failed precondition from silver_output_profile.adb:962"
	.align 8
.LC108:
	.ascii	"failed postcondition from silver_output_profile.adb:963"
	.text
	.align 2
	.globl	silver_output_profile__dynamic_at
	.type	silver_output_profile__dynamic_at, @function
silver_output_profile__dynamic_at:
.LFB57:
	.loc 2 964 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$17832, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -17848(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -17872(%rbp)
	movq	%rdx, -17864(%rbp)
	movq	%rcx, -17856(%rbp)
	.loc 2 964 4
	leaq	16(%rbp), %rdx
	.loc 2 964 4 is_stmt 0 discriminator 1
	leaq	-17872(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -80(%rbp)
	movq	-17856(%rbp), %rax
	movq	%rax, -72(%rbp)
	movq	-17864(%rbp), %rax
	movl	(%rax), %esi
	movq	-17864(%rbp), %rax
	movl	4(%rax), %edx
	movq	-17864(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L783
	.loc 2 964 4 discriminator 2
	movq	-17864(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-17864(%rbp), %rcx
	movl	(%rcx), %edi
	movslq	%edi, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L784
.L783:
	.loc 2 964 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L784:
.LBB178:
	.loc 2 961 15 is_stmt 1
	cmpl	$1, %esi
	je	.L785
.LBB179:
	.loc 2 961 15 is_stmt 0 discriminator 1
	leaq	.LC106(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L785:
.LBE179:
	.loc 2 961 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 961 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L786
	.loc 2 961 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L787
.L786:
.LBB180:
	.loc 2 961 15 discriminator 4
	leaq	.LC106(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L787:
.LBE180:
	.loc 2 962 19
	movq	-72(%rbp), %rdx
	movq	-17872(%rbp), %rcx
	movq	-17864(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 962 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 961 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L788
.LBB181:
	.loc 2 961 15 is_stmt 0 discriminator 6
	leaq	.LC107(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L788:
.LBE181:
.LBB182:
	.loc 2 964 4 is_stmt 1 discriminator 5
	leaq	-17840(%rbp), %rax
	leaq	-80(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_output_profile__dynamic_at___wrapped_statements.15
	.loc 2 963 16
	leaq	-17840(%rbp), %rdx
	movq	-17872(%rbp), %rcx
	movq	-17864(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 963 16 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L789
.LBB183:
	.loc 2 963 16 discriminator 2
	leaq	.LC108(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L789:
.LBE183:
	.loc 2 964 4 is_stmt 1 discriminator 6
	movq	-17848(%rbp), %rax
	movq	%rax, %rcx
	leaq	-17840(%rbp), %rax
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE182:
.LBE178:
	.loc 2 964 4 is_stmt 0
	movq	-17848(%rbp), %rax
	addq	$17832, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE57:
	.size	silver_output_profile__dynamic_at, .-silver_output_profile__dynamic_at
	.align 2
	.type	silver_output_profile__assignment_at___wrapped_statements.16, @function
silver_output_profile__assignment_at___wrapped_statements.16:
.LFB60:
	.loc 2 977 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$35576, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -35576(%rbp)
	movq	%r10, %rbx
	movq	%r10, -35584(%rbp)
	.loc 2 978 53
	movq	8(%rbx), %rax
	leaq	6828(%rax), %r8
	movq	8(%rbx), %rax
	leaq	4(%rax), %rsi
	movq	8(%rbx), %rax
	movl	(%rax), %ecx
	movq	(%rbx), %rax
	leaq	-17808(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	subq	$8, %rsp
	pushq	$0
	movq	%r8, %r9
	movq	%rsi, %r8
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__expression_at
	addq	$16, %rsp
	.loc 2 980 17
	movq	8(%rbx), %rax
	movl	17756(%rax), %edx
	leaq	-17808(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_output_profile__fits
	.loc 2 980 13 discriminator 1
	xorl	$1, %eax
	xorl	$1, %eax
	.loc 2 980 10 discriminator 1
	testb	%al, %al
	je	.L792
	.loc 2 980 67 discriminator 2
	movq	8(%rbx), %rax
	movl	17752(%rax), %eax
	.loc 2 980 46 discriminator 2
	testl	%eax, %eax
	je	.L792
	.loc 2 981 12
	movzbl	-17791(%rbp), %eax
	xorl	$1, %eax
	testb	%al, %al
	je	.L792
	.loc 2 981 67 discriminator 1
	movl	-17804(%rbp), %edx
	movl	-17800(%rbp), %eax
	.loc 2 981 38 discriminator 1
	cmpl	%eax, %edx
	jne	.L792
	.loc 2 982 54
	movq	8(%rbx), %rax
	movl	17752(%rax), %eax
	testl	%eax, %eax
	jle	.L793
	.loc 2 982 54 is_stmt 0 discriminator 1
	movq	8(%rbx), %rax
	movl	17752(%rax), %eax
	cmpl	$341, %eax
	jle	.L794
.L793:
	.loc 2 982 54 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$982, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L794:
	.loc 2 982 40 is_stmt 1 discriminator 3
	movl	-17800(%rbp), %ecx
	movq	8(%rbx), %rax
	movl	17752(%rax), %eax
	cltq
	movq	8(%rbx), %rsi
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$2, %rax
	addq	%rsi, %rax
	addq	$20, %rax
	movl	(%rax), %eax
	.loc 2 982 40 is_stmt 0 discriminator 4
	cmpl	%eax, %ecx
	setne	%al
	xorl	$1, %eax
	.loc 2 982 12 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L792
	.loc 2 984 29
	movq	8(%rbx), %rax
	movl	17752(%rax), %eax
	testl	%eax, %eax
	jle	.L795
	.loc 2 984 29 is_stmt 0 discriminator 1
	movq	8(%rbx), %rax
	movl	17752(%rax), %eax
	cmpl	$341, %eax
	jle	.L796
.L795:
	.loc 2 984 29 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$984, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L796:
	.loc 2 983 40 is_stmt 1
	movl	-17796(%rbp), %ecx
	.loc 2 984 15 discriminator 3
	movq	8(%rbx), %rax
	movl	17752(%rax), %eax
	movslq	%eax, %rdx
	movq	8(%rbx), %rsi
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$2, %rax
	addq	%rsi, %rax
	addq	$4, %rax
	movzbl	(%rax), %eax
	.loc 2 984 15 is_stmt 0 discriminator 4
	testb	%al, %al
	je	.L797
	.loc 2 984 15 discriminator 5
	movl	$1, %eax
	jmp	.L798
.L797:
	.loc 2 984 15 discriminator 6
	movl	$0, %eax
.L798:
	.loc 2 983 40 is_stmt 1 discriminator 1
	cmpl	%ecx, %eax
	setne	%al
	xorl	$1, %eax
	.loc 2 983 12 discriminator 1
	testb	%al, %al
	je	.L792
	.loc 2 985 34
	movq	8(%rbx), %rdx
	leaq	-35568(%rbp), %rax
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 985 52
	movl	-17808(%rbp), %eax
	movl	%eax, -35568(%rbp)
	.loc 2 980 10 discriminator 3
	leaq	-17776(%rbp), %rax
	leaq	-35568(%rbp), %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	jmp	.L799
.L792:
	.loc 2 980 10 is_stmt 0 discriminator 4
	leaq	-17776(%rbp), %rax
	leaq	silver_output_profile__invalid_state(%rip), %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
.L799:
	.loc 2 980 10 discriminator 5
	leaq	-17776(%rbp), %rax
	.loc 2 978 7 is_stmt 1 discriminator 1
	movq	-35576(%rbp), %rdx
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 977 4
	movq	-35576(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE60:
	.size	silver_output_profile__assignment_at___wrapped_statements.16, .-silver_output_profile__assignment_at___wrapped_statements.16
	.section	.rodata
	.align 8
.LC109:
	.ascii	"failed precondition from silver_output_profile.adb:974"
	.align 8
.LC110:
	.ascii	"failed precondition from silver_output_profile.adb:975"
	.align 8
.LC111:
	.ascii	"failed postcondition from silver_output_profile.adb:976"
	.text
	.align 2
	.globl	silver_output_profile__assignment_at
	.type	silver_output_profile__assignment_at, @function
silver_output_profile__assignment_at:
.LFB59:
	.loc 2 977 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$17832, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -17848(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -17872(%rbp)
	movq	%rdx, -17864(%rbp)
	movq	%rcx, -17856(%rbp)
	.loc 2 977 4
	leaq	16(%rbp), %rdx
	.loc 2 977 4 is_stmt 0 discriminator 1
	leaq	-17872(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -80(%rbp)
	movq	-17856(%rbp), %rax
	movq	%rax, -72(%rbp)
	movq	-17864(%rbp), %rax
	movl	(%rax), %esi
	movq	-17864(%rbp), %rax
	movl	4(%rax), %edx
	movq	-17864(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L802
	.loc 2 977 4 discriminator 2
	movq	-17864(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-17864(%rbp), %rcx
	movl	(%rcx), %edi
	movslq	%edi, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L803
.L802:
	.loc 2 977 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L803:
.LBB184:
	.loc 2 974 15 is_stmt 1
	cmpl	$1, %esi
	je	.L804
.LBB185:
	.loc 2 974 15 is_stmt 0 discriminator 1
	leaq	.LC109(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L804:
.LBE185:
	.loc 2 974 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 974 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L805
	.loc 2 974 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L806
.L805:
.LBB186:
	.loc 2 974 15 discriminator 4
	leaq	.LC109(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L806:
.LBE186:
	.loc 2 975 19
	movq	-72(%rbp), %rdx
	movq	-17872(%rbp), %rcx
	movq	-17864(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 975 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 974 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L807
.LBB187:
	.loc 2 974 15 is_stmt 0 discriminator 6
	leaq	.LC110(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L807:
.LBE187:
.LBB188:
	.loc 2 977 4 is_stmt 1 discriminator 5
	leaq	-17840(%rbp), %rax
	leaq	-80(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_output_profile__assignment_at___wrapped_statements.16
	.loc 2 976 16
	leaq	-17840(%rbp), %rdx
	movq	-17872(%rbp), %rcx
	movq	-17864(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 976 16 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L808
.LBB189:
	.loc 2 976 16 discriminator 2
	leaq	.LC111(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L808:
.LBE189:
	.loc 2 977 4 is_stmt 1 discriminator 6
	movq	-17848(%rbp), %rax
	movq	%rax, %rcx
	leaq	-17840(%rbp), %rax
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE188:
.LBE184:
	.loc 2 977 4 is_stmt 0
	movq	-17848(%rbp), %rax
	addq	$17832, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE59:
	.size	silver_output_profile__assignment_at, .-silver_output_profile__assignment_at
	.align 2
	.type	silver_output_profile__output_at___wrapped_statements.17, @function
silver_output_profile__output_at___wrapped_statements.17:
.LFB62:
	.loc 2 992 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$35576, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -35576(%rbp)
	movq	%r10, %rbx
	movq	%r10, -35584(%rbp)
	.loc 2 993 53
	movq	8(%rbx), %rax
	leaq	6828(%rax), %r8
	movq	8(%rbx), %rax
	leaq	4(%rax), %rsi
	movq	8(%rbx), %rax
	movl	(%rax), %ecx
	movq	(%rbx), %rax
	leaq	-17808(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	subq	$8, %rsp
	pushq	$0
	movq	%r8, %r9
	movq	%rsi, %r8
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__expression_at
	addq	$16, %rsp
	.loc 2 995 17
	movq	8(%rbx), %rax
	movl	17756(%rax), %edx
	leaq	-17808(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_output_profile__fits
	.loc 2 995 10 discriminator 1
	testb	%al, %al
	je	.L811
	.loc 2 996 34
	movq	8(%rbx), %rdx
	leaq	-35568(%rbp), %rax
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 996 52
	movl	-17808(%rbp), %eax
	movl	%eax, -35568(%rbp)
	.loc 2 995 10 discriminator 2
	leaq	-17776(%rbp), %rax
	leaq	-35568(%rbp), %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	jmp	.L812
.L811:
	.loc 2 995 10 is_stmt 0 discriminator 3
	leaq	-17776(%rbp), %rax
	leaq	silver_output_profile__invalid_state(%rip), %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
.L812:
	.loc 2 995 10 discriminator 4
	leaq	-17776(%rbp), %rax
	.loc 2 993 7 is_stmt 1 discriminator 1
	movq	-35576(%rbp), %rdx
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 992 4
	movq	-35576(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE62:
	.size	silver_output_profile__output_at___wrapped_statements.17, .-silver_output_profile__output_at___wrapped_statements.17
	.section	.rodata
	.align 8
.LC112:
	.ascii	"failed precondition from silver_output_profile.adb:989"
	.align 8
.LC113:
	.ascii	"failed precondition from silver_output_profile.adb:990"
	.align 8
.LC114:
	.ascii	"failed postcondition from silver_output_profile.adb:991"
	.text
	.align 2
	.globl	silver_output_profile__output_at
	.type	silver_output_profile__output_at, @function
silver_output_profile__output_at:
.LFB61:
	.loc 2 992 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$17832, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -17848(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -17872(%rbp)
	movq	%rdx, -17864(%rbp)
	movq	%rcx, -17856(%rbp)
	.loc 2 992 4
	leaq	16(%rbp), %rdx
	.loc 2 992 4 is_stmt 0 discriminator 1
	leaq	-17872(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -80(%rbp)
	movq	-17856(%rbp), %rax
	movq	%rax, -72(%rbp)
	movq	-17864(%rbp), %rax
	movl	(%rax), %esi
	movq	-17864(%rbp), %rax
	movl	4(%rax), %edx
	movq	-17864(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L815
	.loc 2 992 4 discriminator 2
	movq	-17864(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-17864(%rbp), %rcx
	movl	(%rcx), %edi
	movslq	%edi, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L816
.L815:
	.loc 2 992 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L816:
.LBB190:
	.loc 2 989 15 is_stmt 1
	cmpl	$1, %esi
	je	.L817
.LBB191:
	.loc 2 989 15 is_stmt 0 discriminator 1
	leaq	.LC112(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L817:
.LBE191:
	.loc 2 989 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 989 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L818
	.loc 2 989 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L819
.L818:
.LBB192:
	.loc 2 989 15 discriminator 4
	leaq	.LC112(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L819:
.LBE192:
	.loc 2 990 19
	movq	-72(%rbp), %rdx
	movq	-17872(%rbp), %rcx
	movq	-17864(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 990 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 989 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L820
.LBB193:
	.loc 2 989 15 is_stmt 0 discriminator 6
	leaq	.LC113(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L820:
.LBE193:
.LBB194:
	.loc 2 992 4 is_stmt 1 discriminator 5
	leaq	-17840(%rbp), %rax
	leaq	-80(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_output_profile__output_at___wrapped_statements.17
	.loc 2 991 16
	leaq	-17840(%rbp), %rdx
	movq	-17872(%rbp), %rcx
	movq	-17864(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 991 16 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L821
.LBB195:
	.loc 2 991 16 discriminator 2
	leaq	.LC114(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L821:
.LBE195:
	.loc 2 992 4 is_stmt 1 discriminator 6
	movq	-17848(%rbp), %rax
	movq	%rax, %rcx
	leaq	-17840(%rbp), %rax
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE194:
.LBE190:
	.loc 2 992 4 is_stmt 0
	movq	-17848(%rbp), %rax
	addq	$17832, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE61:
	.size	silver_output_profile__output_at, .-silver_output_profile__output_at
	.align 2
	.type	silver_output_profile__comparison_at___wrapped_statements.18, @function
silver_output_profile__comparison_at___wrapped_statements.18:
.LFB64:
	.loc 2 1003 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$35608, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, -35624(%rbp)
	movq	%r10, %rbx
	movq	%r10, -35632(%rbp)
	.loc 2 1004 52
	movq	8(%rbx), %rax
	leaq	6828(%rax), %r8
	movq	8(%rbx), %rax
	leaq	4(%rax), %rsi
	movq	8(%rbx), %rax
	movl	(%rax), %ecx
	movq	(%rbx), %rax
	leaq	-17824(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	subq	$8, %rsp
	pushq	$0
	movq	%r8, %r9
	movq	%rsi, %r8
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__expression_at
	addq	$16, %rsp
	.loc 2 1005 53
	movq	8(%rbx), %rax
	leaq	6828(%rax), %r13
	movq	8(%rbx), %rax
	leaq	4(%rax), %r12
	movl	-17824(%rbp), %edx
	movq	(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$40, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	movl	%eax, %ecx
	.loc 2 1005 53 is_stmt 0 discriminator 1
	movq	(%rbx), %rax
	leaq	-17856(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	subq	$8, %rsp
	pushq	$0
	movq	%r13, %r9
	movq	%r12, %r8
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__expression_at
	addq	$16, %rsp
	.loc 2 1008 17 is_stmt 1
	movq	8(%rbx), %rax
	movl	17756(%rax), %edx
	leaq	-17824(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_output_profile__fits
	.loc 2 1008 13 discriminator 1
	xorl	$1, %eax
	xorl	$1, %eax
	.loc 2 1008 10 discriminator 1
	testb	%al, %al
	je	.L824
	.loc 2 1008 57 discriminator 2
	movq	8(%rbx), %rax
	movl	17756(%rax), %edx
	leaq	-17856(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_output_profile__fits
	.loc 2 1008 53 discriminator 3
	xorl	$1, %eax
	xorl	$1, %eax
	.loc 2 1008 45 discriminator 3
	testb	%al, %al
	je	.L824
	.loc 2 1009 12
	movzbl	-17808(%rbp), %eax
	testb	%al, %al
	jne	.L825
	.loc 2 1009 41 discriminator 1
	movzbl	-17840(%rbp), %eax
	testb	%al, %al
	je	.L824
.L825:
	.loc 2 1010 34
	movq	8(%rbx), %rdx
	leaq	-35616(%rbp), %rax
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 1010 52
	movl	-17856(%rbp), %eax
	movl	%eax, -35616(%rbp)
	.loc 2 1008 10 discriminator 4
	leaq	-17792(%rbp), %rax
	leaq	-35616(%rbp), %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	jmp	.L826
.L824:
	.loc 2 1008 10 is_stmt 0 discriminator 5
	leaq	-17792(%rbp), %rax
	leaq	silver_output_profile__invalid_state(%rip), %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
.L826:
	.loc 2 1008 10 discriminator 6
	leaq	-17792(%rbp), %rax
	.loc 2 1004 7 is_stmt 1 discriminator 1
	movq	-35624(%rbp), %rdx
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 1003 4
	movq	-35624(%rbp), %rax
	leaq	-24(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE64:
	.size	silver_output_profile__comparison_at___wrapped_statements.18, .-silver_output_profile__comparison_at___wrapped_statements.18
	.section	.rodata
	.align 8
.LC115:
	.ascii	"failed precondition from silver_output_profile.adb:1000"
	.align 8
.LC116:
	.ascii	"failed precondition from silver_output_profile.adb:1001"
	.align 8
.LC117:
	.ascii	"failed postcondition from silver_output_profile.adb:1002"
	.align 8
.LC6:
	.long	1
	.long	56
	.text
	.align 2
	.globl	silver_output_profile__comparison_at
	.type	silver_output_profile__comparison_at, @function
silver_output_profile__comparison_at:
.LFB63:
	.loc 2 1003 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$17832, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -17848(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -17872(%rbp)
	movq	%rdx, -17864(%rbp)
	movq	%rcx, -17856(%rbp)
	.loc 2 1003 4
	leaq	16(%rbp), %rdx
	.loc 2 1003 4 is_stmt 0 discriminator 1
	leaq	-17872(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -80(%rbp)
	movq	-17856(%rbp), %rax
	movq	%rax, -72(%rbp)
	movq	-17864(%rbp), %rax
	movl	(%rax), %esi
	movq	-17864(%rbp), %rax
	movl	4(%rax), %edx
	movq	-17864(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L829
	.loc 2 1003 4 discriminator 2
	movq	-17864(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-17864(%rbp), %rcx
	movl	(%rcx), %edi
	movslq	%edi, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L830
.L829:
	.loc 2 1003 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L830:
.LBB196:
	.loc 2 1000 15 is_stmt 1
	cmpl	$1, %esi
	je	.L831
.LBB197:
	.loc 2 1000 15 is_stmt 0 discriminator 1
	leaq	.LC115(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L831:
.LBE197:
	.loc 2 1000 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 1000 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L832
	.loc 2 1000 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L833
.L832:
.LBB198:
	.loc 2 1000 15 discriminator 4
	leaq	.LC115(%rip), %r8
	leaq	.LC1(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L833:
.LBE198:
	.loc 2 1001 19
	movq	-72(%rbp), %rdx
	movq	-17872(%rbp), %rcx
	movq	-17864(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 1001 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 1000 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L834
.LBB199:
	.loc 2 1000 15 is_stmt 0 discriminator 6
	leaq	.LC116(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L834:
.LBE199:
.LBB200:
	.loc 2 1003 4 is_stmt 1 discriminator 5
	leaq	-17840(%rbp), %rax
	leaq	-80(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_output_profile__comparison_at___wrapped_statements.18
	.loc 2 1002 16
	leaq	-17840(%rbp), %rdx
	movq	-17872(%rbp), %rcx
	movq	-17864(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 1002 16 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L835
.LBB201:
	.loc 2 1002 16 discriminator 2
	leaq	.LC117(%rip), %r12
	leaq	.LC6(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L835:
.LBE201:
	.loc 2 1003 4 is_stmt 1 discriminator 6
	movq	-17848(%rbp), %rax
	movq	%rax, %rcx
	leaq	-17840(%rbp), %rax
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE200:
.LBE196:
	.loc 2 1003 4 is_stmt 0
	movq	-17848(%rbp), %rax
	addq	$17832, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE63:
	.size	silver_output_profile__comparison_at, .-silver_output_profile__comparison_at
	.section	.rodata
	.align 8
.LC118:
	.ascii	"failed precondition from silver_output_profile.adb:1014"
	.align 8
.LC119:
	.ascii	"failed precondition from silver_output_profile.adb:1015"
	.text
	.align 2
	.globl	silver_output_profile__capacity_at
	.type	silver_output_profile__capacity_at, @function
silver_output_profile__capacity_at:
.LFB65:
	.loc 2 1024 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$17816, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, -17816(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -17840(%rbp)
	movq	%rdx, -17832(%rbp)
	movq	%rcx, -17824(%rbp)
	.loc 2 1024 4
	movq	-17832(%rbp), %rax
	movl	(%rax), %eax
	movq	-17832(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L838
	.loc 2 1024 4 is_stmt 0 discriminator 1
	movslq	%edx, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	movslq	%eax, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rcx
	sbbq	%rdi, %rbx
	addq	$1, %rcx
	adcq	$0, %rbx
	jmp	.L839
.L838:
	.loc 2 1024 4 discriminator 2
	movl	$0, %ecx
	movl	$0, %ebx
.L839:
.LBB202:
	.loc 2 1024 4 discriminator 3
	cmpl	%eax, %edx
	.loc 2 1024 4 discriminator 6
	cmpl	%eax, %edx
	.loc 2 1024 4 discriminator 9
	cmpl	%eax, %edx
	.loc 2 1014 15 is_stmt 1
	cmpl	$1, %eax
	je	.L846
.LBB203:
	.loc 2 1014 15 is_stmt 0 discriminator 1
	leaq	.LC118(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L846:
.LBE203:
	.loc 2 1014 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 1014 15 discriminator 2
	testl	%eax, %eax
	jle	.L847
	.loc 2 1014 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L848
.L847:
.LBB204:
	.loc 2 1014 15 discriminator 4
	leaq	.LC118(%rip), %r8
	leaq	.LC1(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L848:
.LBE204:
	.loc 2 1015 19
	movq	-17824(%rbp), %rdx
	movq	-17840(%rbp), %rcx
	movq	-17832(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 1015 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 1014 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L849
.LBB205:
	.loc 2 1014 15 is_stmt 0 discriminator 6
	leaq	.LC119(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L849:
.LBE205:
	.loc 2 1025 47 is_stmt 1
	movq	-17824(%rbp), %rax
	movl	(%rax), %edx
	movq	-17840(%rbp), %rcx
	movq	-17832(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__skip_at
	.loc 2 1025 47 is_stmt 0 discriminator 1
	movl	%eax, -36(%rbp)
	.loc 2 1028 7 is_stmt 1
	cmpl	$0, -36(%rbp)
	jne	.L850
	.loc 2 1028 28 discriminator 1
	movq	-17816(%rbp), %rax
	movq	%rax, %rcx
	leaq	silver_output_profile__invalid_state(%rip), %rax
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	jmp	.L855
.L850:
	.loc 2 1029 37
	cmpl	$0, -36(%rbp)
	jle	.L852
	.loc 2 1029 37 is_stmt 0 discriminator 1
	cmpl	$4097, -36(%rbp)
	jle	.L853
.L852:
	.loc 2 1029 37 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$1029, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L853:
	.loc 2 1029 16 is_stmt 1 discriminator 3
	movl	-36(%rbp), %edx
	movq	-17840(%rbp), %rcx
	movq	-17832(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__read_capacity@PLT
	.loc 2 1029 13 discriminator 4
	movq	%rax, -48(%rbp)
	.loc 2 1030 22
	movl	-48(%rbp), %eax
	.loc 2 1030 7
	testl	%eax, %eax
	jne	.L854
	.loc 2 1030 31 discriminator 1
	movq	-17816(%rbp), %rax
	movq	%rax, %rcx
	leaq	silver_output_profile__invalid_state(%rip), %rax
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	jmp	.L855
.L854:
	.loc 2 1031 14
	movq	-17824(%rbp), %rdx
	leaq	-17808(%rbp), %rax
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 1031 32
	movl	-48(%rbp), %eax
	movl	%eax, -17808(%rbp)
	.loc 2 1031 57
	movl	-44(%rbp), %eax
	movl	%eax, -52(%rbp)
	.loc 2 1031 7
	movq	-17816(%rbp), %rax
	movq	%rax, %rcx
	leaq	-17808(%rbp), %rax
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.L855:
.LBE202:
	.loc 2 1032 8
	movq	-17816(%rbp), %rax
	addq	$17816, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE65:
	.size	silver_output_profile__capacity_at, .-silver_output_profile__capacity_at
	.align 2
	.type	silver_output_profile__step___wrapped_statements.19, @function
silver_output_profile__step___wrapped_statements.19:
.LFB67:
	.loc 2 1041 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$53336, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -53336(%rbp)
	movq	%r10, %rbx
	movq	%r10, -53344(%rbp)
	.loc 2 1044 25
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	.loc 2 1044 7
	testl	%eax, %eax
	jne	.L857
	.loc 2 1044 34 discriminator 1
	movq	-53336(%rbp), %rax
	movq	%rax, %rcx
	leaq	silver_output_profile__invalid_state(%rip), %rax
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	jmp	.L870
.L857:
	.loc 2 1045 7
	movzbl	17(%rbx), %eax
	cmpb	$51, %al
	jne	.L859
	.loc 2 1046 9
	movq	8(%rbx), %rdx
	leaq	-17776(%rbp), %rax
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 1046 44
	movzbl	16(%rbx), %eax
	movzbl	%al, %eax
	movl	%eax, %edi
	call	silver_output_profile__is_argument_form
	movl	%eax, %edx
	.loc 2 1046 44 is_stmt 0 discriminator 1
	movq	(%rbx), %rax
	movzbl	%dl, %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_names__context_after@PLT
	.loc 2 1046 27 is_stmt 1 discriminator 2
	movl	%eax, -17776(%rbp)
	.loc 2 1046 9 discriminator 2
	movq	-53336(%rbp), %rax
	movq	%rax, %rcx
	leaq	-17776(%rbp), %rax
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	jmp	.L870
.L859:
	.loc 2 1047 7
	movzbl	17(%rbx), %eax
	cmpb	$41, %al
	jne	.L860
	.loc 2 1047 47 discriminator 1
	movq	(%rbx), %rax
	movq	8(%rbx), %rcx
	movq	-53336(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__argument_at
	.loc 2 1047 47 is_stmt 0 discriminator 2
	jmp	.L870
.L860:
	.loc 2 1048 7 is_stmt 1
	movzbl	17(%rbx), %eax
	cmpb	$42, %al
	jne	.L861
	.loc 2 1048 39 discriminator 1
	movzbl	16(%rbx), %eax
	movzbl	%al, %eax
	movl	%eax, %edi
	call	silver_output_profile__is_argument_form
	movl	%eax, %edx
	.loc 2 1048 39 is_stmt 0 discriminator 2
	movq	(%rbx), %rax
	movq	8(%rbx), %rcx
	movq	-53336(%rbp), %rdi
	movzbl	%dl, %esi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movl	%esi, %r8d
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__read_declarations
	.loc 2 1048 39 discriminator 3
	jmp	.L870
.L861:
	.loc 2 1049 7 is_stmt 1
	movzbl	17(%rbx), %eax
	cmpb	$43, %al
	jne	.L862
	.loc 2 1049 44 discriminator 1
	movq	(%rbx), %rax
	movq	8(%rbx), %rcx
	movq	-53336(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movl	$0, %r8d
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__target_at
	.loc 2 1049 44 is_stmt 0 discriminator 2
	jmp	.L870
.L862:
	.loc 2 1050 7 is_stmt 1
	movzbl	17(%rbx), %eax
	cmpb	$44, %al
	jne	.L863
	.loc 2 1050 43 discriminator 1
	movq	(%rbx), %rax
	movq	8(%rbx), %rcx
	movq	-53336(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movl	$1, %r8d
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__target_at
	.loc 2 1050 43 is_stmt 0 discriminator 2
	jmp	.L870
.L863:
	.loc 2 1051 7 is_stmt 1
	movzbl	17(%rbx), %eax
	cmpb	$45, %al
	jne	.L864
	.loc 2 1051 44 discriminator 1
	movq	(%rbx), %rax
	movq	8(%rbx), %rcx
	movq	-53336(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__dynamic_at
	.loc 2 1051 44 is_stmt 0 discriminator 2
	jmp	.L870
.L864:
	.loc 2 1052 7 is_stmt 1
	movzbl	17(%rbx), %eax
	cmpb	$46, %al
	jne	.L865
	.loc 2 1052 43 discriminator 1
	movq	(%rbx), %rax
	movq	8(%rbx), %rcx
	movq	-53336(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__assignment_at
	.loc 2 1052 43 is_stmt 0 discriminator 2
	jmp	.L870
.L865:
	.loc 2 1053 7 is_stmt 1
	movzbl	17(%rbx), %eax
	cmpb	$47, %al
	jne	.L866
	.loc 2 1053 44 discriminator 1
	movq	(%rbx), %rax
	movq	8(%rbx), %rcx
	movq	-53336(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__output_at
	.loc 2 1053 44 is_stmt 0 discriminator 2
	jmp	.L870
.L866:
	.loc 2 1054 7 is_stmt 1
	movzbl	17(%rbx), %eax
	cmpb	$48, %al
	jne	.L867
	.loc 2 1054 48 discriminator 1
	movq	(%rbx), %rax
	movq	8(%rbx), %rcx
	movq	-53336(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__comparison_at
	.loc 2 1054 48 is_stmt 0 discriminator 2
	jmp	.L870
.L867:
	.loc 2 1055 7 is_stmt 1
	movzbl	17(%rbx), %eax
	cmpb	$39, %al
	jne	.L868
	.loc 2 1055 43 discriminator 1
	movq	(%rbx), %rax
	movq	8(%rbx), %rcx
	movq	-53336(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__capacity_at
	.loc 2 1055 43 is_stmt 0 discriminator 2
	jmp	.L870
.L868:
	.loc 2 1056 7 is_stmt 1
	movzbl	17(%rbx), %eax
	cmpb	$15, %al
	jne	.L869
	.loc 2 1057 9
	movq	8(%rbx), %rdx
	leaq	-35536(%rbp), %rax
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 1057 39
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	movq	(%rbx), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__skip_at
	movl	%eax, %ecx
	.loc 2 1057 39 is_stmt 0 discriminator 1
	movq	(%rbx), %rax
	leaq	-35568(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__literal_at
	.loc 2 1057 27 is_stmt 1 discriminator 2
	movl	-35568(%rbp), %eax
	movl	%eax, -35536(%rbp)
	.loc 2 1057 9 discriminator 2
	movq	-53336(%rbp), %rax
	movq	%rax, %rcx
	leaq	-35536(%rbp), %rax
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	jmp	.L870
.L869:
	.loc 2 1058 12
	movq	8(%rbx), %rdx
	leaq	-53328(%rbp), %rax
	movq	%rdx, %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 1058 42
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	movq	(%rbx), %rax
	movzbl	17(%rbx), %ecx
	movzbl	%cl, %ecx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1058 30 discriminator 1
	movl	%eax, -53328(%rbp)
	.loc 2 1058 12 discriminator 1
	movq	-53336(%rbp), %rax
	movq	%rax, %rcx
	leaq	-53328(%rbp), %rax
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.L870:
	.loc 2 1041 4
	movq	-53336(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE67:
	.size	silver_output_profile__step___wrapped_statements.19, .-silver_output_profile__step___wrapped_statements.19
	.section	.rodata
	.align 8
.LC120:
	.ascii	"failed precondition from silver_output_profile.adb:1038"
	.align 8
.LC121:
	.ascii	"failed precondition from silver_output_profile.adb:1039"
	.align 8
.LC122:
	.ascii	"failed postcondition from silver_output_profile.adb:1040"
	.text
	.align 2
	.globl	silver_output_profile__step
	.type	silver_output_profile__step, @function
silver_output_profile__step:
.LFB66:
	.loc 2 1041 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$17864, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -17848(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -17872(%rbp)
	movq	%rdx, -17864(%rbp)
	movb	%cl, -17849(%rbp)
	movb	%r8b, -17850(%rbp)
	movq	%r9, -17880(%rbp)
	.loc 2 1041 4
	leaq	16(%rbp), %rdx
	.loc 2 1041 4 is_stmt 0 discriminator 1
	leaq	-17872(%rbp), %rax
	movq	%rdx, -56(%rbp)
	movq	%rax, -80(%rbp)
	movzbl	-17849(%rbp), %eax
	movb	%al, -64(%rbp)
	movzbl	-17850(%rbp), %eax
	movb	%al, -63(%rbp)
	movq	-17880(%rbp), %rax
	movq	%rax, -72(%rbp)
	movq	-17864(%rbp), %rax
	movl	(%rax), %esi
	movq	-17864(%rbp), %rax
	movl	4(%rax), %edx
	movq	-17864(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L872
	.loc 2 1041 4 discriminator 2
	movq	-17864(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-17864(%rbp), %rcx
	movl	(%rcx), %edi
	movslq	%edi, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L873
.L872:
	.loc 2 1041 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L873:
.LBB206:
	.loc 2 1038 15 is_stmt 1
	cmpl	$1, %esi
	je	.L874
.LBB207:
	.loc 2 1038 15 is_stmt 0 discriminator 1
	leaq	.LC120(%rip), %rax
	movq	%rax, -17904(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -17896(%rbp)
	movq	-17904(%rbp), %rbx
	movq	-17896(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L874:
.LBE207:
	.loc 2 1038 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 1038 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L875
	.loc 2 1038 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L876
.L875:
.LBB208:
	.loc 2 1038 15 discriminator 4
	leaq	.LC120(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L876:
.LBE208:
	.loc 2 1039 19
	movq	-72(%rbp), %rdx
	movq	-17872(%rbp), %rcx
	movq	-17864(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 1039 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 1038 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L877
.LBB209:
	.loc 2 1038 15 is_stmt 0 discriminator 6
	leaq	.LC121(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L877:
.LBE209:
.LBB210:
	.loc 2 1041 4 is_stmt 1 discriminator 5
	leaq	-17840(%rbp), %rax
	leaq	-80(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_output_profile__step___wrapped_statements.19
	.loc 2 1040 16
	leaq	-17840(%rbp), %rdx
	movq	-17872(%rbp), %rcx
	movq	-17864(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 1040 16 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L878
.LBB211:
	.loc 2 1040 16 discriminator 2
	leaq	.LC122(%rip), %r12
	leaq	.LC6(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L878:
.LBE211:
	.loc 2 1041 4 is_stmt 1 discriminator 6
	movq	-17848(%rbp), %rax
	movq	%rax, %rcx
	leaq	-17840(%rbp), %rax
	movl	$17760, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE210:
.LBE206:
	.loc 2 1041 4 is_stmt 0
	movq	-17848(%rbp), %rax
	addq	$17864, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE66:
	.size	silver_output_profile__step, .-silver_output_profile__step
	.align 2
	.globl	silver_output_profile__scan_resultIP
	.type	silver_output_profile__scan_resultIP, @function
silver_output_profile__scan_resultIP:
.LFB68:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE68:
	.size	silver_output_profile__scan_resultIP, .-silver_output_profile__scan_resultIP
	.align 2
	.globl	silver_output_profile__body_contextIP
	.type	silver_output_profile__body_contextIP, @function
silver_output_profile__body_contextIP:
.LFB69:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE69:
	.size	silver_output_profile__body_contextIP, .-silver_output_profile__body_contextIP
	.align 2
	.globl	silver_output_profile__interval_vectorIP
	.type	silver_output_profile__interval_vectorIP, @function
silver_output_profile__interval_vectorIP:
.LFB70:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE70:
	.size	silver_output_profile__interval_vectorIP, .-silver_output_profile__interval_vectorIP
	.align 2
	.globl	silver_output_profile__scalar_flowIP
	.type	silver_output_profile__scalar_flowIP, @function
silver_output_profile__scalar_flowIP:
.LFB71:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movl	%esi, -12(%rbp)
	movq	-8(%rbp), %rax
	movl	-12(%rbp), %edx
	movl	%edx, (%rax)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE71:
	.size	silver_output_profile__scalar_flowIP, .-silver_output_profile__scalar_flowIP
	.align 2
	.globl	silver_output_profile__body_scanIP
	.type	silver_output_profile__body_scanIP, @function
silver_output_profile__body_scanIP:
.LFB72:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movl	%esi, -12(%rbp)
	movq	-8(%rbp), %rax
	movl	-12(%rbp), %edx
	movl	%edx, (%rax)
	movq	-8(%rbp), %rax
	leaq	20(%rax), %rdx
	movl	-12(%rbp), %eax
	movl	%eax, %esi
	movq	%rdx, %rdi
	call	silver_output_profile__scalar_flowIP
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE72:
	.size	silver_output_profile__body_scanIP, .-silver_output_profile__body_scanIP
	.align 2
	.type	silver_output_profile__initial_flow___wrapped_statements.20, @function
silver_output_profile__initial_flow___wrapped_statements.20:
.LFB74:
	.loc 2 1112 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$48, %rsp
	.cfi_offset 14, -24
	.cfi_offset 13, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%r10, %rbx
	movq	%r10, -72(%rbp)
	movq	%rsp, %rax
	movq	%rax, %r14
	.loc 2 1113 7
	movq	(%rbx), %rax
	movl	6824(%rax), %eax
	movl	%eax, -40(%rbp)
	movl	-40(%rbp), %eax
	cltq
	movq	%rax, -48(%rbp)
	movq	(%rbx), %rax
	movl	6824(%rax), %eax
	cltq
	addq	$2, %rax
	leaq	0(,%rax,8), %r13
	movq	(%rbx), %rax
	movl	6824(%rax), %eax
	cltq
	addq	$2, %rax
	leaq	0(,%rax,8), %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %edi
	movl	$0, %edx
	divq	%rdi
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	addq	$3, %rax
	shrq	$2, %rax
	salq	$2, %rax
	movq	%rax, -56(%rbp)
	.loc 2 1113 7 is_stmt 0 discriminator 1
	movq	(%rbx), %rax
	movl	6824(%rax), %edx
	movq	-56(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_output_profile__scalar_flowIP
	.loc 2 1115 27 is_stmt 1
	movq	(%rbx), %rax
	movl	17744(%rax), %eax
	testl	%eax, %eax
	setne	%al
	movq	-56(%rbp), %r12
	movzbl	%al, %eax
	movl	%eax, %edi
	call	silver_path_facts__initial@PLT
	movq	%rax, 4(%r12)
	movl	12(%r12), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, 12(%r12)
	.loc 2 1116 24
	movl	-40(%rbp), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovns	%eax, %edx
	movq	(%rbx), %rax
	movl	6824(%rax), %eax
	movl	$0, %ecx
	testl	%eax, %eax
	cmovs	%ecx, %eax
	cmpl	%eax, %edx
	je	.L891
	.loc 2 1116 24 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1116, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Length_Check@PLT
.L891:
	.loc 2 1116 24 discriminator 2
	movq	(%rbx), %rax
	movl	6824(%rax), %edx
	testl	%edx, %edx
	jle	.L892
.LBB212:
	.loc 2 1116 24 discriminator 3
	movl	$1, %eax
.L893:
	.loc 2 1116 24 discriminator 4
	movslq	%eax, %rcx
	movq	-56(%rbp), %rsi
	leaq	1(%rcx), %rdi
	movl	$1, (%rsi,%rdi,8)
	.loc 2 1116 24 discriminator 5
	movq	-56(%rbp), %rsi
	addq	$1, %rcx
	movl	$0, 4(%rsi,%rcx,8)
	.loc 2 1116 24 discriminator 6
	cmpl	%edx, %eax
	je	.L892
	.loc 2 1116 24 discriminator 7
	addl	$1, %eax
	jmp	.L893
.L892:
.LBE212:
	.loc 2 1117 33 is_stmt 1
	movl	-40(%rbp), %eax
	movl	%eax, -60(%rbp)
	.loc 2 1117 11
	cmpl	$0, -60(%rbp)
	jle	.L894
.LBB213:
	.loc 2 1117 11 is_stmt 0 discriminator 1
	movl	$1, -36(%rbp)
.L897:
.LBB214:
	.loc 2 1121 55 is_stmt 1
	cmpl	$341, -36(%rbp)
	jle	.L895
	.loc 2 1121 55 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1121, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L895:
	.loc 2 1121 16 is_stmt 1 discriminator 2
	movl	-40(%rbp), %eax
	cmpl	%eax, -36(%rbp)
	jle	.L896
	.loc 2 1121 16 is_stmt 0 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$1121, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L896:
	.loc 2 1121 32 is_stmt 1 discriminator 4
	movl	-36(%rbp), %eax
	movslq	%eax, %rsi
	movl	-36(%rbp), %eax
	movslq	%eax, %rcx
	movq	(%rbx), %rdx
	movq	-56(%rbp), %rax
	addq	$1, %rcx
	addq	$212, %rsi
	salq	$5, %rsi
	addq	%rsi, %rdx
	movq	20(%rdx), %rdx
	movq	%rdx, (%rax,%rcx,8)
.LBE214:
	.loc 2 1117 11 discriminator 2
	movl	-36(%rbp), %eax
	cmpl	-60(%rbp), %eax
	je	.L894
	.loc 2 1117 11 is_stmt 0 discriminator 3
	addl	$1, -36(%rbp)
	.loc 2 1122 15 is_stmt 1
	jmp	.L897
.L894:
.LBE213:
	.loc 2 1123 7
	movq	(%rbx), %rax
	movl	6824(%rax), %eax
	cltq
	addq	$2, %rax
	salq	$3, %rax
	movl	$4, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rbx
	.loc 2 1123 7 is_stmt 0 discriminator 1
	movq	%rbx, %rdx
	movq	-56(%rbp), %rax
	movq	%rdx, %rcx
	movq	%r13, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 1123 7 discriminator 2
	movq	%rbx, %rax
	.loc 2 1124 8 is_stmt 1
	movq	%r14, %rsp
	leaq	-32(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE74:
	.size	silver_output_profile__initial_flow___wrapped_statements.20, .-silver_output_profile__initial_flow___wrapped_statements.20
	.section	.rodata
	.align 8
.LC123:
	.ascii	"failed postcondition from silver_output_profile.adb:1108"
	.align 8
.LC124:
	.ascii	"failed postcondition from silver_output_profile.adb:1109"
	.align 8
.LC125:
	.ascii	"failed postcondition from silver_output_profile.adb:1110"
	.text
	.align 2
	.globl	silver_output_profile__initial_flow
	.type	silver_output_profile__initial_flow, @function
silver_output_profile__initial_flow:
.LFB73:
	.loc 2 1112 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$88, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -104(%rbp)
	.loc 2 1112 4
	leaq	16(%rbp), %rax
	.loc 2 1112 4 is_stmt 0 discriminator 1
	movq	%rax, -72(%rbp)
	movq	-104(%rbp), %rax
	movq	%rax, -80(%rbp)
.LBB215:
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__initial_flow___wrapped_statements.20
	movq	%rax, %rbx
.LBB216:
	.loc 2 1108 42 is_stmt 1
	movl	(%rbx), %edx
	.loc 2 1108 42 is_stmt 0 discriminator 1
	movq	-80(%rbp), %rax
	movl	6824(%rax), %eax
	.loc 2 1108 16 is_stmt 1 discriminator 1
	cmpl	%eax, %edx
	je	.L900
.LBB217:
	.loc 2 1108 16 is_stmt 0 discriminator 2
	leaq	.LC123(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rsi
	movq	-120(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L900:
.LBE217:
	.loc 2 1109 51 is_stmt 1
	movq	-80(%rbp), %rax
	movl	17744(%rax), %eax
	testl	%eax, %eax
	setne	%al
	movzbl	%al, %eax
	movl	%eax, %edi
	call	silver_path_facts__initial@PLT
	movq	%rax, -92(%rbp)
	movl	-84(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -84(%rbp)
	.loc 2 1109 51 is_stmt 0 discriminator 1
	leaq	-92(%rbp), %rax
	.loc 2 1109 44 is_stmt 1 discriminator 1
	movl	4(%rbx), %ecx
	.loc 2 1109 44 is_stmt 0 discriminator 2
	movl	(%rax), %edx
	.loc 2 1109 44 discriminator 3
	cmpl	%edx, %ecx
	jne	.L901
	.loc 2 1109 44 discriminator 4
	movl	8(%rbx), %ecx
	.loc 2 1109 44 discriminator 5
	movl	4(%rax), %edx
	.loc 2 1109 44 discriminator 6
	cmpl	%edx, %ecx
	jne	.L901
	.loc 2 1109 44 discriminator 7
	movzbl	12(%rbx), %ecx
	.loc 2 1109 44 discriminator 8
	movzbl	8(%rax), %edx
	.loc 2 1109 44 discriminator 9
	cmpb	%dl, %cl
	jne	.L901
	.loc 2 1109 44 discriminator 10
	movzbl	13(%rbx), %ecx
	.loc 2 1109 44 discriminator 11
	movzbl	9(%rax), %edx
	.loc 2 1109 44 discriminator 12
	cmpb	%dl, %cl
	jne	.L901
	.loc 2 1109 44 discriminator 13
	movzbl	14(%rbx), %edx
	.loc 2 1109 44 discriminator 14
	movzbl	10(%rax), %eax
	.loc 2 1109 44 discriminator 15
	cmpb	%al, %dl
	jne	.L901
	.loc 2 1109 44 discriminator 16
	movl	$1, %eax
	jmp	.L902
.L901:
	.loc 2 1109 44 discriminator 17
	movl	$0, %eax
.L902:
	.loc 2 1109 44 discriminator 18
	xorl	$1, %eax
	.loc 2 1108 16 is_stmt 1 discriminator 3
	testb	%al, %al
	je	.L903
.LBB218:
	.loc 2 1108 16 is_stmt 0 discriminator 4
	leaq	.LC124(%rip), %r14
	leaq	.LC6(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L903:
.LBE218:
	.loc 2 1110 20 is_stmt 1
	movl	$1, %esi
	.loc 2 1110 28
	movl	(%rbx), %eax
	.loc 2 1110 28 is_stmt 0 discriminator 1
	movl	%eax, -56(%rbp)
	.loc 2 1110 20 is_stmt 1 discriminator 1
	cmpl	$0, -56(%rbp)
	jle	.L904
.LBB219:
	.loc 2 1110 28 discriminator 2
	movl	$1, -52(%rbp)
.L910:
	.loc 2 1111 31
	movl	(%rbx), %eax
	.loc 2 1111 31 is_stmt 0 discriminator 1
	cmpl	%eax, -52(%rbp)
	jle	.L905
	.loc 2 1111 31 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$1111, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L905:
	.loc 2 1111 69 is_stmt 1 discriminator 3
	cmpl	$341, -52(%rbp)
	jle	.L906
	.loc 2 1111 69 is_stmt 0 discriminator 4
	leaq	.LC12(%rip), %rax
	movl	$1111, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L906:
	.loc 2 1111 47 is_stmt 1 discriminator 5
	movl	-52(%rbp), %eax
	cltq
	addq	$1, %rax
	movl	(%rbx,%rax,8), %edx
	.loc 2 1111 47 is_stmt 0 discriminator 6
	movl	-52(%rbp), %eax
	movslq	%eax, %rcx
	movq	-80(%rbp), %rax
	addq	$212, %rcx
	salq	$5, %rcx
	addq	%rcx, %rax
	addq	$20, %rax
	movl	(%rax), %eax
	.loc 2 1110 20 is_stmt 1 discriminator 3
	cmpl	%eax, %edx
	jne	.L907
	.loc 2 1111 47 discriminator 8
	movl	-52(%rbp), %eax
	cltq
	addq	$1, %rax
	movl	4(%rbx,%rax,8), %edx
	.loc 2 1111 47 is_stmt 0 discriminator 9
	movl	-52(%rbp), %eax
	movslq	%eax, %rcx
	movq	-80(%rbp), %rax
	addq	$212, %rcx
	salq	$5, %rcx
	addq	%rcx, %rax
	addq	$24, %rax
	movl	(%rax), %eax
	.loc 2 1111 47 discriminator 10
	cmpl	%eax, %edx
	je	.L908
.L907:
	.loc 2 1110 20 is_stmt 1 discriminator 4
	movl	$0, %esi
	jmp	.L904
.L908:
	.loc 2 1110 20 is_stmt 0 discriminator 5
	movl	-52(%rbp), %eax
	cmpl	-56(%rbp), %eax
	je	.L904
	.loc 2 1110 20 discriminator 6
	addl	$1, -52(%rbp)
	jmp	.L910
.L904:
.LBE219:
	.loc 2 1110 20 discriminator 7
	movl	%esi, %eax
	xorl	$1, %eax
	.loc 2 1108 16 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L912
.LBB220:
	.loc 2 1108 16 is_stmt 0 discriminator 6
	leaq	.LC125(%rip), %r12
	leaq	.LC6(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L912:
.LBE220:
.LBE216:
	.loc 2 1112 4 is_stmt 1 discriminator 5
	movq	%rbx, %rax
.LBE215:
	.loc 2 1112 4 is_stmt 0
	addq	$88, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE73:
	.size	silver_output_profile__initial_flow, .-silver_output_profile__initial_flow
	.align 2
	.type	silver_output_profile__body_of, @function
silver_output_profile__body_of:
.LFB75:
	.loc 2 1134 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r12
	pushq	%rbx
	subq	$17792, %rsp
	.cfi_offset 12, -24
	.cfi_offset 3, -32
	movq	%rdi, -17800(%rbp)
.LBB221:
	.loc 2 1136 14
	movq	-17800(%rbp), %rax
	movl	6828(%rax), %eax
	movl	%eax, -20(%rbp)
	movl	-20(%rbp), %eax
	cltq
	movq	%rax, -32(%rbp)
	movq	-17800(%rbp), %rax
	movl	6828(%rax), %eax
	cltq
	addq	$2, %rax
	leaq	0(,%rax,8), %r12
	movq	-17800(%rbp), %rax
	movl	6828(%rax), %eax
	cltq
	salq	$3, %rax
	addq	$36, %rax
	movl	$4, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_allocate@PLT
	.loc 2 1136 14 is_stmt 0 discriminator 1
	movq	%rax, %rbx
	movq	%rbx, -40(%rbp)
	movq	-17800(%rbp), %rax
	movl	6828(%rax), %eax
	movl	%eax, %esi
	movq	%rbx, %rdi
	call	silver_output_profile__body_scanIP
.LBB222:
	.loc 2 1137 40 is_stmt 1
	leaq	-17792(%rbp), %rax
	movq	-17800(%rbp), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__context_of
	.loc 2 1137 26 discriminator 1
	leaq	-17792(%rbp), %rax
	movq	%rax, %rdi
	call	silver_output_profile__initial_flow
	.loc 2 1137 26 is_stmt 0 discriminator 2
	movl	(%rax), %ecx
	.loc 2 1137 26 discriminator 3
	movq	-17800(%rbp), %rdx
	movl	6828(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L914
	.loc 2 1137 26 discriminator 4
	leaq	.LC12(%rip), %rax
	movl	$1137, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L914:
	.loc 2 1137 23 is_stmt 1 discriminator 5
	leaq	20(%rbx), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE222:
	.loc 2 1138 26
	movq	-17800(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, 4(%rbx)
	.loc 2 1139 24
	movq	-17800(%rbp), %rax
	movl	17752(%rax), %eax
	movl	%eax, 8(%rbx)
	.loc 2 1140 26
	movq	-17800(%rbp), %rax
	movl	17756(%rax), %eax
	movl	%eax, 12(%rbx)
	.loc 2 1141 26
	movq	-17800(%rbp), %rax
	movzbl	17760(%rax), %eax
	movb	%al, 16(%rbx)
	.loc 2 1142 24
	movq	-17800(%rbp), %rax
	movzbl	17761(%rax), %eax
	movb	%al, 17(%rbx)
	.loc 2 1136 7 discriminator 3
	movq	%rbx, %rax
.LBE221:
	.loc 2 1144 8
	addq	$17792, %rsp
	popq	%rbx
	popq	%r12
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE75:
	.size	silver_output_profile__body_of, .-silver_output_profile__body_of
	.align 2
	.globl	silver_output_profile__invalid_body
	.type	silver_output_profile__invalid_body, @function
silver_output_profile__invalid_body:
.LFB76:
	.loc 2 1153 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r12
	pushq	%rbx
	subq	$48, %rsp
	.cfi_offset 12, -24
	.cfi_offset 3, -32
	movq	%rdi, -56(%rbp)
.LBB223:
	.loc 2 1155 14
	movq	-56(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -20(%rbp)
	movl	-20(%rbp), %eax
	cltq
	movq	%rax, -32(%rbp)
	movq	-56(%rbp), %rax
	movl	(%rax), %eax
	cltq
	addq	$2, %rax
	leaq	0(,%rax,8), %r12
	movq	-56(%rbp), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	addq	$36, %rax
	movl	$4, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_allocate@PLT
	.loc 2 1155 14 is_stmt 0 discriminator 1
	movq	%rax, %rbx
	movq	%rbx, -40(%rbp)
	movq	-56(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, %esi
	movq	%rbx, %rdi
	call	silver_output_profile__body_scanIP
.LBB224:
	.loc 2 1156 30 is_stmt 1
	movq	-56(%rbp), %rax
	movl	20(%rax), %edx
	movq	-56(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L917
	.loc 2 1156 30 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1156, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L917:
	.loc 2 1156 23 is_stmt 1 discriminator 2
	movq	-56(%rbp), %rax
	leaq	20(%rax), %rdx
	leaq	20(%rbx), %rax
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 1157 28
	movl	$0, 24(%rbx)
	movl	$0, 28(%rbx)
	movb	$0, 32(%rbx)
	movb	$0, 33(%rbx)
	movb	$1, 34(%rbx)
	.loc 2 1158 26
	movl	$0, 4(%rbx)
	.loc 2 1159 24
	movl	$0, 8(%rbx)
	.loc 2 1160 26
	movl	$0, 12(%rbx)
	.loc 2 1161 26
	movb	$0, 16(%rbx)
	.loc 2 1162 24
	movb	$0, 17(%rbx)
.LBE224:
	.loc 2 1155 7 discriminator 3
	movq	%rbx, %rax
.LBE223:
	.loc 2 1164 8
	addq	$48, %rsp
	popq	%rbx
	popq	%r12
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE76:
	.size	silver_output_profile__invalid_body, .-silver_output_profile__invalid_body
	.section	.rodata
	.align 8
.LC126:
	.ascii	"failed precondition from silver_output_profile.adb:1172"
	.text
	.align 2
	.globl	silver_output_profile__valid_context
	.type	silver_output_profile__valid_context, @function
silver_output_profile__valid_context:
.LFB77:
	.loc 2 1173 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 3, -24
	movq	%rdi, %rax
	movq	%rsi, %r10
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r10, %rdi
	movq	%rsi, -48(%rbp)
	movq	%rdi, -40(%rbp)
	movq	%rdx, -56(%rbp)
	.loc 2 1173 4
	movq	-40(%rbp), %rax
	movl	(%rax), %r10d
	movq	-40(%rbp), %rax
	movl	4(%rax), %edx
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L920
	.loc 2 1173 4 is_stmt 0 discriminator 1
	movq	-40(%rbp), %rax
	movl	4(%rax), %esi
	movslq	%esi, %rax
	cqto
	movq	-40(%rbp), %rsi
	movl	(%rsi), %r11d
	movslq	%r11d, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L921
.L920:
	.loc 2 1173 4 discriminator 2
	movl	$0, %eax
	movl	$0, %edx
.L921:
.LBB225:
	.loc 2 1172 15 is_stmt 1
	cmpl	$1, %r10d
	je	.L922
.LBB226:
	.loc 2 1172 15 is_stmt 0 discriminator 1
	leaq	.LC126(%rip), %r8
	leaq	.LC1(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L922:
.LBE226:
	.loc 2 1172 51 is_stmt 1 discriminator 2
	movl	%eax, %esi
	.loc 2 1172 15 discriminator 2
	testl	%esi, %esi
	jle	.L923
	.loc 2 1172 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L924
.L923:
.LBB227:
	.loc 2 1172 15 discriminator 4
	leaq	.LC126(%rip), %rcx
	leaq	.LC1(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L924:
.LBE227:
	.loc 2 1174 7
	movq	-56(%rbp), %rdx
	movq	-48(%rbp), %rcx
	movq	-40(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_names
	.loc 2 1181 7
	testb	%al, %al
	je	.L925
	.loc 2 1175 34
	movq	-56(%rbp), %rax
	leaq	6824(%rax), %rdx
	movq	-48(%rbp), %rcx
	movq	-40(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__valid_environment@PLT
	.loc 2 1175 7 discriminator 1
	testb	%al, %al
	je	.L925
	.loc 2 1176 16
	movq	-56(%rbp), %rax
	movl	17740(%rax), %eax
	movq	-56(%rbp), %rdx
	addq	$6824, %rdx
	movl	%eax, %esi
	movq	%rdx, %rdi
	call	silver_output_profile__valid_declaration_values
	.loc 2 1176 7 discriminator 1
	testb	%al, %al
	je	.L925
	.loc 2 1177 16
	movq	-56(%rbp), %rax
	addq	$6824, %rax
	movq	%rax, %rdi
	call	silver_output_profile__valid_mutable_bounds
	.loc 2 1177 7 discriminator 1
	testb	%al, %al
	je	.L925
	.loc 2 1178 17
	movl	$1, %esi
	.loc 2 1178 59
	movq	-56(%rbp), %rax
	movl	6824(%rax), %eax
	movl	%eax, -24(%rbp)
	movl	-24(%rbp), %eax
	cmpl	$341, %eax
	jbe	.L926
	.loc 2 1178 59 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1178, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L926:
.LBB228:
	.loc 2 1178 25 is_stmt 1 discriminator 2
	movl	$1, -20(%rbp)
.L934:
	.loc 2 1178 17 discriminator 3
	movl	-20(%rbp), %eax
	cmpl	-24(%rbp), %eax
	jg	.L927
	.loc 2 1179 10
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movq	-56(%rbp), %rax
	salq	$5, %rdx
	addq	%rdx, %rax
	addq	$6824, %rax
	movzbl	(%rax), %eax
	testb	%al, %al
	je	.L928
	.loc 2 1180 54
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movq	-56(%rbp), %rax
	addq	$212, %rdx
	salq	$5, %rdx
	addq	%rdx, %rax
	addq	$20, %rax
	movl	(%rax), %edx
	movl	-20(%rbp), %eax
	movslq	%eax, %rcx
	movq	-56(%rbp), %rax
	salq	$5, %rcx
	addq	%rcx, %rax
	addq	$6816, %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jne	.L929
	.loc 2 1180 54 is_stmt 0 discriminator 1
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movq	-56(%rbp), %rax
	addq	$212, %rdx
	salq	$5, %rdx
	addq	%rdx, %rax
	addq	$24, %rax
	movl	(%rax), %edx
	movl	-20(%rbp), %eax
	movslq	%eax, %rcx
	movq	-56(%rbp), %rax
	salq	$5, %rcx
	addq	%rcx, %rax
	addq	$6820, %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L930
.L929:
	.loc 2 1180 54 discriminator 2
	movl	$1, %eax
	jmp	.L932
.L930:
	.loc 2 1180 54 discriminator 3
	movl	$0, %eax
	.loc 2 1179 10 is_stmt 1 discriminator 1
	jmp	.L932
.L928:
	.loc 2 1179 10 is_stmt 0 discriminator 2
	movl	$0, %eax
.L932:
	.loc 2 1178 17 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L933
	.loc 2 1178 17 is_stmt 0 discriminator 5
	movl	$0, %esi
	jmp	.L927
.L933:
	.loc 2 1178 17 discriminator 6
	addl	$1, -20(%rbp)
	jmp	.L934
.L927:
.LBE228:
	.loc 2 1178 7 is_stmt 1 discriminator 7
	testb	%sil, %sil
	je	.L925
	.loc 2 1181 16 discriminator 1
	movq	-56(%rbp), %rax
	movl	17748(%rax), %ecx
	movq	-56(%rbp), %rax
	movl	17744(%rax), %edx
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__valid_name_state@PLT
	.loc 2 1181 7 discriminator 2
	testb	%al, %al
	je	.L925
	.loc 2 1181 7 is_stmt 0 discriminator 3
	movl	$1, %eax
	jmp	.L935
.L925:
	.loc 2 1181 7 discriminator 4
	movl	$0, %eax
.L935:
.LBE225:
	.loc 2 1173 4 is_stmt 1
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE77:
	.size	silver_output_profile__valid_context, .-silver_output_profile__valid_context
	.section	.rodata
	.align 8
.LC127:
	.ascii	"failed precondition from silver_output_profile.adb:1198"
	.text
	.align 2
	.globl	silver_output_profile__valid_body
	.type	silver_output_profile__valid_body, @function
silver_output_profile__valid_body:
.LFB78:
	.loc 2 1199 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r12
	pushq	%rbx
	subq	$32, %rsp
	.cfi_offset 12, -24
	.cfi_offset 3, -32
	movq	%rdi, %rax
	movq	%rsi, %rbx
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%rbx, %rdi
	movq	%rsi, -32(%rbp)
	movq	%rdi, -24(%rbp)
	movq	%rdx, -40(%rbp)
	movq	%rcx, -48(%rbp)
	.loc 2 1199 4
	movq	-24(%rbp), %rax
	movl	(%rax), %edi
	movq	-24(%rbp), %rax
	movl	4(%rax), %esi
	movq	-24(%rbp), %rax
	movl	4(%rax), %edx
	movq	-24(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L938
	.loc 2 1199 4 is_stmt 0 discriminator 1
	movq	-24(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-24(%rbp), %rcx
	movl	(%rcx), %r12d
	movslq	%r12d, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L939
.L938:
	.loc 2 1199 4 discriminator 2
	movl	$0, %eax
	movl	$0, %edx
.L939:
.LBB229:
	.loc 2 1198 15 is_stmt 1
	cmpl	$1, %edi
	je	.L940
.LBB230:
	.loc 2 1198 15 is_stmt 0 discriminator 1
	leaq	.LC127(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L940:
.LBE230:
	.loc 2 1198 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 1198 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L941
	.loc 2 1198 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L942
.L941:
.LBB231:
	.loc 2 1198 15 discriminator 4
	leaq	.LC127(%rip), %r8
	leaq	.LC1(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L942:
.LBE231:
	.loc 2 1201 21
	movq	-48(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 1201 34
	cmpl	$2147483647, %esi
	jne	.L943
	.loc 2 1201 34 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1201, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L943:
	.loc 2 1201 34 discriminator 3
	leal	1(%rsi), %edx
	.loc 2 1202 7 is_stmt 1
	cmpl	%eax, %edx
	jl	.L944
	.loc 2 1201 59 discriminator 4
	movq	-48(%rbp), %rax
	movl	8(%rax), %edx
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 1201 38 discriminator 4
	cmpl	%eax, %edx
	jg	.L944
	.loc 2 1202 16 discriminator 1
	movq	-48(%rbp), %rax
	leaq	20(%rax), %rdx
	movq	-40(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__valid_flow
	.loc 2 1202 7 discriminator 2
	testb	%al, %al
	je	.L944
	.loc 2 1202 7 is_stmt 0 discriminator 3
	movl	$1, %eax
	jmp	.L945
.L944:
	.loc 2 1202 7 discriminator 4
	movl	$0, %eax
.L945:
.LBE229:
	.loc 2 1199 4 is_stmt 1
	addq	$32, %rsp
	popq	%rbx
	popq	%r12
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE78:
	.size	silver_output_profile__valid_body, .-silver_output_profile__valid_body
	.section	.rodata
	.align 8
.LC128:
	.ascii	"failed precondition from silver_output_profile.adb:1224"
	.text
	.align 2
	.type	silver_output_profile__join_into, @function
silver_output_profile__join_into:
.LFB79:
	.loc 2 1226 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r12
	pushq	%rbx
	subq	$32, %rsp
	.cfi_offset 12, -24
	.cfi_offset 3, -32
	movq	%rdi, -40(%rbp)
	movq	%rsi, -48(%rbp)
	.loc 2 1224 45
	movq	-40(%rbp), %rcx
	movl	(%rcx), %esi
	movq	-48(%rbp), %rcx
	movl	(%rcx), %ecx
	.loc 2 1224 34
	cmpl	%ecx, %esi
	je	.L948
.LBB232:
	.loc 2 1224 34 is_stmt 0 discriminator 1
	leaq	.LC128(%rip), %rax
	leaq	.LC1(%rip), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L948:
.LBE232:
	.loc 2 1228 25 is_stmt 1
	movq	-40(%rbp), %rbx
	movq	-48(%rbp), %rcx
	movq	4(%rcx), %rax
	movl	12(%rcx), %ecx
	movq	%rcx, %rdx
	movq	-40(%rbp), %rcx
	movq	4(%rcx), %rdi
	movl	12(%rcx), %esi
	movq	%rdx, %rcx
	movq	%rax, %rdx
	call	silver_path_facts__join@PLT
	movq	%rax, 4(%rbx)
	movl	12(%rbx), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, 12(%rbx)
	.loc 2 1229 31
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -24(%rbp)
	.loc 2 1229 11
	cmpl	$0, -24(%rbp)
	jle	.L954
.LBB233:
	.loc 2 1229 11 is_stmt 0 discriminator 1
	movl	$1, -20(%rbp)
.L953:
.LBB234:
	.loc 2 1236 14 is_stmt 1
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, -20(%rbp)
	jle	.L950
	.loc 2 1236 14 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1236, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L950:
	.loc 2 1236 51 is_stmt 1 discriminator 2
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, -20(%rbp)
	jle	.L951
	.loc 2 1236 51 is_stmt 0 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$1236, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L951:
	.loc 2 1236 73 is_stmt 1 discriminator 4
	movq	-48(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, -20(%rbp)
	jle	.L952
	.loc 2 1236 73 is_stmt 0 discriminator 5
	leaq	.LC12(%rip), %rax
	movl	$1236, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L952:
	.loc 2 1236 40 is_stmt 1 discriminator 6
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movl	-20(%rbp), %eax
	movslq	%eax, %rcx
	.loc 2 1236 30 discriminator 6
	movl	-20(%rbp), %eax
	cltq
	.loc 2 1236 40 discriminator 6
	movq	-40(%rbp), %rbx
	leaq	1(%rax), %r12
	movq	-48(%rbp), %rax
	addq	$1, %rdx
	movq	(%rax,%rdx,8), %rdx
	movq	-40(%rbp), %rax
	addq	$1, %rcx
	movq	(%rax,%rcx,8), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_scalars__join@PLT
	movq	%rax, (%rbx,%r12,8)
.LBE234:
	.loc 2 1229 11 discriminator 2
	movl	-20(%rbp), %eax
	cmpl	-24(%rbp), %eax
	je	.L954
	.loc 2 1229 11 is_stmt 0 discriminator 3
	addl	$1, -20(%rbp)
	.loc 2 1237 15 is_stmt 1
	jmp	.L953
.L954:
.LBE233:
	.loc 2 1238 8 discriminator 1
	nop
	.loc 2 1238 8 is_stmt 0
	addq	$32, %rsp
	popq	%rbx
	popq	%r12
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE79:
	.size	silver_output_profile__join_into, .-silver_output_profile__join_into
	.section	.rodata
	.align 8
.LC129:
	.ascii	"Loop_Invariant failed at silver_output_profile.adb:1249"
	.text
	.align 2
	.type	silver_output_profile__widen_into___wrapped_statements.21, @function
silver_output_profile__widen_into___wrapped_statements.21:
.LFB81:
	.loc 2 1246 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$32, %rsp
	.cfi_offset 14, -24
	.cfi_offset 13, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%r10, %rbx
	movq	%r10, -56(%rbp)
	.loc 2 1248 32
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, -40(%rbp)
	.loc 2 1249 51
	cmpl	$0, -40(%rbp)
	jle	.L965
.LBB235:
	.loc 2 1249 51 is_stmt 0 discriminator 1
	movq	%rsp, %rax
	movq	%rax, %r14
	.loc 2 1249 46 is_stmt 1 discriminator 2
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	.loc 2 1249 51 discriminator 2
	movslq	%eax, %rdx
	addq	$2, %rdx
	leaq	0(,%rdx,8), %rsi
	cltq
	addq	$2, %rax
	leaq	0(,%rax,8), %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %edi
	movl	$0, %edx
	divq	%rdi
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	addq	$3, %rax
	shrq	$2, %rax
	salq	$2, %rax
	movq	%rax, -48(%rbp)
	.loc 2 1249 51 is_stmt 0 discriminator 3
	movq	8(%rbx), %rax
	movq	-48(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%rsi, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 1248 11 is_stmt 1 discriminator 1
	cmpl	$0, -40(%rbp)
	jle	.L957
.LBB236:
	.loc 2 1248 11 is_stmt 0 discriminator 2
	movl	$1, -36(%rbp)
.L964:
.LBB237:
	.loc 2 1249 44 is_stmt 1 discriminator 4
	movq	8(%rbx), %rax
	movl	4(%rax), %edx
	movq	-48(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 1249 33 discriminator 4
	cmpl	%eax, %edx
	jne	.L958
	.loc 2 1249 44 discriminator 5
	movq	8(%rbx), %rax
	movl	8(%rax), %edx
	movq	-48(%rbp), %rax
	movl	8(%rax), %eax
	cmpl	%eax, %edx
	jne	.L958
	.loc 2 1249 44 is_stmt 0 discriminator 6
	movq	8(%rbx), %rax
	movzbl	12(%rax), %edx
	movq	-48(%rbp), %rax
	movzbl	12(%rax), %eax
	cmpb	%al, %dl
	jne	.L958
	.loc 2 1249 44 discriminator 7
	movq	8(%rbx), %rax
	movzbl	13(%rax), %edx
	movq	-48(%rbp), %rax
	movzbl	13(%rax), %eax
	cmpb	%al, %dl
	jne	.L958
	.loc 2 1249 44 discriminator 8
	movq	8(%rbx), %rax
	movzbl	14(%rax), %edx
	movq	-48(%rbp), %rax
	movzbl	14(%rax), %eax
	cmpb	%al, %dl
	je	.L959
.L958:
.LBB238:
	.loc 2 1249 33 is_stmt 1 discriminator 9
	leaq	.LC129(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L959:
.LBE238:
	.loc 2 1258 33
	cmpl	$341, -36(%rbp)
	jle	.L960
	.loc 2 1258 33 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1258, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L960:
	.loc 2 1258 10 is_stmt 1 discriminator 2
	movl	-36(%rbp), %eax
	movslq	%eax, %rdx
	movq	(%rbx), %rax
	salq	$5, %rdx
	addq	%rdx, %rax
	addq	$6824, %rax
	movzbl	(%rax), %eax
	.loc 2 1258 10 is_stmt 0 discriminator 3
	testb	%al, %al
	je	.L961
	.loc 2 1259 57 is_stmt 1
	cmpl	$341, -36(%rbp)
	jle	.L962
	.loc 2 1259 57 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1259, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L962:
	.loc 2 1259 18 is_stmt 1 discriminator 2
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, -36(%rbp)
	jle	.L963
	.loc 2 1259 18 is_stmt 0 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$1259, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L963:
	.loc 2 1259 34 is_stmt 1 discriminator 4
	movl	-36(%rbp), %eax
	movslq	%eax, %rsi
	movl	-36(%rbp), %eax
	movslq	%eax, %rcx
	movq	(%rbx), %rdx
	movq	8(%rbx), %rax
	addq	$1, %rcx
	salq	$5, %rsi
	addq	%rsi, %rdx
	addq	$6800, %rdx
	movq	16(%rdx), %rdx
	movq	%rdx, (%rax,%rcx,8)
.L961:
.LBE237:
	.loc 2 1248 11 discriminator 3
	movl	-36(%rbp), %eax
	cmpl	-40(%rbp), %eax
	je	.L957
	.loc 2 1248 11 is_stmt 0 discriminator 4
	addl	$1, -36(%rbp)
	.loc 2 1261 15 is_stmt 1
	jmp	.L964
.L957:
.LBE236:
	.loc 2 1249 0 discriminator 10
	movq	%r14, %rsp
.L965:
.LBE235:
	.loc 2 1262 8 discriminator 1
	nop
	.loc 2 1262 8 is_stmt 0
	leaq	-32(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE81:
	.size	silver_output_profile__widen_into___wrapped_statements.21, .-silver_output_profile__widen_into___wrapped_statements.21
	.section	.rodata
	.align 8
.LC130:
	.ascii	"failed precondition from silver_output_profile.adb:1240"
	.align 8
.LC131:
	.ascii	"failed postcondition from silver_output_profile.adb:1241"
	.align 8
.LC132:
	.ascii	"failed postcondition from silver_output_profile.adb:1242"
	.text
	.align 2
	.type	silver_output_profile__widen_into, @function
silver_output_profile__widen_into:
.LFB80:
	.loc 2 1246 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$168, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -120(%rbp)
	movq	%rsi, -128(%rbp)
	.loc 2 1246 4
	leaq	16(%rbp), %rax
	.loc 2 1246 4 is_stmt 0 discriminator 1
	movq	%rax, -96(%rbp)
	movq	-120(%rbp), %rax
	movq	%rax, -112(%rbp)
	movq	-128(%rbp), %rax
	movq	%rax, -104(%rbp)
	movq	%rsp, %rax
	movq	%rax, -200(%rbp)
	.loc 2 1240 46 is_stmt 1
	movq	-104(%rbp), %rax
	movl	(%rax), %edx
	movq	-112(%rbp), %rax
	movl	6824(%rax), %eax
	.loc 2 1240 34
	cmpl	%eax, %edx
	je	.L967
.LBB239:
	.loc 2 1240 34 is_stmt 0 discriminator 1
	leaq	.LC130(%rip), %rcx
	leaq	.LC1(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L967:
.LBE239:
	.loc 2 1241 29 is_stmt 1
	movq	-104(%rbp), %rax
	movl	(%rax), %edx
	.loc 2 1241 34
	movslq	%edx, %rax
	addq	$2, %rax
	leaq	0(,%rax,8), %rsi
	movslq	%edx, %rax
	addq	$2, %rax
	leaq	0(,%rax,8), %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %ebx
	movl	$0, %edx
	divq	%rbx
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	addq	$3, %rax
	shrq	$2, %rax
	salq	$2, %rax
	movq	%rax, -64(%rbp)
	.loc 2 1241 34 is_stmt 0 discriminator 1
	movq	-104(%rbp), %rdx
	movq	-64(%rbp), %rax
	movq	%rax, %rdi
	movq	%rdx, %rcx
	movq	%rsi, %rax
	movq	%rax, %rdx
	movq	%rcx, %rsi
	call	memcpy@PLT
	.loc 2 1245 76 is_stmt 1
	movq	-104(%rbp), %rax
	movl	(%rax), %ebx
	.loc 2 1245 81
	movslq	%ebx, %rax
	addq	$2, %rax
	leaq	0(,%rax,8), %rsi
	movslq	%ebx, %rax
	addq	$2, %rax
	leaq	0(,%rax,8), %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %ecx
	movl	$0, %edx
	divq	%rcx
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	addq	$3, %rax
	shrq	$2, %rax
	salq	$2, %rax
	movq	%rax, -72(%rbp)
	.loc 2 1245 81 is_stmt 0 discriminator 1
	movq	-104(%rbp), %rdx
	movq	-72(%rbp), %rax
	movq	%rax, %rdi
	movq	%rdx, %rcx
	movq	%rsi, %rax
	movq	%rax, %rdx
	movq	%rcx, %rsi
	call	memcpy@PLT
	.loc 2 1246 4 is_stmt 1 discriminator 2
	leaq	-112(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__widen_into___wrapped_statements.21
	.loc 2 1241 27 discriminator 2
	movq	-104(%rbp), %rax
	movl	4(%rax), %edx
	movq	-64(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 1241 16 discriminator 2
	cmpl	%eax, %edx
	je	.L968
.LBB240:
	.loc 2 1241 16 is_stmt 0 discriminator 3
	leaq	.LC131(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L968:
.LBE240:
	.loc 2 1241 27 is_stmt 1 discriminator 4
	movq	-104(%rbp), %rax
	movl	8(%rax), %edx
	movq	-64(%rbp), %rax
	movl	8(%rax), %eax
	.loc 2 1241 16 discriminator 4
	cmpl	%eax, %edx
	je	.L969
.LBB241:
	.loc 2 1241 16 is_stmt 0 discriminator 5
	leaq	.LC131(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L969:
.LBE241:
	.loc 2 1241 27 is_stmt 1 discriminator 6
	movq	-104(%rbp), %rax
	movzbl	12(%rax), %edx
	movq	-64(%rbp), %rax
	movzbl	12(%rax), %eax
	.loc 2 1241 16 discriminator 6
	cmpb	%al, %dl
	je	.L970
.LBB242:
	.loc 2 1241 16 is_stmt 0 discriminator 7
	leaq	.LC131(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L970:
.LBE242:
	.loc 2 1241 27 is_stmt 1 discriminator 8
	movq	-104(%rbp), %rax
	movzbl	13(%rax), %edx
	movq	-64(%rbp), %rax
	movzbl	13(%rax), %eax
	.loc 2 1241 16 discriminator 8
	cmpb	%al, %dl
	je	.L971
.LBB243:
	.loc 2 1241 16 is_stmt 0 discriminator 9
	leaq	.LC131(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L971:
.LBE243:
	.loc 2 1241 27 is_stmt 1 discriminator 10
	movq	-104(%rbp), %rax
	movzbl	14(%rax), %edx
	movq	-64(%rbp), %rax
	movzbl	14(%rax), %eax
	.loc 2 1241 16 discriminator 10
	cmpb	%al, %dl
	je	.L972
.LBB244:
	.loc 2 1241 16 is_stmt 0 discriminator 11
	leaq	.LC131(%rip), %r14
	leaq	.LC6(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L972:
.LBE244:
	.loc 2 1242 20 is_stmt 1
	movl	$1, %esi
	.loc 2 1242 49
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -76(%rbp)
	.loc 2 1242 20
	cmpl	$0, -76(%rbp)
	jle	.L973
.LBB245:
	.loc 2 1242 28 discriminator 1
	movl	$1, -52(%rbp)
.L983:
.LBB246:
	.loc 2 1244 38
	cmpl	$341, -52(%rbp)
	jle	.L974
	.loc 2 1244 38 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1244, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L974:
	.loc 2 1243 17 is_stmt 1
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, -52(%rbp)
	jle	.L975
	.loc 2 1243 17 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1243, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L975:
	.loc 2 1244 15 is_stmt 1 discriminator 2
	movl	-52(%rbp), %eax
	movslq	%eax, %rdx
	movq	-112(%rbp), %rax
	salq	$5, %rdx
	addq	%rdx, %rax
	addq	$6824, %rax
	movzbl	(%rax), %eax
	.loc 2 1244 15 is_stmt 0 discriminator 3
	testb	%al, %al
	je	.L976
	.loc 2 1245 40 is_stmt 1 discriminator 2
	cmpl	$341, -52(%rbp)
	jle	.L977
	.loc 2 1245 40 is_stmt 0 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$1245, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L977:
	.loc 2 1244 15 is_stmt 1 discriminator 4
	movl	-52(%rbp), %eax
	movslq	%eax, %rdx
	movq	-112(%rbp), %rax
	salq	$5, %rdx
	addq	%rdx, %rax
	addq	$6800, %rax
	movq	16(%rax), %rax
	movq	%rax, -84(%rbp)
	jmp	.L978
.L976:
	.loc 2 1245 85 discriminator 4
	cmpl	%ebx, -52(%rbp)
	jle	.L979
	.loc 2 1245 85 is_stmt 0 discriminator 5
	leaq	.LC12(%rip), %rax
	movl	$1245, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L979:
	.loc 2 1244 15 is_stmt 1 discriminator 5
	movl	-52(%rbp), %eax
	movslq	%eax, %rdx
	movq	-72(%rbp), %rax
	addq	$1, %rdx
	movq	(%rax,%rdx,8), %rax
	movq	%rax, -84(%rbp)
.L978:
	.loc 2 1244 15 is_stmt 0 discriminator 6
	leaq	-84(%rbp), %rax
	.loc 2 1243 33 is_stmt 1 discriminator 2
	movl	-52(%rbp), %edx
	movslq	%edx, %rcx
	movq	-104(%rbp), %rdx
	addq	$1, %rcx
	movl	(%rdx,%rcx,8), %ecx
	.loc 2 1243 33 is_stmt 0 discriminator 3
	movl	(%rax), %edx
	.loc 2 1242 20 is_stmt 1 discriminator 2
	cmpl	%edx, %ecx
	jne	.L980
	.loc 2 1243 33 discriminator 5
	movl	-52(%rbp), %edx
	movslq	%edx, %rcx
	movq	-104(%rbp), %rdx
	addq	$1, %rcx
	movl	4(%rdx,%rcx,8), %edx
	.loc 2 1243 33 is_stmt 0 discriminator 6
	movl	4(%rax), %eax
	.loc 2 1243 33 discriminator 7
	cmpl	%eax, %edx
	je	.L981
.L980:
	.loc 2 1242 20 is_stmt 1 discriminator 3
	movl	$0, %esi
	jmp	.L973
.L981:
.LBE246:
	.loc 2 1242 20 is_stmt 0 discriminator 4
	movl	-52(%rbp), %eax
	cmpl	-76(%rbp), %eax
	je	.L973
	.loc 2 1242 20 discriminator 5
	addl	$1, -52(%rbp)
	jmp	.L983
.L973:
.LBE245:
	.loc 2 1242 20 discriminator 6
	movl	%esi, %eax
	xorl	$1, %eax
	.loc 2 1241 16 is_stmt 1 discriminator 12
	testb	%al, %al
	je	.L986
.LBB247:
	.loc 2 1241 16 is_stmt 0 discriminator 13
	leaq	.LC132(%rip), %r12
	leaq	.LC6(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L986:
.LBE247:
	.loc 2 1246 4 is_stmt 1 discriminator 4
	movq	-200(%rbp), %rsp
	.loc 2 1246 4 is_stmt 0
	leaq	-40(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE80:
	.size	silver_output_profile__widen_into, .-silver_output_profile__widen_into
	.section	.rodata
	.align 8
.LC133:
	.ascii	"Loop_Invariant failed at silver_output_profile.adb:1279"
	.text
	.align 2
	.type	silver_output_profile__reading_names___wrapped_statements.22, @function
silver_output_profile__reading_names___wrapped_statements.22:
.LFB83:
	.loc 2 1274 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$10952, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, -10968(%rbp)
	movq	%r10, %rbx
	movq	%r10, -10976(%rbp)
	.loc 2 1276 7
	movq	8(%rbx), %rdx
	leaq	-10960(%rbp), %rax
	leaq	6824(%rdx), %rcx
	movl	$10916, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 1278 11
	movq	(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, -40(%rbp)
	cmpl	$0, -40(%rbp)
	jle	.L988
.LBB248:
	.loc 2 1278 11 is_stmt 0 discriminator 1
	movl	$1, -36(%rbp)
.L995:
	.loc 2 1279 46 is_stmt 1
	movl	-10960(%rbp), %edx
	movq	8(%rbx), %rax
	movl	6824(%rax), %eax
	.loc 2 1279 33
	cmpl	%eax, %edx
	je	.L989
.LBB249:
	.loc 2 1279 33 is_stmt 0 discriminator 1
	leaq	.LC133(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L989:
.LBE249:
	.loc 2 1286 19 is_stmt 1
	cmpl	$341, -36(%rbp)
	jle	.L990
	.loc 2 1286 19 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1286, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L990:
	.loc 2 1286 10 is_stmt 1 discriminator 2
	movl	-36(%rbp), %eax
	cltq
	salq	$5, %rax
	leaq	-32(%rax), %rax
	addq	%rbp, %rax
	subq	$10928, %rax
	movzbl	(%rax), %eax
	.loc 2 1286 10 is_stmt 0 discriminator 3
	testb	%al, %al
	jne	.L991
	.loc 2 1286 56 is_stmt 1 discriminator 4
	movq	8(%rbx), %rax
	movl	17740(%rax), %eax
	.loc 2 1286 42 discriminator 4
	cmpl	%eax, -36(%rbp)
	jle	.L992
.L991:
	.loc 2 1287 19
	cmpl	$341, -36(%rbp)
	jle	.L993
	.loc 2 1287 19 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1287, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L993:
	.loc 2 1287 49 is_stmt 1 discriminator 2
	movq	(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, -36(%rbp)
	jle	.L994
	.loc 2 1287 49 is_stmt 0 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$1287, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L994:
	.loc 2 1287 41 is_stmt 1 discriminator 4
	movl	-36(%rbp), %eax
	movslq	%eax, %rcx
	movl	-36(%rbp), %eax
	movslq	%eax, %rdx
	movq	(%rbx), %rax
	subq	$1, %rdx
	salq	$5, %rdx
	leaq	-32(%rdx), %rsi
	leaq	(%rsi,%rbp), %rdx
	subq	$10928, %rdx
	addq	$1, %rcx
	movq	(%rax,%rcx,8), %rax
	movq	%rax, 12(%rdx)
.L992:
	.loc 2 1278 11 discriminator 2
	movl	-36(%rbp), %eax
	cmpl	-40(%rbp), %eax
	je	.L988
	.loc 2 1278 11 is_stmt 0 discriminator 3
	addl	$1, -36(%rbp)
	.loc 2 1289 15 is_stmt 1
	jmp	.L995
.L988:
.LBE248:
	.loc 2 1290 7
	movq	-10968(%rbp), %rax
	movq	%rax, %rcx
	leaq	-10960(%rbp), %rax
	movl	$10916, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 1291 8
	movq	-10968(%rbp), %rax
	addq	$10952, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE83:
	.size	silver_output_profile__reading_names___wrapped_statements.22, .-silver_output_profile__reading_names___wrapped_statements.22
	.section	.rodata
	.align 8
.LC134:
	.ascii	"failed precondition from silver_output_profile.adb:1266"
	.align 8
.LC135:
	.ascii	"failed postcondition from silver_output_profile.adb:1267"
	.align 8
.LC136:
	.ascii	"failed postcondition from silver_output_profile.adb:1268"
	.text
	.align 2
	.type	silver_output_profile__reading_names, @function
silver_output_profile__reading_names:
.LFB82:
	.loc 2 1274 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$11080, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -11096(%rbp)
	movq	%rsi, -11104(%rbp)
	movq	%rdx, -11112(%rbp)
	.loc 2 1274 4
	leaq	16(%rbp), %rax
	.loc 2 1274 4 is_stmt 0 discriminator 1
	movq	%rax, -112(%rbp)
	movq	-11104(%rbp), %rax
	movq	%rax, -120(%rbp)
	movq	-11112(%rbp), %rax
	movq	%rax, -128(%rbp)
	.loc 2 1266 46 is_stmt 1
	movq	-128(%rbp), %rax
	movl	(%rax), %edx
	movq	-120(%rbp), %rax
	movl	6824(%rax), %eax
	.loc 2 1266 34
	cmpl	%eax, %edx
	je	.L998
.LBB250:
	.loc 2 1266 34 is_stmt 0 discriminator 1
	leaq	.LC134(%rip), %rcx
	leaq	.LC1(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L998:
.LBE250:
.LBB251:
	.loc 2 1274 4 is_stmt 1 discriminator 2
	leaq	-11056(%rbp), %rax
	leaq	-128(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_output_profile__reading_names___wrapped_statements.22
.LBB252:
	.loc 2 1267 43
	movl	-11056(%rbp), %edx
	movq	-120(%rbp), %rax
	movl	6824(%rax), %eax
	.loc 2 1267 16
	cmpl	%eax, %edx
	je	.L999
.LBB253:
	.loc 2 1267 16 is_stmt 0 discriminator 1
	leaq	.LC135(%rip), %r14
	leaq	.LC6(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L999:
.LBE253:
	.loc 2 1268 20 is_stmt 1
	movl	$1, %esi
.LBB254:
	.loc 2 1268 28
	movl	$1, -52(%rbp)
.L1007:
	.loc 2 1268 20 discriminator 1
	cmpl	$341, -52(%rbp)
	jg	.L1000
.LBB255:
	.loc 2 1270 24
	movq	-128(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 1270 15
	cmpl	%eax, -52(%rbp)
	jg	.L1001
	.loc 2 1271 16
	movl	-52(%rbp), %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	salq	$5, %rdx
	addq	%rdx, %rax
	addq	$6824, %rax
	movzbl	(%rax), %eax
	.loc 2 1271 16 is_stmt 0 discriminator 1
	testb	%al, %al
	jne	.L1002
	.loc 2 1271 83 is_stmt 1 discriminator 2
	movq	-120(%rbp), %rax
	movl	17740(%rax), %eax
	.loc 2 1271 69 discriminator 2
	cmpl	%eax, -52(%rbp)
	jle	.L1001
.L1002:
	.loc 2 1272 82
	movq	-128(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, -52(%rbp)
	jle	.L1003
	.loc 2 1272 82 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1272, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1003:
	.loc 2 1272 20 is_stmt 1 discriminator 2
	movl	-52(%rbp), %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	addq	$212, %rdx
	salq	$5, %rdx
	leaq	(%rax,%rdx), %rcx
	movq	12(%rcx), %rax
	movq	20(%rcx), %rdx
	movq	%rax, -11088(%rbp)
	movq	%rdx, -11080(%rbp)
	movq	28(%rcx), %rax
	movq	36(%rcx), %rdx
	movq	%rax, -11072(%rbp)
	movq	%rdx, -11064(%rbp)
	.loc 2 1272 67 discriminator 3
	movl	-52(%rbp), %eax
	movslq	%eax, %rdx
	movq	-128(%rbp), %rax
	addq	$1, %rdx
	movq	(%rax,%rdx,8), %rax
	movq	%rax, -11080(%rbp)
	.loc 2 1270 15 discriminator 1
	movq	-11088(%rbp), %rax
	movq	-11080(%rbp), %rdx
	movq	%rax, -96(%rbp)
	movq	%rdx, -88(%rbp)
	movq	-11072(%rbp), %rax
	movq	-11064(%rbp), %rdx
	movq	%rax, -80(%rbp)
	movq	%rdx, -72(%rbp)
	jmp	.L1004
.L1001:
	.loc 2 1270 15 is_stmt 0 discriminator 2
	movl	-52(%rbp), %eax
	movslq	%eax, %rdx
	movq	-120(%rbp), %rax
	addq	$212, %rdx
	salq	$5, %rdx
	leaq	(%rax,%rdx), %rcx
	movq	12(%rcx), %rax
	movq	20(%rcx), %rdx
	movq	%rax, -96(%rbp)
	movq	%rdx, -88(%rbp)
	movq	28(%rcx), %rax
	movq	36(%rcx), %rdx
	movq	%rax, -80(%rbp)
	movq	%rdx, -72(%rbp)
.L1004:
	.loc 2 1270 15 discriminator 3
	leaq	-96(%rbp), %rax
	.loc 2 1269 47 is_stmt 1
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	subq	$1, %rdx
	salq	$5, %rdx
	leaq	-48(%rdx), %rbx
	leaq	(%rbx,%rbp), %rdx
	subq	$11004, %rdx
	movl	(%rdx), %ecx
	.loc 2 1269 47 is_stmt 0 discriminator 1
	movl	(%rax), %edx
	.loc 2 1268 20 is_stmt 1 discriminator 2
	cmpl	%edx, %ecx
	jne	.L1005
	.loc 2 1269 47 discriminator 3
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	subq	$1, %rdx
	salq	$5, %rdx
	leaq	-48(%rdx), %rbx
	leaq	(%rbx,%rbp), %rdx
	subq	$11000, %rdx
	movl	(%rdx), %ecx
	.loc 2 1269 47 is_stmt 0 discriminator 4
	movl	4(%rax), %edx
	.loc 2 1269 47 discriminator 5
	cmpl	%edx, %ecx
	jne	.L1005
	.loc 2 1269 47 discriminator 6
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	subq	$1, %rdx
	salq	$5, %rdx
	leaq	-48(%rdx), %rbx
	leaq	(%rbx,%rbp), %rdx
	subq	$10996, %rdx
	movl	(%rdx), %ecx
	.loc 2 1269 47 discriminator 7
	movl	8(%rax), %edx
	.loc 2 1269 47 discriminator 8
	cmpl	%edx, %ecx
	jne	.L1005
	.loc 2 1269 47 discriminator 9
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	subq	$1, %rdx
	salq	$5, %rdx
	leaq	-48(%rdx), %rbx
	leaq	(%rbx,%rbp), %rdx
	subq	$10992, %rdx
	movl	(%rdx), %ecx
	.loc 2 1269 47 discriminator 10
	movl	12(%rax), %edx
	.loc 2 1269 47 discriminator 11
	cmpl	%edx, %ecx
	jne	.L1005
	.loc 2 1269 47 discriminator 12
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	salq	$5, %rdx
	leaq	-48(%rdx), %rdi
	leaq	(%rdi,%rbp), %rdx
	subq	$11020, %rdx
	movzbl	(%rdx), %ecx
	.loc 2 1269 47 discriminator 13
	movzbl	16(%rax), %edx
	.loc 2 1269 47 discriminator 14
	cmpb	%dl, %cl
	jne	.L1005
	.loc 2 1269 47 discriminator 15
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	salq	$5, %rdx
	leaq	-48(%rdx), %rbx
	leaq	(%rbx,%rbp), %rdx
	subq	$11016, %rdx
	movl	(%rdx), %ecx
	.loc 2 1269 47 discriminator 16
	movl	20(%rax), %edx
	.loc 2 1269 47 discriminator 17
	cmpl	%edx, %ecx
	jne	.L1005
	.loc 2 1269 47 discriminator 18
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	salq	$5, %rdx
	leaq	-48(%rdx), %rdi
	leaq	(%rdi,%rbp), %rdx
	subq	$11012, %rdx
	movl	(%rdx), %ecx
	.loc 2 1269 47 discriminator 19
	movl	24(%rax), %edx
	.loc 2 1269 47 discriminator 20
	cmpl	%edx, %ecx
	jne	.L1005
	.loc 2 1269 47 discriminator 21
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	salq	$5, %rdx
	leaq	-48(%rdx), %rbx
	leaq	(%rbx,%rbp), %rdx
	subq	$11008, %rdx
	movzbl	(%rdx), %edx
	.loc 2 1269 47 discriminator 22
	movzbl	28(%rax), %eax
	.loc 2 1269 47 discriminator 23
	cmpb	%al, %dl
	je	.L1006
.L1005:
	.loc 2 1268 20 is_stmt 1 discriminator 3
	movl	$0, %esi
	jmp	.L1000
.L1006:
.LBE255:
	.loc 2 1268 20 is_stmt 0 discriminator 5
	addl	$1, -52(%rbp)
	jmp	.L1007
.L1000:
.LBE254:
	.loc 2 1268 20 discriminator 6
	movl	%esi, %eax
	xorl	$1, %eax
	.loc 2 1267 16 is_stmt 1 discriminator 2
	testb	%al, %al
	je	.L1008
.LBB256:
	.loc 2 1267 16 is_stmt 0 discriminator 3
	leaq	.LC136(%rip), %r12
	leaq	.LC6(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1008:
.LBE256:
.LBE252:
	.loc 2 1274 4 is_stmt 1 discriminator 3
	movq	-11096(%rbp), %rax
	movq	%rax, %rcx
	leaq	-11056(%rbp), %rax
	movl	$10916, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE251:
	.loc 2 1274 4 is_stmt 0
	movq	-11096(%rbp), %rax
	addq	$11080, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE82:
	.size	silver_output_profile__reading_names, .-silver_output_profile__reading_names
	.align 2
	.type	silver_output_profile__read_scalar_in_flow___wrapped_statements.23, @function
silver_output_profile__read_scalar_in_flow___wrapped_statements.23:
.LFB85:
	.loc 2 1306 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$10952, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -10952(%rbp)
	movq	%r10, %rbx
	movq	%r10, -10960(%rbp)
	.loc 2 1310 60
	movq	16(%rbx), %rcx
	movq	8(%rbx), %rdx
	leaq	-10944(%rbp), %rax
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__reading_names
	.loc 2 1312 32
	movq	(%rbx), %rax
	movl	32(%rbx), %ecx
	movl	28(%rbx), %r9d
	movl	24(%rbx), %esi
	movq	-10952(%rbp), %rdi
	leaq	-10944(%rbp), %r8
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	pushq	$1
	pushq	%rsi
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_scalar_expressions__read_expression@PLT
	addq	$16, %rsp
	.loc 2 1312 7 discriminator 2
	nop
	.loc 2 1313 8
	movq	-10952(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE85:
	.size	silver_output_profile__read_scalar_in_flow___wrapped_statements.23, .-silver_output_profile__read_scalar_in_flow___wrapped_statements.23
	.section	.rodata
	.align 8
.LC137:
	.ascii	"failed precondition from silver_output_profile.adb:1297"
	.align 8
.LC138:
	.ascii	"failed precondition from silver_output_profile.adb:1298"
	.align 8
.LC139:
	.ascii	"failed precondition from silver_output_profile.adb:1299"
	.align 8
.LC140:
	.ascii	"failed postcondition from silver_output_profile.adb:1300"
	.text
	.align 2
	.globl	silver_output_profile__read_scalar_in_flow
	.type	silver_output_profile__read_scalar_in_flow, @function
silver_output_profile__read_scalar_in_flow:
.LFB84:
	.loc 2 1306 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$208, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, -120(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -144(%rbp)
	movq	%rdx, -136(%rbp)
	movq	%rcx, -128(%rbp)
	movl	%r8d, -148(%rbp)
	movq	%r9, -160(%rbp)
	.loc 2 1306 4
	leaq	16(%rbp), %rdx
	.loc 2 1306 4 is_stmt 0 discriminator 1
	leaq	-144(%rbp), %rax
	movq	%rdx, -40(%rbp)
	movq	%rax, -80(%rbp)
	movq	-128(%rbp), %rax
	movq	%rax, -64(%rbp)
	movl	-148(%rbp), %eax
	movl	%eax, -48(%rbp)
	movq	-160(%rbp), %rax
	movq	%rax, -72(%rbp)
	movl	16(%rbp), %eax
	movl	%eax, -52(%rbp)
	movl	24(%rbp), %eax
	movl	%eax, -56(%rbp)
	movq	-136(%rbp), %rax
	movl	(%rax), %r8d
	movq	-136(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%r8d, %r12d
	jl	.L1013
	.loc 2 1306 4 discriminator 2
	movslq	%r12d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r8d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L1014
.L1013:
	.loc 2 1306 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L1014:
.LBB257:
	.loc 2 1306 4 discriminator 4
	cmpl	%r8d, %r12d
	.loc 2 1306 4 discriminator 7
	cmpl	%r8d, %r12d
	.loc 2 1306 4 discriminator 10
	cmpl	%r8d, %r12d
	.loc 2 1297 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L1021
.LBB258:
	.loc 2 1297 15 is_stmt 0 discriminator 1
	leaq	.LC137(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1021:
.LBE258:
	.loc 2 1297 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 1297 15 discriminator 2
	testl	%eax, %eax
	jle	.L1022
	.loc 2 1297 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L1023
.L1022:
.LBB259:
	.loc 2 1297 15 discriminator 4
	leaq	.LC137(%rip), %rax
	movq	%rax, -240(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -232(%rbp)
	movq	-240(%rbp), %rbx
	movq	-232(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1023:
.LBE259:
	.loc 2 1298 19
	movq	-64(%rbp), %rdx
	movq	-144(%rbp), %rcx
	movq	-136(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_context
	.loc 2 1298 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 1297 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L1024
.LBB260:
	.loc 2 1297 15 is_stmt 0 discriminator 6
	leaq	.LC138(%rip), %rax
	movq	%rax, -224(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rbx
	movq	-216(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1024:
.LBE260:
	.loc 2 1298 58 is_stmt 1 discriminator 2
	movq	-64(%rbp), %rax
	movq	-72(%rbp), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__valid_flow
	.loc 2 1298 58 is_stmt 0 discriminator 3
	xorl	$1, %eax
	.loc 2 1297 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L1025
.LBB261:
	.loc 2 1297 15 is_stmt 0 discriminator 8
	leaq	.LC138(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1025:
.LBE261:
	.loc 2 1299 41 is_stmt 1
	cmpl	$2147483647, %r12d
	jne	.L1026
	.loc 2 1299 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1299, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1026:
	.loc 2 1299 41 discriminator 3
	leal	1(%r12), %edx
	.loc 2 1297 15 is_stmt 1 discriminator 9
	movl	-48(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L1027
.LBB262:
	.loc 2 1297 15 is_stmt 0 discriminator 10
	leaq	.LC139(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1027:
.LBE262:
	.loc 2 1299 54 is_stmt 1 discriminator 4
	movl	-52(%rbp), %edx
	movl	-56(%rbp), %ecx
	movq	-144(%rbp), %rsi
	movq	-136(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__valid_name_state@PLT
	.loc 2 1299 54 is_stmt 0 discriminator 5
	xorl	$1, %eax
	.loc 2 1297 15 is_stmt 1 discriminator 11
	testb	%al, %al
	je	.L1028
.LBB263:
	.loc 2 1297 15 is_stmt 0 discriminator 12
	leaq	.LC139(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1028:
.LBE263:
.LBB264:
	.loc 2 1306 4 is_stmt 1 discriminator 13
	leaq	-112(%rbp), %rax
	leaq	-80(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_output_profile__read_scalar_in_flow___wrapped_statements.23
	.loc 2 1300 61
	movl	-112(%rbp), %eax
	.loc 2 1300 28
	testl	%eax, %eax
	je	.L1029
	.loc 2 1301 52
	movl	-112(%rbp), %eax
	.loc 2 1301 10
	movl	-48(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L1030
	.loc 2 1301 52 discriminator 1
	movl	-112(%rbp), %eax
	.loc 2 1301 81 discriminator 1
	cmpl	$2147483647, %r12d
	jne	.L1031
	.loc 2 1301 81 is_stmt 0 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$1301, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1031:
	.loc 2 1301 81 discriminator 4
	leal	1(%r12), %edx
	.loc 2 1301 52 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jl	.L1030
	.loc 2 1302 57
	movl	-100(%rbp), %eax
	.loc 2 1302 12
	testl	%eax, %eax
	jg	.L1029
.L1030:
.LBB265:
	.loc 2 1300 28 discriminator 1
	leaq	.LC140(%rip), %r14
	leaq	.LC6(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1029:
.LBE265:
	.loc 2 1306 4 discriminator 14
	movq	-120(%rbp), %rcx
	movq	-112(%rbp), %rax
	movq	-104(%rbp), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movl	-96(%rbp), %eax
	movl	%eax, 16(%rcx)
.LBE264:
.LBE257:
	.loc 2 1306 4 is_stmt 0
	movq	-120(%rbp), %rax
	addq	$208, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE84:
	.size	silver_output_profile__read_scalar_in_flow, .-silver_output_profile__read_scalar_in_flow
	.align 2
	.type	silver_output_profile__read_string_in_flow___wrapped_statements.24, @function
silver_output_profile__read_string_in_flow___wrapped_statements.24:
.LFB87:
	.loc 2 1326 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$10952, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -10952(%rbp)
	movq	%r10, %rbx
	movq	%r10, -10960(%rbp)
	.loc 2 1329 60
	movq	16(%rbx), %rcx
	movq	8(%rbx), %rdx
	leaq	-10944(%rbp), %rax
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__reading_names
	.loc 2 1331 14
	movq	16(%rbx), %rax
	movq	%rax, %r8
	movq	(%rbx), %rax
	movl	24(%rbx), %ecx
	movq	-10952(%rbp), %rdi
	leaq	-10944(%rbp), %rsi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	subq	$8, %rsp
	pushq	$0
	movq	%rsi, %r9
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__expression_at
	addq	$16, %rsp
	.loc 2 1331 7 discriminator 2
	nop
	.loc 2 1332 8
	movq	-10952(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE87:
	.size	silver_output_profile__read_string_in_flow___wrapped_statements.24, .-silver_output_profile__read_string_in_flow___wrapped_statements.24
	.section	.rodata
	.align 8
.LC141:
	.ascii	"failed precondition from silver_output_profile.adb:1318"
	.align 8
.LC142:
	.ascii	"failed precondition from silver_output_profile.adb:1319"
	.align 8
.LC143:
	.ascii	"failed precondition from silver_output_profile.adb:1320"
	.align 8
.LC144:
	.ascii	"failed postcondition from silver_output_profile.adb:1321"
	.text
	.align 2
	.globl	silver_output_profile__read_string_in_flow
	.type	silver_output_profile__read_string_in_flow, @function
silver_output_profile__read_string_in_flow:
.LFB86:
	.loc 2 1326 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$192, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, -120(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -144(%rbp)
	movq	%rdx, -136(%rbp)
	movq	%rcx, -128(%rbp)
	movl	%r8d, -148(%rbp)
	movq	%r9, -160(%rbp)
	.loc 2 1326 4
	leaq	16(%rbp), %rdx
	.loc 2 1326 4 is_stmt 0 discriminator 1
	leaq	-144(%rbp), %rax
	movq	%rdx, -48(%rbp)
	movq	%rax, -80(%rbp)
	movq	-128(%rbp), %rax
	movq	%rax, -64(%rbp)
	movl	-148(%rbp), %eax
	movl	%eax, -56(%rbp)
	movq	-160(%rbp), %rax
	movq	%rax, -72(%rbp)
	movq	-136(%rbp), %rax
	movl	(%rax), %r8d
	movq	-136(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%r8d, %r12d
	jl	.L1036
	.loc 2 1326 4 discriminator 2
	movslq	%r12d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r8d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L1037
.L1036:
	.loc 2 1326 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L1037:
.LBB266:
	.loc 2 1326 4 discriminator 4
	cmpl	%r8d, %r12d
	.loc 2 1326 4 discriminator 7
	cmpl	%r8d, %r12d
	.loc 2 1326 4 discriminator 10
	cmpl	%r8d, %r12d
	.loc 2 1318 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L1044
.LBB267:
	.loc 2 1318 15 is_stmt 0 discriminator 1
	leaq	.LC141(%rip), %rax
	movq	%rax, -224(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rbx
	movq	-216(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1044:
.LBE267:
	.loc 2 1318 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 1318 15 discriminator 2
	testl	%eax, %eax
	jle	.L1045
	.loc 2 1318 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L1046
.L1045:
.LBB268:
	.loc 2 1318 15 discriminator 4
	leaq	.LC141(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1046:
.LBE268:
	.loc 2 1319 19
	movq	-64(%rbp), %rdx
	movq	-144(%rbp), %rcx
	movq	-136(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_context
	.loc 2 1319 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 1318 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L1047
.LBB269:
	.loc 2 1318 15 is_stmt 0 discriminator 6
	leaq	.LC142(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1047:
.LBE269:
	.loc 2 1319 58 is_stmt 1 discriminator 2
	movq	-64(%rbp), %rax
	movq	-72(%rbp), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__valid_flow
	.loc 2 1319 58 is_stmt 0 discriminator 3
	xorl	$1, %eax
	.loc 2 1318 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L1048
.LBB270:
	.loc 2 1318 15 is_stmt 0 discriminator 8
	leaq	.LC142(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1048:
.LBE270:
	.loc 2 1320 41 is_stmt 1
	cmpl	$2147483647, %r12d
	jne	.L1049
	.loc 2 1320 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1320, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1049:
	.loc 2 1320 41 discriminator 3
	leal	1(%r12), %edx
	.loc 2 1318 15 is_stmt 1 discriminator 9
	movl	-56(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L1050
.LBB271:
	.loc 2 1318 15 is_stmt 0 discriminator 10
	leaq	.LC143(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1050:
.LBE271:
.LBB272:
	.loc 2 1326 4 is_stmt 1 discriminator 13
	leaq	-112(%rbp), %rax
	leaq	-80(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_output_profile__read_string_in_flow___wrapped_statements.24
	.loc 2 1321 61
	movl	-112(%rbp), %eax
	.loc 2 1321 28
	testl	%eax, %eax
	je	.L1051
	.loc 2 1322 51
	movl	-112(%rbp), %eax
	.loc 2 1322 10
	movl	-56(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L1052
	.loc 2 1322 51 discriminator 1
	movl	-112(%rbp), %eax
	.loc 2 1322 80 discriminator 1
	cmpl	$2147483647, %r12d
	jne	.L1053
	.loc 2 1322 80 is_stmt 0 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$1322, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1053:
	.loc 2 1322 80 discriminator 4
	leal	1(%r12), %edx
	.loc 2 1322 51 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L1051
.L1052:
.LBB273:
	.loc 2 1321 28 discriminator 1
	leaq	.LC144(%rip), %r14
	leaq	.LC6(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1051:
.LBE273:
	.loc 2 1326 4 discriminator 14
	movq	-120(%rbp), %rcx
	movq	-112(%rbp), %rax
	movq	-104(%rbp), %rdx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movl	-96(%rbp), %eax
	movl	%eax, 16(%rcx)
.LBE272:
.LBE266:
	.loc 2 1326 4 is_stmt 0
	movq	-120(%rbp), %rax
	addq	$192, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE86:
	.size	silver_output_profile__read_string_in_flow, .-silver_output_profile__read_string_in_flow
	.align 2
	.type	silver_output_profile__body_token___wrapped_statements.25, @function
silver_output_profile__body_token___wrapped_statements.25:
.LFB89:
	.loc 2 1351 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%r10, %rbx
	movq	%r10, -72(%rbp)
.LBB274:
	.loc 2 1355 14
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, -36(%rbp)
	movl	-36(%rbp), %eax
	cltq
	movq	%rax, -48(%rbp)
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	leaq	36(%rax), %r13
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	addq	$36, %rax
	movl	$4, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_allocate@PLT
	.loc 2 1355 14 is_stmt 0 discriminator 1
	movq	%rax, %r12
	movq	%r12, -56(%rbp)
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, %esi
	movq	%r12, %rdi
	call	silver_output_profile__body_scanIP
	.loc 2 1356 17 is_stmt 1
	movq	8(%rbx), %rax
	movq	%r12, %rcx
	movq	%r13, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 1357 29
	movq	8(%rbx), %rax
	movl	4(%rax), %edx
	movq	(%rbx), %rax
	movzbl	16(%rbx), %ecx
	movzbl	%cl, %ecx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1357 26 discriminator 1
	movl	%eax, 4(%r12)
	.loc 2 1355 7 discriminator 3
	movq	%r12, %rax
.LBE274:
	.loc 2 1359 8
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE89:
	.size	silver_output_profile__body_token___wrapped_statements.25, .-silver_output_profile__body_token___wrapped_statements.25
	.section	.rodata
	.align 8
.LC145:
	.ascii	"failed precondition from silver_output_profile.adb:1345"
	.align 8
.LC146:
	.ascii	"failed precondition from silver_output_profile.adb:1346"
	.align 8
.LC147:
	.ascii	"failed postcondition from silver_output_profile.adb:1347"
	.align 8
.LC148:
	.ascii	"failed postcondition from silver_output_profile.adb:1348"
	.text
	.align 2
	.type	silver_output_profile__body_token, @function
silver_output_profile__body_token:
.LFB88:
	.loc 2 1351 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$136, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r9
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r9, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movq	%rdx, -104(%rbp)
	movq	%rcx, -112(%rbp)
	movb	%r8b, -113(%rbp)
	.loc 2 1351 4
	leaq	16(%rbp), %rdx
	.loc 2 1351 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -56(%rbp)
	movq	%rax, -80(%rbp)
	movq	-112(%rbp), %rax
	movq	%rax, -72(%rbp)
	movzbl	-113(%rbp), %eax
	movb	%al, -64(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %r8d
	movq	-88(%rbp), %rax
	movl	4(%rax), %r9d
	cmpl	%r8d, %r9d
	jl	.L1058
	.loc 2 1351 4 discriminator 2
	movslq	%r9d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r8d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L1059
.L1058:
	.loc 2 1351 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L1059:
.LBB275:
	.loc 2 1351 4 discriminator 4
	cmpl	%r8d, %r9d
	.loc 2 1351 4 discriminator 7
	cmpl	%r8d, %r9d
	.loc 2 1351 4 discriminator 10
	cmpl	%r8d, %r9d
	.loc 2 1345 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L1066
.LBB276:
	.loc 2 1345 15 is_stmt 0 discriminator 1
	leaq	.LC145(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1066:
.LBE276:
	.loc 2 1345 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 1345 15 discriminator 2
	testl	%eax, %eax
	jle	.L1067
	.loc 2 1345 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L1068
.L1067:
.LBB277:
	.loc 2 1345 15 discriminator 4
	leaq	.LC145(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1068:
.LBE277:
	.loc 2 1346 19
	movq	-104(%rbp), %rdx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_context
	.loc 2 1346 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 1345 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L1069
.LBB278:
	.loc 2 1345 15 is_stmt 0 discriminator 6
	leaq	.LC146(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1069:
.LBE278:
	.loc 2 1346 58 is_stmt 1 discriminator 2
	movq	-72(%rbp), %rcx
	movq	-104(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_body
	.loc 2 1346 58 is_stmt 0 discriminator 3
	xorl	$1, %eax
	.loc 2 1345 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L1070
.LBB279:
	.loc 2 1345 15 is_stmt 0 discriminator 8
	leaq	.LC146(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1070:
.LBE279:
.LBB280:
	.loc 2 1351 4 is_stmt 1 discriminator 13
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__body_token___wrapped_statements.25
	movq	%rax, %rbx
.LBB281:
	.loc 2 1347 28
	movq	-104(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rbx, %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_body
	.loc 2 1347 28 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L1071
.LBB282:
	.loc 2 1347 28 discriminator 2
	leaq	.LC147(%rip), %r14
	leaq	.LC6(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1071:
.LBE282:
	.loc 2 1348 47 is_stmt 1
	movl	4(%rbx), %eax
	.loc 2 1347 28 discriminator 3
	testl	%eax, %eax
	je	.L1073
	.loc 2 1349 47
	movl	4(%rbx), %edx
	movq	-72(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 1349 12
	cmpl	%eax, %edx
	jg	.L1073
.LBB283:
	.loc 2 1347 28 discriminator 4
	leaq	.LC148(%rip), %r12
	leaq	.LC6(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1073:
.LBE283:
.LBE281:
	.loc 2 1351 4 discriminator 16
	movq	%rbx, %rax
.LBE280:
.LBE275:
	.loc 2 1351 4 is_stmt 0
	addq	$136, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE88:
	.size	silver_output_profile__body_token, .-silver_output_profile__body_token
	.align 2
	.globl	silver_output_profile__comparison_resultIP
	.type	silver_output_profile__comparison_resultIP, @function
silver_output_profile__comparison_resultIP:
.LFB90:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE90:
	.size	silver_output_profile__comparison_resultIP, .-silver_output_profile__comparison_resultIP
	.align 2
	.type	silver_output_profile__scalar_comparison_at___wrapped_statements.26, @function
silver_output_profile__scalar_comparison_at___wrapped_statements.26:
.LFB92:
	.loc 2 1380 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r12
	pushq	%rbx
	subq	$16, %rsp
	.cfi_offset 12, -24
	.cfi_offset 3, -32
	movq	%r10, %rbx
	movq	%r10, -24(%rbp)
	.loc 2 1382 10
	movq	(%rbx), %rax
	movl	8(%rbx), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$32, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1382 7 discriminator 1
	testl	%eax, %eax
	je	.L1076
	.loc 2 1383 10
	movq	(%rbx), %rax
	movl	8(%rbx), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$32, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1383 9 discriminator 1
	movl	%eax, %edx
	movabsq	$-4294967296, %rax
	andq	%r12, %rax
	orq	%rdx, %rax
	movq	%rax, %r12
	movabsq	$-1095216660481, %rax
	movq	%r12, %rdx
	andq	%rax, %rdx
	movabsq	$4294967296, %rax
	orq	%rdx, %rax
	movq	%rax, %r12
	jmp	.L1077
.L1076:
	.loc 2 1384 13
	movq	(%rbx), %rax
	movl	8(%rbx), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$38, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1384 7 discriminator 1
	testl	%eax, %eax
	je	.L1078
	.loc 2 1385 10
	movq	(%rbx), %rax
	movl	8(%rbx), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$38, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1385 9 discriminator 1
	movl	%eax, %edx
	movabsq	$-4294967296, %rax
	andq	%r12, %rax
	orq	%rdx, %rax
	movq	%rax, %r12
	movabsq	$-1095216660481, %rax
	movq	%r12, %rdx
	andq	%rax, %rdx
	movabsq	$12884901888, %rax
	orq	%rdx, %rax
	movq	%rax, %r12
	jmp	.L1077
.L1078:
	.loc 2 1386 13
	movq	(%rbx), %rax
	movl	8(%rbx), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$35, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1386 7 discriminator 1
	testl	%eax, %eax
	je	.L1079
	.loc 2 1387 10
	movq	(%rbx), %rax
	movl	8(%rbx), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$35, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1387 9 discriminator 1
	movl	%eax, %edx
	movabsq	$-4294967296, %rax
	andq	%r12, %rax
	orq	%rdx, %rax
	movq	%rax, %r12
	movabsq	$-1095216660481, %rax
	movq	%r12, %rdx
	andq	%rax, %rdx
	movabsq	$21474836480, %rax
	orq	%rdx, %rax
	movq	%rax, %r12
	jmp	.L1077
.L1079:
	.loc 2 1388 13
	movq	(%rbx), %rax
	movl	8(%rbx), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$40, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1388 7 discriminator 1
	testl	%eax, %eax
	je	.L1080
	.loc 2 1389 10
	movq	(%rbx), %rax
	movl	8(%rbx), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$40, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1389 9 discriminator 1
	movl	%eax, %edx
	movabsq	$-4294967296, %rax
	andq	%r12, %rax
	orq	%rdx, %rax
	movq	%rax, %r12
	movabsq	$-1095216660481, %rax
	andq	%r12, %rax
	movq	%rax, %r12
	jmp	.L1077
.L1080:
	.loc 2 1390 13
	movq	(%rbx), %rax
	movl	8(%rbx), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$33, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1390 7 discriminator 1
	testl	%eax, %eax
	je	.L1081
	.loc 2 1391 10
	movq	(%rbx), %rax
	movl	8(%rbx), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$33, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1391 9 discriminator 1
	movl	%eax, %edx
	movabsq	$-4294967296, %rax
	andq	%r12, %rax
	orq	%rdx, %rax
	movq	%rax, %r12
	movabsq	$-1095216660481, %rax
	movq	%r12, %rdx
	andq	%rax, %rdx
	movabsq	$8589934592, %rax
	orq	%rdx, %rax
	movq	%rax, %r12
	jmp	.L1077
.L1081:
	.loc 2 1392 13
	movq	(%rbx), %rax
	movl	8(%rbx), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$34, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1392 7 discriminator 1
	testl	%eax, %eax
	je	.L1082
	.loc 2 1393 10
	movq	(%rbx), %rax
	movl	8(%rbx), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$34, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1393 9 discriminator 1
	movl	%eax, %edx
	movabsq	$-4294967296, %rax
	andq	%r12, %rax
	orq	%rdx, %rax
	movq	%rax, %r12
	movabsq	$-1095216660481, %rax
	movq	%r12, %rdx
	andq	%rax, %rdx
	movabsq	$17179869184, %rax
	orq	%rdx, %rax
	movq	%rax, %r12
	jmp	.L1077
.L1082:
	.loc 2 1394 12
	movabsq	$-4294967296, %rax
	andq	%r12, %rax
	movq	%rax, %r12
	movabsq	$-1095216660481, %rax
	andq	%r12, %rax
	movq	%rax, %r12
.L1077:
	.loc 2 1380 4
	movq	%r12, %rax
	addq	$16, %rsp
	popq	%rbx
	popq	%r12
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE92:
	.size	silver_output_profile__scalar_comparison_at___wrapped_statements.26, .-silver_output_profile__scalar_comparison_at___wrapped_statements.26
	.section	.rodata
	.align 8
.LC149:
	.ascii	"failed precondition from silver_output_profile.adb:1376"
	.align 8
.LC150:
	.ascii	"failed precondition from silver_output_profile.adb:1377"
	.align 8
.LC151:
	.ascii	"failed postcondition from silver_output_profile.adb:1378"
	.text
	.align 2
	.globl	silver_output_profile__scalar_comparison_at
	.type	silver_output_profile__scalar_comparison_at, @function
silver_output_profile__scalar_comparison_at:
.LFB91:
	.loc 2 1380 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$88, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r14
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r14, %rdi
	movq	%rsi, -112(%rbp)
	movq	%rdi, -104(%rbp)
	movl	%edx, -116(%rbp)
	.loc 2 1380 4
	leaq	16(%rbp), %rdx
	.loc 2 1380 4 is_stmt 0 discriminator 1
	leaq	-112(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -80(%rbp)
	movl	-116(%rbp), %eax
	movl	%eax, -72(%rbp)
	movq	-104(%rbp), %rax
	movl	(%rax), %r15d
	movq	-104(%rbp), %rax
	movl	4(%rax), %r14d
	movq	-104(%rbp), %rax
	movl	4(%rax), %edx
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L1084
	.loc 2 1380 4 discriminator 2
	movq	-104(%rbp), %rax
	movl	4(%rax), %esi
	movslq	%esi, %rax
	cqto
	movq	-104(%rbp), %rsi
	movl	(%rsi), %edi
	movl	%edi, -120(%rbp)
	movslq	-120(%rbp), %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L1085
.L1084:
	.loc 2 1380 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L1085:
.LBB284:
	.loc 2 1376 15 is_stmt 1
	cmpl	$1, %r15d
	je	.L1086
.LBB285:
	.loc 2 1376 15 is_stmt 0 discriminator 1
	leaq	.LC149(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1086:
.LBE285:
	.loc 2 1376 51 is_stmt 1 discriminator 2
	movl	%eax, %esi
	.loc 2 1376 15 discriminator 2
	testl	%esi, %esi
	jle	.L1087
	.loc 2 1376 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L1088
.L1087:
.LBB286:
	.loc 2 1376 15 discriminator 4
	leaq	.LC149(%rip), %r8
	leaq	.LC1(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1088:
.LBE286:
	.loc 2 1377 41
	cmpl	$2147483647, %r14d
	jne	.L1089
	.loc 2 1377 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1377, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1089:
	.loc 2 1377 41 discriminator 3
	leal	1(%r14), %edx
	.loc 2 1376 15 is_stmt 1 discriminator 5
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L1090
.LBB287:
	.loc 2 1376 15 is_stmt 0 discriminator 6
	leaq	.LC150(%rip), %rcx
	leaq	.LC1(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1090:
.LBE287:
.LBB288:
	.loc 2 1380 4 is_stmt 1 discriminator 5
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__scalar_comparison_at___wrapped_statements.26
	movq	%rax, -88(%rbp)
	.loc 2 1378 50
	movl	-88(%rbp), %eax
	.loc 2 1378 16
	testl	%eax, %eax
	je	.L1091
	.loc 2 1379 52
	movl	-88(%rbp), %eax
	.loc 2 1379 10
	movl	-72(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L1092
	.loc 2 1379 52 discriminator 1
	movl	-88(%rbp), %eax
	.loc 2 1379 81 discriminator 1
	cmpl	$2147483647, %r14d
	jne	.L1093
	.loc 2 1379 81 is_stmt 0 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$1379, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1093:
	.loc 2 1379 81 discriminator 4
	leal	1(%r14), %edx
	.loc 2 1379 52 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L1091
.L1092:
.LBB289:
	.loc 2 1378 16 discriminator 1
	leaq	.LC151(%rip), %r12
	leaq	.LC6(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1091:
.LBE289:
	.loc 2 1380 4 discriminator 6
	movq	-88(%rbp), %rax
.LBE288:
.LBE284:
	.loc 2 1380 4 is_stmt 0
	addq	$88, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE91:
	.size	silver_output_profile__scalar_comparison_at, .-silver_output_profile__scalar_comparison_at
	.align 2
	.globl	silver_output_profile__length_resultIP
	.type	silver_output_profile__length_resultIP, @function
silver_output_profile__length_resultIP:
.LFB93:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	.cfi_offset 3, -24
	movq	%rcx, %rax
	movq	%rbx, %rdx
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE93:
	.size	silver_output_profile__length_resultIP, .-silver_output_profile__length_resultIP
	.align 2
	.type	silver_output_profile__length_at___wrapped_statements.27, @function
silver_output_profile__length_at___wrapped_statements.27:
.LFB95:
	.loc 2 1408 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset 3, -24
	movq	%r10, %rbx
	movq	%r10, -88(%rbp)
	.loc 2 1412 46
	movq	8(%rbx), %rax
	movl	16(%rbx), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__skip_at
	.loc 2 1412 46 is_stmt 0 discriminator 1
	movl	%eax, -20(%rbp)
	.loc 2 1413 46 is_stmt 1
	movq	8(%rbx), %rax
	movl	-20(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__name_after
	.loc 2 1413 46 is_stmt 0 discriminator 1
	movl	%eax, -24(%rbp)
	.loc 2 1414 43 is_stmt 1
	movq	(%rbx), %rax
	movq	%rax, %rdi
	movq	8(%rbx), %rax
	movl	-24(%rbp), %ecx
	movl	-20(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%ecx, %r8d
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__lookup_name
	.loc 2 1414 43 is_stmt 0 discriminator 1
	movl	%eax, -28(%rbp)
	.loc 2 1416 34 is_stmt 1
	movq	8(%rbx), %rax
	movl	-20(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_integer_literals__read_integer@PLT
	movq	%rax, -72(%rbp)
	.loc 2 1418 10
	movzbl	20(%rbx), %eax
	testb	%al, %al
	je	.L1097
	.loc 2 1418 43 discriminator 1
	movl	-72(%rbp), %eax
	.loc 2 1418 21 discriminator 1
	testl	%eax, %eax
	je	.L1097
	.loc 2 1418 10 discriminator 2
	movl	-72(%rbp), %eax
	movl	%eax, -52(%rbp)
	movl	-68(%rbp), %eax
	movl	%eax, -48(%rbp)
	movb	$0, -44(%rbp)
	jmp	.L1098
.L1097:
	.loc 2 1419 10
	cmpl	$0, -28(%rbp)
	je	.L1099
	.loc 2 1420 38
	movq	(%rbx), %rax
	leaq	6824(%rax), %rdi
	movq	8(%rbx), %rax
	movl	-24(%rbp), %ecx
	movl	-20(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%ecx, %r8d
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__lookup@PLT
	.loc 2 1420 89 discriminator 1
	testl	%eax, %eax
	setne	%al
	xorl	$1, %eax
	.loc 2 1420 12 discriminator 1
	testb	%al, %al
	je	.L1099
	.loc 2 1423 35
	cmpl	$0, -28(%rbp)
	jle	.L1100
	.loc 2 1423 35 is_stmt 0 discriminator 1
	cmpl	$341, -28(%rbp)
	jle	.L1101
.L1100:
	.loc 2 1423 35 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$1423, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1101:
	.loc 2 1422 16 is_stmt 1
	movq	8(%rbx), %rax
	movl	-24(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$36, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	movl	%eax, %edx
	.loc 2 1422 16 is_stmt 0 discriminator 1
	movq	8(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$37, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1422 15 is_stmt 1 discriminator 2
	movl	%eax, -40(%rbp)
	.loc 2 1423 12 discriminator 3
	movl	-28(%rbp), %eax
	cltq
	movq	(%rbx), %rcx
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$2, %rax
	addq	%rcx, %rax
	addq	$4, %rax
	movq	%rax, %rdi
	call	silver_output_profile__bound_of
	.loc 2 1422 15 discriminator 3
	movq	%rax, -36(%rbp)
	leaq	-40(%rbp), %rax
	.loc 2 1418 10 discriminator 3
	movq	(%rax), %rdx
	movq	%rdx, -52(%rbp)
	movl	8(%rax), %eax
	movl	%eax, -44(%rbp)
	.loc 2 1418 10 is_stmt 0 discriminator 4
	jmp	.L1098
.L1099:
	.loc 2 1418 10 discriminator 5
	movl	$0, -52(%rbp)
	movl	$0, -48(%rbp)
	movb	$0, -44(%rbp)
.L1098:
	.loc 2 1418 10 discriminator 6
	leaq	-52(%rbp), %rax
	.loc 2 1411 7 is_stmt 1
	movq	(%rax), %rdx
	movq	%rdx, -64(%rbp)
	movl	8(%rax), %eax
	movl	%eax, -56(%rbp)
	.loc 2 1411 7 is_stmt 0 discriminator 2
	movq	-64(%rbp), %rax
	movl	-56(%rbp), %ecx
	movq	%rcx, %rdx
	.loc 2 1408 4 is_stmt 1
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE95:
	.size	silver_output_profile__length_at___wrapped_statements.27, .-silver_output_profile__length_at___wrapped_statements.27
	.section	.rodata
	.align 8
.LC152:
	.ascii	"failed precondition from silver_output_profile.adb:1404"
	.align 8
.LC153:
	.ascii	"failed precondition from silver_output_profile.adb:1405"
	.align 8
.LC154:
	.ascii	"failed postcondition from silver_output_profile.adb:1406"
	.text
	.align 2
	.globl	silver_output_profile__length_at
	.type	silver_output_profile__length_at, @function
silver_output_profile__length_at:
.LFB94:
	.loc 2 1408 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$160, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r9
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r9, %rdi
	movq	%rsi, -112(%rbp)
	movq	%rdi, -104(%rbp)
	movq	%rdx, -120(%rbp)
	movl	%ecx, -124(%rbp)
	movb	%r8b, -125(%rbp)
	.loc 2 1408 4
	leaq	16(%rbp), %rdx
	.loc 2 1408 4 is_stmt 0 discriminator 1
	leaq	-112(%rbp), %rax
	movq	%rdx, -56(%rbp)
	movq	%rax, -72(%rbp)
	movq	-120(%rbp), %rax
	movq	%rax, -80(%rbp)
	movl	-124(%rbp), %eax
	movl	%eax, -64(%rbp)
	movzbl	-125(%rbp), %eax
	movb	%al, -60(%rbp)
	movq	-104(%rbp), %rax
	movl	(%rax), %r8d
	movq	-104(%rbp), %rax
	movl	4(%rax), %r12d
	movq	-104(%rbp), %rax
	movl	4(%rax), %edx
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L1104
	.loc 2 1408 4 discriminator 2
	movq	-104(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L1105
.L1104:
	.loc 2 1408 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L1105:
.LBB290:
	.loc 2 1404 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L1106
.LBB291:
	.loc 2 1404 15 is_stmt 0 discriminator 1
	leaq	.LC152(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1106:
.LBE291:
	.loc 2 1404 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 1404 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L1107
	.loc 2 1404 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L1108
.L1107:
.LBB292:
	.loc 2 1404 15 discriminator 4
	leaq	.LC152(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1108:
.LBE292:
	.loc 2 1405 41
	cmpl	$2147483647, %r12d
	jne	.L1109
	.loc 2 1405 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1405, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1109:
	.loc 2 1405 41 discriminator 3
	leal	1(%r12), %edx
	.loc 2 1404 15 is_stmt 1 discriminator 5
	movl	-64(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L1110
.LBB293:
	.loc 2 1404 15 is_stmt 0 discriminator 6
	leaq	.LC153(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1110:
.LBE293:
	.loc 2 1405 54 is_stmt 1 discriminator 4
	movq	-80(%rbp), %rdx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_context
	.loc 2 1405 54 is_stmt 0 discriminator 5
	xorl	$1, %eax
	.loc 2 1404 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L1111
.LBB294:
	.loc 2 1404 15 is_stmt 0 discriminator 8
	leaq	.LC153(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1111:
.LBE294:
.LBB295:
	.loc 2 1408 4 is_stmt 1 discriminator 5
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__length_at___wrapped_statements.27
	movq	%rax, -96(%rbp)
	movl	-88(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -88(%rbp)
	.loc 2 1406 39
	movl	-96(%rbp), %eax
	.loc 2 1406 16
	testl	%eax, %eax
	je	.L1112
	.loc 2 1407 41
	movl	-96(%rbp), %eax
	.loc 2 1407 10
	movl	-64(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L1113
	.loc 2 1407 41 discriminator 1
	movl	-96(%rbp), %eax
	.loc 2 1407 70 discriminator 1
	cmpl	$2147483647, %r12d
	jne	.L1114
	.loc 2 1407 70 is_stmt 0 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$1407, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1114:
	.loc 2 1407 70 discriminator 4
	leal	1(%r12), %edx
	.loc 2 1407 41 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L1112
.L1113:
.LBB296:
	.loc 2 1406 16 discriminator 1
	leaq	.LC154(%rip), %r14
	leaq	.LC6(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1112:
.LBE296:
	.loc 2 1408 4 discriminator 6
	movq	-96(%rbp), %rax
	movq	%rax, -44(%rbp)
	movl	-88(%rbp), %eax
	movl	%eax, -36(%rbp)
	.loc 2 1408 4 is_stmt 0 discriminator 8
	movq	-44(%rbp), %rax
	movl	-36(%rbp), %ecx
	movq	%rcx, %rdx
.LBE295:
.LBE290:
	.loc 2 1408 4
	addq	$160, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE94:
	.size	silver_output_profile__length_at, .-silver_output_profile__length_at
	.align 2
	.globl	silver_output_profile__condition_resultIP
	.type	silver_output_profile__condition_resultIP, @function
silver_output_profile__condition_resultIP:
.LFB96:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movl	%esi, -12(%rbp)
	movq	-8(%rbp), %rax
	movl	-12(%rbp), %edx
	movl	%edx, (%rax)
	movq	-8(%rbp), %rax
	leaq	8(%rax), %rdx
	movl	-12(%rbp), %eax
	movl	%eax, %esi
	movq	%rdx, %rdi
	call	silver_output_profile__scalar_flowIP
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	shrq	$2, %rax
	leaq	0(,%rax,4), %rdx
	movq	-8(%rbp), %rax
	addq	%rax, %rdx
	movl	-12(%rbp), %eax
	movl	%eax, %esi
	movq	%rdx, %rdi
	call	silver_output_profile__scalar_flowIP
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE96:
	.size	silver_output_profile__condition_resultIP, .-silver_output_profile__condition_resultIP
	.section	.rodata
	.align 8
.LC155:
	.ascii	"failed precondition from silver_output_profile.adb:1437"
	.text
	.align 2
	.type	silver_output_profile__invalidate_condition, @function
silver_output_profile__invalidate_condition:
.LFB97:
	.loc 2 1439 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -24(%rbp)
	movq	%rsi, -32(%rbp)
	.loc 2 1439 4
	movq	-24(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	addq	$2, %rcx
	leaq	0(,%rcx,8), %rbx
	.loc 2 1437 47
	movq	-32(%rbp), %rcx
	movl	(%rcx), %esi
	movq	-24(%rbp), %rcx
	movl	(%rcx), %ecx
	.loc 2 1437 34
	cmpl	%ecx, %esi
	je	.L1119
.LBB297:
	.loc 2 1437 34 is_stmt 0 discriminator 1
	leaq	.LC155(%rip), %rax
	leaq	.LC1(%rip), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1119:
.LBE297:
	.loc 2 1441 20 is_stmt 1
	movq	-32(%rbp), %rax
	movl	$0, 4(%rax)
	.loc 2 1442 13
	movq	-32(%rbp), %rax
	movl	(%rax), %edx
	.loc 2 1442 27
	movq	-24(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1120
	.loc 2 1442 27 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1442, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1120:
	.loc 2 1442 24 is_stmt 1 discriminator 2
	movq	-32(%rbp), %rax
	leaq	8(%rax), %rdx
	movq	-24(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rbx, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 1443 13
	movq	-32(%rbp), %rax
	movl	(%rax), %edx
	.loc 2 1443 28
	movq	-24(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1121
	.loc 2 1443 28 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1443, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1121:
	.loc 2 1443 25 is_stmt 1 discriminator 2
	movq	-32(%rbp), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	shrq	$2, %rax
	leaq	0(,%rax,4), %rdx
	movq	-32(%rbp), %rax
	addq	%rax, %rdx
	movq	-24(%rbp), %rax
	movq	%rdx, %rcx
	movq	%rbx, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 1444 29
	movq	-32(%rbp), %rax
	movl	$0, 12(%rax)
	movq	-32(%rbp), %rax
	movl	$0, 16(%rax)
	movq	-32(%rbp), %rax
	movb	$0, 20(%rax)
	movq	-32(%rbp), %rax
	movb	$0, 21(%rax)
	movq	-32(%rbp), %rax
	movb	$1, 22(%rax)
	.loc 2 1445 30
	movq	-32(%rbp), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	shrq	$2, %rax
	movq	-32(%rbp), %rdx
	movl	$0, 4(%rdx,%rax,4)
	movq	-32(%rbp), %rdx
	movl	$0, 8(%rdx,%rax,4)
	movq	-32(%rbp), %rdx
	movb	$0, 12(%rdx,%rax,4)
	movq	-32(%rbp), %rdx
	movb	$0, 13(%rdx,%rax,4)
	movq	-32(%rbp), %rdx
	movb	$1, 14(%rdx,%rax,4)
	.loc 2 1446 8
	nop
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE97:
	.size	silver_output_profile__invalidate_condition, .-silver_output_profile__invalidate_condition
	.align 2
	.type	silver_output_profile__bare_target___wrapped_statements.28, @function
silver_output_profile__bare_target___wrapped_statements.28:
.LFB99:
	.loc 2 1465 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 3, -24
	movq	%r10, %rbx
	movq	%r10, -40(%rbp)
	.loc 2 1468 52
	movq	8(%rbx), %rax
	movl	20(%rbx), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__skip_at
	.loc 2 1468 52 is_stmt 0 discriminator 1
	movl	%eax, -20(%rbp)
	.loc 2 1469 43 is_stmt 1
	movq	8(%rbx), %rax
	movl	-20(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__name_after
	.loc 2 1469 43 is_stmt 0 discriminator 1
	movl	%eax, -24(%rbp)
	.loc 2 1471 27 is_stmt 1
	movq	(%rbx), %rax
	leaq	6824(%rax), %rdi
	movq	8(%rbx), %rax
	movl	-24(%rbp), %ecx
	movl	-20(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%ecx, %r8d
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__lookup@PLT
	.loc 2 1471 27 is_stmt 0 discriminator 1
	movl	%eax, -28(%rbp)
	.loc 2 1473 10 is_stmt 1
	cmpl	$0, -28(%rbp)
	je	.L1124
	.loc 2 1473 24 discriminator 1
	movl	16(%rbx), %eax
	cmpl	%eax, -24(%rbp)
	jne	.L1124
	.loc 2 1474 41
	cmpl	$0, -28(%rbp)
	jle	.L1125
	.loc 2 1474 41 is_stmt 0 discriminator 1
	cmpl	$341, -28(%rbp)
	jle	.L1126
.L1125:
	.loc 2 1474 41 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$1474, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1126:
	.loc 2 1474 64 is_stmt 1 discriminator 3
	movl	-28(%rbp), %eax
	movslq	%eax, %rdx
	movq	(%rbx), %rax
	salq	$5, %rdx
	addq	%rdx, %rax
	addq	$6824, %rax
	movzbl	(%rax), %eax
	testb	%al, %al
	jne	.L1127
	.loc 2 1474 78 discriminator 4
	movq	(%rbx), %rax
	movl	17740(%rax), %eax
	.loc 2 1474 64 discriminator 4
	cmpl	%eax, -28(%rbp)
	jle	.L1128
.L1127:
	.loc 2 1474 64 is_stmt 0 discriminator 5
	movl	$1, %eax
	jmp	.L1129
.L1128:
	.loc 2 1474 64 discriminator 6
	movl	$0, %eax
.L1129:
	.loc 2 1474 11 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L1124
	.loc 2 1473 10 discriminator 2
	movl	-28(%rbp), %eax
	jmp	.L1130
.L1124:
	.loc 2 1473 10 is_stmt 0 discriminator 3
	movl	$0, %eax
.L1130:
	.loc 2 1465 4 is_stmt 1
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE99:
	.size	silver_output_profile__bare_target___wrapped_statements.28, .-silver_output_profile__bare_target___wrapped_statements.28
	.section	.rodata
	.align 8
.LC156:
	.ascii	"failed precondition from silver_output_profile.adb:1461"
	.align 8
.LC157:
	.ascii	"failed precondition from silver_output_profile.adb:1462"
	.align 8
.LC158:
	.ascii	"failed precondition from silver_output_profile.adb:1463"
	.align 8
.LC159:
	.ascii	"failed postcondition from silver_output_profile.adb:1464"
	.text
	.align 2
	.globl	silver_output_profile__bare_target
	.type	silver_output_profile__bare_target, @function
silver_output_profile__bare_target:
.LFB98:
	.loc 2 1465 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	addq	$-128, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r9
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r9, %rdi
	movq	%rsi, -80(%rbp)
	movq	%rdi, -72(%rbp)
	movq	%rdx, -88(%rbp)
	movl	%ecx, -92(%rbp)
	movl	%r8d, -96(%rbp)
	.loc 2 1465 4
	leaq	16(%rbp), %rdx
	.loc 2 1465 4 is_stmt 0 discriminator 1
	leaq	-80(%rbp), %rax
	movq	%rdx, -40(%rbp)
	movq	%rax, -56(%rbp)
	movq	-88(%rbp), %rax
	movq	%rax, -64(%rbp)
	movl	-92(%rbp), %eax
	movl	%eax, -44(%rbp)
	movl	-96(%rbp), %eax
	movl	%eax, -48(%rbp)
	movq	-72(%rbp), %rax
	movl	(%rax), %r8d
	movq	-72(%rbp), %rax
	movl	4(%rax), %r12d
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L1133
	.loc 2 1465 4 discriminator 2
	movq	-72(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L1134
.L1133:
	.loc 2 1465 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L1134:
.LBB298:
	.loc 2 1461 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L1135
.LBB299:
	.loc 2 1461 15 is_stmt 0 discriminator 1
	leaq	.LC156(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1135:
.LBE299:
	.loc 2 1461 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 1461 15 discriminator 2
	testl	%eax, %eax
	jle	.L1136
	.loc 2 1461 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L1137
.L1136:
.LBB300:
	.loc 2 1461 15 discriminator 4
	leaq	.LC156(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1137:
.LBE300:
	.loc 2 1462 19
	movq	-64(%rbp), %rdx
	movq	-80(%rbp), %rcx
	movq	-72(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_context
	.loc 2 1462 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 1461 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L1138
.LBB301:
	.loc 2 1461 15 is_stmt 0 discriminator 6
	leaq	.LC157(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1138:
.LBE301:
	.loc 2 1462 80 is_stmt 1 discriminator 2
	cmpl	$2147483647, %r12d
	jne	.L1139
	.loc 2 1462 80 is_stmt 0 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$1462, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1139:
	.loc 2 1462 80 discriminator 5
	leal	1(%r12), %edx
	.loc 2 1461 15 is_stmt 1 discriminator 7
	movl	-44(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L1140
.LBB302:
	.loc 2 1461 15 is_stmt 0 discriminator 8
	leaq	.LC157(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1140:
.LBE302:
	.loc 2 1463 38 is_stmt 1
	cmpl	$2147483647, %r12d
	jne	.L1141
	.loc 2 1463 38 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1463, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1141:
	.loc 2 1463 38 discriminator 3
	leal	1(%r12), %edx
	.loc 2 1461 15 is_stmt 1 discriminator 9
	movl	-48(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L1142
.LBB303:
	.loc 2 1461 15 is_stmt 0 discriminator 10
	leaq	.LC158(%rip), %rax
	movq	%rax, -112(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -104(%rbp)
	movq	-112(%rbp), %rbx
	movq	-104(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1142:
.LBE303:
.LBB304:
	.loc 2 1465 4 is_stmt 1 discriminator 5
	leaq	-64(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__bare_target___wrapped_statements.28
	.loc 2 1464 35
	movq	-64(%rbp), %rdx
	movl	6824(%rdx), %edx
	.loc 2 1464 16
	cmpl	%edx, %eax
	jle	.L1144
.LBB305:
	.loc 2 1464 16 is_stmt 0 discriminator 1
	leaq	.LC159(%rip), %r14
	leaq	.LC6(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1144:
.LBE305:
.LBE304:
.LBE298:
	.loc 2 1465 4 is_stmt 1
	subq	$-128, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE98:
	.size	silver_output_profile__bare_target, .-silver_output_profile__bare_target
	.section	.rodata
	.align 8
.LC160:
	.ascii	"failed precondition from silver_output_profile.adb:1621"
	.align 8
.LC161:
	.ascii	"failed precondition from silver_output_profile.adb:1622"
	.text
	.align 2
	.globl	silver_output_profile__chain_token
	.type	silver_output_profile__chain_token, @function
silver_output_profile__chain_token:
.LFB100:
	.loc 2 1623 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$32, %rsp
	.cfi_offset 14, -24
	.cfi_offset 13, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r12
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r12, %rdi
	movq	%rsi, -48(%rbp)
	movq	%rdi, -40(%rbp)
	movl	%edx, -52(%rbp)
	.loc 2 1623 4
	movq	-40(%rbp), %rax
	movl	(%rax), %r13d
	movq	-40(%rbp), %rax
	movl	4(%rax), %r12d
	movq	-40(%rbp), %rax
	movl	4(%rax), %edx
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L1146
	.loc 2 1623 4 is_stmt 0 discriminator 1
	movq	-40(%rbp), %rax
	movl	4(%rax), %esi
	movslq	%esi, %rax
	cqto
	movq	-40(%rbp), %rsi
	movl	(%rsi), %r14d
	movslq	%r14d, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L1147
.L1146:
	.loc 2 1623 4 discriminator 2
	movl	$0, %eax
	movl	$0, %edx
.L1147:
	.loc 2 1621 15 is_stmt 1
	cmpl	$1, %r13d
	je	.L1148
.LBB306:
	.loc 2 1621 15 is_stmt 0 discriminator 1
	leaq	.LC160(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1148:
.LBE306:
	.loc 2 1621 51 is_stmt 1 discriminator 2
	movl	%eax, %esi
	.loc 2 1621 15 discriminator 2
	testl	%esi, %esi
	jle	.L1149
	.loc 2 1621 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L1150
.L1149:
.LBB307:
	.loc 2 1621 15 discriminator 4
	leaq	.LC160(%rip), %r8
	leaq	.LC1(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1150:
.LBE307:
	.loc 2 1622 41
	cmpl	$2147483647, %r12d
	jne	.L1151
	.loc 2 1622 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1622, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1151:
	.loc 2 1622 41 discriminator 3
	leal	1(%r12), %eax
	.loc 2 1621 15 is_stmt 1 discriminator 5
	cmpl	-52(%rbp), %eax
	jge	.L1152
.LBB308:
	.loc 2 1621 15 is_stmt 0 discriminator 6
	leaq	.LC161(%rip), %rcx
	leaq	.LC1(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1152:
.LBE308:
	.loc 2 1624 10 is_stmt 1
	movl	-52(%rbp), %edx
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movl	$29, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1624 7 discriminator 1
	testl	%eax, %eax
	je	.L1153
	.loc 2 1624 61 discriminator 2
	movl	$29, %eax
	jmp	.L1154
.L1153:
	.loc 2 1625 13
	movl	-52(%rbp), %edx
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movl	$30, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1625 7 discriminator 1
	testl	%eax, %eax
	je	.L1155
	.loc 2 1625 63 discriminator 2
	movl	$30, %eax
	jmp	.L1154
.L1155:
	.loc 2 1626 12
	movl	$10, %eax
.L1154:
	.loc 2 1623 4
	addq	$32, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE100:
	.size	silver_output_profile__chain_token, .-silver_output_profile__chain_token
	.align 2
	.type	silver_output_profile__chain_after___wrapped_statements.29, @function
silver_output_profile__chain_after___wrapped_statements.29:
.LFB102:
	.loc 2 1634 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r12
	pushq	%rbx
	subq	$16, %rsp
	.cfi_offset 12, -24
	.cfi_offset 3, -32
	movq	%r10, %rbx
	movq	%r10, -24(%rbp)
	.loc 2 1636 7
	movzbl	12(%rbx), %eax
	cmpb	$29, %al
	jne	.L1157
	.loc 2 1636 7 is_stmt 0 discriminator 1
	movl	$24, %r12d
	jmp	.L1158
.L1157:
	.loc 2 1636 7 discriminator 2
	movl	$25, %r12d
.L1158:
	.loc 2 1636 7 discriminator 3
	movq	(%rbx), %rax
	movl	8(%rbx), %edx
	movzbl	12(%rbx), %ecx
	movzbl	%cl, %ecx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	movl	%eax, %edi
	.loc 2 1636 7 discriminator 4
	movq	(%rbx), %rax
	movzbl	%r12b, %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%edx, %ecx
	movl	%edi, %edx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1634 4 is_stmt 1
	addq	$16, %rsp
	popq	%rbx
	popq	%r12
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE102:
	.size	silver_output_profile__chain_after___wrapped_statements.29, .-silver_output_profile__chain_after___wrapped_statements.29
	.section	.rodata
	.align 8
.LC162:
	.ascii	"failed precondition from silver_output_profile.adb:1631"
	.align 8
.LC163:
	.ascii	"failed precondition from silver_output_profile.adb:1632"
	.align 8
.LC164:
	.ascii	"failed postcondition from silver_output_profile.adb:1633"
	.text
	.align 2
	.globl	silver_output_profile__chain_after
	.type	silver_output_profile__chain_after, @function
silver_output_profile__chain_after:
.LFB101:
	.loc 2 1634 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movl	%edx, -100(%rbp)
	movb	%cl, -101(%rbp)
	.loc 2 1634 4
	leaq	16(%rbp), %rdx
	.loc 2 1634 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -80(%rbp)
	movl	-100(%rbp), %eax
	movl	%eax, -72(%rbp)
	movzbl	-101(%rbp), %eax
	movb	%al, -68(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %r8d
	movq	-88(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -108(%rbp)
	movq	-88(%rbp), %rax
	movl	4(%rax), %edx
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L1161
	.loc 2 1634 4 discriminator 2
	movq	-88(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L1162
.L1161:
	.loc 2 1634 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L1162:
.LBB309:
	.loc 2 1631 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L1163
.LBB310:
	.loc 2 1631 15 is_stmt 0 discriminator 1
	leaq	.LC162(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1163:
.LBE310:
	.loc 2 1631 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 1631 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L1164
	.loc 2 1631 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L1165
.L1164:
.LBB311:
	.loc 2 1631 15 discriminator 4
	leaq	.LC162(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1165:
.LBE311:
	.loc 2 1632 41
	cmpl	$2147483647, -108(%rbp)
	jne	.L1166
	.loc 2 1632 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1632, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1166:
	.loc 2 1632 41 discriminator 3
	movl	-108(%rbp), %eax
	leal	1(%rax), %edx
	.loc 2 1631 15 is_stmt 1 discriminator 5
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L1167
.LBB312:
	.loc 2 1631 15 is_stmt 0 discriminator 6
	leaq	.LC163(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1167:
.LBE312:
	.loc 2 1631 15 discriminator 7
	movzbl	-68(%rbp), %eax
	cmpb	$29, %al
	je	.L1168
	.loc 2 1632 80 is_stmt 1 discriminator 4
	movzbl	-68(%rbp), %eax
	cmpb	$30, %al
	je	.L1168
.LBB313:
	.loc 2 1631 15 discriminator 8
	leaq	.LC163(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1168:
.LBE313:
.LBB314:
	.loc 2 1634 4 discriminator 5
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__chain_after___wrapped_statements.29
	.loc 2 1633 16
	testl	%eax, %eax
	je	.L1172
	.loc 2 1633 39 discriminator 1
	movl	-72(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L1170
	.loc 2 1633 95 discriminator 2
	cmpl	$2147483647, -108(%rbp)
	jne	.L1171
	.loc 2 1633 95 is_stmt 0 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$1633, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1171:
	.loc 2 1633 95 discriminator 5
	movl	-108(%rbp), %edx
	addl	$1, %edx
	.loc 2 1633 66 is_stmt 1 discriminator 6
	cmpl	%eax, %edx
	jge	.L1172
.L1170:
.LBB315:
	.loc 2 1633 16 discriminator 7
	leaq	.LC164(%rip), %r12
	leaq	.LC6(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1172:
.LBE315:
.LBE314:
.LBE309:
	.loc 2 1634 4
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE101:
	.size	silver_output_profile__chain_after, .-silver_output_profile__chain_after
	.section	.rodata
	.align 8
.LC165:
	.ascii	"failed precondition from silver_output_profile.adb:1695"
	.align 8
.LC166:
	.ascii	"failed precondition from silver_output_profile.adb:1696"
	.align 8
.LC167:
	.ascii	"failed precondition from silver_output_profile.adb:1697"
	.align 8
.LC168:
	.ascii	"failed postcondition from silver_output_profile.adb:1698"
	.align 8
.LC169:
	.ascii	"failed postcondition from silver_output_profile.adb:1699"
	.text
	.align 2
	.type	silver_output_profile__read_primary_into, @function
silver_output_profile__read_primary_into:
.LFB103:
	.loc 2 1724 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$224, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r10
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r10, %rdi
	movq	%rsi, -112(%rbp)
	movq	%rdi, -104(%rbp)
	movq	%rdx, -120(%rbp)
	movl	%ecx, -124(%rbp)
	movq	%r8, -136(%rbp)
	movq	%r9, -144(%rbp)
	.loc 2 1724 4
	leaq	16(%rbp), %rdx
	.loc 2 1724 4 is_stmt 0 discriminator 1
	leaq	-112(%rbp), %rax
	movq	%rdx, -48(%rbp)
	movq	%rax, -64(%rbp)
	movq	-120(%rbp), %rax
	movq	%rax, -88(%rbp)
	movl	-124(%rbp), %eax
	movl	%eax, -56(%rbp)
	movq	-136(%rbp), %rax
	movq	%rax, -72(%rbp)
	movq	-144(%rbp), %rax
	movq	%rax, -80(%rbp)
	movq	-104(%rbp), %rax
	movl	(%rax), %r8d
	movq	-104(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%r8d, %r12d
	jl	.L1174
	.loc 2 1724 4 discriminator 2
	movslq	%r12d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r8d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L1175
.L1174:
	.loc 2 1724 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L1175:
.LBB316:
	.loc 2 1724 4 discriminator 4
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	cltq
	addq	$2, %rax
	salq	$3, %rax
	movq	%rax, -96(%rbp)
	cmpl	%r8d, %r12d
	.loc 2 1724 4 discriminator 7
	cmpl	%r8d, %r12d
	.loc 2 1724 4 discriminator 10
	cmpl	%r8d, %r12d
	.loc 2 1695 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L1182
.LBB317:
	.loc 2 1695 15 is_stmt 0 discriminator 1
	leaq	.LC165(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1182:
.LBE317:
	.loc 2 1695 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 1695 15 discriminator 2
	testl	%eax, %eax
	jle	.L1183
	.loc 2 1695 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L1184
.L1183:
.LBB318:
	.loc 2 1695 15 discriminator 4
	leaq	.LC165(%rip), %rax
	movq	%rax, -256(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -248(%rbp)
	movq	-256(%rbp), %rbx
	movq	-248(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1184:
.LBE318:
	.loc 2 1696 41
	cmpl	$2147483647, %r12d
	jne	.L1185
	.loc 2 1696 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1696, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1185:
	.loc 2 1696 41 discriminator 3
	leal	1(%r12), %edx
	.loc 2 1695 15 is_stmt 1 discriminator 5
	movl	-56(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L1186
.LBB319:
	.loc 2 1695 15 is_stmt 0 discriminator 6
	leaq	.LC166(%rip), %rax
	movq	%rax, -240(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -232(%rbp)
	movq	-240(%rbp), %rbx
	movq	-232(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1186:
.LBE319:
	.loc 2 1696 54 is_stmt 1 discriminator 4
	movq	-88(%rbp), %rdx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_context
	.loc 2 1696 54 is_stmt 0 discriminator 5
	xorl	$1, %eax
	.loc 2 1695 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L1187
.LBB320:
	.loc 2 1695 15 is_stmt 0 discriminator 8
	leaq	.LC166(%rip), %rax
	movq	%rax, -224(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rbx
	movq	-216(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1187:
.LBE320:
	.loc 2 1697 19 is_stmt 1
	movq	-88(%rbp), %rax
	movq	-72(%rbp), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__valid_flow
	.loc 2 1697 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 1695 15 is_stmt 1 discriminator 9
	testb	%al, %al
	je	.L1188
.LBB321:
	.loc 2 1695 15 is_stmt 0 discriminator 10
	leaq	.LC167(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1188:
.LBE321:
	.loc 2 1697 69 is_stmt 1 discriminator 2
	movq	-80(%rbp), %rax
	movl	(%rax), %edx
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 1695 15 discriminator 11
	cmpl	%eax, %edx
	je	.L1189
.LBB322:
	.loc 2 1695 15 is_stmt 0 discriminator 12
	leaq	.LC167(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1189:
.LBE322:
	.loc 2 1701 55 is_stmt 1
	cmpl	$2147483647, %r12d
	jne	.L1190
	.loc 2 1701 55 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1701, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1190:
	.loc 2 1701 55 discriminator 3
	leal	1(%r12), %eax
	.loc 2 1701 60 is_stmt 1 discriminator 4
	movl	-56(%rbp), %edx
	movl	$0, %ecx
	subl	%edx, %eax
	jno	.L1191
	movl	$1, %ecx
.L1191:
	movl	%eax, %edx
	.loc 2 1701 60 is_stmt 0 discriminator 5
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L1193
	.loc 2 1701 60 discriminator 6
	leaq	.LC12(%rip), %rax
	movl	$1701, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1193:
	.loc 2 1701 60 discriminator 8
	movl	%edx, %eax
	movl	%eax, -52(%rbp)
	.loc 2 1724 4 is_stmt 1 discriminator 13
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__read_primary_into___wrapped_statements.30
	.loc 2 1698 28
	movq	-88(%rbp), %rax
	movq	-80(%rbp), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__valid_condition
	.loc 2 1698 28 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L1194
.LBB323:
	.loc 2 1698 28 discriminator 2
	leaq	.LC168(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rcx
	movq	-168(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1194:
.LBE323:
	.loc 2 1699 33 is_stmt 1
	movq	-80(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 1698 28 discriminator 3
	testl	%eax, %eax
	je	.L1198
	.loc 2 1699 58 discriminator 1
	movq	-80(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 1699 37 discriminator 1
	movl	-56(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L1196
	.loc 2 1699 58 discriminator 2
	movq	-80(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 1699 87 discriminator 2
	cmpl	$2147483647, %r12d
	jne	.L1197
	.loc 2 1699 87 is_stmt 0 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$1699, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1197:
	.loc 2 1699 87 discriminator 5
	leal	1(%r12), %edx
	.loc 2 1699 58 is_stmt 1 discriminator 6
	cmpl	%eax, %edx
	jge	.L1198
.L1196:
.LBB324:
	.loc 2 1698 28 discriminator 4
	leaq	.LC169(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rcx
	movq	-152(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1198:
.LBE324:
	.loc 2 1724 4 discriminator 15
	nop
.LBE316:
	.loc 2 1724 4 is_stmt 0
	addq	$224, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE103:
	.size	silver_output_profile__read_primary_into, .-silver_output_profile__read_primary_into
	.align 2
	.type	silver_output_profile__read_primary_into___wrapped_statements.30, @function
silver_output_profile__read_primary_into___wrapped_statements.30:
.LFB105:
	.loc 2 1724 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r12
	pushq	%rbx
	subq	$32, %rsp
	.cfi_offset 12, -24
	.cfi_offset 3, -32
	movq	%r10, %rbx
	movq	%r10, -40(%rbp)
	.loc 2 1727 44
	movq	32(%rbx), %rax
	movl	40(%rbx), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$11, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1727 44 is_stmt 0 discriminator 1
	movl	%eax, -20(%rbp)
	.loc 2 1729 7 is_stmt 1
	movl	40(%rbx), %eax
	testl	%eax, %eax
	jne	.L1200
	.loc 2 1730 10
	movq	24(%rbx), %rax
	movq	16(%rbx), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__invalidate_condition
	.loc 2 1749 8
	jmp	.L1207
.L1200:
	.loc 2 1731 7
	cmpl	$0, -20(%rbp)
	je	.L1202
	.loc 2 1733 10
	movq	32(%rbx), %rax
	movq	8(%rbx), %rdx
	movq	24(%rbx), %rdi
	movq	16(%rbx), %r8
	movl	-20(%rbp), %ecx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%r8, %r9
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__read_condition_into
	.loc 2 1734 26
	movq	16(%rbx), %rax
	movl	4(%rax), %edx
	movq	32(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$12, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1734 23 discriminator 1
	movq	16(%rbx), %rdx
	movl	%eax, 4(%rdx)
	.loc 2 1735 26
	movq	16(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 1735 10
	testl	%eax, %eax
	jne	.L1207
	.loc 2 1735 35 discriminator 1
	movq	24(%rbx), %rax
	movq	16(%rbx), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__invalidate_condition
	.loc 2 1749 8
	jmp	.L1207
.L1202:
	.loc 2 1736 35
	movq	8(%rbx), %rax
	movl	17744(%rax), %eax
	.loc 2 1736 7
	testl	%eax, %eax
	jne	.L1203
	.loc 2 1737 10
	movq	24(%rbx), %rax
	movq	16(%rbx), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__invalidate_condition
	.loc 2 1749 8
	jmp	.L1207
.L1203:
	.loc 2 1739 26
	movq	8(%rbx), %rax
	leaq	6824(%rax), %rcx
	movq	8(%rbx), %rax
	movq	%rax, %rdi
	movq	32(%rbx), %rax
	movl	40(%rbx), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rcx, %r9
	movl	$3, %r8d
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__call_after
	.loc 2 1739 23 discriminator 1
	movq	16(%rbx), %rdx
	movl	%eax, 4(%rdx)
	.loc 2 1740 16
	movq	16(%rbx), %rax
	movl	(%rax), %edx
	.loc 2 1740 30
	movq	24(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1204
	.loc 2 1740 30 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1740, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1204:
	.loc 2 1740 27 is_stmt 1 discriminator 2
	movq	16(%rbx), %rax
	leaq	8(%rax), %rcx
	movq	24(%rbx), %rdx
	movq	(%rbx), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 1741 16
	movq	16(%rbx), %rax
	movl	(%rax), %edx
	.loc 2 1741 31
	movq	24(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1205
	.loc 2 1741 31 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1741, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1205:
	.loc 2 1741 28 is_stmt 1 discriminator 2
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	shrq	$2, %rax
	movq	%rax, %rdx
	movq	16(%rbx), %rax
	salq	$2, %rdx
	leaq	(%rax,%rdx), %rcx
	movq	24(%rbx), %rdx
	movq	(%rbx), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 1742 26
	movq	16(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 1742 10
	testl	%eax, %eax
	jne	.L1206
	.loc 2 1743 13
	movq	24(%rbx), %rax
	movq	16(%rbx), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__invalidate_condition
	.loc 2 1749 8
	jmp	.L1207
.L1206:
	.loc 2 1745 43
	movq	24(%rbx), %rax
	movq	16(%rbx), %r12
	movq	4(%rax), %rdx
	movl	12(%rax), %eax
	movq	%rdx, %rdi
	movl	%eax, %esi
	call	silver_path_facts__assume_valid@PLT
	movq	%rax, 12(%r12)
	movl	20(%r12), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, 20(%r12)
	.loc 2 1746 36
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	shrq	$2, %rax
	movq	%rax, %r12
	.loc 2 1746 44
	movq	24(%rbx), %rax
	movq	16(%rbx), %rbx
	movq	4(%rax), %rdx
	movl	12(%rax), %eax
	movq	%rdx, %rdi
	movl	%eax, %esi
	call	silver_path_facts__assume_invalid@PLT
	movq	%rax, 4(%rbx,%r12,4)
	movl	12(%rbx,%r12,4), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, 12(%rbx,%r12,4)
.L1207:
	.loc 2 1749 8 discriminator 1
	nop
	.loc 2 1749 8 is_stmt 0
	addq	$32, %rsp
	popq	%rbx
	popq	%r12
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE105:
	.size	silver_output_profile__read_primary_into___wrapped_statements.30, .-silver_output_profile__read_primary_into___wrapped_statements.30
	.section	.rodata
	.align 8
.LC170:
	.ascii	"failed precondition from silver_output_profile.adb:1706"
	.align 8
.LC171:
	.ascii	"failed precondition from silver_output_profile.adb:1707"
	.align 8
.LC172:
	.ascii	"failed precondition from silver_output_profile.adb:1708"
	.align 8
.LC173:
	.ascii	"failed postcondition from silver_output_profile.adb:1709"
	.align 8
.LC174:
	.ascii	"failed postcondition from silver_output_profile.adb:1710"
	.text
	.align 2
	.type	silver_output_profile__read_relation_into, @function
silver_output_profile__read_relation_into:
.LFB106:
	.loc 2 1750 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$224, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r10
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r10, %rdi
	movq	%rsi, -112(%rbp)
	movq	%rdi, -104(%rbp)
	movq	%rdx, -120(%rbp)
	movl	%ecx, -124(%rbp)
	movq	%r8, -136(%rbp)
	movq	%r9, -144(%rbp)
	.loc 2 1750 4
	leaq	16(%rbp), %rdx
	.loc 2 1750 4 is_stmt 0 discriminator 1
	leaq	-112(%rbp), %rax
	movq	%rdx, -48(%rbp)
	movq	%rax, -64(%rbp)
	movq	-120(%rbp), %rax
	movq	%rax, -72(%rbp)
	movl	-124(%rbp), %eax
	movl	%eax, -56(%rbp)
	movq	-136(%rbp), %rax
	movq	%rax, -80(%rbp)
	movq	-144(%rbp), %rax
	movq	%rax, -88(%rbp)
	movq	-104(%rbp), %rax
	movl	(%rax), %r8d
	movq	-104(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%r8d, %r12d
	jl	.L1209
	.loc 2 1750 4 discriminator 2
	movslq	%r12d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r8d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L1210
.L1209:
	.loc 2 1750 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L1210:
.LBB325:
	.loc 2 1750 4 discriminator 4
	movq	-80(%rbp), %rax
	movl	(%rax), %eax
	cltq
	addq	$2, %rax
	salq	$3, %rax
	movq	%rax, -96(%rbp)
	cmpl	%r8d, %r12d
	.loc 2 1750 4 discriminator 7
	cmpl	%r8d, %r12d
	.loc 2 1750 4 discriminator 10
	cmpl	%r8d, %r12d
	.loc 2 1706 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L1217
.LBB326:
	.loc 2 1706 15 is_stmt 0 discriminator 1
	leaq	.LC170(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1217:
.LBE326:
	.loc 2 1706 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 1706 15 discriminator 2
	testl	%eax, %eax
	jle	.L1218
	.loc 2 1706 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L1219
.L1218:
.LBB327:
	.loc 2 1706 15 discriminator 4
	leaq	.LC170(%rip), %rax
	movq	%rax, -256(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -248(%rbp)
	movq	-256(%rbp), %rbx
	movq	-248(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1219:
.LBE327:
	.loc 2 1707 41
	cmpl	$2147483647, %r12d
	jne	.L1220
	.loc 2 1707 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1707, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1220:
	.loc 2 1707 41 discriminator 3
	leal	1(%r12), %edx
	.loc 2 1706 15 is_stmt 1 discriminator 5
	movl	-56(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L1221
.LBB328:
	.loc 2 1706 15 is_stmt 0 discriminator 6
	leaq	.LC171(%rip), %rax
	movq	%rax, -240(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -232(%rbp)
	movq	-240(%rbp), %rbx
	movq	-232(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1221:
.LBE328:
	.loc 2 1707 54 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_context
	.loc 2 1707 54 is_stmt 0 discriminator 5
	xorl	$1, %eax
	.loc 2 1706 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L1222
.LBB329:
	.loc 2 1706 15 is_stmt 0 discriminator 8
	leaq	.LC171(%rip), %rax
	movq	%rax, -224(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rbx
	movq	-216(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1222:
.LBE329:
	.loc 2 1708 19 is_stmt 1
	movq	-72(%rbp), %rax
	movq	-80(%rbp), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__valid_flow
	.loc 2 1708 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 1706 15 is_stmt 1 discriminator 9
	testb	%al, %al
	je	.L1223
.LBB330:
	.loc 2 1706 15 is_stmt 0 discriminator 10
	leaq	.LC172(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1223:
.LBE330:
	.loc 2 1708 69 is_stmt 1 discriminator 2
	movq	-88(%rbp), %rax
	movl	(%rax), %edx
	movq	-80(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 1706 15 discriminator 11
	cmpl	%eax, %edx
	je	.L1224
.LBB331:
	.loc 2 1706 15 is_stmt 0 discriminator 12
	leaq	.LC172(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1224:
.LBE331:
	.loc 2 1712 55 is_stmt 1
	cmpl	$2147483647, %r12d
	jne	.L1225
	.loc 2 1712 55 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1712, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1225:
	.loc 2 1712 55 discriminator 3
	leal	1(%r12), %eax
	.loc 2 1712 60 is_stmt 1 discriminator 4
	movl	-56(%rbp), %edx
	movl	$0, %ecx
	subl	%edx, %eax
	jno	.L1226
	movl	$1, %ecx
.L1226:
	movl	%eax, %edx
	.loc 2 1712 60 is_stmt 0 discriminator 5
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L1228
	.loc 2 1712 60 discriminator 6
	leaq	.LC12(%rip), %rax
	movl	$1712, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1228:
	.loc 2 1712 60 discriminator 8
	movl	%edx, %eax
	movl	%eax, -52(%rbp)
	.loc 2 1750 4 is_stmt 1 discriminator 13
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__read_relation_into___wrapped_statements.31
	.loc 2 1709 28
	movq	-72(%rbp), %rax
	movq	-88(%rbp), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__valid_condition
	.loc 2 1709 28 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L1229
.LBB332:
	.loc 2 1709 28 discriminator 2
	leaq	.LC173(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rcx
	movq	-168(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1229:
.LBE332:
	.loc 2 1710 33 is_stmt 1
	movq	-88(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 1709 28 discriminator 3
	testl	%eax, %eax
	je	.L1233
	.loc 2 1710 58 discriminator 1
	movq	-88(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 1710 37 discriminator 1
	movl	-56(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L1231
	.loc 2 1710 58 discriminator 2
	movq	-88(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 1710 87 discriminator 2
	cmpl	$2147483647, %r12d
	jne	.L1232
	.loc 2 1710 87 is_stmt 0 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$1710, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1232:
	.loc 2 1710 87 discriminator 5
	leal	1(%r12), %edx
	.loc 2 1710 58 is_stmt 1 discriminator 6
	cmpl	%eax, %edx
	jge	.L1233
.L1231:
.LBB333:
	.loc 2 1709 28 discriminator 4
	leaq	.LC174(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rcx
	movq	-152(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1233:
.LBE333:
	.loc 2 1750 4 discriminator 15
	nop
.LBE325:
	.loc 2 1750 4 is_stmt 0
	addq	$224, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE106:
	.size	silver_output_profile__read_relation_into, .-silver_output_profile__read_relation_into
	.align 2
	.type	silver_output_profile__read_relation_into___wrapped_statements.31, @function
silver_output_profile__read_relation_into___wrapped_statements.31:
.LFB108:
	.loc 2 1750 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$240, %rsp
	.cfi_offset 14, -24
	.cfi_offset 13, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%r10, %rbx
	movq	%r10, -264(%rbp)
	.loc 2 1753 44
	movq	32(%rbx), %rax
	movl	40(%rbx), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$31, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 1753 44 is_stmt 0 discriminator 1
	movl	%eax, -52(%rbp)
	.loc 2 1754 47 is_stmt 1
	movq	32(%rbx), %rax
	movq	24(%rbx), %rdx
	movl	40(%rbx), %ecx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$0, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__length_at
	movq	%rax, -80(%rbp)
	movl	-72(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -72(%rbp)
	.loc 2 1755 70
	movq	32(%rbx), %rax
	movq	24(%rbx), %rcx
	movl	40(%rbx), %esi
	movq	16(%rbx), %r8
	leaq	-112(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	pushq	$0
	pushq	$0
	movq	%r8, %r9
	movl	%esi, %r8d
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__read_scalar_in_flow
	addq	$16, %rsp
	.loc 2 1759 7
	movl	40(%rbx), %eax
	testl	%eax, %eax
	jne	.L1235
	.loc 2 1760 10
	movq	16(%rbx), %rax
	movq	8(%rbx), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__invalidate_condition
	.loc 2 1864 8
	jmp	.L1277
.L1235:
	.loc 2 1761 7
	cmpl	$0, -52(%rbp)
	je	.L1237
	.loc 2 1762 10
	movq	32(%rbx), %rax
	movq	24(%rbx), %rdx
	movq	16(%rbx), %rdi
	movq	8(%rbx), %r8
	movl	-52(%rbp), %ecx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%r8, %r9
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__read_primary_into
	.loc 2 1763 25
	movq	8(%rbx), %rax
	movq	12(%rax), %rdx
	movq	%rdx, -128(%rbp)
	movl	20(%rax), %eax
	movl	%eax, -120(%rbp)
	.loc 2 1764 32
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	shrq	$2, %rax
	movq	%rax, %rcx
	movq	8(%rbx), %rdx
	movq	8(%rbx), %rax
	movq	4(%rdx,%rcx,4), %rsi
	movq	%rsi, 12(%rax)
	movl	12(%rdx,%rcx,4), %edx
	movl	%edx, 20(%rax)
	.loc 2 1765 33
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	shrq	$2, %rax
	movq	%rax, %rdx
	movq	8(%rbx), %rax
	movq	-128(%rbp), %rcx
	movq	%rcx, 4(%rax,%rdx,4)
	movl	-120(%rbp), %ecx
	movl	%ecx, 12(%rax,%rdx,4)
	.loc 2 1766 14
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, -64(%rbp)
	cmpl	$0, -64(%rbp)
	jle	.L1277
.LBB334:
	.loc 2 1766 14 is_stmt 0 discriminator 1
	movl	$1, -36(%rbp)
.L1242:
.LBB335:
	.loc 2 1775 38 is_stmt 1
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	.loc 2 1775 48
	cmpl	%eax, -36(%rbp)
	jle	.L1238
	.loc 2 1775 48 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1775, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1238:
	.loc 2 1775 29 is_stmt 1 discriminator 2
	movl	-36(%rbp), %eax
	movslq	%eax, %rdx
	movq	8(%rbx), %rax
	addq	$1, %rdx
	movq	8(%rax,%rdx,8), %rax
	.loc 2 1775 29 is_stmt 0 discriminator 3
	movq	%rax, -136(%rbp)
	.loc 2 1776 19 is_stmt 1
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	.loc 2 1776 54
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	.loc 2 1776 29
	cmpl	%edx, -36(%rbp)
	jle	.L1239
	.loc 2 1776 29 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1776, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1239:
	.loc 2 1776 65 is_stmt 1 discriminator 2
	cmpl	%eax, -36(%rbp)
	jle	.L1240
	.loc 2 1776 65 is_stmt 0 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$1776, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1240:
	.loc 2 1776 45 is_stmt 1 discriminator 4
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	shrq	$2, %rax
	movq	%rax, %rdi
	movl	-36(%rbp), %eax
	movslq	%eax, %rsi
	movl	-36(%rbp), %eax
	movslq	%eax, %rcx
	movq	8(%rbx), %rdx
	movq	8(%rbx), %rax
	addq	$1, %rcx
	addq	$1, %rsi
	addq	%rsi, %rsi
	addq	%rdi, %rsi
	movq	(%rdx,%rsi,4), %rdx
	movq	%rdx, 8(%rax,%rcx,8)
	.loc 2 1777 19
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	.loc 2 1777 30
	cmpl	%eax, -36(%rbp)
	jle	.L1241
	.loc 2 1777 30 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1777, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1241:
	.loc 2 1777 46 is_stmt 1 discriminator 2
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	shrq	$2, %rax
	movq	%rax, %rcx
	movl	-36(%rbp), %eax
	movslq	%eax, %rdx
	movq	8(%rbx), %rax
	addq	$1, %rdx
	addq	%rdx, %rdx
	addq	%rdx, %rcx
	movq	-136(%rbp), %rdx
	movq	%rdx, (%rax,%rcx,4)
.LBE335:
	.loc 2 1766 14 discriminator 2
	movl	-36(%rbp), %eax
	cmpl	-64(%rbp), %eax
	je	.L1277
	.loc 2 1766 14 is_stmt 0 discriminator 3
	addl	$1, -36(%rbp)
	.loc 2 1778 18 is_stmt 1
	jmp	.L1242
.L1237:
.LBE334:
	.loc 2 1779 31
	movl	-80(%rbp), %eax
	.loc 2 1779 7
	testl	%eax, %eax
	je	.L1243
.LBB336:
	.loc 2 1781 54
	movl	-80(%rbp), %edx
	movq	32(%rbx), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__scalar_comparison_at
	movq	%rax, -144(%rbp)
	.loc 2 1782 54
	movl	-144(%rbp), %ecx
	movq	32(%rbx), %rax
	movq	24(%rbx), %rdx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$1, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__length_at
	movq	%rax, -160(%rbp)
	movl	-152(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -152(%rbp)
	.loc 2 1784 35
	movl	-160(%rbp), %eax
	.loc 2 1784 13
	movl	40(%rbx), %edx
	cmpl	%eax, %edx
	jl	.L1244
	.loc 2 1785 16
	movq	16(%rbx), %rax
	movq	8(%rbx), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__invalidate_condition
	.loc 2 1795 13
	jmp	.L1236
.L1244:
	.loc 2 1787 29
	movl	-160(%rbp), %edx
	movq	8(%rbx), %rax
	movl	%edx, 4(%rax)
	.loc 2 1788 22
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	.loc 2 1788 36
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1246
	.loc 2 1788 36 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1788, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1246:
	.loc 2 1788 33 is_stmt 1 discriminator 2
	movq	8(%rbx), %rax
	leaq	8(%rax), %rcx
	movq	16(%rbx), %rdx
	movq	(%rbx), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 1789 22
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	.loc 2 1789 37
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1247
	.loc 2 1789 37 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1789, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1247:
	.loc 2 1789 34 is_stmt 1 discriminator 2
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	shrq	$2, %rax
	movq	%rax, %rdx
	movq	8(%rbx), %rax
	salq	$2, %rdx
	leaq	(%rax,%rdx), %rcx
	movq	16(%rbx), %rdx
	movq	(%rbx), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 1790 46
	movzbl	-140(%rbp), %edx
	movq	16(%rbx), %rax
	movq	8(%rbx), %r12
	movq	-156(%rbp), %rdi
	movq	-76(%rbp), %rcx
	movzbl	%dl, %edx
	movq	4(%rax), %rsi
	movl	12(%rax), %eax
	movl	$1, %r9d
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movl	%eax, %esi
	call	silver_path_facts__refine_bounds@PLT
	movq	%rax, 12(%r12)
	movl	20(%r12), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, 20(%r12)
	.loc 2 1792 47
	movzbl	-140(%rbp), %edx
	.loc 2 1792 39
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	shrq	$2, %rax
	movq	%rax, %r12
	.loc 2 1792 47
	movq	16(%rbx), %rax
	movq	8(%rbx), %rbx
	movq	-156(%rbp), %rdi
	movq	-76(%rbp), %rcx
	movzbl	%dl, %edx
	movq	4(%rax), %rsi
	movl	12(%rax), %eax
	movl	$0, %r9d
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movl	%eax, %esi
	call	silver_path_facts__refine_bounds@PLT
	movq	%rax, 4(%rbx,%r12,4)
	movl	12(%rbx,%r12,4), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, 12(%rbx,%r12,4)
.LBE336:
	.loc 2 1864 8
	jmp	.L1277
.L1243:
	.loc 2 1796 31
	movl	-112(%rbp), %eax
	.loc 2 1796 7
	testl	%eax, %eax
	je	.L1248
.LBB337:
	.loc 2 1798 54
	movl	-112(%rbp), %edx
	movq	32(%rbx), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__scalar_comparison_at
	movq	%rax, -168(%rbp)
	.loc 2 1800 15
	movl	-168(%rbp), %esi
	movq	32(%rbx), %rax
	movq	24(%rbx), %rcx
	movq	16(%rbx), %r8
	leaq	-192(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	pushq	$0
	pushq	$0
	movq	%r8, %r9
	movl	%esi, %r8d
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__read_scalar_in_flow
	addq	$16, %rsp
	.loc 2 1801 72
	movl	-112(%rbp), %edi
	movq	32(%rbx), %rax
	movq	24(%rbx), %rdx
	movl	40(%rbx), %ecx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__bare_target
	.loc 2 1801 72 is_stmt 0 discriminator 1
	movl	%eax, -56(%rbp)
	.loc 2 1802 73 is_stmt 1
	movl	-192(%rbp), %edi
	movl	-168(%rbp), %ecx
	movq	32(%rbx), %rax
	movq	24(%rbx), %rdx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__bare_target
	.loc 2 1802 73 is_stmt 0 discriminator 1
	movl	%eax, -60(%rbp)
	.loc 2 1803 13 is_stmt 1
	movl	$0, -40(%rbp)
	.loc 2 1804 46
	movzbl	-164(%rbp), %eax
	movzbl	%al, %eax
	movl	%eax, %edi
	call	silver_output_profile__scalar_operator
	.loc 2 1804 46 is_stmt 0 discriminator 1
	movb	%al, -41(%rbp)
	.loc 2 1805 13 is_stmt 1
	movl	-188(%rbp), %eax
	movl	%eax, -48(%rbp)
	.loc 2 1807 35
	movl	-192(%rbp), %eax
	.loc 2 1807 13
	movl	40(%rbx), %edx
	cmpl	%eax, %edx
	jl	.L1249
	.loc 2 1808 16
	movq	16(%rbx), %rax
	movq	8(%rbx), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__invalidate_condition
	.loc 2 1829 13
	jmp	.L1278
.L1249:
	.loc 2 1810 29
	movl	-192(%rbp), %edx
	movq	8(%rbx), %rax
	movl	%edx, 4(%rax)
	.loc 2 1811 22
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	.loc 2 1811 36
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1251
	.loc 2 1811 36 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1811, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1251:
	.loc 2 1811 33 is_stmt 1 discriminator 2
	movq	8(%rbx), %rax
	leaq	8(%rax), %rcx
	movq	16(%rbx), %rdx
	movq	(%rbx), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 1812 22
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	.loc 2 1812 37
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1252
	.loc 2 1812 37 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1812, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1252:
	.loc 2 1812 34 is_stmt 1 discriminator 2
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	shrq	$2, %rax
	movq	%rax, %rdx
	movq	8(%rbx), %rax
	salq	$2, %rdx
	leaq	(%rax,%rdx), %rcx
	movq	16(%rbx), %rdx
	movq	(%rbx), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 1813 16
	cmpl	$0, -56(%rbp)
	je	.L1253
	.loc 2 1813 36 discriminator 1
	movzbl	-176(%rbp), %eax
	testb	%al, %al
	je	.L1253
	.loc 2 1814 53
	movl	-188(%rbp), %edx
	movl	-184(%rbp), %eax
	.loc 2 1814 18
	cmpl	%eax, %edx
	jne	.L1253
	.loc 2 1816 26
	movl	-56(%rbp), %eax
	movl	%eax, -40(%rbp)
	jmp	.L1254
.L1253:
	.loc 2 1817 16
	cmpl	$0, -60(%rbp)
	je	.L1254
	.loc 2 1817 40 discriminator 1
	movzbl	-96(%rbp), %eax
	testb	%al, %al
	je	.L1254
	.loc 2 1818 52
	movl	-108(%rbp), %edx
	movl	-104(%rbp), %eax
	.loc 2 1818 18
	cmpl	%eax, %edx
	jne	.L1254
	.loc 2 1820 26
	movl	-60(%rbp), %eax
	movl	%eax, -40(%rbp)
	.loc 2 1821 38
	movzbl	-41(%rbp), %eax
	movl	%eax, %edi
	call	silver_scalars__swap@PLT
	.loc 2 1821 38 is_stmt 0 discriminator 1
	movb	%al, -41(%rbp)
	.loc 2 1822 29 is_stmt 1
	movl	-108(%rbp), %eax
	movl	%eax, -48(%rbp)
.L1254:
	.loc 2 1824 16
	cmpl	$0, -40(%rbp)
	je	.L1278
	.loc 2 1825 25
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	.loc 2 1825 35
	cmpl	$0, -40(%rbp)
	jle	.L1255
	.loc 2 1825 35 is_stmt 0 discriminator 1
	cmpl	%eax, -40(%rbp)
	jle	.L1256
.L1255:
	.loc 2 1825 35 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$1825, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1256:
	.loc 2 1825 76 is_stmt 1 discriminator 3
	cmpl	$0, -40(%rbp)
	jle	.L1257
	.loc 2 1825 76 is_stmt 0 discriminator 4
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, -40(%rbp)
	jle	.L1258
.L1257:
	.loc 2 1825 76 discriminator 5
	leaq	.LC12(%rip), %rax
	movl	$1825, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1258:
	.loc 2 1825 44 is_stmt 1 discriminator 6
	movl	-40(%rbp), %eax
	movl	%eax, %edx
	cmpl	$341, %edx
	jbe	.L1259
	.loc 2 1825 44 is_stmt 0 discriminator 7
	leaq	.LC12(%rip), %rax
	movl	$1825, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L1259:
	.loc 2 1825 55 is_stmt 1 discriminator 8
	movl	-40(%rbp), %edx
	movslq	%edx, %rcx
	.loc 2 1825 52 discriminator 8
	movslq	%eax, %rdx
	.loc 2 1825 55 discriminator 8
	movq	16(%rbx), %rax
	movq	8(%rbx), %r12
	leaq	1(%rdx), %r13
	movl	-48(%rbp), %edx
	movzbl	-41(%rbp), %esi
	addq	$1, %rcx
	movq	(%rax,%rcx,8), %rax
	movl	$1, %ecx
	movq	%rax, %rdi
	call	silver_output_profile__refine_or_keep
	movq	%rax, 8(%r12,%r13,8)
	.loc 2 1826 25
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	.loc 2 1826 36
	cmpl	$0, -40(%rbp)
	jle	.L1260
	.loc 2 1826 36 is_stmt 0 discriminator 1
	cmpl	%eax, -40(%rbp)
	jle	.L1261
.L1260:
	.loc 2 1826 36 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$1826, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1261:
	.loc 2 1826 77 is_stmt 1 discriminator 3
	cmpl	$0, -40(%rbp)
	jle	.L1262
	.loc 2 1826 77 is_stmt 0 discriminator 4
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, -40(%rbp)
	jle	.L1263
.L1262:
	.loc 2 1826 77 discriminator 5
	leaq	.LC12(%rip), %rax
	movl	$1826, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1263:
	.loc 2 1826 45 is_stmt 1 discriminator 6
	movl	-40(%rbp), %eax
	movl	%eax, %edx
	cmpl	$341, %edx
	jbe	.L1264
	.loc 2 1826 45 is_stmt 0 discriminator 7
	leaq	.LC12(%rip), %rax
	movl	$1826, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L1264:
	.loc 2 1826 56 is_stmt 1 discriminator 8
	movl	-40(%rbp), %edx
	movslq	%edx, %rcx
	.loc 2 1826 53 discriminator 8
	movq	8(%rbx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	addq	$3, %rdx
	salq	$3, %rdx
	movq	%rdx, %rsi
	shrq	$2, %rsi
	movslq	%eax, %rdx
	.loc 2 1826 56 discriminator 8
	movq	16(%rbx), %rax
	movq	8(%rbx), %rbx
	addq	$1, %rdx
	addq	%rdx, %rdx
	leaq	(%rdx,%rsi), %r12
	movl	-48(%rbp), %edx
	movzbl	-41(%rbp), %esi
	addq	$1, %rcx
	movq	(%rax,%rcx,8), %rax
	movl	$0, %ecx
	movq	%rax, %rdi
	call	silver_output_profile__refine_or_keep
	movq	%rax, (%rbx,%r12,4)
.LBE337:
	.loc 2 1864 8
	jmp	.L1277
.L1248:
.LBB338:
	.loc 2 1831 55
	movq	32(%rbx), %rax
	movq	24(%rbx), %rcx
	movl	40(%rbx), %esi
	movq	16(%rbx), %r8
	leaq	-224(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%r8, %r9
	movl	%esi, %r8d
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__read_string_in_flow
	.loc 2 1833 27
	movl	-224(%rbp), %eax
	.loc 2 1833 13
	testl	%eax, %eax
	je	.L1265
.LBB339:
	.loc 2 1834 65
	movl	-224(%rbp), %edx
	movq	32(%rbx), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__scalar_comparison_at
	movq	%rax, -232(%rbp)
	.loc 2 1836 37
	movl	-232(%rbp), %eax
	.loc 2 1836 19
	testl	%eax, %eax
	je	.L1266
	.loc 2 1836 79 discriminator 1
	movzbl	-228(%rbp), %eax
	.loc 2 1836 41 discriminator 1
	testb	%al, %al
	je	.L1267
	.loc 2 1836 93 discriminator 2
	movzbl	-228(%rbp), %eax
	cmpb	$1, %al
	je	.L1267
.L1266:
	.loc 2 1837 22
	movq	16(%rbx), %rax
	movq	8(%rbx), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__invalidate_condition
	.loc 2 1837 22 is_stmt 0 discriminator 1
	jmp	.L1268
.L1267:
.LBB340:
	.loc 2 1839 68 is_stmt 1
	movl	-232(%rbp), %esi
	movq	32(%rbx), %rax
	movq	24(%rbx), %rcx
	movq	16(%rbx), %r8
	leaq	-256(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%r8, %r9
	movl	%esi, %r8d
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__read_string_in_flow
	.loc 2 1841 40
	movl	-256(%rbp), %eax
	.loc 2 1841 25
	movl	40(%rbx), %edx
	cmpl	%eax, %edx
	jge	.L1269
	.loc 2 1841 81 discriminator 1
	movzbl	-208(%rbp), %eax
	xorl	$1, %eax
	.loc 2 1841 52 discriminator 1
	testb	%al, %al
	je	.L1270
	.loc 2 1841 81 discriminator 2
	movzbl	-240(%rbp), %eax
	xorl	$1, %eax
	testb	%al, %al
	jne	.L1269
.L1270:
	.loc 2 1842 74
	leaq	-224(%rbp), %rax
	movq	%rax, %rdi
	call	silver_output_profile__summary_of
	.loc 2 1842 55 discriminator 1
	movq	16(%rbx), %rcx
	movq	4(%rcx), %rdi
	movl	12(%rcx), %esi
	movq	%rdx, %rcx
	movq	%rax, %rdx
	call	silver_length_intervals__fits@PLT
	.loc 2 1842 35 discriminator 2
	xorl	$1, %eax
	.loc 2 1842 27 discriminator 2
	testb	%al, %al
	jne	.L1269
	.loc 2 1843 74
	leaq	-256(%rbp), %rax
	movq	%rax, %rdi
	call	silver_output_profile__summary_of
	.loc 2 1843 55 discriminator 1
	movq	16(%rbx), %rcx
	movq	4(%rcx), %rdi
	movl	12(%rcx), %esi
	movq	%rdx, %rcx
	movq	%rax, %rdx
	call	silver_length_intervals__fits@PLT
	.loc 2 1843 35 discriminator 2
	xorl	$1, %eax
	.loc 2 1843 27 discriminator 2
	testb	%al, %al
	je	.L1271
.L1269:
	.loc 2 1845 28
	movq	16(%rbx), %rax
	movq	8(%rbx), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__invalidate_condition
	.loc 2 1845 28 is_stmt 0 discriminator 1
	jmp	.L1272
.L1271:
	.loc 2 1847 41 is_stmt 1
	movl	-256(%rbp), %edx
	movq	8(%rbx), %rax
	movl	%edx, 4(%rax)
	.loc 2 1848 34
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	.loc 2 1848 48
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1273
	.loc 2 1848 48 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1848, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1273:
	.loc 2 1848 45 is_stmt 1 discriminator 2
	movq	8(%rbx), %rax
	leaq	8(%rax), %rcx
	movq	16(%rbx), %rdx
	movq	(%rbx), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 1849 34
	movq	8(%rbx), %rax
	movl	(%rax), %edx
	.loc 2 1849 49
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1274
	.loc 2 1849 49 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1849, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1274:
	.loc 2 1849 46 is_stmt 1 discriminator 2
	movq	8(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	shrq	$2, %rax
	movq	%rax, %rdx
	movq	8(%rbx), %rax
	salq	$2, %rdx
	leaq	(%rax,%rdx), %rcx
	movq	16(%rbx), %rdx
	movq	(%rbx), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 1850 49
	movzbl	-228(%rbp), %eax
	.loc 2 1850 28
	testb	%al, %al
	jne	.L1275
.LBB341:
	.loc 2 1851 118
	leaq	-256(%rbp), %rax
	movq	%rax, %rdi
	call	silver_output_profile__summary_of
	movq	%rax, %r12
	movq	%rdx, %r13
	.loc 2 1851 99 discriminator 1
	leaq	-224(%rbp), %rax
	movq	%rax, %rdi
	call	silver_output_profile__summary_of
	.loc 2 1851 72 discriminator 2
	movq	16(%rbx), %rcx
	movq	8(%rbx), %rbx
	movq	4(%rcx), %rdi
	movl	12(%rcx), %esi
	movq	%r12, %r8
	movq	%r13, %r9
	movq	%rdx, %rcx
	movq	%rax, %rdx
	call	silver_length_intervals__refine_equal@PLT
	movq	%rax, 12(%rbx)
	movl	20(%rbx), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, 20(%rbx)
	jmp	.L1272
.L1275:
.LBE341:
.LBB342:
	.loc 2 1853 119
	leaq	-256(%rbp), %rax
	movq	%rax, %rdi
	call	silver_output_profile__summary_of
	movq	%rax, %r12
	movq	%rdx, %r13
	.loc 2 1853 100 discriminator 1
	leaq	-224(%rbp), %rax
	movq	%rax, %rdi
	call	silver_output_profile__summary_of
	.loc 2 1853 54 discriminator 2
	movq	8(%rbx), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	addq	$3, %rcx
	salq	$3, %rcx
	shrq	$2, %rcx
	movq	%rcx, %r14
	.loc 2 1853 73 discriminator 2
	movq	16(%rbx), %rcx
	movq	8(%rbx), %rbx
	movq	4(%rcx), %rdi
	movl	12(%rcx), %esi
	movq	%r12, %r8
	movq	%r13, %r9
	movq	%rdx, %rcx
	movq	%rax, %rdx
	call	silver_length_intervals__refine_equal@PLT
	movq	%rax, 4(%rbx,%r14,4)
	movl	12(%rbx,%r14,4), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, 12(%rbx,%r14,4)
.L1272:
.LBE342:
.LBE340:
	.loc 2 1858 19
	nop
.L1268:
.LBE339:
.LBE338:
	.loc 2 1864 8
	jmp	.L1277
.L1265:
.LBB343:
	.loc 2 1860 16
	movq	32(%rbx), %rax
	movq	24(%rbx), %rdx
	movl	40(%rbx), %ecx
	movq	16(%rbx), %rdi
	movq	8(%rbx), %r8
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%r8, %r9
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__read_primary_into
.LBE343:
	.loc 2 1864 8
	jmp	.L1277
.L1278:
.LBB344:
	.loc 2 1829 13
	nop
.L1236:
.L1277:
.LBE344:
	.loc 2 1864 8 discriminator 2
	nop
	.loc 2 1864 8 is_stmt 0
	leaq	-32(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE108:
	.size	silver_output_profile__read_relation_into___wrapped_statements.31, .-silver_output_profile__read_relation_into___wrapped_statements.31
	.section	.rodata
	.align 8
.LC175:
	.ascii	"failed precondition from silver_output_profile.adb:1716"
	.align 8
.LC176:
	.ascii	"failed precondition from silver_output_profile.adb:1717"
	.align 8
.LC177:
	.ascii	"failed precondition from silver_output_profile.adb:1718"
	.align 8
.LC178:
	.ascii	"failed precondition from silver_output_profile.adb:1719"
	.align 8
.LC179:
	.ascii	"failed postcondition from silver_output_profile.adb:1720"
	.align 8
.LC180:
	.ascii	"failed postcondition from silver_output_profile.adb:1721"
	.text
	.align 2
	.type	silver_output_profile__read_chain_into, @function
silver_output_profile__read_chain_into:
.LFB109:
	.loc 2 1865 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$168, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -112(%rbp)
	movq	%rdi, -104(%rbp)
	movq	%rdx, -120(%rbp)
	movq	%rcx, -128(%rbp)
	.loc 2 1865 4
	leaq	16(%rbp), %rdx
	.loc 2 1865 4 is_stmt 0 discriminator 1
	leaq	-112(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -96(%rbp)
	movq	-120(%rbp), %rax
	movq	%rax, -88(%rbp)
	movq	-128(%rbp), %rax
	movq	%rax, -80(%rbp)
	movq	-104(%rbp), %rax
	movl	(%rax), %r8d
	movq	-104(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -72(%rbp)
	movl	-72(%rbp), %eax
	cmpl	%r8d, %eax
	jl	.L1280
	.loc 2 1865 4 discriminator 2
	movl	-72(%rbp), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r8d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L1281
.L1280:
	.loc 2 1865 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L1281:
.LBB345:
	.loc 2 1865 4 discriminator 4
	movl	-72(%rbp), %eax
	cmpl	%r8d, %eax
	.loc 2 1865 4 discriminator 7
	movl	-72(%rbp), %eax
	cmpl	%r8d, %eax
	.loc 2 1865 4 discriminator 10
	movl	-72(%rbp), %eax
	cmpl	%r8d, %eax
	.loc 2 1716 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L1288
.LBB346:
	.loc 2 1716 15 is_stmt 0 discriminator 1
	leaq	.LC175(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1288:
.LBE346:
	.loc 2 1716 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 1716 15 discriminator 2
	testl	%eax, %eax
	jle	.L1289
	.loc 2 1716 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L1290
.L1289:
.LBB347:
	.loc 2 1716 15 discriminator 4
	leaq	.LC175(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1290:
.LBE347:
	.loc 2 1717 32
	movq	-80(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 1716 15 discriminator 5
	testl	%eax, %eax
	jle	.L1291
	.loc 2 1717 32 discriminator 1
	movq	-80(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 1717 50 discriminator 1
	movl	-72(%rbp), %edx
	cmpl	$2147483647, %edx
	jne	.L1292
	.loc 2 1717 50 is_stmt 0 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$1717, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1292:
	.loc 2 1717 50 discriminator 4
	movl	-72(%rbp), %edx
	addl	$1, %edx
	.loc 2 1717 32 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L1293
.L1291:
.LBB348:
	.loc 2 1716 15 discriminator 6
	leaq	.LC176(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1293:
.LBE348:
	.loc 2 1717 63 discriminator 6
	movq	-88(%rbp), %rdx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_context
	.loc 2 1717 63 is_stmt 0 discriminator 7
	xorl	$1, %eax
	.loc 2 1716 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L1294
.LBB349:
	.loc 2 1716 15 is_stmt 0 discriminator 8
	leaq	.LC176(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1294:
.LBE349:
	.loc 2 1718 19 is_stmt 1
	movq	-88(%rbp), %rax
	movq	-80(%rbp), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__valid_condition
	.loc 2 1718 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 1716 15 is_stmt 1 discriminator 9
	testb	%al, %al
	je	.L1295
.LBB350:
	.loc 2 1716 15 is_stmt 0 discriminator 10
	leaq	.LC177(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1295:
.LBE350:
	.loc 2 1719 19 is_stmt 1
	movq	-80(%rbp), %rax
	movl	4(%rax), %edx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__chain_token
	.loc 2 1719 69 discriminator 1
	cmpb	$29, %al
	je	.L1296
	.loc 2 1719 69 is_stmt 0 discriminator 2
	cmpb	$30, %al
	jne	.L1297
.L1296:
	.loc 2 1719 69 discriminator 3
	movl	$1, %eax
	jmp	.L1298
.L1297:
	.loc 2 1719 69 discriminator 4
	movl	$0, %eax
.L1298:
	.loc 2 1719 69 discriminator 5
	xorl	$1, %eax
	.loc 2 1716 15 is_stmt 1 discriminator 11
	testb	%al, %al
	je	.L1299
.LBB351:
	.loc 2 1716 15 is_stmt 0 discriminator 12
	leaq	.LC178(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1299:
.LBE351:
	.loc 2 1723 55 is_stmt 1
	movl	-72(%rbp), %eax
	cmpl	$2147483647, %eax
	jne	.L1300
	.loc 2 1723 55 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1723, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1300:
	.loc 2 1723 55 discriminator 3
	movl	-72(%rbp), %eax
	addl	$1, %eax
	.loc 2 1723 60 is_stmt 1 discriminator 4
	movq	-80(%rbp), %rdx
	movl	4(%rdx), %edx
	movl	$0, %ecx
	subl	%edx, %eax
	jno	.L1301
	movl	$1, %ecx
.L1301:
	movl	%eax, %edx
	.loc 2 1723 60 is_stmt 0 discriminator 5
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L1303
	.loc 2 1723 60 discriminator 6
	leaq	.LC12(%rip), %rax
	movl	$1723, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1303:
	.loc 2 1723 60 discriminator 8
	movl	%edx, %eax
	movl	%eax, -68(%rbp)
	.loc 2 1721 73 is_stmt 1
	movq	-80(%rbp), %rax
	movl	4(%rax), %ebx
	.loc 2 1865 4 discriminator 13
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__read_chain_into___wrapped_statements.32
	.loc 2 1720 28
	movq	-88(%rbp), %rax
	movq	-80(%rbp), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__valid_condition
	.loc 2 1720 28 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L1304
.LBB352:
	.loc 2 1720 28 discriminator 2
	leaq	.LC179(%rip), %r14
	leaq	.LC6(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1304:
.LBE352:
	.loc 2 1721 33 is_stmt 1 discriminator 1
	movq	-80(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 1720 28 discriminator 3
	testl	%eax, %eax
	je	.L1308
	.loc 2 1721 58 discriminator 2
	movq	-80(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 1721 37 discriminator 2
	cmpl	%eax, %ebx
	jg	.L1306
	.loc 2 1721 58 discriminator 3
	movq	-80(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 1721 91 discriminator 3
	movl	-72(%rbp), %edx
	cmpl	$2147483647, %edx
	jne	.L1307
	.loc 2 1721 91 is_stmt 0 discriminator 4
	leaq	.LC12(%rip), %rax
	movl	$1721, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1307:
	.loc 2 1721 91 discriminator 6
	movl	-72(%rbp), %edx
	addl	$1, %edx
	.loc 2 1721 58 is_stmt 1 discriminator 7
	cmpl	%eax, %edx
	jge	.L1308
.L1306:
.LBB353:
	.loc 2 1720 28 discriminator 4
	leaq	.LC180(%rip), %r12
	leaq	.LC6(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1308:
.LBE353:
	.loc 2 1865 4 discriminator 15
	nop
.LBE345:
	.loc 2 1865 4 is_stmt 0
	addq	$168, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE109:
	.size	silver_output_profile__read_chain_into, .-silver_output_profile__read_chain_into
	.section	.rodata
	.align 8
.LC181:
	.ascii	"Loop_Invariant failed at silver_output_profile.adb:1875"
	.align 8
.LC182:
	.ascii	"Loop_Invariant failed at silver_output_profile.adb:1876"
	.align 8
.LC183:
	.ascii	"Loop_Invariant failed at silver_output_profile.adb:1877"
	.align 8
.LC184:
	.ascii	"Loop_Invariant failed at silver_output_profile.adb:1878"
	.align 8
.LC185:
	.ascii	"Loop_Variant failed at silver_output_profile.adb:1882"
	.align 8
.LC8:
	.long	1
	.long	53
	.text
	.align 2
	.type	silver_output_profile__read_chain_into___wrapped_statements.32, @function
silver_output_profile__read_chain_into___wrapped_statements.32:
.LFB111:
	.loc 2 1865 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$184, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -120(%rbp)
	.loc 2 1865 4
	movl	24(%rbx), %eax
	movl	%eax, -128(%rbp)
.LBB354:
	movq	%rsp, %rax
	movq	%rax, -216(%rbp)
	.loc 2 1867 7
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, -56(%rbp)
	.loc 2 1868 7
	movl	-56(%rbp), %eax
	cltq
	movq	%rax, -64(%rbp)
	movl	-56(%rbp), %eax
	cltq
	addq	$2, %rax
	salq	$3, %rax
	movq	%rax, -144(%rbp)
	movl	-56(%rbp), %eax
	cltq
	movq	%rax, -72(%rbp)
	movl	-56(%rbp), %eax
	cltq
	addq	$2, %rax
	salq	$3, %rax
	movq	%rax, -200(%rbp)
	movl	-56(%rbp), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	movq	%rax, -80(%rbp)
	movl	-56(%rbp), %eax
	cltq
	salq	$4, %rax
	leaq	40(%rax), %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %esi
	movl	$0, %edx
	divq	%rsi
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	addq	$3, %rax
	shrq	$2, %rax
	salq	$2, %rax
	movq	%rax, -88(%rbp)
	.loc 2 1868 7 is_stmt 0 discriminator 1
	movl	-56(%rbp), %edx
	movq	-88(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_output_profile__condition_resultIP
	.loc 2 1869 7 is_stmt 1
	movb	$29, -49(%rbp)
	.loc 2 1870 7
	movb	$0, -50(%rbp)
.LBB355:
	.loc 2 1878 55
	movq	%rsp, %rax
	movq	%rax, -136(%rbp)
	.loc 2 1878 49 discriminator 1
	movq	16(%rbx), %rax
	movl	(%rax), %edx
	.loc 2 1878 55 discriminator 1
	movslq	%edx, %rax
	salq	$4, %rax
	leaq	40(%rax), %rsi
	movslq	%edx, %rax
	salq	$4, %rax
	leaq	40(%rax), %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %edi
	movl	$0, %edx
	divq	%rdi
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	addq	$3, %rax
	shrq	$2, %rax
	salq	$2, %rax
	movq	%rax, -96(%rbp)
	.loc 2 1878 55 is_stmt 0 discriminator 2
	movq	16(%rbx), %rdx
	movq	-96(%rbp), %rax
	movq	%rax, %rdi
	movq	%rdx, %rcx
	movq	%rsi, %rax
	movq	%rax, %rdx
	movq	%rcx, %rsi
	call	memcpy@PLT
	.loc 2 1874 7 is_stmt 1
	movb	$0, -121(%rbp)
.L1334:
.LBB356:
	.loc 2 1875 46
	movq	16(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 1875 33
	testl	%eax, %eax
	jle	.L1310
	.loc 2 1875 46 discriminator 1
	movq	16(%rbx), %rax
	movl	4(%rax), %edx
	.loc 2 1875 64 discriminator 1
	cmpl	$2147483647, -128(%rbp)
	jne	.L1311
	.loc 2 1875 64 is_stmt 0 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$1875, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1311:
	.loc 2 1875 64 discriminator 4
	movl	-128(%rbp), %eax
	addl	$1, %eax
	.loc 2 1875 46 is_stmt 1 discriminator 5
	cmpl	%edx, %eax
	jge	.L1312
.L1310:
.LBB357:
	.loc 2 1875 33 discriminator 6
	leaq	.LC181(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rcx
	movq	-184(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1312:
.LBE357:
	.loc 2 1876 33
	movq	8(%rbx), %rdx
	movq	16(%rbx), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	silver_output_profile__valid_condition
	.loc 2 1876 33 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L1313
.LBB358:
	.loc 2 1876 33 discriminator 2
	leaq	.LC182(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rcx
	movq	-168(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1313:
.LBE358:
	.loc 2 1877 33 is_stmt 1
	cmpb	$29, -49(%rbp)
	je	.L1314
	.loc 2 1877 59 discriminator 1
	cmpb	$30, -49(%rbp)
	je	.L1314
.LBB359:
	.loc 2 1877 33 discriminator 2
	leaq	.LC183(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rcx
	movq	-152(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1314:
.LBE359:
	.loc 2 1878 46 discriminator 3
	movq	16(%rbx), %rax
	movl	4(%rax), %edx
	movq	-96(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 1878 33 discriminator 3
	cmpl	%eax, %edx
	jge	.L1315
.LBB360:
	.loc 2 1878 33 is_stmt 0 discriminator 4
	leaq	.LC184(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1315:
.LBE360:
	.loc 2 1882 10 is_stmt 1
	cmpb	$0, -121(%rbp)
	je	.L1316
	.loc 2 1882 50 discriminator 1
	movl	-204(%rbp), %eax
	movl	%eax, -208(%rbp)
.L1316:
	.loc 2 1882 50 is_stmt 0 discriminator 2
	movq	16(%rbx), %rax
	movl	4(%rax), %eax
	movl	%eax, -204(%rbp)
	.loc 2 1882 10 is_stmt 1 discriminator 2
	cmpb	$0, -121(%rbp)
	je	.L1317
	.loc 2 1882 50 discriminator 3
	movl	-208(%rbp), %edi
	cmpl	%edi, %eax
	jg	.L1318
.LBB361:
	.loc 2 1882 50 is_stmt 0 discriminator 4
	leaq	.LC185(%rip), %r12
	leaq	.LC8(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1317:
.LBE361:
	.loc 2 1882 10 is_stmt 1 discriminator 5
	movb	$1, -121(%rbp)
.L1318:
	.loc 2 1883 22
	movq	16(%rbx), %rax
	movl	4(%rax), %edx
	movq	(%rbx), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__chain_token
	.loc 2 1883 22 is_stmt 0 discriminator 1
	movb	%al, -97(%rbp)
	.loc 2 1884 10 is_stmt 1
	cmpb	$29, -97(%rbp)
	je	.L1319
	.loc 2 1884 50 discriminator 1
	cmpb	$30, -97(%rbp)
	jne	.L1320
.L1319:
	.loc 2 1885 10
	cmpb	$0, -50(%rbp)
	je	.L1321
	.loc 2 1885 21 discriminator 1
	movzbl	-49(%rbp), %eax
	cmpb	-97(%rbp), %al
	je	.L1321
	.loc 2 1886 26
	movq	16(%rbx), %rax
	movl	$0, 4(%rax)
	.loc 2 1887 35
	movq	16(%rbx), %rax
	movl	$0, 12(%rax)
	movq	16(%rbx), %rax
	movl	$0, 16(%rax)
	movq	16(%rbx), %rax
	movb	$0, 20(%rax)
	movq	16(%rbx), %rax
	movb	$0, 21(%rax)
	movq	16(%rbx), %rax
	movb	$1, 22(%rax)
	.loc 2 1888 19
	movq	16(%rbx), %rax
	movl	(%rax), %edx
	.loc 2 1888 40
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$2, %rax
	leaq	0(,%rax,8), %rsi
	movq	16(%rbx), %rax
	movl	8(%rax), %eax
	cmpl	%eax, %edx
	je	.L1322
	.loc 2 1888 40 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1888, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1322:
	.loc 2 1888 31 is_stmt 1 discriminator 2
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	shrq	$2, %rax
	movq	%rax, %rdx
	movq	16(%rbx), %rax
	leaq	8(%rax), %rcx
	movq	16(%rbx), %rax
	salq	$2, %rdx
	addq	%rdx, %rax
	movq	%rsi, %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 1889 13
	jmp	.L1323
.L1321:
	.loc 2 1891 19
	movq	16(%rbx), %rax
	movl	4(%rax), %edi
	movq	(%rbx), %rax
	movzbl	-97(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%edx, %ecx
	movl	%edi, %edx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__chain_after
	.loc 2 1891 19 is_stmt 0 discriminator 1
	movl	%eax, -104(%rbp)
	.loc 2 1892 10 is_stmt 1
	cmpl	$0, -104(%rbp)
	jne	.L1324
	.loc 2 1893 26
	movq	16(%rbx), %rax
	movl	$0, 4(%rax)
	.loc 2 1894 35
	movq	16(%rbx), %rax
	movl	$0, 12(%rax)
	movq	16(%rbx), %rax
	movl	$0, 16(%rax)
	movq	16(%rbx), %rax
	movb	$0, 20(%rax)
	movq	16(%rbx), %rax
	movb	$0, 21(%rax)
	movq	16(%rbx), %rax
	movb	$1, 22(%rax)
	.loc 2 1895 19
	movq	16(%rbx), %rax
	movl	(%rax), %edx
	.loc 2 1895 40
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$2, %rax
	leaq	0(,%rax,8), %rsi
	movq	16(%rbx), %rax
	movl	8(%rax), %eax
	cmpl	%eax, %edx
	je	.L1325
	.loc 2 1895 40 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1895, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1325:
	.loc 2 1895 31 is_stmt 1 discriminator 2
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	shrq	$2, %rax
	movq	%rax, %rdx
	movq	16(%rbx), %rax
	leaq	8(%rax), %rcx
	movq	16(%rbx), %rax
	salq	$2, %rdx
	addq	%rdx, %rax
	movq	%rsi, %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 1896 13
	jmp	.L1323
.L1324:
	.loc 2 1898 10
	cmpb	$29, -97(%rbp)
	jne	.L1326
	.loc 2 1899 13
	movq	16(%rbx), %rax
	leaq	8(%rax), %r8
	movq	(%rbx), %rax
	movq	8(%rbx), %rdi
	movq	-88(%rbp), %rcx
	movl	-104(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rcx, %r9
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__read_relation_into
	jmp	.L1327
.L1326:
	.loc 2 1901 13
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	shrq	$2, %rax
	movq	16(%rbx), %rdx
	salq	$2, %rax
	leaq	(%rdx,%rax), %r8
	movq	(%rbx), %rax
	movq	8(%rbx), %rdi
	movq	-88(%rbp), %rcx
	movl	-104(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rcx, %r9
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__read_relation_into
.L1327:
	.loc 2 1903 25
	movq	-88(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 1903 10
	testl	%eax, %eax
	jne	.L1328
	.loc 2 1904 26
	movq	16(%rbx), %rax
	movl	$0, 4(%rax)
	.loc 2 1905 35
	movq	16(%rbx), %rax
	movl	$0, 12(%rax)
	movq	16(%rbx), %rax
	movl	$0, 16(%rax)
	movq	16(%rbx), %rax
	movb	$0, 20(%rax)
	movq	16(%rbx), %rax
	movb	$0, 21(%rax)
	movq	16(%rbx), %rax
	movb	$1, 22(%rax)
	.loc 2 1906 19
	movq	16(%rbx), %rax
	movl	(%rax), %edx
	.loc 2 1906 40
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$2, %rax
	leaq	0(,%rax,8), %rsi
	movq	16(%rbx), %rax
	movl	8(%rax), %eax
	cmpl	%eax, %edx
	je	.L1329
	.loc 2 1906 40 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1906, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1329:
	.loc 2 1906 31 is_stmt 1 discriminator 2
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	shrq	$2, %rax
	movq	%rax, %rdx
	movq	16(%rbx), %rax
	leaq	8(%rax), %rcx
	movq	16(%rbx), %rax
	salq	$2, %rdx
	addq	%rdx, %rax
	movq	%rsi, %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 1907 13
	jmp	.L1323
.L1328:
	.loc 2 1909 10
	cmpb	$29, -97(%rbp)
	jne	.L1330
	.loc 2 1910 19
	movq	16(%rbx), %rax
	movl	(%rax), %edx
	.loc 2 1910 38
	movq	-88(%rbp), %rax
	movl	8(%rax), %eax
	cmpl	%eax, %edx
	je	.L1331
	.loc 2 1910 38 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1910, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1331:
	.loc 2 1910 30 is_stmt 1 discriminator 2
	movq	-88(%rbp), %rax
	leaq	8(%rax), %rdx
	movq	16(%rbx), %rax
	addq	$8, %rax
	movq	%rax, %rdi
	movq	%rdx, %rcx
	movq	-144(%rbp), %rax
	movq	%rax, %rdx
	movq	%rcx, %rsi
	call	memcpy@PLT
	.loc 2 1911 13
	movq	-80(%rbp), %rax
	shrq	$2, %rax
	leaq	0(,%rax,4), %rdx
	movq	-88(%rbp), %rax
	leaq	(%rdx,%rax), %rcx
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	shrq	$2, %rax
	movq	16(%rbx), %rdx
	salq	$2, %rax
	addq	%rdx, %rax
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__join_into
	jmp	.L1332
.L1330:
	.loc 2 1913 13
	movq	-88(%rbp), %rax
	leaq	8(%rax), %rdx
	movq	16(%rbx), %rax
	addq	$8, %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__join_into
	.loc 2 1914 19
	movq	16(%rbx), %rax
	movl	(%rax), %ecx
	.loc 2 1914 39
	movq	-80(%rbp), %rax
	shrq	$2, %rax
	movq	%rax, %rdx
	movq	-88(%rbp), %rax
	movl	(%rax,%rdx,4), %eax
	cmpl	%eax, %ecx
	je	.L1333
	.loc 2 1914 39 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1914, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1333:
	.loc 2 1914 31 is_stmt 1 discriminator 2
	movq	-80(%rbp), %rax
	shrq	$2, %rax
	movq	%rax, %rdx
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	shrq	$2, %rax
	movq	%rax, %rcx
	salq	$2, %rdx
	movq	-88(%rbp), %rax
	leaq	(%rdx,%rax), %rsi
	movq	16(%rbx), %rdx
	leaq	0(,%rcx,4), %rax
	addq	%rdx, %rax
	movq	%rax, %rdi
	movq	%rsi, %rcx
	movq	-200(%rbp), %rax
	movq	%rax, %rdx
	movq	%rcx, %rsi
	call	memcpy@PLT
.L1332:
	.loc 2 1916 23
	movq	-88(%rbp), %rax
	movl	4(%rax), %edx
	movq	16(%rbx), %rax
	movl	%edx, 4(%rax)
	.loc 2 1917 19
	movzbl	-97(%rbp), %eax
	movb	%al, -49(%rbp)
	.loc 2 1918 18
	movb	$1, -50(%rbp)
.LBE356:
	.loc 2 1919 15
	jmp	.L1334
.L1320:
	.loc 2 1878 0 discriminator 5
	movq	-136(%rbp), %rsp
.LBE355:
	.loc 2 1920 8
	jmp	.L1335
.L1323:
.LBB362:
	.loc 2 1878 0 discriminator 6
	movq	-136(%rbp), %rsp
.L1335:
.LBE362:
	.loc 2 1920 8 discriminator 1
	movq	-216(%rbp), %rsp
.LBE354:
	.loc 2 1920 8 is_stmt 0
	leaq	-40(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE111:
	.size	silver_output_profile__read_chain_into___wrapped_statements.32, .-silver_output_profile__read_chain_into___wrapped_statements.32
	.section	.rodata
	.align 8
.LC186:
	.ascii	"failed precondition from silver_output_profile.adb:1684"
	.align 8
.LC187:
	.ascii	"failed precondition from silver_output_profile.adb:1685"
	.align 8
.LC188:
	.ascii	"failed precondition from silver_output_profile.adb:1686"
	.align 8
.LC189:
	.ascii	"failed postcondition from silver_output_profile.adb:1687"
	.align 8
.LC190:
	.ascii	"failed postcondition from silver_output_profile.adb:1688"
	.text
	.align 2
	.type	silver_output_profile__read_condition_into, @function
silver_output_profile__read_condition_into:
.LFB112:
	.loc 2 1921 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$208, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r10
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r10, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movq	%rdx, -104(%rbp)
	movl	%ecx, -108(%rbp)
	movq	%r8, -120(%rbp)
	movq	%r9, -128(%rbp)
	.loc 2 1921 4
	leaq	16(%rbp), %rdx
	.loc 2 1921 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -40(%rbp)
	movq	%rax, -56(%rbp)
	movq	-104(%rbp), %rax
	movq	%rax, -64(%rbp)
	movl	-108(%rbp), %eax
	movl	%eax, -48(%rbp)
	movq	-120(%rbp), %rax
	movq	%rax, -72(%rbp)
	movq	-128(%rbp), %rax
	movq	%rax, -80(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %r8d
	movq	-88(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%r8d, %r12d
	jl	.L1338
	.loc 2 1921 4 discriminator 2
	movslq	%r12d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r8d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L1339
.L1338:
	.loc 2 1921 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L1339:
.LBB363:
	.loc 2 1921 4 discriminator 4
	cmpl	%r8d, %r12d
	.loc 2 1921 4 discriminator 7
	cmpl	%r8d, %r12d
	.loc 2 1921 4 discriminator 10
	cmpl	%r8d, %r12d
	.loc 2 1684 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L1346
.LBB364:
	.loc 2 1684 15 is_stmt 0 discriminator 1
	leaq	.LC186(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1346:
.LBE364:
	.loc 2 1684 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 1684 15 discriminator 2
	testl	%eax, %eax
	jle	.L1347
	.loc 2 1684 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L1348
.L1347:
.LBB365:
	.loc 2 1684 15 discriminator 4
	leaq	.LC186(%rip), %rax
	movq	%rax, -240(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -232(%rbp)
	movq	-240(%rbp), %rbx
	movq	-232(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1348:
.LBE365:
	.loc 2 1685 41
	cmpl	$2147483647, %r12d
	jne	.L1349
	.loc 2 1685 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1685, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1349:
	.loc 2 1685 41 discriminator 3
	leal	1(%r12), %edx
	.loc 2 1684 15 is_stmt 1 discriminator 5
	movl	-48(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L1350
.LBB366:
	.loc 2 1684 15 is_stmt 0 discriminator 6
	leaq	.LC187(%rip), %rax
	movq	%rax, -224(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -216(%rbp)
	movq	-224(%rbp), %rbx
	movq	-216(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1350:
.LBE366:
	.loc 2 1685 54 is_stmt 1 discriminator 4
	movq	-64(%rbp), %rdx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_context
	.loc 2 1685 54 is_stmt 0 discriminator 5
	xorl	$1, %eax
	.loc 2 1684 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L1351
.LBB367:
	.loc 2 1684 15 is_stmt 0 discriminator 8
	leaq	.LC187(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rbx
	movq	-200(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1351:
.LBE367:
	.loc 2 1686 19 is_stmt 1
	movq	-64(%rbp), %rax
	movq	-72(%rbp), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__valid_flow
	.loc 2 1686 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 1684 15 is_stmt 1 discriminator 9
	testb	%al, %al
	je	.L1352
.LBB368:
	.loc 2 1684 15 is_stmt 0 discriminator 10
	leaq	.LC188(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1352:
.LBE368:
	.loc 2 1686 69 is_stmt 1 discriminator 2
	movq	-80(%rbp), %rax
	movl	(%rax), %edx
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 1684 15 discriminator 11
	cmpl	%eax, %edx
	je	.L1353
.LBB369:
	.loc 2 1684 15 is_stmt 0 discriminator 12
	leaq	.LC188(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1353:
.LBE369:
	.loc 2 1690 55 is_stmt 1
	cmpl	$2147483647, %r12d
	jne	.L1354
	.loc 2 1690 55 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1690, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1354:
	.loc 2 1690 55 discriminator 3
	leal	1(%r12), %eax
	.loc 2 1690 60 is_stmt 1 discriminator 4
	movl	-48(%rbp), %edx
	movl	$0, %ecx
	subl	%edx, %eax
	jno	.L1355
	movl	$1, %ecx
.L1355:
	movl	%eax, %edx
	.loc 2 1690 60 is_stmt 0 discriminator 5
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L1357
	.loc 2 1690 60 discriminator 6
	leaq	.LC12(%rip), %rax
	movl	$1690, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1357:
	.loc 2 1690 60 discriminator 8
	movl	%edx, %eax
	movl	%eax, -44(%rbp)
	.loc 2 1921 4 is_stmt 1 discriminator 13
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__read_condition_into___wrapped_statements.33
	.loc 2 1687 28
	movq	-64(%rbp), %rax
	movq	-80(%rbp), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__valid_condition
	.loc 2 1687 28 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L1358
.LBB370:
	.loc 2 1687 28 discriminator 2
	leaq	.LC189(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rcx
	movq	-152(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1358:
.LBE370:
	.loc 2 1688 33 is_stmt 1
	movq	-80(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 1687 28 discriminator 3
	testl	%eax, %eax
	je	.L1362
	.loc 2 1688 58 discriminator 1
	movq	-80(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 1688 37 discriminator 1
	movl	-48(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L1360
	.loc 2 1688 58 discriminator 2
	movq	-80(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 1688 87 discriminator 2
	cmpl	$2147483647, %r12d
	jne	.L1361
	.loc 2 1688 87 is_stmt 0 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$1688, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1361:
	.loc 2 1688 87 discriminator 5
	leal	1(%r12), %edx
	.loc 2 1688 58 is_stmt 1 discriminator 6
	cmpl	%eax, %edx
	jge	.L1362
.L1360:
.LBB371:
	.loc 2 1687 28 discriminator 4
	leaq	.LC190(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rcx
	movq	-136(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1362:
.LBE371:
	.loc 2 1921 4 discriminator 15
	nop
.LBE363:
	.loc 2 1921 4 is_stmt 0
	addq	$208, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE112:
	.size	silver_output_profile__read_condition_into, .-silver_output_profile__read_condition_into
	.align 2
	.type	silver_output_profile__read_condition_into___wrapped_statements.33, @function
silver_output_profile__read_condition_into___wrapped_statements.33:
.LFB114:
	.loc 2 1921 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%r10, %rbx
	movq	%r10, -24(%rbp)
	.loc 2 1925 7
	movq	24(%rbx), %rax
	movq	16(%rbx), %rdx
	movl	32(%rbx), %ecx
	movq	8(%rbx), %rdi
	movq	(%rbx), %r8
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%r8, %r9
	movq	%rdi, %r8
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__read_relation_into
	.loc 2 1926 23
	movq	(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 1926 7
	testl	%eax, %eax
	je	.L1364
	.loc 2 1926 37 discriminator 1
	movq	(%rbx), %rax
	movl	4(%rax), %edx
	movq	24(%rbx), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__chain_token
	.loc 2 1926 87 discriminator 2
	cmpb	$29, %al
	je	.L1365
	.loc 2 1926 87 is_stmt 0 discriminator 3
	cmpb	$30, %al
	jne	.L1366
.L1365:
	.loc 2 1926 87 discriminator 4
	movl	$1, %eax
	jmp	.L1367
.L1366:
	.loc 2 1926 87 discriminator 5
	movl	$0, %eax
.L1367:
	.loc 2 1926 28 is_stmt 1 discriminator 6
	testb	%al, %al
	je	.L1364
	.loc 2 1927 10
	movq	24(%rbx), %rax
	movq	16(%rbx), %rdx
	movq	(%rbx), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__read_chain_into
.L1364:
	.loc 2 1929 23
	movq	(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 1929 7
	testl	%eax, %eax
	jne	.L1369
	.loc 2 1929 32 discriminator 1
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__invalidate_condition
.L1369:
	.loc 2 1930 8 discriminator 1
	nop
	.loc 2 1930 8 is_stmt 0
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE114:
	.size	silver_output_profile__read_condition_into___wrapped_statements.33, .-silver_output_profile__read_condition_into___wrapped_statements.33
	.align 2
	.type	silver_output_profile__scalar_target___wrapped_statements.36, @function
silver_output_profile__scalar_target___wrapped_statements.36:
.LFB116:
	.loc 2 1939 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 3, -24
	movq	%r10, %rbx
	movq	%r10, -40(%rbp)
	.loc 2 1942 52
	movq	8(%rbx), %rax
	movl	16(%rbx), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__skip_at
	.loc 2 1942 52 is_stmt 0 discriminator 1
	movl	%eax, -20(%rbp)
	.loc 2 1943 44 is_stmt 1
	movq	8(%rbx), %rax
	movl	-20(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__name_after
	.loc 2 1943 44 is_stmt 0 discriminator 1
	movl	%eax, -24(%rbp)
	.loc 2 1944 31 is_stmt 1
	movq	(%rbx), %rax
	leaq	6824(%rax), %rdi
	movq	8(%rbx), %rax
	movl	-24(%rbp), %ecx
	movl	-20(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%ecx, %r8d
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__lookup@PLT
	.loc 2 1939 4
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE116:
	.size	silver_output_profile__scalar_target___wrapped_statements.36, .-silver_output_profile__scalar_target___wrapped_statements.36
	.section	.rodata
	.align 8
.LC191:
	.ascii	"failed precondition from silver_output_profile.adb:1936"
	.align 8
.LC192:
	.ascii	"failed precondition from silver_output_profile.adb:1937"
	.align 8
.LC193:
	.ascii	"failed postcondition from silver_output_profile.adb:1938"
	.text
	.align 2
	.type	silver_output_profile__scalar_target, @function
silver_output_profile__scalar_target:
.LFB115:
	.loc 2 1939 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movq	%rdx, -104(%rbp)
	movl	%ecx, -108(%rbp)
	.loc 2 1939 4
	leaq	16(%rbp), %rdx
	.loc 2 1939 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -56(%rbp)
	movq	%rax, -72(%rbp)
	movq	-104(%rbp), %rax
	movq	%rax, -80(%rbp)
	movl	-108(%rbp), %eax
	movl	%eax, -64(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %r8d
	movq	-88(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -112(%rbp)
	movq	-88(%rbp), %rax
	movl	4(%rax), %edx
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L1373
	.loc 2 1939 4 discriminator 2
	movq	-88(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L1374
.L1373:
	.loc 2 1939 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L1374:
.LBB372:
	.loc 2 1936 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L1375
.LBB373:
	.loc 2 1936 15 is_stmt 0 discriminator 1
	leaq	.LC191(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1375:
.LBE373:
	.loc 2 1936 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 1936 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L1376
	.loc 2 1936 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L1377
.L1376:
.LBB374:
	.loc 2 1936 15 discriminator 4
	leaq	.LC191(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1377:
.LBE374:
	.loc 2 1937 19
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_context
	.loc 2 1937 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 1936 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L1378
.LBB375:
	.loc 2 1936 15 is_stmt 0 discriminator 6
	leaq	.LC192(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1378:
.LBE375:
	.loc 2 1937 80 is_stmt 1 discriminator 2
	cmpl	$2147483647, -112(%rbp)
	jne	.L1379
	.loc 2 1937 80 is_stmt 0 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$1937, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1379:
	.loc 2 1937 80 discriminator 5
	movl	-112(%rbp), %edx
	addl	$1, %edx
	.loc 2 1936 15 is_stmt 1 discriminator 7
	movl	-64(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L1380
.LBB376:
	.loc 2 1936 15 is_stmt 0 discriminator 8
	leaq	.LC192(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1380:
.LBE376:
.LBB377:
	.loc 2 1939 4 is_stmt 1 discriminator 5
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__scalar_target___wrapped_statements.36
	.loc 2 1938 37
	movq	-80(%rbp), %rdx
	movl	6824(%rdx), %edx
	.loc 2 1938 16
	cmpl	%edx, %eax
	jle	.L1382
.LBB378:
	.loc 2 1938 16 is_stmt 0 discriminator 1
	leaq	.LC193(%rip), %r12
	leaq	.LC6(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1382:
.LBE378:
.LBE377:
.LBE372:
	.loc 2 1939 4 is_stmt 1
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE115:
	.size	silver_output_profile__scalar_target, .-silver_output_profile__scalar_target
	.align 2
	.globl	silver_output_profile__string_target_resultIP
	.type	silver_output_profile__string_target_resultIP, @function
silver_output_profile__string_target_resultIP:
.LFB117:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE117:
	.size	silver_output_profile__string_target_resultIP, .-silver_output_profile__string_target_resultIP
	.align 2
	.type	silver_output_profile__body_string_target___wrapped_statements.37, @function
silver_output_profile__body_string_target___wrapped_statements.37:
.LFB119:
	.loc 2 1959 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 3, -24
	movq	%r10, %rbx
	movq	%r10, -56(%rbp)
	.loc 2 1962 52
	movq	8(%rbx), %rax
	movl	16(%rbx), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__skip_at
	.loc 2 1962 52 is_stmt 0 discriminator 1
	movl	%eax, -20(%rbp)
	.loc 2 1963 44 is_stmt 1
	movq	8(%rbx), %rax
	movl	-20(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__name_after
	.loc 2 1963 44 is_stmt 0 discriminator 1
	movl	%eax, -24(%rbp)
	.loc 2 1964 41 is_stmt 1
	movq	(%rbx), %rax
	movq	%rax, %rdi
	movq	8(%rbx), %rax
	movl	-24(%rbp), %ecx
	movl	-20(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%ecx, %r8d
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__lookup_name
	.loc 2 1964 41 is_stmt 0 discriminator 1
	movl	%eax, -28(%rbp)
	.loc 2 1966 10 is_stmt 1
	cmpl	$0, -28(%rbp)
	je	.L1385
	.loc 2 1967 37
	movq	(%rbx), %rax
	leaq	6824(%rax), %rdi
	movq	8(%rbx), %rax
	movl	-24(%rbp), %ecx
	movl	-20(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%ecx, %r8d
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__lookup@PLT
	.loc 2 1967 88 discriminator 1
	testl	%eax, %eax
	setne	%al
	xorl	$1, %eax
	.loc 2 1967 11 discriminator 1
	testb	%al, %al
	je	.L1385
	.loc 2 1968 36
	cmpl	$0, -28(%rbp)
	jle	.L1386
	.loc 2 1968 36 is_stmt 0 discriminator 1
	cmpl	$341, -28(%rbp)
	jle	.L1387
.L1386:
	.loc 2 1968 36 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$1968, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1387:
	.loc 2 1968 19 is_stmt 1 discriminator 3
	movl	-28(%rbp), %eax
	movslq	%eax, %rdx
	movq	(%rbx), %rcx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$2, %rax
	addq	%rcx, %rax
	addq	$1, %rax
	movzbl	(%rax), %eax
	xorl	$1, %eax
	xorl	$1, %eax
	.loc 2 1968 11 discriminator 3
	testb	%al, %al
	je	.L1385
	.loc 2 1966 10 discriminator 1
	movl	-24(%rbp), %eax
	movl	%eax, -36(%rbp)
	movl	-28(%rbp), %eax
	movl	%eax, -32(%rbp)
	jmp	.L1388
.L1385:
	.loc 2 1966 10 is_stmt 0 discriminator 2
	movl	$0, -36(%rbp)
	movl	$0, -32(%rbp)
.L1388:
	.loc 2 1966 10 discriminator 3
	leaq	-36(%rbp), %rax
	.loc 2 1962 7 is_stmt 1 discriminator 2
	movq	(%rax), %rax
	.loc 2 1959 4
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE119:
	.size	silver_output_profile__body_string_target___wrapped_statements.37, .-silver_output_profile__body_string_target___wrapped_statements.37
	.section	.rodata
	.align 8
.LC194:
	.ascii	"failed precondition from silver_output_profile.adb:1954"
	.align 8
.LC195:
	.ascii	"failed precondition from silver_output_profile.adb:1955"
	.align 8
.LC196:
	.ascii	"failed postcondition from silver_output_profile.adb:1956"
	.align 8
.LC197:
	.ascii	"failed postcondition from silver_output_profile.adb:1957"
	.text
	.align 2
	.type	silver_output_profile__body_string_target, @function
silver_output_profile__body_string_target:
.LFB118:
	.loc 2 1959 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$144, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movq	%rdx, -104(%rbp)
	movl	%ecx, -108(%rbp)
	.loc 2 1959 4
	leaq	16(%rbp), %rdx
	.loc 2 1959 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -40(%rbp)
	movq	%rax, -56(%rbp)
	movq	-104(%rbp), %rax
	movq	%rax, -64(%rbp)
	movl	-108(%rbp), %eax
	movl	%eax, -48(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %r8d
	movq	-88(%rbp), %rax
	movl	4(%rax), %r12d
	movq	-88(%rbp), %rax
	movl	4(%rax), %edx
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L1391
	.loc 2 1959 4 discriminator 2
	movq	-88(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L1392
.L1391:
	.loc 2 1959 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L1392:
.LBB379:
	.loc 2 1954 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L1393
.LBB380:
	.loc 2 1954 15 is_stmt 0 discriminator 1
	leaq	.LC194(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1393:
.LBE380:
	.loc 2 1954 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 1954 15 discriminator 2
	testl	%eax, %eax
	jle	.L1394
	.loc 2 1954 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L1395
.L1394:
.LBB381:
	.loc 2 1954 15 discriminator 4
	leaq	.LC194(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1395:
.LBE381:
	.loc 2 1955 19
	movq	-64(%rbp), %rdx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_context
	.loc 2 1955 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 1954 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L1396
.LBB382:
	.loc 2 1954 15 is_stmt 0 discriminator 6
	leaq	.LC195(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1396:
.LBE382:
	.loc 2 1955 80 is_stmt 1 discriminator 2
	cmpl	$2147483647, %r12d
	jne	.L1397
	.loc 2 1955 80 is_stmt 0 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$1955, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1397:
	.loc 2 1955 80 discriminator 5
	leal	1(%r12), %edx
	.loc 2 1954 15 is_stmt 1 discriminator 7
	movl	-48(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L1398
.LBB383:
	.loc 2 1954 15 is_stmt 0 discriminator 8
	leaq	.LC195(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1398:
.LBE383:
.LBB384:
	.loc 2 1959 4 is_stmt 1 discriminator 5
	leaq	-64(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__body_string_target___wrapped_statements.37
	movq	%rax, -72(%rbp)
	.loc 2 1956 49
	movl	-68(%rbp), %edx
	movq	-64(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 1956 16
	cmpl	%eax, %edx
	jle	.L1399
.LBB385:
	.loc 2 1956 16 is_stmt 0 discriminator 1
	leaq	.LC196(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1399:
.LBE385:
	.loc 2 1957 52 is_stmt 1
	movl	-72(%rbp), %eax
	.loc 2 1956 16 discriminator 2
	testl	%eax, %eax
	je	.L1400
	.loc 2 1958 52
	movl	-72(%rbp), %eax
	.loc 2 1958 12
	movl	-48(%rbp), %edx
	cmpl	%eax, %edx
	jge	.L1401
	.loc 2 1958 52 discriminator 1
	movl	-72(%rbp), %eax
	.loc 2 1958 81 discriminator 1
	cmpl	$2147483647, %r12d
	jne	.L1402
	.loc 2 1958 81 is_stmt 0 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$1958, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1402:
	.loc 2 1958 81 discriminator 4
	leal	1(%r12), %edx
	.loc 2 1958 52 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L1400
.L1401:
.LBB386:
	.loc 2 1956 16 discriminator 3
	leaq	.LC197(%rip), %r14
	leaq	.LC6(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1400:
.LBE386:
	.loc 2 1959 4 discriminator 6
	movq	-72(%rbp), %rax
.LBE384:
.LBE379:
	.loc 2 1959 4 is_stmt 0
	addq	$144, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE118:
	.size	silver_output_profile__body_string_target, .-silver_output_profile__body_string_target
	.align 2
	.type	silver_output_profile__scalar_assignment_body___wrapped_statements.34, @function
silver_output_profile__scalar_assignment_body___wrapped_statements.34:
.LFB121:
	.loc 2 2007 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$88, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%r10, %rbx
	movq	%r10, -104(%rbp)
	.loc 2 2009 44
	movq	16(%rbx), %rax
	movl	4(%rax), %edx
	movq	8(%rbx), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__skip_at
	.loc 2 2009 44 is_stmt 0 discriminator 1
	movl	%eax, -36(%rbp)
	.loc 2 2010 44 is_stmt 1
	movq	8(%rbx), %rax
	movl	-36(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__name_after
	.loc 2 2010 44 is_stmt 0 discriminator 1
	movl	%eax, -40(%rbp)
	.loc 2 2012 27 is_stmt 1
	movq	(%rbx), %rax
	leaq	6824(%rax), %rdi
	movq	8(%rbx), %rax
	movl	-40(%rbp), %ecx
	movl	-36(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%ecx, %r8d
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_scalar_expressions__lookup@PLT
	.loc 2 2012 27 is_stmt 0 discriminator 1
	movl	%eax, -44(%rbp)
	.loc 2 2014 9 is_stmt 1
	movq	16(%rbx), %rax
	leaq	20(%rax), %r12
	movq	8(%rbx), %rax
	movl	-40(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$19, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	movl	%eax, %esi
	.loc 2 2014 9 is_stmt 0 discriminator 1
	movq	8(%rbx), %rax
	movq	(%rbx), %rcx
	leaq	-96(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	pushq	$0
	pushq	$0
	movq	%r12, %r9
	movl	%esi, %r8d
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__read_scalar_in_flow
	addq	$16, %rsp
	.loc 2 2016 7 is_stmt 1
	cmpl	$0, -44(%rbp)
	je	.L1405
	.loc 2 2016 53 discriminator 1
	cmpl	$0, -44(%rbp)
	jle	.L1406
	.loc 2 2016 53 is_stmt 0 discriminator 2
	cmpl	$341, -44(%rbp)
	jle	.L1407
.L1406:
	.loc 2 2016 53 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2016, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1407:
	.loc 2 2016 29 is_stmt 1 discriminator 4
	movl	-44(%rbp), %eax
	movslq	%eax, %rdx
	movq	(%rbx), %rax
	salq	$5, %rdx
	addq	%rdx, %rax
	addq	$6824, %rax
	movzbl	(%rax), %eax
	.loc 2 2016 29 is_stmt 0 discriminator 5
	xorl	$1, %eax
	.loc 2 2016 21 is_stmt 1 discriminator 5
	testb	%al, %al
	jne	.L1405
	.loc 2 2017 29
	movl	-96(%rbp), %edx
	movq	16(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 2017 9
	cmpl	%eax, %edx
	jle	.L1405
	.loc 2 2017 61 discriminator 1
	movq	-92(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty@PLT
	.loc 2 2017 46 discriminator 2
	testb	%al, %al
	jne	.L1405
	.loc 2 2018 58
	cmpl	$0, -44(%rbp)
	jle	.L1408
	.loc 2 2018 58 is_stmt 0 discriminator 1
	cmpl	$341, -44(%rbp)
	jle	.L1409
.L1408:
	.loc 2 2018 58 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$2018, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1409:
	.loc 2 2018 36 is_stmt 1 discriminator 3
	movl	-92(%rbp), %edx
	movl	-44(%rbp), %eax
	movslq	%eax, %rcx
	movq	(%rbx), %rax
	salq	$5, %rcx
	addq	%rcx, %rax
	addq	$6816, %rax
	movl	(%rax), %eax
	.loc 2 2018 36 is_stmt 0 discriminator 4
	cmpl	%eax, %edx
	setl	%al
	.loc 2 2018 9 is_stmt 1 discriminator 4
	testb	%al, %al
	jne	.L1405
	.loc 2 2019 58
	cmpl	$0, -44(%rbp)
	jle	.L1410
	.loc 2 2019 58 is_stmt 0 discriminator 1
	cmpl	$341, -44(%rbp)
	jle	.L1411
.L1410:
	.loc 2 2019 58 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$2019, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1411:
	.loc 2 2019 36 is_stmt 1 discriminator 3
	movl	-88(%rbp), %edx
	movl	-44(%rbp), %eax
	movslq	%eax, %rcx
	movq	(%rbx), %rax
	salq	$5, %rcx
	addq	%rcx, %rax
	addq	$6820, %rax
	movl	(%rax), %eax
	.loc 2 2019 36 is_stmt 0 discriminator 4
	cmpl	%eax, %edx
	setg	%al
	.loc 2 2019 9 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L1412
.L1405:
	.loc 2 2020 19
	movq	16(%rbx), %rax
	movq	%rax, %rdi
	call	silver_output_profile__invalid_body
	movq	%rax, %r12
	.loc 2 2020 12 discriminator 1
	jmp	.L1417
.L1412:
.LBB387:
	.loc 2 2021 14
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, -48(%rbp)
	movl	-48(%rbp), %eax
	cltq
	movq	%rax, -56(%rbp)
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	leaq	36(%rax), %r13
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	addq	$36, %rax
	movl	$4, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_allocate@PLT
	.loc 2 2021 14 is_stmt 0 discriminator 1
	movq	%rax, %r12
	movq	%r12, -64(%rbp)
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, %esi
	movq	%r12, %rdi
	call	silver_output_profile__body_scanIP
.LBB388:
	.loc 2 2022 17 is_stmt 1
	movq	16(%rbx), %rax
	movq	%r12, %rcx
	movq	%r13, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 2023 26
	movl	-96(%rbp), %eax
	movl	%eax, 4(%r12)
	.loc 2 2024 26
	movb	$1, 16(%r12)
	.loc 2 2025 22
	movl	-48(%rbp), %eax
	cmpl	$0, -44(%rbp)
	jle	.L1414
	.loc 2 2025 22 is_stmt 0 discriminator 1
	cmpl	%eax, -44(%rbp)
	jle	.L1415
.L1414:
	.loc 2 2025 22 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$2025, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1415:
	.loc 2 2025 31 is_stmt 1 discriminator 3
	movl	-44(%rbp), %eax
	cmpl	$341, %eax
	jbe	.L1416
	.loc 2 2025 31 is_stmt 0 discriminator 4
	leaq	.LC12(%rip), %rax
	movl	$2025, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L1416:
	.loc 2 2025 39 is_stmt 1 discriminator 5
	movl	-44(%rbp), %eax
	cltq
	leaq	3(%rax), %rdx
	movq	-92(%rbp), %rax
	movq	%rax, 4(%r12,%rdx,8)
.LBE388:
	.loc 2 2021 7 discriminator 2
	nop
.L1417:
.LBE387:
	.loc 2 2027 8
	movq	%r12, %rax
	leaq	-24(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE121:
	.size	silver_output_profile__scalar_assignment_body___wrapped_statements.34, .-silver_output_profile__scalar_assignment_body___wrapped_statements.34
	.section	.rodata
	.align 8
.LC198:
	.ascii	"failed precondition from silver_output_profile.adb:2001"
	.align 8
.LC199:
	.ascii	"failed precondition from silver_output_profile.adb:2002"
	.align 8
.LC200:
	.ascii	"failed postcondition from silver_output_profile.adb:2003"
	.align 8
.LC201:
	.ascii	"failed postcondition from silver_output_profile.adb:2004"
	.text
	.align 2
	.type	silver_output_profile__scalar_assignment_body, @function
silver_output_profile__scalar_assignment_body:
.LFB120:
	.loc 2 2007 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$120, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movq	%rdx, -104(%rbp)
	movq	%rcx, -112(%rbp)
	.loc 2 2007 4
	leaq	16(%rbp), %rdx
	.loc 2 2007 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -56(%rbp)
	movq	%rax, -72(%rbp)
	movq	-104(%rbp), %rax
	movq	%rax, -80(%rbp)
	movq	-112(%rbp), %rax
	movq	%rax, -64(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %r8d
	movq	-88(%rbp), %rax
	movl	4(%rax), %r9d
	cmpl	%r8d, %r9d
	jl	.L1419
	.loc 2 2007 4 discriminator 2
	movslq	%r9d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r8d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L1420
.L1419:
	.loc 2 2007 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L1420:
.LBB389:
	.loc 2 2007 4 discriminator 4
	cmpl	%r8d, %r9d
	.loc 2 2007 4 discriminator 7
	cmpl	%r8d, %r9d
	.loc 2 2007 4 discriminator 10
	cmpl	%r8d, %r9d
	.loc 2 2001 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L1427
.LBB390:
	.loc 2 2001 15 is_stmt 0 discriminator 1
	leaq	.LC198(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1427:
.LBE390:
	.loc 2 2001 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 2001 15 discriminator 2
	testl	%eax, %eax
	jle	.L1428
	.loc 2 2001 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L1429
.L1428:
.LBB391:
	.loc 2 2001 15 discriminator 4
	leaq	.LC198(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1429:
.LBE391:
	.loc 2 2002 19
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_context
	.loc 2 2002 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 2001 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L1430
.LBB392:
	.loc 2 2001 15 is_stmt 0 discriminator 6
	leaq	.LC199(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1430:
.LBE392:
	.loc 2 2002 58 is_stmt 1 discriminator 2
	movq	-80(%rbp), %rdx
	movq	-64(%rbp), %rcx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_body
	.loc 2 2002 58 is_stmt 0 discriminator 3
	xorl	$1, %eax
	.loc 2 2001 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L1431
.LBB393:
	.loc 2 2001 15 is_stmt 0 discriminator 8
	leaq	.LC199(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1431:
.LBE393:
.LBB394:
	.loc 2 2007 4 is_stmt 1 discriminator 13
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__scalar_assignment_body___wrapped_statements.34
	movq	%rax, %rbx
.LBB395:
	.loc 2 2003 28
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rbx, %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_body
	.loc 2 2003 28 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L1432
.LBB396:
	.loc 2 2003 28 discriminator 2
	leaq	.LC200(%rip), %r14
	leaq	.LC6(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1432:
.LBE396:
	.loc 2 2004 59 is_stmt 1
	movl	4(%rbx), %eax
	.loc 2 2003 28 discriminator 3
	testl	%eax, %eax
	je	.L1434
	.loc 2 2005 59
	movl	4(%rbx), %edx
	movq	-64(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 2005 12
	cmpl	%eax, %edx
	jg	.L1434
.LBB397:
	.loc 2 2003 28 discriminator 4
	leaq	.LC201(%rip), %r12
	leaq	.LC6(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1434:
.LBE397:
.LBE395:
	.loc 2 2007 4 discriminator 16
	movq	%rbx, %rax
.LBE394:
.LBE389:
	.loc 2 2007 4 is_stmt 0
	addq	$120, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE120:
	.size	silver_output_profile__scalar_assignment_body, .-silver_output_profile__scalar_assignment_body
	.align 2
	.type	silver_output_profile__basic_body___wrapped_statements.35, @function
silver_output_profile__basic_body___wrapped_statements.35:
.LFB123:
	.loc 2 2037 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$136, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -120(%rbp)
	movq	%rsp, %rax
	movq	%rax, -168(%rbp)
	.loc 2 2039 7
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, -52(%rbp)
	movl	-52(%rbp), %eax
	cltq
	movq	%rax, -64(%rbp)
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	leaq	36(%rax), %r12
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	leaq	36(%rax), %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %edi
	movl	$0, %edx
	divq	%rdi
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	addq	$3, %rax
	shrq	$2, %rax
	salq	$2, %rax
	movq	%rax, -72(%rbp)
	.loc 2 2039 7 is_stmt 0 discriminator 1
	movq	16(%rbx), %rax
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 2043 26 is_stmt 1
	movq	-72(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 2043 7
	testl	%eax, %eax
	jne	.L1436
	.loc 2 2043 42 discriminator 1
	movq	16(%rbx), %rax
	movq	%rax, %rdi
	call	silver_output_profile__invalid_body
	.loc 2 2043 35 discriminator 2
	jmp	.L1437
.L1436:
	.loc 2 2044 10
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	8(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$49, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 2044 7 discriminator 1
	testl	%eax, %eax
	je	.L1438
.LBB398:
	.loc 2 2045 20
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$49, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__body_token
	.loc 2 2045 20 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2045 20 discriminator 2
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1439
	.loc 2 2045 20 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2045, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1439:
	.loc 2 2045 17 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	jmp	.L1440
.L1438:
.LBE398:
	.loc 2 2046 13
	movq	(%rbx), %rax
	leaq	6824(%rax), %rcx
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	(%rbx), %rax
	movq	%rax, %rdi
	movq	8(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rcx, %r9
	movl	$0, %r8d
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__call_after
	.loc 2 2046 7 discriminator 1
	testl	%eax, %eax
	je	.L1441
	.loc 2 2047 29
	movq	(%rbx), %rax
	leaq	6824(%rax), %rcx
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	(%rbx), %rax
	movq	%rax, %rdi
	movq	8(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rcx, %r9
	movl	$0, %r8d
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__call_after
	.loc 2 2047 26 discriminator 1
	movq	-72(%rbp), %rdx
	movl	%eax, 4(%rdx)
.LBB399:
	.loc 2 2048 20
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$11, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__body_token
	.loc 2 2048 20 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2048 20 discriminator 2
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1442
	.loc 2 2048 20 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2048, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1442:
	.loc 2 2048 17 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE399:
	.loc 2 2049 34
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	8(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$0, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_names__association_after@PLT
	.loc 2 2049 26 discriminator 1
	movq	-72(%rbp), %rdx
	movl	%eax, 4(%rdx)
	.loc 2 2050 19
	movq	-72(%rbp), %rax
	leaq	20(%rax), %r8
	movq	-72(%rbp), %rax
	movl	4(%rax), %esi
	movq	8(%rbx), %rax
	movq	(%rbx), %rcx
	leaq	-160(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%r8, %r9
	movl	%esi, %r8d
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__read_string_in_flow
	movq	-160(%rbp), %rax
	movq	-152(%rbp), %rdx
	movq	%rax, -96(%rbp)
	movq	%rdx, -88(%rbp)
	movl	-144(%rbp), %eax
	movl	%eax, -80(%rbp)
	.loc 2 2051 25
	movl	-96(%rbp), %eax
	.loc 2 2051 10
	testl	%eax, %eax
	je	.L1443
	.loc 2 2051 29 discriminator 1
	movq	-72(%rbp), %rax
	movzbl	33(%rax), %eax
	testb	%al, %al
	jne	.L1443
	.loc 2 2052 66
	leaq	-96(%rbp), %rax
	movq	%rax, %rdi
	call	silver_output_profile__summary_of
	movq	%rax, %rsi
	movq	%rdx, %rdi
	.loc 2 2052 40 discriminator 1
	movq	-72(%rbp), %rax
	movq	24(%rax), %r8
	movl	32(%rax), %eax
	movq	%rsi, %rdx
	movq	%rdi, %rcx
	movq	%r8, %rdi
	movl	%eax, %esi
	call	silver_length_intervals__fits@PLT
	.loc 2 2052 20 discriminator 2
	xorl	$1, %eax
	.loc 2 2052 12 discriminator 2
	testb	%al, %al
	je	.L1444
.L1443:
	.loc 2 2053 22
	movq	16(%rbx), %rax
	movq	%rax, %rdi
	call	silver_output_profile__invalid_body
	.loc 2 2053 15 discriminator 1
	jmp	.L1437
.L1444:
	.loc 2 2054 26
	movl	-96(%rbp), %edx
	movq	-72(%rbp), %rax
	movl	%edx, 4(%rax)
.LBB400:
	.loc 2 2055 20
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$12, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__body_token
	.loc 2 2055 20 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2055 20 discriminator 2
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1445
	.loc 2 2055 20 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2055, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1445:
	.loc 2 2055 17 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE400:
	.loc 2 2056 24
	movq	-72(%rbp), %rax
	movb	$1, 17(%rax)
	jmp	.L1440
.L1441:
	.loc 2 2057 13
	movq	(%rbx), %rax
	leaq	6824(%rax), %rcx
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	(%rbx), %rax
	movq	%rax, %rdi
	movq	8(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rcx, %r9
	movl	$1, %r8d
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__call_after
	.loc 2 2057 7 discriminator 1
	testl	%eax, %eax
	je	.L1446
	.loc 2 2058 29
	movq	(%rbx), %rax
	leaq	6824(%rax), %rcx
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	(%rbx), %rax
	movq	%rax, %rdi
	movq	8(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rcx, %r9
	movl	$1, %r8d
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__call_after
	.loc 2 2058 26 discriminator 1
	movq	-72(%rbp), %rdx
	movl	%eax, 4(%rdx)
.LBB401:
	.loc 2 2059 20
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$11, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__body_token
	.loc 2 2059 20 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2059 20 discriminator 2
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1447
	.loc 2 2059 20 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2059, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1447:
	.loc 2 2059 17 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE401:
	.loc 2 2060 34
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	8(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$0, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_names__association_after@PLT
	.loc 2 2060 26 discriminator 1
	movq	-72(%rbp), %rdx
	movl	%eax, 4(%rdx)
	.loc 2 2061 19
	movq	-72(%rbp), %rax
	leaq	20(%rax), %r8
	movq	-72(%rbp), %rax
	movl	4(%rax), %esi
	movq	8(%rbx), %rax
	movq	(%rbx), %rcx
	leaq	-160(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%r8, %r9
	movl	%esi, %r8d
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__read_string_in_flow
	movq	-160(%rbp), %rax
	movq	-152(%rbp), %rdx
	movq	%rax, -96(%rbp)
	movq	%rdx, -88(%rbp)
	movl	-144(%rbp), %eax
	movl	%eax, -80(%rbp)
	.loc 2 2062 25
	movl	-96(%rbp), %eax
	.loc 2 2062 10
	testl	%eax, %eax
	je	.L1448
	.loc 2 2062 29 discriminator 1
	movq	-72(%rbp), %rax
	movzbl	33(%rax), %eax
	testb	%al, %al
	jne	.L1448
	.loc 2 2063 66
	leaq	-96(%rbp), %rax
	movq	%rax, %rdi
	call	silver_output_profile__summary_of
	movq	%rax, %rsi
	movq	%rdx, %rdi
	.loc 2 2063 40 discriminator 1
	movq	-72(%rbp), %rax
	movq	24(%rax), %r8
	movl	32(%rax), %eax
	movq	%rsi, %rdx
	movq	%rdi, %rcx
	movq	%r8, %rdi
	movl	%eax, %esi
	call	silver_length_intervals__fits@PLT
	.loc 2 2063 20 discriminator 2
	xorl	$1, %eax
	.loc 2 2063 12 discriminator 2
	testb	%al, %al
	je	.L1449
.L1448:
	.loc 2 2064 22
	movq	16(%rbx), %rax
	movq	%rax, %rdi
	call	silver_output_profile__invalid_body
	.loc 2 2064 15 discriminator 1
	jmp	.L1437
.L1449:
	.loc 2 2065 26
	movl	-96(%rbp), %edx
	movq	-72(%rbp), %rax
	movl	%edx, 4(%rax)
.LBB402:
	.loc 2 2066 20
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$12, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__body_token
	.loc 2 2066 20 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2066 20 discriminator 2
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1450
	.loc 2 2066 20 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2066, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1450:
	.loc 2 2066 17 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE402:
	.loc 2 2067 24
	movq	-72(%rbp), %rax
	movb	$1, 17(%rax)
	jmp	.L1440
.L1446:
	.loc 2 2068 35
	movq	(%rbx), %rax
	movl	17744(%rax), %eax
	.loc 2 2068 7
	testl	%eax, %eax
	je	.L1451
	.loc 2 2069 18
	movq	(%rbx), %rax
	leaq	6824(%rax), %rcx
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	(%rbx), %rax
	movq	%rax, %rdi
	movq	8(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rcx, %r9
	movl	$4, %r8d
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__call_after
	.loc 2 2069 109 discriminator 1
	testl	%eax, %eax
	setne	%al
	.loc 2 2069 9 discriminator 1
	testb	%al, %al
	je	.L1451
	.loc 2 2071 29
	movq	(%rbx), %rax
	leaq	6824(%rax), %rcx
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	(%rbx), %rax
	movq	%rax, %rdi
	movq	8(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rcx, %r9
	movl	$4, %r8d
	movl	%edx, %ecx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__call_after
	.loc 2 2071 26 discriminator 1
	movq	-72(%rbp), %rdx
	movl	%eax, 4(%rdx)
	.loc 2 2072 36
	movq	-72(%rbp), %r13
	movq	-72(%rbp), %rax
	movq	24(%rax), %rdx
	movl	32(%rax), %eax
	movq	%rdx, %rdi
	movl	%eax, %esi
	call	silver_path_facts__rejected@PLT
	movq	%rax, 24(%r13)
	movl	32(%r13), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, 32(%r13)
	.loc 2 2072 28 discriminator 1
	jmp	.L1440
.L1451:
	.loc 2 2073 13
	movq	-72(%rbp), %rax
	movl	4(%rax), %ecx
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__scalar_target
	.loc 2 2073 7 discriminator 1
	testl	%eax, %eax
	je	.L1452
.LBB403:
	.loc 2 2074 20
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__scalar_assignment_body
	.loc 2 2074 20 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2074 20 discriminator 2
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1453
	.loc 2 2074 20 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2074, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1453:
	.loc 2 2074 17 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	jmp	.L1440
.L1452:
.LBE403:
	.loc 2 2076 20
	movq	-72(%rbp), %rax
	movl	4(%rax), %ecx
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__body_string_target
	.loc 2 2076 17 discriminator 1
	movq	%rax, -104(%rbp)
	.loc 2 2077 26
	movl	-104(%rbp), %edx
	movq	-72(%rbp), %rax
	movl	%edx, 4(%rax)
	.loc 2 2078 24
	movl	-100(%rbp), %edx
	movq	-72(%rbp), %rax
	movl	%edx, 8(%rax)
.LBB404:
	.loc 2 2079 20
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$19, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__body_token
	.loc 2 2079 20 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2079 20 discriminator 2
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1454
	.loc 2 2079 20 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2079, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1454:
	.loc 2 2079 17 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE404:
	.loc 2 2080 19
	movq	-72(%rbp), %rax
	leaq	20(%rax), %r8
	movq	-72(%rbp), %rax
	movl	4(%rax), %esi
	movq	8(%rbx), %rax
	movq	(%rbx), %rcx
	leaq	-160(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%r8, %r9
	movl	%esi, %r8d
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__read_string_in_flow
	movq	-160(%rbp), %rax
	movq	-152(%rbp), %rdx
	movq	%rax, -96(%rbp)
	movq	%rdx, -88(%rbp)
	movl	-144(%rbp), %eax
	movl	%eax, -80(%rbp)
	.loc 2 2081 25
	movl	-96(%rbp), %eax
	.loc 2 2081 10
	testl	%eax, %eax
	je	.L1455
	.loc 2 2081 51 discriminator 1
	movq	-72(%rbp), %rax
	movl	8(%rax), %eax
	.loc 2 2081 29 discriminator 1
	testl	%eax, %eax
	je	.L1455
	.loc 2 2082 66
	leaq	-96(%rbp), %rax
	movq	%rax, %rdi
	call	silver_output_profile__summary_of
	movq	%rax, %rsi
	movq	%rdx, %rdi
	.loc 2 2082 40 discriminator 1
	movq	-72(%rbp), %rax
	movq	24(%rax), %r8
	movl	32(%rax), %eax
	movq	%rsi, %rdx
	movq	%rdi, %rcx
	movq	%r8, %rdi
	movl	%eax, %esi
	call	silver_length_intervals__fits@PLT
	.loc 2 2082 20 discriminator 2
	xorl	$1, %eax
	.loc 2 2082 12 discriminator 2
	testb	%al, %al
	jne	.L1455
	.loc 2 2084 98
	movq	-72(%rbp), %rax
	movl	8(%rax), %eax
	.loc 2 2084 84
	testl	%eax, %eax
	jle	.L1456
	.loc 2 2084 84 is_stmt 0 discriminator 1
	cmpl	$341, %eax
	jle	.L1457
.L1456:
	.loc 2 2084 84 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$2084, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1457:
	.loc 2 2084 54 is_stmt 1 discriminator 3
	cltq
	movq	(%rbx), %rcx
	leaq	-1(%rax), %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	salq	$2, %rax
	addq	%rcx, %rax
	addq	$4, %rax
	movq	%rax, %rdi
	call	silver_output_profile__binding_summary
	movq	%rax, %r14
	movq	%rdx, %r15
	.loc 2 2084 34 discriminator 4
	leaq	-96(%rbp), %rax
	movq	%rax, %rdi
	call	silver_output_profile__summary_of
	movq	%rax, %rsi
	movq	%rdx, %rdi
	.loc 2 2083 40
	movq	-72(%rbp), %rax
	movq	24(%rax), %r10
	movl	32(%rax), %eax
	movq	%r14, %r8
	movq	%r15, %r9
	movq	%rsi, %rdx
	movq	%rdi, %rcx
	movq	%r10, %rdi
	movl	%eax, %esi
	call	silver_length_intervals__same_length@PLT
	.loc 2 2083 20 discriminator 1
	xorl	$1, %eax
	.loc 2 2083 12 discriminator 1
	testb	%al, %al
	je	.L1458
.L1455:
	.loc 2 2085 22
	movq	16(%rbx), %rax
	movq	%rax, %rdi
	call	silver_output_profile__invalid_body
	.loc 2 2085 15 discriminator 1
	jmp	.L1437
.L1458:
	.loc 2 2086 26
	movl	-96(%rbp), %edx
	movq	-72(%rbp), %rax
	movl	%edx, 4(%rax)
	.loc 2 2087 26
	movq	-72(%rbp), %rax
	movb	$1, 16(%rax)
.L1440:
.LBB405:
	.loc 2 2089 17
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$13, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__body_token
	.loc 2 2089 17 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2089 17 discriminator 2
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1459
	.loc 2 2089 17 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2089, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1459:
	.loc 2 2089 14 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE405:
	.loc 2 2090 26
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	16(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 2090 7
	cmpl	%eax, %edx
	jg	.L1460
	.loc 2 2090 55 discriminator 1
	movq	16(%rbx), %rax
	movq	%rax, %rdi
	call	silver_output_profile__invalid_body
	.loc 2 2090 48 discriminator 2
	jmp	.L1437
.L1460:
	.loc 2 2091 7
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	addq	$36, %rax
	movl	$4, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rbx
	.loc 2 2091 7 is_stmt 0 discriminator 1
	movq	%rbx, %rdx
	movq	-72(%rbp), %rax
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 2091 7 discriminator 2
	movq	%rbx, %rax
.L1437:
	.loc 2 2092 8 is_stmt 1
	movq	-168(%rbp), %rsp
	leaq	-40(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE123:
	.size	silver_output_profile__basic_body___wrapped_statements.35, .-silver_output_profile__basic_body___wrapped_statements.35
	.section	.rodata
	.align 8
.LC202:
	.ascii	"failed precondition from silver_output_profile.adb:2032"
	.align 8
.LC203:
	.ascii	"failed precondition from silver_output_profile.adb:2033"
	.align 8
.LC204:
	.ascii	"failed postcondition from silver_output_profile.adb:2034"
	.align 8
.LC205:
	.ascii	"failed postcondition from silver_output_profile.adb:2035"
	.text
	.align 2
	.globl	silver_output_profile__basic_body
	.type	silver_output_profile__basic_body, @function
silver_output_profile__basic_body:
.LFB122:
	.loc 2 2037 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$120, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movq	%rdx, -104(%rbp)
	movq	%rcx, -112(%rbp)
	.loc 2 2037 4
	leaq	16(%rbp), %rdx
	.loc 2 2037 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -56(%rbp)
	movq	%rax, -72(%rbp)
	movq	-104(%rbp), %rax
	movq	%rax, -80(%rbp)
	movq	-112(%rbp), %rax
	movq	%rax, -64(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %r8d
	movq	-88(%rbp), %rax
	movl	4(%rax), %r9d
	cmpl	%r8d, %r9d
	jl	.L1463
	.loc 2 2037 4 discriminator 2
	movslq	%r9d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r8d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L1464
.L1463:
	.loc 2 2037 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L1464:
.LBB406:
	.loc 2 2037 4 discriminator 4
	cmpl	%r8d, %r9d
	.loc 2 2037 4 discriminator 7
	cmpl	%r8d, %r9d
	.loc 2 2037 4 discriminator 10
	cmpl	%r8d, %r9d
	.loc 2 2032 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L1471
.LBB407:
	.loc 2 2032 15 is_stmt 0 discriminator 1
	leaq	.LC202(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1471:
.LBE407:
	.loc 2 2032 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 2032 15 discriminator 2
	testl	%eax, %eax
	jle	.L1472
	.loc 2 2032 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L1473
.L1472:
.LBB408:
	.loc 2 2032 15 discriminator 4
	leaq	.LC202(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1473:
.LBE408:
	.loc 2 2033 19
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_context
	.loc 2 2033 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 2032 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L1474
.LBB409:
	.loc 2 2032 15 is_stmt 0 discriminator 6
	leaq	.LC203(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1474:
.LBE409:
	.loc 2 2033 58 is_stmt 1 discriminator 2
	movq	-80(%rbp), %rdx
	movq	-64(%rbp), %rcx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_body
	.loc 2 2033 58 is_stmt 0 discriminator 3
	xorl	$1, %eax
	.loc 2 2032 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L1475
.LBB410:
	.loc 2 2032 15 is_stmt 0 discriminator 8
	leaq	.LC203(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1475:
.LBE410:
.LBB411:
	.loc 2 2037 4 is_stmt 1 discriminator 13
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__basic_body___wrapped_statements.35
	movq	%rax, %rbx
.LBB412:
	.loc 2 2034 16
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rbx, %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_body
	.loc 2 2034 16 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L1476
.LBB413:
	.loc 2 2034 16 discriminator 2
	leaq	.LC204(%rip), %r14
	leaq	.LC6(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1476:
.LBE413:
	.loc 2 2035 47 is_stmt 1
	movl	4(%rbx), %eax
	.loc 2 2034 16 discriminator 3
	testl	%eax, %eax
	je	.L1478
	.loc 2 2036 47
	movl	4(%rbx), %edx
	movq	-64(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 2036 12
	cmpl	%eax, %edx
	jg	.L1478
.LBB414:
	.loc 2 2034 16 discriminator 4
	leaq	.LC205(%rip), %r12
	leaq	.LC6(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1478:
.LBE414:
.LBE412:
	.loc 2 2037 4 discriminator 16
	movq	%rbx, %rax
.LBE411:
.LBE406:
	.loc 2 2037 4 is_stmt 0
	addq	$120, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE122:
	.size	silver_output_profile__basic_body, .-silver_output_profile__basic_body
	.section	.rodata
	.align 8
.LC206:
	.ascii	"failed precondition from silver_output_profile.adb:2097"
	.align 8
.LC207:
	.ascii	"failed precondition from silver_output_profile.adb:2098"
	.text
	.align 2
	.globl	silver_output_profile__at_body_stop
	.type	silver_output_profile__at_body_stop, @function
silver_output_profile__at_body_stop:
.LFB124:
	.loc 2 2099 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$32, %rsp
	.cfi_offset 14, -24
	.cfi_offset 13, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %rbx
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%rbx, %rdi
	movq	%rsi, -48(%rbp)
	movq	%rdi, -40(%rbp)
	movl	%edx, -52(%rbp)
	movb	%cl, -53(%rbp)
	.loc 2 2099 4
	movq	-40(%rbp), %rax
	movl	(%rax), %edi
	movq	-40(%rbp), %rax
	movl	4(%rax), %esi
	movq	-40(%rbp), %rax
	movl	4(%rax), %edx
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L1480
	.loc 2 2099 4 is_stmt 0 discriminator 1
	movq	-40(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-40(%rbp), %rcx
	movl	(%rcx), %r14d
	movslq	%r14d, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L1481
.L1480:
	.loc 2 2099 4 discriminator 2
	movl	$0, %eax
	movl	$0, %edx
.L1481:
.LBB415:
	.loc 2 2097 15 is_stmt 1
	cmpl	$1, %edi
	je	.L1482
.LBB416:
	.loc 2 2097 15 is_stmt 0 discriminator 1
	leaq	.LC206(%rip), %r12
	leaq	.LC1(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1482:
.LBE416:
	.loc 2 2097 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 2097 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L1483
	.loc 2 2097 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L1484
.L1483:
.LBB417:
	.loc 2 2097 15 discriminator 4
	leaq	.LC206(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1484:
.LBE417:
	.loc 2 2098 41
	cmpl	$2147483647, %esi
	jne	.L1485
	.loc 2 2098 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$2098, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1485:
	.loc 2 2098 41 discriminator 3
	leal	1(%rsi), %eax
	.loc 2 2097 15 is_stmt 1 discriminator 5
	cmpl	-52(%rbp), %eax
	jge	.L1486
.LBB418:
	.loc 2 2097 15 is_stmt 0 discriminator 6
	leaq	.LC207(%rip), %r8
	leaq	.LC1(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1486:
.LBE418:
	.loc 2 2101 12 is_stmt 1
	cmpb	$2, -53(%rbp)
	jbe	.L1487
	.loc 2 2101 12 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$2101, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L1487:
	.loc 2 2101 12 discriminator 2
	cmpb	$2, -53(%rbp)
	jbe	.L1488
	.loc 2 2101 12 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2101, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L1488:
	.loc 2 2101 7 is_stmt 1 discriminator 4
	cmpb	$0, -53(%rbp)
	je	.L1489
	cmpb	$1, -53(%rbp)
	je	.L1490
	jmp	.L1496
.L1489:
	.loc 2 2102 26
	movl	-52(%rbp), %edx
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movl	$10, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 2102 67 discriminator 1
	testl	%eax, %eax
	setne	%al
	jmp	.L1492
.L1490:
	.loc 2 2103 27
	movl	-52(%rbp), %edx
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movl	$25, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 2103 69 discriminator 1
	testl	%eax, %eax
	setne	%al
	jmp	.L1492
.L1496:
	.loc 2 2104 30
	movl	-52(%rbp), %edx
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movl	$26, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 2104 73 discriminator 1
	testl	%eax, %eax
	setne	%al
	.loc 2 2106 11
	testb	%al, %al
	jne	.L1493
	.loc 2 2105 19
	movl	-52(%rbp), %edx
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movl	$25, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 2105 61 discriminator 1
	testl	%eax, %eax
	setne	%al
	.loc 2 2105 11 discriminator 1
	testb	%al, %al
	jne	.L1493
	.loc 2 2106 19 discriminator 1
	movl	-52(%rbp), %edx
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movl	$10, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 2106 60 discriminator 2
	testl	%eax, %eax
	setne	%al
	.loc 2 2106 11 discriminator 2
	testb	%al, %al
	je	.L1494
.L1493:
	.loc 2 2106 11 is_stmt 0 discriminator 3
	movl	$1, %eax
	.loc 2 2106 11 discriminator 5
	jmp	.L1492
.L1494:
	.loc 2 2106 11 discriminator 4
	movl	$0, %eax
.L1492:
.LBE415:
	.loc 2 2099 4 is_stmt 1
	addq	$32, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE124:
	.size	silver_output_profile__at_body_stop, .-silver_output_profile__at_body_stop
	.section	.rodata
	.align 8
.LC208:
	.ascii	"failed precondition from silver_output_profile.adb:2168"
	.align 8
.LC209:
	.ascii	"failed precondition from silver_output_profile.adb:2169"
	.align 8
.LC210:
	.ascii	"failed postcondition from silver_output_profile.adb:2170"
	.align 8
.LC211:
	.ascii	"failed postcondition from silver_output_profile.adb:2171"
	.text
	.align 2
	.type	silver_output_profile__body_tail, @function
silver_output_profile__body_tail:
.LFB125:
	.loc 2 2175 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$160, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r9
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r9, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movq	%rdx, -104(%rbp)
	movq	%rcx, -112(%rbp)
	movb	%r8b, -113(%rbp)
	.loc 2 2175 4
	leaq	16(%rbp), %rdx
	.loc 2 2175 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -48(%rbp)
	movq	%rax, -72(%rbp)
	movq	-104(%rbp), %rax
	movq	%rax, -80(%rbp)
	movq	-112(%rbp), %rax
	movq	%rax, -64(%rbp)
	movzbl	-113(%rbp), %eax
	movb	%al, -52(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %r8d
	movq	-88(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%r8d, %r12d
	jl	.L1498
	.loc 2 2175 4 discriminator 2
	movslq	%r12d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r8d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L1499
.L1498:
	.loc 2 2175 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L1499:
.LBB419:
	.loc 2 2175 4 discriminator 4
	cmpl	%r8d, %r12d
	.loc 2 2175 4 discriminator 7
	cmpl	%r8d, %r12d
	.loc 2 2175 4 discriminator 10
	cmpl	%r8d, %r12d
	.loc 2 2168 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L1506
.LBB420:
	.loc 2 2168 15 is_stmt 0 discriminator 1
	leaq	.LC208(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1506:
.LBE420:
	.loc 2 2168 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 2168 15 discriminator 2
	testl	%eax, %eax
	jle	.L1507
	.loc 2 2168 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L1508
.L1507:
.LBB421:
	.loc 2 2168 15 discriminator 4
	leaq	.LC208(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1508:
.LBE421:
	.loc 2 2169 19
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_context
	.loc 2 2169 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 2168 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L1509
.LBB422:
	.loc 2 2168 15 is_stmt 0 discriminator 6
	leaq	.LC209(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1509:
.LBE422:
	.loc 2 2169 58 is_stmt 1 discriminator 2
	movq	-80(%rbp), %rdx
	movq	-64(%rbp), %rcx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_body
	.loc 2 2169 58 is_stmt 0 discriminator 3
	xorl	$1, %eax
	.loc 2 2168 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L1510
.LBB423:
	.loc 2 2168 15 is_stmt 0 discriminator 8
	leaq	.LC209(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1510:
.LBE423:
	.loc 2 2174 55 is_stmt 1
	cmpl	$2147483647, %r12d
	jne	.L1511
	.loc 2 2174 55 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$2174, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1511:
	.loc 2 2174 55 discriminator 3
	leal	1(%r12), %eax
	.loc 2 2174 60 is_stmt 1 discriminator 4
	movq	-64(%rbp), %rdx
	movl	4(%rdx), %edx
	movl	$0, %ecx
	subl	%edx, %eax
	jno	.L1512
	movl	$1, %ecx
.L1512:
	movl	%eax, %edx
	.loc 2 2174 60 is_stmt 0 discriminator 5
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L1514
	.loc 2 2174 60 discriminator 6
	leaq	.LC12(%rip), %rax
	movl	$2174, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1514:
	.loc 2 2174 60 discriminator 8
	movl	%edx, %eax
	movl	%eax, -56(%rbp)
.LBB424:
	.loc 2 2175 4 is_stmt 1 discriminator 13
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__body_tail___wrapped_statements.38
	movq	%rax, %rbx
.LBB425:
	.loc 2 2170 28
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rbx, %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_body
	.loc 2 2170 28 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L1515
.LBB426:
	.loc 2 2170 28 discriminator 2
	leaq	.LC210(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1515:
.LBE426:
	.loc 2 2171 46 is_stmt 1
	movl	4(%rbx), %eax
	.loc 2 2170 28 discriminator 3
	testl	%eax, %eax
	je	.L1517
	.loc 2 2171 84 discriminator 1
	movl	4(%rbx), %edx
	movq	-64(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 2171 50 discriminator 1
	cmpl	%eax, %edx
	jge	.L1517
.LBB427:
	.loc 2 2170 28 discriminator 4
	leaq	.LC211(%rip), %r14
	leaq	.LC6(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1517:
.LBE427:
.LBE425:
	.loc 2 2175 4 discriminator 16
	movq	%rbx, %rax
.LBE424:
.LBE419:
	.loc 2 2175 4 is_stmt 0
	addq	$160, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE125:
	.size	silver_output_profile__body_tail, .-silver_output_profile__body_tail
	.align 2
	.type	silver_output_profile__body_tail___wrapped_statements__L_19__B2177b___finalizer.39, @function
silver_output_profile__body_tail___wrapped_statements__L_19__B2177b___finalizer.39:
.LFB128:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE128:
	.size	silver_output_profile__body_tail___wrapped_statements__L_19__B2177b___finalizer.39, .-silver_output_profile__body_tail___wrapped_statements__L_19__B2177b___finalizer.39
	.section	.rodata
	.align 8
.LC212:
	.ascii	"Loop_Invariant failed at silver_output_profile.adb:2182"
	.align 8
.LC213:
	.ascii	"Loop_Invariant failed at silver_output_profile.adb:2183"
	.align 8
.LC214:
	.ascii	"Loop_Variant failed at silver_output_profile.adb:2186"
	.text
	.align 2
	.type	silver_output_profile__body_tail___wrapped_statements.38, @function
silver_output_profile__body_tail___wrapped_statements.38:
.LFB127:
	.loc 2 2175 4 is_stmt 1
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA127
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB4:
	subq	$152, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -120(%rbp)
	.loc 2 2175 4
	leaq	16(%rbp), %rax
	.loc 2 2175 4 is_stmt 0 discriminator 1
	movq	%rax, -88(%rbp)
	movq	%rsp, %rax
	movq	%rax, -184(%rbp)
	.loc 2 2178 7 is_stmt 1
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, -52(%rbp)
	movl	-52(%rbp), %eax
	cltq
	movq	%rax, -64(%rbp)
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	leaq	36(%rax), %rsi
	movq	%rsi, -128(%rbp)
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	leaq	36(%rax), %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %ecx
	movl	$0, %edx
	divq	%rcx
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	addq	$3, %rax
	shrq	$2, %rax
	salq	$2, %rax
	movq	%rax, -72(%rbp)
	.loc 2 2178 7 is_stmt 0 discriminator 1
	movq	16(%rbx), %rdx
	movq	-72(%rbp), %rax
	movq	%rax, %rdi
	movq	%rdx, %rcx
	movq	%rsi, %rax
	movq	%rax, %rdx
	movq	%rcx, %rsi
	call	memcpy@PLT
	.loc 2 2181 90 is_stmt 1
	movl	$0, %r13d
.L1532:
.LBB428:
	.loc 2 2181 29 discriminator 1
	movq	-72(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 2181 34 discriminator 1
	testl	%eax, %eax
	je	.L1521
	.loc 2 2181 47 discriminator 2
	movq	-72(%rbp), %rax
	movl	4(%rax), %r8d
	movq	8(%rbx), %rdx
	movzbl	28(%rbx), %eax
	movzbl	%al, %eax
	movq	(%rdx), %rdi
	movq	8(%rdx), %rsi
	movl	%eax, %ecx
	movl	%r8d, %edx
	call	silver_output_profile__at_body_stop
	.loc 2 2181 43 discriminator 3
	xorl	$1, %eax
	xorl	$1, %eax
	.loc 2 2181 34 discriminator 3
	testb	%al, %al
	jne	.L1521
	.loc 2 2182 33
	movq	8(%rbx), %rax
	movq	(%rbx), %rdi
	movq	-72(%rbp), %rdx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_body
	.loc 2 2182 33 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L1522
.LBB429:
	.loc 2 2182 33 discriminator 2
	leaq	.LC212(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rcx
	movq	-152(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1522:
.LBE429:
	.loc 2 2183 49 is_stmt 1
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	16(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 2183 33
	cmpl	%eax, %edx
	jge	.L1523
.LBB430:
	.loc 2 2183 33 is_stmt 0 discriminator 1
	leaq	.LC213(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rcx
	movq	-136(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1523:
.LBE430:
	.loc 2 2186 10 is_stmt 1
	testb	%r13b, %r13b
	je	.L1524
	.loc 2 2186 50 discriminator 1
	movl	-172(%rbp), %eax
	movl	%eax, -176(%rbp)
.L1524:
	.loc 2 2186 50 is_stmt 0 discriminator 2
	movq	-72(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -172(%rbp)
	.loc 2 2186 10 is_stmt 1 discriminator 2
	testb	%r13b, %r13b
	je	.L1525
	.loc 2 2186 50 discriminator 3
	movl	-176(%rbp), %ecx
	cmpl	%ecx, %eax
	jg	.L1526
.LBB431:
	.loc 2 2186 50 is_stmt 0 discriminator 4
	leaq	.LC214(%rip), %r14
	leaq	.LC8(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.LEHE4:
.L1525:
.LBE431:
	.loc 2 2186 10 is_stmt 1 discriminator 5
	movl	$1, %r13d
.L1526:
	.loc 2 2187 17
	movq	-72(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -76(%rbp)
	leaq	-112(%rbp), %rax
	movq	%rax, %rdi
.LEHB5:
	call	system__secondary_stack__ss_mark@PLT
.LBB432:
	.loc 2 2188 20
	movq	8(%rbx), %rax
	movq	(%rbx), %rdi
	movq	-72(%rbp), %rdx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__statement_body
	movq	%rax, %rcx
	.loc 2 2188 20 is_stmt 0 discriminator 1
	movl	(%rcx), %edx
	.loc 2 2188 20 discriminator 2
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1527
	.loc 2 2188 20 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2188, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.LEHE5:
.L1527:
	.loc 2 2188 17 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rax
	movq	%rax, %rdi
	movq	-128(%rbp), %rax
	movq	%rax, %rdx
	movq	%rcx, %rsi
	call	memcpy@PLT
	.loc 2 2188 0 discriminator 5
	movl	$1, %r12d
.L1536:
	.loc 2 2188 0 is_stmt 0 discriminator 6
	leaq	-112(%rbp), %rax
	movq	%rax, %r10
.LEHB6:
	call	silver_output_profile__body_tail___wrapped_statements__L_19__B2177b___finalizer.39
.LEHE6:
	.loc 2 2188 0 discriminator 7
	cmpl	$1, %r12d
	jne	.L1528
	.loc 2 2188 0 discriminator 9
	movl	$1, %eax
.L1538:
	.loc 2 2188 0 discriminator 10
	cmpl	$1, %eax
	jne	.L1529
	.loc 2 2188 0 discriminator 11
	nop
.LBE432:
	.loc 2 2189 29 is_stmt 1
	movq	-72(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 2189 10
	cmpl	%eax, -76(%rbp)
	jl	.L1532
	.loc 2 2189 51 discriminator 1
	movq	-72(%rbp), %rax
	movq	%rax, %rdi
.LEHB7:
	call	silver_output_profile__invalid_body
	.loc 2 2189 44 discriminator 2
	jmp	.L1531
.L1521:
.LBE428:
	.loc 2 2191 26
	movq	-72(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 2191 7
	testl	%eax, %eax
	jne	.L1533
	.loc 2 2191 42 discriminator 1
	movq	-72(%rbp), %rax
	movq	%rax, %rdi
	call	silver_output_profile__invalid_body
	.loc 2 2191 35 discriminator 2
	jmp	.L1531
.L1533:
	.loc 2 2192 7
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	addq	$36, %rax
	movl	$4, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rbx
	.loc 2 2192 7 is_stmt 0 discriminator 1
	movq	%rbx, %rdx
	movq	-72(%rbp), %rax
	movq	%rdx, %rcx
	movq	-128(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 2192 7 discriminator 2
	movq	%rbx, %rax
.L1531:
	.loc 2 2193 8 is_stmt 1
	movq	-184(%rbp), %rsp
	jmp	.L1541
.L1539:
	movq	%rax, -192(%rbp)
	movl	$0, %r12d
.LBB434:
.LBB433:
	.loc 2 2188 17 discriminator 12
	jmp	.L1536
.L1528:
	movq	-192(%rbp), %rax
	movq	%rax, -168(%rbp)
	jmp	.L1537
.L1540:
	movq	%rax, -168(%rbp)
.L1537:
	movl	$0, %eax
	jmp	.L1538
.L1529:
	movq	-168(%rbp), %rax
	movq	%rax, %rdi
	call	_Unwind_Resume@PLT
.L1541:
.LBE433:
.LBE434:
	.loc 2 2193 8
	leaq	-40(%rbp), %rsp
.LEHE7:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE127:
	.section	.gcc_except_table
.LLSDA127:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE127-.LLSDACSB127
.LLSDACSB127:
	.uleb128 .LEHB4-.LFB127
	.uleb128 .LEHE4-.LEHB4
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB5-.LFB127
	.uleb128 .LEHE5-.LEHB5
	.uleb128 .L1539-.LFB127
	.uleb128 0
	.uleb128 .LEHB6-.LFB127
	.uleb128 .LEHE6-.LEHB6
	.uleb128 .L1540-.LFB127
	.uleb128 0
	.uleb128 .LEHB7-.LFB127
	.uleb128 .LEHE7-.LEHB7
	.uleb128 0
	.uleb128 0
.LLSDACSE127:
	.text
	.size	silver_output_profile__body_tail___wrapped_statements.38, .-silver_output_profile__body_tail___wrapped_statements.38
	.section	.rodata
	.align 8
.LC215:
	.ascii	"failed precondition from silver_output_profile.adb:2199"
	.align 8
.LC216:
	.ascii	"failed precondition from silver_output_profile.adb:2200"
	.align 8
.LC217:
	.ascii	"failed postcondition from silver_output_profile.adb:2201"
	.align 8
.LC218:
	.ascii	"failed postcondition from silver_output_profile.adb:2202"
	.text
	.align 2
	.type	silver_output_profile__read_body, @function
silver_output_profile__read_body:
.LFB129:
	.loc 2 2208 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$160, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r9
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r9, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movq	%rdx, -104(%rbp)
	movq	%rcx, -112(%rbp)
	movb	%r8b, -113(%rbp)
	.loc 2 2208 4
	leaq	16(%rbp), %rdx
	.loc 2 2208 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -48(%rbp)
	movq	%rax, -72(%rbp)
	movq	-104(%rbp), %rax
	movq	%rax, -80(%rbp)
	movq	-112(%rbp), %rax
	movq	%rax, -64(%rbp)
	movzbl	-113(%rbp), %eax
	movb	%al, -52(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %r8d
	movq	-88(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%r8d, %r12d
	jl	.L1543
	.loc 2 2208 4 discriminator 2
	movslq	%r12d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r8d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L1544
.L1543:
	.loc 2 2208 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L1544:
.LBB435:
	.loc 2 2208 4 discriminator 4
	cmpl	%r8d, %r12d
	.loc 2 2208 4 discriminator 7
	cmpl	%r8d, %r12d
	.loc 2 2208 4 discriminator 10
	cmpl	%r8d, %r12d
	.loc 2 2199 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L1551
.LBB436:
	.loc 2 2199 15 is_stmt 0 discriminator 1
	leaq	.LC215(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1551:
.LBE436:
	.loc 2 2199 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 2199 15 discriminator 2
	testl	%eax, %eax
	jle	.L1552
	.loc 2 2199 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L1553
.L1552:
.LBB437:
	.loc 2 2199 15 discriminator 4
	leaq	.LC215(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1553:
.LBE437:
	.loc 2 2200 19
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_context
	.loc 2 2200 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 2199 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L1554
.LBB438:
	.loc 2 2199 15 is_stmt 0 discriminator 6
	leaq	.LC216(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1554:
.LBE438:
	.loc 2 2200 58 is_stmt 1 discriminator 2
	movq	-80(%rbp), %rdx
	movq	-64(%rbp), %rcx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_body
	.loc 2 2200 58 is_stmt 0 discriminator 3
	xorl	$1, %eax
	.loc 2 2199 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L1555
.LBB439:
	.loc 2 2199 15 is_stmt 0 discriminator 8
	leaq	.LC216(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1555:
.LBE439:
	.loc 2 2207 55 is_stmt 1
	cmpl	$2147483647, %r12d
	jne	.L1556
	.loc 2 2207 55 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$2207, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1556:
	.loc 2 2207 55 discriminator 3
	leal	1(%r12), %eax
	.loc 2 2207 60 is_stmt 1 discriminator 4
	movq	-64(%rbp), %rdx
	movl	4(%rdx), %edx
	movl	$0, %ecx
	subl	%edx, %eax
	jno	.L1557
	movl	$1, %ecx
.L1557:
	movl	%eax, %edx
	.loc 2 2207 60 is_stmt 0 discriminator 5
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L1559
	.loc 2 2207 60 discriminator 6
	leaq	.LC12(%rip), %rax
	movl	$2207, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1559:
	.loc 2 2207 60 discriminator 8
	movl	%edx, %eax
	movl	%eax, -56(%rbp)
.LBB440:
	.loc 2 2208 4 is_stmt 1 discriminator 13
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__read_body___wrapped_statements.40
	movq	%rax, %rbx
.LBB441:
	.loc 2 2201 28
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rbx, %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_body
	.loc 2 2201 28 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L1560
.LBB442:
	.loc 2 2201 28 discriminator 2
	leaq	.LC217(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1560:
.LBE442:
	.loc 2 2202 46 is_stmt 1
	movl	4(%rbx), %eax
	.loc 2 2201 28 discriminator 3
	testl	%eax, %eax
	je	.L1562
	.loc 2 2203 46
	movl	4(%rbx), %edx
	movq	-64(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 2203 12
	cmpl	%eax, %edx
	jg	.L1562
.LBB443:
	.loc 2 2201 28 discriminator 4
	leaq	.LC218(%rip), %r14
	leaq	.LC6(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1562:
.LBE443:
.LBE441:
	.loc 2 2208 4 discriminator 16
	movq	%rbx, %rax
.LBE440:
.LBE435:
	.loc 2 2208 4 is_stmt 0
	addq	$160, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE129:
	.size	silver_output_profile__read_body, .-silver_output_profile__read_body
	.align 2
	.type	silver_output_profile__read_body___wrapped_statements.40, @function
silver_output_profile__read_body___wrapped_statements.40:
.LFB131:
	.loc 2 2208 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%r10, %rbx
	movq	%r10, -72(%rbp)
	movq	%rsp, %rax
	movq	%rax, %r13
	.loc 2 2211 7
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, -36(%rbp)
	movl	-36(%rbp), %eax
	cltq
	movq	%rax, -48(%rbp)
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	leaq	36(%rax), %r12
	.loc 2 2211 51
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	16(%rbx), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__statement_body
	movq	%rax, %rcx
	.loc 2 2211 51 is_stmt 0 discriminator 1
	movl	(%rcx), %edx
	.loc 2 2211 51 discriminator 2
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1564
	.loc 2 2211 51 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2211, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1564:
	.loc 2 2211 7 is_stmt 1 discriminator 4
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	leaq	36(%rax), %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %edi
	movl	$0, %edx
	divq	%rdi
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	addq	$3, %rax
	shrq	$2, %rax
	salq	$2, %rax
	movq	%rax, -56(%rbp)
	.loc 2 2211 7 is_stmt 0 discriminator 5
	movq	-56(%rbp), %rax
	movq	%r12, %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 2213 26 is_stmt 1
	movq	-56(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 2213 7
	testl	%eax, %eax
	jne	.L1565
	.loc 2 2213 42 discriminator 1
	movq	-56(%rbp), %rax
	movq	%rax, %rdi
	call	silver_output_profile__invalid_body
	.loc 2 2213 35 discriminator 2
	jmp	.L1566
.L1565:
	.loc 2 2214 14
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movzbl	28(%rbx), %ecx
	movzbl	%cl, %edi
	movq	-56(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__body_tail
	.loc 2 2214 7 discriminator 1
	nop
.L1566:
	.loc 2 2215 8
	movq	%r13, %rsp
	leaq	-24(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE131:
	.size	silver_output_profile__read_body___wrapped_statements.40, .-silver_output_profile__read_body___wrapped_statements.40
	.section	.rodata
	.align 8
.LC219:
	.ascii	"failed precondition from silver_output_profile.adb:2111"
	.align 8
.LC220:
	.ascii	"failed precondition from silver_output_profile.adb:2112"
	.align 8
.LC221:
	.ascii	"failed postcondition from silver_output_profile.adb:2113"
	.align 8
.LC222:
	.ascii	"failed postcondition from silver_output_profile.adb:2114"
	.text
	.align 2
	.globl	silver_output_profile__statement_body
	.type	silver_output_profile__statement_body, @function
silver_output_profile__statement_body:
.LFB132:
	.loc 2 2217 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$152, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -112(%rbp)
	movq	%rdi, -104(%rbp)
	movq	%rdx, -120(%rbp)
	movq	%rcx, -128(%rbp)
	.loc 2 2217 4
	leaq	16(%rbp), %rdx
	.loc 2 2217 4 is_stmt 0 discriminator 1
	leaq	-112(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -88(%rbp)
	movq	-120(%rbp), %rax
	movq	%rax, -96(%rbp)
	movq	-128(%rbp), %rax
	movq	%rax, -80(%rbp)
	movq	-104(%rbp), %rax
	movl	(%rax), %r8d
	movq	-104(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -132(%rbp)
	movq	-104(%rbp), %rax
	movl	4(%rax), %edx
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L1569
	.loc 2 2217 4 discriminator 2
	movq	-104(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L1570
.L1569:
	.loc 2 2217 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L1570:
.LBB444:
	.loc 2 2111 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L1571
.LBB445:
	.loc 2 2111 15 is_stmt 0 discriminator 1
	leaq	.LC219(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1571:
.LBE445:
	.loc 2 2111 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 2111 15 discriminator 2
	testl	%eax, %eax
	jle	.L1572
	.loc 2 2111 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L1573
.L1572:
.LBB446:
	.loc 2 2111 15 discriminator 4
	leaq	.LC219(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1573:
.LBE446:
	.loc 2 2112 19
	movq	-96(%rbp), %rdx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_context
	.loc 2 2112 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 2111 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L1574
.LBB447:
	.loc 2 2111 15 is_stmt 0 discriminator 6
	leaq	.LC220(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1574:
.LBE447:
	.loc 2 2112 58 is_stmt 1 discriminator 2
	movq	-96(%rbp), %rdx
	movq	-80(%rbp), %rcx
	movq	-112(%rbp), %rsi
	movq	-104(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_body
	.loc 2 2112 58 is_stmt 0 discriminator 3
	xorl	$1, %eax
	.loc 2 2111 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L1575
.LBB448:
	.loc 2 2111 15 is_stmt 0 discriminator 8
	leaq	.LC220(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1575:
.LBE448:
	.loc 2 2116 55 is_stmt 1
	cmpl	$2147483647, -132(%rbp)
	jne	.L1576
	.loc 2 2116 55 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$2116, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1576:
	.loc 2 2116 55 discriminator 3
	movl	-132(%rbp), %eax
	addl	$1, %eax
	.loc 2 2116 60 is_stmt 1 discriminator 4
	movq	-80(%rbp), %rdx
	movl	4(%rdx), %edx
	movl	$0, %ecx
	subl	%edx, %eax
	jno	.L1577
	movl	$1, %ecx
.L1577:
	movl	%eax, %edx
	.loc 2 2116 60 is_stmt 0 discriminator 5
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L1579
	.loc 2 2116 60 discriminator 6
	leaq	.LC12(%rip), %rax
	movl	$2116, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1579:
	.loc 2 2116 60 discriminator 8
	movl	%edx, %eax
	movl	%eax, -72(%rbp)
.LBB449:
	.loc 2 2217 4 is_stmt 1 discriminator 5
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__statement_body___wrapped_statements.41
	movq	%rax, %rbx
.LBB450:
	.loc 2 2113 16
	movq	-96(%rbp), %rdx
	movq	-112(%rbp), %rsi
	movq	-104(%rbp), %rax
	movq	%rbx, %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_body
	.loc 2 2113 16 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L1580
.LBB451:
	.loc 2 2113 16 discriminator 2
	leaq	.LC221(%rip), %r14
	leaq	.LC6(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1580:
.LBE451:
	.loc 2 2114 51 is_stmt 1
	movl	4(%rbx), %eax
	.loc 2 2113 16 discriminator 3
	testl	%eax, %eax
	je	.L1582
	.loc 2 2115 51
	movl	4(%rbx), %edx
	movq	-80(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 2115 12
	cmpl	%eax, %edx
	jg	.L1582
.LBB452:
	.loc 2 2113 16 discriminator 4
	leaq	.LC222(%rip), %r12
	leaq	.LC6(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1582:
.LBE452:
.LBE450:
	.loc 2 2217 4 discriminator 8
	movq	%rbx, %rax
.LBE449:
.LBE444:
	.loc 2 2217 4 is_stmt 0
	addq	$152, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE132:
	.size	silver_output_profile__statement_body, .-silver_output_profile__statement_body
	.align 2
	.type	silver_output_profile__statement_body___wrapped_statements.41, @function
silver_output_profile__statement_body___wrapped_statements.41:
.LFB134:
	.loc 2 2217 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%r10, %rbx
	movq	%r10, -24(%rbp)
	.loc 2 2219 24
	movq	16(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 2219 7
	testl	%eax, %eax
	jne	.L1584
	.loc 2 2219 33 discriminator 1
	movq	16(%rbx), %rax
	movq	%rax, %rdi
	call	silver_output_profile__invalid_body
	.loc 2 2219 33 is_stmt 0 discriminator 2
	jmp	.L1585
.L1584:
	.loc 2 2220 13 is_stmt 1
	movq	16(%rbx), %rax
	movl	4(%rax), %edx
	movq	8(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$22, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 2220 7 discriminator 1
	testl	%eax, %eax
	je	.L1586
	.loc 2 2221 12
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	16(%rbx), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__conditional_body
	.loc 2 2221 12 is_stmt 0 discriminator 1
	jmp	.L1585
.L1586:
	.loc 2 2222 13 is_stmt 1
	movq	16(%rbx), %rax
	movl	4(%rax), %edx
	movq	8(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$53, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 2222 7 discriminator 1
	testl	%eax, %eax
	je	.L1587
	.loc 2 2223 12
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	16(%rbx), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__loop_body
	.loc 2 2223 12 is_stmt 0 discriminator 1
	jmp	.L1585
.L1587:
	.loc 2 2223 49 is_stmt 1 discriminator 2
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	16(%rbx), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__basic_body
.L1585:
	.loc 2 2217 4
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE134:
	.size	silver_output_profile__statement_body___wrapped_statements.41, .-silver_output_profile__statement_body___wrapped_statements.41
	.section	.rodata
	.align 8
.LC223:
	.ascii	"failed precondition from silver_output_profile.adb:2120"
	.align 8
.LC224:
	.ascii	"failed precondition from silver_output_profile.adb:2121"
	.align 8
.LC225:
	.ascii	"failed postcondition from silver_output_profile.adb:2122"
	.align 8
.LC226:
	.ascii	"failed postcondition from silver_output_profile.adb:2123"
	.text
	.align 2
	.globl	silver_output_profile__loop_body
	.type	silver_output_profile__loop_body, @function
silver_output_profile__loop_body:
.LFB135:
	.loc 2 2225 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$144, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movq	%rdx, -104(%rbp)
	movq	%rcx, -112(%rbp)
	.loc 2 2225 4
	leaq	16(%rbp), %rdx
	.loc 2 2225 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -48(%rbp)
	movq	%rax, -72(%rbp)
	movq	-104(%rbp), %rax
	movq	%rax, -80(%rbp)
	movq	-112(%rbp), %rax
	movq	%rax, -64(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %r8d
	movq	-88(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%r8d, %r12d
	jl	.L1589
	.loc 2 2225 4 discriminator 2
	movslq	%r12d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r8d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L1590
.L1589:
	.loc 2 2225 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L1590:
.LBB453:
	.loc 2 2225 4 discriminator 4
	cmpl	%r8d, %r12d
	.loc 2 2225 4 discriminator 7
	cmpl	%r8d, %r12d
	.loc 2 2225 4 discriminator 10
	cmpl	%r8d, %r12d
	.loc 2 2120 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L1597
.LBB454:
	.loc 2 2120 15 is_stmt 0 discriminator 1
	leaq	.LC223(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1597:
.LBE454:
	.loc 2 2120 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 2120 15 discriminator 2
	testl	%eax, %eax
	jle	.L1598
	.loc 2 2120 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L1599
.L1598:
.LBB455:
	.loc 2 2120 15 discriminator 4
	leaq	.LC223(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1599:
.LBE455:
	.loc 2 2121 19
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_context
	.loc 2 2121 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 2120 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L1600
.LBB456:
	.loc 2 2120 15 is_stmt 0 discriminator 6
	leaq	.LC224(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1600:
.LBE456:
	.loc 2 2121 58 is_stmt 1 discriminator 2
	movq	-80(%rbp), %rdx
	movq	-64(%rbp), %rcx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_body
	.loc 2 2121 58 is_stmt 0 discriminator 3
	xorl	$1, %eax
	.loc 2 2120 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L1601
.LBB457:
	.loc 2 2120 15 is_stmt 0 discriminator 8
	leaq	.LC224(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1601:
.LBE457:
	.loc 2 2125 55 is_stmt 1
	cmpl	$2147483647, %r12d
	jne	.L1602
	.loc 2 2125 55 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$2125, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1602:
	.loc 2 2125 55 discriminator 3
	leal	1(%r12), %eax
	.loc 2 2125 60 is_stmt 1 discriminator 4
	movq	-64(%rbp), %rdx
	movl	4(%rdx), %edx
	movl	$0, %ecx
	subl	%edx, %eax
	jno	.L1603
	movl	$1, %ecx
.L1603:
	movl	%eax, %edx
	.loc 2 2125 60 is_stmt 0 discriminator 5
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L1605
	.loc 2 2125 60 discriminator 6
	leaq	.LC12(%rip), %rax
	movl	$2125, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1605:
	.loc 2 2125 60 discriminator 8
	movl	%edx, %eax
	movl	%eax, -56(%rbp)
.LBB458:
	.loc 2 2225 4 is_stmt 1 discriminator 13
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__loop_body___wrapped_statements.42
	movq	%rax, %rbx
.LBB459:
	.loc 2 2122 16
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rbx, %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_body
	.loc 2 2122 16 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L1606
.LBB460:
	.loc 2 2122 16 discriminator 2
	leaq	.LC225(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1606:
.LBE460:
	.loc 2 2123 46 is_stmt 1
	movl	4(%rbx), %eax
	.loc 2 2122 16 discriminator 3
	testl	%eax, %eax
	je	.L1608
	.loc 2 2124 46
	movl	4(%rbx), %edx
	movq	-64(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 2124 12
	cmpl	%eax, %edx
	jg	.L1608
.LBB461:
	.loc 2 2122 16 discriminator 4
	leaq	.LC226(%rip), %r14
	leaq	.LC6(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1608:
.LBE461:
.LBE459:
	.loc 2 2225 4 discriminator 16
	movq	%rbx, %rax
.LBE458:
.LBE453:
	.loc 2 2225 4 is_stmt 0
	addq	$144, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE135:
	.size	silver_output_profile__loop_body, .-silver_output_profile__loop_body
	.section	.rodata
.LC227:
	.ascii	"string"
.LC228:
	.ascii	"silver_arguments"
	.align 8
.LC9:
	.long	1
	.long	6
	.align 8
.LC10:
	.long	1
	.long	16
	.text
	.align 2
	.type	silver_output_profile__loop_body___wrapped_statements.42, @function
silver_output_profile__loop_body___wrapped_statements.42:
.LFB137:
	.loc 2 2225 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$28920, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -17976(%rbp)
	movq	%rsp, %rax
	movq	%rax, -28944(%rbp)
	.loc 2 2227 7
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, -56(%rbp)
	movl	-56(%rbp), %eax
	cltq
	movq	%rax, -64(%rbp)
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$2, %rax
	salq	$3, %rax
	movq	%rax, -28936(%rbp)
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	addq	$36, %rax
	movq	%rax, -28920(%rbp)
	.loc 2 2227 42
	movq	8(%rbx), %rax
	movq	(%rbx), %rsi
	movq	16(%rbx), %rdx
	movq	(%rax), %rdi
	movq	8(%rax), %rax
	movl	$53, %r8d
	movq	%rdx, %rcx
	movq	%rsi, %rdx
	movq	%rax, %rsi
	call	silver_output_profile__body_token
	movq	%rax, %rcx
	.loc 2 2227 42 is_stmt 0 discriminator 1
	movl	(%rcx), %edx
	.loc 2 2227 42 discriminator 2
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1610
	.loc 2 2227 42 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2227, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1610:
	.loc 2 2227 7 is_stmt 1 discriminator 4
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	leaq	36(%rax), %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %edi
	movl	$0, %edx
	divq	%rdi
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	addq	$3, %rax
	shrq	$2, %rax
	salq	$2, %rax
	movq	%rax, -72(%rbp)
	.loc 2 2227 7 is_stmt 0 discriminator 5
	movq	-72(%rbp), %rax
	movq	-28920(%rbp), %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 2228 44 is_stmt 1
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	8(%rbx), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__skip_at
	.loc 2 2228 44 is_stmt 0 discriminator 1
	movl	%eax, -76(%rbp)
	.loc 2 2229 44 is_stmt 1
	movq	8(%rbx), %rax
	movl	-76(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__name_after
	.loc 2 2229 44 is_stmt 0 discriminator 1
	movl	%eax, -80(%rbp)
	.loc 2 2234 7 is_stmt 1
	cmpl	$0, -76(%rbp)
	je	.L1611
	.loc 2 2234 20 discriminator 1
	movl	-80(%rbp), %eax
	cmpl	-76(%rbp), %eax
	jle	.L1611
	.loc 2 2235 40
	cmpl	$0, -76(%rbp)
	jle	.L1612
	.loc 2 2235 40 is_stmt 0 discriminator 1
	cmpl	$4097, -76(%rbp)
	jle	.L1613
.L1612:
	.loc 2 2235 40 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$2235, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L1613:
	.loc 2 2235 47 is_stmt 1 discriminator 3
	cmpl	$0, -80(%rbp)
	jle	.L1614
	.loc 2 2235 47 is_stmt 0 discriminator 4
	cmpl	$4097, -80(%rbp)
	jle	.L1615
.L1614:
	.loc 2 2235 47 discriminator 5
	leaq	.LC12(%rip), %rax
	movl	$2235, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L1615:
	.loc 2 2235 18 is_stmt 1 discriminator 6
	movq	8(%rbx), %rax
	movl	-80(%rbp), %ecx
	movl	-76(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__forbidden_name@PLT
	.loc 2 2235 9 discriminator 7
	testb	%al, %al
	je	.L1616
	.loc 2 2236 39
	cmpl	$0, -76(%rbp)
	jle	.L1617
	.loc 2 2236 39 is_stmt 0 discriminator 1
	cmpl	$4097, -76(%rbp)
	jle	.L1618
.L1617:
	.loc 2 2236 39 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$2236, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L1618:
	.loc 2 2236 46 is_stmt 1 discriminator 3
	cmpl	$0, -80(%rbp)
	jle	.L1619
	.loc 2 2236 46 is_stmt 0 discriminator 4
	cmpl	$4097, -80(%rbp)
	jle	.L1620
.L1619:
	.loc 2 2236 46 discriminator 5
	leaq	.LC12(%rip), %rax
	movl	$2236, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L1620:
	.loc 2 2236 24 is_stmt 1 discriminator 6
	leaq	.LC227(%rip), %r14
	leaq	.LC9(%rip), %r15
	movq	8(%rbx), %rax
	movl	-80(%rbp), %ecx
	movl	-76(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%r14, %r8
	movq	%r15, %r9
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__name_is@PLT
	.loc 2 2236 20 discriminator 7
	xorl	$1, %eax
	.loc 2 2236 11 discriminator 7
	testb	%al, %al
	jne	.L1611
.L1616:
	.loc 2 2237 40
	movq	(%rbx), %rax
	movl	17744(%rax), %eax
	.loc 2 2237 9
	testl	%eax, %eax
	je	.L1621
	.loc 2 2238 35
	cmpl	$0, -76(%rbp)
	jle	.L1622
	.loc 2 2238 35 is_stmt 0 discriminator 1
	cmpl	$4097, -76(%rbp)
	jle	.L1623
.L1622:
	.loc 2 2238 35 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$2238, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L1623:
	.loc 2 2238 42 is_stmt 1 discriminator 3
	cmpl	$0, -80(%rbp)
	jle	.L1624
	.loc 2 2238 42 is_stmt 0 discriminator 4
	cmpl	$4097, -80(%rbp)
	jle	.L1625
.L1624:
	.loc 2 2238 42 discriminator 5
	leaq	.LC12(%rip), %rax
	movl	$2238, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L1625:
	.loc 2 2238 20 is_stmt 1 discriminator 6
	leaq	.LC228(%rip), %r12
	leaq	.LC10(%rip), %r13
	movq	8(%rbx), %rax
	movl	-80(%rbp), %ecx
	movl	-76(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%r12, %r8
	movq	%r13, %r9
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__name_is@PLT
	.loc 2 2238 11 discriminator 7
	testb	%al, %al
	jne	.L1611
.L1621:
	.loc 2 2239 44
	movq	(%rbx), %rax
	movl	6824(%rax), %eax
	.loc 2 2239 9
	cmpl	$341, %eax
	jne	.L1626
.L1611:
	.loc 2 2240 19
	movq	16(%rbx), %rax
	movq	%rax, %rdi
	call	silver_output_profile__invalid_body
	.loc 2 2240 12 discriminator 1
	jmp	.L1627
.L1626:
	.loc 2 2241 26
	movq	8(%rbx), %rax
	movl	-80(%rbp), %edx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$54, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 2241 23 discriminator 1
	movq	-72(%rbp), %rdx
	movl	%eax, 4(%rdx)
	.loc 2 2242 10
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	8(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$55, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 2242 7 discriminator 1
	testl	%eax, %eax
	je	.L1628
	.loc 2 2243 29
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	8(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$55, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 2243 26 discriminator 1
	movq	-72(%rbp), %rdx
	movl	%eax, 4(%rdx)
.L1628:
	.loc 2 2246 14
	movq	16(%rbx), %rax
	leaq	20(%rax), %r9
	movq	-72(%rbp), %rax
	movl	4(%rax), %r8d
	movq	8(%rbx), %rax
	movq	(%rbx), %rcx
	leaq	-128(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movl	-80(%rbp), %esi
	pushq	%rsi
	movl	-76(%rbp), %esi
	pushq	%rsi
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__read_scalar_in_flow
	addq	$16, %rsp
	.loc 2 2247 26
	movl	-128(%rbp), %edx
	movq	8(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$57, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 2247 23 discriminator 1
	movq	-72(%rbp), %rdx
	movl	%eax, 4(%rdx)
	.loc 2 2248 15
	movq	16(%rbx), %rax
	leaq	20(%rax), %r9
	movq	-72(%rbp), %rax
	movl	4(%rax), %r8d
	movq	8(%rbx), %rax
	movq	(%rbx), %rcx
	leaq	-160(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movl	-80(%rbp), %esi
	pushq	%rsi
	movl	-76(%rbp), %esi
	pushq	%rsi
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__read_scalar_in_flow
	addq	$16, %rsp
	.loc 2 2249 26
	movl	-160(%rbp), %edx
	movq	8(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$56, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 2249 23 discriminator 1
	movq	-72(%rbp), %rdx
	movl	%eax, 4(%rdx)
	.loc 2 2250 26
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	16(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 2250 7
	cmpl	%eax, %edx
	jg	.L1629
	.loc 2 2250 55 discriminator 1
	movq	16(%rbx), %rax
	movq	%rax, %rdi
	call	silver_output_profile__invalid_body
	.loc 2 2250 48 discriminator 2
	jmp	.L1627
.L1629:
	.loc 2 2252 20
	movq	-124(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty@PLT
	.loc 2 2252 20 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 2252 10 is_stmt 1 discriminator 1
	testb	%al, %al
	je	.L1630
	.loc 2 2252 58 discriminator 2
	movq	-156(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty@PLT
	.loc 2 2252 58 is_stmt 0 discriminator 3
	xorl	$1, %eax
	.loc 2 2252 43 is_stmt 1 discriminator 3
	testb	%al, %al
	je	.L1630
	.loc 2 2253 41
	movl	-124(%rbp), %eax
	movl	%eax, %edx
	movabsq	$-4294967296, %rax
	andq	-28952(%rbp), %rax
	orq	%rdx, %rax
	movq	%rax, %rdi
	movl	-152(%rbp), %eax
	movl	%eax, %eax
	salq	$32, %rax
	movl	%edi, %edx
	orq	%rdx, %rax
	movq	%rax, %rdi
	call	silver_scalars__normalize@PLT
	movq	%rax, -176(%rbp)
	.loc 2 2253 41 is_stmt 0 discriminator 1
	leaq	-176(%rbp), %rax
	.loc 2 2252 10 is_stmt 1 discriminator 4
	movq	(%rax), %rax
	movq	%rax, -28928(%rbp)
	.loc 2 2252 10 is_stmt 0 discriminator 5
	jmp	.L1631
.L1630:
	.loc 2 2252 10 discriminator 6
	movabsq	$-4294967296, %rax
	andq	-28928(%rbp), %rax
	orq	$1, %rax
	movl	%eax, %eax
	movq	%rax, -28928(%rbp)
.L1631:
	.loc 2 2251 20 is_stmt 1
	movq	-28928(%rbp), %rax
	movq	%rax, -168(%rbp)
	.loc 2 2254 30
	movq	-124(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty@PLT
	.loc 2 2254 19 discriminator 1
	xorl	$1, %eax
	.loc 2 2255 9
	testb	%al, %al
	je	.L1632
	.loc 2 2254 73 discriminator 2
	movq	-156(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty@PLT
	.loc 2 2254 62 discriminator 3
	xorl	$1, %eax
	.loc 2 2254 53 discriminator 3
	testb	%al, %al
	je	.L1632
	.loc 2 2255 35 discriminator 1
	movl	-120(%rbp), %edx
	movl	-156(%rbp), %eax
	.loc 2 2255 9 discriminator 1
	cmpl	%eax, %edx
	jg	.L1632
	.loc 2 2255 9 is_stmt 0 discriminator 2
	movl	$1, %eax
	jmp	.L1633
.L1632:
	.loc 2 2255 9 discriminator 3
	movl	$0, %eax
.L1633:
	.loc 2 2254 16 is_stmt 1 discriminator 4
	movb	%al, -81(%rbp)
	.loc 2 2256 7
	movq	-72(%rbp), %rax
	leaq	20(%rax), %rdx
	movq	(%rbx), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__widen_into
.LBB462:
	.loc 2 2257 7
	movq	%rsp, %rax
	movq	%rax, %r13
	.loc 2 2258 10
	movq	(%rbx), %rdx
	leaq	-17936(%rbp), %rax
	movq	%rdx, %rcx
	movl	$17752, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 2259 45
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cmpl	$-1, %eax
	jl	.L1634
	.loc 2 2259 45 is_stmt 0 discriminator 1
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cmpl	$340, %eax
	jle	.L1635
.L1634:
	.loc 2 2259 45 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$2259, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L1635:
	.loc 2 2259 45 discriminator 3
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	.loc 2 2259 10 is_stmt 1 discriminator 3
	addl	$1, %eax
	movl	%eax, -88(%rbp)
	movl	-88(%rbp), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	cltq
	movq	%rax, -96(%rbp)
	.loc 2 2259 45 discriminator 3
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	addl	$1, %eax
	.loc 2 2259 10 discriminator 3
	cltq
	salq	$3, %rax
	leaq	36(%rax), %r12
	.loc 2 2259 45 discriminator 3
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	addl	$1, %eax
	.loc 2 2259 10 discriminator 3
	cltq
	salq	$3, %rax
	leaq	36(%rax), %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %edi
	movl	$0, %edx
	divq	%rdi
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	addq	$3, %rax
	shrq	$2, %rax
	salq	$2, %rax
	movq	%rax, -104(%rbp)
	.loc 2 2259 45 discriminator 4
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L1636
	.loc 2 2259 45 is_stmt 0 discriminator 5
	cmpl	$341, %eax
	jle	.L1637
.L1636:
	.loc 2 2259 45 discriminator 6
	leaq	.LC12(%rip), %rax
	movl	$2259, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L1637:
	.loc 2 2259 10 is_stmt 1 discriminator 7
	movq	-104(%rbp), %rdx
	movl	%eax, %esi
	movq	%rdx, %rdi
	call	silver_output_profile__body_scanIP
.LBB463:
	.loc 2 2262 35
	movl	-76(%rbp), %eax
	movl	%eax, -17968(%rbp)
	movl	-80(%rbp), %eax
	movl	%eax, -17964(%rbp)
	movq	-168(%rbp), %rax
	movq	%rax, -17960(%rbp)
	movb	$0, -17952(%rbp)
	movq	-168(%rbp), %rax
	movq	%rax, -17948(%rbp)
	movb	$0, -17940(%rbp)
	.loc 2 2261 50
	movq	(%rbx), %rax
	leaq	6824(%rax), %rcx
	leaq	-28912(%rbp), %rax
	leaq	-17968(%rbp), %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	silver_scalar_expressions__append@PLT
	leaq	-11112(%rbp), %rax
	leaq	-28912(%rbp), %rcx
	movl	$10916, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
.LBE463:
	.loc 2 2263 30
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	-104(%rbp), %rax
	movl	%edx, 4(%rax)
	.loc 2 2264 28
	movq	-72(%rbp), %rax
	movl	8(%rax), %edx
	movq	-104(%rbp), %rax
	movl	%edx, 8(%rax)
	.loc 2 2265 30
	movq	-72(%rbp), %rax
	movl	12(%rax), %edx
	movq	-104(%rbp), %rax
	movl	%edx, 12(%rax)
	.loc 2 2266 30
	movq	-72(%rbp), %rax
	movzbl	16(%rax), %edx
	movq	-104(%rbp), %rax
	movb	%dl, 16(%rax)
	.loc 2 2267 28
	movq	-72(%rbp), %rax
	movzbl	17(%rax), %edx
	movq	-104(%rbp), %rax
	movb	%dl, 17(%rax)
	.loc 2 2269 23
	movq	-168(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty@PLT
	.loc 2 2269 13 discriminator 1
	testb	%al, %al
	je	.L1638
	.loc 2 2268 32
	movq	-104(%rbp), %rax
	movl	$0, 24(%rax)
	movq	-104(%rbp), %rax
	movl	$0, 28(%rax)
	movq	-104(%rbp), %rax
	movb	$0, 32(%rax)
	movq	-104(%rbp), %rax
	movb	$0, 33(%rax)
	movq	-104(%rbp), %rax
	movb	$1, 34(%rax)
	jmp	.L1639
.L1638:
	.loc 2 2268 32 is_stmt 0 discriminator 1
	movq	-104(%rbp), %rax
	movq	-72(%rbp), %rdx
	movq	24(%rdx), %rcx
	movq	%rcx, 24(%rax)
	movl	32(%rdx), %edx
	movl	%edx, 32(%rax)
.L1639:
	.loc 2 2270 37 is_stmt 1
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	testl	%eax, %eax
	.loc 2 2270 37 is_stmt 0 discriminator 3
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	testl	%eax, %eax
	.loc 2 2270 37 discriminator 6
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	testl	%eax, %eax
	.loc 2 2259 45 is_stmt 1 discriminator 12
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	addl	$1, %eax
	.loc 2 2270 37 discriminator 9
	cmpl	%eax, -88(%rbp)
	je	.L1646
	.loc 2 2270 37 is_stmt 0 discriminator 10
	leaq	.LC12(%rip), %rax
	movl	$2270, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Length_Check@PLT
.L1646:
	.loc 2 2259 45 is_stmt 1 discriminator 13
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	.loc 2 2270 37 discriminator 11
	leal	1(%rax), %edx
	testl	%edx, %edx
	jle	.L1647
.LBB464:
	.loc 2 2270 37 is_stmt 0 discriminator 12
	movl	$1, %eax
.L1648:
	.loc 2 2270 37 discriminator 13
	movslq	%eax, %rcx
	movq	-104(%rbp), %rsi
	leaq	3(%rcx), %rdi
	movl	$1, 4(%rsi,%rdi,8)
	.loc 2 2270 37 discriminator 14
	movq	-104(%rbp), %rsi
	addq	$3, %rcx
	movl	$0, 8(%rsi,%rcx,8)
	.loc 2 2270 37 discriminator 15
	cmpl	%edx, %eax
	je	.L1647
	.loc 2 2270 37 discriminator 16
	addl	$1, %eax
	jmp	.L1648
.L1647:
.LBE464:
	.loc 2 2271 42 is_stmt 1
	movl	-56(%rbp), %eax
	movl	%eax, -108(%rbp)
	.loc 2 2271 14
	cmpl	$0, -108(%rbp)
	jle	.L1649
.LBB465:
	.loc 2 2271 14 is_stmt 0 discriminator 1
	movl	$1, -52(%rbp)
.L1652:
.LBB466:
	.loc 2 2275 29 is_stmt 1
	movl	-88(%rbp), %eax
	cmpl	%eax, -52(%rbp)
	jle	.L1650
	.loc 2 2275 29 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$2275, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1650:
	.loc 2 2275 60 is_stmt 1 discriminator 2
	movl	-56(%rbp), %eax
	cmpl	%eax, -52(%rbp)
	jle	.L1651
	.loc 2 2275 60 is_stmt 0 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2275, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1651:
	.loc 2 2275 45 is_stmt 1 discriminator 4
	movl	-52(%rbp), %eax
	movslq	%eax, %rsi
	movl	-52(%rbp), %eax
	movslq	%eax, %rdx
	movq	-104(%rbp), %rax
	leaq	3(%rdx), %rcx
	movq	-72(%rbp), %rdx
	addq	$3, %rsi
	movq	4(%rdx,%rsi,8), %rdx
	movq	%rdx, 4(%rax,%rcx,8)
.LBE466:
	.loc 2 2271 14 discriminator 2
	movl	-52(%rbp), %eax
	cmpl	-108(%rbp), %eax
	je	.L1649
	.loc 2 2271 14 is_stmt 0 discriminator 3
	addl	$1, -52(%rbp)
	.loc 2 2276 18 is_stmt 1
	jmp	.L1652
.L1649:
.LBE465:
	.loc 2 2277 45
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 2277 26
	movl	-88(%rbp), %edx
	testl	%eax, %eax
	jle	.L1653
	.loc 2 2277 26 is_stmt 0 discriminator 1
	cmpl	%edx, %eax
	jle	.L1654
.L1653:
	.loc 2 2277 26 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$2277, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1654:
	.loc 2 2277 53 is_stmt 1 discriminator 3
	movslq	%eax, %rdx
	movq	-104(%rbp), %rax
	leaq	3(%rdx), %rcx
	movq	-168(%rbp), %rdx
	movq	%rdx, 4(%rax,%rcx,8)
.LBB467:
	.loc 2 2278 24
	movq	8(%rbx), %rax
	movq	-104(%rbp), %rcx
	leaq	-17936(%rbp), %rdx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$0, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__read_body
	.loc 2 2278 24 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2259 45 is_stmt 1 discriminator 14
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	addl	$1, %edx
	.loc 2 2278 24 discriminator 2
	cmpl	%edx, %ecx
	je	.L1655
	.loc 2 2278 24 is_stmt 0 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2278, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1655:
	.loc 2 2278 21 is_stmt 1 discriminator 4
	movq	-104(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE467:
	.loc 2 2279 33
	movq	-104(%rbp), %rax
	movl	4(%rax), %edx
	movq	16(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 2279 10
	cmpl	%eax, %edx
	jg	.L1656
	.loc 2 2279 62 discriminator 1
	movq	16(%rbx), %rax
	movq	%rax, %rdi
	call	silver_output_profile__invalid_body
	.loc 2 2293 10 discriminator 1
	movq	%r13, %rsp
	jmp	.L1627
.L1656:
	.loc 2 2280 26
	movq	-104(%rbp), %rax
	movl	4(%rax), %edx
	movq	-72(%rbp), %rax
	movl	%edx, 4(%rax)
	.loc 2 2281 24
	movq	-104(%rbp), %rax
	movl	8(%rax), %edx
	movq	-72(%rbp), %rax
	movl	%edx, 8(%rax)
	.loc 2 2282 26
	movq	-104(%rbp), %rax
	movl	12(%rax), %edx
	movq	-72(%rbp), %rax
	movl	%edx, 12(%rax)
	.loc 2 2283 26
	movq	-104(%rbp), %rax
	movzbl	16(%rax), %edx
	movq	-72(%rbp), %rax
	movb	%dl, 16(%rax)
	.loc 2 2284 24
	movq	-104(%rbp), %rax
	movzbl	17(%rax), %edx
	movq	-72(%rbp), %rax
	movb	%dl, 17(%rax)
	.loc 2 2285 20
	movq	-168(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty@PLT
	.loc 2 2285 10 discriminator 1
	testb	%al, %al
	je	.L1657
	.loc 2 2286 33
	movq	16(%rbx), %rax
	movl	20(%rax), %edx
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1658
	.loc 2 2286 33 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$2286, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1658:
	.loc 2 2286 26 is_stmt 1 discriminator 2
	movq	16(%rbx), %rax
	leaq	20(%rax), %rdx
	movq	-72(%rbp), %rax
	addq	$20, %rax
	movq	%rdx, %rcx
	movq	-28936(%rbp), %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	jmp	.L1659
.L1657:
	.loc 2 2287 10
	cmpb	$0, -81(%rbp)
	je	.L1660
	.loc 2 2288 31
	movq	-72(%rbp), %rax
	movq	-104(%rbp), %rdx
	movq	24(%rdx), %rcx
	movq	%rcx, 24(%rax)
	movl	32(%rdx), %edx
	movl	%edx, 32(%rax)
	jmp	.L1659
.L1660:
	.loc 2 2290 39
	movq	16(%rbx), %rcx
	movq	-72(%rbp), %r12
	movq	-104(%rbp), %rsi
	movq	24(%rsi), %rax
	movl	32(%rsi), %esi
	movq	%rsi, %rdx
	movq	24(%rcx), %rdi
	movl	32(%rcx), %esi
	movq	%rdx, %rcx
	movq	%rax, %rdx
	call	silver_path_facts__join@PLT
	movq	%rax, 24(%r12)
	movl	32(%r12), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, 32(%r12)
.L1659:
	.loc 2 2293 10
	movq	%r13, %rsp
.LBE462:
.LBB468:
	.loc 2 2294 17
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$10, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__body_token
	.loc 2 2294 17 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2294 17 discriminator 2
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1661
	.loc 2 2294 17 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2294, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1661:
	.loc 2 2294 14 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	-28920(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE468:
.LBB469:
	.loc 2 2295 17
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$56, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__body_token
	.loc 2 2295 17 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2295 17 discriminator 2
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1662
	.loc 2 2295 17 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2295, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1662:
	.loc 2 2295 14 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	-28920(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE469:
.LBB470:
	.loc 2 2296 17
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$13, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__body_token
	.loc 2 2296 17 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2296 17 discriminator 2
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1663
	.loc 2 2296 17 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2296, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1663:
	.loc 2 2296 14 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	-28920(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE470:
	.loc 2 2297 26
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	16(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 2297 7
	cmpl	%eax, %edx
	jg	.L1664
	.loc 2 2297 55 discriminator 1
	movq	16(%rbx), %rax
	movq	%rax, %rdi
	call	silver_output_profile__invalid_body
	.loc 2 2297 48 discriminator 2
	jmp	.L1627
.L1664:
	.loc 2 2298 7
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	addq	$36, %rax
	movl	$4, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rbx
	.loc 2 2298 7 is_stmt 0 discriminator 1
	movq	%rbx, %rdx
	movq	-72(%rbp), %rax
	movq	%rdx, %rcx
	movq	-28920(%rbp), %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 2298 7 discriminator 2
	movq	%rbx, %rax
.L1627:
	.loc 2 2299 8 is_stmt 1
	movq	-28944(%rbp), %rsp
	leaq	-40(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE137:
	.size	silver_output_profile__loop_body___wrapped_statements.42, .-silver_output_profile__loop_body___wrapped_statements.42
	.section	.rodata
	.align 8
.LC229:
	.ascii	"failed precondition from silver_output_profile.adb:2129"
	.align 8
.LC230:
	.ascii	"failed precondition from silver_output_profile.adb:2130"
	.align 8
.LC231:
	.ascii	"failed postcondition from silver_output_profile.adb:2131"
	.align 8
.LC232:
	.ascii	"failed postcondition from silver_output_profile.adb:2132"
	.text
	.align 2
	.globl	silver_output_profile__conditional_body
	.type	silver_output_profile__conditional_body, @function
silver_output_profile__conditional_body:
.LFB138:
	.loc 2 2301 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$144, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movq	%rdx, -104(%rbp)
	movq	%rcx, -112(%rbp)
	.loc 2 2301 4
	leaq	16(%rbp), %rdx
	.loc 2 2301 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -48(%rbp)
	movq	%rax, -72(%rbp)
	movq	-104(%rbp), %rax
	movq	%rax, -80(%rbp)
	movq	-112(%rbp), %rax
	movq	%rax, -64(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %r8d
	movq	-88(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%r8d, %r12d
	jl	.L1667
	.loc 2 2301 4 discriminator 2
	movslq	%r12d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r8d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L1668
.L1667:
	.loc 2 2301 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L1668:
.LBB471:
	.loc 2 2301 4 discriminator 4
	cmpl	%r8d, %r12d
	.loc 2 2301 4 discriminator 7
	cmpl	%r8d, %r12d
	.loc 2 2301 4 discriminator 10
	cmpl	%r8d, %r12d
	.loc 2 2129 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L1675
.LBB472:
	.loc 2 2129 15 is_stmt 0 discriminator 1
	leaq	.LC229(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1675:
.LBE472:
	.loc 2 2129 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 2129 15 discriminator 2
	testl	%eax, %eax
	jle	.L1676
	.loc 2 2129 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L1677
.L1676:
.LBB473:
	.loc 2 2129 15 discriminator 4
	leaq	.LC229(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1677:
.LBE473:
	.loc 2 2130 19
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_context
	.loc 2 2130 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 2129 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L1678
.LBB474:
	.loc 2 2129 15 is_stmt 0 discriminator 6
	leaq	.LC230(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1678:
.LBE474:
	.loc 2 2130 58 is_stmt 1 discriminator 2
	movq	-80(%rbp), %rdx
	movq	-64(%rbp), %rcx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_body
	.loc 2 2130 58 is_stmt 0 discriminator 3
	xorl	$1, %eax
	.loc 2 2129 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L1679
.LBB475:
	.loc 2 2129 15 is_stmt 0 discriminator 8
	leaq	.LC230(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1679:
.LBE475:
	.loc 2 2134 55 is_stmt 1
	cmpl	$2147483647, %r12d
	jne	.L1680
	.loc 2 2134 55 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$2134, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1680:
	.loc 2 2134 55 discriminator 3
	leal	1(%r12), %eax
	.loc 2 2134 60 is_stmt 1 discriminator 4
	movq	-64(%rbp), %rdx
	movl	4(%rdx), %edx
	movl	$0, %ecx
	subl	%edx, %eax
	jno	.L1681
	movl	$1, %ecx
.L1681:
	movl	%eax, %edx
	.loc 2 2134 60 is_stmt 0 discriminator 5
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L1683
	.loc 2 2134 60 discriminator 6
	leaq	.LC12(%rip), %rax
	movl	$2134, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1683:
	.loc 2 2134 60 discriminator 8
	movl	%edx, %eax
	movl	%eax, -56(%rbp)
.LBB476:
	.loc 2 2301 4 is_stmt 1 discriminator 13
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__conditional_body___wrapped_statements.43
	movq	%rax, %rbx
.LBB477:
	.loc 2 2131 16
	movq	-80(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rbx, %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_body
	.loc 2 2131 16 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L1684
.LBB478:
	.loc 2 2131 16 discriminator 2
	leaq	.LC231(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1684:
.LBE478:
	.loc 2 2132 53 is_stmt 1
	movl	4(%rbx), %eax
	.loc 2 2131 16 discriminator 3
	testl	%eax, %eax
	je	.L1686
	.loc 2 2133 53
	movl	4(%rbx), %edx
	movq	-64(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 2133 12
	cmpl	%eax, %edx
	jg	.L1686
.LBB479:
	.loc 2 2131 16 discriminator 4
	leaq	.LC232(%rip), %r14
	leaq	.LC6(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1686:
.LBE479:
.LBE477:
	.loc 2 2301 4 discriminator 16
	movq	%rbx, %rax
.LBE476:
.LBE471:
	.loc 2 2301 4 is_stmt 0
	addq	$144, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE138:
	.size	silver_output_profile__conditional_body, .-silver_output_profile__conditional_body
	.align 2
	.type	silver_output_profile__conditional_body___wrapped_statements__B2465b___finalizer.44, @function
silver_output_profile__conditional_body___wrapped_statements__B2465b___finalizer.44:
.LFB141:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE141:
	.size	silver_output_profile__conditional_body___wrapped_statements__B2465b___finalizer.44, .-silver_output_profile__conditional_body___wrapped_statements__B2465b___finalizer.44
	.align 2
	.type	silver_output_profile__conditional_body___wrapped_statements.43, @function
silver_output_profile__conditional_body___wrapped_statements.43:
.LFB140:
	.loc 2 2301 4 is_stmt 1
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA140
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB8:
	subq	$168, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -184(%rbp)
	.loc 2 2301 4
	leaq	16(%rbp), %rax
	.loc 2 2301 4 is_stmt 0 discriminator 1
	movq	%rax, -152(%rbp)
	movq	%rsp, %rax
	movq	%rax, -208(%rbp)
	.loc 2 2303 7 is_stmt 1
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, -52(%rbp)
	movl	-52(%rbp), %eax
	cltq
	movq	%rax, -64(%rbp)
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$2, %rax
	leaq	0(,%rax,8), %r14
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	leaq	36(%rax), %r12
	.loc 2 2303 42
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	16(%rbx), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$22, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__body_token
	movq	%rax, %rcx
	.loc 2 2303 42 is_stmt 0 discriminator 1
	movl	(%rcx), %edx
	.loc 2 2303 42 discriminator 2
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1690
	.loc 2 2303 42 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2303, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1690:
	.loc 2 2303 7 is_stmt 1 discriminator 4
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	leaq	36(%rax), %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %edi
	movl	$0, %edx
	divq	%rdi
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	addq	$3, %rax
	shrq	$2, %rax
	salq	$2, %rax
	movq	%rax, -72(%rbp)
	.loc 2 2303 7 is_stmt 0 discriminator 5
	movq	-72(%rbp), %rax
	movq	%r12, %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 2304 7 is_stmt 1
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, -76(%rbp)
	movl	-76(%rbp), %eax
	cltq
	movq	%rax, -88(%rbp)
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, -92(%rbp)
	movl	-92(%rbp), %eax
	cltq
	movq	%rax, -104(%rbp)
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	movq	%rax, -112(%rbp)
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$4, %rax
	leaq	40(%rax), %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %edi
	movl	$0, %edx
	divq	%rdi
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	addq	$3, %rax
	shrq	$2, %rax
	salq	$2, %rax
	movq	%rax, -120(%rbp)
	.loc 2 2304 7 is_stmt 0 discriminator 1
	movq	16(%rbx), %rax
	movl	(%rax), %edx
	movq	-120(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_output_profile__condition_resultIP
	.loc 2 2305 7 is_stmt 1
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, -124(%rbp)
	movl	-124(%rbp), %eax
	cltq
	movq	%rax, -136(%rbp)
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$2, %rax
	salq	$3, %rax
	movq	%rax, -200(%rbp)
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$2, %rax
	leaq	0(,%rax,8), %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %edi
	movl	$0, %edx
	divq	%rdi
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	addq	$3, %rax
	shrq	$2, %rax
	salq	$2, %rax
	movq	%rax, -144(%rbp)
	.loc 2 2305 7 is_stmt 0 discriminator 1
	movq	16(%rbx), %rax
	movl	(%rax), %edx
	movq	-144(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_output_profile__scalar_flowIP
	.loc 2 2307 7 is_stmt 1
	movq	-72(%rbp), %rax
	leaq	20(%rax), %r8
	movq	-72(%rbp), %rax
	movl	4(%rax), %ecx
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	-120(%rbp), %rdi
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rdi, %r9
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__read_condition_into
	.loc 2 2308 23
	movq	-120(%rbp), %rax
	movl	4(%rax), %edx
	movq	-72(%rbp), %rax
	movl	%edx, 4(%rax)
	.loc 2 2309 32
	movq	-120(%rbp), %rax
	movl	8(%rax), %edx
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1691
	.loc 2 2309 32 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$2309, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.LEHE8:
.L1691:
	.loc 2 2309 20 is_stmt 1 discriminator 2
	movq	-120(%rbp), %rax
	leaq	8(%rax), %rdx
	movq	-72(%rbp), %rax
	addq	$20, %rax
	movq	%rdx, %rcx
	movq	%r14, %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	leaq	-176(%rbp), %rax
	movq	%rax, %rdi
.LEHB9:
	call	system__secondary_stack__ss_mark@PLT
.LBB480:
	.loc 2 2310 17
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$24, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__body_token
	.loc 2 2310 17 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2310 17 discriminator 2
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1692
	.loc 2 2310 17 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2310, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.LEHE9:
.L1692:
	.loc 2 2310 14 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 2310 0 discriminator 5
	movl	$1, -188(%rbp)
.L1708:
	.loc 2 2310 0 is_stmt 0 discriminator 6
	leaq	-176(%rbp), %rax
	movq	%rax, %r10
.LEHB10:
	call	silver_output_profile__conditional_body___wrapped_statements__B2465b___finalizer.44
.LEHE10:
	.loc 2 2310 0 discriminator 7
	cmpl	$1, -188(%rbp)
	jne	.L1693
	.loc 2 2310 0 discriminator 9
	movl	$1, %eax
.L1710:
	.loc 2 2310 0 discriminator 10
	cmpl	$1, %eax
	jne	.L1694
	.loc 2 2310 0 discriminator 11
	nop
.LBE480:
	.loc 2 2311 26 is_stmt 1
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	16(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 2311 7
	cmpl	%eax, %edx
	jg	.L1695
	.loc 2 2311 55 discriminator 1
	movq	16(%rbx), %rax
	movq	%rax, %rdi
.LEHB11:
	call	silver_output_profile__invalid_body
	.loc 2 2311 48 discriminator 2
	jmp	.L1696
.L1695:
.LBB481:
	.loc 2 2312 17
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$2, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__read_body
	.loc 2 2312 17 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2312 17 discriminator 2
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1697
	.loc 2 2312 17 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2312, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1697:
	.loc 2 2312 14 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE481:
	.loc 2 2313 26
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	16(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 2313 7
	cmpl	%eax, %edx
	jg	.L1698
	.loc 2 2313 55 discriminator 1
	movq	16(%rbx), %rax
	movq	%rax, %rdi
	call	silver_output_profile__invalid_body
	.loc 2 2313 48 discriminator 2
	jmp	.L1696
.L1698:
	.loc 2 2314 20
	movq	-72(%rbp), %rax
	movl	20(%rax), %edx
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1699
	.loc 2 2314 20 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$2314, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1699:
	.loc 2 2314 11 is_stmt 1 discriminator 2
	movq	-72(%rbp), %rax
	leaq	20(%rax), %rdx
	movq	-144(%rbp), %rax
	movq	%rdx, %rcx
	movq	-200(%rbp), %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 2315 32
	movq	-112(%rbp), %rax
	shrq	$2, %rax
	movq	%rax, %rdx
	movq	-120(%rbp), %rax
	movl	(%rax,%rdx,4), %edx
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1700
	.loc 2 2315 32 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$2315, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1700:
	.loc 2 2315 20 is_stmt 1 discriminator 2
	movq	-112(%rbp), %rax
	shrq	$2, %rax
	leaq	0(,%rax,4), %rdx
	movq	-120(%rbp), %rax
	addq	%rax, %rdx
	movq	-72(%rbp), %rax
	addq	$20, %rax
	movq	%rdx, %rcx
	movq	%r14, %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
.LBB482:
	.loc 2 2316 17
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__alternative_body
	.loc 2 2316 17 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2316 17 discriminator 2
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1701
	.loc 2 2316 17 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2316, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1701:
	.loc 2 2316 14 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE482:
	.loc 2 2317 7
	movq	-72(%rbp), %rax
	leaq	20(%rax), %rdx
	movq	-144(%rbp), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	silver_output_profile__join_into
.LBB483:
	.loc 2 2318 17
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$10, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__body_token
	.loc 2 2318 17 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2318 17 discriminator 2
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1702
	.loc 2 2318 17 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2318, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1702:
	.loc 2 2318 14 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE483:
.LBB484:
	.loc 2 2319 17
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$22, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__body_token
	.loc 2 2319 17 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2319 17 discriminator 2
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1703
	.loc 2 2319 17 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2319, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1703:
	.loc 2 2319 14 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE484:
.LBB485:
	.loc 2 2320 17
	movq	8(%rbx), %rax
	movq	(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$13, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__body_token
	.loc 2 2320 17 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2320 17 discriminator 2
	movq	16(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1704
	.loc 2 2320 17 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2320, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1704:
	.loc 2 2320 14 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE485:
	.loc 2 2321 26
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	16(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 2321 7
	cmpl	%eax, %edx
	jg	.L1705
	.loc 2 2321 55 discriminator 1
	movq	16(%rbx), %rax
	movq	%rax, %rdi
	call	silver_output_profile__invalid_body
	.loc 2 2321 48 discriminator 2
	jmp	.L1696
.L1705:
	.loc 2 2322 7
	movq	16(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	addq	$36, %rax
	movl	$4, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rbx
	.loc 2 2322 7 is_stmt 0 discriminator 1
	movq	%rbx, %rdx
	movq	-72(%rbp), %rax
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 2322 7 discriminator 2
	movq	%rbx, %rax
.L1696:
	.loc 2 2323 8 is_stmt 1
	movq	-208(%rbp), %rsp
	jmp	.L1713
.L1711:
	movq	%rax, %r15
	movl	$0, -188(%rbp)
.LBB486:
	.loc 2 2310 14 discriminator 12
	jmp	.L1708
.L1693:
	movq	%r15, %r13
	jmp	.L1709
.L1712:
	movq	%rax, %r13
.L1709:
	movl	$0, %eax
	jmp	.L1710
.L1694:
	movq	%r13, %rax
	movq	%rax, %rdi
	call	_Unwind_Resume@PLT
.L1713:
.LBE486:
	.loc 2 2323 8
	leaq	-40(%rbp), %rsp
.LEHE11:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE140:
	.section	.gcc_except_table
.LLSDA140:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE140-.LLSDACSB140
.LLSDACSB140:
	.uleb128 .LEHB8-.LFB140
	.uleb128 .LEHE8-.LEHB8
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB9-.LFB140
	.uleb128 .LEHE9-.LEHB9
	.uleb128 .L1711-.LFB140
	.uleb128 0
	.uleb128 .LEHB10-.LFB140
	.uleb128 .LEHE10-.LEHB10
	.uleb128 .L1712-.LFB140
	.uleb128 0
	.uleb128 .LEHB11-.LFB140
	.uleb128 .LEHE11-.LEHB11
	.uleb128 0
	.uleb128 0
.LLSDACSE140:
	.text
	.size	silver_output_profile__conditional_body___wrapped_statements.43, .-silver_output_profile__conditional_body___wrapped_statements.43
	.section	.rodata
	.align 8
.LC233:
	.ascii	"failed precondition from silver_output_profile.adb:2138"
	.align 8
.LC234:
	.ascii	"failed precondition from silver_output_profile.adb:2139"
	.align 8
.LC235:
	.ascii	"failed postcondition from silver_output_profile.adb:2140"
	.align 8
.LC236:
	.ascii	"failed postcondition from silver_output_profile.adb:2141"
	.text
	.align 2
	.type	silver_output_profile__alternative_body, @function
silver_output_profile__alternative_body:
.LFB142:
	.loc 2 2325 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$144, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -96(%rbp)
	movq	%rdi, -88(%rbp)
	movq	%rdx, -104(%rbp)
	movq	%rcx, -112(%rbp)
	.loc 2 2325 4
	leaq	16(%rbp), %rdx
	.loc 2 2325 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -40(%rbp)
	movq	%rax, -64(%rbp)
	movq	-104(%rbp), %rax
	movq	%rax, -72(%rbp)
	movq	-112(%rbp), %rax
	movq	%rax, -56(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %r8d
	movq	-88(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%r8d, %r12d
	jl	.L1715
	.loc 2 2325 4 discriminator 2
	movslq	%r12d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r8d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L1716
.L1715:
	.loc 2 2325 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L1716:
.LBB487:
	.loc 2 2325 4 discriminator 4
	movq	-56(%rbp), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	addq	$36, %rax
	movq	%rax, -80(%rbp)
	cmpl	%r8d, %r12d
	.loc 2 2325 4 discriminator 7
	cmpl	%r8d, %r12d
	.loc 2 2325 4 discriminator 10
	cmpl	%r8d, %r12d
	.loc 2 2138 15 is_stmt 1
	cmpl	$1, %r8d
	je	.L1723
.LBB488:
	.loc 2 2138 15 is_stmt 0 discriminator 1
	leaq	.LC233(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1723:
.LBE488:
	.loc 2 2138 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 2 2138 15 discriminator 2
	testl	%eax, %eax
	jle	.L1724
	.loc 2 2138 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L1725
.L1724:
.LBB489:
	.loc 2 2138 15 discriminator 4
	leaq	.LC233(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1725:
.LBE489:
	.loc 2 2139 19
	movq	-72(%rbp), %rdx
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_context
	.loc 2 2139 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 2138 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L1726
.LBB490:
	.loc 2 2138 15 is_stmt 0 discriminator 6
	leaq	.LC234(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1726:
.LBE490:
	.loc 2 2139 58 is_stmt 1 discriminator 2
	movq	-72(%rbp), %rdx
	movq	-56(%rbp), %rcx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_body
	.loc 2 2139 58 is_stmt 0 discriminator 3
	xorl	$1, %eax
	.loc 2 2138 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L1727
.LBB491:
	.loc 2 2138 15 is_stmt 0 discriminator 8
	leaq	.LC234(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1727:
.LBE491:
	.loc 2 2143 55 is_stmt 1
	cmpl	$2147483647, %r12d
	jne	.L1728
	.loc 2 2143 55 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$2143, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1728:
	.loc 2 2143 55 discriminator 3
	leal	1(%r12), %eax
	.loc 2 2143 60 is_stmt 1 discriminator 4
	movq	-56(%rbp), %rdx
	movl	4(%rdx), %edx
	movl	$0, %ecx
	subl	%edx, %eax
	jno	.L1729
	movl	$1, %ecx
.L1729:
	movl	%eax, %edx
	.loc 2 2143 60 is_stmt 0 discriminator 5
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L1731
	.loc 2 2143 60 discriminator 6
	leaq	.LC12(%rip), %rax
	movl	$2143, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L1731:
	.loc 2 2143 60 discriminator 8
	movl	%edx, %eax
	movl	%eax, -48(%rbp)
.LBB492:
	.loc 2 2325 4 is_stmt 1 discriminator 13
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_profile__alternative_body___wrapped_statements.45
	movq	%rax, %rbx
.LBB493:
	.loc 2 2140 16
	movq	-72(%rbp), %rdx
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rax
	movq	%rbx, %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_body
	.loc 2 2140 16 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L1732
.LBB494:
	.loc 2 2140 16 discriminator 2
	leaq	.LC235(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1732:
.LBE494:
	.loc 2 2141 53 is_stmt 1
	movl	4(%rbx), %eax
	.loc 2 2140 16 discriminator 3
	testl	%eax, %eax
	je	.L1734
	.loc 2 2142 53
	movl	4(%rbx), %edx
	movq	-56(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 2142 12
	cmpl	%eax, %edx
	jge	.L1734
.LBB495:
	.loc 2 2140 16 discriminator 4
	leaq	.LC236(%rip), %r14
	leaq	.LC6(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1734:
.LBE495:
.LBE493:
	.loc 2 2325 4 discriminator 16
	movq	%rbx, %rax
.LBE492:
.LBE487:
	.loc 2 2325 4 is_stmt 0
	addq	$144, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE142:
	.size	silver_output_profile__alternative_body, .-silver_output_profile__alternative_body
	.align 2
	.type	silver_output_profile__alternative_body___wrapped_statements.45, @function
silver_output_profile__alternative_body___wrapped_statements.45:
.LFB144:
	.loc 2 2325 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$120, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -152(%rbp)
	movq	%rsp, %rax
	movq	%rax, %r15
	.loc 2 2327 7
	movq	24(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, -52(%rbp)
	movl	-52(%rbp), %eax
	cltq
	movq	%rax, -64(%rbp)
	movq	24(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$2, %rax
	leaq	0(,%rax,8), %r13
	movq	24(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	leaq	36(%rax), %r12
	movq	24(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	leaq	36(%rax), %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %edi
	movl	$0, %edx
	divq	%rdi
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	addq	$3, %rax
	shrq	$2, %rax
	salq	$2, %rax
	movq	%rax, -72(%rbp)
	.loc 2 2327 7 is_stmt 0 discriminator 1
	movq	24(%rbx), %rax
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 2328 7 is_stmt 1
	movq	24(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, -76(%rbp)
	movl	-76(%rbp), %eax
	cltq
	movq	%rax, -88(%rbp)
	movq	24(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, -92(%rbp)
	movl	-92(%rbp), %eax
	cltq
	movq	%rax, -104(%rbp)
	movq	24(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	movq	%rax, -112(%rbp)
	movq	24(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$4, %rax
	leaq	40(%rax), %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %edi
	movl	$0, %edx
	divq	%rdi
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	addq	$3, %rax
	shrq	$2, %rax
	salq	$2, %rax
	movq	%rax, -120(%rbp)
	.loc 2 2328 7 is_stmt 0 discriminator 1
	movq	24(%rbx), %rax
	movl	(%rax), %edx
	movq	-120(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_output_profile__condition_resultIP
	.loc 2 2329 7 is_stmt 1
	movq	24(%rbx), %rax
	movl	(%rax), %eax
	movl	%eax, -124(%rbp)
	movl	-124(%rbp), %eax
	cltq
	movq	%rax, -136(%rbp)
	movq	24(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$2, %rax
	leaq	0(,%rax,8), %r14
	movq	24(%rbx), %rax
	movl	(%rax), %eax
	cltq
	addq	$2, %rax
	leaq	0(,%rax,8), %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %edi
	movl	$0, %edx
	divq	%rdi
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	addq	$3, %rax
	shrq	$2, %rax
	salq	$2, %rax
	movq	%rax, -144(%rbp)
	.loc 2 2329 7 is_stmt 0 discriminator 1
	movq	24(%rbx), %rax
	movl	(%rax), %edx
	movq	-144(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_output_profile__scalar_flowIP
	.loc 2 2331 24 is_stmt 1
	movq	24(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 2331 7
	testl	%eax, %eax
	jne	.L1736
	.loc 2 2331 40 discriminator 1
	movq	24(%rbx), %rax
	movq	%rax, %rdi
	call	silver_output_profile__invalid_body
	.loc 2 2331 33 discriminator 2
	jmp	.L1737
.L1736:
	.loc 2 2332 10
	movq	24(%rbx), %rax
	movl	4(%rax), %edx
	movq	16(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$26, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 2332 7 discriminator 1
	testl	%eax, %eax
	je	.L1738
.LBB496:
	.loc 2 2333 20
	movq	16(%rbx), %rax
	movq	8(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$26, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__body_token
	.loc 2 2333 20 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2333 20 discriminator 2
	movq	24(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1739
	.loc 2 2333 20 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2333, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1739:
	.loc 2 2333 17 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE496:
	.loc 2 2334 10
	movq	-72(%rbp), %rax
	leaq	20(%rax), %r8
	movq	-72(%rbp), %rax
	movl	4(%rax), %ecx
	movq	16(%rbx), %rax
	movq	8(%rbx), %rdx
	movq	-120(%rbp), %rdi
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rdi, %r9
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__read_condition_into
	.loc 2 2335 26
	movq	-120(%rbp), %rax
	movl	4(%rax), %edx
	movq	-72(%rbp), %rax
	movl	%edx, 4(%rax)
	.loc 2 2336 35
	movq	-120(%rbp), %rax
	movl	8(%rax), %edx
	movq	24(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1740
	.loc 2 2336 35 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$2336, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1740:
	.loc 2 2336 23 is_stmt 1 discriminator 2
	movq	-120(%rbp), %rax
	leaq	8(%rax), %rdx
	movq	-72(%rbp), %rax
	addq	$20, %rax
	movq	%rdx, %rcx
	movq	%r13, %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
.LBB497:
	.loc 2 2337 20
	movq	16(%rbx), %rax
	movq	8(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$24, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__body_token
	.loc 2 2337 20 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2337 20 discriminator 2
	movq	24(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1741
	.loc 2 2337 20 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2337, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1741:
	.loc 2 2337 17 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE497:
	.loc 2 2338 29
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	24(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 2338 10
	cmpl	%eax, %edx
	jg	.L1742
	.loc 2 2338 58 discriminator 1
	movq	24(%rbx), %rax
	movq	%rax, %rdi
	call	silver_output_profile__invalid_body
	.loc 2 2338 51 discriminator 2
	jmp	.L1737
.L1742:
.LBB498:
	.loc 2 2339 20
	movq	16(%rbx), %rax
	movq	8(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$2, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__read_body
	.loc 2 2339 20 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2339 20 discriminator 2
	movq	24(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1743
	.loc 2 2339 20 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2339, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1743:
	.loc 2 2339 17 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE498:
	.loc 2 2340 29
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	24(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 2340 10
	cmpl	%eax, %edx
	jg	.L1744
	.loc 2 2340 58 discriminator 1
	movq	24(%rbx), %rax
	movq	%rax, %rdi
	call	silver_output_profile__invalid_body
	.loc 2 2340 51 discriminator 2
	jmp	.L1737
.L1744:
	.loc 2 2341 23
	movq	-72(%rbp), %rax
	movl	20(%rax), %edx
	movq	24(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1745
	.loc 2 2341 23 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$2341, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1745:
	.loc 2 2341 14 is_stmt 1 discriminator 2
	movq	-72(%rbp), %rax
	leaq	20(%rax), %rdx
	movq	-144(%rbp), %rax
	movq	%rdx, %rcx
	movq	%r14, %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 2342 35
	movq	-112(%rbp), %rax
	shrq	$2, %rax
	movq	%rax, %rdx
	movq	-120(%rbp), %rax
	movl	(%rax,%rdx,4), %edx
	movq	24(%rbx), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	je	.L1746
	.loc 2 2342 35 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$2342, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1746:
	.loc 2 2342 23 is_stmt 1 discriminator 2
	movq	-112(%rbp), %rax
	shrq	$2, %rax
	leaq	0(,%rax,4), %rdx
	movq	-120(%rbp), %rax
	addq	%rax, %rdx
	movq	-72(%rbp), %rax
	addq	$20, %rax
	movq	%rdx, %rcx
	movq	%r13, %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
.LBB499:
	.loc 2 2343 20
	movq	16(%rbx), %rax
	movq	8(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__alternative_body
	.loc 2 2343 20 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2343 20 discriminator 2
	movq	24(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1747
	.loc 2 2343 20 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2343, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1747:
	.loc 2 2343 17 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE499:
	.loc 2 2344 10
	movq	-72(%rbp), %rax
	leaq	20(%rax), %rdx
	movq	-144(%rbp), %rax
	movq	%rax, %rsi
	movq	%rdx, %rdi
	call	silver_output_profile__join_into
	.loc 2 2345 10
	movq	24(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	addq	$36, %rax
	movl	$4, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rbx
	.loc 2 2345 10 is_stmt 0 discriminator 1
	movq	%rbx, %rdx
	movq	-72(%rbp), %rax
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 2345 10 discriminator 2
	movq	%rbx, %rax
	jmp	.L1737
.L1738:
	.loc 2 2346 13 is_stmt 1
	movq	24(%rbx), %rax
	movl	4(%rax), %edx
	movq	16(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$25, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 2346 7 discriminator 1
	testl	%eax, %eax
	je	.L1748
.LBB500:
	.loc 2 2347 20
	movq	16(%rbx), %rax
	movq	8(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$25, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__body_token
	.loc 2 2347 20 is_stmt 0 discriminator 1
	movl	(%rax), %ecx
	.loc 2 2347 20 discriminator 2
	movq	24(%rbx), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	je	.L1749
	.loc 2 2347 20 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2347, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.L1749:
	.loc 2 2347 17 is_stmt 1 discriminator 4
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r12, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE500:
	.loc 2 2348 29
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	24(%rbx), %rax
	movl	4(%rax), %eax
	.loc 2 2348 10
	cmpl	%eax, %edx
	jg	.L1750
	.loc 2 2348 58 discriminator 1
	movq	24(%rbx), %rax
	movq	%rax, %rdi
	call	silver_output_profile__invalid_body
	.loc 2 2348 51 discriminator 2
	jmp	.L1737
.L1750:
	.loc 2 2349 17
	movq	16(%rbx), %rax
	movq	8(%rbx), %rdx
	movq	-72(%rbp), %rcx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$0, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__read_body
	.loc 2 2349 10 discriminator 1
	jmp	.L1737
.L1748:
	.loc 2 2350 13
	movq	24(%rbx), %rax
	movl	4(%rax), %edx
	movq	16(%rbx), %rax
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	$10, %ecx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__take_token
	.loc 2 2350 7 discriminator 1
	testl	%eax, %eax
	je	.L1751
	.loc 2 2351 10
	movq	24(%rbx), %rax
	movl	(%rax), %eax
	cltq
	salq	$3, %rax
	addq	$36, %rax
	movl	$4, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %r12
	.loc 2 2351 10 is_stmt 0 discriminator 1
	movq	%r12, %rcx
	movq	24(%rbx), %rdx
	movq	(%rbx), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdx
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 2351 10 discriminator 2
	movq	%r12, %rax
	jmp	.L1737
.L1751:
	.loc 2 2353 17 is_stmt 1
	movq	24(%rbx), %rax
	movq	%rax, %rdi
	call	silver_output_profile__invalid_body
	.loc 2 2353 10 discriminator 1
	nop
.L1737:
	.loc 2 2355 8
	movq	%r15, %rsp
	leaq	-40(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE144:
	.size	silver_output_profile__alternative_body___wrapped_statements.45, .-silver_output_profile__alternative_body___wrapped_statements.45
	.align 2
	.type	silver_output_profile__read_statements___wrapped_statements___finalizer.47, @function
silver_output_profile__read_statements___wrapped_statements___finalizer.47:
.LFB147:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE147:
	.size	silver_output_profile__read_statements___wrapped_statements___finalizer.47, .-silver_output_profile__read_statements___wrapped_statements___finalizer.47
	.align 2
	.type	silver_output_profile__read_statements___wrapped_statements.46, @function
silver_output_profile__read_statements___wrapped_statements.46:
.LFB146:
	.loc 2 2363 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA146
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB12:
	subq	$17848, %rsp
.LEHE12:
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -17864(%rbp)
	movq	%r10, %rbx
	movq	%r10, -17872(%rbp)
	.loc 2 2363 4
	leaq	16(%rbp), %rax
	.loc 2 2363 4 is_stmt 0 discriminator 1
	movq	%rax, -17832(%rbp)
	movq	%rsp, %rax
	movq	%rax, -17880(%rbp)
	leaq	-17856(%rbp), %rax
	movq	%rax, %rdi
.LEHB13:
	call	system__secondary_stack__ss_mark@PLT
	.loc 2 2365 42 is_stmt 1
	movq	8(%rbx), %rdx
	leaq	-17824(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__context_of
	.loc 2 2366 7
	movq	8(%rbx), %rax
	movl	6828(%rax), %eax
	movl	%eax, -52(%rbp)
	movl	-52(%rbp), %eax
	cltq
	movq	%rax, -64(%rbp)
	movq	8(%rbx), %rax
	movl	6828(%rax), %eax
	cltq
	salq	$3, %rax
	leaq	36(%rax), %r14
	.loc 2 2366 70
	movzbl	16(%rbx), %eax
	cmpb	$25, %al
	jne	.L1756
	.loc 2 2366 70 is_stmt 0 discriminator 1
	movl	$1, %r15d
	jmp	.L1757
.L1756:
	.loc 2 2366 70 discriminator 2
	movl	$0, %r15d
.L1757:
	.loc 2 2367 25 is_stmt 1
	movq	8(%rbx), %rax
	movq	%rax, %rdi
	call	silver_output_profile__body_of
	movq	%rax, %rcx
	.loc 2 2366 70 discriminator 3
	movq	(%rbx), %rax
	movzbl	%r15b, %edi
	leaq	-17824(%rbp), %rdx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__read_body
	movq	%rax, %rcx
	.loc 2 2366 70 is_stmt 0 discriminator 4
	movl	(%rcx), %edx
	.loc 2 2366 70 discriminator 5
	movq	8(%rbx), %rax
	movl	6828(%rax), %eax
	cmpl	%eax, %edx
	je	.L1758
	.loc 2 2366 70 discriminator 6
	leaq	.LC12(%rip), %rax
	movl	$2366, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Discriminant_Check@PLT
.LEHE13:
.L1758:
	.loc 2 2366 7 is_stmt 1 discriminator 7
	movq	8(%rbx), %rax
	movl	6828(%rax), %eax
	cltq
	salq	$3, %rax
	leaq	36(%rax), %rdx
	movl	$16, %eax
	subq	$1, %rax
	addq	%rdx, %rax
	movl	$16, %esi
	movl	$0, %edx
.LEHB14:
	divq	%rsi
.LEHE14:
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	addq	$3, %rax
	shrq	$2, %rax
	salq	$2, %rax
	movq	%rax, -72(%rbp)
	.loc 2 2366 7 is_stmt 0 discriminator 8
	movq	-72(%rbp), %rax
	movq	%r14, %rdx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 2369 34 is_stmt 1
	movq	-72(%rbp), %rax
	movl	4(%rax), %eax
	.loc 2 2369 15
	testl	%eax, %eax
	je	.L1759
	.loc 2 2369 55 discriminator 1
	movq	-72(%rbp), %rax
	movq	24(%rax), %rdx
	movl	32(%rax), %eax
	movq	%rdx, %rdi
	movl	%eax, %esi
.LEHB15:
	call	silver_path_facts__completed@PLT
	.loc 2 2369 46 discriminator 2
	xorl	$1, %eax
	.loc 2 2369 38 discriminator 2
	testb	%al, %al
	je	.L1760
.L1759:
	.loc 2 2370 20
	movq	-17864(%rbp), %rax
	movq	%rax, %rcx
	leaq	silver_output_profile__invalid_scan(%rip), %rax
	movl	$17764, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	movl	$0, %ebx
	jmp	.L1761
.L1760:
	.loc 2 2370 38 discriminator 1
	movq	-17864(%rbp), %rax
	movq	-72(%rbp), %rdx
	leaq	-17824(%rbp), %rcx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__expand_body
.LEHE15:
	.loc 2 2370 38 is_stmt 0 discriminator 2
	movl	$0, %ebx
.L1761:
	.loc 2 2371 0 is_stmt 1
	leaq	-17856(%rbp), %rax
	movq	%rax, %r10
.LEHB16:
	call	silver_output_profile__read_statements___wrapped_statements___finalizer.47
.LEHE16:
	.loc 2 2371 0 is_stmt 0 discriminator 1
	cmpl	$1, %ebx
	je	.L1762
	movl	$0, %eax
.L1767:
.LEHB17:
	.loc 2 2371 8 is_stmt 1 discriminator 2
	movq	-17880(%rbp), %rsp
	.loc 2 2371 8 is_stmt 0 discriminator 3
	cmpl	$1, %eax
	je	.L1763
	.loc 2 2371 8
	jmp	.L1770
.L1768:
	movq	%rax, %r13
	movl	$1, %ebx
	.loc 2 2363 4 is_stmt 1 discriminator 2
	jmp	.L1761
.L1762:
	movq	%r13, %r12
	jmp	.L1766
.L1769:
	movq	%rax, %r12
.L1766:
	movl	$1, %eax
	jmp	.L1767
.L1763:
	movq	%r12, %rax
	movq	%rax, %rdi
	call	_Unwind_Resume@PLT
.L1770:
	.loc 2 2371 8
	movq	-17864(%rbp), %rax
	leaq	-40(%rbp), %rsp
.LEHE17:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE146:
	.section	.gcc_except_table
.LLSDA146:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE146-.LLSDACSB146
.LLSDACSB146:
	.uleb128 .LEHB12-.LFB146
	.uleb128 .LEHE12-.LEHB12
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB13-.LFB146
	.uleb128 .LEHE13-.LEHB13
	.uleb128 .L1768-.LFB146
	.uleb128 0
	.uleb128 .LEHB14-.LFB146
	.uleb128 .LEHE14-.LEHB14
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB15-.LFB146
	.uleb128 .LEHE15-.LEHB15
	.uleb128 .L1768-.LFB146
	.uleb128 0
	.uleb128 .LEHB16-.LFB146
	.uleb128 .LEHE16-.LEHB16
	.uleb128 .L1769-.LFB146
	.uleb128 0
	.uleb128 .LEHB17-.LFB146
	.uleb128 .LEHE17-.LEHB17
	.uleb128 0
	.uleb128 0
.LLSDACSE146:
	.text
	.size	silver_output_profile__read_statements___wrapped_statements.46, .-silver_output_profile__read_statements___wrapped_statements.46
	.section	.rodata
	.align 8
.LC237:
	.ascii	"failed precondition from silver_output_profile.adb:2360"
	.align 8
.LC238:
	.ascii	"failed precondition from silver_output_profile.adb:2361"
	.align 8
.LC239:
	.ascii	"failed postcondition from silver_output_profile.adb:2362"
	.text
	.align 2
	.globl	silver_output_profile__read_statements
	.type	silver_output_profile__read_statements, @function
silver_output_profile__read_statements:
.LFB145:
	.loc 2 2363 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	subq	$17888, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	movq	%rdi, -17848(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -17872(%rbp)
	movq	%rdx, -17864(%rbp)
	movq	%rcx, -17856(%rbp)
	movb	%r8b, -17873(%rbp)
	.loc 2 2363 4
	leaq	16(%rbp), %rdx
	.loc 2 2363 4 is_stmt 0 discriminator 1
	leaq	-17872(%rbp), %rax
	movq	%rdx, -40(%rbp)
	movq	%rax, -64(%rbp)
	movq	-17856(%rbp), %rax
	movq	%rax, -56(%rbp)
	movzbl	-17873(%rbp), %eax
	movb	%al, -48(%rbp)
	movq	-17864(%rbp), %rax
	movl	(%rax), %ecx
	movq	-17864(%rbp), %rax
	movl	4(%rax), %esi
	cmpl	%ecx, %esi
	jl	.L1772
	.loc 2 2363 4 discriminator 2
	movslq	%esi, %rax
	cqto
	movslq	%ecx, %rdi
	movq	%rdi, %r8
	movq	%rdi, %r9
	sarq	$63, %r9
	subq	%r8, %rax
	sbbq	%r9, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L1773
.L1772:
	.loc 2 2363 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L1773:
.LBB501:
	.loc 2 2363 4 discriminator 4
	cmpl	%ecx, %esi
	.loc 2 2363 4 discriminator 7
	cmpl	%ecx, %esi
	.loc 2 2363 4 discriminator 10
	cmpl	%ecx, %esi
	.loc 2 2360 15 is_stmt 1
	cmpl	$1, %ecx
	je	.L1780
.LBB502:
	.loc 2 2360 15 is_stmt 0 discriminator 1
	leaq	.LC237(%rip), %rax
	movq	%rax, -17920(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -17912(%rbp)
	movq	-17920(%rbp), %rsi
	movq	-17912(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1780:
.LBE502:
	.loc 2 2360 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 2360 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L1781
	.loc 2 2360 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L1782
.L1781:
.LBB503:
	.loc 2 2360 15 discriminator 4
	leaq	.LC237(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1782:
.LBE503:
	.loc 2 2361 19
	movq	-56(%rbp), %rax
	movq	%rax, %rdx
	movq	-17872(%rbp), %rcx
	movq	-17864(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 2361 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 2360 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L1783
.LBB504:
	.loc 2 2360 15 is_stmt 0 discriminator 6
	leaq	.LC238(%rip), %rax
	movq	%rax, -17904(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -17896(%rbp)
	movq	-17904(%rbp), %rsi
	movq	-17896(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1783:
.LBE504:
	.loc 2 2360 15 discriminator 7
	movzbl	-48(%rbp), %eax
	cmpb	$25, %al
	je	.L1784
	.loc 2 2361 82 is_stmt 1 discriminator 2
	movzbl	-48(%rbp), %eax
	cmpb	$10, %al
	je	.L1784
.LBB505:
	.loc 2 2360 15 discriminator 8
	leaq	.LC238(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1784:
.LBE505:
.LBB506:
	.loc 2 2363 4 discriminator 13
	leaq	-17840(%rbp), %rax
	leaq	-64(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_output_profile__read_statements___wrapped_statements.46
	.loc 2 2362 16
	leaq	-17840(%rbp), %rdx
	movq	-17872(%rbp), %rcx
	movq	-17864(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 2362 16 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L1785
.LBB507:
	.loc 2 2362 16 discriminator 2
	leaq	.LC239(%rip), %r12
	leaq	.LC6(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1785:
.LBE507:
	.loc 2 2363 4 is_stmt 1 discriminator 14
	movq	-17848(%rbp), %rax
	movq	%rax, %rcx
	leaq	-17840(%rbp), %rax
	movl	$17764, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE506:
.LBE501:
	.loc 2 2363 4 is_stmt 0
	movq	-17848(%rbp), %rax
	addq	$17888, %rsp
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE145:
	.size	silver_output_profile__read_statements, .-silver_output_profile__read_statements
	.align 2
	.type	silver_output_profile__scan_step___wrapped_statements.48, @function
silver_output_profile__scan_step___wrapped_statements.48:
.LFB149:
	.loc 2 2380 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$35560, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -17800(%rbp)
	movq	%r10, %rbx
	movq	%r10, -17808(%rbp)
	.loc 2 2383 7
	movzbl	17(%rbx), %eax
	cmpb	$50, %al
	jne	.L1788
	.loc 2 2383 34 discriminator 1
	movq	8(%rbx), %rax
	movq	(%rbx), %rcx
	movq	-17800(%rbp), %rdi
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movl	$10, %r8d
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__read_statements
	.loc 2 2383 34 is_stmt 0 discriminator 2
	jmp	.L1790
.L1788:
	.loc 2 2385 12 is_stmt 1
	movq	(%rbx), %rdx
	leaq	-17792(%rbp), %rax
	movq	%rdx, %rcx
	movl	$17764, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 2385 38
	movq	(%rbx), %rax
	movq	%rax, %r8
	movq	8(%rbx), %rax
	movzbl	16(%rbx), %edx
	movzbl	17(%rbx), %ecx
	leaq	-35568(%rbp), %rdi
	movzbl	%cl, %esi
	movzbl	%dl, %ecx
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%r8, %r9
	movl	%esi, %r8d
	movq	%rdx, %rsi
	movq	%rax, %rdx
	call	silver_output_profile__step
	leaq	-17792(%rbp), %rax
	leaq	-35568(%rbp), %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	.loc 2 2385 12 discriminator 1
	movq	-17800(%rbp), %rax
	movq	%rax, %rcx
	leaq	-17792(%rbp), %rax
	movl	$17764, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.L1790:
	.loc 2 2380 4
	movq	-17800(%rbp), %rax
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE149:
	.size	silver_output_profile__scan_step___wrapped_statements.48, .-silver_output_profile__scan_step___wrapped_statements.48
	.section	.rodata
	.align 8
.LC240:
	.ascii	"failed precondition from silver_output_profile.adb:2377"
	.align 8
.LC241:
	.ascii	"failed precondition from silver_output_profile.adb:2378"
	.align 8
.LC242:
	.ascii	"failed postcondition from silver_output_profile.adb:2379"
	.text
	.align 2
	.globl	silver_output_profile__scan_step
	.type	silver_output_profile__scan_step, @function
silver_output_profile__scan_step:
.LFB148:
	.loc 2 2380 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$17880, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -17864(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -17888(%rbp)
	movq	%rdx, -17880(%rbp)
	movb	%cl, -17865(%rbp)
	movb	%r8b, -17866(%rbp)
	movq	%r9, -17896(%rbp)
	.loc 2 2380 4
	leaq	16(%rbp), %rdx
	.loc 2 2380 4 is_stmt 0 discriminator 1
	leaq	-17888(%rbp), %rax
	movq	%rdx, -56(%rbp)
	movq	%rax, -72(%rbp)
	movzbl	-17865(%rbp), %eax
	movb	%al, -64(%rbp)
	movzbl	-17866(%rbp), %eax
	movb	%al, -63(%rbp)
	movq	-17896(%rbp), %rax
	movq	%rax, -80(%rbp)
	movq	-17880(%rbp), %rax
	movl	(%rax), %esi
	movq	-17880(%rbp), %rax
	movl	4(%rax), %edx
	movq	-17880(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L1792
	.loc 2 2380 4 discriminator 2
	movq	-17880(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-17880(%rbp), %rcx
	movl	(%rcx), %edi
	movslq	%edi, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L1793
.L1792:
	.loc 2 2380 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L1793:
.LBB508:
	.loc 2 2377 15 is_stmt 1
	cmpl	$1, %esi
	je	.L1794
.LBB509:
	.loc 2 2377 15 is_stmt 0 discriminator 1
	leaq	.LC240(%rip), %rax
	movq	%rax, -17920(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -17912(%rbp)
	movq	-17920(%rbp), %rbx
	movq	-17912(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1794:
.LBE509:
	.loc 2 2377 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 2 2377 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L1795
	.loc 2 2377 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L1796
.L1795:
.LBB510:
	.loc 2 2377 15 discriminator 4
	leaq	.LC240(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1796:
.LBE510:
	.loc 2 2378 19
	movq	-80(%rbp), %rax
	movq	%rax, %rdx
	movq	-17888(%rbp), %rcx
	movq	-17880(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 2378 19 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 2377 15 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L1797
.LBB511:
	.loc 2 2377 15 is_stmt 0 discriminator 6
	leaq	.LC241(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1797:
.LBE511:
.LBB512:
	.loc 2 2380 4 is_stmt 1 discriminator 5
	leaq	-17856(%rbp), %rax
	leaq	-80(%rbp), %rdx
	movq	%rdx, %r10
	movq	%rax, %rdi
	call	silver_output_profile__scan_step___wrapped_statements.48
	.loc 2 2379 16
	leaq	-17856(%rbp), %rdx
	movq	-17888(%rbp), %rcx
	movq	-17880(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__valid_state
	.loc 2 2379 16 is_stmt 0 discriminator 1
	xorl	$1, %eax
	testb	%al, %al
	je	.L1798
.LBB513:
	.loc 2 2379 16 discriminator 2
	leaq	.LC242(%rip), %r12
	leaq	.LC6(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1798:
.LBE513:
	.loc 2 2380 4 is_stmt 1 discriminator 6
	movq	-17864(%rbp), %rax
	movq	%rax, %rcx
	leaq	-17856(%rbp), %rax
	movl	$17764, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
.LBE512:
.LBE508:
	.loc 2 2380 4 is_stmt 0
	movq	-17864(%rbp), %rax
	addq	$17880, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE148:
	.size	silver_output_profile__scan_step, .-silver_output_profile__scan_step
	.align 2
	.type	silver_output_profile__read_form__B_22__L_23__B2666b___finalizer.49, @function
silver_output_profile__read_form__B_22__L_23__B2666b___finalizer.49:
.LFB151:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	addq	$48, %rax
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE151:
	.size	silver_output_profile__read_form__B_22__L_23__B2666b___finalizer.49, .-silver_output_profile__read_form__B_22__L_23__B2666b___finalizer.49
	.section	.rodata
	.align 8
.LC243:
	.ascii	"Loop_Invariant failed at silver_output_profile.adb:2441"
	.align 8
.LC244:
	.ascii	"Loop_Variant failed at silver_output_profile.adb:2445"
	.text
	.align 2
	.type	silver_output_profile__read_form, @function
silver_output_profile__read_form:
.LFB150:
	.loc 2 2430 4 is_stmt 1
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA150
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB18:
	subq	$35800, %rsp
.LEHE18:
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, -17960(%rbp)
	movq	%rsi, %rax
	movq	%rdx, %rsi
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -17984(%rbp)
	movq	%rdx, -17976(%rbp)
	movb	%cl, -17961(%rbp)
	.loc 2 2430 4
	leaq	16(%rbp), %rax
	.loc 2 2430 4 is_stmt 0 discriminator 1
	movq	%rax, -104(%rbp)
	movq	-17976(%rbp), %rax
	movl	(%rax), %edx
	movq	-17976(%rbp), %rax
	movl	4(%rax), %ecx
.LBB514:
	cmpl	%edx, %ecx
	.loc 2 2430 4 discriminator 4
	cmpl	%edx, %ecx
	.loc 2 2430 4 discriminator 7
	cmpl	%edx, %ecx
	.loc 2 2432 7 is_stmt 1
	cmpl	%ecx, %edx
	jg	.L1809
	.loc 2 2432 50 discriminator 1
	movslq	%edx, %rax
	leaq	4095(%rax), %rdx
	movslq	%ecx, %rax
	.loc 2 2432 28 discriminator 1
	cmpq	%rax, %rdx
	jge	.L1810
.L1809:
	.loc 2 2432 75 discriminator 2
	movq	-17960(%rbp), %rax
	movq	%rax, %rcx
	leaq	silver_output_profile__invalid_scan(%rip), %rax
	movl	$17764, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	jmp	.L1802
.L1810:
	leaq	-176(%rbp), %rax
	movq	%rax, %rdi
.LEHB19:
	call	system__secondary_stack__ss_mark@PLT
.LBB515:
	.loc 2 2434 36
	movq	-17984(%rbp), %rax
	movq	-17976(%rbp), %rdx
	movq	%rax, %rdi
	movq	%rdx, %rsi
	call	silver_output_profile__normalized
	.loc 2 2434 36 is_stmt 0 discriminator 1
	movq	%rax, %r12
	movq	%rdx, %r13
	movq	%r13, %rax
	movl	(%rax), %eax
	movl	%eax, -56(%rbp)
	movq	%r13, %rax
	movl	4(%rax), %eax
	movl	%eax, -60(%rbp)
	.loc 2 2434 10 is_stmt 1 discriminator 1
	movl	-56(%rbp), %eax
	cltq
	movq	%rax, -72(%rbp)
	movl	-60(%rbp), %eax
	cmpl	-56(%rbp), %eax
	jl	.L1812
	.loc 2 2434 10 is_stmt 0 discriminator 2
	movl	-60(%rbp), %eax
	cltq
	movq	%rax, -80(%rbp)
	jmp	.L1813
.L1812:
	.loc 2 2434 10 discriminator 3
	movl	-56(%rbp), %eax
	cltq
	subq	$1, %rax
	movq	%rax, -80(%rbp)
.L1813:
	.loc 2 2434 10 discriminator 4
	movl	-60(%rbp), %eax
	cmpl	-56(%rbp), %eax
	.loc 2 2434 10 discriminator 7
	movl	-60(%rbp), %eax
	cmpl	-56(%rbp), %eax
	.loc 2 2434 36 is_stmt 1 discriminator 10
	movl	-60(%rbp), %eax
	cmpl	-56(%rbp), %eax
	jl	.L1818
	.loc 2 2434 36 is_stmt 0 discriminator 11
	cmpl	$0, -56(%rbp)
	jg	.L1818
	.loc 2 2434 36 discriminator 12
	leaq	.LC12(%rip), %rax
	movl	$2434, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L1818:
	.loc 2 2434 10 is_stmt 1 discriminator 13
	movq	%r12, -88(%rbp)
	.loc 2 2435 10
	leaq	-17952(%rbp), %rdi
	leaq	silver_output_profile__initial_scan(%rip), %rcx
	movl	$17764, %eax
	movq	%rax, %rdx
	movq	%rcx, %rsi
	call	memcpy@PLT
	.loc 2 2436 10
	movl	$1, -52(%rbp)
	.loc 2 2438 17
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__allowed_source
	.loc 2 2438 17 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 2438 10 is_stmt 1 discriminator 1
	testb	%al, %al
	je	.L1819
	.loc 2 2438 44 discriminator 2
	movq	-17960(%rbp), %rax
	movq	%rax, %rcx
	leaq	silver_output_profile__invalid_scan(%rip), %rax
	movl	$17764, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	movl	$0, %ebx
	jmp	.L1820
.L1819:
	.loc 2 2439 17
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_output_profile__within_work_budget
.LEHE19:
	.loc 2 2439 17 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 2439 10 is_stmt 1 discriminator 1
	testb	%al, %al
	je	.L1821
	.loc 2 2439 48 discriminator 2
	movq	-17960(%rbp), %rax
	movq	%rax, %rcx
	leaq	silver_output_profile__invalid_scan(%rip), %rax
	movl	$17764, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	movl	$0, %ebx
	jmp	.L1820
.L1821:
	.loc 2 2440 49
	movb	$0, -17962(%rbp)
.L1837:
	leaq	-128(%rbp), %rax
	movq	%rax, %rdi
.LEHB20:
	call	system__secondary_stack__ss_mark@PLT
.LBB516:
.LBB517:
	.loc 2 2440 30 discriminator 1
	movzbl	-17961(%rbp), %eax
	movl	%eax, %edi
	call	silver_output_profile__tokens
.LEHE20:
	.loc 2 2440 27 discriminator 2
	movq	%rdx, %rax
	movl	4(%rax), %eax
	cmpl	%eax, -52(%rbp)
	setle	-17963(%rbp)
	.loc 2 2440 0 discriminator 2
	movl	$1, %ebx
.L1842:
	.loc 2 2440 0 is_stmt 0 discriminator 3
	leaq	-176(%rbp), %rax
	movq	%rax, %r10
.LEHB21:
	call	silver_output_profile__read_form__B_22__L_23__B2666b___finalizer.49
.LEHE21:
	.loc 2 2440 0 discriminator 4
	cmpl	$1, %ebx
	jne	.L1822
	.loc 2 2440 0 discriminator 6
	movl	$1, %eax
.L1844:
	.loc 2 2440 0 discriminator 7
	cmpl	$1, %eax
	jne	.L1823
	.loc 2 2440 0 discriminator 8
	nop
.LBE517:
	.loc 2 2440 27 is_stmt 1 discriminator 9
	movzbl	-17963(%rbp), %eax
	xorl	$1, %eax
	testb	%al, %al
	jne	.L1824
	.loc 2 2441 56
	movl	-17952(%rbp), %eax
	.loc 2 2441 36
	testl	%eax, %eax
	jle	.L1825
	.loc 2 2441 69 discriminator 1
	leaq	-17952(%rbp), %rax
	movq	%r12, %rsi
	movq	%r13, %rcx
	movq	%rax, %rdx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
.LEHB22:
	call	silver_output_profile__valid_state
	.loc 2 2441 69 is_stmt 0 discriminator 2
	xorl	$1, %eax
	.loc 2 2441 60 is_stmt 1 discriminator 2
	testb	%al, %al
	je	.L1826
.L1825:
.LBB518:
	.loc 2 2441 36 discriminator 3
	leaq	.LC243(%rip), %rax
	movq	%rax, -35792(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -35784(%rbp)
	movq	-35792(%rbp), %rbx
	movq	-35784(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L1826:
.LBE518:
	.loc 2 2445 13
	cmpb	$0, -17962(%rbp)
	je	.L1827
	.loc 2 2445 47 discriminator 1
	movl	-17968(%rbp), %eax
	movl	%eax, -35812(%rbp)
.L1827:
	.loc 2 2445 47 is_stmt 0 discriminator 2
	movl	-52(%rbp), %eax
	movl	%eax, -17968(%rbp)
	.loc 2 2445 13 is_stmt 1 discriminator 2
	cmpb	$0, -17962(%rbp)
	je	.L1828
	.loc 2 2445 47 discriminator 3
	movl	-35812(%rbp), %ebx
	cmpl	%ebx, %eax
	jg	.L1829
.LBB519:
	.loc 2 2445 47 is_stmt 0 discriminator 4
	leaq	.LC244(%rip), %r14
	leaq	.LC8(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.LEHE22:
.L1828:
.LBE519:
	.loc 2 2445 13 is_stmt 1 discriminator 5
	movb	$1, -17962(%rbp)
.L1829:
	leaq	-152(%rbp), %rax
	movq	%rax, %rdi
.LEHB23:
	call	system__secondary_stack__ss_mark@PLT
.LBB520:
	.loc 2 2446 44
	movzbl	-17961(%rbp), %eax
	movl	%eax, %edi
	call	silver_output_profile__tokens
	.loc 2 2446 44 is_stmt 0 discriminator 1
	movq	%rax, %rcx
	movq	%rdx, %rbx
	movq	%rbx, %rax
	movl	(%rax), %edx
	movq	%rbx, %rax
	movl	4(%rax), %eax
	cmpl	%edx, -52(%rbp)
	jl	.L1830
	.loc 2 2446 44 discriminator 2
	cmpl	%eax, -52(%rbp)
	jle	.L1831
.L1830:
	.loc 2 2446 44 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$2446, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1831:
	.loc 2 2446 21 is_stmt 1 discriminator 4
	movq	%rcx, %rsi
	movq	%rbx, %rax
	movl	(%rax), %eax
	movslq	%eax, %rdx
	movl	-52(%rbp), %eax
	cltq
	subq	%rdx, %rax
	movzbl	(%rsi,%rax), %eax
	.loc 2 2446 21 is_stmt 0 discriminator 5
	leaq	-35760(%rbp), %r10
	leaq	-17952(%rbp), %rcx
	movzbl	%al, %edx
	movzbl	-17961(%rbp), %eax
	movq	%r12, %rsi
	movq	%r13, %rdi
	movq	%rcx, %r9
	movl	%edx, %r8d
	movl	%eax, %ecx
	movq	%rdi, %rdx
	movq	%r10, %rdi
	call	silver_output_profile__scan_step
.LEHE23:
	leaq	-17952(%rbp), %rdi
	leaq	-35760(%rbp), %rcx
	movl	$17764, %eax
	movq	%rax, %rdx
	movq	%rcx, %rsi
	call	memcpy@PLT
	.loc 2 2446 0 is_stmt 1 discriminator 6
	movl	$1, %ebx
.L1847:
	.loc 2 2446 0 is_stmt 0 discriminator 7
	leaq	-176(%rbp), %rax
	movq	%rax, %r10
.LEHB24:
	call	silver_output_profile__read_form__B_22__L_23__B2704b___finalizer.50
.LEHE24:
	.loc 2 2446 0 discriminator 8
	cmpl	$1, %ebx
	jne	.L1832
	.loc 2 2446 0 discriminator 10
	movl	$1, %eax
.L1849:
	.loc 2 2446 0 discriminator 11
	cmpl	$1, %eax
	jne	.L1833
	.loc 2 2446 0 discriminator 12
	nop
.LBE520:
	.loc 2 2447 36 is_stmt 1
	movl	-17952(%rbp), %eax
	.loc 2 2447 13
	testl	%eax, %eax
	jne	.L1834
	.loc 2 2447 45 discriminator 1
	movq	-17960(%rbp), %rax
	movq	%rax, %rcx
	leaq	silver_output_profile__invalid_scan(%rip), %rax
	movl	$17764, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	movl	$0, %ebx
	jmp	.L1820
.L1834:
	.loc 2 2448 38
	movl	-52(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L1835
	.loc 2 2448 38 is_stmt 0 discriminator 1
	cmpl	$101, %eax
	jle	.L1836
.L1835:
	.loc 2 2448 38 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$2448, %esi
	movq	%rax, %rdi
.LEHB25:
	call	__gnat_rcheck_CE_Range_Check@PLT
.L1836:
	.loc 2 2448 24 is_stmt 1 discriminator 3
	movl	%eax, -52(%rbp)
.LBE516:
	.loc 2 2449 18
	jmp	.L1837
.L1824:
	.loc 2 2450 21
	movl	-17952(%rbp), %eax
	movq	%r12, %rsi
	movq	%r13, %rcx
	movl	%eax, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver_output_profile__skip_at
.LEHE25:
	.loc 2 2450 18 discriminator 1
	cmpl	%eax, -60(%rbp)
	jge	.L1838
	.loc 2 2450 74 discriminator 2
	movq	-17960(%rbp), %rax
	movq	%rax, %rcx
	leaq	-17952(%rbp), %rax
	movl	$17764, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	movl	$0, %ebx
	jmp	.L1820
.L1838:
	.loc 2 2450 84 discriminator 3
	movq	-17960(%rbp), %rax
	movq	%rax, %rcx
	leaq	silver_output_profile__invalid_scan(%rip), %rax
	movl	$17764, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	movl	$0, %ebx
.L1820:
	.loc 2 2451 0
	leaq	-176(%rbp), %rax
	movq	%rax, %r10
.LEHB26:
	call	silver_output_profile__read_form__B_22___finalizer.51
.LEHE26:
	.loc 2 2451 0 is_stmt 0 discriminator 1
	cmpl	$1, %ebx
	je	.L1839
	movl	$0, %eax
.L1851:
	.loc 2 2451 10 is_stmt 1 discriminator 2
	cmpl	$1, %eax
	je	.L1840
.LBE515:
.LBE514:
	.loc 2 2452 8
	jmp	.L1802
.L1853:
	movq	%rax, -35824(%rbp)
	movl	$0, %ebx
.LBB525:
.LBB524:
.LBB523:
.LBB521:
	.loc 2 2440 27 discriminator 10
	jmp	.L1842
.L1822:
	movq	-35824(%rbp), %rax
	movq	%rax, -35776(%rbp)
	jmp	.L1843
.L1854:
	movq	%rax, -35776(%rbp)
.L1843:
	movl	$0, %eax
	jmp	.L1844
.L1823:
	movq	-35776(%rbp), %rax
	movq	%rax, -35768(%rbp)
	jmp	.L1845
.L1855:
	movq	%rax, -35832(%rbp)
	movl	$0, %ebx
.LBE521:
.LBB522:
	.loc 2 2446 18 discriminator 13
	jmp	.L1847
.L1832:
	movq	-35832(%rbp), %rax
	movq	%rax, -35800(%rbp)
	jmp	.L1848
.L1856:
	movq	%rax, -35800(%rbp)
.L1848:
	movl	$0, %eax
	jmp	.L1849
.L1833:
	movq	-35800(%rbp), %rax
	movq	%rax, -35768(%rbp)
	jmp	.L1845
.L1852:
	movq	%rax, -35768(%rbp)
.L1845:
	movl	$1, %ebx
.LBE522:
.LBE523:
	.loc 2 2433 7
	jmp	.L1820
.L1839:
	movq	-35768(%rbp), %rax
	movq	%rax, -35808(%rbp)
	jmp	.L1850
.L1857:
	movq	%rax, -35808(%rbp)
.L1850:
	movl	$1, %eax
	jmp	.L1851
.L1840:
	movq	-35808(%rbp), %rax
	movq	%rax, %rdi
.LEHB27:
	call	_Unwind_Resume@PLT
.L1802:
.LBE524:
.LBE525:
	.loc 2 2452 8
	movq	-17960(%rbp), %rax
	addq	$35800, %rsp
.LEHE27:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE150:
	.section	.gcc_except_table
.LLSDA150:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE150-.LLSDACSB150
.LLSDACSB150:
	.uleb128 .LEHB18-.LFB150
	.uleb128 .LEHE18-.LEHB18
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB19-.LFB150
	.uleb128 .LEHE19-.LEHB19
	.uleb128 .L1852-.LFB150
	.uleb128 0
	.uleb128 .LEHB20-.LFB150
	.uleb128 .LEHE20-.LEHB20
	.uleb128 .L1853-.LFB150
	.uleb128 0
	.uleb128 .LEHB21-.LFB150
	.uleb128 .LEHE21-.LEHB21
	.uleb128 .L1854-.LFB150
	.uleb128 0
	.uleb128 .LEHB22-.LFB150
	.uleb128 .LEHE22-.LEHB22
	.uleb128 .L1852-.LFB150
	.uleb128 0
	.uleb128 .LEHB23-.LFB150
	.uleb128 .LEHE23-.LEHB23
	.uleb128 .L1855-.LFB150
	.uleb128 0
	.uleb128 .LEHB24-.LFB150
	.uleb128 .LEHE24-.LEHB24
	.uleb128 .L1856-.LFB150
	.uleb128 0
	.uleb128 .LEHB25-.LFB150
	.uleb128 .LEHE25-.LEHB25
	.uleb128 .L1852-.LFB150
	.uleb128 0
	.uleb128 .LEHB26-.LFB150
	.uleb128 .LEHE26-.LEHB26
	.uleb128 .L1857-.LFB150
	.uleb128 0
	.uleb128 .LEHB27-.LFB150
	.uleb128 .LEHE27-.LEHB27
	.uleb128 0
	.uleb128 0
.LLSDACSE150:
	.text
	.size	silver_output_profile__read_form, .-silver_output_profile__read_form
	.align 2
	.type	silver_output_profile__read_form__B_22__L_23__B2704b___finalizer.50, @function
silver_output_profile__read_form__B_22__L_23__B2704b___finalizer.50:
.LFB152:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	addq	$24, %rax
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE152:
	.size	silver_output_profile__read_form__B_22__L_23__B2704b___finalizer.50, .-silver_output_profile__read_form__B_22__L_23__B2704b___finalizer.50
	.align 2
	.type	silver_output_profile__read_form__B_22___finalizer.51, @function
silver_output_profile__read_form__B_22___finalizer.51:
.LFB153:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE153:
	.size	silver_output_profile__read_form__B_22___finalizer.51, .-silver_output_profile__read_form__B_22___finalizer.51
	.align 2
	.globl	silver_output_profile__accepts
	.type	silver_output_profile__accepts, @function
silver_output_profile__accepts:
.LFB154:
	.loc 2 2454 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$17792, %rsp
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -17792(%rbp)
	movq	%rdx, -17784(%rbp)
	.loc 2 2454 4
	movq	-17784(%rbp), %rax
	movl	(%rax), %eax
	movq	-17784(%rbp), %rdx
	movl	4(%rdx), %edx
.LBB526:
	cmpl	%eax, %edx
	.loc 2 2454 4 is_stmt 0 discriminator 3
	cmpl	%eax, %edx
	.loc 2 2454 4 discriminator 6
	cmpl	%eax, %edx
.LBB527:
	.loc 2 2456 11 is_stmt 1 discriminator 1
	movb	$0, -1(%rbp)
.L1872:
.LBB528:
	.loc 2 2460 13
	leaq	-17776(%rbp), %rax
	movzbl	-1(%rbp), %ecx
	movq	-17792(%rbp), %rsi
	movq	-17784(%rbp), %rdx
	movq	%rax, %rdi
	call	silver_output_profile__read_form
	.loc 2 2460 53 discriminator 1
	movl	-17776(%rbp), %eax
	.loc 2 2460 10 discriminator 1
	testl	%eax, %eax
	je	.L1869
	.loc 2 2460 63 discriminator 2
	movl	$1, %eax
	jmp	.L1870
.L1869:
.LBE528:
	.loc 2 2456 11 discriminator 2
	cmpb	$1, -1(%rbp)
	je	.L1871
	.loc 2 2456 11 is_stmt 0 discriminator 3
	addb	$1, -1(%rbp)
	.loc 2 2461 15 is_stmt 1
	jmp	.L1872
.L1871:
.LBE527:
	.loc 2 2462 7
	movl	$0, %eax
.L1870:
.LBE526:
	.loc 2 2463 8
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE154:
	.size	silver_output_profile__accepts, .-silver_output_profile__accepts
	.align 2
	.globl	silver_output_profile__uses_arguments
	.type	silver_output_profile__uses_arguments, @function
silver_output_profile__uses_arguments:
.LFB155:
	.loc 2 2465 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$17792, %rsp
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -17792(%rbp)
	movq	%rdx, -17784(%rbp)
	.loc 2 2465 4
	movq	-17784(%rbp), %rax
	movl	(%rax), %eax
	movq	-17784(%rbp), %rdx
	movl	4(%rdx), %edx
.LBB529:
	cmpl	%eax, %edx
	.loc 2 2465 4 is_stmt 0 discriminator 3
	cmpl	%eax, %edx
	.loc 2 2465 4 discriminator 6
	cmpl	%eax, %edx
.LBB530:
	.loc 2 2467 11 is_stmt 1 discriminator 1
	movb	$0, -1(%rbp)
.L1883:
.LBB531:
	.loc 2 2472 13
	leaq	-17776(%rbp), %rax
	movzbl	-1(%rbp), %ecx
	movq	-17792(%rbp), %rsi
	movq	-17784(%rbp), %rdx
	movq	%rax, %rdi
	call	silver_output_profile__read_form
	.loc 2 2472 53 discriminator 1
	movl	-17776(%rbp), %eax
	.loc 2 2472 10 discriminator 1
	testl	%eax, %eax
	je	.L1880
	.loc 2 2472 67 discriminator 2
	movzbl	-1(%rbp), %eax
	movl	%eax, %edi
	call	silver_output_profile__is_argument_form
	.loc 2 2472 58 discriminator 3
	testb	%al, %al
	je	.L1880
	.loc 2 2473 15
	movl	$1, %eax
	jmp	.L1881
.L1880:
.LBE531:
	.loc 2 2467 11 discriminator 2
	cmpb	$1, -1(%rbp)
	je	.L1882
	.loc 2 2467 11 is_stmt 0 discriminator 3
	addb	$1, -1(%rbp)
	.loc 2 2474 15 is_stmt 1
	jmp	.L1883
.L1882:
.LBE530:
	.loc 2 2475 7
	movl	$0, %eax
.L1881:
.LBE529:
	.loc 2 2476 8
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE155:
	.size	silver_output_profile__uses_arguments, .-silver_output_profile__uses_arguments
	.align 2
	.globl	silver_output_profile__uses_assignment
	.type	silver_output_profile__uses_assignment, @function
silver_output_profile__uses_assignment:
.LFB156:
	.loc 2 2478 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$17792, %rsp
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -17792(%rbp)
	movq	%rdx, -17784(%rbp)
	.loc 2 2478 4
	movq	-17784(%rbp), %rax
	movl	(%rax), %eax
	movq	-17784(%rbp), %rdx
	movl	4(%rdx), %edx
.LBB532:
	cmpl	%eax, %edx
	.loc 2 2478 4 is_stmt 0 discriminator 3
	cmpl	%eax, %edx
	.loc 2 2478 4 discriminator 6
	cmpl	%eax, %edx
.LBB533:
	.loc 2 2480 11 is_stmt 1 discriminator 1
	movb	$0, -1(%rbp)
.L1894:
.LBB534:
	.loc 2 2485 49
	leaq	-17776(%rbp), %rax
	movzbl	-1(%rbp), %ecx
	movq	-17792(%rbp), %rsi
	movq	-17784(%rbp), %rdx
	movq	%rax, %rdi
	call	silver_output_profile__read_form
	.loc 2 2486 36
	movl	-17776(%rbp), %eax
	.loc 2 2486 13
	testl	%eax, %eax
	je	.L1891
	.loc 2 2486 41 discriminator 1
	movzbl	-16(%rbp), %eax
	testb	%al, %al
	je	.L1891
	.loc 2 2486 69 discriminator 2
	movl	$1, %eax
	jmp	.L1892
.L1891:
.LBE534:
	.loc 2 2480 11 discriminator 2
	cmpb	$1, -1(%rbp)
	je	.L1893
	.loc 2 2480 11 is_stmt 0 discriminator 3
	addb	$1, -1(%rbp)
	.loc 2 2488 15 is_stmt 1
	jmp	.L1894
.L1893:
.LBE533:
	.loc 2 2489 7
	movl	$0, %eax
.L1892:
.LBE532:
	.loc 2 2490 8
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE156:
	.size	silver_output_profile__uses_assignment, .-silver_output_profile__uses_assignment
	.align 2
	.globl	silver_output_profile__uses_output
	.type	silver_output_profile__uses_output, @function
silver_output_profile__uses_output:
.LFB157:
	.loc 2 2492 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$17792, %rsp
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -17792(%rbp)
	movq	%rdx, -17784(%rbp)
	.loc 2 2492 4
	movq	-17784(%rbp), %rax
	movl	(%rax), %eax
	movq	-17784(%rbp), %rdx
	movl	4(%rdx), %edx
.LBB535:
	cmpl	%eax, %edx
	.loc 2 2492 4 is_stmt 0 discriminator 3
	cmpl	%eax, %edx
	.loc 2 2492 4 discriminator 6
	cmpl	%eax, %edx
.LBB536:
	.loc 2 2494 11 is_stmt 1 discriminator 1
	movb	$0, -1(%rbp)
.L1905:
.LBB537:
	.loc 2 2499 49
	leaq	-17776(%rbp), %rax
	movzbl	-1(%rbp), %ecx
	movq	-17792(%rbp), %rsi
	movq	-17784(%rbp), %rdx
	movq	%rax, %rdi
	call	silver_output_profile__read_form
	.loc 2 2500 36
	movl	-17776(%rbp), %eax
	.loc 2 2500 13
	testl	%eax, %eax
	je	.L1902
	.loc 2 2500 41 discriminator 1
	movzbl	-15(%rbp), %eax
	testb	%al, %al
	je	.L1902
	.loc 2 2500 67 discriminator 2
	movl	$1, %eax
	jmp	.L1903
.L1902:
.LBE537:
	.loc 2 2494 11 discriminator 2
	cmpb	$1, -1(%rbp)
	je	.L1904
	.loc 2 2494 11 is_stmt 0 discriminator 3
	addb	$1, -1(%rbp)
	.loc 2 2502 15 is_stmt 1
	jmp	.L1905
.L1904:
.LBE536:
	.loc 2 2503 7
	movl	$0, %eax
.L1903:
.LBE535:
	.loc 2 2504 8
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE157:
	.size	silver_output_profile__uses_output, .-silver_output_profile__uses_output
	.align 2
	.globl	silver_output_profile__allowed_source
	.type	silver_output_profile__allowed_source, @function
silver_output_profile__allowed_source:
.LFB158:
	.loc 2 112 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$32, %rsp
	.cfi_offset 14, -24
	.cfi_offset 13, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -64(%rbp)
	movq	%rdx, -56(%rbp)
	.loc 2 112 4
	movq	-56(%rbp), %rax
	movl	(%rax), %r13d
	movq	-56(%rbp), %rax
	movl	4(%rax), %r12d
.LBB538:
	.loc 2 113 7
	movl	$1, %r14d
	cmpl	%r12d, %r13d
	jg	.L1913
.LBB539:
	.loc 2 113 7 is_stmt 0 discriminator 1
	movl	%r13d, %ebx
.L1912:
.LBB540:
	.loc 2 113 7 discriminator 2
	cmpl	%ebx, %r13d
	jg	.L1908
	.loc 2 113 7 discriminator 3
	cmpl	%ebx, %r12d
	jge	.L1909
.L1908:
	.loc 2 113 7 discriminator 4
	leaq	.LC12(%rip), %rax
	movl	$113, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1909:
	.loc 2 113 15 is_stmt 1 discriminator 5
	movq	-64(%rbp), %rcx
	movq	-56(%rbp), %rax
	movl	(%rax), %eax
	movslq	%eax, %rdx
	movslq	%ebx, %rax
	movq	%rax, %rsi
	subq	%rdx, %rsi
	leaq	(%rcx,%rsi), %rdx
	movq	%rdx, -40(%rbp)
	.loc 2 113 31 discriminator 5
	movq	-64(%rbp), %rdx
	movq	-56(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	subq	%rcx, %rax
	movzbl	(%rdx,%rax), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_allowed_character@PLT
	.loc 2 113 31 is_stmt 0 discriminator 6
	xorl	$1, %eax
	.loc 2 113 7 is_stmt 1 discriminator 6
	testb	%al, %al
	je	.L1910
	.loc 2 113 7 is_stmt 0 discriminator 7
	movl	$0, %r14d
.LBE540:
.LBE539:
	.loc 2 113 7 discriminator 10
	jmp	.L1913
.L1910:
.LBB541:
	.loc 2 113 7 discriminator 8
	cmpl	%r12d, %ebx
	je	.L1913
	.loc 2 113 7 discriminator 9
	addl	$1, %ebx
	jmp	.L1912
.L1913:
.LBE541:
	.loc 2 113 7 discriminator 11
	movl	%r14d, %eax
.LBE538:
	.loc 2 112 4 is_stmt 1
	addq	$32, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE158:
	.size	silver_output_profile__allowed_source, .-silver_output_profile__allowed_source
	.align 2
	.globl	silver_output_profile__valid_mutable_bounds
	.type	silver_output_profile__valid_mutable_bounds, @function
silver_output_profile__valid_mutable_bounds:
.LFB159:
	.loc 2 159 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -40(%rbp)
	.loc 2 160 7
	movl	$1, %ebx
	.loc 2 160 41
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -24(%rbp)
	movl	-24(%rbp), %eax
	cmpl	$341, %eax
	jbe	.L1915
	.loc 2 160 41 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$160, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L1915:
.LBB542:
	.loc 2 160 15 is_stmt 1 discriminator 2
	movl	$1, -20(%rbp)
.L1923:
	.loc 2 160 7 discriminator 3
	movl	-20(%rbp), %eax
	cmpl	-24(%rbp), %eax
	jg	.L1924
.LBB543:
	.loc 2 161 9
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movq	-40(%rbp), %rax
	salq	$5, %rdx
	addq	%rdx, %rax
	movzbl	(%rax), %eax
	testb	%al, %al
	je	.L1917
	.loc 2 162 22
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movq	-40(%rbp), %rax
	subq	$1, %rdx
	salq	$5, %rdx
	addq	%rdx, %rax
	movq	12(%rax), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty@PLT
	.loc 2 162 11 discriminator 1
	xorl	$1, %eax
	xorl	$1, %eax
	.loc 2 164 11
	testb	%al, %al
	jne	.L1918
	.loc 2 163 60
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movq	-40(%rbp), %rax
	subq	$1, %rdx
	salq	$5, %rdx
	addq	%rdx, %rax
	addq	$12, %rax
	movl	(%rax), %edx
	movl	-20(%rbp), %eax
	movslq	%eax, %rcx
	movq	-40(%rbp), %rax
	salq	$5, %rcx
	addq	%rcx, %rax
	subq	$8, %rax
	movl	(%rax), %eax
	.loc 2 163 11
	cmpl	%eax, %edx
	jl	.L1918
	.loc 2 164 60 discriminator 1
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movq	-40(%rbp), %rax
	subq	$1, %rdx
	salq	$5, %rdx
	addq	%rdx, %rax
	addq	$16, %rax
	movl	(%rax), %edx
	movl	-20(%rbp), %eax
	movslq	%eax, %rcx
	movq	-40(%rbp), %rax
	salq	$5, %rcx
	addq	%rcx, %rax
	subq	$4, %rax
	movl	(%rax), %eax
	.loc 2 164 11 discriminator 1
	cmpl	%eax, %edx
	jle	.L1919
.L1918:
	.loc 2 164 11 is_stmt 0 discriminator 2
	movl	$1, %eax
	jmp	.L1921
.L1919:
	.loc 2 164 11 discriminator 3
	movl	$0, %eax
	.loc 2 161 9 is_stmt 1 discriminator 1
	jmp	.L1921
.L1917:
	.loc 2 161 9 is_stmt 0 discriminator 2
	movl	$0, %eax
.L1921:
	.loc 2 160 7 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L1922
	.loc 2 160 7 is_stmt 0 discriminator 5
	movl	$0, %ebx
.LBE543:
.LBE542:
	.loc 2 160 7 discriminator 7
	jmp	.L1924
.L1922:
.LBB544:
	.loc 2 160 7 discriminator 6
	addl	$1, -20(%rbp)
	jmp	.L1923
.L1924:
.LBE544:
	.loc 2 160 7 discriminator 8
	movl	%ebx, %eax
	.loc 2 159 4 is_stmt 1
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE159:
	.size	silver_output_profile__valid_mutable_bounds, .-silver_output_profile__valid_mutable_bounds
	.align 2
	.globl	silver_output_profile__valid_declaration_values
	.type	silver_output_profile__valid_declaration_values, @function
silver_output_profile__valid_declaration_values:
.LFB160:
	.loc 2 165 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -40(%rbp)
	movl	%esi, -44(%rbp)
	.loc 2 168 13
	movq	-40(%rbp), %rax
	movl	(%rax), %eax
	.loc 2 169 7
	cmpl	%eax, -44(%rbp)
	jg	.L1926
	.loc 2 169 17 discriminator 1
	movl	$1, %ebx
	.loc 2 169 25 discriminator 1
	movl	-44(%rbp), %eax
	movl	%eax, -24(%rbp)
.LBB545:
	movl	$1, -20(%rbp)
.L1929:
	.loc 2 169 17 discriminator 2
	movl	-20(%rbp), %eax
	cmpl	-24(%rbp), %eax
	jg	.L1927
	.loc 2 169 59 discriminator 3
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movq	-40(%rbp), %rax
	subq	$1, %rdx
	salq	$5, %rdx
	addq	%rdx, %rax
	movq	12(%rax), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty@PLT
	.loc 2 169 17 discriminator 4
	testb	%al, %al
	je	.L1928
	.loc 2 169 17 is_stmt 0 discriminator 5
	movl	$0, %ebx
	jmp	.L1927
.L1928:
	.loc 2 169 17 discriminator 6
	addl	$1, -20(%rbp)
	jmp	.L1929
.L1927:
.LBE545:
	.loc 2 169 7 is_stmt 1 discriminator 7
	testb	%bl, %bl
	je	.L1926
	.loc 2 169 7 is_stmt 0 discriminator 8
	movl	$1, %eax
	jmp	.L1930
.L1926:
	.loc 2 169 7 discriminator 9
	movl	$0, %eax
.L1930:
	.loc 2 165 4 is_stmt 1
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE160:
	.size	silver_output_profile__valid_declaration_values, .-silver_output_profile__valid_declaration_values
	.align 2
	.globl	silver_output_profile__context_of
	.type	silver_output_profile__context_of, @function
silver_output_profile__context_of:
.LFB161:
	.loc 2 1100 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$10944, %rsp
	movq	%rdi, -10936(%rbp)
	movq	%rsi, -10944(%rbp)
	.loc 2 1101 6
	movq	-10936(%rbp), %rdx
	movq	-10944(%rbp), %rax
	movq	%rdx, %rcx
	addq	$4, %rax
	movl	$6824, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 2 1102 41
	movq	-10944(%rbp), %rax
	leaq	6828(%rax), %rdx
	leaq	-10928(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_scalar_expressions__body_environment@PLT
	.loc 2 1101 6 discriminator 1
	movq	-10936(%rbp), %rax
	leaq	6824(%rax), %rcx
	leaq	-10928(%rbp), %rax
	movl	$10916, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	movq	-10944(%rbp), %rax
	movl	6828(%rax), %edx
	movq	-10936(%rbp), %rax
	movl	%edx, 17740(%rax)
	movq	-10944(%rbp), %rax
	movl	17744(%rax), %edx
	movq	-10936(%rbp), %rax
	movl	%edx, 17744(%rax)
	movq	-10944(%rbp), %rax
	movl	17748(%rax), %edx
	movq	-10936(%rbp), %rax
	movl	%edx, 17748(%rax)
	.loc 2 1100 4
	movq	-10936(%rbp), %rax
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE161:
	.size	silver_output_profile__context_of, .-silver_output_profile__context_of
	.align 2
	.type	silver_output_profile__expand_body, @function
silver_output_profile__expand_body:
.LFB162:
	.loc 2 1165 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rdx, -24(%rbp)
	.loc 2 1166 6
	movq	-24(%rbp), %rax
	movl	4(%rax), %edx
	movq	-8(%rbp), %rax
	movl	%edx, (%rax)
	movq	-8(%rbp), %rax
	movq	-16(%rbp), %rdx
	addq	$4, %rax
	movq	%rdx, %rcx
	movl	$6824, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	movq	-8(%rbp), %rax
	movq	-16(%rbp), %rdx
	addq	$6828, %rax
	leaq	6824(%rdx), %rcx
	movl	$10916, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	movq	-16(%rbp), %rax
	movl	17744(%rax), %edx
	movq	-8(%rbp), %rax
	movl	%edx, 17744(%rax)
	movq	-16(%rbp), %rax
	movl	17748(%rax), %edx
	movq	-8(%rbp), %rax
	movl	%edx, 17748(%rax)
	movq	-24(%rbp), %rax
	movl	8(%rax), %edx
	movq	-8(%rbp), %rax
	movl	%edx, 17752(%rax)
	movq	-24(%rbp), %rax
	movl	12(%rax), %edx
	movq	-8(%rbp), %rax
	movl	%edx, 17756(%rax)
	movq	-24(%rbp), %rax
	movzbl	16(%rax), %edx
	movq	-8(%rbp), %rax
	movb	%dl, 17760(%rax)
	movq	-24(%rbp), %rax
	movzbl	17(%rax), %edx
	movq	-8(%rbp), %rax
	movb	%dl, 17761(%rax)
	.loc 2 1165 4
	movq	-8(%rbp), %rax
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE162:
	.size	silver_output_profile__expand_body, .-silver_output_profile__expand_body
	.align 2
	.globl	silver_output_profile__included
	.type	silver_output_profile__included, @function
silver_output_profile__included:
.LFB163:
	.loc 2 1182 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	.loc 2 1183 14
	movq	-8(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty@PLT
	.loc 2 1184 7
	testb	%al, %al
	jne	.L1937
	.loc 2 1184 27 discriminator 1
	movq	-16(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty@PLT
	.loc 2 1184 16 discriminator 2
	xorl	$1, %eax
	.loc 2 1184 7 discriminator 2
	testb	%al, %al
	je	.L1938
	.loc 2 1184 67 discriminator 3
	movl	-8(%rbp), %edx
	movl	-16(%rbp), %eax
	.loc 2 1184 46 discriminator 3
	cmpl	%eax, %edx
	jl	.L1938
	.loc 2 1185 30
	movl	-4(%rbp), %edx
	movl	-12(%rbp), %eax
	.loc 2 1185 9
	cmpl	%eax, %edx
	jg	.L1938
.L1937:
	.loc 2 1184 7 discriminator 4
	movl	$1, %eax
	jmp	.L1939
.L1938:
	.loc 2 1184 7 is_stmt 0 discriminator 5
	movl	$0, %eax
.L1939:
	.loc 2 1182 4 is_stmt 1
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE163:
	.size	silver_output_profile__included, .-silver_output_profile__included
	.align 2
	.globl	silver_output_profile__valid_flow
	.type	silver_output_profile__valid_flow, @function
silver_output_profile__valid_flow:
.LFB164:
	.loc 2 1186 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 3, -24
	movq	%rdi, -40(%rbp)
	movq	%rsi, -48(%rbp)
	.loc 2 1187 19
	movq	-48(%rbp), %rax
	movl	(%rax), %edx
	movq	-40(%rbp), %rax
	movl	6824(%rax), %eax
	.loc 2 1188 7
	cmpl	%eax, %edx
	jne	.L1942
	.loc 2 1188 17 discriminator 1
	movl	$1, %ebx
	.loc 2 1188 25 discriminator 1
	movq	-48(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -24(%rbp)
	.loc 2 1188 17 discriminator 1
	cmpl	$0, -24(%rbp)
	jle	.L1943
.LBB546:
	.loc 2 1188 25 discriminator 2
	movl	$1, -20(%rbp)
.L1962:
.LBB547:
	.loc 2 1189 33
	cmpl	$341, -20(%rbp)
	jle	.L1944
	.loc 2 1189 33 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1189, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1944:
	.loc 2 1189 10 is_stmt 1 discriminator 2
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movq	-40(%rbp), %rax
	salq	$5, %rdx
	addq	%rdx, %rax
	addq	$6824, %rax
	movzbl	(%rax), %eax
	testb	%al, %al
	je	.L1945
	.loc 2 1190 39
	movq	-48(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, -20(%rbp)
	jle	.L1946
	.loc 2 1190 39 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1190, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1946:
	.loc 2 1190 23 is_stmt 1 discriminator 2
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movq	-48(%rbp), %rax
	addq	$1, %rdx
	movq	(%rax,%rdx,8), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty@PLT
	.loc 2 1190 12 discriminator 3
	xorl	$1, %eax
	xorl	$1, %eax
	.loc 2 1191 12
	testb	%al, %al
	jne	.L1947
	.loc 2 1191 36 discriminator 1
	movq	-48(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, -20(%rbp)
	jle	.L1948
	.loc 2 1191 36 is_stmt 0 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$1191, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1948:
	.loc 2 1191 73 is_stmt 1 discriminator 3
	cmpl	$341, -20(%rbp)
	jle	.L1949
	.loc 2 1191 73 is_stmt 0 discriminator 4
	leaq	.LC12(%rip), %rax
	movl	$1191, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1949:
	.loc 2 1191 21 is_stmt 1 discriminator 5
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movl	-20(%rbp), %eax
	movslq	%eax, %rcx
	movq	-40(%rbp), %rax
	salq	$5, %rdx
	addq	%rdx, %rax
	addq	$6800, %rax
	movq	16(%rax), %rdx
	movq	-48(%rbp), %rax
	addq	$1, %rcx
	movq	(%rax,%rcx,8), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__included
	.loc 2 1191 21 is_stmt 0 discriminator 6
	xorl	$1, %eax
	.loc 2 1191 12 is_stmt 1 discriminator 6
	testb	%al, %al
	je	.L1950
.L1947:
	.loc 2 1191 12 is_stmt 0 discriminator 7
	movl	$1, %eax
	jmp	.L1952
.L1950:
	.loc 2 1191 12 discriminator 8
	movl	$0, %eax
	.loc 2 1189 10 is_stmt 1 discriminator 3
	jmp	.L1952
.L1945:
	.loc 2 1192 22
	movq	-40(%rbp), %rax
	movl	17740(%rax), %eax
	.loc 2 1192 10
	cmpl	%eax, -20(%rbp)
	jle	.L1953
	.loc 2 1193 27
	movq	-48(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, -20(%rbp)
	jle	.L1954
	.loc 2 1193 27 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1193, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1954:
	.loc 2 1193 64 is_stmt 1 discriminator 2
	cmpl	$341, -20(%rbp)
	jle	.L1955
	.loc 2 1193 64 is_stmt 0 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$1193, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1955:
	.loc 2 1193 12 is_stmt 1 discriminator 4
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movl	-20(%rbp), %eax
	movslq	%eax, %rcx
	movq	-40(%rbp), %rax
	addq	$212, %rdx
	salq	$5, %rdx
	addq	%rdx, %rax
	movq	20(%rax), %rdx
	movq	-48(%rbp), %rax
	addq	$1, %rcx
	movq	(%rax,%rcx,8), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__included
	.loc 2 1189 10 discriminator 4
	xorl	$1, %eax
	jmp	.L1952
.L1953:
	.loc 2 1194 20
	movq	-48(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, -20(%rbp)
	jle	.L1956
	.loc 2 1194 20 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1194, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1956:
	.loc 2 1194 58 is_stmt 1 discriminator 2
	cmpl	$341, -20(%rbp)
	jle	.L1957
	.loc 2 1194 58 is_stmt 0 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$1194, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L1957:
	.loc 2 1194 36 is_stmt 1 discriminator 4
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movq	-48(%rbp), %rax
	addq	$1, %rdx
	movl	(%rax,%rdx,8), %edx
	movl	-20(%rbp), %eax
	movslq	%eax, %rcx
	movq	-40(%rbp), %rax
	addq	$212, %rcx
	salq	$5, %rcx
	addq	%rcx, %rax
	addq	$20, %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jne	.L1958
	.loc 2 1194 36 is_stmt 0 discriminator 5
	movl	-20(%rbp), %eax
	movslq	%eax, %rdx
	movq	-48(%rbp), %rax
	addq	$1, %rdx
	movl	4(%rax,%rdx,8), %edx
	movl	-20(%rbp), %eax
	movslq	%eax, %rcx
	movq	-40(%rbp), %rax
	addq	$212, %rcx
	salq	$5, %rcx
	addq	%rcx, %rax
	addq	$24, %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jne	.L1958
	.loc 2 1194 36 discriminator 6
	movl	$1, %eax
	jmp	.L1959
.L1958:
	.loc 2 1194 36 discriminator 7
	movl	$0, %eax
.L1959:
	.loc 2 1189 10 is_stmt 1 discriminator 5
	xorl	$1, %eax
.L1952:
	.loc 2 1188 17 discriminator 3
	testb	%al, %al
	je	.L1960
	.loc 2 1188 17 is_stmt 0 discriminator 4
	movl	$0, %ebx
	jmp	.L1943
.L1960:
.LBE547:
	.loc 2 1188 17 discriminator 5
	movl	-20(%rbp), %eax
	cmpl	-24(%rbp), %eax
	je	.L1943
	.loc 2 1188 17 discriminator 6
	addl	$1, -20(%rbp)
	jmp	.L1962
.L1943:
.LBE546:
	.loc 2 1188 7 is_stmt 1 discriminator 7
	testb	%bl, %bl
	je	.L1942
	.loc 2 1188 7 is_stmt 0 discriminator 8
	movl	$1, %eax
	jmp	.L1963
.L1942:
	.loc 2 1188 7 discriminator 9
	movl	$0, %eax
.L1963:
	.loc 2 1186 4 is_stmt 1
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE164:
	.size	silver_output_profile__valid_flow, .-silver_output_profile__valid_flow
	.align 2
	.globl	silver_output_profile__summary_of
	.type	silver_output_profile__summary_of, @function
silver_output_profile__summary_of:
.LFB165:
	.loc 2 1361 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	.loc 2 1362 6
	movq	-8(%rbp), %rcx
	movl	4(%rcx), %ecx
	movl	%ecx, %esi
	movq	%rax, %rdi
	movabsq	$-4294967296, %rcx
	andq	%rdi, %rcx
	orq	%rsi, %rcx
	movq	%rcx, %rax
	movq	-8(%rbp), %rcx
	movl	8(%rcx), %ecx
	movl	%ecx, %ecx
	salq	$32, %rcx
	movq	%rax, %rsi
	movl	%esi, %esi
	orq	%rsi, %rcx
	movq	%rcx, %rax
	movq	-8(%rbp), %rcx
	movl	12(%rcx), %ecx
	movl	%ecx, %esi
	movq	%rdx, %rdi
	movabsq	$-4294967296, %rcx
	andq	%rdi, %rcx
	orq	%rsi, %rcx
	movq	%rcx, %rdx
	movq	-8(%rbp), %rcx
	movzbl	17(%rcx), %ecx
	movzbl	%cl, %ecx
	salq	$32, %rcx
	movq	%rdx, %rdi
	movabsq	$-1095216660481, %rsi
	andq	%rdi, %rsi
	orq	%rsi, %rcx
	movq	%rcx, %rdx
	.loc 2 1361 4
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE165:
	.size	silver_output_profile__summary_of, .-silver_output_profile__summary_of
	.align 2
	.globl	silver_output_profile__bound_of
	.type	silver_output_profile__bound_of, @function
silver_output_profile__bound_of:
.LFB166:
	.loc 2 1363 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	.loc 2 1364 6
	movq	-8(%rbp), %rax
	movl	12(%rax), %eax
	movl	%eax, %ecx
	movabsq	$-4294967296, %rax
	andq	%rdx, %rax
	orq	%rcx, %rax
	movq	%rax, %rdx
	movq	-8(%rbp), %rax
	movzbl	16(%rax), %eax
	movzbl	%al, %eax
	salq	$32, %rax
	movabsq	$-1095216660481, %rcx
	andq	%rcx, %rdx
	orq	%rdx, %rax
	movq	%rax, %rdx
	.loc 2 1364 6 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	.loc 2 1363 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE166:
	.size	silver_output_profile__bound_of, .-silver_output_profile__bound_of
	.align 2
	.type	silver_output_profile__binding_summary, @function
silver_output_profile__binding_summary:
.LFB167:
	.loc 2 1365 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	.loc 2 1366 8
	movq	-8(%rbp), %rcx
	movzbl	16(%rcx), %ecx
	testb	%cl, %cl
	je	.L1970
	.loc 2 1366 8 is_stmt 0 discriminator 1
	movl	$0, %ecx
	jmp	.L1971
.L1970:
	.loc 2 1366 8 discriminator 2
	movq	-8(%rbp), %rcx
	movl	12(%rcx), %ecx
.L1971:
	.loc 2 1366 6 is_stmt 1 discriminator 3
	movl	%ecx, %esi
	movq	%rax, %rdi
	movabsq	$-4294967296, %rcx
	andq	%rdi, %rcx
	orq	%rsi, %rcx
	movq	%rcx, %rax
	.loc 2 1367 8
	movq	-8(%rbp), %rcx
	movzbl	16(%rcx), %ecx
	testb	%cl, %cl
	je	.L1972
	.loc 2 1367 8 is_stmt 0 discriminator 1
	movl	$0, %ecx
	jmp	.L1973
.L1972:
	.loc 2 1367 8 discriminator 2
	movq	-8(%rbp), %rcx
	movl	12(%rcx), %ecx
.L1973:
	.loc 2 1366 6 is_stmt 1 discriminator 4
	movl	%ecx, %ecx
	salq	$32, %rcx
	movq	%rax, %rsi
	movl	%esi, %esi
	orq	%rsi, %rcx
	movq	%rcx, %rax
	.loc 2 1367 60 discriminator 3
	movq	-8(%rbp), %rcx
	movzbl	16(%rcx), %ecx
	testb	%cl, %cl
	je	.L1974
	.loc 2 1367 60 is_stmt 0 discriminator 4
	movl	$1, %ecx
	jmp	.L1975
.L1974:
	.loc 2 1367 60 discriminator 5
	movl	$0, %ecx
.L1975:
	.loc 2 1366 6 is_stmt 1 discriminator 5
	movl	%ecx, %esi
	movq	%rdx, %rdi
	movabsq	$-4294967296, %rcx
	andq	%rdi, %rcx
	orq	%rsi, %rcx
	movq	%rcx, %rdx
	movq	%rdx, %rsi
	movabsq	$-1095216660481, %rcx
	andq	%rsi, %rcx
	movq	%rcx, %rdx
	.loc 2 1365 4
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE167:
	.size	silver_output_profile__binding_summary, .-silver_output_profile__binding_summary
	.align 2
	.type	silver_output_profile__valid_condition, @function
silver_output_profile__valid_condition:
.LFB168:
	.loc 2 1434 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%rdi, -8(%rbp)
	movq	%rsi, -16(%rbp)
	.loc 2 1435 7
	movq	-16(%rbp), %rax
	leaq	8(%rax), %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__valid_flow
	.loc 2 1435 46 discriminator 1
	testb	%al, %al
	je	.L1978
	.loc 2 1435 55 discriminator 2
	movq	-16(%rbp), %rax
	movl	(%rax), %eax
	cltq
	addq	$3, %rax
	salq	$3, %rax
	shrq	$2, %rax
	leaq	0(,%rax,4), %rdx
	movq	-16(%rbp), %rax
	addq	%rax, %rdx
	movq	-8(%rbp), %rax
	movq	%rdx, %rsi
	movq	%rax, %rdi
	call	silver_output_profile__valid_flow
	.loc 2 1435 46 discriminator 3
	testb	%al, %al
	je	.L1978
	.loc 2 1435 46 is_stmt 0 discriminator 4
	movl	$1, %eax
	jmp	.L1979
.L1978:
	.loc 2 1435 46 discriminator 5
	movl	$0, %eax
.L1979:
	.loc 2 1434 4 is_stmt 1
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE168:
	.size	silver_output_profile__valid_condition, .-silver_output_profile__valid_condition
	.align 2
	.globl	silver_output_profile__scalar_operator
	.type	silver_output_profile__scalar_operator, @function
silver_output_profile__scalar_operator:
.LFB169:
	.loc 2 1447 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movb	%dil, -1(%rbp)
	.loc 2 1448 12
	cmpb	$5, -1(%rbp)
	jbe	.L1982
	.loc 2 1448 12 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$1448, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L1982:
	.loc 2 1448 12 discriminator 2
	cmpb	$5, -1(%rbp)
	jbe	.L1983
	.loc 2 1448 12 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$1448, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L1983:
	.loc 2 1448 7 is_stmt 1 discriminator 4
	cmpb	$4, -1(%rbp)
	je	.L1984
	cmpb	$4, -1(%rbp)
	ja	.L1985
	cmpb	$3, -1(%rbp)
	je	.L1986
	cmpb	$3, -1(%rbp)
	ja	.L1985
	cmpb	$2, -1(%rbp)
	je	.L1987
	cmpb	$2, -1(%rbp)
	ja	.L1985
	cmpb	$0, -1(%rbp)
	je	.L1988
	cmpb	$1, -1(%rbp)
	je	.L1989
	jmp	.L1985
.L1988:
	.loc 2 1449 36
	movl	$0, %eax
	jmp	.L1990
.L1989:
	.loc 2 1449 73 discriminator 1
	movl	$1, %eax
	jmp	.L1990
.L1987:
	.loc 2 1450 35
	movl	$2, %eax
	jmp	.L1990
.L1986:
	.loc 2 1450 74 discriminator 1
	movl	$3, %eax
	jmp	.L1990
.L1984:
	.loc 2 1451 38
	movl	$4, %eax
	jmp	.L1990
.L1985:
	.loc 2 1451 83 discriminator 1
	movl	$5, %eax
.L1990:
	.loc 2 1447 4
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE169:
	.size	silver_output_profile__scalar_operator, .-silver_output_profile__scalar_operator
	.align 2
	.globl	silver_output_profile__refine_or_keep
	.type	silver_output_profile__refine_or_keep, @function
silver_output_profile__refine_or_keep:
.LFB170:
	.loc 2 1452 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, -24(%rbp)
	movb	%sil, -25(%rbp)
	movl	%edx, -32(%rbp)
	movb	%cl, -26(%rbp)
	.loc 2 1455 61
	movzbl	-26(%rbp), %ecx
	movl	-32(%rbp), %edx
	movzbl	-25(%rbp), %esi
	movq	-24(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__refine@PLT
	movq	%rax, -16(%rbp)
	.loc 2 1456 24
	movq	-16(%rbp), %rax
	movq	%rax, %rdi
	call	silver_scalars__is_empty@PLT
	.loc 2 1456 14 discriminator 1
	testb	%al, %al
	je	.L1992
	.loc 2 1456 14 is_stmt 0 discriminator 2
	movq	-24(%rbp), %rax
	movq	%rax, -8(%rbp)
	jmp	.L1993
.L1992:
	.loc 2 1456 14 discriminator 3
	movq	-16(%rbp), %rax
	movq	%rax, -8(%rbp)
.L1993:
	.loc 2 1456 14 discriminator 4
	leaq	-8(%rbp), %rax
	.loc 2 1455 7 is_stmt 1 discriminator 1
	movq	(%rax), %rax
	.loc 2 1452 4
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE170:
	.size	silver_output_profile__refine_or_keep, .-silver_output_profile__refine_or_keep
	.align 2
	.globl	silver_output_profile___elabb
	.type	silver_output_profile___elabb, @function
silver_output_profile___elabb:
.LFB0:
	.loc 2 15 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	.loc 2 131 6
	movl	$0, silver_output_profile__empty_environment(%rip)
.LBB548:
	.loc 2 131 28
	movl	$1, %ecx
.L1997:
	.loc 2 131 28 is_stmt 0 discriminator 1
	cmpl	$341, %ecx
	jg	.L1996
	.loc 2 131 28 discriminator 2
	movslq	%ecx, %rax
	leaq	-1(%rax), %rsi
	movq	%rsi, %rdx
	salq	$2, %rdx
	addq	%rsi, %rdx
	salq	$2, %rdx
	movq	%rdx, %rsi
	leaq	4+silver_output_profile__empty_environment(%rip), %rdx
	movl	$0, (%rsi,%rdx)
	leaq	-1(%rax), %rsi
	movq	%rsi, %rdx
	salq	$2, %rdx
	addq	%rsi, %rdx
	salq	$2, %rdx
	movq	%rdx, %rsi
	leaq	8+silver_output_profile__empty_environment(%rip), %rdx
	movl	$0, (%rsi,%rdx)
	leaq	-1(%rax), %rsi
	movq	%rsi, %rdx
	salq	$2, %rdx
	addq	%rsi, %rdx
	salq	$2, %rdx
	movq	%rdx, %rsi
	leaq	12+silver_output_profile__empty_environment(%rip), %rdx
	movl	$0, (%rsi,%rdx)
	leaq	-1(%rax), %rsi
	movq	%rsi, %rdx
	salq	$2, %rdx
	addq	%rsi, %rdx
	salq	$2, %rdx
	movq	%rdx, %rsi
	leaq	16+silver_output_profile__empty_environment(%rip), %rdx
	movl	$0, (%rsi,%rdx)
	movq	%rax, %rdx
	salq	$2, %rdx
	addq	%rax, %rdx
	salq	$2, %rdx
	movq	%rdx, %rsi
	leaq	silver_output_profile__empty_environment(%rip), %rdx
	movb	$0, (%rsi,%rdx)
	movq	%rax, %rdx
	salq	$2, %rdx
	addq	%rax, %rdx
	leaq	0(,%rdx,4), %rax
	movq	%rax, %rdx
	leaq	1+silver_output_profile__empty_environment(%rip), %rax
	movb	$0, (%rdx,%rax)
	addl	$1, %ecx
	jmp	.L1997
.L1996:
.LBE548:
	.loc 2 150 4 is_stmt 1
	movl	$1, silver_output_profile__initial_state(%rip)
	leaq	4+silver_output_profile__initial_state(%rip), %rax
	leaq	silver_output_profile__empty_environment(%rip), %rcx
	movl	$6824, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	leaq	6828+silver_output_profile__initial_state(%rip), %rax
	leaq	silver_scalar_expressions__empty_environment(%rip), %rcx
	movl	$10916, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	movl	$0, 17744+silver_output_profile__initial_state(%rip)
	movl	$0, 17748+silver_output_profile__initial_state(%rip)
	movl	$0, 17752+silver_output_profile__initial_state(%rip)
	movl	$4096, 17756+silver_output_profile__initial_state(%rip)
	.loc 2 154 4
	movl	$0, silver_output_profile__invalid_state(%rip)
	leaq	4+silver_output_profile__invalid_state(%rip), %rax
	leaq	silver_output_profile__empty_environment(%rip), %rcx
	movl	$6824, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	leaq	6828+silver_output_profile__invalid_state(%rip), %rax
	leaq	silver_scalar_expressions__empty_environment(%rip), %rcx
	movl	$10916, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	movl	$0, 17744+silver_output_profile__invalid_state(%rip)
	movl	$0, 17748+silver_output_profile__invalid_state(%rip)
	movl	$0, 17752+silver_output_profile__invalid_state(%rip)
	movl	$0, 17756+silver_output_profile__invalid_state(%rip)
	.loc 2 1068 4
	leaq	silver_output_profile__initial_scan(%rip), %rax
	leaq	silver_output_profile__initial_state(%rip), %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	movb	$0, 17760+silver_output_profile__initial_scan(%rip)
	movb	$0, 17761+silver_output_profile__initial_scan(%rip)
	.loc 2 1070 4
	leaq	silver_output_profile__invalid_scan(%rip), %rax
	leaq	silver_output_profile__invalid_state(%rip), %rcx
	movl	$17760, %edx
	movq	%rcx, %rsi
	movq	%rax, %rdi
	call	memcpy@PLT
	movb	$0, 17760+silver_output_profile__invalid_scan(%rip)
	movb	$0, 17761+silver_output_profile__invalid_scan(%rip)
	.loc 2 2505 5
	nop
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE0:
	.size	silver_output_profile___elabb, .-silver_output_profile___elabb
	.globl	silver_output_profile_E
	.data
	.align 2
	.type	silver_output_profile_E, @object
	.size	silver_output_profile_E, 2
silver_output_profile_E:
	.zero	2
	.globl	silver_output_profile__max_source_length
	.section	.rodata
	.align 4
	.type	silver_output_profile__max_source_length, @object
	.size	silver_output_profile__max_source_length, 4
silver_output_profile__max_source_length:
	.long	4096
	.globl	silver_output_profile__max_expression_operands
	.align 4
	.type	silver_output_profile__max_expression_operands, @object
	.size	silver_output_profile__max_expression_operands, 4
silver_output_profile__max_expression_operands:
	.long	64
	.globl	silver_output_profile__max_concatenations
	.align 4
	.type	silver_output_profile__max_concatenations, @object
	.size	silver_output_profile__max_concatenations, 4
silver_output_profile__max_concatenations:
	.long	63
	.globl	silver_output_profile__max_bindings
	.align 4
	.type	silver_output_profile__max_bindings, @object
	.size	silver_output_profile__max_bindings, 4
silver_output_profile__max_bindings:
	.long	341
	.globl	silver_output_profile__comment_introducer
	.align 2
	.type	silver_output_profile__comment_introducer, @object
	.size	silver_output_profile__comment_introducer, 2
silver_output_profile__comment_introducer:
	.ascii	"--"
	.globl	silver_output_profile__form_kindS
	.align 16
	.type	silver_output_profile__form_kindS, @object
	.size	silver_output_profile__form_kindS, 24
silver_output_profile__form_kindS:
	.ascii	"DIRECT_FORMARGUMENT_FORM"
	.globl	silver_output_profile__form_kindN
	.align 4
	.type	silver_output_profile__form_kindN, @object
	.size	silver_output_profile__form_kindN, 4
silver_output_profile__form_kindN:
	.byte	1
	.byte	12
	.byte	25
	.zero	1
	.globl	silver_output_profile__token_kindS
	.align 32
	.type	silver_output_profile__token_kindS, @object
	.size	silver_output_profile__token_kindS, 728
silver_output_profile__token_kindS:
	.ascii	"WITH_KEYWORDIO_NAMEPROCEDURE_KEYWORDMAIN_NAMEIS_KEYWORDPRAGM"
	.ascii	"A_KEYWORDSPARK_MODE_NAMEON_NAMEBEGIN_KEYWORDPUT_LINE_NAMEEND"
	.ascii	"_KEYWORDLEFT_PARENTHESISRIGHT_PARENTHESISSEMICOLONDOTSTRING_"
	.ascii	"LITERALCOLONCONSTANT_KEYWORDSTRING_NAMEASSIGNMENTARGUMENTS_N"
	.ascii	"AMEFIRST_OR_DEFAULT_NAMEIF_KEYWORDINPUT_IS_VALID_NAMETHEN_KE"
	.ascii	"YWORDELSE_KEYWORDELSIF_KEYWORDREJECT_NAMEAMPERSANDAND_KEYWOR"
	.ascii	"DOR_KEYWORDNOT_KEYWORDNOT_EQUALLESSGREATERGREATER_EQUALAPOST"
	.ascii	"ROPHELENGTH_NAMELESS_EQUALCAPACITY_LITERALEQUALARGUMENT_DECL"
	.ascii	"ARATIONDECLARATIONSASSIGNMENT_TARGETTARGET_REFERENCEDYNAMIC_"
	.ascii	"REFERENCEASSIGNMENT_VALUEOUTPUT_EXPRESSIONCOMPARISON_EXPRESS"
	.ascii	"IONNULL_KEYWORDSTATEMENTSCONTEXT_CLAUSESINTEGER_NAMEFOR_KEYW"
	.ascii	"ORDIN_KEYWORDREVERSE_KEYWORDLOOP_KEYWORDRANGE_DELIMITERRANGE"
	.ascii	"_KEYWORD"
	.globl	silver_output_profile__token_kindN
	.align 32
	.type	silver_output_profile__token_kindN, @object
	.size	silver_output_profile__token_kindN, 120
silver_output_profile__token_kindN:
	.value	1
	.value	13
	.value	20
	.value	37
	.value	46
	.value	56
	.value	70
	.value	85
	.value	92
	.value	105
	.value	118
	.value	129
	.value	145
	.value	162
	.value	171
	.value	174
	.value	188
	.value	193
	.value	209
	.value	220
	.value	230
	.value	244
	.value	265
	.value	275
	.value	294
	.value	306
	.value	318
	.value	331
	.value	342
	.value	351
	.value	362
	.value	372
	.value	383
	.value	392
	.value	396
	.value	403
	.value	416
	.value	426
	.value	437
	.value	447
	.value	463
	.value	468
	.value	488
	.value	500
	.value	517
	.value	533
	.value	550
	.value	566
	.value	583
	.value	604
	.value	616
	.value	626
	.value	641
	.value	653
	.value	664
	.value	674
	.value	689
	.value	701
	.value	716
	.value	729
	.globl	silver_output_profile__empty_binding
	.align 16
	.type	silver_output_profile__empty_binding, @object
	.size	silver_output_profile__empty_binding, 20
silver_output_profile__empty_binding:
	.zero	20
	.globl	silver_output_profile__empty_environment
	.bss
	.align 32
	.type	silver_output_profile__empty_environment, @object
	.size	silver_output_profile__empty_environment, 6824
silver_output_profile__empty_environment:
	.zero	6824
	.globl	silver_output_profile__initial_state
	.align 32
	.type	silver_output_profile__initial_state, @object
	.size	silver_output_profile__initial_state, 17760
silver_output_profile__initial_state:
	.zero	17760
	.globl	silver_output_profile__invalid_state
	.align 32
	.type	silver_output_profile__invalid_state, @object
	.size	silver_output_profile__invalid_state, 17760
silver_output_profile__invalid_state:
	.zero	17760
	.globl	silver_output_profile__invalid_value
	.section	.rodata
	.align 16
	.type	silver_output_profile__invalid_value, @object
	.size	silver_output_profile__invalid_value, 24
silver_output_profile__invalid_value:
	.zero	24
	.globl	silver_output_profile__invalid_expression
	.align 16
	.type	silver_output_profile__invalid_expression, @object
	.size	silver_output_profile__invalid_expression, 20
silver_output_profile__invalid_expression:
	.zero	20
	.globl	silver_output_profile__invalid_expression_state
	.align 16
	.type	silver_output_profile__invalid_expression_state, @object
	.size	silver_output_profile__invalid_expression_state, 28
silver_output_profile__invalid_expression_state:
	.long	0
	.long	0
	.long	0
	.long	0
	.long	0
	.long	0
	.byte	0
	.byte	1
	.byte	0
	.byte	0
	.globl	silver_output_profile__initial_scan
	.bss
	.align 32
	.type	silver_output_profile__initial_scan, @object
	.size	silver_output_profile__initial_scan, 17764
silver_output_profile__initial_scan:
	.zero	17764
	.globl	silver_output_profile__invalid_scan
	.align 32
	.type	silver_output_profile__invalid_scan, @object
	.size	silver_output_profile__invalid_scan, 17764
silver_output_profile__invalid_scan:
	.zero	17764
	.globl	silver_output_profile__body_stopS
	.section	.rodata
	.align 16
	.type	silver_output_profile__body_stopS, @object
	.size	silver_output_profile__body_stopS, 29
silver_output_profile__body_stopS:
	.ascii	"END_ONLYELSE_ONLYARM_BOUNDARY"
	.globl	silver_output_profile__body_stopN
	.align 4
	.type	silver_output_profile__body_stopN, @object
	.size	silver_output_profile__body_stopN, 4
silver_output_profile__body_stopN:
	.byte	1
	.byte	9
	.byte	18
	.byte	30
	.align 16
	.type	token_kindP.55, @object
	.size	token_kindP.55, 20
token_kindP.55:
	.long	1
	.long	2
	.long	3
	.long	9
	.long	12
	.align 8
	.type	token_kindT1.54, @object
	.size	token_kindT1.54, 8
token_kindT1.54:
	.byte	7
	.byte	70
	.byte	78
	.byte	3
	.byte	56
	.zero	3
	.align 8
	.type	token_kindT2.53, @object
	.size	token_kindT2.53, 8
token_kindT2.53:
	.byte	60
	.byte	23
	.byte	24
	.byte	67
	.byte	96
	.zero	3
	.align 32
	.type	token_kindG.52, @object
	.size	token_kindG.52, 119
token_kindG.52:
	.byte	47
	.byte	30
	.byte	44
	.byte	0
	.byte	0
	.byte	52
	.byte	1
	.byte	0
	.byte	0
	.byte	51
	.byte	0
	.byte	0
	.byte	0
	.byte	46
	.byte	0
	.byte	0
	.byte	0
	.byte	7
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	1
	.byte	0
	.byte	40
	.byte	0
	.byte	36
	.byte	33
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	53
	.byte	32
	.byte	0
	.byte	0
	.byte	0
	.byte	25
	.byte	0
	.byte	16
	.byte	0
	.byte	9
	.byte	42
	.byte	38
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	4
	.byte	24
	.byte	34
	.byte	38
	.byte	6
	.byte	0
	.byte	10
	.byte	54
	.byte	3
	.byte	14
	.byte	0
	.byte	42
	.byte	27
	.byte	13
	.byte	0
	.byte	21
	.byte	40
	.byte	0
	.byte	0
	.byte	55
	.byte	0
	.byte	11
	.byte	21
	.byte	0
	.byte	0
	.byte	0
	.byte	10
	.byte	18
	.byte	0
	.byte	0
	.byte	57
	.byte	24
	.byte	48
	.byte	39
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	6
	.byte	0
	.byte	0
	.byte	7
	.byte	22
	.byte	17
	.byte	0
	.byte	0
	.byte	8
	.byte	40
	.byte	0
	.byte	0
	.byte	40
	.byte	0
	.byte	0
	.byte	14
	.byte	2
	.byte	31
	.byte	49
	.byte	50
	.byte	0
	.byte	0
	.byte	3
	.byte	54
	.byte	0
	.byte	37
	.byte	38
	.text
.Letext0:
	.file 3 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_scalars.ads"
	.file 4 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_scalar_expressions.ads"
	.file 5 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_names.ads"
	.file 6 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_path_facts.ads"
	.file 7 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_length_intervals.ads"
	.file 8 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_scalar_literals.ads"
	.file 9 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_output_lexical.ads"
	.file 10 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_integer_literals.ads"
	.file 11 "<built-in>"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x428d
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x34
	.long	.LASF453
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.long	.LLRL6
	.quad	0
	.long	.Ldebug_line0
	.uleb128 0x12
	.long	.LASF2
	.byte	0x1
	.byte	0x6
	.long	0x4d
	.uleb128 0x9
	.byte	0x3
	.quad	silver_output_profile__max_source_length
	.uleb128 0x20
	.sleb128 2147483647
	.long	.LASF113
	.long	0x52
	.uleb128 0xd
	.long	0x3f
	.uleb128 0x18
	.byte	0x4
	.byte	0x5
	.long	.LASF12
	.uleb128 0x12
	.long	.LASF3
	.byte	0x1
	.byte	0x7
	.long	0x4d
	.uleb128 0x9
	.byte	0x3
	.quad	silver_output_profile__max_expression_operands
	.uleb128 0x12
	.long	.LASF4
	.byte	0x1
	.byte	0xa
	.long	0x4d
	.uleb128 0x9
	.byte	0x3
	.quad	silver_output_profile__max_concatenations
	.uleb128 0x12
	.long	.LASF5
	.byte	0x1
	.byte	0xd
	.long	0x4d
	.uleb128 0x9
	.byte	0x3
	.quad	silver_output_profile__max_bindings
	.uleb128 0xe
	.long	.LASF6
	.byte	0x14
	.byte	0x4
	.long	0xa6
	.uleb128 0x2
	.byte	0x9
	.byte	0xff
	.uleb128 0x35
	.byte	0x1
	.sleb128 0
	.long	.LASF454
	.long	0x52
	.uleb128 0xe
	.long	.LASF7
	.byte	0x15
	.byte	0x4
	.long	0xa6
	.uleb128 0x2
	.byte	0x9
	.byte	0xff
	.uleb128 0xe
	.long	.LASF8
	.byte	0x16
	.byte	0x4
	.long	0xa6
	.uleb128 0x2
	.byte	0x9
	.byte	0xff
	.uleb128 0xe
	.long	.LASF9
	.byte	0x17
	.byte	0x4
	.long	0xa6
	.uleb128 0x2
	.byte	0x9
	.byte	0xff
	.uleb128 0xe
	.long	.LASF10
	.byte	0x18
	.byte	0x4
	.long	0xa6
	.uleb128 0x2
	.byte	0x9
	.byte	0xff
	.uleb128 0x2
	.long	.LASF11
	.value	0x438
	.byte	0x4
	.long	0xa6
	.uleb128 0x2
	.byte	0x9
	.byte	0xff
	.uleb128 0x15
	.long	0x10d
	.long	0x108
	.uleb128 0x21
	.long	0x52
	.sleb128 2
	.byte	0
	.uleb128 0x5
	.long	0xf8
	.uleb128 0x18
	.byte	0x1
	.byte	0x8
	.long	.LASF13
	.uleb128 0x1a
	.long	.LASF16
	.byte	0x1
	.byte	0x2a
	.long	0x12c
	.uleb128 0x3
	.long	.LASF14
	.byte	0
	.uleb128 0x3
	.long	.LASF15
	.byte	0x1
	.byte	0
	.uleb128 0xd
	.long	0x114
	.uleb128 0x1a
	.long	.LASF17
	.byte	0x1
	.byte	0x10
	.long	0x29f
	.uleb128 0x3
	.long	.LASF18
	.byte	0
	.uleb128 0x3
	.long	.LASF19
	.byte	0x1
	.uleb128 0x3
	.long	.LASF20
	.byte	0x2
	.uleb128 0x3
	.long	.LASF21
	.byte	0x3
	.uleb128 0x3
	.long	.LASF22
	.byte	0x4
	.uleb128 0x3
	.long	.LASF23
	.byte	0x5
	.uleb128 0x3
	.long	.LASF24
	.byte	0x6
	.uleb128 0x3
	.long	.LASF25
	.byte	0x7
	.uleb128 0x3
	.long	.LASF26
	.byte	0x8
	.uleb128 0x3
	.long	.LASF27
	.byte	0x9
	.uleb128 0x3
	.long	.LASF28
	.byte	0xa
	.uleb128 0x3
	.long	.LASF29
	.byte	0xb
	.uleb128 0x3
	.long	.LASF30
	.byte	0xc
	.uleb128 0x3
	.long	.LASF31
	.byte	0xd
	.uleb128 0x3
	.long	.LASF32
	.byte	0xe
	.uleb128 0x3
	.long	.LASF33
	.byte	0xf
	.uleb128 0x3
	.long	.LASF34
	.byte	0x10
	.uleb128 0x3
	.long	.LASF35
	.byte	0x11
	.uleb128 0x3
	.long	.LASF36
	.byte	0x12
	.uleb128 0x3
	.long	.LASF37
	.byte	0x13
	.uleb128 0x3
	.long	.LASF38
	.byte	0x14
	.uleb128 0x3
	.long	.LASF39
	.byte	0x15
	.uleb128 0x3
	.long	.LASF40
	.byte	0x16
	.uleb128 0x3
	.long	.LASF41
	.byte	0x17
	.uleb128 0x3
	.long	.LASF42
	.byte	0x18
	.uleb128 0x3
	.long	.LASF43
	.byte	0x19
	.uleb128 0x3
	.long	.LASF44
	.byte	0x1a
	.uleb128 0x3
	.long	.LASF45
	.byte	0x1b
	.uleb128 0x3
	.long	.LASF46
	.byte	0x1c
	.uleb128 0x3
	.long	.LASF47
	.byte	0x1d
	.uleb128 0x3
	.long	.LASF48
	.byte	0x1e
	.uleb128 0x3
	.long	.LASF49
	.byte	0x1f
	.uleb128 0x3
	.long	.LASF50
	.byte	0x20
	.uleb128 0x3
	.long	.LASF51
	.byte	0x21
	.uleb128 0x3
	.long	.LASF52
	.byte	0x22
	.uleb128 0x3
	.long	.LASF53
	.byte	0x23
	.uleb128 0x3
	.long	.LASF54
	.byte	0x24
	.uleb128 0x3
	.long	.LASF55
	.byte	0x25
	.uleb128 0x3
	.long	.LASF56
	.byte	0x26
	.uleb128 0x3
	.long	.LASF57
	.byte	0x27
	.uleb128 0x3
	.long	.LASF58
	.byte	0x28
	.uleb128 0x3
	.long	.LASF59
	.byte	0x29
	.uleb128 0x3
	.long	.LASF60
	.byte	0x2a
	.uleb128 0x3
	.long	.LASF61
	.byte	0x2b
	.uleb128 0x3
	.long	.LASF62
	.byte	0x2c
	.uleb128 0x3
	.long	.LASF63
	.byte	0x2d
	.uleb128 0x3
	.long	.LASF64
	.byte	0x2e
	.uleb128 0x3
	.long	.LASF65
	.byte	0x2f
	.uleb128 0x3
	.long	.LASF66
	.byte	0x30
	.uleb128 0x3
	.long	.LASF67
	.byte	0x31
	.uleb128 0x3
	.long	.LASF68
	.byte	0x32
	.uleb128 0x3
	.long	.LASF69
	.byte	0x33
	.uleb128 0x3
	.long	.LASF70
	.byte	0x34
	.uleb128 0x3
	.long	.LASF71
	.byte	0x35
	.uleb128 0x3
	.long	.LASF72
	.byte	0x36
	.uleb128 0x3
	.long	.LASF73
	.byte	0x37
	.uleb128 0x3
	.long	.LASF74
	.byte	0x38
	.uleb128 0x3
	.long	.LASF75
	.byte	0x39
	.uleb128 0x3
	.long	.LASF76
	.byte	0x3a
	.byte	0
	.uleb128 0xd
	.long	0x131
	.uleb128 0x36
	.long	.LASF455
	.byte	0x10
	.byte	0x1
	.byte	0x28
	.byte	0x9
	.long	0x2ee
	.uleb128 0x8
	.long	.LASF77
	.byte	0x1
	.byte	0x28
	.byte	0x9
	.long	0x2be
	.byte	0
	.uleb128 0x1e
	.long	0x2ee
	.uleb128 0x26
	.byte	0x1
	.byte	0x28
	.byte	0x9
	.long	0x2e0
	.uleb128 0x27
	.string	"LB0"
	.long	0x3f
	.byte	0
	.uleb128 0x27
	.string	"UB0"
	.long	0x3f
	.byte	0x4
	.byte	0
	.uleb128 0x8
	.long	.LASF78
	.byte	0x1
	.byte	0x28
	.byte	0x9
	.long	0x30d
	.byte	0x8
	.byte	0
	.uleb128 0x15
	.long	0x131
	.long	0x30d
	.uleb128 0x28
	.long	0x52
	.uleb128 0x6
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x94
	.byte	0x4
	.uleb128 0x8
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x23
	.uleb128 0x4
	.byte	0x94
	.byte	0x4
	.byte	0
	.uleb128 0x1e
	.long	0x2c3
	.uleb128 0xf
	.sleb128 0
	.sleb128 341
	.long	.LASF79
	.long	0x52
	.uleb128 0xf
	.sleb128 0
	.sleb128 4097
	.long	.LASF80
	.long	0x52
	.uleb128 0xd
	.long	0x31e
	.uleb128 0xf
	.sleb128 0
	.sleb128 4096
	.long	.LASF81
	.long	0x52
	.uleb128 0xd
	.long	0x32f
	.uleb128 0x13
	.long	.LASF89
	.byte	0x14
	.byte	0x2
	.byte	0x75
	.long	0x39b
	.uleb128 0x8
	.long	.LASF82
	.byte	0x2
	.byte	0x76
	.byte	0x7
	.long	0x31e
	.byte	0
	.uleb128 0x8
	.long	.LASF83
	.byte	0x2
	.byte	0x76
	.byte	0xe
	.long	0x31e
	.byte	0x4
	.uleb128 0x8
	.long	.LASF84
	.byte	0x2
	.byte	0x76
	.byte	0x15
	.long	0x31e
	.byte	0x8
	.uleb128 0x8
	.long	.LASF85
	.byte	0x2
	.byte	0x77
	.byte	0x7
	.long	0x32f
	.byte	0xc
	.uleb128 0x8
	.long	.LASF86
	.byte	0x2
	.byte	0x78
	.byte	0x7
	.long	0x3a0
	.byte	0x10
	.uleb128 0x8
	.long	.LASF87
	.byte	0x2
	.byte	0x78
	.byte	0x10
	.long	0x3a0
	.byte	0x11
	.byte	0
	.uleb128 0xd
	.long	0x340
	.uleb128 0x18
	.byte	0x1
	.byte	0x2
	.long	.LASF88
	.uleb128 0xd
	.long	0x3a0
	.uleb128 0x29
	.long	.LASF102
	.long	0x340
	.long	0x3c1
	.uleb128 0x21
	.long	0x52
	.sleb128 341
	.byte	0
	.uleb128 0x22
	.long	.LASF90
	.value	0x1aa8
	.byte	0x2
	.byte	0x7e
	.long	0x3e9
	.uleb128 0x8
	.long	.LASF91
	.byte	0x2
	.byte	0x7f
	.byte	0x7
	.long	0x312
	.byte	0
	.uleb128 0x8
	.long	.LASF92
	.byte	0x2
	.byte	0x80
	.byte	0x7
	.long	0x3ac
	.byte	0x4
	.byte	0
	.uleb128 0xf
	.sleb128 0
	.sleb128 341
	.long	.LASF93
	.long	0x52
	.uleb128 0xd
	.long	0x3e9
	.uleb128 0xf
	.sleb128 -2147483648
	.sleb128 2147483647
	.long	.LASF94
	.long	0x52
	.uleb128 0xd
	.long	0x3fa
	.uleb128 0x13
	.long	.LASF95
	.byte	0x8
	.byte	0x3
	.byte	0x9
	.long	0x439
	.uleb128 0x8
	.long	.LASF96
	.byte	0x3
	.byte	0xa
	.byte	0x7
	.long	0x3fa
	.byte	0
	.uleb128 0x8
	.long	.LASF97
	.byte	0x3
	.byte	0xa
	.byte	0xe
	.long	0x3fa
	.byte	0x4
	.byte	0
	.uleb128 0xd
	.long	0x412
	.uleb128 0x13
	.long	.LASF98
	.byte	0x20
	.byte	0x4
	.byte	0xd
	.long	0x499
	.uleb128 0x8
	.long	.LASF82
	.byte	0x4
	.byte	0xe
	.byte	0x7
	.long	0x31e
	.byte	0
	.uleb128 0x8
	.long	.LASF83
	.byte	0x4
	.byte	0xe
	.byte	0xe
	.long	0x31e
	.byte	0x4
	.uleb128 0x8
	.long	.LASF99
	.byte	0x4
	.byte	0xf
	.byte	0x7
	.long	0x412
	.byte	0x8
	.uleb128 0x8
	.long	.LASF100
	.byte	0x4
	.byte	0x10
	.byte	0x7
	.long	0x3a0
	.byte	0x10
	.uleb128 0x8
	.long	.LASF101
	.byte	0x4
	.byte	0x11
	.byte	0x7
	.long	0x412
	.byte	0x14
	.uleb128 0x8
	.long	.LASF87
	.byte	0x4
	.byte	0x12
	.byte	0x7
	.long	0x3a0
	.byte	0x1c
	.byte	0
	.uleb128 0x29
	.long	.LASF103
	.long	0x43e
	.long	0x4ae
	.uleb128 0x21
	.long	0x52
	.sleb128 341
	.byte	0
	.uleb128 0x22
	.long	.LASF104
	.value	0x2aa4
	.byte	0x4
	.byte	0x17
	.long	0x4d6
	.uleb128 0x8
	.long	.LASF91
	.byte	0x4
	.byte	0x18
	.byte	0x7
	.long	0x3e9
	.byte	0
	.uleb128 0x8
	.long	.LASF92
	.byte	0x4
	.byte	0x19
	.byte	0x7
	.long	0x499
	.byte	0x4
	.byte	0
	.uleb128 0x22
	.long	.LASF105
	.value	0x4560
	.byte	0x2
	.byte	0x8e
	.long	0x53f
	.uleb128 0x8
	.long	.LASF106
	.byte	0x2
	.byte	0x8f
	.byte	0x7
	.long	0x31e
	.byte	0
	.uleb128 0x8
	.long	.LASF107
	.byte	0x2
	.byte	0x90
	.byte	0x7
	.long	0x3c1
	.byte	0x4
	.uleb128 0x1b
	.long	.LASF108
	.byte	0x91
	.byte	0x7
	.long	0x4ae
	.value	0x1aac
	.uleb128 0x1b
	.long	.LASF109
	.byte	0x92
	.byte	0x7
	.long	0x31e
	.value	0x4550
	.uleb128 0x1b
	.long	.LASF110
	.byte	0x92
	.byte	0x16
	.long	0x31e
	.value	0x4554
	.uleb128 0x1b
	.long	.LASF111
	.byte	0x93
	.byte	0x7
	.long	0x312
	.value	0x4558
	.uleb128 0x1b
	.long	.LASF112
	.byte	0x94
	.byte	0x7
	.long	0x32f
	.value	0x455c
	.byte	0
	.uleb128 0x20
	.sleb128 4097
	.long	.LASF114
	.long	0x52
	.uleb128 0x26
	.byte	0x2
	.byte	0xe9
	.byte	0xe
	.long	0x56d
	.uleb128 0x8
	.long	.LASF106
	.byte	0x2
	.byte	0xea
	.byte	0x16
	.long	0x53f
	.byte	0
	.uleb128 0x8
	.long	.LASF115
	.byte	0x2
	.byte	0xeb
	.byte	0x7
	.long	0x3a0
	.byte	0x4
	.byte	0
	.uleb128 0x1a
	.long	.LASF116
	.byte	0x5
	.byte	0x8
	.long	0x597
	.uleb128 0x3
	.long	.LASF117
	.byte	0
	.uleb128 0x3
	.long	.LASF118
	.byte	0x1
	.uleb128 0x3
	.long	.LASF119
	.byte	0x2
	.uleb128 0x3
	.long	.LASF120
	.byte	0x3
	.uleb128 0x3
	.long	.LASF121
	.byte	0x4
	.byte	0
	.uleb128 0xd
	.long	0x56d
	.uleb128 0x14
	.long	.LASF122
	.byte	0x18
	.byte	0x2
	.value	0x163
	.long	0x61a
	.uleb128 0x7
	.long	.LASF83
	.byte	0x2
	.value	0x164
	.byte	0x7
	.long	0x31e
	.byte	0
	.uleb128 0x7
	.long	.LASF84
	.byte	0x2
	.value	0x164
	.byte	0xe
	.long	0x31e
	.byte	0x4
	.uleb128 0x7
	.long	.LASF123
	.byte	0x2
	.value	0x165
	.byte	0x7
	.long	0x32f
	.byte	0x8
	.uleb128 0x7
	.long	.LASF85
	.byte	0x2
	.value	0x165
	.byte	0x17
	.long	0x32f
	.byte	0xc
	.uleb128 0x7
	.long	.LASF124
	.byte	0x2
	.value	0x166
	.byte	0x7
	.long	0x3a0
	.byte	0x10
	.uleb128 0x7
	.long	.LASF125
	.byte	0x2
	.value	0x166
	.byte	0x15
	.long	0x3a0
	.byte	0x11
	.uleb128 0x7
	.long	.LASF126
	.byte	0x2
	.value	0x166
	.byte	0x26
	.long	0x3a0
	.byte	0x12
	.uleb128 0x7
	.long	.LASF127
	.byte	0x2
	.value	0x167
	.byte	0x7
	.long	0x312
	.byte	0x14
	.byte	0
	.uleb128 0xd
	.long	0x59c
	.uleb128 0xf
	.sleb128 0
	.sleb128 63
	.long	.LASF128
	.long	0x52
	.uleb128 0xf
	.sleb128 0
	.sleb128 64
	.long	.LASF129
	.long	0x52
	.uleb128 0x14
	.long	.LASF130
	.byte	0x14
	.byte	0x2
	.value	0x227
	.long	0x698
	.uleb128 0x7
	.long	.LASF83
	.byte	0x2
	.value	0x228
	.byte	0x7
	.long	0x31e
	.byte	0
	.uleb128 0x7
	.long	.LASF123
	.byte	0x2
	.value	0x229
	.byte	0x7
	.long	0x32f
	.byte	0x4
	.uleb128 0x7
	.long	.LASF85
	.byte	0x2
	.value	0x229
	.byte	0x17
	.long	0x32f
	.byte	0x8
	.uleb128 0x7
	.long	.LASF131
	.byte	0x2
	.value	0x22a
	.byte	0x7
	.long	0x62a
	.byte	0xc
	.uleb128 0x7
	.long	.LASF132
	.byte	0x2
	.value	0x22b
	.byte	0x7
	.long	0x3a0
	.byte	0x10
	.uleb128 0x7
	.long	.LASF126
	.byte	0x2
	.value	0x22b
	.byte	0x13
	.long	0x3a0
	.byte	0x11
	.byte	0
	.uleb128 0xd
	.long	0x636
	.uleb128 0x14
	.long	.LASF133
	.byte	0x1c
	.byte	0x2
	.value	0x233
	.long	0x737
	.uleb128 0x7
	.long	.LASF106
	.byte	0x2
	.value	0x234
	.byte	0x7
	.long	0x31e
	.byte	0
	.uleb128 0x7
	.long	.LASF123
	.byte	0x2
	.value	0x235
	.byte	0x7
	.long	0x32f
	.byte	0x4
	.uleb128 0x7
	.long	.LASF85
	.byte	0x2
	.value	0x235
	.byte	0x17
	.long	0x32f
	.byte	0x8
	.uleb128 0x7
	.long	.LASF131
	.byte	0x2
	.value	0x236
	.byte	0x7
	.long	0x62a
	.byte	0xc
	.uleb128 0x7
	.long	.LASF134
	.byte	0x2
	.value	0x236
	.byte	0x16
	.long	0x62a
	.byte	0x10
	.uleb128 0x7
	.long	.LASF135
	.byte	0x2
	.value	0x237
	.byte	0x7
	.long	0x31e
	.byte	0x14
	.uleb128 0x7
	.long	.LASF132
	.byte	0x2
	.value	0x238
	.byte	0x7
	.long	0x3a0
	.byte	0x18
	.uleb128 0x7
	.long	.LASF136
	.byte	0x2
	.value	0x238
	.byte	0x13
	.long	0x3a0
	.byte	0x19
	.uleb128 0x7
	.long	.LASF137
	.byte	0x2
	.value	0x238
	.byte	0x21
	.long	0x3a0
	.byte	0x1a
	.uleb128 0x7
	.long	.LASF126
	.byte	0x2
	.value	0x238
	.byte	0x2b
	.long	0x3a0
	.byte	0x1b
	.byte	0
	.uleb128 0xd
	.long	0x69d
	.uleb128 0x14
	.long	.LASF138
	.byte	0xc
	.byte	0x2
	.value	0x2f1
	.long	0x766
	.uleb128 0x7
	.long	.LASF83
	.byte	0x2
	.value	0x2f2
	.byte	0x7
	.long	0x31e
	.byte	0
	.uleb128 0x7
	.long	.LASF99
	.byte	0x2
	.value	0x2f3
	.byte	0x7
	.long	0x412
	.byte	0x4
	.byte	0
	.uleb128 0x2a
	.long	.LASF139
	.value	0x4564
	.value	0x428
	.long	0x79e
	.uleb128 0x7
	.long	.LASF140
	.byte	0x2
	.value	0x429
	.byte	0x7
	.long	0x4d6
	.byte	0
	.uleb128 0x19
	.long	.LASF141
	.value	0x42a
	.byte	0x7
	.long	0x3a0
	.value	0x4560
	.uleb128 0x19
	.long	.LASF142
	.value	0x42a
	.byte	0x11
	.long	0x3a0
	.value	0x4561
	.byte	0
	.uleb128 0x2a
	.long	.LASF143
	.value	0x4558
	.value	0x432
	.long	0x7f2
	.uleb128 0x7
	.long	.LASF107
	.byte	0x2
	.value	0x433
	.byte	0x7
	.long	0x3c1
	.byte	0
	.uleb128 0x19
	.long	.LASF108
	.value	0x434
	.byte	0x7
	.long	0x4ae
	.value	0x1aa8
	.uleb128 0x19
	.long	.LASF144
	.value	0x435
	.byte	0x7
	.long	0x3e9
	.value	0x454c
	.uleb128 0x19
	.long	.LASF109
	.value	0x436
	.byte	0x7
	.long	0x31e
	.value	0x4550
	.uleb128 0x19
	.long	.LASF110
	.value	0x436
	.byte	0x16
	.long	0x31e
	.value	0x4554
	.byte	0
	.uleb128 0xf
	.sleb128 0
	.sleb128 4096
	.long	.LASF145
	.long	0x52
	.uleb128 0x13
	.long	.LASF146
	.byte	0xc
	.byte	0x6
	.byte	0x20
	.long	0x84c
	.uleb128 0x8
	.long	.LASF96
	.byte	0x6
	.byte	0x21
	.byte	0x7
	.long	0x7f2
	.byte	0
	.uleb128 0x8
	.long	.LASF97
	.byte	0x6
	.byte	0x21
	.byte	0xe
	.long	0x7f2
	.byte	0x4
	.uleb128 0x8
	.long	.LASF147
	.byte	0x6
	.byte	0x22
	.byte	0x7
	.long	0x3a0
	.byte	0x8
	.uleb128 0x8
	.long	.LASF148
	.byte	0x6
	.byte	0x22
	.byte	0x18
	.long	0x3a0
	.byte	0x9
	.uleb128 0x8
	.long	.LASF149
	.byte	0x6
	.byte	0x22
	.byte	0x2b
	.long	0x3a0
	.byte	0xa
	.byte	0
	.uleb128 0x23
	.long	.LASF150
	.uleb128 0x7
	.byte	0x97
	.byte	0x94
	.byte	0x4
	.byte	0x23
	.uleb128 0x2
	.byte	0x38
	.byte	0x1e
	.value	0x43f
	.long	0x89d
	.uleb128 0x7
	.long	.LASF91
	.byte	0x2
	.value	0x43f
	.byte	0x16
	.long	0x3e9
	.byte	0
	.uleb128 0x7
	.long	.LASF151
	.byte	0x2
	.value	0x440
	.byte	0x7
	.long	0x7fe
	.byte	0x4
	.uleb128 0x15
	.long	0x412
	.long	0x88e
	.uleb128 0x2b
	.long	0x52
	.long	0x85f
	.byte	0
	.uleb128 0x7
	.long	.LASF152
	.byte	0x2
	.value	0x441
	.byte	0x7
	.long	0x87b
	.byte	0x10
	.byte	0
	.uleb128 0x23
	.long	.LASF153
	.uleb128 0x7
	.byte	0x97
	.byte	0x94
	.byte	0x4
	.byte	0x38
	.byte	0x1e
	.byte	0x23
	.uleb128 0x24
	.value	0x443
	.long	0x913
	.uleb128 0x7
	.long	.LASF91
	.byte	0x2
	.value	0x443
	.byte	0x14
	.long	0x3e9
	.byte	0
	.uleb128 0x7
	.long	.LASF106
	.byte	0x2
	.value	0x445
	.byte	0x7
	.long	0x31e
	.byte	0x4
	.uleb128 0x7
	.long	.LASF111
	.byte	0x2
	.value	0x446
	.byte	0x7
	.long	0x312
	.byte	0x8
	.uleb128 0x7
	.long	.LASF112
	.byte	0x2
	.value	0x447
	.byte	0x7
	.long	0x32f
	.byte	0xc
	.uleb128 0x7
	.long	.LASF141
	.byte	0x2
	.value	0x448
	.byte	0x7
	.long	0x3a0
	.byte	0x10
	.uleb128 0x7
	.long	.LASF142
	.byte	0x2
	.value	0x448
	.byte	0x11
	.long	0x3a0
	.byte	0x11
	.uleb128 0x7
	.long	.LASF154
	.byte	0x2
	.value	0x444
	.byte	0x7
	.long	0x84c
	.byte	0x14
	.byte	0
	.uleb128 0x37
	.long	.LASF155
	.byte	0x7
	.byte	0x1
	.byte	0x2
	.value	0x44a
	.byte	0x9
	.long	0x935
	.uleb128 0x3
	.long	.LASF156
	.byte	0
	.uleb128 0x3
	.long	.LASF157
	.byte	0x1
	.uleb128 0x3
	.long	.LASF158
	.byte	0x2
	.byte	0
	.uleb128 0xd
	.long	0x913
	.uleb128 0xf
	.sleb128 0
	.sleb128 64
	.long	.LASF159
	.long	0x52
	.uleb128 0x13
	.long	.LASF160
	.byte	0x14
	.byte	0x4
	.byte	0x46
	.long	0x987
	.uleb128 0x8
	.long	.LASF83
	.byte	0x4
	.byte	0x47
	.byte	0x7
	.long	0x31e
	.byte	0
	.uleb128 0x8
	.long	.LASF99
	.byte	0x4
	.byte	0x48
	.byte	0x7
	.long	0x412
	.byte	0x4
	.uleb128 0x8
	.long	.LASF134
	.byte	0x4
	.byte	0x49
	.byte	0x7
	.long	0x93a
	.byte	0xc
	.uleb128 0x8
	.long	.LASF100
	.byte	0x4
	.byte	0x4a
	.byte	0x7
	.long	0x3a0
	.byte	0x10
	.byte	0
	.uleb128 0xf
	.sleb128 0
	.sleb128 64
	.long	.LASF161
	.long	0x52
	.uleb128 0x13
	.long	.LASF162
	.byte	0x10
	.byte	0x7
	.byte	0x8
	.long	0x9d4
	.uleb128 0x8
	.long	.LASF123
	.byte	0x7
	.byte	0x9
	.byte	0x7
	.long	0x7f2
	.byte	0
	.uleb128 0x8
	.long	.LASF85
	.byte	0x7
	.byte	0x9
	.byte	0x17
	.long	0x7f2
	.byte	0x4
	.uleb128 0x8
	.long	.LASF131
	.byte	0x7
	.byte	0xa
	.byte	0x7
	.long	0x987
	.byte	0x8
	.uleb128 0x8
	.long	.LASF126
	.byte	0x7
	.byte	0xb
	.byte	0x7
	.long	0x3a0
	.byte	0xc
	.byte	0
	.uleb128 0x13
	.long	.LASF163
	.byte	0x8
	.byte	0x6
	.byte	0x60
	.long	0x9fb
	.uleb128 0x8
	.long	.LASF85
	.byte	0x6
	.byte	0x61
	.byte	0x7
	.long	0x7f2
	.byte	0
	.uleb128 0x8
	.long	.LASF86
	.byte	0x6
	.byte	0x62
	.byte	0x7
	.long	0x3a0
	.byte	0x4
	.byte	0
	.uleb128 0x1a
	.long	.LASF164
	.byte	0x6
	.byte	0x9
	.long	0xa2b
	.uleb128 0x3
	.long	.LASF165
	.byte	0
	.uleb128 0x3
	.long	.LASF166
	.byte	0x1
	.uleb128 0x3
	.long	.LASF167
	.byte	0x2
	.uleb128 0x3
	.long	.LASF168
	.byte	0x3
	.uleb128 0x3
	.long	.LASF169
	.byte	0x4
	.uleb128 0x3
	.long	.LASF170
	.byte	0x5
	.byte	0
	.uleb128 0xd
	.long	0x9fb
	.uleb128 0x14
	.long	.LASF171
	.byte	0x8
	.byte	0x2
	.value	0x559
	.long	0xa5a
	.uleb128 0x7
	.long	.LASF83
	.byte	0x2
	.value	0x55a
	.byte	0x7
	.long	0x31e
	.byte	0
	.uleb128 0x7
	.long	.LASF172
	.byte	0x2
	.value	0x55b
	.byte	0x7
	.long	0x9fb
	.byte	0x4
	.byte	0
	.uleb128 0x14
	.long	.LASF173
	.byte	0xc
	.byte	0x2
	.value	0x574
	.long	0xa84
	.uleb128 0x7
	.long	.LASF83
	.byte	0x2
	.value	0x575
	.byte	0x7
	.long	0x31e
	.byte	0
	.uleb128 0x7
	.long	.LASF174
	.byte	0x2
	.value	0x576
	.byte	0x7
	.long	0x9d4
	.byte	0x4
	.byte	0
	.uleb128 0x23
	.long	.LASF175
	.uleb128 0x7
	.byte	0x97
	.byte	0x94
	.byte	0x4
	.byte	0x40
	.byte	0x1e
	.byte	0x23
	.uleb128 0x28
	.value	0x591
	.long	0xad8
	.uleb128 0x7
	.long	.LASF91
	.byte	0x2
	.value	0x591
	.byte	0x1b
	.long	0x3e9
	.byte	0
	.uleb128 0x7
	.long	.LASF83
	.byte	0x2
	.value	0x592
	.byte	0x7
	.long	0x31e
	.byte	0x4
	.uleb128 0x7
	.long	.LASF176
	.byte	0x2
	.value	0x593
	.byte	0x7
	.long	0x84c
	.byte	0x8
	.uleb128 0x38
	.long	.LASF177
	.byte	0x2
	.value	0x593
	.byte	0x12
	.long	0x84c
	.uleb128 0x8
	.byte	0x97
	.byte	0x94
	.byte	0x4
	.byte	0x23
	.uleb128 0x3
	.byte	0x38
	.byte	0x1e
	.byte	0x22
	.byte	0
	.uleb128 0x1a
	.long	.LASF178
	.byte	0x3
	.byte	0x1e
	.long	0xb08
	.uleb128 0x3
	.long	.LASF179
	.byte	0
	.uleb128 0x3
	.long	.LASF180
	.byte	0x1
	.uleb128 0x3
	.long	.LASF181
	.byte	0x2
	.uleb128 0x3
	.long	.LASF182
	.byte	0x3
	.uleb128 0x3
	.long	.LASF183
	.byte	0x4
	.uleb128 0x3
	.long	.LASF184
	.byte	0x5
	.byte	0
	.uleb128 0xd
	.long	0xad8
	.uleb128 0x14
	.long	.LASF185
	.byte	0x8
	.byte	0x2
	.value	0x79a
	.long	0xb37
	.uleb128 0x7
	.long	.LASF83
	.byte	0x2
	.value	0x79b
	.byte	0x7
	.long	0x31e
	.byte	0
	.uleb128 0x7
	.long	.LASF111
	.byte	0x2
	.value	0x79c
	.byte	0x7
	.long	0x312
	.byte	0x4
	.byte	0
	.uleb128 0x20
	.sleb128 101
	.long	.LASF186
	.long	0x52
	.uleb128 0x18
	.byte	0x8
	.byte	0x7
	.long	.LASF187
	.uleb128 0x2c
	.long	.LASF188
	.uleb128 0x2c
	.long	.LASF189
	.uleb128 0x18
	.byte	0x1
	.byte	0x7
	.long	.LASF190
	.uleb128 0xf
	.sleb128 0
	.sleb128 4097
	.long	.LASF191
	.long	0x52
	.uleb128 0xf
	.sleb128 0
	.sleb128 2147483648
	.long	.LASF192
	.long	0xb75
	.uleb128 0x18
	.byte	0x8
	.byte	0x5
	.long	.LASF193
	.uleb128 0x13
	.long	.LASF194
	.byte	0x10
	.byte	0x8
	.byte	0xa
	.long	0xba3
	.uleb128 0x8
	.long	.LASF83
	.byte	0x8
	.byte	0xb
	.byte	0x7
	.long	0xb5a
	.byte	0
	.uleb128 0x8
	.long	.LASF174
	.byte	0x8
	.byte	0xc
	.byte	0x7
	.long	0xb66
	.byte	0x8
	.byte	0
	.uleb128 0x14
	.long	.LASF195
	.byte	0x8
	.byte	0x9
	.value	0x115
	.long	0xbcd
	.uleb128 0x7
	.long	.LASF83
	.byte	0x9
	.value	0x116
	.byte	0x7
	.long	0x31e
	.byte	0
	.uleb128 0x7
	.long	.LASF174
	.byte	0x9
	.value	0x117
	.byte	0x7
	.long	0x32f
	.byte	0x4
	.byte	0
	.uleb128 0xf
	.sleb128 0
	.sleb128 4097
	.long	.LASF196
	.long	0x52
	.uleb128 0xf
	.sleb128 0
	.sleb128 4096
	.long	.LASF197
	.long	0x52
	.uleb128 0x13
	.long	.LASF198
	.byte	0x8
	.byte	0xa
	.byte	0x8
	.long	0xc0c
	.uleb128 0x8
	.long	.LASF83
	.byte	0xa
	.byte	0x9
	.byte	0x7
	.long	0xbcd
	.byte	0
	.uleb128 0x8
	.long	.LASF174
	.byte	0xa
	.byte	0xa
	.byte	0x7
	.long	0xbd9
	.byte	0x4
	.byte	0
	.uleb128 0x12
	.long	.LASF199
	.byte	0x1
	.byte	0xe
	.long	0x108
	.uleb128 0x9
	.byte	0x3
	.quad	silver_output_profile__comment_introducer
	.uleb128 0x12
	.long	.LASF200
	.byte	0x2
	.byte	0x7a
	.long	0x39b
	.uleb128 0x9
	.byte	0x3
	.quad	silver_output_profile__empty_binding
	.uleb128 0x12
	.long	.LASF201
	.byte	0x2
	.byte	0x82
	.long	0x3c1
	.uleb128 0x9
	.byte	0x3
	.quad	silver_output_profile__empty_environment
	.uleb128 0x12
	.long	.LASF202
	.byte	0x2
	.byte	0x96
	.long	0x4d6
	.uleb128 0x9
	.byte	0x3
	.quad	silver_output_profile__initial_state
	.uleb128 0x12
	.long	.LASF203
	.byte	0x2
	.byte	0x9a
	.long	0x4d6
	.uleb128 0x9
	.byte	0x3
	.quad	silver_output_profile__invalid_state
	.uleb128 0x1c
	.long	.LASF204
	.value	0x169
	.long	0x61a
	.uleb128 0x9
	.byte	0x3
	.quad	silver_output_profile__invalid_value
	.uleb128 0x1c
	.long	.LASF205
	.value	0x22d
	.long	0x698
	.uleb128 0x9
	.byte	0x3
	.quad	silver_output_profile__invalid_expression
	.uleb128 0x1c
	.long	.LASF206
	.value	0x23a
	.long	0x737
	.uleb128 0x9
	.byte	0x3
	.quad	silver_output_profile__invalid_expression_state
	.uleb128 0x1c
	.long	.LASF207
	.value	0x42c
	.long	0x766
	.uleb128 0x9
	.byte	0x3
	.quad	silver_output_profile__initial_scan
	.uleb128 0x1c
	.long	.LASF208
	.value	0x42e
	.long	0x766
	.uleb128 0x9
	.byte	0x3
	.quad	silver_output_profile__invalid_scan
	.uleb128 0x2d
	.long	.LASF209
	.byte	0x1
	.byte	0x1
	.uleb128 0x2e
	.byte	0x12
	.long	0xcde
	.uleb128 0x2d
	.long	.LASF210
	.byte	0x2
	.byte	0x5
	.uleb128 0x2e
	.byte	0x13
	.long	0xceb
	.uleb128 0x39
	.long	.LASF456
	.byte	0x2
	.byte	0xf
	.byte	0x1
	.quad	.LFB0
	.quad	.LFE0-.LFB0
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.long	.LASF214
	.value	0x5ac
	.long	0x412
	.quad	.LFB170
	.quad	.LFE170-.LFB170
	.uleb128 0x1
	.byte	0x9c
	.long	0xd7f
	.uleb128 0x1
	.long	.LASF99
	.value	0x5ad
	.byte	0x7
	.long	0x439
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x1
	.long	.LASF172
	.value	0x5ad
	.byte	0x22
	.long	0xb08
	.uleb128 0x2
	.byte	0x91
	.sleb128 -41
	.uleb128 0x1
	.long	.LASF211
	.value	0x5ad
	.byte	0x41
	.long	0x40d
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0x1
	.long	.LASF212
	.value	0x5ad
	.byte	0x5c
	.long	0x3a7
	.uleb128 0x2
	.byte	0x91
	.sleb128 -42
	.uleb128 0x2
	.long	.LASF213
	.value	0x5af
	.byte	0xf
	.long	0x412
	.uleb128 0x2
	.byte	0x91
	.sleb128 -32
	.byte	0
	.uleb128 0x6
	.long	.LASF215
	.value	0x5a7
	.long	0xad8
	.quad	.LFB169
	.quad	.LFE169-.LFB169
	.uleb128 0x1
	.byte	0x9c
	.long	0xdb0
	.uleb128 0x1
	.long	.LASF172
	.value	0x5a7
	.byte	0x1e
	.long	0xa2b
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.byte	0
	.uleb128 0x10
	.long	.LASF218
	.value	0x59a
	.long	0x3a0
	.quad	.LFB168
	.quad	.LFE168-.LFB168
	.uleb128 0x1
	.byte	0x9c
	.long	0xdf0
	.uleb128 0x1
	.long	.LASF216
	.value	0x59a
	.byte	0x1e
	.long	0xdf0
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0x1
	.long	.LASF217
	.value	0x59a
	.byte	0x36
	.long	0xdf5
	.uleb128 0x2
	.byte	0x91
	.sleb128 -32
	.byte	0
	.uleb128 0xc
	.long	0x79e
	.uleb128 0xc
	.long	0xa84
	.uleb128 0x3a
	.long	.LASF219
	.byte	0x2
	.value	0x555
	.byte	0x4
	.long	0x993
	.quad	.LFB167
	.quad	.LFE167-.LFB167
	.uleb128 0x1
	.byte	0x9c
	.long	0xe2d
	.uleb128 0x1
	.long	.LASF174
	.value	0x555
	.byte	0x1e
	.long	0xe2d
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.byte	0
	.uleb128 0xc
	.long	0x340
	.uleb128 0x24
	.long	.LASF220
	.value	0x553
	.long	0x9d4
	.quad	.LFB166
	.quad	.LFE166-.LFB166
	.uleb128 0x1
	.byte	0x9c
	.long	0xe63
	.uleb128 0x1
	.long	.LASF174
	.value	0x553
	.byte	0x17
	.long	0xe2d
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.byte	0
	.uleb128 0x24
	.long	.LASF221
	.value	0x551
	.long	0x993
	.quad	.LFB165
	.quad	.LFE165-.LFB165
	.uleb128 0x1
	.byte	0x9c
	.long	0xe94
	.uleb128 0x1
	.long	.LASF174
	.value	0x551
	.byte	0x19
	.long	0xe94
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.byte	0
	.uleb128 0xc
	.long	0x636
	.uleb128 0x6
	.long	.LASF222
	.value	0x4a2
	.long	0x3a0
	.quad	.LFB164
	.quad	.LFE164-.LFB164
	.uleb128 0x1
	.byte	0x9c
	.long	0xf06
	.uleb128 0x1
	.long	.LASF216
	.value	0x4a2
	.byte	0x19
	.long	0xdf0
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x1
	.long	.LASF154
	.value	0x4a2
	.byte	0x31
	.long	0xf06
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x9
	.long	.LASF229
	.long	0x52
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x4
	.quad	.LBB546
	.quad	.LBE546-.LBB546
	.uleb128 0x2
	.long	.LASF223
	.value	0x4a4
	.byte	0x19
	.long	0x52
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.byte	0
	.byte	0
	.uleb128 0xc
	.long	0x84c
	.uleb128 0x6
	.long	.LASF224
	.value	0x49e
	.long	0x3a0
	.quad	.LFB163
	.quad	.LFE163-.LFB163
	.uleb128 0x1
	.byte	0x9c
	.long	0xf4b
	.uleb128 0x1
	.long	.LASF174
	.value	0x49e
	.byte	0x17
	.long	0x439
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0x1
	.long	.LASF99
	.value	0x49e
	.byte	0x1e
	.long	0x439
	.uleb128 0x2
	.byte	0x91
	.sleb128 -32
	.byte	0
	.uleb128 0x10
	.long	.LASF225
	.value	0x48d
	.long	0x766
	.quad	.LFB162
	.quad	.LFE162-.LFB162
	.uleb128 0x1
	.byte	0x9c
	.long	0xf8b
	.uleb128 0x1
	.long	.LASF216
	.value	0x48d
	.byte	0x1a
	.long	0xdf0
	.uleb128 0x2
	.byte	0x91
	.sleb128 -32
	.uleb128 0x1
	.long	.LASF226
	.value	0x48d
	.byte	0x32
	.long	0xf8b
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.byte	0
	.uleb128 0xc
	.long	0x89d
	.uleb128 0x6
	.long	.LASF227
	.value	0x44c
	.long	0x79e
	.quad	.LFB161
	.quad	.LFE161-.LFB161
	.uleb128 0x1
	.byte	0x9c
	.long	0xfc3
	.uleb128 0x1
	.long	.LASF226
	.value	0x44c
	.byte	0x19
	.long	0xfc3
	.uleb128 0x4
	.byte	0x91
	.sleb128 -10960
	.byte	0
	.uleb128 0xc
	.long	0x766
	.uleb128 0x11
	.long	.LASF228
	.byte	0xa5
	.long	0x3a0
	.quad	.LFB160
	.quad	.LFE160-.LFB160
	.uleb128 0x1
	.byte	0x9c
	.long	0x1033
	.uleb128 0xb
	.long	.LASF108
	.byte	0x2
	.byte	0xa6
	.byte	0x7
	.long	0x1033
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0xb
	.long	.LASF91
	.byte	0x2
	.byte	0xa6
	.byte	0x36
	.long	0x3f5
	.uleb128 0x2
	.byte	0x91
	.sleb128 -60
	.uleb128 0x9
	.long	.LASF230
	.long	0x3e9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x4
	.quad	.LBB545
	.quad	.LBE545-.LBB545
	.uleb128 0xe
	.long	.LASF223
	.byte	0xa9
	.byte	0x19
	.long	0x52
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.byte	0
	.byte	0
	.uleb128 0xc
	.long	0x4ae
	.uleb128 0x11
	.long	.LASF231
	.byte	0x9f
	.long	0x3a0
	.quad	.LFB159
	.quad	.LFE159-.LFB159
	.uleb128 0x1
	.byte	0x9c
	.long	0x1088
	.uleb128 0xb
	.long	.LASF108
	.byte	0x2
	.byte	0x9f
	.byte	0x23
	.long	0x1033
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x9
	.long	.LASF232
	.long	0x3e9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x1d
	.long	.LLRL5
	.uleb128 0xe
	.long	.LASF223
	.byte	0xa0
	.byte	0xf
	.long	0x52
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.byte	0
	.byte	0
	.uleb128 0x11
	.long	.LASF233
	.byte	0x70
	.long	0x3a0
	.quad	.LFB158
	.quad	.LFE158-.LFB158
	.uleb128 0x1
	.byte	0x9c
	.long	0x10d9
	.uleb128 0xb
	.long	.LASF234
	.byte	0x2
	.byte	0x70
	.byte	0x1d
	.long	0x1252
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x4
	.quad	.LBB540
	.quad	.LBE540-.LBB540
	.uleb128 0xe
	.long	.LASF235
	.byte	0x71
	.byte	0xf
	.long	0x127b
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.byte	0
	.byte	0
	.uleb128 0x3b
	.long	.LASF236
	.byte	0x10
	.byte	0xb
	.byte	0
	.long	0x111c
	.uleb128 0x2f
	.long	.LASF77
	.long	0x10ef
	.byte	0
	.uleb128 0x1e
	.long	0x1257
	.uleb128 0x3c
	.byte	0x8
	.byte	0xb
	.byte	0
	.long	0x1111
	.uleb128 0x30
	.string	"LB0"
	.long	0x3f
	.byte	0
	.uleb128 0x30
	.string	"UB0"
	.long	0x3f
	.byte	0x4
	.byte	0
	.uleb128 0x2f
	.long	.LASF78
	.long	0x1276
	.byte	0x8
	.byte	0
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x5
	.long	0x10d9
	.uleb128 0x15
	.long	0x10d
	.long	0x1276
	.uleb128 0x28
	.long	0x52
	.uleb128 0x6
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x94
	.byte	0x4
	.uleb128 0x8
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x23
	.uleb128 0x4
	.byte	0x94
	.byte	0x4
	.byte	0
	.uleb128 0x1e
	.long	0x10f4
	.uleb128 0xc
	.long	0x10d
	.uleb128 0x6
	.long	.LASF237
	.value	0x9bc
	.long	0x3a0
	.quad	.LFB157
	.quad	.LFE157-.LFB157
	.uleb128 0x1
	.byte	0x9c
	.long	0x12f7
	.uleb128 0xb
	.long	.LASF238
	.byte	0x1
	.byte	0x45
	.byte	0x1a
	.long	0x124d
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17808
	.uleb128 0x4
	.quad	.LBB536
	.quad	.LBE536-.LBB536
	.uleb128 0x2
	.long	.LASF239
	.value	0x9be
	.byte	0xb
	.long	0x114
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.uleb128 0x4
	.quad	.LBB537
	.quad	.LBE537-.LBB537
	.uleb128 0x2
	.long	.LASF226
	.value	0x9c3
	.byte	0x12
	.long	0x766
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17792
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF240
	.value	0x9ae
	.long	0x3a0
	.quad	.LFB156
	.quad	.LFE156-.LFB156
	.uleb128 0x1
	.byte	0x9c
	.long	0x136e
	.uleb128 0xb
	.long	.LASF238
	.byte	0x1
	.byte	0x40
	.byte	0x1e
	.long	0x1248
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17808
	.uleb128 0x4
	.quad	.LBB533
	.quad	.LBE533-.LBB533
	.uleb128 0x2
	.long	.LASF239
	.value	0x9b0
	.byte	0xb
	.long	0x114
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.uleb128 0x4
	.quad	.LBB534
	.quad	.LBE534-.LBB534
	.uleb128 0x2
	.long	.LASF226
	.value	0x9b5
	.byte	0x12
	.long	0x766
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17792
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF241
	.value	0x9a1
	.long	0x3a0
	.quad	.LFB155
	.quad	.LFE155-.LFB155
	.uleb128 0x1
	.byte	0x9c
	.long	0x13c2
	.uleb128 0xb
	.long	.LASF238
	.byte	0x1
	.byte	0x3b
	.byte	0x1d
	.long	0x1243
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17808
	.uleb128 0x4
	.quad	.LBB530
	.quad	.LBE530-.LBB530
	.uleb128 0x2
	.long	.LASF239
	.value	0x9a3
	.byte	0xb
	.long	0x114
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF242
	.value	0x996
	.long	0x3a0
	.quad	.LFB154
	.quad	.LFE154-.LFB154
	.uleb128 0x1
	.byte	0x9c
	.long	0x1416
	.uleb128 0xb
	.long	.LASF238
	.byte	0x1
	.byte	0x48
	.byte	0x16
	.long	0x123e
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17808
	.uleb128 0x4
	.quad	.LBB527
	.quad	.LBE527-.LBB527
	.uleb128 0x2
	.long	.LASF239
	.value	0x998
	.byte	0xb
	.long	0x114
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.byte	0
	.byte	0
	.uleb128 0x10
	.long	.LASF243
	.value	0x97e
	.long	0x766
	.quad	.LFB150
	.quad	.LFE150-.LFB150
	.uleb128 0x1
	.byte	0x9c
	.long	0x14c7
	.uleb128 0x1
	.long	.LASF238
	.value	0x97b
	.byte	0x18
	.long	0x1239
	.uleb128 0x4
	.byte	0x91
	.sleb128 -18000
	.uleb128 0x1
	.long	.LASF239
	.value	0x97b
	.byte	0x29
	.long	0x12c
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17977
	.uleb128 0x1d
	.long	.LLRL4
	.uleb128 0x9
	.long	.LASF244
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x9
	.long	.LASF245
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x15
	.long	0x10d
	.long	0x148f
	.uleb128 0x31
	.long	0x52
	.long	0x145e
	.long	0x146b
	.byte	0
	.uleb128 0x2
	.long	.LASF234
	.value	0x982
	.byte	0xa
	.long	0x149f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -104
	.uleb128 0xc
	.long	0x1478
	.uleb128 0x2
	.long	.LASF226
	.value	0x983
	.byte	0xa
	.long	0x766
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17968
	.uleb128 0x2
	.long	.LASF246
	.value	0x984
	.byte	0xa
	.long	0xb37
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF247
	.value	0x94c
	.long	0x766
	.quad	.LFB148
	.quad	.LFE148-.LFB148
	.uleb128 0x1
	.byte	0x9c
	.long	0x1564
	.uleb128 0x1
	.long	.LASF234
	.value	0x946
	.byte	0x7
	.long	0x1234
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17904
	.uleb128 0x1
	.long	.LASF239
	.value	0x946
	.byte	0x16
	.long	0x12c
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x1
	.long	.LASF248
	.value	0x946
	.byte	0x28
	.long	0x29f
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x11
	.uleb128 0x1
	.long	.LASF226
	.value	0x946
	.byte	0x3c
	.long	0xfc3
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x4
	.quad	.LBB508
	.quad	.LBE508-.LBB508
	.uleb128 0x16
	.long	.LASF277
	.long	0x766
	.quad	.LFB149
	.quad	.LFE149-.LFB149
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -17824
	.byte	0x6
	.byte	0x23
	.uleb128 0x18
	.byte	0x6
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF249
	.value	0x93b
	.long	0x766
	.quad	.LFB145
	.quad	.LFE145-.LFB145
	.uleb128 0x1
	.byte	0x9c
	.long	0x1621
	.uleb128 0x1
	.long	.LASF234
	.value	0x936
	.byte	0x7
	.long	0x122f
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17888
	.uleb128 0x1
	.long	.LASF226
	.value	0x936
	.byte	0x16
	.long	0xfc3
	.uleb128 0x5
	.byte	0x91
	.sleb128 -80
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF250
	.value	0x936
	.byte	0x2a
	.long	0x29f
	.uleb128 0x5
	.byte	0x91
	.sleb128 -80
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x4
	.quad	.LBB501
	.quad	.LBE501-.LBB501
	.uleb128 0xa
	.long	.LASF253
	.long	0x766
	.quad	.LFB146
	.quad	.LFE146-.LFB146
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -17888
	.byte	0x6
	.byte	0x23
	.uleb128 0x18
	.byte	0x6
	.uleb128 0x2
	.long	.LASF216
	.value	0x93d
	.byte	0x7
	.long	0x79e
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17840
	.uleb128 0x9
	.long	.LASF251
	.long	0x3e9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x2
	.long	.LASF217
	.value	0x93e
	.byte	0x7
	.long	0x89d
	.uleb128 0x4
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x10
	.long	.LASF252
	.value	0x915
	.long	0xf8b
	.quad	.LFB142
	.quad	.LFE142-.LFB142
	.uleb128 0x1
	.byte	0x9c
	.long	0x1713
	.uleb128 0x1
	.long	.LASF234
	.value	0x858
	.byte	0x7
	.long	0x122a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF216
	.value	0x858
	.byte	0x16
	.long	0xdf0
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF226
	.value	0x858
	.byte	0x2e
	.long	0xf8b
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x4
	.quad	.LBB487
	.quad	.LBE487-.LBB487
	.uleb128 0xa
	.long	.LASF254
	.long	0xf8b
	.quad	.LFB144
	.quad	.LFE144-.LFB144
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -168
	.byte	0x6
	.byte	0x23
	.uleb128 0x28
	.byte	0x6
	.uleb128 0x9
	.long	.LASF255
	.long	0x3e9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x2
	.long	.LASF217
	.value	0x917
	.byte	0x7
	.long	0x89d
	.uleb128 0x4
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.uleb128 0x9
	.long	.LASF256
	.long	0x3e9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -92
	.uleb128 0x9
	.long	.LASF257
	.long	0x3e9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -108
	.uleb128 0x2
	.long	.LASF258
	.value	0x918
	.byte	0x7
	.long	0xa84
	.uleb128 0x4
	.byte	0x91
	.sleb128 -136
	.byte	0x6
	.uleb128 0x9
	.long	.LASF259
	.long	0x3e9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -140
	.uleb128 0x1f
	.string	"yes"
	.value	0x919
	.long	0x84c
	.uleb128 0x4
	.byte	0x91
	.sleb128 -160
	.byte	0x6
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF260
	.value	0x8fd
	.long	0xf8b
	.quad	.LFB138
	.quad	.LFE138-.LFB138
	.uleb128 0x1
	.byte	0x9c
	.long	0x1803
	.uleb128 0x1
	.long	.LASF234
	.value	0x84f
	.byte	0x7
	.long	0x1225
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF216
	.value	0x84f
	.byte	0x16
	.long	0xdf0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF226
	.value	0x84f
	.byte	0x2e
	.long	0xf8b
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x4
	.quad	.LBB471
	.quad	.LBE471-.LBB471
	.uleb128 0xa
	.long	.LASF261
	.long	0xf8b
	.quad	.LFB140
	.quad	.LFE140-.LFB140
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -200
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x9
	.long	.LASF262
	.long	0x3e9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x2
	.long	.LASF217
	.value	0x8ff
	.byte	0x7
	.long	0x89d
	.uleb128 0x4
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.uleb128 0x9
	.long	.LASF263
	.long	0x3e9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -92
	.uleb128 0x9
	.long	.LASF264
	.long	0x3e9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -108
	.uleb128 0x2
	.long	.LASF258
	.value	0x900
	.byte	0x7
	.long	0xa84
	.uleb128 0x4
	.byte	0x91
	.sleb128 -136
	.byte	0x6
	.uleb128 0x9
	.long	.LASF265
	.long	0x3e9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -140
	.uleb128 0x1f
	.string	"yes"
	.value	0x901
	.long	0x84c
	.uleb128 0x4
	.byte	0x91
	.sleb128 -160
	.byte	0x6
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF266
	.value	0x8b1
	.long	0xf8b
	.quad	.LFB135
	.quad	.LFE135-.LFB135
	.uleb128 0x1
	.byte	0x9c
	.long	0x197b
	.uleb128 0x1
	.long	.LASF234
	.value	0x846
	.byte	0x7
	.long	0x1220
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF216
	.value	0x846
	.byte	0x16
	.long	0xdf0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF226
	.value	0x846
	.byte	0x2e
	.long	0xf8b
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x4
	.quad	.LBB453
	.quad	.LBE453-.LBB453
	.uleb128 0xa
	.long	.LASF267
	.long	0xf8b
	.quad	.LFB137
	.quad	.LFE137-.LFB137
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -17992
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x9
	.long	.LASF268
	.long	0x3e9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x2
	.long	.LASF217
	.value	0x8b3
	.byte	0x7
	.long	0x89d
	.uleb128 0x4
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.uleb128 0x2
	.long	.LASF82
	.value	0x8b4
	.byte	0x7
	.long	0x31e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -92
	.uleb128 0x2
	.long	.LASF83
	.value	0x8b5
	.byte	0x7
	.long	0x31e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1f
	.string	"low"
	.value	0x8b6
	.long	0x946
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x2
	.long	.LASF269
	.value	0x8b6
	.byte	0xc
	.long	0x946
	.uleb128 0x3
	.byte	0x91
	.sleb128 -176
	.uleb128 0x2
	.long	.LASF270
	.value	0x8b7
	.byte	0x7
	.long	0x412
	.uleb128 0x3
	.byte	0x91
	.sleb128 -184
	.uleb128 0x2
	.long	.LASF271
	.value	0x8b8
	.byte	0x7
	.long	0x3a0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -97
	.uleb128 0x4
	.quad	.LBB462
	.quad	.LBE462-.LBB462
	.uleb128 0x2
	.long	.LASF272
	.value	0x8d2
	.byte	0xa
	.long	0x79e
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17952
	.uleb128 0x9
	.long	.LASF273
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -104
	.uleb128 0x2
	.long	.LASF274
	.value	0x8d3
	.byte	0xa
	.long	0x89d
	.uleb128 0x4
	.byte	0x91
	.sleb128 -120
	.byte	0x6
	.uleb128 0x9
	.long	.LASF275
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -124
	.uleb128 0x4
	.quad	.LBB465
	.quad	.LBE465-.LBB465
	.uleb128 0x2
	.long	.LASF223
	.value	0x8df
	.byte	0xe
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF276
	.value	0x8a9
	.long	0xf8b
	.quad	.LFB132
	.quad	.LFE132-.LFB132
	.uleb128 0x1
	.byte	0x9c
	.long	0x1a03
	.uleb128 0x1
	.long	.LASF234
	.value	0x83d
	.byte	0x7
	.long	0x121b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x1
	.long	.LASF216
	.value	0x83d
	.byte	0x16
	.long	0xdf0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF226
	.value	0x83d
	.byte	0x2e
	.long	0xf8b
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x4
	.quad	.LBB444
	.quad	.LBE444-.LBB444
	.uleb128 0x16
	.long	.LASF278
	.long	0xf8b
	.quad	.LFB134
	.quad	.LFE134-.LFB134
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -40
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.byte	0
	.byte	0
	.uleb128 0x10
	.long	.LASF279
	.value	0x8a0
	.long	0xf8b
	.quad	.LFB129
	.quad	.LFE129-.LFB129
	.uleb128 0x1
	.byte	0x9c
	.long	0x1abc
	.uleb128 0x1
	.long	.LASF234
	.value	0x894
	.byte	0x7
	.long	0x1216
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF216
	.value	0x894
	.byte	0x16
	.long	0xdf0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF226
	.value	0x894
	.byte	0x2e
	.long	0xf8b
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x1
	.long	.LASF250
	.value	0x894
	.byte	0x40
	.long	0x935
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x1c
	.uleb128 0x4
	.quad	.LBB435
	.quad	.LBE435-.LBB435
	.uleb128 0xa
	.long	.LASF280
	.long	0xf8b
	.quad	.LFB131
	.quad	.LFE131-.LFB131
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x9
	.long	.LASF281
	.long	0x3e9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.uleb128 0x2
	.long	.LASF217
	.value	0x8a3
	.byte	0x7
	.long	0x89d
	.uleb128 0x4
	.byte	0x91
	.sleb128 -72
	.byte	0x6
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x10
	.long	.LASF282
	.value	0x87f
	.long	0xf8b
	.quad	.LFB125
	.quad	.LFE125-.LFB125
	.uleb128 0x1
	.byte	0x9c
	.long	0x1b86
	.uleb128 0x1
	.long	.LASF234
	.value	0x875
	.byte	0x7
	.long	0x1211
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF216
	.value	0x875
	.byte	0x16
	.long	0xdf0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF226
	.value	0x875
	.byte	0x2e
	.long	0xf8b
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x1
	.long	.LASF250
	.value	0x875
	.byte	0x40
	.long	0x935
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x1c
	.uleb128 0x4
	.quad	.LBB419
	.quad	.LBE419-.LBB419
	.uleb128 0xa
	.long	.LASF283
	.long	0xf8b
	.quad	.LFB127
	.quad	.LFE127-.LFB127
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -136
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x9
	.long	.LASF284
	.long	0x3e9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x2
	.long	.LASF217
	.value	0x882
	.byte	0x7
	.long	0x89d
	.uleb128 0x4
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.uleb128 0x2
	.long	.LASF285
	.value	0x883
	.byte	0x7
	.long	0x31e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -92
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF286
	.value	0x833
	.long	0x3a0
	.quad	.LFB124
	.quad	.LFE124-.LFB124
	.uleb128 0x1
	.byte	0x9c
	.long	0x1bd7
	.uleb128 0x1
	.long	.LASF234
	.value	0x82e
	.byte	0x1b
	.long	0x120c
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x1
	.long	.LASF106
	.value	0x82e
	.byte	0x2a
	.long	0x32a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x1
	.long	.LASF250
	.value	0x82e
	.byte	0x47
	.long	0x935
	.uleb128 0x3
	.byte	0x91
	.sleb128 -69
	.byte	0
	.uleb128 0x6
	.long	.LASF287
	.value	0x7f5
	.long	0xf8b
	.quad	.LFB122
	.quad	.LFE122-.LFB122
	.uleb128 0x1
	.byte	0x9c
	.long	0x1c9f
	.uleb128 0x1
	.long	.LASF234
	.value	0x7ee
	.byte	0x7
	.long	0x1207
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF216
	.value	0x7ee
	.byte	0x16
	.long	0xdf0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF226
	.value	0x7ee
	.byte	0x2e
	.long	0xf8b
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x4
	.quad	.LBB406
	.quad	.LBE406-.LBB406
	.uleb128 0xa
	.long	.LASF288
	.long	0xf8b
	.quad	.LFB123
	.quad	.LFE123-.LFB123
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -136
	.byte	0x6
	.byte	0x23
	.uleb128 0x18
	.byte	0x6
	.uleb128 0x9
	.long	.LASF289
	.long	0x3e9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x2
	.long	.LASF217
	.value	0x7f7
	.byte	0x7
	.long	0x89d
	.uleb128 0x4
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.uleb128 0x2
	.long	.LASF174
	.value	0x7f8
	.byte	0x7
	.long	0x636
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x2
	.long	.LASF111
	.value	0x7f9
	.byte	0x7
	.long	0xb0d
	.uleb128 0x3
	.byte	0x91
	.sleb128 -120
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x10
	.long	.LASF290
	.value	0x7d7
	.long	0xf8b
	.quad	.LFB120
	.quad	.LFE120-.LFB120
	.uleb128 0x1
	.byte	0x9c
	.long	0x1d99
	.uleb128 0x1
	.long	.LASF234
	.value	0x7cf
	.byte	0x7
	.long	0x1202
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF216
	.value	0x7cf
	.byte	0x16
	.long	0xdf0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF226
	.value	0x7cf
	.byte	0x2e
	.long	0xf8b
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x4
	.quad	.LBB389
	.quad	.LBE389-.LBB389
	.uleb128 0xa
	.long	.LASF291
	.long	0xf8b
	.quad	.LFB121
	.quad	.LFE121-.LFB121
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -120
	.byte	0x6
	.byte	0x23
	.uleb128 0x18
	.byte	0x6
	.uleb128 0x2
	.long	.LASF82
	.value	0x7d9
	.byte	0x7
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.uleb128 0x2
	.long	.LASF83
	.value	0x7da
	.byte	0x7
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x2
	.long	.LASF111
	.value	0x7db
	.byte	0x7
	.long	0x3e9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -60
	.uleb128 0x2
	.long	.LASF174
	.value	0x7dd
	.byte	0x7
	.long	0x946
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x4
	.quad	.LBB387
	.quad	.LBE387-.LBB387
	.uleb128 0x9
	.long	.LASF292
	.long	0x3e9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x2
	.long	.LASF217
	.value	0x7e5
	.byte	0xe
	.long	0x1d90
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0xc
	.long	0x89d
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x10
	.long	.LASF293
	.value	0x7a7
	.long	0xb0d
	.quad	.LFB118
	.quad	.LFE118-.LFB118
	.uleb128 0x1
	.byte	0x9c
	.long	0x1e50
	.uleb128 0x1
	.long	.LASF234
	.value	0x79f
	.byte	0x7
	.long	0x11fd
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF216
	.value	0x79f
	.byte	0x16
	.long	0xdf0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x1
	.long	.LASF106
	.value	0x79f
	.byte	0x2e
	.long	0x32a
	.uleb128 0x5
	.byte	0x91
	.sleb128 -80
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x4
	.quad	.LBB379
	.quad	.LBE379-.LBB379
	.uleb128 0xa
	.long	.LASF294
	.long	0xb0d
	.quad	.LFB119
	.quad	.LFE119-.LFB119
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -72
	.byte	0x6
	.byte	0x23
	.uleb128 0x18
	.byte	0x6
	.uleb128 0x2
	.long	.LASF82
	.value	0x7aa
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.uleb128 0x2
	.long	.LASF83
	.value	0x7ab
	.byte	0x7
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x2
	.long	.LASF223
	.value	0x7ac
	.byte	0x7
	.long	0x312
	.uleb128 0x2
	.byte	0x91
	.sleb128 -44
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x10
	.long	.LASF295
	.value	0x793
	.long	0x3e9
	.quad	.LFB115
	.quad	.LFE115-.LFB115
	.uleb128 0x1
	.byte	0x9c
	.long	0x1ef7
	.uleb128 0x1
	.long	.LASF234
	.value	0x78d
	.byte	0x7
	.long	0x11f8
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF216
	.value	0x78d
	.byte	0x16
	.long	0xdf0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF106
	.value	0x78d
	.byte	0x2e
	.long	0x32a
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x4
	.quad	.LBB372
	.quad	.LBE372-.LBB372
	.uleb128 0xa
	.long	.LASF296
	.long	0x3e9
	.quad	.LFB116
	.quad	.LFE116-.LFB116
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -56
	.byte	0x6
	.byte	0x23
	.uleb128 0x18
	.byte	0x6
	.uleb128 0x2
	.long	.LASF82
	.value	0x796
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.uleb128 0x2
	.long	.LASF83
	.value	0x797
	.byte	0x7
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x17
	.long	.LASF297
	.value	0x781
	.quad	.LFB112
	.quad	.LFE112-.LFB112
	.uleb128 0x1
	.byte	0x9c
	.long	0x1f9b
	.uleb128 0x1
	.long	.LASF234
	.value	0x691
	.byte	0x7
	.long	0x11f3
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF216
	.value	0x691
	.byte	0x16
	.long	0xdf0
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x1
	.long	.LASF106
	.value	0x691
	.byte	0x2e
	.long	0x32a
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x20
	.uleb128 0x1
	.long	.LASF154
	.value	0x692
	.byte	0x7
	.long	0xf06
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF217
	.value	0x692
	.byte	0x1c
	.long	0xdf5
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x4
	.quad	.LBB363
	.quad	.LBE363-.LBB363
	.uleb128 0x3d
	.long	.LASF457
	.quad	.LFB114
	.quad	.LFE114-.LFB114
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -40
	.byte	0x6
	.byte	0x23
	.uleb128 0x28
	.byte	0x6
	.byte	0
	.byte	0
	.uleb128 0x17
	.long	.LASF298
	.value	0x749
	.quad	.LFB109
	.quad	.LFE109-.LFB109
	.uleb128 0x1
	.byte	0x9c
	.long	0x2092
	.uleb128 0x1
	.long	.LASF234
	.value	0x6b2
	.byte	0x7
	.long	0x11ee
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x1
	.long	.LASF216
	.value	0x6b2
	.byte	0x16
	.long	0xdf0
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF217
	.value	0x6b2
	.byte	0x2e
	.long	0xdf5
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x4
	.quad	.LBB345
	.quad	.LBE345-.LBB345
	.uleb128 0x25
	.long	.LASF304
	.quad	.LFB111
	.quad	.LFE111-.LFB111
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -136
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x4
	.quad	.LBB354
	.quad	.LBE354-.LBB354
	.uleb128 0x2
	.long	.LASF299
	.value	0x74b
	.byte	0x7
	.long	0x3e9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x2
	.long	.LASF300
	.value	0x74c
	.byte	0x7
	.long	0xa84
	.uleb128 0x4
	.byte	0x91
	.sleb128 -104
	.byte	0x6
	.uleb128 0x2
	.long	.LASF172
	.value	0x74d
	.byte	0x7
	.long	0x131
	.uleb128 0x3
	.byte	0x91
	.sleb128 -65
	.uleb128 0x2
	.long	.LASF301
	.value	0x74e
	.byte	0x7
	.long	0x3a0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -66
	.uleb128 0x2
	.long	.LASF302
	.value	0x74f
	.byte	0x7
	.long	0x131
	.uleb128 0x3
	.byte	0x91
	.sleb128 -113
	.uleb128 0x2
	.long	.LASF83
	.value	0x750
	.byte	0x7
	.long	0x31e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -120
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x17
	.long	.LASF303
	.value	0x6d6
	.quad	.LFB106
	.quad	.LFE106-.LFB106
	.uleb128 0x1
	.byte	0x9c
	.long	0x22c3
	.uleb128 0x1
	.long	.LASF234
	.value	0x6a7
	.byte	0x7
	.long	0x11e9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x1
	.long	.LASF216
	.value	0x6a7
	.byte	0x16
	.long	0xdf0
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x1
	.long	.LASF106
	.value	0x6a7
	.byte	0x2e
	.long	0x32a
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x28
	.uleb128 0x1
	.long	.LASF154
	.value	0x6a8
	.byte	0x7
	.long	0xf06
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x1
	.long	.LASF217
	.value	0x6a8
	.byte	0x1c
	.long	0xdf5
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x4
	.quad	.LBB325
	.quad	.LBE325-.LBB325
	.uleb128 0x25
	.long	.LASF305
	.quad	.LFB108
	.quad	.LFE108-.LFB108
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -280
	.byte	0x6
	.byte	0x23
	.uleb128 0x30
	.byte	0x6
	.uleb128 0x2
	.long	.LASF83
	.value	0x6d9
	.byte	0x7
	.long	0x31e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x2
	.long	.LASF306
	.value	0x6da
	.byte	0x7
	.long	0xa5a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x2
	.long	.LASF307
	.value	0x6db
	.byte	0x7
	.long	0x946
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x2
	.long	.LASF308
	.value	0x6dc
	.byte	0x7
	.long	0x7fe
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x2
	.long	.LASF309
	.value	0x6dd
	.byte	0x7
	.long	0x412
	.uleb128 0x3
	.byte	0x91
	.sleb128 -152
	.uleb128 0x9
	.long	.LASF310
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x32
	.quad	.LBB334
	.quad	.LBE334-.LBB334
	.long	0x21b9
	.uleb128 0x2
	.long	.LASF223
	.value	0x6e6
	.byte	0xe
	.long	0x52
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.byte	0
	.uleb128 0x32
	.quad	.LBB336
	.quad	.LBE336-.LBB336
	.long	0x21ef
	.uleb128 0x2
	.long	.LASF172
	.value	0x6f5
	.byte	0xd
	.long	0xa30
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0x2
	.long	.LASF311
	.value	0x6f6
	.byte	0xd
	.long	0xa5a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -176
	.byte	0
	.uleb128 0x3e
	.long	.LLRL2
	.long	0x2266
	.uleb128 0x2
	.long	.LASF172
	.value	0x706
	.byte	0xd
	.long	0xa30
	.uleb128 0x3
	.byte	0x91
	.sleb128 -184
	.uleb128 0x2
	.long	.LASF312
	.value	0x707
	.byte	0xd
	.long	0x946
	.uleb128 0x3
	.byte	0x91
	.sleb128 -208
	.uleb128 0x2
	.long	.LASF313
	.value	0x709
	.byte	0xd
	.long	0x3e9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x2
	.long	.LASF314
	.value	0x70a
	.byte	0xd
	.long	0x3e9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x2
	.long	.LASF111
	.value	0x70b
	.byte	0xd
	.long	0x3e9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x2
	.long	.LASF302
	.value	0x70c
	.byte	0xd
	.long	0xad8
	.uleb128 0x2
	.byte	0x91
	.sleb128 -57
	.uleb128 0x2
	.long	.LASF211
	.value	0x70d
	.byte	0xd
	.long	0x3fa
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.byte	0
	.uleb128 0x1d
	.long	.LLRL3
	.uleb128 0x2
	.long	.LASF315
	.value	0x727
	.byte	0x12
	.long	0x636
	.uleb128 0x3
	.byte	0x91
	.sleb128 -240
	.uleb128 0x4
	.quad	.LBB339
	.quad	.LBE339-.LBB339
	.uleb128 0x2
	.long	.LASF172
	.value	0x72a
	.byte	0x18
	.long	0xa30
	.uleb128 0x3
	.byte	0x91
	.sleb128 -248
	.uleb128 0x4
	.quad	.LBB340
	.quad	.LBE340-.LBB340
	.uleb128 0x2
	.long	.LASF300
	.value	0x72f
	.byte	0x1e
	.long	0x636
	.uleb128 0x3
	.byte	0x91
	.sleb128 -272
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x17
	.long	.LASF316
	.value	0x6bc
	.quad	.LFB103
	.quad	.LFE103-.LFB103
	.uleb128 0x1
	.byte	0x9c
	.long	0x2379
	.uleb128 0x1
	.long	.LASF234
	.value	0x69c
	.byte	0x7
	.long	0x11e4
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x1
	.long	.LASF216
	.value	0x69c
	.byte	0x16
	.long	0xdf0
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF106
	.value	0x69c
	.byte	0x2e
	.long	0x32a
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x28
	.uleb128 0x1
	.long	.LASF154
	.value	0x69d
	.byte	0x7
	.long	0xf06
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x1
	.long	.LASF217
	.value	0x69d
	.byte	0x1c
	.long	0xdf5
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x4
	.quad	.LBB316
	.quad	.LBE316-.LBB316
	.uleb128 0x25
	.long	.LASF317
	.quad	.LFB105
	.quad	.LFE105-.LFB105
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -56
	.byte	0x6
	.byte	0x23
	.uleb128 0x30
	.byte	0x6
	.uleb128 0x2
	.long	.LASF83
	.value	0x6bf
	.byte	0x7
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF318
	.value	0x662
	.long	0x31e
	.quad	.LFB101
	.quad	.LFE101-.LFB101
	.uleb128 0x1
	.byte	0x9c
	.long	0x2403
	.uleb128 0x1
	.long	.LASF234
	.value	0x65c
	.byte	0x1a
	.long	0x11df
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF106
	.value	0x65c
	.byte	0x29
	.long	0x32a
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF172
	.value	0x65c
	.byte	0x46
	.long	0x29f
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0xc
	.uleb128 0x4
	.quad	.LBB309
	.quad	.LBE309-.LBB309
	.uleb128 0x16
	.long	.LASF319
	.long	0x31e
	.quad	.LFB102
	.quad	.LFE102-.LFB102
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -40
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF320
	.value	0x657
	.long	0x131
	.quad	.LFB100
	.quad	.LFE100-.LFB100
	.uleb128 0x1
	.byte	0x9c
	.long	0x2444
	.uleb128 0x1
	.long	.LASF234
	.value	0x653
	.byte	0x1a
	.long	0x11da
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x1
	.long	.LASF106
	.value	0x653
	.byte	0x29
	.long	0x32a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.uleb128 0x6
	.long	.LASF321
	.value	0x5b9
	.long	0x3e9
	.quad	.LFB98
	.quad	.LFE98-.LFB98
	.uleb128 0x1
	.byte	0x9c
	.long	0x250c
	.uleb128 0x1
	.long	.LASF234
	.value	0x5b2
	.byte	0x7
	.long	0x11d5
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF216
	.value	0x5b2
	.byte	0x16
	.long	0xdf0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x1
	.long	.LASF106
	.value	0x5b2
	.byte	0x2e
	.long	0x32a
	.uleb128 0x5
	.byte	0x91
	.sleb128 -80
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x1
	.long	.LASF83
	.value	0x5b2
	.byte	0x38
	.long	0x32a
	.uleb128 0x5
	.byte	0x91
	.sleb128 -80
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x4
	.quad	.LBB298
	.quad	.LBE298-.LBB298
	.uleb128 0xa
	.long	.LASF322
	.long	0x3e9
	.quad	.LFB99
	.quad	.LFE99-.LFB99
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -56
	.byte	0x6
	.byte	0x23
	.uleb128 0x18
	.byte	0x6
	.uleb128 0x2
	.long	.LASF82
	.value	0x5bc
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.uleb128 0x2
	.long	.LASF323
	.value	0x5bd
	.byte	0x7
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x2
	.long	.LASF223
	.value	0x5be
	.byte	0x7
	.long	0x3e9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -44
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x17
	.long	.LASF324
	.value	0x59f
	.quad	.LFB97
	.quad	.LFE97-.LFB97
	.uleb128 0x1
	.byte	0x9c
	.long	0x2548
	.uleb128 0x1
	.long	.LASF154
	.value	0x59c
	.byte	0x24
	.long	0xf06
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x1
	.long	.LASF217
	.value	0x59c
	.byte	0x39
	.long	0xdf5
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.byte	0
	.uleb128 0x6
	.long	.LASF325
	.value	0x580
	.long	0xa5a
	.quad	.LFB94
	.quad	.LFE94-.LFB94
	.uleb128 0x1
	.byte	0x9c
	.long	0x2621
	.uleb128 0x1
	.long	.LASF234
	.value	0x579
	.byte	0x7
	.long	0x11d0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x1
	.long	.LASF216
	.value	0x579
	.byte	0x16
	.long	0xdf0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF106
	.value	0x579
	.byte	0x2e
	.long	0x32a
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x1
	.long	.LASF326
	.value	0x579
	.byte	0x4b
	.long	0x3a7
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x14
	.uleb128 0x4
	.quad	.LBB290
	.quad	.LBE290-.LBB290
	.uleb128 0xa
	.long	.LASF327
	.long	0xa5a
	.quad	.LFB95
	.quad	.LFE95-.LFB95
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -104
	.byte	0x6
	.byte	0x23
	.uleb128 0x18
	.byte	0x6
	.uleb128 0x2
	.long	.LASF82
	.value	0x584
	.byte	0x9
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.uleb128 0x2
	.long	.LASF83
	.value	0x585
	.byte	0x9
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x2
	.long	.LASF223
	.value	0x586
	.byte	0x9
	.long	0x312
	.uleb128 0x2
	.byte	0x91
	.sleb128 -44
	.uleb128 0x2
	.long	.LASF328
	.value	0x587
	.byte	0x9
	.long	0xbe5
	.uleb128 0x3
	.byte	0x91
	.sleb128 -88
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF329
	.value	0x564
	.long	0xa30
	.quad	.LFB91
	.quad	.LFE91-.LFB91
	.uleb128 0x1
	.byte	0x9c
	.long	0x2699
	.uleb128 0x1
	.long	.LASF234
	.value	0x55d
	.byte	0x23
	.long	0x11cb
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x1
	.long	.LASF106
	.value	0x55d
	.byte	0x32
	.long	0x32a
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x4
	.quad	.LBB284
	.quad	.LBE284-.LBB284
	.uleb128 0x16
	.long	.LASF330
	.long	0xa30
	.quad	.LFB92
	.quad	.LFE92-.LFB92
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -40
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.byte	0
	.byte	0
	.uleb128 0x10
	.long	.LASF331
	.value	0x547
	.long	0xf8b
	.quad	.LFB88
	.quad	.LFE88-.LFB88
	.uleb128 0x1
	.byte	0x9c
	.long	0x2768
	.uleb128 0x1
	.long	.LASF234
	.value	0x53e
	.byte	0x7
	.long	0x11c6
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF216
	.value	0x53e
	.byte	0x16
	.long	0xdf0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -120
	.uleb128 0x1
	.long	.LASF226
	.value	0x53e
	.byte	0x2e
	.long	0xf8b
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF248
	.value	0x53e
	.byte	0x40
	.long	0x29f
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x4
	.quad	.LBB275
	.quad	.LBE275-.LBB275
	.uleb128 0xa
	.long	.LASF332
	.long	0xf8b
	.quad	.LFB89
	.quad	.LFE89-.LFB89
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0x23
	.uleb128 0x18
	.byte	0x6
	.uleb128 0x4
	.quad	.LBB274
	.quad	.LBE274-.LBB274
	.uleb128 0x9
	.long	.LASF333
	.long	0x3e9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.uleb128 0x2
	.long	.LASF217
	.value	0x54b
	.byte	0xe
	.long	0x275f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0xc
	.long	0x89d
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF334
	.value	0x52e
	.long	0x636
	.quad	.LFB86
	.quad	.LFE86-.LFB86
	.uleb128 0x1
	.byte	0x9c
	.long	0x2818
	.uleb128 0x1
	.long	.LASF234
	.value	0x523
	.byte	0x7
	.long	0x11c1
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0x1
	.long	.LASF216
	.value	0x523
	.byte	0x16
	.long	0xdf0
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x1
	.long	.LASF106
	.value	0x523
	.byte	0x2e
	.long	0x32a
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x1
	.long	.LASF154
	.value	0x523
	.byte	0x4b
	.long	0xf06
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x4
	.quad	.LBB266
	.quad	.LBE266-.LBB266
	.uleb128 0xa
	.long	.LASF335
	.long	0x636
	.quad	.LFB87
	.quad	.LFE87-.LFB87
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -10976
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x2
	.long	.LASF336
	.value	0x531
	.byte	0x7
	.long	0x4ae
	.uleb128 0x4
	.byte	0x91
	.sleb128 -10960
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF337
	.value	0x51a
	.long	0x946
	.quad	.LFB84
	.quad	.LFE84-.LFB84
	.uleb128 0x1
	.byte	0x9c
	.long	0x28ec
	.uleb128 0x1
	.long	.LASF234
	.value	0x50d
	.byte	0x7
	.long	0x11bc
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0x1
	.long	.LASF216
	.value	0x50d
	.byte	0x16
	.long	0xdf0
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x1
	.long	.LASF106
	.value	0x50d
	.byte	0x2e
	.long	0x32a
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x20
	.uleb128 0x1
	.long	.LASF154
	.value	0x50d
	.byte	0x4b
	.long	0xf06
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF338
	.value	0x50e
	.byte	0x7
	.long	0x32a
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x1c
	.uleb128 0x1
	.long	.LASF339
	.value	0x50e
	.byte	0x2b
	.long	0x32a
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x4
	.quad	.LBB257
	.quad	.LBE257-.LBB257
	.uleb128 0xa
	.long	.LASF340
	.long	0x946
	.quad	.LFB85
	.quad	.LFE85-.LFB85
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -10976
	.byte	0x6
	.byte	0x23
	.uleb128 0x28
	.byte	0x6
	.uleb128 0x2
	.long	.LASF336
	.value	0x51e
	.byte	0x7
	.long	0x4ae
	.uleb128 0x4
	.byte	0x91
	.sleb128 -10960
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x10
	.long	.LASF341
	.value	0x4fa
	.long	0x4ae
	.quad	.LFB82
	.quad	.LFE82-.LFB82
	.uleb128 0x1
	.byte	0x9c
	.long	0x29b9
	.uleb128 0x1
	.long	.LASF216
	.value	0x4f0
	.byte	0x1c
	.long	0xdf0
	.uleb128 0x5
	.byte	0x91
	.sleb128 -144
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF154
	.value	0x4f0
	.byte	0x34
	.long	0xf06
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x33
	.long	.LASF342
	.long	0x4ae
	.quad	.LFB83
	.quad	.LFE83-.LFB83
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -10992
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.long	0x2996
	.uleb128 0x2
	.long	.LASF217
	.value	0x4fc
	.byte	0x7
	.long	0x4ae
	.uleb128 0x4
	.byte	0x91
	.sleb128 -10976
	.uleb128 0x9
	.long	.LASF343
	.long	0x52
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x4
	.quad	.LBB248
	.quad	.LBE248-.LBB248
	.uleb128 0x2
	.long	.LASF223
	.value	0x4fe
	.byte	0xb
	.long	0x52
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.byte	0
	.byte	0
	.uleb128 0x4
	.quad	.LBB254
	.quad	.LBE254-.LBB254
	.uleb128 0x2
	.long	.LASF344
	.value	0x4f4
	.byte	0x1c
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.uleb128 0x17
	.long	.LASF345
	.value	0x4de
	.quad	.LFB80
	.quad	.LFE80-.LFB80
	.uleb128 0x1
	.byte	0x9c
	.long	0x2a8b
	.uleb128 0x1
	.long	.LASF216
	.value	0x4d7
	.byte	0x1a
	.long	0xdf0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x1
	.long	.LASF154
	.value	0x4d7
	.byte	0x32
	.long	0xf06
	.uleb128 0x5
	.byte	0x91
	.sleb128 -128
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x3f
	.long	.LASF346
	.quad	.LFB81
	.quad	.LFE81-.LFB81
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -72
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.long	0x2a5b
	.uleb128 0x9
	.long	.LASF347
	.long	0x52
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x4
	.quad	.LBB235
	.quad	.LBE235-.LBB235
	.uleb128 0x4
	.quad	.LBB236
	.quad	.LBE236-.LBB236
	.uleb128 0x2
	.long	.LASF223
	.value	0x4e0
	.byte	0xb
	.long	0x52
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x9
	.long	.LASF348
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -92
	.uleb128 0x4
	.quad	.LBB245
	.quad	.LBE245-.LBB245
	.uleb128 0x2
	.long	.LASF349
	.value	0x4da
	.byte	0x1c
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.uleb128 0x17
	.long	.LASF350
	.value	0x4ca
	.quad	.LFB79
	.quad	.LFE79-.LFB79
	.uleb128 0x1
	.byte	0x9c
	.long	0x2af4
	.uleb128 0x1
	.long	.LASF315
	.value	0x4c7
	.byte	0x19
	.long	0xf06
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x1
	.long	.LASF300
	.value	0x4c7
	.byte	0x34
	.long	0xf06
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x9
	.long	.LASF351
	.long	0x52
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x4
	.quad	.LBB233
	.quad	.LBE233-.LBB233
	.uleb128 0x2
	.long	.LASF223
	.value	0x4cd
	.byte	0xb
	.long	0x52
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF352
	.value	0x4af
	.long	0x3a0
	.quad	.LFB78
	.quad	.LFE78-.LFB78
	.uleb128 0x1
	.byte	0x9c
	.long	0x2b43
	.uleb128 0x1
	.long	.LASF234
	.value	0x4ac
	.byte	0x7
	.long	0x11b7
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0x1
	.long	.LASF216
	.value	0x4ac
	.byte	0x16
	.long	0xdf0
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x1
	.long	.LASF226
	.value	0x4ac
	.byte	0x2e
	.long	0xf8b
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.byte	0
	.uleb128 0x6
	.long	.LASF353
	.value	0x495
	.long	0x3a0
	.quad	.LFB77
	.quad	.LFE77-.LFB77
	.uleb128 0x1
	.byte	0x9c
	.long	0x2bc3
	.uleb128 0x1
	.long	.LASF234
	.value	0x492
	.byte	0x1c
	.long	0x11b2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x1
	.long	.LASF216
	.value	0x492
	.byte	0x2b
	.long	0xdf0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x4
	.quad	.LBB225
	.quad	.LBE225-.LBB225
	.uleb128 0x9
	.long	.LASF354
	.long	0x3e9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x4
	.quad	.LBB228
	.quad	.LBE228-.LBB228
	.uleb128 0x2
	.long	.LASF223
	.value	0x49a
	.byte	0x19
	.long	0x52
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF355
	.value	0x481
	.long	0xf8b
	.quad	.LFB76
	.quad	.LFE76-.LFB76
	.uleb128 0x1
	.byte	0x9c
	.long	0x2c27
	.uleb128 0x1
	.long	.LASF226
	.value	0x47e
	.byte	0x1b
	.long	0xf8b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x4
	.quad	.LBB223
	.quad	.LBE223-.LBB223
	.uleb128 0x9
	.long	.LASF356
	.long	0x3e9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.uleb128 0x2
	.long	.LASF217
	.value	0x483
	.byte	0xe
	.long	0x2c20
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0xc
	.long	0x89d
	.byte	0
	.byte	0
	.uleb128 0x10
	.long	.LASF357
	.value	0x46e
	.long	0xf8b
	.quad	.LFB75
	.quad	.LFE75-.LFB75
	.uleb128 0x1
	.byte	0x9c
	.long	0x2c8c
	.uleb128 0x1
	.long	.LASF226
	.value	0x46b
	.byte	0x16
	.long	0xfc3
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17816
	.uleb128 0x4
	.quad	.LBB221
	.quad	.LBE221-.LBB221
	.uleb128 0x9
	.long	.LASF358
	.long	0x3e9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.uleb128 0x2
	.long	.LASF217
	.value	0x470
	.byte	0xe
	.long	0x2c85
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0xc
	.long	0x89d
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF359
	.value	0x458
	.long	0xf06
	.quad	.LFB73
	.quad	.LFE73-.LFB73
	.uleb128 0x1
	.byte	0x9c
	.long	0x2d72
	.uleb128 0x1
	.long	.LASF216
	.value	0x452
	.byte	0x1b
	.long	0xdf0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x33
	.long	.LASF360
	.long	0xf06
	.quad	.LFB74
	.quad	.LFE74-.LFB74
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.long	0x2d30
	.uleb128 0x9
	.long	.LASF361
	.long	0x3e9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x2
	.long	.LASF217
	.value	0x459
	.byte	0x7
	.long	0x84c
	.uleb128 0x4
	.byte	0x91
	.sleb128 -72
	.byte	0x6
	.uleb128 0x9
	.long	.LASF362
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x4
	.quad	.LBB213
	.quad	.LBE213-.LBB213
	.uleb128 0x2
	.long	.LASF223
	.value	0x45d
	.byte	0xb
	.long	0x52
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.byte	0
	.byte	0
	.uleb128 0x4
	.quad	.LBB216
	.quad	.LBE216-.LBB216
	.uleb128 0x9
	.long	.LASF363
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x4
	.quad	.LBB219
	.quad	.LBE219-.LBB219
	.uleb128 0x2
	.long	.LASF364
	.value	0x456
	.byte	0x1c
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF365
	.value	0x411
	.long	0x4d6
	.quad	.LFB66
	.quad	.LFE66-.LFB66
	.uleb128 0x1
	.byte	0x9c
	.long	0x2e11
	.uleb128 0x1
	.long	.LASF234
	.value	0x40b
	.byte	0x7
	.long	0x11ad
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17888
	.uleb128 0x1
	.long	.LASF239
	.value	0x40b
	.byte	0x16
	.long	0x12c
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x1
	.long	.LASF248
	.value	0x40b
	.byte	0x28
	.long	0x29f
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x11
	.uleb128 0x1
	.long	.LASF140
	.value	0x40b
	.byte	0x3c
	.long	0x2e11
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x4
	.quad	.LBB206
	.quad	.LBE206-.LBB206
	.uleb128 0x16
	.long	.LASF366
	.long	0x4d6
	.quad	.LFB67
	.quad	.LFE67-.LFB67
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -53360
	.byte	0x6
	.byte	0x23
	.uleb128 0x18
	.byte	0x6
	.byte	0
	.byte	0
	.uleb128 0xc
	.long	0x4d6
	.uleb128 0x6
	.long	.LASF367
	.value	0x400
	.long	0x4d6
	.quad	.LFB65
	.quad	.LFE65-.LFB65
	.uleb128 0x1
	.byte	0x9c
	.long	0x2e8a
	.uleb128 0x1
	.long	.LASF234
	.value	0x3f4
	.byte	0x1a
	.long	0x11a8
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17856
	.uleb128 0x1
	.long	.LASF140
	.value	0x3f4
	.byte	0x29
	.long	0x2e11
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17840
	.uleb128 0x4
	.quad	.LBB202
	.quad	.LBE202-.LBB202
	.uleb128 0x2
	.long	.LASF106
	.value	0x401
	.byte	0x7
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.uleb128 0x2
	.long	.LASF174
	.value	0x402
	.byte	0x7
	.long	0xba3
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF368
	.value	0x3eb
	.long	0x4d6
	.quad	.LFB63
	.quad	.LFE63-.LFB63
	.uleb128 0x1
	.byte	0x9c
	.long	0x2f28
	.uleb128 0x1
	.long	.LASF234
	.value	0x3e6
	.byte	0x1c
	.long	0x11a3
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17888
	.uleb128 0x1
	.long	.LASF140
	.value	0x3e6
	.byte	0x2b
	.long	0x2e11
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x4
	.quad	.LBB196
	.quad	.LBE196-.LBB196
	.uleb128 0xa
	.long	.LASF369
	.long	0x4d6
	.quad	.LFB64
	.quad	.LFE64-.LFB64
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -35648
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0x2
	.long	.LASF315
	.value	0x3ec
	.byte	0xf
	.long	0x636
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17840
	.uleb128 0x2
	.long	.LASF300
	.value	0x3ed
	.byte	0xf
	.long	0x636
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17872
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF370
	.value	0x3e0
	.long	0x4d6
	.quad	.LFB61
	.quad	.LFE61-.LFB61
	.uleb128 0x1
	.byte	0x9c
	.long	0x2fb5
	.uleb128 0x1
	.long	.LASF234
	.value	0x3db
	.byte	0x18
	.long	0x119e
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17888
	.uleb128 0x1
	.long	.LASF140
	.value	0x3db
	.byte	0x27
	.long	0x2e11
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x4
	.quad	.LBB190
	.quad	.LBE190-.LBB190
	.uleb128 0xa
	.long	.LASF371
	.long	0x4d6
	.quad	.LFB62
	.quad	.LFE62-.LFB62
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -35600
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0x2
	.long	.LASF174
	.value	0x3e1
	.byte	0xf
	.long	0x636
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17824
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF372
	.value	0x3d1
	.long	0x4d6
	.quad	.LFB59
	.quad	.LFE59-.LFB59
	.uleb128 0x1
	.byte	0x9c
	.long	0x3042
	.uleb128 0x1
	.long	.LASF234
	.value	0x3cc
	.byte	0x1c
	.long	0x1199
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17888
	.uleb128 0x1
	.long	.LASF140
	.value	0x3cc
	.byte	0x2b
	.long	0x2e11
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x4
	.quad	.LBB184
	.quad	.LBE184-.LBB184
	.uleb128 0xa
	.long	.LASF373
	.long	0x4d6
	.quad	.LFB60
	.quad	.LFE60-.LFB60
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -35600
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0x2
	.long	.LASF174
	.value	0x3d2
	.byte	0xf
	.long	0x636
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17824
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF374
	.value	0x3c4
	.long	0x4d6
	.quad	.LFB57
	.quad	.LFE57-.LFB57
	.uleb128 0x1
	.byte	0x9c
	.long	0x30dc
	.uleb128 0x1
	.long	.LASF234
	.value	0x3bf
	.byte	0x19
	.long	0x1194
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17888
	.uleb128 0x1
	.long	.LASF140
	.value	0x3bf
	.byte	0x28
	.long	0x2e11
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x4
	.quad	.LBB178
	.quad	.LBE178-.LBB178
	.uleb128 0xa
	.long	.LASF375
	.long	0x4d6
	.quad	.LFB58
	.quad	.LFE58-.LFB58
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -35584
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0x2
	.long	.LASF82
	.value	0x3c5
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.uleb128 0x2
	.long	.LASF83
	.value	0x3c6
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF376
	.value	0x3b2
	.long	0x4d6
	.quad	.LFB55
	.quad	.LFE55-.LFB55
	.uleb128 0x1
	.byte	0x9c
	.long	0x3197
	.uleb128 0x1
	.long	.LASF234
	.value	0x3ad
	.byte	0x7
	.long	0x118f
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17888
	.uleb128 0x1
	.long	.LASF140
	.value	0x3ad
	.byte	0x16
	.long	0x2e11
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF377
	.value	0x3ad
	.byte	0x2c
	.long	0x3a7
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x4
	.quad	.LBB172
	.quad	.LBE172-.LBB172
	.uleb128 0xa
	.long	.LASF378
	.long	0x4d6
	.quad	.LFB56
	.quad	.LFE56-.LFB56
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -35584
	.byte	0x6
	.byte	0x23
	.uleb128 0x18
	.byte	0x6
	.uleb128 0x2
	.long	.LASF82
	.value	0x3b4
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.uleb128 0x2
	.long	.LASF83
	.value	0x3b5
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x2
	.long	.LASF223
	.value	0x3b6
	.byte	0xf
	.long	0x312
	.uleb128 0x2
	.byte	0x91
	.sleb128 -44
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF379
	.value	0x39d
	.long	0x4d6
	.quad	.LFB54
	.quad	.LFE54-.LFB54
	.uleb128 0x1
	.byte	0x9c
	.long	0x320f
	.uleb128 0x1
	.long	.LASF234
	.value	0x397
	.byte	0x7
	.long	0x118a
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17856
	.uleb128 0x1
	.long	.LASF140
	.value	0x397
	.byte	0x16
	.long	0x2e11
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17840
	.uleb128 0x1
	.long	.LASF380
	.value	0x397
	.byte	0x2c
	.long	0x3a7
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17857
	.uleb128 0x4
	.quad	.LBB166
	.quad	.LBE166-.LBB166
	.uleb128 0x2
	.long	.LASF217
	.value	0x39f
	.byte	0x7
	.long	0x4d6
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17824
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF381
	.value	0x371
	.long	0x4d6
	.quad	.LFB52
	.quad	.LFE52-.LFB52
	.uleb128 0x1
	.byte	0x9c
	.long	0x32f6
	.uleb128 0x1
	.long	.LASF234
	.value	0x36c
	.byte	0x1a
	.long	0x1185
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17888
	.uleb128 0x1
	.long	.LASF140
	.value	0x36c
	.byte	0x29
	.long	0x2e11
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x4
	.quad	.LBB160
	.quad	.LBE160-.LBB160
	.uleb128 0xa
	.long	.LASF382
	.long	0x4d6
	.quad	.LFB53
	.quad	.LFE53-.LFB53
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -35664
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0x2
	.long	.LASF82
	.value	0x372
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.uleb128 0x2
	.long	.LASF83
	.value	0x373
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x2
	.long	.LASF383
	.value	0x374
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -44
	.uleb128 0x2
	.long	.LASF384
	.value	0x377
	.byte	0xf
	.long	0x3a0
	.uleb128 0x2
	.byte	0x91
	.sleb128 -45
	.uleb128 0x2
	.long	.LASF385
	.value	0x379
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.uleb128 0x2
	.long	.LASF386
	.value	0x37c
	.byte	0xf
	.long	0x59c
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17856
	.uleb128 0x2
	.long	.LASF387
	.value	0x37d
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF388
	.value	0x366
	.long	0x4d6
	.quad	.LFB50
	.quad	.LFE50-.LFB50
	.uleb128 0x1
	.byte	0x9c
	.long	0x3393
	.uleb128 0x1
	.long	.LASF234
	.value	0x35f
	.byte	0x7
	.long	0x1180
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17872
	.uleb128 0x1
	.long	.LASF140
	.value	0x35f
	.byte	0x16
	.long	0x2e11
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x1
	.long	.LASF380
	.value	0x35f
	.byte	0x2c
	.long	0x3a7
	.uleb128 0x5
	.byte	0x91
	.sleb128 -80
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x4
	.quad	.LBB152
	.quad	.LBE152-.LBB152
	.uleb128 0xa
	.long	.LASF389
	.long	0x4d6
	.quad	.LFB51
	.quad	.LFE51-.LFB51
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -53328
	.byte	0x6
	.byte	0x23
	.uleb128 0x18
	.byte	0x6
	.uleb128 0x2
	.long	.LASF390
	.value	0x368
	.byte	0xf
	.long	0x4d6
	.uleb128 0x4
	.byte	0x91
	.sleb128 -35552
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF391
	.value	0x344
	.long	0x4d6
	.quad	.LFB48
	.quad	.LFE48-.LFB48
	.uleb128 0x1
	.byte	0x9c
	.long	0x348e
	.uleb128 0x1
	.long	.LASF234
	.value	0x33d
	.byte	0x7
	.long	0x117b
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17872
	.uleb128 0x1
	.long	.LASF140
	.value	0x33d
	.byte	0x16
	.long	0x2e11
	.uleb128 0x5
	.byte	0x91
	.sleb128 -80
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF380
	.value	0x33d
	.byte	0x2c
	.long	0x3a7
	.uleb128 0x5
	.byte	0x91
	.sleb128 -80
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x4
	.quad	.LBB144
	.quad	.LBE144-.LBB144
	.uleb128 0xa
	.long	.LASF392
	.long	0x4d6
	.quad	.LFB49
	.quad	.LFE49-.LFB49
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -35680
	.byte	0x6
	.byte	0x23
	.uleb128 0x18
	.byte	0x6
	.uleb128 0x2
	.long	.LASF82
	.value	0x346
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.uleb128 0x2
	.long	.LASF83
	.value	0x347
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x2
	.long	.LASF393
	.value	0x348
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -60
	.uleb128 0x2
	.long	.LASF394
	.value	0x349
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x2
	.long	.LASF395
	.value	0x34a
	.byte	0xf
	.long	0x31e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x2
	.long	.LASF174
	.value	0x34c
	.byte	0xf
	.long	0x636
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17872
	.uleb128 0x2
	.long	.LASF387
	.value	0x350
	.byte	0xf
	.long	0x31e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF396
	.value	0x31c
	.long	0x4d6
	.quad	.LFB46
	.quad	.LFE46-.LFB46
	.uleb128 0x1
	.byte	0x9c
	.long	0x35aa
	.uleb128 0x1
	.long	.LASF234
	.value	0x315
	.byte	0x7
	.long	0x1176
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17872
	.uleb128 0x1
	.long	.LASF140
	.value	0x315
	.byte	0x16
	.long	0x2e11
	.uleb128 0x5
	.byte	0x91
	.sleb128 -80
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF380
	.value	0x315
	.byte	0x2c
	.long	0x3a7
	.uleb128 0x5
	.byte	0x91
	.sleb128 -80
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x4
	.quad	.LBB135
	.quad	.LBE135-.LBB135
	.uleb128 0xa
	.long	.LASF397
	.long	0x4d6
	.quad	.LFB47
	.quad	.LFE47-.LFB47
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x8
	.byte	0x91
	.sleb128 -35696
	.byte	0x6
	.byte	0x23
	.uleb128 0x18
	.byte	0x6
	.uleb128 0x2
	.long	.LASF82
	.value	0x31e
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.uleb128 0x2
	.long	.LASF83
	.value	0x31f
	.byte	0x7
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x2
	.long	.LASF393
	.value	0x320
	.byte	0x7
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -60
	.uleb128 0x2
	.long	.LASF394
	.value	0x321
	.byte	0x7
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x2
	.long	.LASF398
	.value	0x322
	.byte	0x7
	.long	0x31e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x2
	.long	.LASF395
	.value	0x324
	.byte	0x7
	.long	0x31e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x2
	.long	.LASF399
	.value	0x325
	.byte	0x7
	.long	0x73c
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17856
	.uleb128 0x2
	.long	.LASF174
	.value	0x327
	.byte	0x7
	.long	0x946
	.uleb128 0x4
	.byte	0x91
	.sleb128 -17888
	.uleb128 0x2
	.long	.LASF387
	.value	0x32a
	.byte	0x7
	.long	0x31e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF400
	.value	0x2fe
	.long	0x73c
	.quad	.LFB44
	.quad	.LFE44-.LFB44
	.uleb128 0x1
	.byte	0x9c
	.long	0x3671
	.uleb128 0x1
	.long	.LASF234
	.value	0x2f6
	.byte	0x7
	.long	0x1171
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x1
	.long	.LASF106
	.value	0x2f6
	.byte	0x16
	.long	0x32a
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x1
	.long	.LASF108
	.value	0x2f7
	.byte	0x7
	.long	0x1033
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x4
	.quad	.LBB127
	.quad	.LBE127-.LBB127
	.uleb128 0xa
	.long	.LASF401
	.long	0x73c
	.quad	.LFB45
	.quad	.LFE45-.LFB45
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -136
	.byte	0x6
	.byte	0x23
	.uleb128 0x18
	.byte	0x6
	.uleb128 0x2
	.long	.LASF402
	.value	0x301
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.uleb128 0x1f
	.string	"low"
	.value	0x302
	.long	0x946
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x2
	.long	.LASF403
	.value	0x304
	.byte	0x7
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x2
	.long	.LASF269
	.value	0x306
	.byte	0x7
	.long	0x946
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF404
	.value	0x2e6
	.long	0x4d6
	.quad	.LFB42
	.quad	.LFE42-.LFB42
	.uleb128 0x1
	.byte	0x9c
	.long	0x36f7
	.uleb128 0x1
	.long	.LASF140
	.value	0x2e1
	.byte	0x7
	.long	0x2e11
	.uleb128 0x4
	.byte	0x91
	.sleb128 -24640
	.uleb128 0x1
	.long	.LASF82
	.value	0x2e1
	.byte	0x1d
	.long	0x32a
	.uleb128 0x4
	.byte	0x91
	.sleb128 -24644
	.uleb128 0x1
	.long	.LASF83
	.value	0x2e1
	.byte	0x24
	.long	0x32a
	.uleb128 0x4
	.byte	0x91
	.sleb128 -24648
	.uleb128 0x1
	.long	.LASF174
	.value	0x2e2
	.byte	0x7
	.long	0x36f7
	.uleb128 0x4
	.byte	0x91
	.sleb128 -24656
	.uleb128 0x1
	.long	.LASF87
	.value	0x2e2
	.byte	0x1d
	.long	0x3a7
	.uleb128 0x4
	.byte	0x91
	.sleb128 -24657
	.uleb128 0x1
	.long	.LASF387
	.value	0x2e2
	.byte	0x30
	.long	0x32a
	.uleb128 0x2
	.byte	0x91
	.sleb128 0
	.byte	0
	.uleb128 0xc
	.long	0x59c
	.uleb128 0x6
	.long	.LASF405
	.value	0x2d7
	.long	0x3a0
	.quad	.LFB41
	.quad	.LFE41-.LFB41
	.uleb128 0x1
	.byte	0x9c
	.long	0x376d
	.uleb128 0x1
	.long	.LASF234
	.value	0x2d1
	.byte	0x7
	.long	0x116c
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x1
	.long	.LASF140
	.value	0x2d1
	.byte	0x16
	.long	0x2e11
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x1
	.long	.LASF82
	.value	0x2d1
	.byte	0x2c
	.long	0x32a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x1
	.long	.LASF83
	.value	0x2d1
	.byte	0x33
	.long	0x32a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x1
	.long	.LASF380
	.value	0x2d2
	.byte	0x7
	.long	0x3a7
	.uleb128 0x3
	.byte	0x91
	.sleb128 -81
	.byte	0
	.uleb128 0x24
	.long	.LASF406
	.value	0x2cb
	.long	0x3a0
	.quad	.LFB40
	.quad	.LFE40-.LFB40
	.uleb128 0x1
	.byte	0x9c
	.long	0x37ad
	.uleb128 0x1
	.long	.LASF174
	.value	0x2c9
	.byte	0x13
	.long	0xe94
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0x1
	.long	.LASF112
	.value	0x2c9
	.byte	0x2e
	.long	0x33b
	.uleb128 0x2
	.byte	0x91
	.sleb128 -28
	.byte	0
	.uleb128 0x6
	.long	.LASF407
	.value	0x2aa
	.long	0x636
	.quad	.LFB39
	.quad	.LFE39-.LFB39
	.uleb128 0x1
	.byte	0x9c
	.long	0x3840
	.uleb128 0x1
	.long	.LASF234
	.value	0x29c
	.byte	0x7
	.long	0x1167
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x1
	.long	.LASF106
	.value	0x29c
	.byte	0x16
	.long	0x32a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -108
	.uleb128 0x1
	.long	.LASF107
	.value	0x29c
	.byte	0x33
	.long	0x3840
	.uleb128 0x3
	.byte	0x91
	.sleb128 -136
	.uleb128 0x1
	.long	.LASF108
	.value	0x29d
	.byte	0x7
	.long	0x1033
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x1
	.long	.LASF408
	.value	0x29e
	.byte	0x7
	.long	0x3a7
	.uleb128 0x2
	.byte	0x91
	.sleb128 0
	.uleb128 0x4
	.quad	.LBB109
	.quad	.LBE109-.LBB109
	.uleb128 0x2
	.long	.LASF140
	.value	0x2af
	.byte	0x7
	.long	0x69d
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.byte	0
	.byte	0
	.uleb128 0xc
	.long	0x3c1
	.uleb128 0x6
	.long	.LASF409
	.value	0x257
	.long	0x69d
	.quad	.LFB37
	.quad	.LFE37-.LFB37
	.uleb128 0x1
	.byte	0x9c
	.long	0x3930
	.uleb128 0x1
	.long	.LASF234
	.value	0x24a
	.byte	0x7
	.long	0x1162
	.uleb128 0x3
	.byte	0x91
	.sleb128 -176
	.uleb128 0x1
	.long	.LASF107
	.value	0x24a
	.byte	0x16
	.long	0x3840
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF140
	.value	0x24a
	.byte	0x33
	.long	0x3930
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x1
	.long	.LASF108
	.value	0x24b
	.byte	0x7
	.long	0x1033
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF408
	.value	0x24c
	.byte	0x7
	.long	0x3a7
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x20
	.uleb128 0x4
	.quad	.LBB99
	.quad	.LBE99-.LBB99
	.uleb128 0xa
	.long	.LASF410
	.long	0x69d
	.quad	.LFB38
	.quad	.LFE38-.LFB38
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -288
	.byte	0x6
	.byte	0x23
	.uleb128 0x28
	.byte	0x6
	.uleb128 0x2
	.long	.LASF411
	.value	0x25c
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.uleb128 0x2
	.long	.LASF412
	.value	0x25e
	.byte	0xf
	.long	0x59c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x2
	.long	.LASF413
	.value	0x25f
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x2
	.long	.LASF414
	.value	0x261
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -44
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0xc
	.long	0x69d
	.uleb128 0x6
	.long	.LASF415
	.value	0x243
	.long	0x3a0
	.quad	.LFB36
	.quad	.LFE36-.LFB36
	.uleb128 0x1
	.byte	0x9c
	.long	0x3975
	.uleb128 0x1
	.long	.LASF234
	.value	0x240
	.byte	0x7
	.long	0x115d
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0x1
	.long	.LASF140
	.value	0x240
	.byte	0x16
	.long	0x3930
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.byte	0
	.uleb128 0x6
	.long	.LASF416
	.value	0x212
	.long	0x59c
	.quad	.LFB32
	.quad	.LFE32-.LFB32
	.uleb128 0x1
	.byte	0x9c
	.long	0x3a60
	.uleb128 0x1
	.long	.LASF234
	.value	0x206
	.byte	0x7
	.long	0x1158
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0x1
	.long	.LASF106
	.value	0x206
	.byte	0x16
	.long	0x32a
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x1
	.long	.LASF107
	.value	0x206
	.byte	0x33
	.long	0x3840
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF108
	.value	0x207
	.byte	0x7
	.long	0x1033
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF408
	.value	0x208
	.byte	0x7
	.long	0x3a7
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x1c
	.uleb128 0x4
	.quad	.LBB87
	.quad	.LBE87-.LBB87
	.uleb128 0xa
	.long	.LASF417
	.long	0x59c
	.quad	.LFB33
	.quad	.LFE33-.LFB33
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -192
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x2
	.long	.LASF82
	.value	0x217
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.uleb128 0x2
	.long	.LASF418
	.value	0x218
	.byte	0xf
	.long	0x59c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x2
	.long	.LASF83
	.value	0x219
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x2
	.long	.LASF223
	.value	0x21a
	.byte	0xf
	.long	0x312
	.uleb128 0x2
	.byte	0x91
	.sleb128 -44
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF419
	.value	0x1ea
	.long	0x59c
	.quad	.LFB30
	.quad	.LFE30-.LFB30
	.uleb128 0x1
	.byte	0x9c
	.long	0x3b6a
	.uleb128 0x1
	.long	.LASF234
	.value	0x1df
	.byte	0x7
	.long	0x1153
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0x1
	.long	.LASF106
	.value	0x1df
	.byte	0x16
	.long	0x32a
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x1
	.long	.LASF107
	.value	0x1df
	.byte	0x33
	.long	0x3840
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF108
	.value	0x1e0
	.byte	0x7
	.long	0x1033
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF408
	.value	0x1e0
	.byte	0x36
	.long	0x3a7
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x1c
	.uleb128 0x4
	.quad	.LBB77
	.quad	.LBE77-.LBB77
	.uleb128 0xa
	.long	.LASF420
	.long	0x59c
	.quad	.LFB31
	.quad	.LFE31-.LFB31
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -176
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x2
	.long	.LASF82
	.value	0x1ee
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.uleb128 0x2
	.long	.LASF395
	.value	0x1ef
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x2
	.long	.LASF421
	.value	0x1f0
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -60
	.uleb128 0x2
	.long	.LASF422
	.value	0x1f2
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x2
	.long	.LASF174
	.value	0x1f3
	.byte	0xf
	.long	0x946
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0x2
	.long	.LASF387
	.value	0x1f6
	.byte	0xf
	.long	0x31e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF423
	.value	0x1b4
	.long	0x3a0
	.quad	.LFB29
	.quad	.LFE29-.LFB29
	.uleb128 0x1
	.byte	0x9c
	.long	0x3c20
	.uleb128 0x1
	.long	.LASF234
	.value	0x1b0
	.byte	0x21
	.long	0x114e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x4
	.quad	.LBB71
	.quad	.LBE71-.LBB71
	.uleb128 0x2
	.long	.LASF106
	.value	0x1b5
	.byte	0x7
	.long	0x53f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x2
	.long	.LASF424
	.value	0x1b6
	.byte	0x7
	.long	0x61f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x4
	.quad	.LBB76
	.quad	.LBE76-.LBB76
	.uleb128 0x2
	.long	.LASF82
	.value	0x1be
	.byte	0xd
	.long	0x31e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x2
	.long	.LASF418
	.value	0x1bf
	.byte	0xd
	.long	0x59c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x2
	.long	.LASF425
	.value	0x1c0
	.byte	0xd
	.long	0x31e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x2
	.long	.LASF328
	.value	0x1c1
	.byte	0xd
	.long	0xb7c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF426
	.value	0x17e
	.long	0x59c
	.quad	.LFB28
	.quad	.LFE28-.LFB28
	.uleb128 0x1
	.byte	0x9c
	.long	0x3ca1
	.uleb128 0x1
	.long	.LASF234
	.value	0x16c
	.byte	0x19
	.long	0x1149
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF106
	.value	0x16c
	.byte	0x28
	.long	0x32a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x4
	.quad	.LBB66
	.quad	.LBE66-.LBB66
	.uleb128 0x2
	.long	.LASF427
	.value	0x17f
	.byte	0x7
	.long	0x53f
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.uleb128 0x2
	.long	.LASF428
	.value	0x180
	.byte	0x7
	.long	0x32f
	.uleb128 0x2
	.byte	0x91
	.sleb128 -60
	.uleb128 0x2
	.long	.LASF115
	.value	0x181
	.byte	0x7
	.long	0x3a0
	.uleb128 0x2
	.byte	0x91
	.sleb128 -53
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF429
	.value	0x159
	.long	0x31e
	.quad	.LFB25
	.quad	.LFE25-.LFB25
	.uleb128 0x1
	.byte	0x9c
	.long	0x3d6c
	.uleb128 0x1
	.long	.LASF234
	.value	0x150
	.byte	0x7
	.long	0x1144
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF430
	.value	0x150
	.byte	0x16
	.long	0x3840
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x1
	.long	.LASF106
	.value	0x150
	.byte	0x39
	.long	0x32a
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x18
	.uleb128 0x1
	.long	.LASF431
	.value	0x151
	.byte	0x7
	.long	0x597
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x1c
	.uleb128 0x1
	.long	.LASF108
	.value	0x152
	.byte	0x7
	.long	0x1033
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x4
	.quad	.LBB58
	.quad	.LBE58-.LBB58
	.uleb128 0xa
	.long	.LASF432
	.long	0x31e
	.quad	.LFB26
	.quad	.LFE26-.LFB26
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -56
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x2
	.long	.LASF82
	.value	0x15d
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.uleb128 0x2
	.long	.LASF83
	.value	0x15e
	.byte	0xf
	.long	0x31e
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF433
	.value	0x13b
	.long	0x312
	.quad	.LFB24
	.quad	.LFE24-.LFB24
	.uleb128 0x1
	.byte	0x9c
	.long	0x3df0
	.uleb128 0x1
	.long	.LASF234
	.value	0x131
	.byte	0x7
	.long	0x113f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF107
	.value	0x131
	.byte	0x16
	.long	0x3840
	.uleb128 0x3
	.byte	0x91
	.sleb128 -104
	.uleb128 0x1
	.long	.LASF82
	.value	0x131
	.byte	0x33
	.long	0x32a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -108
	.uleb128 0x1
	.long	.LASF83
	.value	0x131
	.byte	0x3a
	.long	0x32a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x4
	.quad	.LBB49
	.quad	.LBE49-.LBB49
	.uleb128 0x2
	.long	.LASF223
	.value	0x13f
	.byte	0x7
	.long	0x3f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.uleb128 0x6
	.long	.LASF434
	.value	0x111
	.long	0x31e
	.quad	.LFB23
	.quad	.LFE23-.LFB23
	.uleb128 0x1
	.byte	0x9c
	.long	0x3e72
	.uleb128 0x1
	.long	.LASF234
	.value	0x109
	.byte	0x7
	.long	0x113a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x1
	.long	.LASF106
	.value	0x109
	.byte	0x16
	.long	0x32a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -84
	.uleb128 0x1
	.long	.LASF248
	.value	0x109
	.byte	0x33
	.long	0x29f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -85
	.uleb128 0x4
	.quad	.LBB44
	.quad	.LBE44-.LBB44
	.uleb128 0x2
	.long	.LASF427
	.value	0x115
	.byte	0x7
	.long	0x53f
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.uleb128 0x2
	.long	.LASF115
	.value	0x116
	.byte	0x7
	.long	0x3a0
	.uleb128 0x2
	.byte	0x91
	.sleb128 -53
	.byte	0
	.byte	0
	.uleb128 0x40
	.long	.LASF435
	.byte	0x2
	.byte	0xe9
	.byte	0x4
	.long	0x54a
	.quad	.LFB21
	.quad	.LFE21-.LFB21
	.uleb128 0x1
	.byte	0x9c
	.long	0x3f41
	.uleb128 0xb
	.long	.LASF234
	.byte	0x2
	.byte	0xea
	.byte	0x7
	.long	0x1135
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0xb
	.long	.LASF106
	.byte	0x2
	.byte	0xea
	.byte	0x16
	.long	0x53f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -164
	.uleb128 0xb
	.long	.LASF248
	.byte	0x2
	.byte	0xea
	.byte	0x30
	.long	0x29f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -165
	.uleb128 0xb
	.long	.LASF115
	.byte	0x2
	.byte	0xeb
	.byte	0x7
	.long	0x3a0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -105
	.uleb128 0x1d
	.long	.LLRL1
	.uleb128 0x9
	.long	.LASF436
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x9
	.long	.LASF437
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x15
	.long	0x10d
	.long	0x3f0a
	.uleb128 0x31
	.long	0x52
	.long	0x3ed9
	.long	0x3ee6
	.byte	0
	.uleb128 0xe
	.long	.LASF438
	.byte	0xf5
	.byte	0x7
	.long	0x3f19
	.uleb128 0x3
	.byte	0x91
	.sleb128 -104
	.uleb128 0xc
	.long	0x3ef3
	.uleb128 0x4
	.quad	.LBB41
	.quad	.LBE41-.LBB41
	.uleb128 0xe
	.long	.LASF223
	.byte	0xf9
	.byte	0xb
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x11
	.long	.LASF439
	.byte	0xd0
	.long	0x31e
	.quad	.LFB20
	.quad	.LFE20-.LFB20
	.uleb128 0x1
	.byte	0x9c
	.long	0x3fb0
	.uleb128 0xb
	.long	.LASF234
	.byte	0x2
	.byte	0xc8
	.byte	0x19
	.long	0x1130
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0xb
	.long	.LASF106
	.byte	0x2
	.byte	0xc8
	.byte	0x28
	.long	0x32a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -84
	.uleb128 0x4
	.quad	.LBB32
	.quad	.LBE32-.LBB32
	.uleb128 0xe
	.long	.LASF427
	.byte	0xd1
	.byte	0x7
	.long	0x53f
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.uleb128 0xe
	.long	.LASF115
	.byte	0xd2
	.byte	0x7
	.long	0x3a0
	.uleb128 0x2
	.byte	0x91
	.sleb128 -53
	.byte	0
	.byte	0
	.uleb128 0x11
	.long	.LASF440
	.byte	0xbf
	.long	0x31e
	.quad	.LFB19
	.quad	.LFE19-.LFB19
	.uleb128 0x1
	.byte	0x9c
	.long	0x4011
	.uleb128 0xb
	.long	.LASF234
	.byte	0x2
	.byte	0xb8
	.byte	0x16
	.long	0x112b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0xb
	.long	.LASF106
	.byte	0x2
	.byte	0xb8
	.byte	0x25
	.long	0x32a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -84
	.uleb128 0x4
	.quad	.LBB28
	.quad	.LBE28-.LBB28
	.uleb128 0xe
	.long	.LASF427
	.byte	0xc0
	.byte	0x7
	.long	0x53f
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.byte	0
	.byte	0
	.uleb128 0x11
	.long	.LASF441
	.byte	0xad
	.long	0x3a0
	.quad	.LFB18
	.quad	.LFE18-.LFB18
	.uleb128 0x1
	.byte	0x9c
	.long	0x4050
	.uleb128 0xb
	.long	.LASF234
	.byte	0x2
	.byte	0xaa
	.byte	0x1a
	.long	0x1126
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0xb
	.long	.LASF140
	.byte	0x2
	.byte	0xaa
	.byte	0x29
	.long	0x2e11
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.byte	0
	.uleb128 0x11
	.long	.LASF442
	.byte	0x88
	.long	0x3a0
	.quad	.LFB16
	.quad	.LFE16-.LFB16
	.uleb128 0x1
	.byte	0x9c
	.long	0x40c1
	.uleb128 0xb
	.long	.LASF234
	.byte	0x2
	.byte	0x85
	.byte	0x1a
	.long	0x1121
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0xb
	.long	.LASF107
	.byte	0x2
	.byte	0x85
	.byte	0x29
	.long	0x3840
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x4
	.quad	.LBB19
	.quad	.LBE19-.LBB19
	.uleb128 0x9
	.long	.LASF443
	.long	0x312
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.uleb128 0x1d
	.long	.LLRL0
	.uleb128 0x41
	.string	"i"
	.byte	0x2
	.byte	0x89
	.byte	0xf
	.long	0x52
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x11
	.long	.LASF444
	.byte	0x65
	.long	0x10d9
	.quad	.LFB11
	.quad	.LFE11-.LFB11
	.uleb128 0x1
	.byte	0x9c
	.long	0x416a
	.uleb128 0xb
	.long	.LASF238
	.byte	0x2
	.byte	0x65
	.byte	0x19
	.long	0x111c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x4
	.quad	.LBB13
	.quad	.LBE13-.LBB13
	.uleb128 0xa
	.long	.LASF445
	.long	0x10d9
	.quad	.LFB12
	.quad	.LFE12-.LFB12
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -104
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0x4
	.quad	.LBB12
	.quad	.LBE12-.LBB12
	.uleb128 0x9
	.long	.LASF446
	.long	0x52
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x15
	.long	0x10d
	.long	0x4156
	.uleb128 0x2b
	.long	0x52
	.long	0x4136
	.byte	0
	.uleb128 0xe
	.long	.LASF234
	.byte	0x6b
	.byte	0x7
	.long	0x4143
	.uleb128 0x4
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x11
	.long	.LASF447
	.byte	0x58
	.long	0x2a4
	.quad	.LFB9
	.quad	.LFE9-.LFB9
	.uleb128 0x1
	.byte	0x9c
	.long	0x41bd
	.uleb128 0xb
	.long	.LASF239
	.byte	0x1
	.byte	0x2c
	.byte	0x15
	.long	0x12c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x16
	.long	.LASF448
	.long	0x2a4
	.quad	.LFB10
	.quad	.LFE10-.LFB10
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -40
	.byte	0x6
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0
	.uleb128 0x11
	.long	.LASF449
	.byte	0x21
	.long	0x10d9
	.quad	.LFB7
	.quad	.LFE7-.LFB7
	.uleb128 0x1
	.byte	0x9c
	.long	0x4210
	.uleb128 0xb
	.long	.LASF248
	.byte	0x1
	.byte	0x32
	.byte	0x17
	.long	0x29f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x16
	.long	.LASF450
	.long	0x10d9
	.quad	.LFB8
	.quad	.LFE8-.LFB8
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -40
	.byte	0x6
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0
	.uleb128 0x11
	.long	.LASF451
	.byte	0x1a
	.long	0x3a0
	.quad	.LFB5
	.quad	.LFE5-.LFB5
	.uleb128 0x1
	.byte	0x9c
	.long	0x4262
	.uleb128 0xb
	.long	.LASF248
	.byte	0x1
	.byte	0x1f
	.byte	0x1c
	.long	0x29f
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0x42
	.long	.LASF452
	.long	0x3a0
	.quad	.LFB6
	.quad	.LFE6-.LFB6
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -24
	.byte	0x6
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0
	.uleb128 0x43
	.long	.LASF458
	.byte	0x1
	.byte	0x30
	.byte	0x4
	.long	0x3a0
	.quad	.LFB4
	.quad	.LFE4-.LFB4
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0xb
	.long	.LASF239
	.byte	0x1
	.byte	0x30
	.byte	0x1f
	.long	0x12c
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.byte	0
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x28
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x1c
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x10
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0xd
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x14
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x15
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x16
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x17
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x18
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x19
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0x5
	.byte	0
	.byte	0
	.uleb128 0x1a
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3e
	.uleb128 0x21
	.sleb128 7
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1b
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0x5
	.byte	0
	.byte	0
	.uleb128 0x1c
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x1d
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x55
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x1e
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1f
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 7
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x20
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x21
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0x22
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0x5
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x23
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0x18
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x24
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x25
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x26
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x27
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 40
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x28
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x18
	.uleb128 0x2f
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x29
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x2a
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0x5
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x2b
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x2c
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x3e
	.uleb128 0x21
	.sleb128 5
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x2d
	.uleb128 0x1e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 6
	.byte	0
	.byte	0
	.uleb128 0x2e
	.uleb128 0x3a
	.byte	0
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x18
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 11
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x30
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 11
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x31
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x32
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x33
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x34
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x55
	.uleb128 0x17
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x35
	.uleb128 0x21
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x36
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x37
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x38
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x39
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x3a
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x3b
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x3c
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x3d
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x3e
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x55
	.uleb128 0x17
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x3f
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x40
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x41
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x42
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x43
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x12c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.LFE11-.Ltext0
	.quad	.LFB16
	.quad	.LFE16-.LFB16
	.quad	.LFB18
	.quad	.LFE20-.LFB18
	.quad	.LFB21
	.quad	.LFE25-.LFB21
	.quad	.LFB28
	.quad	.LFE32-.LFB28
	.quad	.LFB36
	.quad	.LFE42-.LFB36
	.quad	.LFB45
	.quad	.LFE66-.LFB45
	.quad	.LFB74
	.quad	.LFE88-.LFB74
	.quad	.LFB92
	.quad	.LFE91-.LFB92
	.quad	.LFB95
	.quad	.LFE94-.LFB95
	.quad	.LFB97
	.quad	.LFE115-.LFB97
	.quad	.LFB119
	.quad	.LFE125-.LFB119
	.quad	.LFB127
	.quad	.LFE138-.LFB127
	.quad	.LFB140
	.quad	.LFE144-.LFB140
	.quad	.LFB146
	.quad	.LFE148-.LFB146
	.quad	.LFB150
	.quad	.LFE150-.LFB150
	.quad	.LFB154
	.quad	.Letext0-.LFB154
	.quad	0
	.quad	0
	.section	.debug_rnglists,"",@progbits
.Ldebug_ranges0:
	.long	.Ldebug_ranges3-.Ldebug_ranges2
.Ldebug_ranges2:
	.value	0x5
	.byte	0x8
	.byte	0
	.long	0
.LLRL0:
	.byte	0x5
	.quad	.LBB22
	.byte	0x4
	.uleb128 .LBB22-.LBB22
	.uleb128 .LBE22-.LBB22
	.byte	0x4
	.uleb128 .LBB24-.LBB22
	.uleb128 .LBE24-.LBB22
	.byte	0
.LLRL1:
	.byte	0x5
	.quad	.LBB37
	.byte	0x4
	.uleb128 .LBB37-.LBB37
	.uleb128 .LBE37-.LBB37
	.byte	0x4
	.uleb128 .LBB43-.LBB37
	.uleb128 .LBE43-.LBB37
	.byte	0
.LLRL2:
	.byte	0x5
	.quad	.LBB337
	.byte	0x4
	.uleb128 .LBB337-.LBB337
	.uleb128 .LBE337-.LBB337
	.byte	0x4
	.uleb128 .LBB344-.LBB337
	.uleb128 .LBE344-.LBB337
	.byte	0
.LLRL3:
	.byte	0x5
	.quad	.LBB338
	.byte	0x4
	.uleb128 .LBB338-.LBB338
	.uleb128 .LBE338-.LBB338
	.byte	0x4
	.uleb128 .LBB343-.LBB338
	.uleb128 .LBE343-.LBB338
	.byte	0
.LLRL4:
	.byte	0x5
	.quad	.LBB515
	.byte	0x4
	.uleb128 .LBB515-.LBB515
	.uleb128 .LBE515-.LBB515
	.byte	0x4
	.uleb128 .LBB524-.LBB515
	.uleb128 .LBE524-.LBB515
	.byte	0
.LLRL5:
	.byte	0x5
	.quad	.LBB542
	.byte	0x4
	.uleb128 .LBB542-.LBB542
	.uleb128 .LBE542-.LBB542
	.byte	0x4
	.uleb128 .LBB544-.LBB542
	.uleb128 .LBE544-.LBB542
	.byte	0
.LLRL6:
	.byte	0x7
	.quad	.Ltext0
	.uleb128 .LFE11-.Ltext0
	.byte	0x7
	.quad	.LFB16
	.uleb128 .LFE16-.LFB16
	.byte	0x7
	.quad	.LFB18
	.uleb128 .LFE20-.LFB18
	.byte	0x7
	.quad	.LFB21
	.uleb128 .LFE25-.LFB21
	.byte	0x7
	.quad	.LFB28
	.uleb128 .LFE32-.LFB28
	.byte	0x7
	.quad	.LFB36
	.uleb128 .LFE42-.LFB36
	.byte	0x7
	.quad	.LFB45
	.uleb128 .LFE66-.LFB45
	.byte	0x7
	.quad	.LFB74
	.uleb128 .LFE88-.LFB74
	.byte	0x7
	.quad	.LFB92
	.uleb128 .LFE91-.LFB92
	.byte	0x7
	.quad	.LFB95
	.uleb128 .LFE94-.LFB95
	.byte	0x7
	.quad	.LFB97
	.uleb128 .LFE115-.LFB97
	.byte	0x7
	.quad	.LFB119
	.uleb128 .LFE125-.LFB119
	.byte	0x7
	.quad	.LFB127
	.uleb128 .LFE138-.LFB127
	.byte	0x7
	.quad	.LFB140
	.uleb128 .LFE144-.LFB140
	.byte	0x7
	.quad	.LFB146
	.uleb128 .LFE148-.LFB146
	.byte	0x7
	.quad	.LFB150
	.uleb128 .LFE150-.LFB150
	.byte	0x7
	.quad	.LFB154
	.uleb128 .Letext0-.LFB154
	.byte	0
.Ldebug_ranges3:
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF386:
	.string	"default_value"
.LASF298:
	.string	"silver_output_profile__read_chain_into"
.LASF24:
	.string	"silver_output_profile__spark_mode_name"
.LASF323:
	.string	"last"
.LASF187:
	.string	"system__address"
.LASF125:
	.string	"nonliteral_seen"
.LASF425:
	.string	"after_name"
.LASF220:
	.string	"silver_output_profile__bound_of"
.LASF431:
	.string	"operation"
.LASF239:
	.string	"form"
.LASF201:
	.string	"silver_output_profile__empty_environment"
.LASF61:
	.string	"silver_output_profile__assignment_target"
.LASF172:
	.string	"operator"
.LASF142:
	.string	"output"
.LASF271:
	.string	"definite"
.LASF138:
	.string	"silver_output_profile__scalar_constraint_result"
.LASF277:
	.string	"silver_output_profile__scan_step___wrapped_statements"
.LASF112:
	.string	"capacity"
.LASF199:
	.string	"silver_output_profile__comment_introducer"
.LASF391:
	.string	"silver_output_profile__string_declaration_at"
.LASF392:
	.string	"silver_output_profile__string_declaration_at___wrapped_statements"
.LASF6:
	.string	"silver_output_profile__names___XRP_silver_names___XE"
.LASF369:
	.string	"silver_output_profile__comparison_at___wrapped_statements"
.LASF251:
	.string	"silver_output_profile__read_statements___wrapped_statements__TresultS__T2613b__TT2614bP1___U"
.LASF276:
	.string	"silver_output_profile__statement_body"
.LASF130:
	.string	"silver_output_profile__expression_result"
.LASF101:
	.string	"declared_bounds"
.LASF146:
	.string	"silver_path_facts__context"
.LASF12:
	.string	"integer"
.LASF10:
	.string	"silver_output_profile__length_intervals___XRP_silver_length_intervals___XE"
.LASF37:
	.string	"silver_output_profile__assignment"
.LASF438:
	.string	"word"
.LASF53:
	.string	"silver_output_profile__greater_equal"
.LASF20:
	.string	"silver_output_profile__procedure_keyword"
.LASF228:
	.string	"silver_output_profile__valid_declaration_values"
.LASF382:
	.string	"silver_output_profile__argument_at___wrapped_statements"
.LASF269:
	.string	"high"
.LASF29:
	.string	"silver_output_profile__left_parenthesis"
.LASF427:
	.string	"next"
.LASF178:
	.string	"silver_scalars__comparison"
.LASF246:
	.string	"next_token"
.LASF335:
	.string	"silver_output_profile__read_string_in_flow___wrapped_statements"
.LASF366:
	.string	"silver_output_profile__step___wrapped_statements"
.LASF444:
	.string	"silver_output_profile__normalized"
.LASF406:
	.string	"silver_output_profile__fits"
.LASF184:
	.string	"silver_scalars__greater_equal"
.LASF243:
	.string	"silver_output_profile__read_form"
.LASF295:
	.string	"silver_output_profile__scalar_target"
.LASF200:
	.string	"silver_output_profile__empty_binding"
.LASF455:
	.string	"silver_output_profile__token_sequence"
.LASF17:
	.string	"silver_output_profile__token_kind"
.LASF47:
	.string	"silver_output_profile__and_keyword"
.LASF74:
	.string	"silver_output_profile__loop_keyword"
.LASF379:
	.string	"silver_output_profile__read_declarations"
.LASF314:
	.string	"right_target"
.LASF225:
	.string	"silver_output_profile__expand_body"
.LASF398:
	.string	"type_first"
.LASF110:
	.string	"dynamic_after"
.LASF376:
	.string	"silver_output_profile__target_at"
.LASF194:
	.string	"silver_scalar_literals__literal_result"
.LASF364:
	.string	"T871b"
.LASF156:
	.string	"silver_output_profile__end_only"
.LASF77:
	.string	"P_ARRAY"
.LASF244:
	.string	"B2659b"
.LASF245:
	.string	"B2663b"
.LASF294:
	.string	"silver_output_profile__body_string_target___wrapped_statements"
.LASF32:
	.string	"silver_output_profile__dot"
.LASF153:
	.string	"silver_output_profile__body_scan"
.LASF278:
	.string	"silver_output_profile__statement_body___wrapped_statements"
.LASF291:
	.string	"silver_output_profile__scalar_assignment_body___wrapped_statements"
.LASF203:
	.string	"silver_output_profile__invalid_state"
.LASF448:
	.string	"silver_output_profile__tokens___wrapped_statements"
.LASF360:
	.string	"silver_output_profile__initial_flow___wrapped_statements"
.LASF46:
	.string	"silver_output_profile__ampersand"
.LASF430:
	.string	"environment"
.LASF218:
	.string	"silver_output_profile__valid_condition"
.LASF127:
	.string	"reference"
.LASF41:
	.string	"silver_output_profile__input_is_valid_name"
.LASF457:
	.string	"silver_output_profile__read_condition_into___wrapped_statements"
.LASF62:
	.string	"silver_output_profile__target_reference"
.LASF241:
	.string	"silver_output_profile__uses_arguments"
.LASF114:
	.string	"silver_output_lexical__cursor"
.LASF372:
	.string	"silver_output_profile__assignment_at"
.LASF67:
	.string	"silver_output_profile__null_keyword"
.LASF215:
	.string	"silver_output_profile__scalar_operator"
.LASF380:
	.string	"arguments"
.LASF44:
	.string	"silver_output_profile__elsif_keyword"
.LASF93:
	.string	"silver_scalar_expressions__binding_count"
.LASF27:
	.string	"silver_output_profile__put_line_name"
.LASF272:
	.string	"inner"
.LASF148:
	.string	"invalid_reachable"
.LASF25:
	.string	"silver_output_profile__on_name"
.LASF328:
	.string	"number"
.LASF60:
	.string	"silver_output_profile__declarations"
.LASF322:
	.string	"silver_output_profile__bare_target___wrapped_statements"
.LASF290:
	.string	"silver_output_profile__scalar_assignment_body"
.LASF4:
	.string	"silver_output_profile__max_concatenations"
.LASF250:
	.string	"stop"
.LASF422:
	.string	"attribute_after"
.LASF313:
	.string	"left_target"
.LASF109:
	.string	"dynamic_first"
.LASF337:
	.string	"silver_output_profile__read_scalar_in_flow"
.LASF56:
	.string	"silver_output_profile__less_equal"
.LASF91:
	.string	"count"
.LASF223:
	.string	"index"
.LASF408:
	.string	"integer_hidden"
.LASF297:
	.string	"silver_output_profile__read_condition_into"
.LASF263:
	.string	"silver_output_profile__conditional_body___wrapped_statements__TconditionS__T2460b__TT2461bP1___U"
.LASF249:
	.string	"silver_output_profile__read_statements"
.LASF108:
	.string	"scalar_names"
.LASF217:
	.string	"result"
.LASF158:
	.string	"silver_output_profile__arm_boundary"
.LASF420:
	.string	"silver_output_profile__image_at___wrapped_statements"
.LASF433:
	.string	"silver_output_profile__lookup_name"
.LASF145:
	.string	"silver_path_facts__length_value"
.LASF120:
	.string	"silver_names__validity_call"
.LASF353:
	.string	"silver_output_profile__valid_context"
.LASF70:
	.string	"silver_output_profile__integer_name"
.LASF233:
	.string	"silver_output_profile__allowed_source"
.LASF450:
	.string	"silver_output_profile__spelling___wrapped_statements"
.LASF354:
	.string	"R965b"
.LASF451:
	.string	"silver_output_profile__is_word_token"
.LASF293:
	.string	"silver_output_profile__body_string_target"
.LASF104:
	.string	"silver_scalar_expressions__environment"
.LASF248:
	.string	"token"
.LASF72:
	.string	"silver_output_profile__in_keyword"
.LASF405:
	.string	"silver_output_profile__new_name_allowed"
.LASF252:
	.string	"silver_output_profile__alternative_body"
.LASF193:
	.string	"long_long_integer"
.LASF209:
	.string	"silver_profile"
.LASF362:
	.string	"R878b"
.LASF208:
	.string	"silver_output_profile__invalid_scan"
.LASF206:
	.string	"silver_output_profile__invalid_expression_state"
.LASF144:
	.string	"declaration_count"
.LASF166:
	.string	"silver_path_facts__unequal"
.LASF210:
	.string	"silver_output_lexical"
.LASF161:
	.string	"silver_path_facts__operand_count"
.LASF96:
	.string	"lower"
.LASF174:
	.string	"value"
.LASF261:
	.string	"silver_output_profile__conditional_body___wrapped_statements"
.LASF333:
	.string	"silver_output_profile__body_token___wrapped_statements__R1168b__TresultS__T1169b__TT1170bP1___U"
.LASF5:
	.string	"silver_output_profile__max_bindings"
.LASF205:
	.string	"silver_output_profile__invalid_expression"
.LASF212:
	.string	"truth"
.LASF86:
	.string	"dynamic"
.LASF394:
	.string	"constant_after"
.LASF143:
	.string	"silver_output_profile__body_context"
.LASF118:
	.string	"silver_names__partial_output_call"
.LASF385:
	.string	"prefix"
.LASF262:
	.string	"silver_output_profile__conditional_body___wrapped_statements__TresultS__T2454b__TT2455bP1___U"
.LASF396:
	.string	"silver_output_profile__scalar_declaration_at"
.LASF111:
	.string	"target"
.LASF442:
	.string	"silver_output_profile__valid_names"
.LASF247:
	.string	"silver_output_profile__scan_step"
.LASF359:
	.string	"silver_output_profile__initial_flow"
.LASF367:
	.string	"silver_output_profile__capacity_at"
.LASF13:
	.string	"character"
.LASF119:
	.string	"silver_names__argument_call"
.LASF195:
	.string	"silver_output_lexical__decimal_result"
.LASF255:
	.string	"silver_output_profile__alternative_body___wrapped_statements__TresultS__T2539b__TT2540bP1___U"
.LASF124:
	.string	"dynamic_seen"
.LASF34:
	.string	"silver_output_profile__colon"
.LASF154:
	.string	"facts"
.LASF69:
	.string	"silver_output_profile__context_clauses"
.LASF102:
	.string	"silver_output_profile__binding_array"
.LASF324:
	.string	"silver_output_profile__invalidate_condition"
.LASF170:
	.string	"silver_path_facts__greater_equal"
.LASF2:
	.string	"silver_output_profile__max_source_length"
.LASF116:
	.string	"silver_names__operation_kind"
.LASF151:
	.string	"path"
.LASF347:
	.string	"R1027b"
.LASF240:
	.string	"silver_output_profile__uses_assignment"
.LASF98:
	.string	"silver_scalar_expressions__binding"
.LASF137:
	.string	"complete"
.LASF381:
	.string	"silver_output_profile__argument_at"
.LASF358:
	.string	"silver_output_profile__body_of__R918b__TresultS__T919b__TT920bP1___U"
.LASF350:
	.string	"silver_output_profile__join_into"
.LASF452:
	.string	"silver_output_profile__is_word_token___wrapped_statements"
.LASF192:
	.string	"silver_scalar_literals__literal_value"
.LASF43:
	.string	"silver_output_profile__else_keyword"
.LASF399:
	.string	"constraint"
.LASF306:
	.string	"left_length"
.LASF435:
	.string	"silver_output_profile__match_token"
.LASF94:
	.string	"silver_scalars__value"
.LASF259:
	.string	"silver_output_profile__alternative_body___wrapped_statements__TyesS__TT2545bP1___U"
.LASF78:
	.string	"P_BOUNDS"
.LASF237:
	.string	"silver_output_profile__uses_output"
.LASF447:
	.string	"silver_output_profile__tokens"
.LASF122:
	.string	"silver_output_profile__value_result"
.LASF351:
	.string	"R994b"
.LASF401:
	.string	"silver_output_profile__scalar_constraint_at___wrapped_statements"
.LASF171:
	.string	"silver_output_profile__comparison_result"
.LASF30:
	.string	"silver_output_profile__right_parenthesis"
.LASF28:
	.string	"silver_output_profile__end_keyword"
.LASF236:
	.string	"string"
.LASF221:
	.string	"silver_output_profile__summary_of"
.LASF234:
	.string	"text"
.LASF191:
	.string	"silver_scalar_literals__literal_position"
.LASF229:
	.string	"silver_output_profile__valid_flow__B2816b__L2817b__T2818b___U"
.LASF282:
	.string	"silver_output_profile__body_tail"
.LASF113:
	.string	"positive"
.LASF16:
	.string	"silver_output_profile__form_kind"
.LASF357:
	.string	"silver_output_profile__body_of"
.LASF90:
	.string	"silver_output_profile__binding_environment"
.LASF232:
	.string	"R2787b"
.LASF429:
	.string	"silver_output_profile__call_after"
.LASF327:
	.string	"silver_output_profile__length_at___wrapped_statements"
.LASF19:
	.string	"silver_output_profile__io_name"
.LASF415:
	.string	"silver_output_profile__valid_expression_state"
.LASF361:
	.string	"silver_output_profile__initial_flow___wrapped_statements__TresultS__TT872bP1___U"
.LASF409:
	.string	"silver_output_profile__expression_step"
.LASF58:
	.string	"silver_output_profile__equal"
.LASF21:
	.string	"silver_output_profile__main_name"
.LASF150:
	.string	"silver_output_profile__scalar_flow"
.LASF15:
	.string	"silver_output_profile__argument_form"
.LASF18:
	.string	"silver_output_profile__with_keyword"
.LASF289:
	.string	"silver_output_profile__basic_body___wrapped_statements__TresultS__T1970b__TT1971bP1___U"
.LASF303:
	.string	"silver_output_profile__read_relation_into"
.LASF264:
	.string	"silver_output_profile__conditional_body___wrapped_statements__TconditionS__T2462b__TT2463bP1___U"
.LASF88:
	.string	"boolean"
.LASF275:
	.string	"R2373b"
.LASF300:
	.string	"right"
.LASF163:
	.string	"silver_path_facts__bound"
.LASF222:
	.string	"silver_output_profile__valid_flow"
.LASF128:
	.string	"silver_output_profile__concatenation_count"
.LASF296:
	.string	"silver_output_profile__scalar_target___wrapped_statements"
.LASF188:
	.string	"system__storage_elements__Tstorage_offsetB"
.LASF121:
	.string	"silver_names__reject_call"
.LASF456:
	.string	"silver_output_profile___elabb"
.LASF8:
	.string	"silver_output_profile__scalar_expressions___XRP_silver_scalar_expressions___XE"
.LASF219:
	.string	"silver_output_profile__binding_summary"
.LASF14:
	.string	"silver_output_profile__direct_form"
.LASF135:
	.string	"depth"
.LASF105:
	.string	"silver_output_profile__parser_state"
.LASF439:
	.string	"silver_output_profile__name_after"
.LASF216:
	.string	"context"
.LASF371:
	.string	"silver_output_profile__output_at___wrapped_statements"
.LASF329:
	.string	"silver_output_profile__scalar_comparison_at"
.LASF71:
	.string	"silver_output_profile__for_keyword"
.LASF186:
	.string	"silver_output_profile__token_index"
.LASF167:
	.string	"silver_path_facts__less"
.LASF411:
	.string	"open_after"
.LASF31:
	.string	"silver_output_profile__semicolon"
.LASF226:
	.string	"scan"
.LASF374:
	.string	"silver_output_profile__dynamic_at"
.LASF107:
	.string	"names"
.LASF414:
	.string	"close_after"
.LASF213:
	.string	"refined"
.LASF316:
	.string	"silver_output_profile__read_primary_into"
.LASF204:
	.string	"silver_output_profile__invalid_value"
.LASF224:
	.string	"silver_output_profile__included"
.LASF52:
	.string	"silver_output_profile__greater"
.LASF403:
	.string	"delimiter_after"
.LASF434:
	.string	"silver_output_profile__take_token"
.LASF284:
	.string	"silver_output_profile__body_tail___wrapped_statements__TresultS__T2089b__TT2090bP1___U"
.LASF103:
	.string	"silver_scalar_expressions__binding_array"
.LASF202:
	.string	"silver_output_profile__initial_state"
.LASF378:
	.string	"silver_output_profile__target_at___wrapped_statements"
.LASF95:
	.string	"silver_scalars__interval"
.LASF368:
	.string	"silver_output_profile__comparison_at"
.LASF169:
	.string	"silver_path_facts__greater"
.LASF152:
	.string	"values"
.LASF311:
	.string	"right_length"
.LASF388:
	.string	"silver_output_profile__declaration_at"
.LASF343:
	.string	"silver_output_profile__reading_names___wrapped_statements__L_11__T1092b___U"
.LASF446:
	.string	"silver_output_profile__normalized___wrapped_statements__TTtextSP1___U"
.LASF363:
	.string	"___ghost_silver_output_profile__initial_flow__R891b__B906b__L907b__T908b___U"
.LASF26:
	.string	"silver_output_profile__begin_keyword"
.LASF131:
	.string	"dynamic_count"
.LASF410:
	.string	"silver_output_profile__expression_step___wrapped_statements"
.LASF197:
	.string	"silver_integer_literals__literal_value"
.LASF377:
	.string	"same_target"
.LASF331:
	.string	"silver_output_profile__body_token"
.LASF123:
	.string	"minimum_length"
.LASF310:
	.string	"silver_output_profile__read_relation_into___wrapped_statements__L_12__T1507b___U"
.LASF302:
	.string	"selected"
.LASF182:
	.string	"silver_scalars__less_equal"
.LASF92:
	.string	"items"
.LASF283:
	.string	"silver_output_profile__body_tail___wrapped_statements"
.LASF288:
	.string	"silver_output_profile__basic_body___wrapped_statements"
.LASF292:
	.string	"silver_output_profile__scalar_assignment_body___wrapped_statements__R1935b__TresultS__T1936b__TT1937bP1___U"
.LASF356:
	.string	"silver_output_profile__invalid_body__R938b__TresultS__T939b__TT940bP1___U"
.LASF57:
	.string	"silver_output_profile__capacity_literal"
.LASF402:
	.string	"range_after"
.LASF65:
	.string	"silver_output_profile__output_expression"
.LASF168:
	.string	"silver_path_facts__less_equal"
.LASF87:
	.string	"mutable"
.LASF45:
	.string	"silver_output_profile__reject_name"
.LASF50:
	.string	"silver_output_profile__not_equal"
.LASF149:
	.string	"invalid_rejected"
.LASF453:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.637716/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.637716/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF176:
	.string	"when_true"
.LASF68:
	.string	"silver_output_profile__statements"
.LASF84:
	.string	"value_first"
.LASF342:
	.string	"silver_output_profile__reading_names___wrapped_statements"
.LASF339:
	.string	"mask_after"
.LASF75:
	.string	"silver_output_profile__range_delimiter"
.LASF141:
	.string	"assigned"
.LASF375:
	.string	"silver_output_profile__dynamic_at___wrapped_statements"
.LASF352:
	.string	"silver_output_profile__valid_body"
.LASF227:
	.string	"silver_output_profile__context_of"
.LASF100:
	.string	"static"
.LASF196:
	.string	"silver_integer_literals__literal_position"
.LASF164:
	.string	"silver_path_facts__comparison"
.LASF319:
	.string	"silver_output_profile__chain_after___wrapped_statements"
.LASF49:
	.string	"silver_output_profile__not_keyword"
.LASF317:
	.string	"silver_output_profile__read_primary_into___wrapped_statements"
.LASF253:
	.string	"silver_output_profile__read_statements___wrapped_statements"
.LASF185:
	.string	"silver_output_profile__string_target_result"
.LASF390:
	.string	"scalar_state"
.LASF115:
	.string	"matched"
.LASF132:
	.string	"named_seen"
.LASF417:
	.string	"silver_output_profile__value_at___wrapped_statements"
.LASF270:
	.string	"index_bounds"
.LASF299:
	.string	"active_count"
.LASF423:
	.string	"silver_output_profile__within_work_budget"
.LASF214:
	.string	"silver_output_profile__refine_or_keep"
.LASF177:
	.string	"when_false"
.LASF133:
	.string	"silver_output_profile__expression_state"
.LASF449:
	.string	"silver_output_profile__spelling"
.LASF39:
	.string	"silver_output_profile__first_or_default_name"
.LASF173:
	.string	"silver_output_profile__length_result"
.LASF426:
	.string	"silver_output_profile__literal_at"
.LASF428:
	.string	"length"
.LASF336:
	.string	"overlay"
.LASF22:
	.string	"silver_output_profile__is_keyword"
.LASF80:
	.string	"silver_output_lexical__literal_position"
.LASF454:
	.string	"_renaming_type"
.LASF117:
	.string	"silver_names__output_call"
.LASF389:
	.string	"silver_output_profile__declaration_at___wrapped_statements"
.LASF231:
	.string	"silver_output_profile__valid_mutable_bounds"
.LASF395:
	.string	"type_after"
.LASF340:
	.string	"silver_output_profile__read_scalar_in_flow___wrapped_statements"
.LASF42:
	.string	"silver_output_profile__then_keyword"
.LASF440:
	.string	"silver_output_profile__skip_at"
.LASF207:
	.string	"silver_output_profile__initial_scan"
.LASF55:
	.string	"silver_output_profile__length_name"
.LASF407:
	.string	"silver_output_profile__expression_at"
.LASF129:
	.string	"silver_output_profile__operand_count"
.LASF136:
	.string	"need_operand"
.LASF230:
	.string	"silver_output_profile__valid_declaration_values__B2794b__L2795b__T2796b___U"
.LASF242:
	.string	"silver_output_profile__accepts"
.LASF257:
	.string	"silver_output_profile__alternative_body___wrapped_statements__TconditionS__T2543b__TT2544bP1___U"
.LASF416:
	.string	"silver_output_profile__value_at"
.LASF83:
	.string	"after"
.LASF165:
	.string	"silver_path_facts__equal"
.LASF326:
	.string	"literal"
.LASF238:
	.string	"source"
.LASF301:
	.string	"chained"
.LASF441:
	.string	"silver_output_profile__valid_state"
.LASF383:
	.string	"start"
.LASF338:
	.string	"mask_first"
.LASF59:
	.string	"silver_output_profile__argument_declaration"
.LASF346:
	.string	"silver_output_profile__widen_into___wrapped_statements"
.LASF286:
	.string	"silver_output_profile__at_body_stop"
.LASF345:
	.string	"silver_output_profile__widen_into"
.LASF373:
	.string	"silver_output_profile__assignment_at___wrapped_statements"
.LASF76:
	.string	"silver_output_profile__range_keyword"
.LASF33:
	.string	"silver_output_profile__string_literal"
.LASF325:
	.string	"silver_output_profile__length_at"
.LASF3:
	.string	"silver_output_profile__max_expression_operands"
.LASF332:
	.string	"silver_output_profile__body_token___wrapped_statements"
.LASF265:
	.string	"silver_output_profile__conditional_body___wrapped_statements__TyesS__TT2464bP1___U"
.LASF155:
	.string	"silver_output_profile__body_stop"
.LASF307:
	.string	"left_scalar"
.LASF349:
	.string	"T1025b"
.LASF7:
	.string	"silver_output_profile__scalars___XRP_silver_scalars___XE"
.LASF305:
	.string	"silver_output_profile__read_relation_into___wrapped_statements"
.LASF281:
	.string	"silver_output_profile__read_body___wrapped_statements__TresultS__T2227b__TT2228bP1___U"
.LASF330:
	.string	"silver_output_profile__scalar_comparison_at___wrapped_statements"
.LASF189:
	.string	"system__parameters__Tsize_typeB"
.LASF160:
	.string	"silver_scalar_expressions__expression_result"
.LASF285:
	.string	"before"
.LASF370:
	.string	"silver_output_profile__output_at"
.LASF308:
	.string	"temporary_path"
.LASF85:
	.string	"static_length"
.LASF179:
	.string	"silver_scalars__equal"
.LASF266:
	.string	"silver_output_profile__loop_body"
.LASF54:
	.string	"silver_output_profile__apostrophe"
.LASF260:
	.string	"silver_output_profile__conditional_body"
.LASF89:
	.string	"silver_output_profile__binding_info"
.LASF175:
	.string	"silver_output_profile__condition_result"
.LASF418:
	.string	"quoted"
.LASF397:
	.string	"silver_output_profile__scalar_declaration_at___wrapped_statements"
.LASF97:
	.string	"upper"
.LASF421:
	.string	"attribute_first"
.LASF312:
	.string	"right_scalar"
.LASF400:
	.string	"silver_output_profile__scalar_constraint_at"
.LASF280:
	.string	"silver_output_profile__read_body___wrapped_statements"
.LASF82:
	.string	"first"
.LASF139:
	.string	"silver_output_profile__scan_result"
.LASF180:
	.string	"silver_scalars__unequal"
.LASF384:
	.string	"hidden"
.LASF190:
	.string	"system__storage_elements__storage_element"
.LASF66:
	.string	"silver_output_profile__comparison_expression"
.LASF334:
	.string	"silver_output_profile__read_string_in_flow"
.LASF355:
	.string	"silver_output_profile__invalid_body"
.LASF432:
	.string	"silver_output_profile__call_after___wrapped_statements"
.LASF140:
	.string	"state"
.LASF38:
	.string	"silver_output_profile__arguments_name"
.LASF279:
	.string	"silver_output_profile__read_body"
.LASF315:
	.string	"left"
.LASF81:
	.string	"silver_output_lexical__capacity_value"
.LASF181:
	.string	"silver_scalars__less"
.LASF48:
	.string	"silver_output_profile__or_keyword"
.LASF445:
	.string	"silver_output_profile__normalized___wrapped_statements"
.LASF126:
	.string	"empty_value"
.LASF235:
	.string	"item"
.LASF211:
	.string	"threshold"
.LASF387:
	.string	"following"
.LASF304:
	.string	"silver_output_profile__read_chain_into___wrapped_statements"
.LASF51:
	.string	"silver_output_profile__less"
.LASF348:
	.string	"R1070b"
.LASF419:
	.string	"silver_output_profile__image_at"
.LASF320:
	.string	"silver_output_profile__chain_token"
.LASF23:
	.string	"silver_output_profile__pragma_keyword"
.LASF35:
	.string	"silver_output_profile__constant_keyword"
.LASF318:
	.string	"silver_output_profile__chain_after"
.LASF458:
	.string	"silver_output_profile__is_argument_form"
.LASF36:
	.string	"silver_output_profile__string_name"
.LASF99:
	.string	"bounds"
.LASF321:
	.string	"silver_output_profile__bare_target"
.LASF424:
	.string	"remaining"
.LASF413:
	.string	"join_after"
.LASF183:
	.string	"silver_scalars__greater"
.LASF436:
	.string	"B267b"
.LASF437:
	.string	"B271b"
.LASF412:
	.string	"atom"
.LASF134:
	.string	"operands"
.LASF443:
	.string	"R226b"
.LASF267:
	.string	"silver_output_profile__loop_body___wrapped_statements"
.LASF64:
	.string	"silver_output_profile__assignment_value"
.LASF273:
	.string	"silver_output_profile__loop_body___wrapped_statements__B_20__Tinner_scanS__T2363b__TT2364bP1___U"
.LASF159:
	.string	"silver_scalar_expressions__operand_count"
.LASF254:
	.string	"silver_output_profile__alternative_body___wrapped_statements"
.LASF268:
	.string	"silver_output_profile__loop_body___wrapped_statements__TresultS__T2328b__TT2329bP1___U"
.LASF404:
	.string	"silver_output_profile__add_binding"
.LASF393:
	.string	"colon_after"
.LASF256:
	.string	"silver_output_profile__alternative_body___wrapped_statements__TconditionS__T2541b__TT2542bP1___U"
.LASF198:
	.string	"silver_integer_literals__literal_result"
.LASF287:
	.string	"silver_output_profile__basic_body"
.LASF9:
	.string	"silver_output_profile__image_lengths___XRP_silver_integer_image___XE"
.LASF73:
	.string	"silver_output_profile__reverse_keyword"
.LASF147:
	.string	"valid_reachable"
.LASF11:
	.string	"silver_output_profile__paths___XRP_silver_path_facts___XE"
.LASF365:
	.string	"silver_output_profile__step"
.LASF40:
	.string	"silver_output_profile__if_keyword"
.LASF79:
	.string	"silver_output_profile__binding_count"
.LASF341:
	.string	"silver_output_profile__reading_names"
.LASF63:
	.string	"silver_output_profile__dynamic_reference"
.LASF157:
	.string	"silver_output_profile__else_only"
.LASF258:
	.string	"condition"
.LASF106:
	.string	"position"
.LASF309:
	.string	"temporary_value"
.LASF344:
	.string	"T1088b"
.LASF274:
	.string	"inner_scan"
.LASF162:
	.string	"silver_length_intervals__summary"
	.section	.debug_line_str,"MS",@progbits,1
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_output_profile.adb"
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
	.hidden	DW.ref.__gnat_personality_v0
	.weak	DW.ref.__gnat_personality_v0
	.section	.data.rel.local.DW.ref.__gnat_personality_v0,"awG",@progbits,DW.ref.__gnat_personality_v0,comdat
	.align 8
	.type	DW.ref.__gnat_personality_v0, @object
	.size	DW.ref.__gnat_personality_v0, 8
DW.ref.__gnat_personality_v0:
	.quad	__gnat_personality_v0
	.globl	__gnat_personality_v0
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
