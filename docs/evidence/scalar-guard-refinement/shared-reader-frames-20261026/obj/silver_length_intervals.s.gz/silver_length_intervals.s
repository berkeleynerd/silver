	.file	"silver_length_intervals.adb"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_length_intervals.adb"
	.align 2
	.globl	silver_length_intervals__summaryIP
	.type	silver_length_intervals__summaryIP, @function
silver_length_intervals__summaryIP:
.LFB2:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movb	$0, -4(%rbp)
	movq	-16(%rbp), %rax
	movq	-8(%rbp), %rdx
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	silver_length_intervals__summaryIP, .-silver_length_intervals__summaryIP
	.align 2
	.globl	silver_length_intervals__is_empty
	.type	silver_length_intervals__is_empty, @function
silver_length_intervals__is_empty:
.LFB3:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_length_intervals.ads"
	.loc 1 15 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	.loc 1 15 64
	movzbl	-4(%rbp), %eax
	.loc 1 15 4
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.size	silver_length_intervals__is_empty, .-silver_length_intervals__is_empty
	.align 2
	.globl	silver_length_intervals__lower
	.type	silver_length_intervals__lower, @function
silver_length_intervals__lower:
.LFB4:
	.loc 1 16 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	.loc 1 17 6
	movl	-16(%rbp), %eax
	movl	%eax, %edx
	movabsq	$-4294967296, %rax
	andq	%rcx, %rax
	orq	%rdx, %rax
	movq	%rax, %rcx
	movl	-8(%rbp), %eax
	movl	%eax, %eax
	salq	$32, %rax
	movl	%ecx, %edx
	orq	%rdx, %rax
	movq	%rax, %rcx
	.loc 1 17 6 is_stmt 0 discriminator 1
	movq	%rcx, %rax
	.loc 1 16 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	silver_length_intervals__lower, .-silver_length_intervals__lower
	.align 2
	.globl	silver_length_intervals__upper
	.type	silver_length_intervals__upper, @function
silver_length_intervals__upper:
.LFB5:
	.loc 1 18 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rsi, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	.loc 1 19 6
	movl	-12(%rbp), %eax
	movl	%eax, %edx
	movabsq	$-4294967296, %rax
	andq	%rcx, %rax
	orq	%rdx, %rax
	movq	%rax, %rcx
	movl	-8(%rbp), %eax
	movl	%eax, %eax
	salq	$32, %rax
	movl	%ecx, %edx
	orq	%rdx, %rax
	movq	%rax, %rcx
	.loc 1 19 6 is_stmt 0 discriminator 1
	movq	%rcx, %rax
	.loc 1 18 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE5:
	.size	silver_length_intervals__upper, .-silver_length_intervals__upper
	.align 2
	.globl	silver_length_intervals__fits
	.type	silver_length_intervals__fits, @function
silver_length_intervals__fits:
.LFB6:
	.file 2 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_length_intervals.adb"
	.loc 2 2 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movl	%esi, %eax
	movq	%rdx, -32(%rbp)
	movq	%rcx, -24(%rbp)
	movq	%rdi, -16(%rbp)
	movl	%eax, -8(%rbp)
	.loc 2 3 27
	movl	-28(%rbp), %eax
	.loc 2 4 7
	cmpl	$4096, %eax
	jg	.L9
	.loc 2 4 17 discriminator 1
	movq	-32(%rbp), %rdx
	movq	-24(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_length_intervals__is_empty
	.loc 2 4 7 discriminator 2
	testb	%al, %al
	jne	.L10
	.loc 2 4 61 discriminator 3
	movq	-32(%rbp), %rdx
	movq	-24(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_length_intervals__upper
	movq	%rax, %rdx
	.loc 2 4 47 discriminator 4
	movq	-16(%rbp), %rcx
	movl	-8(%rbp), %eax
	movq	%rcx, %rdi
	movl	%eax, %esi
	call	silver_path_facts__fits@PLT
	.loc 2 4 34 discriminator 5
	testb	%al, %al
	je	.L9
.L10:
	.loc 2 4 7 discriminator 6
	movl	$1, %eax
	jmp	.L12
.L9:
	.loc 2 4 7 is_stmt 0 discriminator 7
	movl	$0, %eax
.L12:
	.loc 2 2 4 is_stmt 1
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE6:
	.size	silver_length_intervals__fits, .-silver_length_intervals__fits
	.align 2
	.globl	silver_length_intervals__same_length
	.type	silver_length_intervals__same_length, @function
silver_length_intervals__same_length:
.LFB7:
	.loc 2 6 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 3, -24
	movl	%esi, %eax
	movq	%rdx, -48(%rbp)
	movq	%rcx, -40(%rbp)
	movq	%r8, -64(%rbp)
	movq	%r9, -56(%rbp)
	movq	%rdi, -32(%rbp)
	movl	%eax, -24(%rbp)
	.loc 2 7 10
	movq	-48(%rbp), %rdx
	movq	-40(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_length_intervals__is_empty
	.loc 2 7 7 discriminator 1
	testb	%al, %al
	jne	.L14
	.loc 2 7 34 discriminator 2
	movq	-64(%rbp), %rdx
	movq	-56(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_length_intervals__is_empty
	.loc 2 7 26 discriminator 3
	testb	%al, %al
	je	.L15
.L14:
	.loc 2 8 29
	movl	-56(%rbp), %eax
	.loc 2 8 34
	testl	%eax, %eax
	jne	.L16
	.loc 2 8 62 discriminator 1
	movl	-48(%rbp), %edx
	movl	-60(%rbp), %eax
	.loc 2 8 34 discriminator 1
	cmpl	%eax, %edx
	jg	.L17
.L16:
	.loc 2 8 34 is_stmt 0 discriminator 2
	movl	$1, %eax
	.loc 2 8 34 discriminator 4
	jmp	.L22
.L17:
	.loc 2 8 34 discriminator 3
	movl	$0, %eax
	.loc 2 8 34 discriminator 4
	jmp	.L22
.L15:
	.loc 2 9 52 is_stmt 1
	movq	-64(%rbp), %rdx
	movq	-56(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_length_intervals__upper
	movq	%rax, %rbx
	.loc 2 9 38 discriminator 1
	movq	-48(%rbp), %rdx
	movq	-40(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_length_intervals__lower
	movq	%rax, %rdx
	.loc 2 9 17 discriminator 2
	movq	-32(%rbp), %rsi
	movl	-24(%rbp), %eax
	movq	%rbx, %rcx
	movq	%rsi, %rdi
	movl	%eax, %esi
	call	silver_path_facts__same_length@PLT
	.loc 2 10 9
	testb	%al, %al
	je	.L20
	.loc 2 10 58 discriminator 1
	movq	-64(%rbp), %rdx
	movq	-56(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_length_intervals__lower
	movq	%rax, %rbx
	.loc 2 10 44 discriminator 2
	movq	-48(%rbp), %rdx
	movq	-40(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_length_intervals__upper
	movq	%rax, %rdx
	.loc 2 10 23 discriminator 3
	movq	-32(%rbp), %rsi
	movl	-24(%rbp), %eax
	movq	%rbx, %rcx
	movq	%rsi, %rdi
	movl	%eax, %esi
	call	silver_path_facts__same_length@PLT
	.loc 2 10 9 discriminator 4
	testb	%al, %al
	je	.L20
	.loc 2 10 9 is_stmt 0 discriminator 5
	movl	$1, %eax
	.loc 2 10 9 discriminator 7
	jmp	.L22
.L20:
	.loc 2 10 9 discriminator 6
	movl	$0, %eax
.L22:
	.loc 2 6 4 is_stmt 1
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE7:
	.size	silver_length_intervals__same_length, .-silver_length_intervals__same_length
	.section	.rodata
	.align 8
.LC1:
	.ascii	"failed precondition from silver_length_intervals.adb:15"
.LC2:
	.ascii	"silver_length_intervals.adb"
	.zero	1
	.align 8
.LC0:
	.long	1
	.long	55
	.text
	.align 2
	.globl	silver_length_intervals__equal_increasing
	.type	silver_length_intervals__equal_increasing, @function
silver_length_intervals__equal_increasing:
.LFB8:
	.loc 2 16 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$112, %rsp
	movl	%esi, %eax
	movq	%rdx, -80(%rbp)
	movq	%rcx, -72(%rbp)
	movq	%r8, -96(%rbp)
	movq	%r9, -88(%rbp)
	movq	%rdi, -64(%rbp)
	movl	%eax, -56(%rbp)
	.loc 2 15 34
	movl	-72(%rbp), %edx
	movl	-88(%rbp), %eax
	.loc 2 15 15
	cmpl	%eax, %edx
	jg	.L24
.LBB2:
	.loc 2 15 15 is_stmt 0 discriminator 1
	leaq	.LC1(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L24:
.LBE2:
	.loc 2 18 30 is_stmt 1
	movl	-92(%rbp), %edx
	movl	-80(%rbp), %eax
	.loc 2 18 7
	cmpl	%eax, %edx
	jge	.L25
	.loc 2 18 62 discriminator 1
	movq	silver_path_facts__empty_context(%rip), %rax
	movq	%rax, -28(%rbp)
	movl	8+silver_path_facts__empty_context(%rip), %eax
	movl	%eax, -20(%rbp)
	jmp	.L37
.L25:
	.loc 2 20 66
	movl	-72(%rbp), %eax
	movl	-88(%rbp), %edx
	subl	%edx, %eax
	testl	%eax, %eax
	jg	.L27
	.loc 2 20 66 is_stmt 0 discriminator 1
	leaq	.LC2(%rip), %rax
	movl	$20, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L27:
	.loc 2 20 13 is_stmt 1 discriminator 2
	movl	%eax, -8(%rbp)
	.loc 2 22 40
	movl	-96(%rbp), %edx
	movl	-76(%rbp), %eax
	.loc 2 22 16
	cmpl	%eax, %edx
	jle	.L28
	.loc 2 23 42
	movl	-96(%rbp), %eax
	movl	-76(%rbp), %edx
	subl	%edx, %eax
	testl	%eax, %eax
	jns	.L29
	.loc 2 23 42 is_stmt 0 discriminator 1
	leaq	.LC2(%rip), %rax
	movl	$23, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L29:
	.loc 2 21 13 is_stmt 1
	movl	%eax, -4(%rbp)
	jmp	.L30
.L28:
	.loc 2 21 13 is_stmt 0 discriminator 1
	movl	$0, -4(%rbp)
.L30:
	.loc 2 24 65 is_stmt 1
	movl	$0, %ecx
	movl	-4(%rbp), %edx
	movl	-8(%rbp), %eax
	addl	%edx, %eax
	testl	%eax, %eax
	js	.L32
	cmpl	-8(%rbp), %eax
	jnb	.L31
.L32:
	movl	$1, %ecx
.L31:
	.loc 2 24 65 is_stmt 0 discriminator 1
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L33
	.loc 2 24 65 discriminator 2
	leaq	.LC2(%rip), %rax
	movl	$24, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L33:
	.loc 2 24 65 discriminator 4
	movl	-4(%rbp), %edx
	movl	-8(%rbp), %eax
	addl	%edx, %eax
	testl	%eax, %eax
	js	.L34
	cmpl	-8(%rbp), %eax
.L34:
	.loc 2 24 65 discriminator 5
	subl	$1, %eax
	.loc 2 24 13 is_stmt 1 discriminator 6
	cltd
	idivl	-8(%rbp)
	.loc 2 24 13 is_stmt 0 discriminator 7
	movl	%eax, -12(%rbp)
	.loc 2 25 61 is_stmt 1
	movl	-92(%rbp), %edx
	movl	-80(%rbp), %eax
	subl	%eax, %edx
	.loc 2 25 84
	movl	%edx, %eax
	cltd
	idivl	-8(%rbp)
	.loc 2 25 84 is_stmt 0 discriminator 1
	testl	%eax, %eax
	jns	.L36
	.loc 2 25 84 discriminator 2
	leaq	.LC2(%rip), %rax
	movl	$25, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L36:
	.loc 2 25 13 is_stmt 1 discriminator 3
	movl	%eax, -16(%rbp)
	.loc 2 26 21
	movl	-16(%rbp), %ecx
	movl	-12(%rbp), %edx
	movq	-64(%rbp), %rsi
	movl	-56(%rbp), %eax
	movq	%rsi, %rdi
	movl	%eax, %esi
	call	silver_path_facts__intersect@PLT
	movq	%rax, -40(%rbp)
	movl	-32(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -32(%rbp)
	.loc 2 26 21 is_stmt 0 discriminator 1
	leaq	-40(%rbp), %rax
	.loc 2 19 10 is_stmt 1
	movq	(%rax), %rdx
	movq	%rdx, -28(%rbp)
	movl	8(%rax), %eax
	movl	%eax, -20(%rbp)
.L37:
	.loc 2 16 4
	movq	-28(%rbp), %rax
	movl	-20(%rbp), %ecx
	movq	%rcx, %rdx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE8:
	.size	silver_length_intervals__equal_increasing, .-silver_length_intervals__equal_increasing
	.align 2
	.globl	silver_length_intervals__refine_equal
	.type	silver_length_intervals__refine_equal, @function
silver_length_intervals__refine_equal:
.LFB9:
	.loc 2 28 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$88, %rsp
	.cfi_offset 3, -24
	movl	%esi, %eax
	movq	%rdx, -64(%rbp)
	movq	%rcx, -56(%rbp)
	movq	%r8, -80(%rbp)
	movq	%r9, -72(%rbp)
	movq	%rdi, -48(%rbp)
	movl	%eax, -40(%rbp)
	.loc 2 30 10
	movq	-64(%rbp), %rdx
	movq	-56(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_length_intervals__is_empty
	.loc 2 30 7 discriminator 1
	testb	%al, %al
	jne	.L39
	.loc 2 30 34 discriminator 2
	movq	-80(%rbp), %rdx
	movq	-72(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_length_intervals__is_empty
	.loc 2 30 26 discriminator 3
	testb	%al, %al
	je	.L40
.L39:
	.loc 2 30 61 discriminator 4
	movq	silver_path_facts__empty_context(%rip), %rax
	movq	%rax, -28(%rbp)
	movl	8+silver_path_facts__empty_context(%rip), %eax
	movl	%eax, -20(%rbp)
	jmp	.L41
.L40:
	.loc 2 31 32
	movl	-56(%rbp), %edx
	movl	-72(%rbp), %eax
	.loc 2 31 7
	cmpl	%eax, %edx
	jne	.L42
	.loc 2 32 51
	movl	-64(%rbp), %edx
	movl	-76(%rbp), %eax
	.loc 2 32 14
	cmpl	%eax, %edx
	jg	.L43
	.loc 2 33 41
	movl	-80(%rbp), %edx
	movl	-60(%rbp), %eax
	.loc 2 32 14 discriminator 1
	cmpl	%eax, %edx
	jg	.L43
	.loc 2 32 14 is_stmt 0 discriminator 2
	movl	$1, %eax
	jmp	.L44
.L43:
	.loc 2 32 14 discriminator 3
	movl	$0, %eax
.L44:
	.loc 2 32 14 discriminator 4
	movzbl	%al, %edx
	movq	-48(%rbp), %rcx
	movl	-40(%rbp), %eax
	movq	%rcx, %rdi
	movl	%eax, %esi
	call	silver_path_facts__keep_if@PLT
	movq	%rax, -28(%rbp)
	movl	-20(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -20(%rbp)
	.loc 2 32 14 discriminator 5
	jmp	.L41
.L42:
	.loc 2 34 32 is_stmt 1
	movl	-56(%rbp), %edx
	movl	-72(%rbp), %eax
	.loc 2 34 7
	cmpl	%eax, %edx
	jle	.L45
	.loc 2 34 59 discriminator 1
	movq	-80(%rbp), %rcx
	movq	-72(%rbp), %rbx
	movq	-64(%rbp), %rax
	movq	-56(%rbp), %rdx
	movq	-48(%rbp), %rdi
	movl	-40(%rbp), %esi
	movq	%rcx, %r8
	movq	%rbx, %r9
	movq	%rdx, %rcx
	movq	%rax, %rdx
	call	silver_length_intervals__equal_increasing
	movq	%rax, -28(%rbp)
	movl	-20(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -20(%rbp)
	.loc 2 34 59 is_stmt 0 discriminator 2
	jmp	.L41
.L45:
	.loc 2 35 12 is_stmt 1
	movq	-64(%rbp), %rcx
	movq	-56(%rbp), %rbx
	movq	-80(%rbp), %rax
	movq	-72(%rbp), %rdx
	movq	-48(%rbp), %rdi
	movl	-40(%rbp), %esi
	movq	%rcx, %r8
	movq	%rbx, %r9
	movq	%rdx, %rcx
	movq	%rax, %rdx
	call	silver_length_intervals__equal_increasing
	movq	%rax, -28(%rbp)
	movl	-20(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -20(%rbp)
.L41:
	.loc 2 28 4
	movq	-28(%rbp), %rax
	movl	-20(%rbp), %ecx
	movq	%rcx, %rdx
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE9:
	.size	silver_length_intervals__refine_equal, .-silver_length_intervals__refine_equal
	.globl	silver_length_intervals_E
	.data
	.align 2
	.type	silver_length_intervals_E, @object
	.size	silver_length_intervals_E, 2
silver_length_intervals_E:
	.zero	2
	.globl	silver_length_intervals__empty_summary
	.section	.rodata
	.align 16
	.type	silver_length_intervals__empty_summary, @object
	.size	silver_length_intervals__empty_summary, 16
silver_length_intervals__empty_summary:
	.long	0
	.long	0
	.long	0
	.byte	1
	.zero	3
	.text
.Letext0:
	.file 3 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_path_facts.ads"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x354
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0xa
	.long	.LASF33
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.quad	.Ltext0
	.quad	.Letext0-.Ltext0
	.long	.Ldebug_line0
	.uleb128 0x3
	.long	.LASF23
	.byte	0x1
	.byte	0x4
	.byte	0x4
	.long	0x3d
	.uleb128 0x2
	.byte	0x9
	.byte	0xff
	.uleb128 0xb
	.byte	0x1
	.sleb128 0
	.long	.LASF34
	.long	0x48
	.uleb128 0x7
	.byte	0x4
	.byte	0x5
	.long	.LASF8
	.uleb128 0x5
	.sleb128 4096
	.long	.LASF2
	.long	0x48
	.uleb128 0x5
	.sleb128 64
	.long	.LASF3
	.long	0x48
	.uleb128 0x6
	.long	.LASF10
	.byte	0x10
	.byte	0x1
	.byte	0x8
	.long	0xa6
	.uleb128 0x2
	.long	.LASF4
	.byte	0x1
	.byte	0x9
	.byte	0x7
	.long	0x4f
	.byte	0
	.uleb128 0x2
	.long	.LASF5
	.byte	0x1
	.byte	0x9
	.byte	0x17
	.long	0x4f
	.byte	0x4
	.uleb128 0x2
	.long	.LASF6
	.byte	0x1
	.byte	0xa
	.byte	0x7
	.long	0x5a
	.byte	0x8
	.uleb128 0x2
	.long	.LASF7
	.byte	0x1
	.byte	0xb
	.byte	0x7
	.long	0xab
	.byte	0xc
	.byte	0
	.uleb128 0x8
	.long	0x65
	.uleb128 0x7
	.byte	0x1
	.byte	0x2
	.long	.LASF9
	.uleb128 0x6
	.long	.LASF11
	.byte	0x8
	.byte	0x3
	.byte	0x6d
	.long	0xd9
	.uleb128 0x2
	.long	.LASF5
	.byte	0x3
	.byte	0x6e
	.byte	0x7
	.long	0x4f
	.byte	0
	.uleb128 0x2
	.long	.LASF6
	.byte	0x3
	.byte	0x6f
	.byte	0x7
	.long	0x5a
	.byte	0x4
	.byte	0
	.uleb128 0x6
	.long	.LASF12
	.byte	0xc
	.byte	0x3
	.byte	0x20
	.long	0x127
	.uleb128 0x2
	.long	.LASF13
	.byte	0x3
	.byte	0x21
	.byte	0x7
	.long	0x4f
	.byte	0
	.uleb128 0x2
	.long	.LASF14
	.byte	0x3
	.byte	0x21
	.byte	0xe
	.long	0x4f
	.byte	0x4
	.uleb128 0x2
	.long	.LASF15
	.byte	0x3
	.byte	0x22
	.byte	0x7
	.long	0xab
	.byte	0x8
	.uleb128 0x2
	.long	.LASF16
	.byte	0x3
	.byte	0x22
	.byte	0x18
	.long	0xab
	.byte	0x9
	.uleb128 0x2
	.long	.LASF17
	.byte	0x3
	.byte	0x22
	.byte	0x2b
	.long	0xab
	.byte	0xa
	.byte	0
	.uleb128 0x8
	.long	0xd9
	.uleb128 0xc
	.long	.LASF35
	.byte	0x1
	.byte	0xd
	.byte	0x4
	.long	0xa6
	.uleb128 0x9
	.byte	0x3
	.quad	silver_length_intervals__empty_summary
	.uleb128 0x4
	.long	.LASF21
	.byte	0x1c
	.long	0xd9
	.quad	.LFB9
	.quad	.LFE9-.LFB9
	.uleb128 0x1
	.byte	0x9c
	.long	0x192
	.uleb128 0x1
	.long	.LASF18
	.byte	0x1
	.byte	0x1d
	.byte	0x1b
	.long	0x127
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x1
	.long	.LASF19
	.byte	0x1
	.byte	0x1d
	.byte	0x32
	.long	0xa6
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x1
	.long	.LASF20
	.byte	0x1
	.byte	0x1d
	.byte	0x38
	.long	0xa6
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.byte	0
	.uleb128 0x4
	.long	.LASF22
	.byte	0x10
	.long	0xd9
	.quad	.LFB8
	.quad	.LFE8-.LFB8
	.uleb128 0x1
	.byte	0x9c
	.long	0x21f
	.uleb128 0x1
	.long	.LASF18
	.byte	0x2
	.byte	0xc
	.byte	0x1f
	.long	0x127
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x1
	.long	.LASF19
	.byte	0x2
	.byte	0xc
	.byte	0x36
	.long	0xa6
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF20
	.byte	0x2
	.byte	0xc
	.byte	0x3c
	.long	0xa6
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x3
	.long	.LASF24
	.byte	0x2
	.byte	0x14
	.byte	0xd
	.long	0x21f
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0x3
	.long	.LASF25
	.byte	0x2
	.byte	0x15
	.byte	0xd
	.long	0x22d
	.uleb128 0x2
	.byte	0x91
	.sleb128 -20
	.uleb128 0xd
	.string	"low"
	.byte	0x2
	.byte	0x18
	.byte	0xd
	.long	0x22d
	.uleb128 0x2
	.byte	0x91
	.sleb128 -28
	.uleb128 0x3
	.long	.LASF26
	.byte	0x2
	.byte	0x19
	.byte	0xd
	.long	0x22d
	.uleb128 0x2
	.byte	0x91
	.sleb128 -32
	.byte	0
	.uleb128 0xe
	.sleb128 2147483647
	.long	.LASF36
	.long	0x48
	.uleb128 0x5
	.sleb128 2147483647
	.long	.LASF27
	.long	0x48
	.uleb128 0x4
	.long	.LASF28
	.byte	0x6
	.long	0xab
	.quad	.LFB7
	.quad	.LFE7-.LFB7
	.uleb128 0x1
	.byte	0x9c
	.long	0x28a
	.uleb128 0x1
	.long	.LASF18
	.byte	0x1
	.byte	0x1a
	.byte	0x1a
	.long	0x127
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0x1
	.long	.LASF19
	.byte	0x1
	.byte	0x1a
	.byte	0x31
	.long	0xa6
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x1
	.long	.LASF20
	.byte	0x1
	.byte	0x1a
	.byte	0x37
	.long	0xa6
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.byte	0
	.uleb128 0x4
	.long	.LASF29
	.byte	0x2
	.long	0xab
	.quad	.LFB6
	.quad	.LFE6-.LFB6
	.uleb128 0x1
	.byte	0x9c
	.long	0x2c9
	.uleb128 0x1
	.long	.LASF18
	.byte	0x1
	.byte	0x15
	.byte	0x13
	.long	0x127
	.uleb128 0x2
	.byte	0x91
	.sleb128 -32
	.uleb128 0x1
	.long	.LASF30
	.byte	0x1
	.byte	0x15
	.byte	0x2a
	.long	0xa6
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.byte	0
	.uleb128 0x9
	.long	.LASF31
	.byte	0x12
	.long	0xb2
	.quad	.LFB5
	.quad	.LFE5-.LFB5
	.uleb128 0x1
	.byte	0x9c
	.long	0x2f9
	.uleb128 0x1
	.long	.LASF30
	.byte	0x1
	.byte	0x12
	.byte	0x14
	.long	0xa6
	.uleb128 0x2
	.byte	0x91
	.sleb128 -32
	.byte	0
	.uleb128 0x9
	.long	.LASF32
	.byte	0x10
	.long	0xb2
	.quad	.LFB4
	.quad	.LFE4-.LFB4
	.uleb128 0x1
	.byte	0x9c
	.long	0x329
	.uleb128 0x1
	.long	.LASF30
	.byte	0x1
	.byte	0x10
	.byte	0x14
	.long	0xa6
	.uleb128 0x2
	.byte	0x91
	.sleb128 -32
	.byte	0
	.uleb128 0xf
	.long	.LASF37
	.byte	0x1
	.byte	0xf
	.byte	0x4
	.long	0xab
	.quad	.LFB3
	.quad	.LFE3-.LFB3
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x1
	.long	.LASF30
	.byte	0x1
	.byte	0xf
	.byte	0x17
	.long	0xa6
	.uleb128 0x2
	.byte	0x91
	.sleb128 -32
	.byte	0
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x2c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.Letext0-.Ltext0
	.quad	0
	.quad	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF13:
	.string	"lower"
.LASF37:
	.string	"silver_length_intervals__is_empty"
.LASF36:
	.string	"positive"
.LASF28:
	.string	"silver_length_intervals__same_length"
.LASF33:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF19:
	.string	"left"
.LASF17:
	.string	"invalid_rejected"
.LASF20:
	.string	"right"
.LASF26:
	.string	"high"
.LASF16:
	.string	"invalid_reachable"
.LASF35:
	.string	"silver_length_intervals__empty_summary"
.LASF4:
	.string	"minimum_length"
.LASF24:
	.string	"difference"
.LASF23:
	.string	"silver_length_intervals__paths___XRP_silver_path_facts___XE"
.LASF22:
	.string	"silver_length_intervals__equal_increasing"
.LASF31:
	.string	"silver_length_intervals__upper"
.LASF3:
	.string	"silver_path_facts__operand_count"
.LASF10:
	.string	"silver_length_intervals__summary"
.LASF11:
	.string	"silver_path_facts__summary"
.LASF15:
	.string	"valid_reachable"
.LASF9:
	.string	"boolean"
.LASF6:
	.string	"dynamic_count"
.LASF18:
	.string	"facts"
.LASF5:
	.string	"static_length"
.LASF14:
	.string	"upper"
.LASF32:
	.string	"silver_length_intervals__lower"
.LASF12:
	.string	"silver_path_facts__context"
.LASF25:
	.string	"numerator"
.LASF8:
	.string	"integer"
.LASF21:
	.string	"silver_length_intervals__refine_equal"
.LASF30:
	.string	"value"
.LASF2:
	.string	"silver_path_facts__length_value"
.LASF27:
	.string	"natural"
.LASF34:
	.string	"_renaming_type"
.LASF29:
	.string	"silver_length_intervals__fits"
.LASF7:
	.string	"empty_value"
	.section	.debug_line_str,"MS",@progbits,1
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_length_intervals.adb"
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
