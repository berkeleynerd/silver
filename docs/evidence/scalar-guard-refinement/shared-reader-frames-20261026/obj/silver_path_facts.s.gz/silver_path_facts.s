	.file	"silver_path_facts.ads"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_path_facts.ads"
	.align 2
	.globl	silver_path_facts__comparisonH
	.type	silver_path_facts__comparisonH, @function
silver_path_facts__comparisonH:
.LFB1:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	movq	-8(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L2
	movl	%edx, %ecx
	subl	%eax, %ecx
	leal	1(%rcx), %r11d
	jmp	.L3
.L2:
	movl	$0, %r11d
.L3:
	movslq	%eax, %r9
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	leal	-1(%rax), %r10d
	movl	$0, %esi
	movl	$0, %ecx
	movl	$0, %edx
.L11:
	cmpl	$1, %edx
	jg	.L10
	movslq	%edx, %rax
	leaq	0(,%rax,4), %rdi
	leaq	comparisonP.3(%rip), %rax
	movl	(%rdi,%rax), %eax
	cmpl	%eax, %r11d
	jl	.L10
	movq	-16(%rbp), %rax
	movslq	%edx, %rdi
	leaq	0(,%rdi,4), %r8
	leaq	comparisonP.3(%rip), %rdi
	movl	(%r8,%rdi), %edi
	addl	%r10d, %edi
	movslq	%edi, %rdi
	subq	%r9, %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %r8d
	movslq	%edx, %rax
	leaq	comparisonT1.2(%rip), %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %eax
	imull	%r8d, %eax
	leal	(%rsi,%rax), %edi
	movslq	%edi, %rax
	imulq	$1321528399, %rax, %rax
	shrq	$32, %rax
	movl	%eax, %esi
	sarl	$2, %esi
	movl	%edi, %eax
	sarl	$31, %eax
	subl	%eax, %esi
	movl	%esi, %eax
	addl	%eax, %eax
	addl	%esi, %eax
	sall	$2, %eax
	addl	%esi, %eax
	movl	%edi, %esi
	subl	%eax, %esi
	movslq	%edx, %rax
	leaq	comparisonT2.1(%rip), %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %eax
	imull	%r8d, %eax
	leal	(%rcx,%rax), %edi
	movslq	%edi, %rax
	imulq	$1321528399, %rax, %rax
	shrq	$32, %rax
	movl	%eax, %ecx
	sarl	$2, %ecx
	movl	%edi, %eax
	sarl	$31, %eax
	subl	%eax, %ecx
	movl	%ecx, %eax
	addl	%eax, %eax
	addl	%ecx, %eax
	sall	$2, %eax
	addl	%ecx, %eax
	movl	%edi, %ecx
	subl	%eax, %ecx
	addl	$1, %edx
	jmp	.L11
.L10:
	movslq	%esi, %rax
	leaq	comparisonG.0(%rip), %rdx
	movzbl	(%rax,%rdx), %eax
	movzbl	%al, %edx
	movslq	%ecx, %rax
	leaq	comparisonG.0(%rip), %rcx
	movzbl	(%rax,%rcx), %eax
	movzbl	%al, %eax
	leal	(%rdx,%rax), %ecx
	movslq	%ecx, %rax
	imulq	$715827883, %rax, %rax
	shrq	$32, %rax
	movq	%rax, %rdx
	movl	%ecx, %eax
	sarl	$31, %eax
	subl	%eax, %edx
	movl	%edx, %eax
	addl	%eax, %eax
	addl	%edx, %eax
	addl	%eax, %eax
	movl	%ecx, %edx
	subl	%eax, %edx
	movl	%edx, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1:
	.size	silver_path_facts__comparisonH, .-silver_path_facts__comparisonH
	.align 2
	.globl	silver_path_facts__contextIP
	.type	silver_path_facts__contextIP, @function
silver_path_facts__contextIP:
.LFB2:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	.cfi_offset 3, -24
	movq	%rcx, %rax
	movq	%rbx, %rdx
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	silver_path_facts__contextIP, .-silver_path_facts__contextIP
	.align 2
	.globl	silver_path_facts__summaryIP
	.type	silver_path_facts__summaryIP, @function
silver_path_facts__summaryIP:
.LFB3:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.size	silver_path_facts__summaryIP, .-silver_path_facts__summaryIP
	.section	.rodata
	.align 8
.LC1:
	.ascii	"failed precondition from silver_path_facts.ads:129"
.LC2:
	.ascii	"silver_path_facts.ads"
	.zero	1
	.align 8
.LC0:
	.long	1
	.long	50
	.text
	.align 2
	.globl	silver_path_facts__equal_increasing
	.type	silver_path_facts__equal_increasing, @function
silver_path_facts__equal_increasing:
.LFB4:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_path_facts.ads"
	.loc 1 130 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset 3, -24
	movl	%esi, %eax
	movq	%rdx, -88(%rbp)
	movq	%rcx, -96(%rbp)
	movq	%rdi, -80(%rbp)
	movl	%eax, -72(%rbp)
	.loc 1 129 37
	movl	-84(%rbp), %edx
	movl	-92(%rbp), %eax
	.loc 1 129 18
	cmpl	%eax, %edx
	jg	.L16
.LBB4:
	.loc 1 129 18 is_stmt 0 discriminator 1
	leaq	.LC1(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L16:
.LBE4:
	.loc 1 133 36 is_stmt 1
	movl	-96(%rbp), %edx
	movl	-88(%rbp), %eax
	.loc 1 133 13
	cmpl	%eax, %edx
	jl	.L17
	.loc 1 134 38
	movl	-96(%rbp), %eax
	movl	-88(%rbp), %edx
	subl	%edx, %eax
	testl	%eax, %eax
	js	.L18
	.loc 1 134 38 is_stmt 0 discriminator 1
	cmpl	$4096, %eax
	jle	.L19
.L18:
	.loc 1 134 38 discriminator 2
	leaq	.LC2(%rip), %rax
	movl	$134, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L19:
	.loc 1 132 10 is_stmt 1
	movl	%eax, -20(%rbp)
	jmp	.L20
.L17:
	.loc 1 132 10 is_stmt 0 discriminator 1
	movl	$0, -20(%rbp)
.L20:
	.loc 1 136 22 is_stmt 1
	movl	-84(%rbp), %edx
	movl	-92(%rbp), %eax
	cmpl	%eax, %edx
	jne	.L21
	.loc 1 136 22 is_stmt 0 discriminator 1
	leaq	.LC2(%rip), %rax
	movl	$136, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Divide_By_Zero@PLT
.L21:
	.loc 1 136 44 is_stmt 1 discriminator 2
	movl	-84(%rbp), %edx
	movl	-92(%rbp), %eax
	movl	%edx, %ebx
	subl	%eax, %ebx
	.loc 1 136 22 discriminator 2
	movl	-20(%rbp), %eax
	cltd
	idivl	%ebx
	.loc 1 136 22 is_stmt 0 discriminator 3
	testl	%eax, %eax
	js	.L22
	.loc 1 136 22 discriminator 4
	cmpl	$4096, %eax
	jle	.L23
.L22:
	.loc 1 136 22 discriminator 5
	leaq	.LC2(%rip), %rax
	movl	$136, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L23:
	.loc 1 135 10 is_stmt 1
	movl	%eax, -24(%rbp)
.LBB5:
	.loc 1 138 21
	movl	-24(%rbp), %edx
	movq	-88(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_path_facts__length_at
	movl	%eax, %ebx
	.loc 1 138 51 discriminator 1
	movl	-24(%rbp), %edx
	movq	-96(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_path_facts__length_at
	.loc 1 137 13
	cmpl	%eax, %ebx
	sete	%bl
	.loc 1 137 22
	movl	-24(%rbp), %ecx
	movl	-24(%rbp), %edx
	movq	-80(%rbp), %rsi
	movl	-72(%rbp), %eax
	movq	%rsi, %rdi
	movl	%eax, %esi
	call	silver_path_facts__intersect
	movq	%rax, -60(%rbp)
	movl	-52(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -52(%rbp)
	.loc 1 137 13 discriminator 1
	movzbl	%bl, %edx
	movq	-60(%rbp), %rcx
	movl	-52(%rbp), %eax
	movq	%rcx, %rdi
	movl	%eax, %esi
	call	silver_path_facts__keep_if
	movq	%rax, -48(%rbp)
	movl	-40(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -40(%rbp)
.LBE5:
	.loc 1 137 13 is_stmt 0 discriminator 2
	leaq	-48(%rbp), %rax
	.loc 1 131 7 is_stmt 1
	movq	(%rax), %rdx
	movq	%rdx, -36(%rbp)
	movl	8(%rax), %eax
	movl	%eax, -28(%rbp)
	.loc 1 131 7 is_stmt 0 discriminator 2
	movq	-36(%rbp), %rax
	movl	-28(%rbp), %ecx
	movq	%rcx, %rdx
	.loc 1 130 4 is_stmt 1
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	silver_path_facts__equal_increasing, .-silver_path_facts__equal_increasing
	.align 2
	.globl	silver_path_facts__boundIP
	.type	silver_path_facts__boundIP, @function
silver_path_facts__boundIP:
.LFB5:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE5:
	.size	silver_path_facts__boundIP, .-silver_path_facts__boundIP
	.align 2
	.globl	silver_path_facts__compare
	.type	silver_path_facts__compare, @function
silver_path_facts__compare:
.LFB6:
	.loc 1 10 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movb	%dil, -1(%rbp)
	movl	%esi, -8(%rbp)
	movl	%edx, -12(%rbp)
	.loc 1 12 12
	cmpb	$5, -1(%rbp)
	jbe	.L27
	.loc 1 12 12 is_stmt 0 discriminator 1
	leaq	.LC2(%rip), %rax
	movl	$12, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L27:
	.loc 1 12 12 discriminator 2
	cmpb	$5, -1(%rbp)
	jbe	.L28
	.loc 1 12 12 discriminator 3
	leaq	.LC2(%rip), %rax
	movl	$12, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L28:
	.loc 1 12 7 is_stmt 1 discriminator 4
	cmpb	$4, -1(%rbp)
	je	.L29
	cmpb	$4, -1(%rbp)
	ja	.L30
	cmpb	$3, -1(%rbp)
	je	.L31
	cmpb	$3, -1(%rbp)
	ja	.L30
	cmpb	$2, -1(%rbp)
	je	.L32
	cmpb	$2, -1(%rbp)
	ja	.L30
	cmpb	$0, -1(%rbp)
	je	.L33
	cmpb	$1, -1(%rbp)
	je	.L34
	jmp	.L30
.L33:
	.loc 1 13 28
	movl	-8(%rbp), %eax
	cmpl	-12(%rbp), %eax
	sete	%al
	jmp	.L35
.L34:
	.loc 1 14 30
	movl	-8(%rbp), %eax
	cmpl	-12(%rbp), %eax
	setne	%al
	jmp	.L35
.L32:
	.loc 1 15 27
	movl	-8(%rbp), %eax
	cmpl	-12(%rbp), %eax
	setl	%al
	jmp	.L35
.L31:
	.loc 1 16 33
	movl	-8(%rbp), %eax
	cmpl	-12(%rbp), %eax
	setle	%al
	jmp	.L35
.L29:
	.loc 1 17 30
	movl	-8(%rbp), %eax
	cmpl	-12(%rbp), %eax
	setg	%al
	jmp	.L35
.L30:
	.loc 1 18 36
	movl	-8(%rbp), %eax
	cmpl	-12(%rbp), %eax
	setge	%al
.L35:
	.loc 1 10 4
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE6:
	.size	silver_path_facts__compare, .-silver_path_facts__compare
	.align 2
	.globl	silver_path_facts__complement
	.type	silver_path_facts__complement, @function
silver_path_facts__complement:
.LFB7:
	.loc 1 19 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movb	%dil, -1(%rbp)
	.loc 1 20 12
	cmpb	$5, -1(%rbp)
	jbe	.L37
	.loc 1 20 12 is_stmt 0 discriminator 1
	leaq	.LC2(%rip), %rax
	movl	$20, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L37:
	.loc 1 20 12 discriminator 2
	cmpb	$5, -1(%rbp)
	jbe	.L38
	.loc 1 20 12 discriminator 3
	leaq	.LC2(%rip), %rax
	movl	$20, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L38:
	.loc 1 20 7 is_stmt 1 discriminator 4
	cmpb	$4, -1(%rbp)
	je	.L39
	cmpb	$4, -1(%rbp)
	ja	.L40
	cmpb	$3, -1(%rbp)
	je	.L41
	cmpb	$3, -1(%rbp)
	ja	.L40
	cmpb	$2, -1(%rbp)
	je	.L42
	cmpb	$2, -1(%rbp)
	ja	.L40
	cmpb	$0, -1(%rbp)
	je	.L43
	cmpb	$1, -1(%rbp)
	je	.L44
	jmp	.L40
.L43:
	.loc 1 21 23
	movl	$1, %eax
	jmp	.L45
.L44:
	.loc 1 21 48 discriminator 1
	movl	$0, %eax
	jmp	.L45
.L42:
	.loc 1 22 22
	movl	$5, %eax
	jmp	.L45
.L41:
	.loc 1 22 56 discriminator 1
	movl	$4, %eax
	jmp	.L45
.L39:
	.loc 1 23 25
	movl	$3, %eax
	jmp	.L45
.L40:
	.loc 1 23 59 discriminator 1
	movl	$2, %eax
.L45:
	.loc 1 19 4
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE7:
	.size	silver_path_facts__complement, .-silver_path_facts__complement
	.align 2
	.globl	silver_path_facts__swap
	.type	silver_path_facts__swap, @function
silver_path_facts__swap:
.LFB8:
	.loc 1 24 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movb	%dil, -1(%rbp)
	.loc 1 25 12
	cmpb	$5, -1(%rbp)
	jbe	.L47
	.loc 1 25 12 is_stmt 0 discriminator 1
	leaq	.LC2(%rip), %rax
	movl	$25, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L47:
	.loc 1 25 12 discriminator 2
	cmpb	$5, -1(%rbp)
	jbe	.L48
	.loc 1 25 12 discriminator 3
	leaq	.LC2(%rip), %rax
	movl	$25, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L48:
	.loc 1 25 7 is_stmt 1 discriminator 4
	cmpb	$4, -1(%rbp)
	je	.L49
	cmpb	$4, -1(%rbp)
	ja	.L50
	cmpb	$3, -1(%rbp)
	je	.L51
	cmpb	$3, -1(%rbp)
	ja	.L50
	cmpb	$2, -1(%rbp)
	je	.L52
	cmpb	$2, -1(%rbp)
	ja	.L50
	cmpb	$0, -1(%rbp)
	je	.L53
	cmpb	$1, -1(%rbp)
	je	.L54
	jmp	.L50
.L53:
	.loc 1 26 23
	movl	$0, %eax
	jmp	.L55
.L54:
	.loc 1 26 46 discriminator 1
	movl	$1, %eax
	jmp	.L55
.L52:
	.loc 1 27 22
	movl	$4, %eax
	jmp	.L55
.L51:
	.loc 1 27 50 discriminator 1
	movl	$5, %eax
	jmp	.L55
.L49:
	.loc 1 28 25
	movl	$2, %eax
	jmp	.L55
.L50:
	.loc 1 28 53 discriminator 1
	movl	$3, %eax
.L55:
	.loc 1 24 4
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE8:
	.size	silver_path_facts__swap, .-silver_path_facts__swap
	.align 2
	.globl	silver_path_facts__initial
	.type	silver_path_facts__initial, @function
silver_path_facts__initial:
.LFB9:
	.loc 1 37 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movb	%dil, -17(%rbp)
	.loc 1 38 6
	movl	$0, -12(%rbp)
	.loc 1 38 11
	cmpb	$0, -17(%rbp)
	je	.L57
	.loc 1 38 11 is_stmt 0 discriminator 1
	movl	$4096, %eax
	jmp	.L58
.L57:
	.loc 1 38 11 discriminator 2
	movl	$0, %eax
.L58:
	.loc 1 38 6 is_stmt 1 discriminator 3
	movl	%eax, -8(%rbp)
	movb	$1, -4(%rbp)
	movzbl	-17(%rbp), %eax
	movb	%al, -3(%rbp)
	movb	$0, -2(%rbp)
	.loc 1 38 6 is_stmt 0 discriminator 4
	movq	-12(%rbp), %rax
	movl	-4(%rbp), %ecx
	movq	%rcx, %rdx
	.loc 1 37 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE9:
	.size	silver_path_facts__initial, .-silver_path_facts__initial
	.align 2
	.globl	silver_path_facts__ceiling
	.type	silver_path_facts__ceiling, @function
silver_path_facts__ceiling:
.LFB10:
	.loc 1 39 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rdx
	movl	%esi, %eax
	movq	%rdx, -16(%rbp)
	movl	%eax, -8(%rbp)
	.loc 1 40 7
	movzbl	-8(%rbp), %eax
	testb	%al, %al
	je	.L61
	.loc 1 40 42 discriminator 1
	movl	-12(%rbp), %eax
	jmp	.L62
.L61:
	.loc 1 40 54 discriminator 2
	movl	$0, %eax
.L62:
	.loc 1 39 4
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE10:
	.size	silver_path_facts__ceiling, .-silver_path_facts__ceiling
	.align 2
	.globl	silver_path_facts__assume_valid
	.type	silver_path_facts__assume_valid, @function
silver_path_facts__assume_valid:
.LFB11:
	.loc 1 41 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rdx
	movl	%esi, %eax
	movq	%rdx, -48(%rbp)
	movl	%eax, -40(%rbp)
	.loc 1 42 6
	movq	-48(%rbp), %rax
	movq	%rax, -32(%rbp)
	movl	-40(%rbp), %eax
	movl	%eax, -24(%rbp)
	.loc 1 42 24
	movb	$0, -23(%rbp)
	.loc 1 42 6
	movq	-32(%rbp), %rax
	movq	%rax, -12(%rbp)
	movl	-24(%rbp), %eax
	movl	%eax, -4(%rbp)
	.loc 1 42 6 is_stmt 0 discriminator 1
	movq	-12(%rbp), %rax
	movl	-4(%rbp), %ecx
	movq	%rcx, %rdx
	.loc 1 41 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE11:
	.size	silver_path_facts__assume_valid, .-silver_path_facts__assume_valid
	.align 2
	.globl	silver_path_facts__assume_invalid
	.type	silver_path_facts__assume_invalid, @function
silver_path_facts__assume_invalid:
.LFB12:
	.loc 1 43 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rdx
	movl	%esi, %eax
	movq	%rdx, -48(%rbp)
	movl	%eax, -40(%rbp)
	.loc 1 44 6
	movq	-48(%rbp), %rax
	movq	%rax, -32(%rbp)
	movl	-40(%rbp), %eax
	movl	%eax, -24(%rbp)
	.loc 1 44 24
	movl	$0, -32(%rbp)
	.loc 1 44 36
	movl	$0, -28(%rbp)
	.loc 1 44 48
	movb	$0, -24(%rbp)
	.loc 1 44 6
	movq	-32(%rbp), %rax
	movq	%rax, -12(%rbp)
	movl	-24(%rbp), %eax
	movl	%eax, -4(%rbp)
	.loc 1 44 6 is_stmt 0 discriminator 1
	movq	-12(%rbp), %rax
	movl	-4(%rbp), %ecx
	movq	%rcx, %rdx
	.loc 1 43 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE12:
	.size	silver_path_facts__assume_invalid, .-silver_path_facts__assume_invalid
	.align 2
	.globl	silver_path_facts__rejected
	.type	silver_path_facts__rejected, @function
silver_path_facts__rejected:
.LFB13:
	.loc 1 45 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rdx
	movl	%esi, %eax
	movq	%rdx, -48(%rbp)
	movl	%eax, -40(%rbp)
	.loc 1 46 6
	movq	-48(%rbp), %rax
	movq	%rax, -32(%rbp)
	movl	-40(%rbp), %eax
	movl	%eax, -24(%rbp)
	.loc 1 46 24
	movb	$1, -22(%rbp)
	.loc 1 46 6
	movq	-32(%rbp), %rax
	movq	%rax, -12(%rbp)
	movl	-24(%rbp), %eax
	movl	%eax, -4(%rbp)
	.loc 1 46 6 is_stmt 0 discriminator 1
	movq	-12(%rbp), %rax
	movl	-4(%rbp), %ecx
	movq	%rcx, %rdx
	.loc 1 45 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE13:
	.size	silver_path_facts__rejected, .-silver_path_facts__rejected
	.align 2
	.globl	silver_path_facts__completed
	.type	silver_path_facts__completed, @function
silver_path_facts__completed:
.LFB14:
	.loc 1 47 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rdx
	movl	%esi, %eax
	movq	%rdx, -16(%rbp)
	movl	%eax, -8(%rbp)
	.loc 1 48 7
	movzbl	-7(%rbp), %eax
	xorl	$1, %eax
	.loc 1 48 35
	testb	%al, %al
	jne	.L70
	.loc 1 48 35 is_stmt 0 discriminator 1
	movzbl	-6(%rbp), %eax
	testb	%al, %al
	je	.L71
.L70:
	.loc 1 48 35 discriminator 2
	movl	$1, %eax
	jmp	.L72
.L71:
	.loc 1 48 35 discriminator 3
	movl	$0, %eax
.L72:
	.loc 1 47 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE14:
	.size	silver_path_facts__completed, .-silver_path_facts__completed
	.align 2
	.globl	silver_path_facts__keep_if
	.type	silver_path_facts__keep_if, @function
silver_path_facts__keep_if:
.LFB15:
	.loc 1 49 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rcx
	movl	%esi, %eax
	movb	%dl, -33(%rbp)
	movq	%rcx, -32(%rbp)
	movl	%eax, -24(%rbp)
	.loc 1 50 7
	cmpb	$0, -33(%rbp)
	je	.L75
	.loc 1 50 25 discriminator 1
	movq	-32(%rbp), %rax
	movq	%rax, -12(%rbp)
	movl	-24(%rbp), %eax
	movl	%eax, -4(%rbp)
	jmp	.L76
.L75:
	.loc 1 50 36 discriminator 2
	movq	silver_path_facts__empty_context(%rip), %rax
	movq	%rax, -12(%rbp)
	movl	8+silver_path_facts__empty_context(%rip), %eax
	movl	%eax, -4(%rbp)
.L76:
	.loc 1 49 4
	movq	-12(%rbp), %rax
	movl	-4(%rbp), %ecx
	movq	%rcx, %rdx
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE15:
	.size	silver_path_facts__keep_if, .-silver_path_facts__keep_if
	.align 2
	.globl	silver_path_facts__intersect
	.type	silver_path_facts__intersect, @function
silver_path_facts__intersect:
.LFB16:
	.loc 1 52 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$96, %rsp
	movl	%esi, %eax
	movl	%edx, -68(%rbp)
	movl	%ecx, -72(%rbp)
	movq	%rdi, -64(%rbp)
	movl	%eax, -56(%rbp)
	.loc 1 54 43
	movl	-64(%rbp), %edx
	movl	-68(%rbp), %eax
	cmpl	%eax, %edx
	cmovge	%edx, %eax
	testl	%eax, %eax
	jns	.L78
	.loc 1 54 43 is_stmt 0 discriminator 1
	leaq	.LC2(%rip), %rax
	movl	$54, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L78:
	.loc 1 54 43 discriminator 2
	movl	-64(%rbp), %eax
	.loc 1 54 10 is_stmt 1 discriminator 2
	movl	-68(%rbp), %edx
	cmpl	%eax, %edx
	cmovge	%edx, %eax
	movl	%eax, -4(%rbp)
	.loc 1 55 44
	movl	-60(%rbp), %edx
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	cmovle	%edx, %eax
	testl	%eax, %eax
	jns	.L79
	.loc 1 55 44 is_stmt 0 discriminator 1
	leaq	.LC2(%rip), %rax
	movl	$55, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L79:
	.loc 1 55 44 discriminator 2
	movl	-60(%rbp), %eax
	.loc 1 55 10 is_stmt 1 discriminator 2
	movl	-72(%rbp), %edx
	cmpl	%eax, %edx
	cmovle	%edx, %eax
	movl	%eax, -8(%rbp)
	.loc 1 56 60
	movzbl	-56(%rbp), %eax
	testb	%al, %al
	je	.L80
	.loc 1 56 60 is_stmt 0 discriminator 1
	movl	-4(%rbp), %eax
	cmpl	-8(%rbp), %eax
	jg	.L80
	.loc 1 56 60 discriminator 2
	movl	$1, %eax
	jmp	.L81
.L80:
	.loc 1 56 60 discriminator 3
	movl	$0, %eax
.L81:
	.loc 1 56 10 is_stmt 1 discriminator 4
	movb	%al, -9(%rbp)
	.loc 1 58 20
	cmpb	$0, -9(%rbp)
	je	.L82
	.loc 1 58 34 discriminator 1
	cmpl	$4096, -4(%rbp)
	jle	.L83
	.loc 1 58 34 is_stmt 0 discriminator 2
	leaq	.LC2(%rip), %rax
	movl	$58, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L83:
	.loc 1 58 20 is_stmt 1 discriminator 3
	movl	-4(%rbp), %eax
	jmp	.L84
.L82:
	.loc 1 58 20 is_stmt 0 discriminator 4
	movl	$0, %eax
.L84:
	.loc 1 58 9 is_stmt 1 discriminator 5
	movl	%eax, -24(%rbp)
	.loc 1 59 20
	cmpb	$0, -9(%rbp)
	je	.L85
	.loc 1 59 34 discriminator 1
	cmpl	$4096, -8(%rbp)
	jle	.L86
	.loc 1 59 34 is_stmt 0 discriminator 2
	leaq	.LC2(%rip), %rax
	movl	$59, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L86:
	.loc 1 59 20 is_stmt 1 discriminator 3
	movl	-8(%rbp), %eax
	jmp	.L87
.L85:
	.loc 1 59 20 is_stmt 0 discriminator 4
	movl	$0, %eax
.L87:
	.loc 1 58 9 is_stmt 1 discriminator 6
	movl	%eax, -20(%rbp)
	movzbl	-9(%rbp), %eax
	movb	%al, -16(%rbp)
	.loc 1 60 55
	movzbl	-55(%rbp), %eax
	testb	%al, %al
	je	.L88
	.loc 1 60 55 is_stmt 0 discriminator 1
	cmpl	$0, -68(%rbp)
	jne	.L88
	.loc 1 60 55 discriminator 2
	movl	$1, %eax
	jmp	.L89
.L88:
	.loc 1 60 55 discriminator 3
	movl	$0, %eax
.L89:
	.loc 1 58 9 is_stmt 1 discriminator 7
	movb	%al, -15(%rbp)
	movzbl	-54(%rbp), %eax
	movb	%al, -14(%rbp)
	leaq	-24(%rbp), %rax
	.loc 1 53 7
	movq	(%rax), %rdx
	movq	%rdx, -36(%rbp)
	movl	8(%rax), %eax
	movl	%eax, -28(%rbp)
	.loc 1 53 7 is_stmt 0 discriminator 1
	movq	-36(%rbp), %rax
	movl	-28(%rbp), %ecx
	movq	%rcx, %rdx
	.loc 1 52 4 is_stmt 1
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE16:
	.size	silver_path_facts__intersect, .-silver_path_facts__intersect
	.align 2
	.globl	silver_path_facts__join
	.type	silver_path_facts__join, @function
silver_path_facts__join:
.LFB17:
	.loc 1 63 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdx, %rax
	movq	%rcx, %rdx
	movq	%rdi, -32(%rbp)
	movl	%esi, -24(%rbp)
	movq	%rax, -48(%rbp)
	movl	-40(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -40(%rbp)
	.loc 1 64 20
	movzbl	-24(%rbp), %eax
	xorl	$1, %eax
	.loc 1 64 17
	testb	%al, %al
	je	.L92
	.loc 1 64 17 is_stmt 0 discriminator 1
	movl	-48(%rbp), %eax
	jmp	.L93
.L92:
	.loc 1 65 23 is_stmt 1
	movzbl	-40(%rbp), %eax
	xorl	$1, %eax
	.loc 1 65 17
	testb	%al, %al
	je	.L94
	.loc 1 64 17 discriminator 2
	movl	-32(%rbp), %eax
	jmp	.L93
.L94:
	.loc 1 66 34
	movl	-32(%rbp), %edx
	movl	-48(%rbp), %eax
	.loc 1 64 17 discriminator 3
	cmpl	%eax, %edx
	cmovle	%edx, %eax
.L93:
	.loc 1 64 6 discriminator 4
	movl	%eax, -12(%rbp)
	.loc 1 67 20
	movzbl	-24(%rbp), %eax
	xorl	$1, %eax
	.loc 1 67 17
	testb	%al, %al
	je	.L95
	.loc 1 67 17 is_stmt 0 discriminator 1
	movl	-44(%rbp), %eax
	jmp	.L96
.L95:
	.loc 1 68 23 is_stmt 1
	movzbl	-40(%rbp), %eax
	xorl	$1, %eax
	.loc 1 68 17
	testb	%al, %al
	je	.L97
	.loc 1 67 17 discriminator 2
	movl	-28(%rbp), %eax
	jmp	.L96
.L97:
	.loc 1 69 34
	movl	-28(%rbp), %edx
	movl	-44(%rbp), %eax
	.loc 1 67 17 discriminator 3
	cmpl	%eax, %edx
	cmovge	%edx, %eax
.L96:
	.loc 1 64 6 discriminator 5
	movl	%eax, -8(%rbp)
	.loc 1 70 47
	movzbl	-24(%rbp), %eax
	testb	%al, %al
	jne	.L98
	.loc 1 70 47 is_stmt 0 discriminator 1
	movzbl	-40(%rbp), %eax
	testb	%al, %al
	je	.L99
.L98:
	.loc 1 70 47 discriminator 2
	movl	$1, %eax
	jmp	.L100
.L99:
	.loc 1 70 47 discriminator 3
	movl	$0, %eax
.L100:
	.loc 1 64 6 is_stmt 1 discriminator 6
	movb	%al, -4(%rbp)
	.loc 1 71 51
	movzbl	-23(%rbp), %eax
	testb	%al, %al
	jne	.L101
	.loc 1 71 51 is_stmt 0 discriminator 1
	movzbl	-39(%rbp), %eax
	testb	%al, %al
	je	.L102
.L101:
	.loc 1 71 51 discriminator 2
	movl	$1, %eax
	jmp	.L103
.L102:
	.loc 1 71 51 discriminator 3
	movl	$0, %eax
.L103:
	.loc 1 64 6 is_stmt 1 discriminator 7
	movb	%al, -3(%rbp)
	.loc 1 73 10
	movzbl	-23(%rbp), %eax
	xorl	$1, %eax
	.loc 1 74 9
	testb	%al, %al
	jne	.L104
	.loc 1 73 37 discriminator 1
	movzbl	-22(%rbp), %eax
	testb	%al, %al
	je	.L105
.L104:
	.loc 1 74 19 discriminator 1
	movzbl	-39(%rbp), %eax
	xorl	$1, %eax
	.loc 1 74 9 discriminator 1
	testb	%al, %al
	jne	.L106
	.loc 1 74 47 discriminator 2
	movzbl	-38(%rbp), %eax
	testb	%al, %al
	je	.L105
.L106:
	.loc 1 74 9 discriminator 3
	movl	$1, %eax
	jmp	.L107
.L105:
	.loc 1 74 9 is_stmt 0 discriminator 4
	movl	$0, %eax
.L107:
	.loc 1 64 6 is_stmt 1 discriminator 8
	movb	%al, -2(%rbp)
	.loc 1 64 6 is_stmt 0 discriminator 9
	movq	-12(%rbp), %rax
	movl	-4(%rbp), %ecx
	movq	%rcx, %rdx
	.loc 1 63 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE17:
	.size	silver_path_facts__join, .-silver_path_facts__join
	.align 2
	.globl	silver_path_facts__below
	.type	silver_path_facts__below, @function
silver_path_facts__below:
.LFB18:
	.loc 1 76 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$64, %rsp
	movq	%rdi, %rcx
	movl	%esi, %eax
	movl	%edx, -36(%rbp)
	movq	%rcx, -32(%rbp)
	movl	%eax, -24(%rbp)
	.loc 1 77 7
	cmpl	$0, -36(%rbp)
	jne	.L110
	.loc 1 77 29 discriminator 1
	movq	silver_path_facts__empty_context(%rip), %rax
	movq	%rax, -12(%rbp)
	movl	8+silver_path_facts__empty_context(%rip), %eax
	movl	%eax, -4(%rbp)
	jmp	.L111
.L110:
	.loc 1 77 79 discriminator 2
	movl	-36(%rbp), %eax
	subl	$1, %eax
	testl	%eax, %eax
	jns	.L112
	.loc 1 77 79 is_stmt 0 discriminator 3
	leaq	.LC2(%rip), %rax
	movl	$77, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L112:
	.loc 1 77 48 is_stmt 1 discriminator 4
	movq	-32(%rbp), %rdi
	movl	-24(%rbp), %esi
	movl	%eax, %ecx
	movl	$0, %edx
	call	silver_path_facts__intersect
	movq	%rax, -12(%rbp)
	movl	-4(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -4(%rbp)
.L111:
	.loc 1 76 4
	movq	-12(%rbp), %rax
	movl	-4(%rbp), %ecx
	movq	%rcx, %rdx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE18:
	.size	silver_path_facts__below, .-silver_path_facts__below
	.align 2
	.globl	silver_path_facts__above
	.type	silver_path_facts__above, @function
silver_path_facts__above:
.LFB19:
	.loc 1 78 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$64, %rsp
	movq	%rdi, %rcx
	movl	%esi, %eax
	movl	%edx, -36(%rbp)
	movq	%rcx, -32(%rbp)
	movl	%eax, -24(%rbp)
	.loc 1 79 40
	movq	-32(%rbp), %rdx
	movl	-24(%rbp), %eax
	movq	%rdx, %rdi
	movl	%eax, %esi
	call	silver_path_facts__ceiling
	movl	%eax, %ecx
	.loc 1 79 35 discriminator 1
	movl	-36(%rbp), %eax
	leal	1(%rax), %edx
	.loc 1 79 7 discriminator 1
	movq	-32(%rbp), %rsi
	movl	-24(%rbp), %eax
	movq	%rsi, %rdi
	movl	%eax, %esi
	call	silver_path_facts__intersect
	movq	%rax, -12(%rbp)
	movl	-4(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -4(%rbp)
	.loc 1 79 7 is_stmt 0 discriminator 3
	movq	-12(%rbp), %rax
	movl	-4(%rbp), %ecx
	movq	%rcx, %rdx
	.loc 1 78 4 is_stmt 1
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE19:
	.size	silver_path_facts__above, .-silver_path_facts__above
	.align 2
	.globl	silver_path_facts__refine_input_true
	.type	silver_path_facts__refine_input_true, @function
silver_path_facts__refine_input_true:
.LFB20:
	.loc 1 80 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$96, %rsp
	movl	%esi, %eax
	movb	%dl, -65(%rbp)
	movl	%ecx, -72(%rbp)
	movq	%rdi, -64(%rbp)
	movl	%eax, -56(%rbp)
	.loc 1 83 12
	cmpb	$5, -65(%rbp)
	jbe	.L116
	.loc 1 83 12 is_stmt 0 discriminator 1
	leaq	.LC2(%rip), %rax
	movl	$83, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L116:
	.loc 1 83 12 discriminator 2
	cmpb	$5, -65(%rbp)
	jbe	.L117
	.loc 1 83 12 discriminator 3
	leaq	.LC2(%rip), %rax
	movl	$83, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L117:
	.loc 1 83 7 is_stmt 1 discriminator 4
	cmpb	$4, -65(%rbp)
	je	.L118
	cmpb	$4, -65(%rbp)
	ja	.L119
	cmpb	$3, -65(%rbp)
	je	.L120
	cmpb	$3, -65(%rbp)
	ja	.L119
	cmpb	$2, -65(%rbp)
	je	.L121
	cmpb	$2, -65(%rbp)
	ja	.L119
	cmpb	$0, -65(%rbp)
	je	.L122
	cmpb	$1, -65(%rbp)
	je	.L123
	jmp	.L119
.L122:
	.loc 1 84 23
	movl	-72(%rbp), %ecx
	movl	-72(%rbp), %edx
	movq	-64(%rbp), %rsi
	movl	-56(%rbp), %eax
	movq	%rsi, %rdi
	movl	%eax, %esi
	call	silver_path_facts__intersect
	movq	%rax, -12(%rbp)
	movl	-4(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -4(%rbp)
	.loc 1 84 23 is_stmt 0 discriminator 1
	jmp	.L125
.L123:
	.loc 1 85 57 is_stmt 1
	movl	-72(%rbp), %edx
	movq	-64(%rbp), %rcx
	movl	-56(%rbp), %eax
	movq	%rcx, %rdi
	movl	%eax, %esi
	call	silver_path_facts__above
	movq	%rax, -36(%rbp)
	movl	-28(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -28(%rbp)
	.loc 1 85 31 discriminator 1
	movl	-72(%rbp), %edx
	movq	-64(%rbp), %rcx
	movl	-56(%rbp), %eax
	movq	%rcx, %rdi
	movl	%eax, %esi
	call	silver_path_facts__below
	movq	%rax, -24(%rbp)
	movl	-16(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -16(%rbp)
	.loc 1 85 25 discriminator 2
	movq	-36(%rbp), %rax
	movl	-28(%rbp), %ecx
	movq	%rcx, %rdx
	movq	-24(%rbp), %rdi
	movl	-16(%rbp), %esi
	movq	%rdx, %rcx
	movq	%rax, %rdx
	call	silver_path_facts__join
	movq	%rax, -12(%rbp)
	movl	-4(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -4(%rbp)
	.loc 1 85 25 is_stmt 0 discriminator 3
	jmp	.L125
.L121:
	.loc 1 86 22 is_stmt 1
	movl	-72(%rbp), %edx
	movq	-64(%rbp), %rcx
	movl	-56(%rbp), %eax
	movq	%rcx, %rdi
	movl	%eax, %esi
	call	silver_path_facts__below
	movq	%rax, -12(%rbp)
	movl	-4(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -4(%rbp)
	.loc 1 86 22 is_stmt 0 discriminator 1
	jmp	.L125
.L120:
	.loc 1 87 28 is_stmt 1
	movl	-72(%rbp), %edx
	movq	-64(%rbp), %rsi
	movl	-56(%rbp), %eax
	movl	%edx, %ecx
	movl	$0, %edx
	movq	%rsi, %rdi
	movl	%eax, %esi
	call	silver_path_facts__intersect
	movq	%rax, -12(%rbp)
	movl	-4(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -4(%rbp)
	.loc 1 87 28 is_stmt 0 discriminator 1
	jmp	.L125
.L118:
	.loc 1 88 25 is_stmt 1
	movl	-72(%rbp), %edx
	movq	-64(%rbp), %rcx
	movl	-56(%rbp), %eax
	movq	%rcx, %rdi
	movl	%eax, %esi
	call	silver_path_facts__above
	movq	%rax, -12(%rbp)
	movl	-4(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -4(%rbp)
	.loc 1 88 25 is_stmt 0 discriminator 1
	jmp	.L125
.L119:
	.loc 1 89 60 is_stmt 1
	movq	-64(%rbp), %rdx
	movl	-56(%rbp), %eax
	movq	%rdx, %rdi
	movl	%eax, %esi
	call	silver_path_facts__ceiling
	movl	%eax, %ecx
	.loc 1 89 31 discriminator 1
	movl	-72(%rbp), %edx
	movq	-64(%rbp), %rsi
	movl	-56(%rbp), %eax
	movq	%rsi, %rdi
	movl	%eax, %esi
	call	silver_path_facts__intersect
	movq	%rax, -12(%rbp)
	movl	-4(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -4(%rbp)
.L125:
	.loc 1 80 4
	movq	-12(%rbp), %rax
	movl	-4(%rbp), %ecx
	movq	%rcx, %rdx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE20:
	.size	silver_path_facts__refine_input_true, .-silver_path_facts__refine_input_true
	.align 2
	.globl	silver_path_facts__refine_input
	.type	silver_path_facts__refine_input, @function
silver_path_facts__refine_input:
.LFB21:
	.loc 1 90 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$64, %rsp
	movl	%esi, %eax
	movb	%dl, -33(%rbp)
	movl	%ecx, -40(%rbp)
	movb	%r8b, -34(%rbp)
	movq	%rdi, -32(%rbp)
	movl	%eax, -24(%rbp)
	.loc 1 93 7
	cmpb	$0, -34(%rbp)
	je	.L127
	.loc 1 93 7 is_stmt 0 discriminator 1
	movzbl	-33(%rbp), %eax
	jmp	.L128
.L127:
	.loc 1 94 46 is_stmt 1
	movzbl	-33(%rbp), %eax
	movl	%eax, %edi
	call	silver_path_facts__complement
.L128:
	.loc 1 93 7 discriminator 3
	movl	-40(%rbp), %ecx
	movzbl	%al, %edx
	movq	-32(%rbp), %rsi
	movl	-24(%rbp), %eax
	movq	%rsi, %rdi
	movl	%eax, %esi
	call	silver_path_facts__refine_input_true
	movq	%rax, -12(%rbp)
	movl	-4(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -4(%rbp)
	.loc 1 93 7 is_stmt 0 discriminator 5
	movq	-12(%rbp), %rax
	movl	-4(%rbp), %ecx
	movq	%rcx, %rdx
	.loc 1 90 4 is_stmt 1
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE21:
	.size	silver_path_facts__refine_input, .-silver_path_facts__refine_input
	.align 2
	.globl	silver_path_facts__refine_bounds
	.type	silver_path_facts__refine_bounds, @function
silver_path_facts__refine_bounds:
.LFB22:
	.loc 1 100 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$88, %rsp
	.cfi_offset 3, -24
	movl	%esi, %eax
	movb	%dl, -49(%rbp)
	movq	%rcx, -60(%rbp)
	movq	%r8, -68(%rbp)
	movb	%r9b, -50(%rbp)
	movq	%rdi, -48(%rbp)
	movl	%eax, -40(%rbp)
	.loc 1 103 7
	movzbl	-56(%rbp), %eax
	testb	%al, %al
	je	.L131
	.loc 1 103 23 discriminator 1
	movzbl	-64(%rbp), %eax
	testb	%al, %al
	je	.L131
	.loc 1 104 25
	movzbl	-49(%rbp), %eax
	movl	$0, %edx
	movl	$0, %esi
	movl	%eax, %edi
	call	silver_path_facts__compare
	.loc 1 104 9 discriminator 1
	cmpb	%al, -50(%rbp)
	sete	%al
	movzbl	%al, %edx
	movq	-48(%rbp), %rcx
	movl	-40(%rbp), %eax
	movq	%rcx, %rdi
	movl	%eax, %esi
	call	silver_path_facts__keep_if
	movq	%rax, -28(%rbp)
	movl	-20(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -20(%rbp)
	.loc 1 104 9 is_stmt 0 discriminator 2
	jmp	.L132
.L131:
	.loc 1 105 7 is_stmt 1
	movzbl	-56(%rbp), %eax
	testb	%al, %al
	je	.L133
	.loc 1 105 31 discriminator 1
	movl	-68(%rbp), %ecx
	movzbl	-50(%rbp), %edi
	movzbl	-49(%rbp), %edx
	movq	-48(%rbp), %rsi
	movl	-40(%rbp), %eax
	movl	%edi, %r8d
	movq	%rsi, %rdi
	movl	%eax, %esi
	call	silver_path_facts__refine_input
	movq	%rax, -28(%rbp)
	movl	-20(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -20(%rbp)
	.loc 1 105 31 is_stmt 0 discriminator 2
	jmp	.L132
.L133:
	.loc 1 106 7 is_stmt 1
	movzbl	-64(%rbp), %eax
	testb	%al, %al
	je	.L134
	.loc 1 106 32 discriminator 1
	movl	-60(%rbp), %ebx
	movzbl	-49(%rbp), %eax
	movl	%eax, %edi
	call	silver_path_facts__swap
	.loc 1 106 32 is_stmt 0 discriminator 2
	movzbl	-50(%rbp), %ecx
	movzbl	%al, %edx
	movq	-48(%rbp), %rsi
	movl	-40(%rbp), %eax
	movl	%ecx, %r8d
	movl	%ebx, %ecx
	movq	%rsi, %rdi
	movl	%eax, %esi
	call	silver_path_facts__refine_input
	movq	%rax, -28(%rbp)
	movl	-20(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -20(%rbp)
	.loc 1 106 32 discriminator 3
	jmp	.L132
.L134:
	.loc 1 107 28 is_stmt 1
	movl	-68(%rbp), %edx
	movl	-60(%rbp), %ecx
	movzbl	-49(%rbp), %eax
	movl	%ecx, %esi
	movl	%eax, %edi
	call	silver_path_facts__compare
	.loc 1 107 12 discriminator 1
	cmpb	%al, -50(%rbp)
	sete	%al
	movzbl	%al, %edx
	movq	-48(%rbp), %rcx
	movl	-40(%rbp), %eax
	movq	%rcx, %rdi
	movl	%eax, %esi
	call	silver_path_facts__keep_if
	movq	%rax, -28(%rbp)
	movl	-20(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -20(%rbp)
.L132:
	.loc 1 100 4
	movq	-28(%rbp), %rax
	movl	-20(%rbp), %ecx
	movq	%rcx, %rdx
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE22:
	.size	silver_path_facts__refine_bounds, .-silver_path_facts__refine_bounds
	.align 2
	.globl	silver_path_facts__length_at
	.type	silver_path_facts__length_at, @function
silver_path_facts__length_at:
.LFB23:
	.loc 1 113 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, -8(%rbp)
	movl	%esi, -12(%rbp)
	.loc 1 115 27
	movl	-8(%rbp), %edx
	.loc 1 115 49
	movl	-4(%rbp), %eax
	imull	-12(%rbp), %eax
	.loc 1 115 27
	addl	%edx, %eax
	.loc 1 113 4
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE23:
	.size	silver_path_facts__length_at, .-silver_path_facts__length_at
	.align 2
	.globl	silver_path_facts__fits
	.type	silver_path_facts__fits, @function
silver_path_facts__fits:
.LFB24:
	.loc 1 116 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$32, %rsp
	movq	%rdi, %rcx
	movl	%esi, %eax
	movq	%rdx, -24(%rbp)
	movq	%rcx, -16(%rbp)
	movl	%eax, -8(%rbp)
	.loc 1 117 8
	movzbl	-8(%rbp), %eax
	xorl	$1, %eax
	.loc 1 118 7
	testb	%al, %al
	jne	.L138
	.loc 1 117 42 discriminator 1
	movl	-12(%rbp), %edx
	movq	-24(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_path_facts__length_at
	.loc 1 117 73 discriminator 2
	cmpl	$4096, %eax
	setle	%al
	.loc 1 117 34 discriminator 2
	testb	%al, %al
	je	.L139
.L138:
	.loc 1 118 17 discriminator 1
	movzbl	-7(%rbp), %eax
	xorl	$1, %eax
	.loc 1 118 7 discriminator 1
	testb	%al, %al
	jne	.L140
	.loc 1 118 53 discriminator 2
	movq	-24(%rbp), %rax
	movl	$0, %esi
	movq	%rax, %rdi
	call	silver_path_facts__length_at
	.loc 1 118 74 discriminator 3
	cmpl	$4096, %eax
	setle	%al
	.loc 1 118 45 discriminator 3
	testb	%al, %al
	je	.L139
.L140:
	.loc 1 118 7 discriminator 4
	movl	$1, %eax
	jmp	.L141
.L139:
	.loc 1 118 7 is_stmt 0 discriminator 5
	movl	$0, %eax
.L141:
	.loc 1 116 4 is_stmt 1
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE24:
	.size	silver_path_facts__fits, .-silver_path_facts__fits
	.align 2
	.globl	silver_path_facts__same_length
	.type	silver_path_facts__same_length, @function
silver_path_facts__same_length:
.LFB25:
	.loc 1 119 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 3, -24
	movl	%esi, %eax
	movq	%rdx, -40(%rbp)
	movq	%rcx, -48(%rbp)
	movq	%rdi, -32(%rbp)
	movl	%eax, -24(%rbp)
	.loc 1 120 28
	movl	-44(%rbp), %eax
	.loc 1 127 7
	testl	%eax, %eax
	jne	.L144
	.loc 1 121 36
	movl	-40(%rbp), %edx
	movl	-48(%rbp), %eax
	.loc 1 121 8
	cmpl	%eax, %edx
	jg	.L145
	.loc 1 122 39
	movl	-36(%rbp), %eax
	.loc 1 122 10
	testl	%eax, %eax
	jne	.L144
	.loc 1 123 39
	movl	-40(%rbp), %edx
	movl	-48(%rbp), %eax
	.loc 1 123 12
	cmpl	%eax, %edx
	jne	.L145
.L144:
	.loc 1 124 17
	movzbl	-24(%rbp), %eax
	xorl	$1, %eax
	.loc 1 124 7
	testb	%al, %al
	jne	.L146
	.loc 1 125 10
	movl	-32(%rbp), %edx
	movq	-40(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_path_facts__length_at
	movl	%eax, %ebx
	.loc 1 125 42 discriminator 1
	movl	-32(%rbp), %edx
	movq	-48(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_path_facts__length_at
	.loc 1 125 40 discriminator 2
	cmpl	%eax, %ebx
	sete	%al
	.loc 1 124 43 discriminator 1
	testb	%al, %al
	je	.L145
	.loc 1 126 19
	movl	-28(%rbp), %edx
	movq	-40(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_path_facts__length_at
	movl	%eax, %ebx
	.loc 1 126 51 discriminator 1
	movl	-28(%rbp), %edx
	movq	-48(%rbp), %rax
	movl	%edx, %esi
	movq	%rax, %rdi
	call	silver_path_facts__length_at
	.loc 1 126 49 discriminator 2
	cmpl	%eax, %ebx
	sete	%al
	.loc 1 126 10 discriminator 2
	testb	%al, %al
	je	.L145
.L146:
	.loc 1 127 17 discriminator 1
	movzbl	-23(%rbp), %eax
	xorl	$1, %eax
	.loc 1 127 7 discriminator 1
	testb	%al, %al
	jne	.L147
	.loc 1 127 53 discriminator 2
	movq	-40(%rbp), %rax
	movl	$0, %esi
	movq	%rax, %rdi
	call	silver_path_facts__length_at
	movl	%eax, %ebx
	.loc 1 127 75 discriminator 3
	movq	-48(%rbp), %rax
	movl	$0, %esi
	movq	%rax, %rdi
	call	silver_path_facts__length_at
	.loc 1 127 73 discriminator 4
	cmpl	%eax, %ebx
	sete	%al
	.loc 1 127 45 discriminator 4
	testb	%al, %al
	je	.L145
.L147:
	.loc 1 127 7 discriminator 5
	movl	$1, %eax
	jmp	.L148
.L145:
	.loc 1 127 7 is_stmt 0 discriminator 6
	movl	$0, %eax
.L148:
	.loc 1 119 4 is_stmt 1
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE25:
	.size	silver_path_facts__same_length, .-silver_path_facts__same_length
	.align 2
	.globl	silver_path_facts__refine_equal
	.type	silver_path_facts__refine_equal, @function
silver_path_facts__refine_equal:
.LFB26:
	.loc 1 139 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$64, %rsp
	movl	%esi, %eax
	movq	%rdx, -40(%rbp)
	movq	%rcx, -48(%rbp)
	movq	%rdi, -32(%rbp)
	movl	%eax, -24(%rbp)
	.loc 1 140 29
	movl	-36(%rbp), %edx
	movl	-44(%rbp), %eax
	.loc 1 140 7
	cmpl	%eax, %edx
	jne	.L151
	.loc 1 141 9
	movl	-40(%rbp), %edx
	movl	-48(%rbp), %eax
	cmpl	%eax, %edx
	sete	%al
	movzbl	%al, %edx
	movq	-32(%rbp), %rcx
	movl	-24(%rbp), %eax
	movq	%rcx, %rdi
	movl	%eax, %esi
	call	silver_path_facts__keep_if
	movq	%rax, -12(%rbp)
	movl	-4(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -4(%rbp)
	.loc 1 141 9 is_stmt 0 discriminator 1
	jmp	.L152
.L151:
	.loc 1 142 32 is_stmt 1
	movl	-36(%rbp), %edx
	movl	-44(%rbp), %eax
	.loc 1 142 7
	cmpl	%eax, %edx
	jle	.L153
	.loc 1 142 59 discriminator 1
	movq	-48(%rbp), %rcx
	movq	-40(%rbp), %rdx
	movq	-32(%rbp), %rsi
	movl	-24(%rbp), %eax
	movq	%rsi, %rdi
	movl	%eax, %esi
	call	silver_path_facts__equal_increasing
	movq	%rax, -12(%rbp)
	movl	-4(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -4(%rbp)
	.loc 1 142 59 is_stmt 0 discriminator 2
	jmp	.L152
.L153:
	.loc 1 143 12 is_stmt 1
	movq	-40(%rbp), %rcx
	movq	-48(%rbp), %rdx
	movq	-32(%rbp), %rsi
	movl	-24(%rbp), %eax
	movq	%rsi, %rdi
	movl	%eax, %esi
	call	silver_path_facts__equal_increasing
	movq	%rax, -12(%rbp)
	movl	-4(%rbp), %eax
	andl	$0, %eax
	orl	%edx, %eax
	movl	%eax, -4(%rbp)
.L152:
	.loc 1 139 4
	movq	-12(%rbp), %rax
	movl	-4(%rbp), %ecx
	movq	%rcx, %rdx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE26:
	.size	silver_path_facts__refine_equal, .-silver_path_facts__refine_equal
	.globl	silver_path_facts_E
	.data
	.align 2
	.type	silver_path_facts_E, @object
	.size	silver_path_facts_E, 2
silver_path_facts_E:
	.zero	2
	.globl	silver_path_facts__comparisonS
	.section	.rodata
	.align 32
	.type	silver_path_facts__comparisonS, @object
	.size	silver_path_facts__comparisonS, 46
silver_path_facts__comparisonS:
	.ascii	"EQUALUNEQUALLESSLESS_EQUALGREATERGREATER_EQUAL"
	.globl	silver_path_facts__comparisonN
	.align 8
	.type	silver_path_facts__comparisonN, @object
	.size	silver_path_facts__comparisonN, 8
silver_path_facts__comparisonN:
	.byte	1
	.byte	6
	.byte	13
	.byte	17
	.byte	27
	.byte	34
	.byte	47
	.zero	1
	.globl	silver_path_facts__empty_context
	.align 16
	.type	silver_path_facts__empty_context, @object
	.size	silver_path_facts__empty_context, 16
silver_path_facts__empty_context:
	.long	0
	.long	0
	.byte	0
	.byte	0
	.byte	1
	.zero	1
	.zero	4
	.align 8
	.type	comparisonP.3, @object
	.size	comparisonP.3, 8
comparisonP.3:
	.long	1
	.long	8
	.align 2
	.type	comparisonT1.2, @object
	.size	comparisonT1.2, 2
comparisonT1.2:
	.byte	3
	.byte	8
	.align 2
	.type	comparisonT2.1, @object
	.size	comparisonT2.1, 2
comparisonT2.1:
	.byte	2
	.byte	0
	.align 16
	.type	comparisonG.0, @object
	.size	comparisonG.0, 16
comparisonG.0:
	.byte	0
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	4
	.byte	0
	.byte	4
	.byte	0
	.byte	4
	.byte	0
	.byte	5
	.byte	0
	.zero	3
	.text
.Letext0:
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x736
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0xb
	.long	.LASF61
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.long	.LLRL0
	.quad	0
	.long	.Ldebug_line0
	.uleb128 0x7
	.sleb128 4096
	.long	.LASF2
	.long	0x3a
	.uleb128 0x3
	.long	0x2a
	.uleb128 0x9
	.byte	0x4
	.byte	0x5
	.long	.LASF16
	.uleb128 0x7
	.sleb128 64
	.long	.LASF3
	.long	0x3a
	.uleb128 0x7
	.sleb128 266240
	.long	.LASF4
	.long	0x3a
	.uleb128 0x3
	.long	0x4c
	.uleb128 0xc
	.long	.LASF62
	.byte	0x7
	.byte	0x1
	.byte	0x1
	.byte	0x9
	.byte	0x9
	.long	0x90
	.uleb128 0x6
	.long	.LASF5
	.byte	0
	.uleb128 0x6
	.long	.LASF6
	.byte	0x1
	.uleb128 0x6
	.long	.LASF7
	.byte	0x2
	.uleb128 0x6
	.long	.LASF8
	.byte	0x3
	.uleb128 0x6
	.long	.LASF9
	.byte	0x4
	.uleb128 0x6
	.long	.LASF10
	.byte	0x5
	.byte	0
	.uleb128 0x3
	.long	0x5d
	.uleb128 0xa
	.long	.LASF18
	.byte	0xc
	.byte	0x20
	.long	0xdd
	.uleb128 0x4
	.long	.LASF11
	.byte	0x21
	.byte	0x7
	.long	0x2a
	.byte	0
	.uleb128 0x4
	.long	.LASF12
	.byte	0x21
	.byte	0xe
	.long	0x2a
	.byte	0x4
	.uleb128 0x4
	.long	.LASF13
	.byte	0x22
	.byte	0x7
	.long	0xe2
	.byte	0x8
	.uleb128 0x4
	.long	.LASF14
	.byte	0x22
	.byte	0x18
	.long	0xe2
	.byte	0x9
	.uleb128 0x4
	.long	.LASF15
	.byte	0x22
	.byte	0x2b
	.long	0xe2
	.byte	0xa
	.byte	0
	.uleb128 0x3
	.long	0x95
	.uleb128 0x9
	.byte	0x1
	.byte	0x2
	.long	.LASF17
	.uleb128 0x3
	.long	0xe2
	.uleb128 0xa
	.long	.LASF19
	.byte	0x8
	.byte	0x6d
	.long	0x112
	.uleb128 0x4
	.long	.LASF20
	.byte	0x6e
	.byte	0x7
	.long	0x2a
	.byte	0
	.uleb128 0x4
	.long	.LASF21
	.byte	0x6f
	.byte	0x7
	.long	0x41
	.byte	0x4
	.byte	0
	.uleb128 0x3
	.long	0xee
	.uleb128 0xa
	.long	.LASF22
	.byte	0x8
	.byte	0x60
	.long	0x13b
	.uleb128 0x4
	.long	.LASF20
	.byte	0x61
	.byte	0x7
	.long	0x2a
	.byte	0
	.uleb128 0x4
	.long	.LASF23
	.byte	0x62
	.byte	0x7
	.long	0xe2
	.byte	0x4
	.byte	0
	.uleb128 0x3
	.long	0x117
	.uleb128 0xd
	.long	.LASF63
	.byte	0x1
	.byte	0x24
	.byte	0x4
	.long	0xdd
	.uleb128 0x9
	.byte	0x3
	.quad	silver_path_facts__empty_context
	.uleb128 0xe
	.long	.LASF64
	.byte	0x1
	.byte	0x4
	.byte	0x4
	.long	0x16b
	.value	0x1000
	.uleb128 0x9
	.byte	0x10
	.byte	0x5
	.long	.LASF24
	.uleb128 0x3
	.long	0x164
	.uleb128 0x2
	.long	.LASF28
	.byte	0x8b
	.long	0x95
	.quad	.LFB26
	.quad	.LFE26-.LFB26
	.uleb128 0x1
	.byte	0x9c
	.long	0x1bb
	.uleb128 0x1
	.long	.LASF25
	.byte	0x8b
	.byte	0x1b
	.long	0xdd
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0x1
	.long	.LASF26
	.byte	0x8b
	.byte	0x2c
	.long	0x112
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x1
	.long	.LASF27
	.byte	0x8b
	.byte	0x32
	.long	0x112
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.byte	0
	.uleb128 0x2
	.long	.LASF29
	.byte	0x77
	.long	0xe2
	.quad	.LFB25
	.quad	.LFE25-.LFB25
	.uleb128 0x1
	.byte	0x9c
	.long	0x206
	.uleb128 0x1
	.long	.LASF25
	.byte	0x77
	.byte	0x1a
	.long	0xdd
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0x1
	.long	.LASF26
	.byte	0x77
	.byte	0x2b
	.long	0x112
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x1
	.long	.LASF27
	.byte	0x77
	.byte	0x31
	.long	0x112
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.byte	0
	.uleb128 0x2
	.long	.LASF30
	.byte	0x74
	.long	0xe2
	.quad	.LFB24
	.quad	.LFE24-.LFB24
	.uleb128 0x1
	.byte	0x9c
	.long	0x243
	.uleb128 0x1
	.long	.LASF25
	.byte	0x74
	.byte	0x13
	.long	0xdd
	.uleb128 0x2
	.byte	0x91
	.sleb128 -32
	.uleb128 0x1
	.long	.LASF31
	.byte	0x74
	.byte	0x24
	.long	0x112
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.byte	0
	.uleb128 0x5
	.long	.LASF32
	.byte	0x71
	.long	0x4c
	.quad	.LFB23
	.quad	.LFE23-.LFB23
	.uleb128 0x1
	.byte	0x9c
	.long	0x280
	.uleb128 0x1
	.long	.LASF31
	.byte	0x71
	.byte	0x18
	.long	0x112
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0x1
	.long	.LASF33
	.byte	0x71
	.byte	0x29
	.long	0x35
	.uleb128 0x2
	.byte	0x91
	.sleb128 -28
	.byte	0
	.uleb128 0x2
	.long	.LASF34
	.byte	0x64
	.long	0x95
	.quad	.LFB22
	.quad	.LFE22-.LFB22
	.uleb128 0x1
	.byte	0x9c
	.long	0x2eb
	.uleb128 0x1
	.long	.LASF25
	.byte	0x65
	.byte	0x7
	.long	0xdd
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0x1
	.long	.LASF35
	.byte	0x65
	.byte	0x18
	.long	0x90
	.uleb128 0x3
	.byte	0x91
	.sleb128 -65
	.uleb128 0x1
	.long	.LASF26
	.byte	0x65
	.byte	0x2f
	.long	0x13b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x1
	.long	.LASF27
	.byte	0x65
	.byte	0x35
	.long	0x13b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -84
	.uleb128 0x1
	.long	.LASF36
	.byte	0x65
	.byte	0x44
	.long	0xe9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -66
	.byte	0
	.uleb128 0x2
	.long	.LASF37
	.byte	0x5a
	.long	0x95
	.quad	.LFB21
	.quad	.LFE21-.LFB21
	.uleb128 0x1
	.byte	0x9c
	.long	0x344
	.uleb128 0x1
	.long	.LASF25
	.byte	0x5b
	.byte	0x7
	.long	0xdd
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0x1
	.long	.LASF35
	.byte	0x5b
	.byte	0x18
	.long	0x90
	.uleb128 0x2
	.byte	0x91
	.sleb128 -49
	.uleb128 0x1
	.long	.LASF38
	.byte	0x5b
	.byte	0x2f
	.long	0x35
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.uleb128 0x1
	.long	.LASF36
	.byte	0x5b
	.byte	0x49
	.long	0xe9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -50
	.byte	0
	.uleb128 0x2
	.long	.LASF39
	.byte	0x50
	.long	0x95
	.quad	.LFB20
	.quad	.LFE20-.LFB20
	.uleb128 0x1
	.byte	0x9c
	.long	0x392
	.uleb128 0x1
	.long	.LASF25
	.byte	0x51
	.byte	0x7
	.long	0xdd
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x1
	.long	.LASF35
	.byte	0x51
	.byte	0x18
	.long	0x90
	.uleb128 0x3
	.byte	0x91
	.sleb128 -81
	.uleb128 0x1
	.long	.LASF38
	.byte	0x51
	.byte	0x2f
	.long	0x35
	.uleb128 0x3
	.byte	0x91
	.sleb128 -88
	.byte	0
	.uleb128 0x2
	.long	.LASF40
	.byte	0x4e
	.long	0x95
	.quad	.LFB19
	.quad	.LFE19-.LFB19
	.uleb128 0x1
	.byte	0x9c
	.long	0x3cf
	.uleb128 0x1
	.long	.LASF25
	.byte	0x4e
	.byte	0x14
	.long	0xdd
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0x1
	.long	.LASF38
	.byte	0x4e
	.byte	0x25
	.long	0x35
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.byte	0
	.uleb128 0x2
	.long	.LASF41
	.byte	0x4c
	.long	0x95
	.quad	.LFB18
	.quad	.LFE18-.LFB18
	.uleb128 0x1
	.byte	0x9c
	.long	0x40c
	.uleb128 0x1
	.long	.LASF25
	.byte	0x4c
	.byte	0x14
	.long	0xdd
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0x1
	.long	.LASF38
	.byte	0x4c
	.byte	0x25
	.long	0x35
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.byte	0
	.uleb128 0x5
	.long	.LASF42
	.byte	0x3f
	.long	0x95
	.quad	.LFB17
	.quad	.LFE17-.LFB17
	.uleb128 0x1
	.byte	0x9c
	.long	0x449
	.uleb128 0x1
	.long	.LASF26
	.byte	0x3f
	.byte	0x13
	.long	0xdd
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0x1
	.long	.LASF27
	.byte	0x3f
	.byte	0x19
	.long	0xdd
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.byte	0
	.uleb128 0x2
	.long	.LASF43
	.byte	0x34
	.long	0x95
	.quad	.LFB16
	.quad	.LFE16-.LFB16
	.uleb128 0x1
	.byte	0x9c
	.long	0x4c0
	.uleb128 0x1
	.long	.LASF25
	.byte	0x34
	.byte	0x18
	.long	0xdd
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x1
	.long	.LASF11
	.byte	0x34
	.byte	0x29
	.long	0x4ce
	.uleb128 0x3
	.byte	0x91
	.sleb128 -84
	.uleb128 0x1
	.long	.LASF12
	.byte	0x34
	.byte	0x30
	.long	0x4ce
	.uleb128 0x3
	.byte	0x91
	.sleb128 -88
	.uleb128 0xf
	.string	"low"
	.byte	0x1
	.byte	0x36
	.byte	0xa
	.long	0x4c0
	.uleb128 0x2
	.byte	0x91
	.sleb128 -20
	.uleb128 0x8
	.long	.LASF44
	.byte	0x37
	.long	0x4c0
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0x8
	.long	.LASF45
	.byte	0x38
	.long	0xe2
	.uleb128 0x2
	.byte	0x91
	.sleb128 -25
	.byte	0
	.uleb128 0x7
	.sleb128 2147483647
	.long	.LASF46
	.long	0x3a
	.uleb128 0x3
	.long	0x4c0
	.uleb128 0x5
	.long	.LASF47
	.byte	0x31
	.long	0x95
	.quad	.LFB15
	.quad	.LFE15-.LFB15
	.uleb128 0x1
	.byte	0x9c
	.long	0x510
	.uleb128 0x1
	.long	.LASF25
	.byte	0x31
	.byte	0x16
	.long	0xdd
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0x1
	.long	.LASF48
	.byte	0x31
	.byte	0x27
	.long	0xe9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -49
	.byte	0
	.uleb128 0x5
	.long	.LASF49
	.byte	0x2f
	.long	0xe2
	.quad	.LFB14
	.quad	.LFE14-.LFB14
	.uleb128 0x1
	.byte	0x9c
	.long	0x53f
	.uleb128 0x1
	.long	.LASF25
	.byte	0x2f
	.byte	0x18
	.long	0xdd
	.uleb128 0x2
	.byte	0x91
	.sleb128 -32
	.byte	0
	.uleb128 0x5
	.long	.LASF50
	.byte	0x2d
	.long	0x95
	.quad	.LFB13
	.quad	.LFE13-.LFB13
	.uleb128 0x1
	.byte	0x9c
	.long	0x56e
	.uleb128 0x1
	.long	.LASF25
	.byte	0x2d
	.byte	0x17
	.long	0xdd
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.byte	0
	.uleb128 0x5
	.long	.LASF51
	.byte	0x2b
	.long	0x95
	.quad	.LFB12
	.quad	.LFE12-.LFB12
	.uleb128 0x1
	.byte	0x9c
	.long	0x59d
	.uleb128 0x1
	.long	.LASF25
	.byte	0x2b
	.byte	0x1d
	.long	0xdd
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.byte	0
	.uleb128 0x5
	.long	.LASF52
	.byte	0x29
	.long	0x95
	.quad	.LFB11
	.quad	.LFE11-.LFB11
	.uleb128 0x1
	.byte	0x9c
	.long	0x5cc
	.uleb128 0x1
	.long	.LASF25
	.byte	0x29
	.byte	0x1b
	.long	0xdd
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.byte	0
	.uleb128 0x5
	.long	.LASF53
	.byte	0x27
	.long	0x2a
	.quad	.LFB10
	.quad	.LFE10-.LFB10
	.uleb128 0x1
	.byte	0x9c
	.long	0x5fb
	.uleb128 0x1
	.long	.LASF25
	.byte	0x27
	.byte	0x16
	.long	0xdd
	.uleb128 0x2
	.byte	0x91
	.sleb128 -32
	.byte	0
	.uleb128 0x5
	.long	.LASF54
	.byte	0x25
	.long	0x95
	.quad	.LFB9
	.quad	.LFE9-.LFB9
	.uleb128 0x1
	.byte	0x9c
	.long	0x62a
	.uleb128 0x1
	.long	.LASF55
	.byte	0x25
	.byte	0x16
	.long	0xe9
	.uleb128 0x2
	.byte	0x91
	.sleb128 -33
	.byte	0
	.uleb128 0x2
	.long	.LASF56
	.byte	0x18
	.long	0x5d
	.quad	.LFB8
	.quad	.LFE8-.LFB8
	.uleb128 0x1
	.byte	0x9c
	.long	0x659
	.uleb128 0x1
	.long	.LASF35
	.byte	0x18
	.byte	0x13
	.long	0x90
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.byte	0
	.uleb128 0x2
	.long	.LASF57
	.byte	0x13
	.long	0x5d
	.quad	.LFB7
	.quad	.LFE7-.LFB7
	.uleb128 0x1
	.byte	0x9c
	.long	0x688
	.uleb128 0x1
	.long	.LASF35
	.byte	0x13
	.byte	0x19
	.long	0x90
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.byte	0
	.uleb128 0x2
	.long	.LASF58
	.byte	0xa
	.long	0xe2
	.quad	.LFB6
	.quad	.LFE6-.LFB6
	.uleb128 0x1
	.byte	0x9c
	.long	0x6d3
	.uleb128 0x1
	.long	.LASF35
	.byte	0xa
	.byte	0x16
	.long	0x90
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.uleb128 0x1
	.long	.LASF26
	.byte	0xa
	.byte	0x2d
	.long	0x58
	.uleb128 0x2
	.byte	0x91
	.sleb128 -24
	.uleb128 0x1
	.long	.LASF27
	.byte	0xa
	.byte	0x33
	.long	0x58
	.uleb128 0x2
	.byte	0x91
	.sleb128 -28
	.byte	0
	.uleb128 0x10
	.long	.LASF65
	.byte	0x1
	.byte	0x82
	.byte	0x4
	.long	0x95
	.quad	.LFB4
	.quad	.LFE4-.LFB4
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x1
	.long	.LASF25
	.byte	0x80
	.byte	0x1f
	.long	0xdd
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF26
	.byte	0x80
	.byte	0x30
	.long	0x112
	.uleb128 0x3
	.byte	0x91
	.sleb128 -104
	.uleb128 0x1
	.long	.LASF27
	.byte	0x80
	.byte	0x36
	.long	0x112
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x8
	.long	.LASF59
	.byte	0x84
	.long	0x2a
	.uleb128 0x2
	.byte	0x91
	.sleb128 -36
	.uleb128 0x8
	.long	.LASF60
	.byte	0x87
	.long	0x2a
	.uleb128 0x2
	.byte	0x91
	.sleb128 -40
	.byte	0
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x28
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x1c
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 10
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 9
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x55
	.uleb128 0x17
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x27
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x1c
	.uleb128 0x5
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x3c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.LFE4-.Ltext0
	.quad	.LFB6
	.quad	.Letext0-.LFB6
	.quad	0
	.quad	0
	.section	.debug_rnglists,"",@progbits
.Ldebug_ranges0:
	.long	.Ldebug_ranges3-.Ldebug_ranges2
.Ldebug_ranges2:
	.value	0x5
	.byte	0x8
	.byte	0
	.long	0
.LLRL0:
	.byte	0x7
	.quad	.Ltext0
	.uleb128 .LFE4-.Ltext0
	.byte	0x7
	.quad	.LFB6
	.uleb128 .Letext0-.LFB6
	.byte	0
.Ldebug_ranges3:
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF7:
	.string	"silver_path_facts__less"
.LASF32:
	.string	"silver_path_facts__length_at"
.LASF4:
	.string	"silver_path_facts__expression_length"
.LASF34:
	.string	"silver_path_facts__refine_bounds"
.LASF65:
	.string	"silver_path_facts__equal_increasing"
.LASF39:
	.string	"silver_path_facts__refine_input_true"
.LASF12:
	.string	"upper"
.LASF31:
	.string	"value"
.LASF22:
	.string	"silver_path_facts__bound"
.LASF26:
	.string	"left"
.LASF20:
	.string	"static_length"
.LASF8:
	.string	"silver_path_facts__less_equal"
.LASF55:
	.string	"arguments"
.LASF28:
	.string	"silver_path_facts__refine_equal"
.LASF56:
	.string	"silver_path_facts__swap"
.LASF43:
	.string	"silver_path_facts__intersect"
.LASF11:
	.string	"lower"
.LASF53:
	.string	"silver_path_facts__ceiling"
.LASF3:
	.string	"silver_path_facts__operand_count"
.LASF54:
	.string	"silver_path_facts__initial"
.LASF10:
	.string	"silver_path_facts__greater_equal"
.LASF64:
	.string	"silver_path_facts__max_length"
.LASF18:
	.string	"silver_path_facts__context"
.LASF15:
	.string	"invalid_rejected"
.LASF19:
	.string	"silver_path_facts__summary"
.LASF14:
	.string	"invalid_reachable"
.LASF13:
	.string	"valid_reachable"
.LASF37:
	.string	"silver_path_facts__refine_input"
.LASF35:
	.string	"operator"
.LASF5:
	.string	"silver_path_facts__equal"
.LASF47:
	.string	"silver_path_facts__keep_if"
.LASF49:
	.string	"silver_path_facts__completed"
.LASF46:
	.string	"natural"
.LASF48:
	.string	"condition"
.LASF50:
	.string	"silver_path_facts__rejected"
.LASF41:
	.string	"silver_path_facts__below"
.LASF9:
	.string	"silver_path_facts__greater"
.LASF27:
	.string	"right"
.LASF60:
	.string	"candidate"
.LASF38:
	.string	"threshold"
.LASF23:
	.string	"dynamic"
.LASF30:
	.string	"silver_path_facts__fits"
.LASF58:
	.string	"silver_path_facts__compare"
.LASF6:
	.string	"silver_path_facts__unequal"
.LASF21:
	.string	"dynamic_count"
.LASF29:
	.string	"silver_path_facts__same_length"
.LASF42:
	.string	"silver_path_facts__join"
.LASF57:
	.string	"silver_path_facts__complement"
.LASF40:
	.string	"silver_path_facts__above"
.LASF25:
	.string	"facts"
.LASF44:
	.string	"high"
.LASF52:
	.string	"silver_path_facts__assume_valid"
.LASF24:
	.string	"universal_integer"
.LASF51:
	.string	"silver_path_facts__assume_invalid"
.LASF16:
	.string	"integer"
.LASF36:
	.string	"truth"
.LASF59:
	.string	"numerator"
.LASF62:
	.string	"silver_path_facts__comparison"
.LASF33:
	.string	"input_length"
.LASF63:
	.string	"silver_path_facts__empty_context"
.LASF61:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF17:
	.string	"boolean"
.LASF2:
	.string	"silver_path_facts__length_value"
.LASF45:
	.string	"valid"
	.section	.debug_line_str,"MS",@progbits,1
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_path_facts.ads"
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
