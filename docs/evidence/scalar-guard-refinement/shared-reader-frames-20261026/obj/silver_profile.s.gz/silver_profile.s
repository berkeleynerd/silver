	.file	"silver_profile.adb"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_profile.adb"
	.align 2
	.globl	silver_profile__token_kindH
	.type	silver_profile__token_kindH, @function
silver_profile__token_kindH:
.LFB2:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	movq	-8(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L2
	movl	%edx, %ecx
	subl	%eax, %ecx
	leal	1(%rcx), %r11d
	jmp	.L3
.L2:
	movl	$0, %r11d
.L3:
	movslq	%eax, %r9
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	leal	-1(%rax), %r10d
	movl	$0, %esi
	movl	$0, %ecx
	movl	$0, %edx
.L11:
	cmpl	$1, %edx
	jg	.L10
	movslq	%edx, %rax
	leaq	0(,%rax,4), %rdi
	leaq	token_kindP.20(%rip), %rax
	movl	(%rdi,%rax), %eax
	cmpl	%eax, %r11d
	jl	.L10
	movq	-16(%rbp), %rax
	movslq	%edx, %rdi
	leaq	0(,%rdi,4), %r8
	leaq	token_kindP.20(%rip), %rdi
	movl	(%r8,%rdi), %edi
	addl	%r10d, %edi
	movslq	%edi, %rdi
	subq	%r9, %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %r8d
	movslq	%edx, %rax
	leaq	token_kindT1.19(%rip), %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %eax
	imull	%r8d, %eax
	leal	(%rsi,%rax), %edi
	movslq	%edi, %rax
	imulq	$1272582903, %rax, %rax
	shrq	$32, %rax
	movl	%eax, %esi
	sarl	$3, %esi
	movl	%edi, %eax
	sarl	$31, %eax
	subl	%eax, %esi
	movl	%esi, %eax
	addl	%eax, %eax
	addl	%esi, %eax
	leal	0(,%rax,8), %esi
	addl	%esi, %eax
	movl	%edi, %esi
	subl	%eax, %esi
	movslq	%edx, %rax
	leaq	token_kindT2.18(%rip), %rdi
	movzbl	(%rax,%rdi), %eax
	movzbl	%al, %eax
	imull	%r8d, %eax
	leal	(%rcx,%rax), %edi
	movslq	%edi, %rax
	imulq	$1272582903, %rax, %rax
	shrq	$32, %rax
	movl	%eax, %ecx
	sarl	$3, %ecx
	movl	%edi, %eax
	sarl	$31, %eax
	subl	%eax, %ecx
	movl	%ecx, %eax
	addl	%eax, %eax
	addl	%ecx, %eax
	leal	0(,%rax,8), %ecx
	addl	%ecx, %eax
	movl	%edi, %ecx
	subl	%eax, %ecx
	addl	$1, %edx
	jmp	.L11
.L10:
	movslq	%esi, %rax
	leaq	token_kindG.17(%rip), %rdx
	movzbl	(%rax,%rdx), %eax
	movzbl	%al, %edx
	movslq	%ecx, %rax
	leaq	token_kindG.17(%rip), %rcx
	movzbl	(%rax,%rcx), %eax
	movzbl	%al, %eax
	leal	(%rdx,%rax), %ecx
	movslq	%ecx, %rax
	imulq	$715827883, %rax, %rax
	shrq	$32, %rax
	movl	%eax, %edx
	sarl	%edx
	movl	%ecx, %eax
	sarl	$31, %eax
	subl	%eax, %edx
	movl	%edx, %eax
	addl	%eax, %eax
	addl	%edx, %eax
	sall	$2, %eax
	movl	%ecx, %edx
	subl	%eax, %edx
	movl	%edx, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	silver_profile__token_kindH, .-silver_profile__token_kindH
	.align 2
	.globl	silver_profile__token_sequenceIP
	.type	silver_profile__token_sequenceIP, @function
silver_profile__token_sequenceIP:
.LFB3:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.size	silver_profile__token_sequenceIP, .-silver_profile__token_sequenceIP
	.align 2
	.type	silver_profile__is_word_token___wrapped_statements.0, @function
silver_profile__is_word_token___wrapped_statements.0:
.LFB5:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_profile.adb"
	.loc 1 6 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	.loc 1 7 13
	movzbl	(%rax), %eax
	cmpb	$8, %al
	setbe	%al
	.loc 1 6 4
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE5:
	.size	silver_profile__is_word_token___wrapped_statements.0, .-silver_profile__is_word_token___wrapped_statements.0
	.section	.rodata
	.align 8
.LC6:
	.ascii	"failed postcondition from silver_profile.ads:53"
	.align 8
.LC0:
	.long	1
	.long	47
	.text
	.align 2
	.globl	silver_profile__is_word_token
	.type	silver_profile__is_word_token, @function
silver_profile__is_word_token:
.LFB4:
	.loc 1 6 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	subq	$32, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	movb	%dil, -33(%rbp)
	.loc 1 6 4
	leaq	16(%rbp), %rax
	.loc 1 6 4 is_stmt 0 discriminator 1
	movq	%rax, -24(%rbp)
	movzbl	-33(%rbp), %eax
	movb	%al, -32(%rbp)
.LBB4:
	leaq	-32(%rbp), %rax
	movq	%rax, %r10
	call	silver_profile__is_word_token___wrapped_statements.0
	.file 2 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_profile.ads"
	.loc 2 53 66 is_stmt 1
	movzbl	-32(%rbp), %edx
	cmpb	$8, %dl
	setbe	%dl
	.loc 2 53 19
	cmpb	%dl, %al
	je	.L19
.LBB5:
	.loc 2 53 19 is_stmt 0 discriminator 1
	leaq	.LC6(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L19:
.LBE5:
.LBE4:
	.loc 1 6 4 is_stmt 1
	addq	$32, %rsp
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	silver_profile__is_word_token, .-silver_profile__is_word_token
	.section	.rodata
.LC7:
	.ascii	"silver_profile.adb"
	.zero	1
	.text
	.align 2
	.type	silver_profile__spelling___wrapped_statements.1, @function
silver_profile__spelling___wrapped_statements.1:
.LFB7:
	.loc 1 9 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	subq	$16, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	movq	%r10, %rax
	movq	%r10, -24(%rbp)
	.loc 1 10 12
	movzbl	(%rax), %edx
	cmpb	$11, %dl
	jbe	.L21
	.loc 1 10 12 is_stmt 0 discriminator 1
	leaq	.LC7(%rip), %rax
	movl	$10, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L21:
	.loc 1 10 12 discriminator 2
	movzbl	(%rax), %edx
	cmpb	$11, %dl
	jbe	.L22
	.loc 1 10 12 discriminator 3
	leaq	.LC7(%rip), %rax
	movl	$10, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L22:
	.loc 1 10 7 is_stmt 1 discriminator 4
	movzbl	(%rax), %eax
	cmpb	$10, %al
	je	.L23
	cmpb	$10, %al
	ja	.L24
	cmpb	$9, %al
	je	.L25
	cmpb	$9, %al
	ja	.L24
	cmpb	$8, %al
	je	.L26
	cmpb	$8, %al
	ja	.L24
	cmpb	$7, %al
	je	.L27
	cmpb	$7, %al
	ja	.L24
	cmpb	$6, %al
	je	.L28
	cmpb	$6, %al
	ja	.L24
	cmpb	$5, %al
	je	.L29
	cmpb	$5, %al
	ja	.L24
	cmpb	$4, %al
	je	.L30
	cmpb	$4, %al
	ja	.L24
	cmpb	$3, %al
	je	.L31
	cmpb	$3, %al
	ja	.L24
	cmpb	$2, %al
	je	.L32
	cmpb	$2, %al
	ja	.L24
	testb	%al, %al
	je	.L33
	cmpb	$1, %al
	je	.L34
	jmp	.L24
.L33:
	.loc 1 11 36
	movl	$4, %esi
	movl	$20, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 11 36 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$9, 4(%rax)
	movabsq	$8247608679221654128, %rcx
	movq	%rcx, 8(%rax)
	movb	$101, 16(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L35
.L34:
	.loc 1 12 28 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 12 28 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1852399981, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L35
.L32:
	.loc 1 13 29 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 13 29 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$2, 4(%rax)
	movw	$29545, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L35
.L31:
	.loc 1 14 33 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 14 33 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$6, 4(%rax)
	movl	$1734439536, 8(%rax)
	movw	$24941, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L35
.L30:
	.loc 1 15 34 is_stmt 1
	movl	$4, %esi
	movl	$20, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 15 34 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$10, 4(%rax)
	movabsq	$8029178625756590195, %rcx
	movq	%rcx, 8(%rax)
	movw	$25956, 16(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L35
.L29:
	.loc 1 16 26 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 16 26 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$2, 4(%rax)
	movw	$28271, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L35
.L28:
	.loc 1 17 32 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 17 32 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$5, 4(%rax)
	movl	$1768383842, 8(%rax)
	movb	$110, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L35
.L27:
	.loc 1 18 31 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 18 31 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1819047278, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L35
.L26:
	.loc 1 19 30 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 19 30 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$28261, 8(%rax)
	movb	$100, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L35
.L25:
	.loc 1 20 35 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 20 35 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$1, 4(%rax)
	movb	$40, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L35
.L23:
	.loc 1 21 36 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 21 36 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$1, 4(%rax)
	movb	$41, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L35
.L24:
	.loc 1 22 28 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 22 28 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$1, 4(%rax)
	movb	$59, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
.L35:
	.loc 1 9 4 is_stmt 1
	movq	%r12, %rax
	movq	%r13, %rdx
	addq	$16, %rsp
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE7:
	.size	silver_profile__spelling___wrapped_statements.1, .-silver_profile__spelling___wrapped_statements.1
	.section	.rodata
	.align 8
.LC8:
	.ascii	"failed postcondition from silver_profile.ads:78"
	.align 8
.LC9:
	.ascii	"failed postcondition from silver_profile.ads:79"
	.text
	.align 2
	.globl	silver_profile__spelling
	.type	silver_profile__spelling, @function
silver_profile__spelling:
.LFB6:
	.loc 1 9 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movb	%dil, -65(%rbp)
	.loc 1 9 4
	leaq	16(%rbp), %rax
	.loc 1 9 4 is_stmt 0 discriminator 1
	movq	%rax, -56(%rbp)
	movzbl	-65(%rbp), %eax
	movb	%al, -64(%rbp)
.LBB6:
	leaq	-64(%rbp), %rax
	movq	%rax, %r10
	call	silver_profile__spelling___wrapped_statements.1
	.loc 1 9 4 discriminator 2
	movq	%rax, %rcx
	movq	%rdx, %rbx
	movq	%rbx, %rax
	movl	(%rax), %eax
	movq	%rbx, %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	.loc 1 9 4 discriminator 5
	cmpl	%eax, %edx
	.loc 1 9 4 discriminator 8
	cmpl	%eax, %edx
	.loc 1 9 4 discriminator 11
	cmpl	%eax, %edx
	jl	.L43
	.loc 1 9 4 discriminator 12
	testl	%eax, %eax
	jg	.L43
	.loc 1 9 4 discriminator 13
	leaq	.LC7(%rip), %rax
	movl	$9, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L43:
	.loc 2 78 19 is_stmt 1
	cmpl	$1, %eax
	je	.L44
.LBB7:
	.loc 2 78 19 is_stmt 0 discriminator 1
	leaq	.LC8(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L44:
.LBE7:
	.loc 2 78 19 discriminator 2
	cmpl	%eax, %edx
	jl	.L45
	.loc 2 79 45 is_stmt 1
	movl	%edx, %esi
	movl	%eax, %edi
	subl	%edi, %esi
	addl	$1, %esi
	testl	%esi, %esi
	jle	.L45
	.loc 2 79 45 is_stmt 0 discriminator 1
	cmpl	%eax, %edx
	jl	.L46
	.loc 2 79 45 discriminator 2
	movl	%edx, %esi
	movl	%eax, %edx
	movl	%esi, %eax
	subl	%edx, %eax
	addl	$1, %eax
	cmpl	$10, %eax
	jle	.L46
.L45:
.LBB8:
	.loc 2 78 19 is_stmt 1 discriminator 3
	leaq	.LC9(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L46:
.LBE8:
	.loc 1 9 4 discriminator 14
	movq	%rcx, %rax
	movq	%rbx, %rdx
.LBE6:
	.loc 1 9 4 is_stmt 0
	addq	$40, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE6:
	.size	silver_profile__spelling, .-silver_profile__spelling
	.align 2
	.type	silver_profile__is_whitespace___wrapped_statements.2, @function
silver_profile__is_whitespace___wrapped_statements.2:
.LFB9:
	.loc 1 24 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	.loc 1 28 7
	movzbl	(%rax), %edx
	cmpb	$32, %dl
	je	.L49
	.loc 1 26 7
	movzbl	(%rax), %edx
	cmpb	$9, %dl
	je	.L49
	.loc 1 27 7
	movzbl	(%rax), %edx
	cmpb	$10, %dl
	je	.L49
	.loc 1 28 7 discriminator 1
	movzbl	(%rax), %eax
	cmpb	$13, %al
	jne	.L50
.L49:
	.loc 1 28 7 is_stmt 0 discriminator 2
	movl	$1, %eax
	jmp	.L51
.L50:
	.loc 1 28 7 discriminator 3
	movl	$0, %eax
.L51:
	.loc 1 24 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE9:
	.size	silver_profile__is_whitespace___wrapped_statements.2, .-silver_profile__is_whitespace___wrapped_statements.2
	.section	.rodata
	.align 8
.LC10:
	.ascii	"failed postcondition from silver_profile.ads:10"
	.text
	.align 2
	.globl	silver_profile__is_whitespace
	.type	silver_profile__is_whitespace, @function
silver_profile__is_whitespace:
.LFB8:
	.loc 1 24 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	subq	$32, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	movb	%dil, -33(%rbp)
	.loc 1 24 4
	leaq	16(%rbp), %rax
	.loc 1 24 4 is_stmt 0 discriminator 1
	movq	%rax, -24(%rbp)
	movzbl	-33(%rbp), %eax
	movb	%al, -32(%rbp)
.LBB9:
	leaq	-32(%rbp), %rax
	movq	%rax, %r10
	call	silver_profile__is_whitespace___wrapped_statements.2
	.loc 2 12 48 is_stmt 1
	movzbl	-32(%rbp), %edx
	cmpb	$32, %dl
	je	.L54
	.loc 2 11 40
	movzbl	-32(%rbp), %edx
	cmpb	$9, %dl
	je	.L54
	.loc 2 12 14 discriminator 1
	movzbl	-32(%rbp), %edx
	cmpb	$10, %dl
	je	.L54
	.loc 2 12 48 discriminator 2
	movzbl	-32(%rbp), %edx
	cmpb	$13, %dl
	jne	.L55
.L54:
	.loc 2 12 48 is_stmt 0 discriminator 3
	movl	$1, %edx
	jmp	.L56
.L55:
	.loc 2 12 48 discriminator 4
	movl	$0, %edx
.L56:
	.loc 2 10 19 is_stmt 1
	cmpb	%al, %dl
	je	.L58
.LBB10:
	.loc 2 10 19 is_stmt 0 discriminator 1
	leaq	.LC10(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L58:
.LBE10:
.LBE9:
	.loc 1 24 4 is_stmt 1
	addq	$32, %rsp
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE8:
	.size	silver_profile__is_whitespace, .-silver_profile__is_whitespace
	.align 2
	.type	silver_profile__is_allowed_character___wrapped_statements.3, @function
silver_profile__is_allowed_character___wrapped_statements.3:
.LFB11:
	.loc 1 30 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	.loc 1 31 12
	movzbl	(%rax), %edx
	.loc 1 31 26
	cmpb	$31, %dl
	jbe	.L60
	.loc 1 31 12 discriminator 1
	movzbl	(%rax), %edx
	cmpb	$126, %dl
	jbe	.L61
.L60:
	.loc 1 31 34 discriminator 2
	movzbl	(%rax), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_whitespace
	.loc 1 31 26 discriminator 3
	testb	%al, %al
	je	.L62
.L61:
	.loc 1 31 26 is_stmt 0 discriminator 4
	movl	$1, %eax
	jmp	.L63
.L62:
	.loc 1 31 26 discriminator 5
	movl	$0, %eax
.L63:
	.loc 1 30 4 is_stmt 1
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE11:
	.size	silver_profile__is_allowed_character___wrapped_statements.3, .-silver_profile__is_allowed_character___wrapped_statements.3
	.section	.rodata
	.align 8
.LC11:
	.ascii	"failed postcondition from silver_profile.ads:15"
	.text
	.align 2
	.globl	silver_profile__is_allowed_character
	.type	silver_profile__is_allowed_character, @function
silver_profile__is_allowed_character:
.LFB10:
	.loc 1 30 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	subq	$32, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	movb	%dil, -33(%rbp)
	.loc 1 30 4
	leaq	16(%rbp), %rax
	.loc 1 30 4 is_stmt 0 discriminator 1
	movq	%rax, -24(%rbp)
	movzbl	-33(%rbp), %eax
	movb	%al, -32(%rbp)
.LBB11:
	leaq	-32(%rbp), %rax
	movq	%rax, %r10
	call	silver_profile__is_allowed_character___wrapped_statements.3
	.loc 2 16 35 is_stmt 1
	movzbl	-32(%rbp), %edx
	.loc 2 19 14
	cmpb	$31, %dl
	jbe	.L66
	.loc 2 16 35 discriminator 1
	movzbl	-32(%rbp), %edx
	cmpb	$126, %dl
	jbe	.L67
.L66:
	.loc 2 17 14
	movzbl	-32(%rbp), %edx
	cmpb	$9, %dl
	je	.L67
	.loc 2 18 14
	movzbl	-32(%rbp), %edx
	cmpb	$10, %dl
	je	.L67
	.loc 2 19 14 discriminator 1
	movzbl	-32(%rbp), %edx
	cmpb	$13, %dl
	jne	.L68
.L67:
	.loc 2 19 14 is_stmt 0 discriminator 2
	movl	$1, %edx
	jmp	.L69
.L68:
	.loc 2 19 14 discriminator 3
	movl	$0, %edx
.L69:
	.loc 2 15 19 is_stmt 1
	cmpb	%al, %dl
	je	.L71
.LBB12:
	.loc 2 15 19 is_stmt 0 discriminator 1
	leaq	.LC11(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L71:
.LBE12:
.LBE11:
	.loc 1 30 4 is_stmt 1
	addq	$32, %rsp
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE10:
	.size	silver_profile__is_allowed_character, .-silver_profile__is_allowed_character
	.align 2
	.type	silver_profile__is_comment_end___wrapped_statements.4, @function
silver_profile__is_comment_end___wrapped_statements.4:
.LFB13:
	.loc 1 33 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	.loc 1 34 33
	movzbl	(%rax), %edx
	cmpb	$10, %dl
	je	.L73
	.loc 1 34 33 is_stmt 0 discriminator 1
	movzbl	(%rax), %eax
	cmpb	$13, %al
	jne	.L74
.L73:
	.loc 1 34 33 discriminator 2
	movl	$1, %eax
	jmp	.L75
.L74:
	.loc 1 34 33 discriminator 3
	movl	$0, %eax
.L75:
	.loc 1 33 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE13:
	.size	silver_profile__is_comment_end___wrapped_statements.4, .-silver_profile__is_comment_end___wrapped_statements.4
	.section	.rodata
	.align 8
.LC12:
	.ascii	"failed postcondition from silver_profile.ads:29"
	.text
	.align 2
	.globl	silver_profile__is_comment_end
	.type	silver_profile__is_comment_end, @function
silver_profile__is_comment_end:
.LFB12:
	.loc 1 33 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	subq	$32, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	movb	%dil, -33(%rbp)
	.loc 1 33 4
	leaq	16(%rbp), %rax
	.loc 1 33 4 is_stmt 0 discriminator 1
	movq	%rax, -24(%rbp)
	movzbl	-33(%rbp), %eax
	movb	%al, -32(%rbp)
.LBB13:
	leaq	-32(%rbp), %rax
	movq	%rax, %r10
	call	silver_profile__is_comment_end___wrapped_statements.4
	.loc 2 30 40 is_stmt 1
	movzbl	-32(%rbp), %edx
	cmpb	$10, %dl
	je	.L78
	.loc 2 30 40 is_stmt 0 discriminator 1
	movzbl	-32(%rbp), %edx
	cmpb	$13, %dl
	jne	.L79
.L78:
	.loc 2 30 40 discriminator 2
	movl	$1, %edx
	jmp	.L80
.L79:
	.loc 2 30 40 discriminator 3
	movl	$0, %edx
.L80:
	.loc 2 29 19 is_stmt 1
	cmpb	%al, %dl
	je	.L82
.LBB14:
	.loc 2 29 19 is_stmt 0 discriminator 1
	leaq	.LC12(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L82:
.LBE14:
.LBE13:
	.loc 1 33 4 is_stmt 1
	addq	$32, %rsp
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE12:
	.size	silver_profile__is_comment_end, .-silver_profile__is_comment_end
	.align 2
	.type	silver_profile__is_identifier_character___wrapped_statements.5, @function
silver_profile__is_identifier_character___wrapped_statements.5:
.LFB15:
	.loc 1 36 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	.loc 1 37 12
	movzbl	(%rax), %edx
	.loc 1 40 7
	cmpb	$64, %dl
	jbe	.L84
	.loc 1 37 12 discriminator 1
	movzbl	(%rax), %edx
	cmpb	$90, %dl
	jbe	.L85
.L84:
	.loc 1 38 20
	movzbl	(%rax), %edx
	.loc 1 38 7
	cmpb	$96, %dl
	jbe	.L86
	.loc 1 38 20 discriminator 1
	movzbl	(%rax), %edx
	cmpb	$122, %dl
	jbe	.L85
.L86:
	.loc 1 39 20
	movzbl	(%rax), %edx
	.loc 1 39 7
	cmpb	$47, %dl
	jbe	.L87
	.loc 1 39 20 discriminator 1
	movzbl	(%rax), %edx
	cmpb	$57, %dl
	jbe	.L85
.L87:
	.loc 1 40 7 discriminator 1
	movzbl	(%rax), %eax
	cmpb	$95, %al
	jne	.L88
.L85:
	.loc 1 40 7 is_stmt 0 discriminator 2
	movl	$1, %eax
	jmp	.L89
.L88:
	.loc 1 40 7 discriminator 3
	movl	$0, %eax
.L89:
	.loc 1 36 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE15:
	.size	silver_profile__is_identifier_character___wrapped_statements.5, .-silver_profile__is_identifier_character___wrapped_statements.5
	.section	.rodata
	.align 8
.LC13:
	.ascii	"failed postcondition from silver_profile.ads:22"
	.text
	.align 2
	.globl	silver_profile__is_identifier_character
	.type	silver_profile__is_identifier_character, @function
silver_profile__is_identifier_character:
.LFB14:
	.loc 1 36 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	subq	$32, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	movb	%dil, -33(%rbp)
	.loc 1 36 4
	leaq	16(%rbp), %rax
	.loc 1 36 4 is_stmt 0 discriminator 1
	movq	%rax, -24(%rbp)
	movzbl	-33(%rbp), %eax
	movb	%al, -32(%rbp)
.LBB15:
	leaq	-32(%rbp), %rax
	movq	%rax, %r10
	call	silver_profile__is_identifier_character___wrapped_statements.5
	.loc 2 23 35 is_stmt 1
	movzbl	-32(%rbp), %edx
	.loc 2 26 14
	cmpb	$64, %dl
	jbe	.L92
	.loc 2 23 35 discriminator 1
	movzbl	-32(%rbp), %edx
	cmpb	$90, %dl
	jbe	.L93
.L92:
	.loc 2 24 43
	movzbl	-32(%rbp), %edx
	.loc 2 24 14
	cmpb	$96, %dl
	jbe	.L94
	.loc 2 24 43 discriminator 1
	movzbl	-32(%rbp), %edx
	cmpb	$122, %dl
	jbe	.L93
.L94:
	.loc 2 25 43
	movzbl	-32(%rbp), %edx
	.loc 2 25 14
	cmpb	$47, %dl
	jbe	.L95
	.loc 2 25 43 discriminator 1
	movzbl	-32(%rbp), %edx
	cmpb	$57, %dl
	jbe	.L93
.L95:
	.loc 2 26 14 discriminator 1
	movzbl	-32(%rbp), %edx
	cmpb	$95, %dl
	jne	.L96
.L93:
	.loc 2 26 14 is_stmt 0 discriminator 2
	movl	$1, %edx
	jmp	.L97
.L96:
	.loc 2 26 14 discriminator 3
	movl	$0, %edx
.L97:
	.loc 2 22 19 is_stmt 1
	cmpb	%al, %dl
	je	.L99
.LBB16:
	.loc 2 22 19 is_stmt 0 discriminator 1
	leaq	.LC13(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L99:
.LBE16:
.LBE15:
	.loc 1 36 4 is_stmt 1
	addq	$32, %rsp
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE14:
	.size	silver_profile__is_identifier_character, .-silver_profile__is_identifier_character
	.align 2
	.type	silver_profile__lowercase___wrapped_statements.6, @function
silver_profile__lowercase___wrapped_statements.6:
.LFB17:
	.loc 1 42 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	.loc 1 43 15
	movzbl	(%rax), %edx
	.loc 1 43 7
	cmpb	$64, %dl
	jbe	.L101
	.loc 1 43 15 discriminator 1
	movzbl	(%rax), %edx
	cmpb	$90, %dl
	ja	.L101
	.loc 1 44 48
	movzbl	(%rax), %eax
	movzbl	%al, %eax
	addl	$32, %eax
	cmpl	$255, %eax
	jle	.L103
	.loc 1 44 48 is_stmt 0 discriminator 1
	leaq	.LC7(%rip), %rax
	movl	$44, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L101:
	.loc 1 45 12 is_stmt 1
	movzbl	(%rax), %eax
.L103:
	.loc 1 42 4
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE17:
	.size	silver_profile__lowercase___wrapped_statements.6, .-silver_profile__lowercase___wrapped_statements.6
	.section	.rodata
	.align 8
.LC14:
	.ascii	"failed postcondition from silver_profile.ads:33"
	.text
	.align 2
	.globl	silver_profile__lowercase
	.type	silver_profile__lowercase, @function
silver_profile__lowercase:
.LFB16:
	.loc 1 42 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movb	%dil, -49(%rbp)
	.loc 1 42 4
	leaq	16(%rbp), %rax
	.loc 1 42 4 is_stmt 0 discriminator 1
	movq	%rax, -40(%rbp)
	movzbl	-49(%rbp), %eax
	movb	%al, -48(%rbp)
.LBB17:
	leaq	-48(%rbp), %rax
	movq	%rax, %r10
	call	silver_profile__lowercase___wrapped_statements.6
	movl	%eax, %edi
	.loc 2 33 52 is_stmt 1
	movl	%edi, %eax
	movzbl	%al, %eax
	movq	%rax, %rcx
	movl	$0, %ebx
	.loc 2 34 38
	movzbl	-48(%rbp), %eax
	.loc 2 34 14
	cmpb	$64, %al
	jbe	.L105
	.loc 2 34 38 discriminator 1
	movzbl	-48(%rbp), %eax
	cmpb	$90, %al
	ja	.L105
	.loc 2 35 40
	movzbl	-48(%rbp), %eax
	movzbl	%al, %eax
	leal	32(%rax), %esi
	.loc 2 34 14 discriminator 2
	movslq	%esi, %rax
	cqto
	jmp	.L106
.L105:
	.loc 2 34 14 is_stmt 0 discriminator 3
	movzbl	-48(%rbp), %eax
	movl	%eax, %esi
	movzbl	%sil, %eax
	movq	%rax, %rax
	movl	$0, %edx
.L106:
	.loc 2 33 19 is_stmt 1 discriminator 1
	movq	%rax, %rsi
	xorq	%rcx, %rsi
	movq	%rdx, %rax
	xorq	%rbx, %rax
	orq	%rax, %rsi
	je	.L108
.LBB18:
	.loc 2 33 19 is_stmt 0 discriminator 2
	leaq	.LC14(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L108:
.LBE18:
	.loc 1 42 4 is_stmt 1 discriminator 4
	movl	%edi, %eax
.LBE17:
	.loc 1 42 4 is_stmt 0
	addq	$40, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE16:
	.size	silver_profile__lowercase, .-silver_profile__lowercase
	.align 2
	.type	silver_profile__normalized___wrapped_statements.7, @function
silver_profile__normalized___wrapped_statements.7:
.LFB19:
	.loc 1 47 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rcx
	movq	%r10, -88(%rbp)
	.loc 1 47 4
	movl	12(%rcx), %edx
	movl	8(%rcx), %eax
	cmpl	%eax, %edx
	jl	.L110
	.loc 1 47 4 is_stmt 0 discriminator 1
	movl	12(%rcx), %esi
	movslq	%esi, %rax
	cqto
	movl	8(%rcx), %r8d
	movslq	%r8d, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L111
.L110:
	.loc 1 47 4 discriminator 2
	movl	$0, %eax
	movl	$0, %edx
.L111:
	movq	%rsp, %rsi
	movq	%rsi, %r15
.LBB19:
	.loc 1 55 7 is_stmt 1
	movl	%eax, -52(%rbp)
	movl	-52(%rbp), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	cltq
	movq	%rax, -64(%rbp)
	movl	-52(%rbp), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	movslq	%eax, %r14
	.loc 1 55 54
	movl	-52(%rbp), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	cltq
	movl	12(%rcx), %esi
	movl	8(%rcx), %edx
	cmpl	%edx, %esi
	jl	.L112
	.loc 1 55 54 is_stmt 0 discriminator 1
	movl	12(%rcx), %edx
	movslq	%edx, %rsi
	movl	8(%rcx), %edx
	movslq	%edx, %rdx
	subq	%rdx, %rsi
	movq	%rsi, %rdx
	addq	$1, %rdx
	jmp	.L113
.L112:
	.loc 1 55 54 discriminator 2
	movl	$0, %edx
.L113:
	.loc 1 55 54 discriminator 3
	cmpq	%rax, %rdx
	je	.L114
	.loc 1 55 54 discriminator 4
	leaq	.LC7(%rip), %rax
	movl	$55, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Length_Check@PLT
.L114:
	.loc 1 55 7 is_stmt 1 discriminator 5
	movl	-52(%rbp), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	cltq
	movl	$16, %edx
	subq	$1, %rdx
	addq	%rdx, %rax
	movl	$16, %edi
	movl	$0, %edx
	divq	%rdi
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	movq	%rax, -72(%rbp)
	.loc 1 55 7 is_stmt 0 discriminator 6
	movq	(%rcx), %rax
	movq	(%rax), %rax
	movq	-72(%rbp), %rdx
	movq	%rdx, %rcx
	movq	%r14, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 1 57 7 is_stmt 1
	movl	-52(%rbp), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	cltq
	addq	$11, %rax
	andq	$-4, %rax
	movl	$4, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rbx
	.loc 1 57 7 is_stmt 0 discriminator 1
	movq	%rbx, %rax
	movl	$1, (%rax)
	movl	-52(%rbp), %edx
	movl	%edx, 4(%rax)
	leaq	8(%rax), %rdx
	movq	-72(%rbp), %rax
	movq	%rdx, %rcx
	movq	%r14, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcpy@PLT
	.loc 1 57 7 discriminator 2
	movq	%rbx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rbx, %rax
	movq	%rax, %r13
	.loc 1 58 8 is_stmt 1
	movq	%r15, %rsp
	.loc 1 57 7 discriminator 3
	movq	%r12, %rax
	movq	%r13, %rdx
.LBE19:
	.loc 1 58 8
	leaq	-40(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE19:
	.size	silver_profile__normalized___wrapped_statements.7, .-silver_profile__normalized___wrapped_statements.7
	.section	.rodata
	.align 8
.LC15:
	.ascii	"failed precondition from silver_profile.adb:50"
	.align 8
.LC16:
	.ascii	"failed postcondition from silver_profile.adb:51"
	.align 8
.LC17:
	.ascii	"failed postcondition from silver_profile.adb:52"
	.align 8
.LC18:
	.ascii	"failed postcondition from silver_profile.adb:53"
	.align 8
.LC1:
	.long	1
	.long	46
	.text
	.align 2
	.globl	silver_profile__normalized
	.type	silver_profile__normalized, @function
silver_profile__normalized:
.LFB18:
	.loc 1 47 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rcx
	movq	%rcx, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -96(%rbp)
	movq	%rbx, -88(%rbp)
	.loc 1 47 4
	leaq	16(%rbp), %rsi
	.loc 1 47 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rcx
	movq	%rsi, -64(%rbp)
	movq	%rcx, -80(%rbp)
	movq	-88(%rbp), %rcx
	movl	(%rcx), %ecx
	movl	%ecx, -72(%rbp)
	movq	-88(%rbp), %rcx
	movl	4(%rcx), %ecx
	movl	%ecx, -68(%rbp)
	movl	-68(%rbp), %esi
	movl	-72(%rbp), %ecx
	cmpl	%ecx, %esi
	jl	.L117
	.loc 1 47 4 discriminator 2
	movl	-68(%rbp), %esi
	movslq	%esi, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	movl	-72(%rbp), %r8d
	movslq	%r8d, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rcx
	sbbq	%rdi, %rbx
	addq	$1, %rcx
	adcq	$0, %rbx
	movq	%rcx, -128(%rbp)
	movq	%rbx, -120(%rbp)
	jmp	.L118
.L117:
	.loc 1 47 4 discriminator 3
	movq	$0, -128(%rbp)
	movq	$0, -120(%rbp)
.L118:
.LBB20:
	.loc 1 47 4 discriminator 4
	movl	-68(%rbp), %esi
	movl	-72(%rbp), %ecx
	cmpl	%ecx, %esi
	.loc 1 47 4 discriminator 7
	movl	-68(%rbp), %esi
	movl	-72(%rbp), %ecx
	cmpl	%ecx, %esi
	.loc 1 47 4 discriminator 10
	movl	-68(%rbp), %esi
	movl	-72(%rbp), %ecx
	cmpl	%ecx, %esi
	.loc 1 50 29 is_stmt 1
	movl	-72(%rbp), %ecx
	movslq	%ecx, %rcx
	leaq	4095(%rcx), %rsi
	movl	-68(%rbp), %ecx
	movslq	%ecx, %rcx
	.loc 1 50 15
	cmpq	%rcx, %rsi
	jge	.L125
.LBB21:
	.loc 1 50 15 is_stmt 0 discriminator 1
	leaq	.LC15(%rip), %rax
	leaq	.LC1(%rip), %rdx
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L125:
.LBE21:
.LBB22:
	.loc 1 47 4 is_stmt 1 discriminator 13
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	silver_profile__normalized___wrapped_statements.7
	.loc 1 47 4 is_stmt 0 discriminator 14
	movq	%rax, %rbx
	movq	%rdx, %rsi
	movq	%rbx, -112(%rbp)
	movq	%rsi, -104(%rbp)
	movq	%rsi, %rax
	movl	(%rax), %eax
	movq	%rsi, %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	.loc 1 47 4 discriminator 17
	cmpl	%eax, %edx
	.loc 1 47 4 discriminator 20
	cmpl	%eax, %edx
	jl	.L130
	.loc 1 47 4 discriminator 21
	movslq	%edx, %rsi
	movslq	%eax, %rcx
	subq	%rcx, %rsi
	leaq	1(%rsi), %rcx
	jmp	.L131
.L130:
	.loc 1 47 4 discriminator 22
	movl	$0, %ecx
.L131:
	.loc 1 47 4 discriminator 23
	cmpl	%eax, %edx
	jl	.L132
	.loc 1 47 4 discriminator 24
	testl	%eax, %eax
	jg	.L132
	.loc 1 47 4 discriminator 25
	leaq	.LC7(%rip), %rax
	movl	$47, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L132:
	.loc 1 51 16 is_stmt 1
	cmpl	$1, %eax
	je	.L133
.LBB23:
	.loc 1 51 16 is_stmt 0 discriminator 1
	leaq	.LC16(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L133:
.LBE23:
	.loc 1 52 36 is_stmt 1
	cmpl	%eax, %edx
	jl	.L134
	.loc 1 52 36 is_stmt 0 discriminator 1
	movl	%edx, %esi
	movl	%eax, %edi
	subl	%edi, %esi
	addl	$1, %esi
	movl	%esi, %edi
	jmp	.L135
.L134:
	.loc 1 52 36 discriminator 2
	movl	$0, %edi
.L135:
	.loc 1 52 44 is_stmt 1 discriminator 3
	movl	-128(%rbp), %esi
	.loc 1 51 16 discriminator 2
	cmpl	%esi, %edi
	je	.L136
.LBB24:
	.loc 1 51 16 is_stmt 0 discriminator 3
	leaq	.LC17(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L136:
.LBE24:
	.loc 1 51 16 discriminator 4
	cmpl	%eax, %edx
	jge	.L137
	.loc 1 53 37 is_stmt 1
	movl	-68(%rbp), %edi
	movl	-72(%rbp), %esi
	cmpl	%esi, %edi
	jl	.L138
.L137:
	.loc 1 53 37 is_stmt 0 discriminator 1
	cmpl	%eax, %edx
	jl	.L139
	.loc 1 53 37 discriminator 2
	movslq	%edx, %rdx
	cltq
	subq	%rax, %rdx
	addq	$1, %rdx
	jmp	.L140
.L139:
	.loc 1 53 37 discriminator 3
	movl	$0, %edx
.L140:
	.loc 1 53 37 discriminator 4
	movl	-68(%rbp), %esi
	movl	-72(%rbp), %eax
	cmpl	%eax, %esi
	jl	.L141
	.loc 1 53 37 discriminator 5
	movl	-68(%rbp), %eax
	movslq	%eax, %rsi
	movl	-72(%rbp), %eax
	cltq
	subq	%rax, %rsi
	leaq	1(%rsi), %rax
	jmp	.L142
.L141:
	.loc 1 53 37 discriminator 6
	movl	$0, %eax
.L142:
	.loc 1 53 37 discriminator 7
	cmpq	%rax, %rdx
	jne	.L143
	.loc 1 53 37 discriminator 8
	movq	-96(%rbp), %rax
	movq	-112(%rbp), %rdi
	movq	%rcx, %rdx
	movq	%rax, %rsi
	call	memcmp@PLT
	.loc 1 53 37 discriminator 9
	testl	%eax, %eax
	je	.L138
.L143:
.LBB25:
	.loc 1 51 16 is_stmt 1 discriminator 5
	leaq	.LC18(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L138:
.LBE25:
	.loc 1 47 4 discriminator 26
	movq	-112(%rbp), %rax
	movq	-104(%rbp), %rdx
.LBE22:
.LBE20:
	.loc 1 47 4 is_stmt 0
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE18:
	.size	silver_profile__normalized, .-silver_profile__normalized
	.section	.rodata
	.align 8
.LC19:
	.ascii	"failed precondition from silver_profile.adb:69"
	.align 8
.LC20:
	.ascii	"failed precondition from silver_profile.adb:70"
	.align 8
.LC21:
	.ascii	"failed precondition from silver_profile.adb:71"
	.align 8
.LC22:
	.ascii	"failed postcondition from silver_profile.adb:72"
	.text
	.align 2
	.globl	___ghost_silver_profile__comment_end
	.type	___ghost_silver_profile__comment_end, @function
___ghost_silver_profile__comment_end:
.LFB20:
	.loc 1 75 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -96(%rbp)
	movq	%rbx, -88(%rbp)
	movl	%edx, -100(%rbp)
	.loc 1 75 4
	leaq	16(%rbp), %rdx
	.loc 1 75 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -80(%rbp)
	movl	-100(%rbp), %eax
	movl	%eax, -72(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -104(%rbp)
	movq	-88(%rbp), %rax
	movl	4(%rax), %ebx
	movq	-88(%rbp), %rax
	movl	4(%rax), %edx
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L146
	.loc 1 75 4 discriminator 2
	movq	-88(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-88(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movq	%rcx, %rsi
	movq	%rcx, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L147
.L146:
	.loc 1 75 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L147:
.LBB26:
	.loc 1 69 15 is_stmt 1
	cmpl	$1, -104(%rbp)
	je	.L148
.LBB27:
	.loc 1 69 15 is_stmt 0 discriminator 1
	leaq	.LC19(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L148:
.LBE27:
	.loc 1 70 31 is_stmt 1
	movl	%eax, %ecx
	.loc 1 69 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L149
	.loc 1 70 31 discriminator 1
	cmpl	$4096, %eax
	jle	.L150
.L149:
.LBB28:
	.loc 1 69 15 discriminator 3
	leaq	.LC20(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L150:
.LBE28:
	.loc 1 71 41
	cmpl	$2147483647, %ebx
	jne	.L151
	.loc 1 71 41 is_stmt 0 discriminator 1
	leaq	.LC7(%rip), %rax
	movl	$71, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L151:
	.loc 1 71 41 discriminator 3
	leal	1(%rbx), %edx
	.loc 1 69 15 is_stmt 1 discriminator 4
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L152
.LBB29:
	.loc 1 69 15 is_stmt 0 discriminator 5
	leaq	.LC21(%rip), %r8
	leaq	.LC1(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L152:
.LBE29:
	.loc 1 73 55 is_stmt 1
	cmpl	$2147483647, %ebx
	jne	.L153
	.loc 1 73 55 is_stmt 0 discriminator 1
	leaq	.LC7(%rip), %rax
	movl	$73, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L153:
	.loc 1 73 55 discriminator 3
	leal	1(%rbx), %eax
	.loc 1 73 60 is_stmt 1 discriminator 4
	movl	-72(%rbp), %edx
	movl	$0, %ecx
	subl	%edx, %eax
	jno	.L154
	movl	$1, %ecx
.L154:
	movl	%eax, %edx
	.loc 1 73 60 is_stmt 0 discriminator 5
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L156
	.loc 1 73 60 discriminator 6
	leaq	.LC7(%rip), %rax
	movl	$73, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L156:
	.loc 1 73 60 discriminator 8
	movl	%edx, %eax
	movl	%eax, -68(%rbp)
.LBB30:
	.loc 1 75 4 is_stmt 1 discriminator 5
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	___ghost_silver_profile__comment_end___wrapped_statements
	.loc 1 72 16
	movl	-72(%rbp), %edx
	cmpl	%edx, %eax
	jl	.L157
	.loc 1 72 60 discriminator 1
	cmpl	$2147483647, %ebx
	jne	.L158
	.loc 1 72 60 is_stmt 0 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$72, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L158:
	.loc 1 72 60 discriminator 4
	leal	1(%rbx), %edx
	.loc 1 72 35 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L160
.L157:
.LBB31:
	.loc 1 72 16 discriminator 6
	leaq	.LC22(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L160:
.LBE31:
.LBE30:
.LBE26:
	.loc 1 75 4
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE20:
	.size	___ghost_silver_profile__comment_end, .-___ghost_silver_profile__comment_end
	.align 2
	.type	___ghost_silver_profile__comment_end___wrapped_statements, @function
___ghost_silver_profile__comment_end___wrapped_statements:
.LFB22:
	.loc 1 75 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 3, -24
	movq	%r10, %rbx
	movq	%r10, -24(%rbp)
	.loc 1 75 4
	movq	(%rbx), %rax
	movq	8(%rax), %rax
	movl	(%rax), %ecx
	movq	(%rbx), %rax
	movq	8(%rax), %rax
	movl	4(%rax), %eax
.LBB32:
	.loc 1 76 7
	movl	8(%rbx), %edx
	cmpl	%edx, %eax
	jl	.L162
	.loc 1 77 33
	movl	8(%rbx), %edx
	cmpl	%edx, %ecx
	jg	.L163
	.loc 1 77 33 is_stmt 0 discriminator 1
	movl	8(%rbx), %edx
	cmpl	%edx, %eax
	jge	.L164
.L163:
	.loc 1 77 33 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$77, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L164:
	.loc 1 77 17 is_stmt 1 discriminator 3
	movq	(%rbx), %rax
	movq	(%rax), %rax
	movq	(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	8(%rbx), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_comment_end
	.loc 1 77 9 discriminator 4
	testb	%al, %al
	je	.L165
.L162:
	.loc 1 78 12
	movl	8(%rbx), %eax
	jmp	.L166
.L165:
	.loc 1 79 40
	movl	8(%rbx), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L167
	.loc 1 79 40 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L168
.L167:
	.loc 1 79 40 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$79, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L168:
	.loc 1 79 12 is_stmt 1 discriminator 3
	movq	(%rbx), %rdx
	movq	(%rdx), %rsi
	movq	8(%rdx), %rcx
	movl	%eax, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	___ghost_silver_profile__comment_end
.L166:
.LBE32:
	.loc 1 75 4
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE22:
	.size	___ghost_silver_profile__comment_end___wrapped_statements, .-___ghost_silver_profile__comment_end___wrapped_statements
	.section	.rodata
	.align 8
.LC23:
	.ascii	"failed precondition from silver_profile.adb:85"
	.align 8
.LC24:
	.ascii	"failed precondition from silver_profile.adb:86"
	.align 8
.LC25:
	.ascii	"failed precondition from silver_profile.adb:87"
	.align 8
.LC26:
	.ascii	"failed postcondition from silver_profile.adb:88"
	.text
	.align 2
	.globl	___ghost_silver_profile__trivia_end
	.type	___ghost_silver_profile__trivia_end, @function
___ghost_silver_profile__trivia_end:
.LFB23:
	.loc 1 91 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -96(%rbp)
	movq	%rbx, -88(%rbp)
	movl	%edx, -100(%rbp)
	.loc 1 91 4
	leaq	16(%rbp), %rdx
	.loc 1 91 4 is_stmt 0 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -80(%rbp)
	movl	-100(%rbp), %eax
	movl	%eax, -72(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -104(%rbp)
	movq	-88(%rbp), %rax
	movl	4(%rax), %ebx
	movq	-88(%rbp), %rax
	movl	4(%rax), %edx
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L170
	.loc 1 91 4 discriminator 2
	movq	-88(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-88(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movq	%rcx, %rsi
	movq	%rcx, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L171
.L170:
	.loc 1 91 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L171:
.LBB33:
	.loc 1 85 15 is_stmt 1
	cmpl	$1, -104(%rbp)
	je	.L172
.LBB34:
	.loc 1 85 15 is_stmt 0 discriminator 1
	leaq	.LC23(%rip), %r14
	leaq	.LC1(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L172:
.LBE34:
	.loc 1 86 31 is_stmt 1
	movl	%eax, %ecx
	.loc 1 85 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L173
	.loc 1 86 31 discriminator 1
	cmpl	$4096, %eax
	jle	.L174
.L173:
.LBB35:
	.loc 1 85 15 discriminator 3
	leaq	.LC24(%rip), %r10
	leaq	.LC1(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L174:
.LBE35:
	.loc 1 87 41
	cmpl	$2147483647, %ebx
	jne	.L175
	.loc 1 87 41 is_stmt 0 discriminator 1
	leaq	.LC7(%rip), %rax
	movl	$87, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L175:
	.loc 1 87 41 discriminator 3
	leal	1(%rbx), %edx
	.loc 1 85 15 is_stmt 1 discriminator 4
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L176
.LBB36:
	.loc 1 85 15 is_stmt 0 discriminator 5
	leaq	.LC25(%rip), %r8
	leaq	.LC1(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L176:
.LBE36:
	.loc 1 89 55 is_stmt 1
	cmpl	$2147483647, %ebx
	jne	.L177
	.loc 1 89 55 is_stmt 0 discriminator 1
	leaq	.LC7(%rip), %rax
	movl	$89, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L177:
	.loc 1 89 55 discriminator 3
	leal	1(%rbx), %eax
	.loc 1 89 60 is_stmt 1 discriminator 4
	movl	-72(%rbp), %edx
	movl	$0, %ecx
	subl	%edx, %eax
	jno	.L178
	movl	$1, %ecx
.L178:
	movl	%eax, %edx
	.loc 1 89 60 is_stmt 0 discriminator 5
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L180
	.loc 1 89 60 discriminator 6
	leaq	.LC7(%rip), %rax
	movl	$89, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L180:
	.loc 1 89 60 discriminator 8
	movl	%edx, %eax
	movl	%eax, -68(%rbp)
.LBB37:
	.loc 1 91 4 is_stmt 1 discriminator 5
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
	call	___ghost_silver_profile__trivia_end___wrapped_statements
	.loc 1 88 16
	movl	-72(%rbp), %edx
	cmpl	%edx, %eax
	jl	.L181
	.loc 1 88 59 discriminator 1
	cmpl	$2147483647, %ebx
	jne	.L182
	.loc 1 88 59 is_stmt 0 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$88, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L182:
	.loc 1 88 59 discriminator 4
	leal	1(%rbx), %edx
	.loc 1 88 34 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	jge	.L184
.L181:
.LBB38:
	.loc 1 88 16 discriminator 6
	leaq	.LC26(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L184:
.LBE38:
.LBE37:
.LBE33:
	.loc 1 91 4
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE23:
	.size	___ghost_silver_profile__trivia_end, .-___ghost_silver_profile__trivia_end
	.align 2
	.type	___ghost_silver_profile__trivia_end___wrapped_statements, @function
___ghost_silver_profile__trivia_end___wrapped_statements:
.LFB25:
	.loc 1 91 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$24, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%r10, %rbx
	movq	%r10, -40(%rbp)
	.loc 1 91 4
	movq	(%rbx), %rax
	movq	8(%rax), %rax
	movl	(%rax), %r13d
	movq	(%rbx), %rax
	movq	8(%rax), %rax
	movl	4(%rax), %r12d
.LBB39:
	.loc 1 92 7
	movl	8(%rbx), %eax
	cmpl	%eax, %r12d
	jge	.L186
	.loc 1 92 36 discriminator 1
	movl	8(%rbx), %eax
	jmp	.L187
.L186:
	.loc 1 93 28
	movl	8(%rbx), %eax
	cmpl	%eax, %r13d
	jg	.L188
	.loc 1 93 28 is_stmt 0 discriminator 1
	movl	8(%rbx), %eax
	cmpl	%eax, %r12d
	jge	.L189
.L188:
	.loc 1 93 28 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$93, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L189:
	.loc 1 93 13 is_stmt 1 discriminator 3
	movq	(%rbx), %rax
	movq	(%rax), %rax
	movq	(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	8(%rbx), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_whitespace
	.loc 1 93 7 discriminator 4
	testb	%al, %al
	je	.L190
	.loc 1 94 39
	movl	8(%rbx), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L191
	.loc 1 94 39 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L192
.L191:
	.loc 1 94 39 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$94, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L192:
	.loc 1 94 12 is_stmt 1 discriminator 3
	movq	(%rbx), %rdx
	movq	(%rdx), %rsi
	movq	8(%rdx), %rcx
	movl	%eax, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	___ghost_silver_profile__trivia_end
	.loc 1 94 12 is_stmt 0 discriminator 4
	jmp	.L187
.L190:
	.loc 1 95 13 is_stmt 1
	movl	8(%rbx), %eax
	cmpl	%eax, %r13d
	jg	.L193
	.loc 1 95 13 is_stmt 0 discriminator 1
	movl	8(%rbx), %eax
	cmpl	%eax, %r12d
	jge	.L194
.L193:
	.loc 1 95 13 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$95, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L194:
	.loc 1 95 29 is_stmt 1 discriminator 3
	movq	(%rbx), %rax
	movq	(%rax), %rax
	movq	(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movl	8(%rbx), %ecx
	movslq	%ecx, %rcx
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$45, %al
	sete	%al
	.loc 1 95 7 discriminator 3
	testb	%al, %al
	je	.L195
	.loc 1 96 9
	movl	8(%rbx), %eax
	cmpl	%eax, %r12d
	jle	.L195
	.loc 1 97 33
	movl	8(%rbx), %eax
	addl	$1, %eax
	.loc 1 97 18
	cmpl	%eax, %r13d
	jg	.L196
	.loc 1 97 18 is_stmt 0 discriminator 1
	movl	8(%rbx), %eax
	cmpl	%eax, %r12d
	jg	.L197
.L196:
	.loc 1 97 18 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$97, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L197:
	.loc 1 97 38 is_stmt 1 discriminator 3
	movq	(%rbx), %rax
	movq	(%rax), %rax
	movq	(%rbx), %rdx
	movq	8(%rdx), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 1 97 33 discriminator 3
	movl	8(%rbx), %ecx
	addl	$1, %ecx
	movslq	%ecx, %rcx
	.loc 1 97 38 discriminator 3
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$45, %al
	sete	%al
	.loc 1 97 9 discriminator 3
	testb	%al, %al
	je	.L195
	.loc 1 98 58
	movl	8(%rbx), %eax
	addl	$2, %eax
	testl	%eax, %eax
	jle	.L198
	.loc 1 98 58 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L199
.L198:
	.loc 1 98 58 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$98, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L199:
	.loc 1 98 12 is_stmt 1 discriminator 3
	movq	(%rbx), %rdx
	movq	(%rdx), %rsi
	movq	8(%rdx), %rcx
	movl	%eax, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	___ghost_silver_profile__comment_end
	movl	%eax, %edx
	.loc 1 98 12 is_stmt 0 discriminator 4
	movq	(%rbx), %rax
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	___ghost_silver_profile__trivia_end
	.loc 1 98 12 discriminator 5
	jmp	.L187
.L195:
	.loc 1 99 12 is_stmt 1
	movl	8(%rbx), %eax
.L187:
.LBE39:
	.loc 1 91 4
	addq	$24, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE25:
	.size	___ghost_silver_profile__trivia_end___wrapped_statements, .-___ghost_silver_profile__trivia_end___wrapped_statements
	.section	.rodata
	.align 8
.LC27:
	.ascii	"failed precondition from silver_profile.adb:107"
	.align 8
.LC28:
	.ascii	"failed precondition from silver_profile.adb:108"
	.align 8
.LC29:
	.ascii	"failed precondition from silver_profile.adb:109"
	.align 8
.LC30:
	.ascii	"failed precondition from silver_profile.adb:110"
	.align 8
.LC31:
	.ascii	"failed precondition from silver_profile.adb:111"
	.text
	.align 2
	.globl	___ghost_silver_profile__token_at
	.type	___ghost_silver_profile__token_at, @function
___ghost_silver_profile__token_at:
.LFB26:
	.loc 1 113 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$152, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r10
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r10, %rdi
	movq	%rsi, -80(%rbp)
	movq	%rdi, -72(%rbp)
	movl	%edx, -84(%rbp)
	movq	%rcx, %rax
	movq	%r8, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -112(%rbp)
	movq	%rdx, -104(%rbp)
	movb	%r9b, -85(%rbp)
	.loc 1 113 4
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -92(%rbp)
	movq	-72(%rbp), %rax
	movl	4(%rax), %r14d
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L201
	.loc 1 113 4 is_stmt 0 discriminator 1
	movq	-72(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %r8
	movq	%rdx, %r9
	jmp	.L202
.L201:
	.loc 1 113 4 discriminator 2
	movl	$0, %r8d
	movl	$0, %r9d
.L202:
	.loc 1 113 4 discriminator 3
	movq	-104(%rbp), %rax
	movl	(%rax), %r15d
	movq	-104(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -96(%rbp)
	movq	-104(%rbp), %rax
	movl	4(%rax), %edx
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L203
	.loc 1 113 4 discriminator 4
	movq	-104(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %r12
	movq	%rdx, %r13
	jmp	.L204
.L203:
	.loc 1 113 4 discriminator 5
	movl	$0, %r12d
	movl	$0, %r13d
.L204:
.LBB40:
	.loc 1 107 15 is_stmt 1
	cmpl	$1, -92(%rbp)
	je	.L205
.LBB41:
	.loc 1 107 15 is_stmt 0 discriminator 1
	leaq	.LC27(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L205:
.LBE41:
	.loc 1 108 31 is_stmt 1
	movl	%r8d, %eax
	.loc 1 107 15 discriminator 2
	testl	%eax, %eax
	jle	.L206
	.loc 1 108 31 discriminator 1
	movl	%r8d, %eax
	cmpl	$4096, %eax
	jle	.L207
.L206:
.LBB42:
	.loc 1 107 15 discriminator 3
	leaq	.LC28(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L207:
.LBE42:
	.loc 1 109 41
	cmpl	$2147483647, %r14d
	jne	.L208
	.loc 1 109 41 is_stmt 0 discriminator 1
	leaq	.LC7(%rip), %rax
	movl	$109, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L208:
	.loc 1 109 41 discriminator 3
	leal	1(%r14), %eax
	.loc 1 107 15 is_stmt 1 discriminator 4
	cmpl	-84(%rbp), %eax
	jge	.L209
.LBB43:
	.loc 1 107 15 is_stmt 0 discriminator 5
	leaq	.LC29(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L209:
.LBE43:
	.loc 1 107 15 discriminator 6
	cmpl	$1, %r15d
	je	.L210
.LBB44:
	.loc 1 107 15 discriminator 7
	leaq	.LC30(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L210:
.LBE44:
	.loc 1 111 31 is_stmt 1
	movl	%r12d, %eax
	.loc 1 107 15 discriminator 8
	testl	%eax, %eax
	jle	.L211
	.loc 1 111 31 discriminator 1
	movl	%r12d, %eax
	cmpl	$10, %eax
	jle	.L212
.L211:
.LBB45:
	.loc 1 107 15 discriminator 9
	leaq	.LC31(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L212:
.LBE45:
	.loc 1 117 19
	movl	%r12d, %edx
	.loc 1 117 33
	movl	$0, %eax
	movl	%r14d, %edi
	subl	-84(%rbp), %edi
	jno	.L213
	movl	$1, %eax
.L213:
	.loc 1 117 33 is_stmt 0 discriminator 1
	testl	%eax, %eax
	je	.L215
	.loc 1 117 33 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$117, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L215:
	.loc 1 117 33 discriminator 4
	movl	%r14d, %eax
	subl	-84(%rbp), %eax
	.loc 1 117 45 is_stmt 1 discriminator 6
	cmpl	$2147483647, %eax
	jne	.L218
	.loc 1 117 45 is_stmt 0 discriminator 7
	leaq	.LC7(%rip), %rax
	movl	$117, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L218:
	.loc 1 117 45 discriminator 9
	addl	$1, %eax
	.loc 1 121 7 is_stmt 1
	cmpl	%edx, %eax
	jl	.L219
	.loc 1 119 10
	movl	$1, %ebx
	.loc 1 119 18
	movl	%r15d, -56(%rbp)
	movl	-96(%rbp), %eax
	movl	%eax, -60(%rbp)
	.loc 1 119 10
	movl	-56(%rbp), %eax
	cmpl	-60(%rbp), %eax
	jg	.L220
.LBB46:
	.loc 1 119 18 discriminator 1
	movl	-56(%rbp), %eax
	movl	%eax, -52(%rbp)
.L231:
	.loc 1 120 39
	movl	$0, %ecx
	movl	-84(%rbp), %edx
	movl	-52(%rbp), %eax
	addl	%edx, %eax
	jno	.L221
	movl	$1, %ecx
.L221:
	movl	%eax, %edx
	.loc 1 120 39 is_stmt 0 discriminator 1
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L223
	.loc 1 120 39 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$120, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L223:
	.loc 1 120 39 discriminator 4
	movl	%edx, %eax
	.loc 1 120 48 is_stmt 1 discriminator 5
	cmpl	$-2147483648, %eax
	jne	.L224
	.loc 1 120 48 is_stmt 0 discriminator 6
	leaq	.LC7(%rip), %rax
	movl	$120, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L224:
	.loc 1 120 48 discriminator 8
	subl	$1, %eax
	.loc 1 120 23 is_stmt 1 discriminator 9
	movl	-92(%rbp), %edi
	cmpl	%edi, %eax
	jl	.L225
	.loc 1 120 23 is_stmt 0 discriminator 10
	cmpl	%r14d, %eax
	jle	.L226
.L225:
	.loc 1 120 23 discriminator 11
	leaq	.LC7(%rip), %rax
	movl	$120, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L226:
	.loc 1 120 56 is_stmt 1 discriminator 12
	cmpl	-52(%rbp), %r15d
	jg	.L227
	.loc 1 120 56 is_stmt 0 discriminator 13
	movl	-96(%rbp), %eax
	cmpl	-52(%rbp), %eax
	jge	.L228
.L227:
	.loc 1 120 56 discriminator 14
	leaq	.LC7(%rip), %rax
	movl	$120, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L228:
	.loc 1 120 12 is_stmt 1 discriminator 15
	movq	-80(%rbp), %rax
	movq	-72(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 1 120 39 discriminator 15
	movl	-84(%rbp), %esi
	movl	-52(%rbp), %ecx
	addl	%esi, %ecx
	.loc 1 120 48 discriminator 15
	subl	$1, %ecx
	movslq	%ecx, %rcx
	.loc 1 120 12 discriminator 15
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__lowercase
	.loc 1 120 54 discriminator 16
	movq	-112(%rbp), %rdx
	movq	-104(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movl	-52(%rbp), %esi
	movslq	%esi, %rsi
	subq	%rcx, %rsi
	movzbl	(%rdx,%rsi), %edx
	.loc 1 119 10 discriminator 2
	cmpb	%dl, %al
	je	.L229
	.loc 1 119 10 is_stmt 0 discriminator 3
	movl	$0, %ebx
	jmp	.L220
.L229:
	.loc 1 119 10 discriminator 4
	movl	-52(%rbp), %eax
	cmpl	-60(%rbp), %eax
	je	.L220
	.loc 1 119 10 discriminator 5
	addl	$1, -52(%rbp)
	jmp	.L231
.L220:
.LBE46:
	.loc 1 118 7 is_stmt 1
	testb	%bl, %bl
	je	.L219
	.loc 1 122 10
	movzbl	-85(%rbp), %eax
	xorl	$1, %eax
	.loc 1 121 7 discriminator 1
	testb	%al, %al
	jne	.L232
	.loc 1 123 27
	movl	%r12d, %ecx
	movl	$0, %edx
	movl	-84(%rbp), %eax
	addl	%ecx, %eax
	jno	.L233
	movl	$1, %edx
.L233:
	.loc 1 123 27 is_stmt 0 discriminator 1
	movl	%edx, %eax
	testl	%eax, %eax
	je	.L235
	.loc 1 123 27 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$123, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L235:
	.loc 1 123 27 discriminator 4
	movl	%r12d, %edx
	movl	-84(%rbp), %eax
	addl	%edx, %eax
	.loc 1 123 10 is_stmt 1 discriminator 6
	cmpl	%r14d, %eax
	jg	.L232
	.loc 1 124 62
	movl	%r12d, %ecx
	movl	$0, %edx
	movl	-84(%rbp), %eax
	addl	%ecx, %eax
	jno	.L238
	movl	$1, %edx
.L238:
	.loc 1 124 62 is_stmt 0 discriminator 1
	movl	%edx, %eax
	testl	%eax, %eax
	je	.L240
	.loc 1 124 62 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$124, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L240:
	.loc 1 124 62 discriminator 4
	movl	%r12d, %edx
	movl	-84(%rbp), %eax
	addl	%edx, %eax
	.loc 1 124 47 is_stmt 1 discriminator 6
	movl	-92(%rbp), %ebx
	cmpl	%ebx, %eax
	jl	.L243
	.loc 1 124 47 is_stmt 0 discriminator 7
	cmpl	%r14d, %eax
	jle	.L244
.L243:
	.loc 1 124 47 discriminator 8
	leaq	.LC7(%rip), %rax
	movl	$124, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L244:
	.loc 1 124 22 is_stmt 1 discriminator 9
	movq	-80(%rbp), %rax
	movq	-72(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 1 124 62 discriminator 9
	movl	%r12d, %esi
	movl	-84(%rbp), %ecx
	addl	%esi, %ecx
	movslq	%ecx, %rcx
	.loc 1 124 22 discriminator 9
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_identifier_character
	.loc 1 124 18 discriminator 10
	xorl	$1, %eax
	.loc 1 124 10 discriminator 10
	testb	%al, %al
	je	.L219
.L232:
	.loc 1 121 7 discriminator 2
	movl	$1, %eax
	jmp	.L245
.L219:
	.loc 1 121 7 is_stmt 0 discriminator 3
	movl	$0, %eax
.L245:
.LBE40:
	.loc 1 113 4 is_stmt 1
	addq	$152, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE26:
	.size	___ghost_silver_profile__token_at, .-___ghost_silver_profile__token_at
	.section	.rodata
	.align 8
.LC32:
	.ascii	"failed precondition from silver_profile.adb:134"
	.align 8
.LC33:
	.ascii	"failed precondition from silver_profile.adb:135"
	.align 8
.LC34:
	.ascii	"failed precondition from silver_profile.adb:136"
	.text
	.align 2
	.globl	___ghost_silver_profile__suffix_matches
	.type	___ghost_silver_profile__suffix_matches, @function
___ghost_silver_profile__suffix_matches:
.LFB27:
	.loc 1 139 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA27
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB0:
	subq	$104, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %rbx
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%rbx, %rdi
	movq	%rsi, -112(%rbp)
	movq	%rdi, -104(%rbp)
	movl	%edx, -116(%rbp)
	movl	%ecx, -120(%rbp)
	.loc 1 139 4
	leaq	16(%rbp), %rax
	.loc 1 139 4 is_stmt 0 discriminator 1
	movq	%rax, -64(%rbp)
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -124(%rbp)
	movq	-104(%rbp), %rax
	movl	4(%rax), %ebx
	movq	-104(%rbp), %rax
	movl	4(%rax), %edx
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L248
	.loc 1 139 4 discriminator 2
	movq	-104(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-104(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movq	%rcx, %rsi
	movq	%rcx, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L249
.L248:
	.loc 1 139 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L249:
.LBB47:
	.loc 1 134 15 is_stmt 1
	cmpl	$1, -124(%rbp)
	je	.L250
.LBB48:
	.loc 1 134 15 is_stmt 0 discriminator 1
	leaq	.LC32(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L250:
.LBE48:
	.loc 1 135 31 is_stmt 1
	movl	%eax, %ecx
	.loc 1 134 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L251
	.loc 1 135 31 discriminator 1
	cmpl	$4096, %eax
	jle	.L252
.L251:
.LBB49:
	.loc 1 134 15 discriminator 3
	leaq	.LC33(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L252:
.LBE49:
	.loc 1 136 41
	cmpl	$2147483647, %ebx
	jne	.L253
	.loc 1 136 41 is_stmt 0 discriminator 1
	leaq	.LC7(%rip), %rax
	movl	$136, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L253:
	.loc 1 136 41 discriminator 3
	leal	1(%rbx), %eax
	.loc 1 134 15 is_stmt 1 discriminator 4
	cmpl	-116(%rbp), %eax
	jge	.L254
.LBB50:
	.loc 1 134 15 is_stmt 0 discriminator 5
	leaq	.LC34(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.LEHE0:
.L254:
.LBE50:
	.loc 1 137 44 is_stmt 1
	movl	-120(%rbp), %eax
	movl	%eax, -72(%rbp)
	leaq	-96(%rbp), %rax
	movq	%rax, %rdi
.LEHB1:
	call	system__secondary_stack__ss_mark@PLT
.LBB51:
	.loc 1 143 7
	cmpl	$15, -120(%rbp)
	jle	.L255
	.loc 1 144 12
	movl	-116(%rbp), %edx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	___ghost_silver_profile__trivia_end
	.loc 1 144 52 discriminator 1
	cmpl	$2147483647, %ebx
	jne	.L256
	.loc 1 144 52 is_stmt 0 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$144, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L256:
	.loc 1 144 52 discriminator 4
	leal	1(%rbx), %edx
	.loc 1 144 40 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	sete	%r14b
	movl	$0, %ebx
	jmp	.L257
.L255:
	.loc 1 148 22
	cmpl	$0, -120(%rbp)
	jle	.L258
	.loc 1 148 22 is_stmt 0 discriminator 1
	cmpl	$15, -120(%rbp)
	jle	.L259
.L258:
	.loc 1 148 22 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$148, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L259:
	.loc 1 149 27 is_stmt 1
	cmpl	$0, -120(%rbp)
	jle	.L260
	.loc 1 149 27 is_stmt 0 discriminator 1
	cmpl	$15, -120(%rbp)
	jle	.L261
.L260:
	.loc 1 149 27 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$149, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L261:
	.loc 1 146 9 is_stmt 1
	movl	-120(%rbp), %eax
	cltq
	leaq	-1+silver_profile__required_tokens(%rip), %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 146 9 is_stmt 0 discriminator 1
	movzbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_word_token
	movl	%eax, %ebx
	.loc 1 148 12 is_stmt 1 discriminator 3
	movl	-120(%rbp), %eax
	cltq
	leaq	-1+silver_profile__required_tokens(%rip), %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 148 12 is_stmt 0 discriminator 4
	movzbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__spelling
	movq	%rax, %r12
	movq	%rdx, %r13
	.loc 1 146 9 is_stmt 1 discriminator 3
	movl	-116(%rbp), %edx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	___ghost_silver_profile__trivia_end
	movl	%eax, %edx
	.loc 1 146 9 is_stmt 0 discriminator 4
	movzbl	%bl, %ecx
	movq	%r12, %rdi
	movq	%r13, %r8
	movq	-112(%rbp), %rsi
	movq	-104(%rbp), %rax
	movl	%ecx, %r9d
	movq	%rdi, %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	___ghost_silver_profile__token_at
	.loc 1 150 9 is_stmt 1
	testb	%al, %al
	je	.L262
	.loc 1 153 26
	cmpl	$0, -120(%rbp)
	jle	.L263
	.loc 1 153 26 is_stmt 0 discriminator 1
	cmpl	$15, -120(%rbp)
	jle	.L264
.L263:
	.loc 1 153 26 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$153, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L264:
	.loc 1 152 12 is_stmt 1
	movl	-116(%rbp), %edx
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	___ghost_silver_profile__trivia_end
	movl	%eax, %ebx
	.loc 1 153 16 discriminator 3
	movl	-120(%rbp), %eax
	cltq
	leaq	-1+silver_profile__required_tokens(%rip), %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 153 16 is_stmt 0 discriminator 4
	movzbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__spelling
	.loc 1 153 55 is_stmt 1 discriminator 5
	movq	%rdx, %rcx
	movl	4(%rcx), %esi
	movq	%rdx, %rcx
	movl	(%rcx), %ecx
	cmpl	%ecx, %esi
	jl	.L265
	.loc 1 153 55 is_stmt 0 discriminator 6
	movq	%rdx, %rcx
	movl	4(%rcx), %ecx
	movq	%rdx, %rax
	movl	(%rax), %eax
	movl	%eax, %edx
	movl	%ecx, %eax
	subl	%edx, %eax
	addl	$1, %eax
	jmp	.L266
.L265:
	.loc 1 153 55 discriminator 7
	movl	$0, %eax
.L266:
	.loc 1 153 14 is_stmt 1 discriminator 8
	movl	$0, %edx
	addl	%ebx, %eax
	jno	.L267
	movl	$1, %edx
.L267:
	movl	%eax, %ecx
	.loc 1 153 14 is_stmt 0 discriminator 9
	movl	%edx, %eax
	testl	%eax, %eax
	je	.L269
	.loc 1 153 14 discriminator 10
	leaq	.LC7(%rip), %rax
	movl	$153, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L269:
	.loc 1 153 14 discriminator 12
	movl	%ecx, %edx
	.loc 1 153 14 discriminator 13
	testl	%edx, %edx
	jle	.L270
	.loc 1 153 14 discriminator 14
	cmpl	$4097, %edx
	jle	.L271
.L270:
	.loc 1 153 14 discriminator 15
	leaq	.LC7(%rip), %rax
	movl	$153, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L271:
	.loc 1 154 23 is_stmt 1
	movl	-120(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L272
	.loc 1 154 23 is_stmt 0 discriminator 1
	cmpl	$16, %eax
	jle	.L273
.L272:
	.loc 1 154 23 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$154, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L273:
	.loc 1 150 18 is_stmt 1 discriminator 1
	movq	-112(%rbp), %rdi
	movq	-104(%rbp), %rsi
	movl	%eax, %ecx
	call	___ghost_silver_profile__suffix_matches
.LEHE1:
	.loc 1 150 9 discriminator 2
	testb	%al, %al
	je	.L262
	.loc 1 150 9 is_stmt 0 discriminator 3
	movl	$1, %r14d
	jmp	.L274
.L262:
	.loc 1 150 9 discriminator 4
	movl	$0, %r14d
.L274:
	.loc 1 150 9 discriminator 5
	movl	$0, %ebx
.L257:
	.loc 1 143 0 is_stmt 1 discriminator 1
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
.LEHB2:
	call	silver_profile__suffix_matches__B166b___finalizer.8
.LEHE2:
	.loc 1 143 0 is_stmt 0 discriminator 2
	cmpl	$1, %ebx
	je	.L275
	movl	$0, %eax
.L280:
	.loc 1 143 0 discriminator 3
	cmpl	$1, %eax
	je	.L276
.LBE51:
.LBE47:
	.loc 1 139 4 is_stmt 1
	movl	%r14d, %eax
	jmp	.L283
.L281:
	movq	%rax, -136(%rbp)
	movl	$1, %ebx
.LBB53:
.LBB52:
	.loc 1 143 7 discriminator 4
	jmp	.L257
.L275:
	movq	-136(%rbp), %r15
	jmp	.L279
.L282:
	movq	%rax, %r15
.L279:
	movl	$1, %eax
	jmp	.L280
.L276:
	movq	%r15, %rax
	movq	%rax, %rdi
.LEHB3:
	call	_Unwind_Resume@PLT
.L283:
.LBE52:
.LBE53:
	.loc 1 139 4
	addq	$104, %rsp
.LEHE3:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE27:
	.section	.gcc_except_table,"a",@progbits
.LLSDA27:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE27-.LLSDACSB27
.LLSDACSB27:
	.uleb128 .LEHB0-.LFB27
	.uleb128 .LEHE0-.LEHB0
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB1-.LFB27
	.uleb128 .LEHE1-.LEHB1
	.uleb128 .L281-.LFB27
	.uleb128 0
	.uleb128 .LEHB2-.LFB27
	.uleb128 .LEHE2-.LEHB2
	.uleb128 .L282-.LFB27
	.uleb128 0
	.uleb128 .LEHB3-.LFB27
	.uleb128 .LEHE3-.LEHB3
	.uleb128 0
	.uleb128 0
.LLSDACSE27:
	.text
	.size	___ghost_silver_profile__suffix_matches, .-___ghost_silver_profile__suffix_matches
	.align 2
	.type	silver_profile__suffix_matches__B166b___finalizer.8, @function
silver_profile__suffix_matches__B166b___finalizer.8:
.LFB29:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE29:
	.size	silver_profile__suffix_matches__B166b___finalizer.8, .-silver_profile__suffix_matches__B166b___finalizer.8
	.align 2
	.type	silver_profile__is_member__B176b___finalizer.9, @function
silver_profile__is_member__B176b___finalizer.9:
.LFB31:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE31:
	.size	silver_profile__is_member__B176b___finalizer.9, .-silver_profile__is_member__B176b___finalizer.9
	.align 2
	.globl	___ghost_silver_profile__is_member
	.type	___ghost_silver_profile__is_member, @function
___ghost_silver_profile__is_member:
.LFB30:
	.loc 1 156 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA30
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB4:
	subq	$72, %rsp
.LEHE4:
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -96(%rbp)
	movq	%rdx, -88(%rbp)
	.loc 1 156 4
	leaq	16(%rbp), %rax
	.loc 1 156 4 is_stmt 0 discriminator 1
	movq	%rax, -56(%rbp)
	movq	-88(%rbp), %rax
	movl	4(%rax), %edx
	movq	-88(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L289
	.loc 1 156 4 discriminator 2
	movq	-88(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-88(%rbp), %rcx
	movl	(%rcx), %esi
	movslq	%esi, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %r12
	movq	%rdx, %r13
	jmp	.L290
.L289:
	.loc 1 156 4 discriminator 3
	movl	$0, %r12d
	movl	$0, %r13d
.L290:
	leaq	-80(%rbp), %rax
	movq	%rax, %rdi
.LEHB5:
	call	system__secondary_stack__ss_mark@PLT
.LBB54:
	.loc 1 157 21 is_stmt 1
	movl	%r12d, %eax
	.loc 1 159 7
	testl	%eax, %eax
	jle	.L291
	.loc 1 157 21 discriminator 1
	movl	%r12d, %eax
	cmpl	$4096, %eax
	jg	.L291
	.loc 1 158 32
	movq	-96(%rbp), %rdx
	movq	-88(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_profile__normalized
	.loc 1 158 16 discriminator 1
	movq	%rax, %rcx
	movq	%rdx, %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_profile__allowed_source
	.loc 1 158 7 discriminator 2
	testb	%al, %al
	je	.L291
	.loc 1 159 32 discriminator 1
	movq	-96(%rbp), %rdx
	movq	-88(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_profile__normalized
	.loc 1 159 16 discriminator 2
	movq	%rax, %rsi
	movq	%rdx, %rax
	movl	$1, %ecx
	movl	$1, %edx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	___ghost_silver_profile__suffix_matches
.LEHE5:
	.loc 1 159 7 discriminator 3
	testb	%al, %al
	je	.L291
	.loc 1 159 7 is_stmt 0 discriminator 4
	movb	$1, -97(%rbp)
	jmp	.L292
.L291:
	.loc 1 159 7 discriminator 5
	movb	$0, -97(%rbp)
.L292:
	.loc 1 159 7 discriminator 6
	movl	$0, %ebx
.L297:
	.loc 1 159 0 is_stmt 1 discriminator 7
	leaq	-80(%rbp), %rax
	movq	%rax, %r10
.LEHB6:
	call	silver_profile__is_member__B176b___finalizer.9
.LEHE6:
	.loc 1 159 0 is_stmt 0 discriminator 8
	cmpl	$1, %ebx
	je	.L293
	movl	$0, %eax
.L299:
	.loc 1 159 0 discriminator 9
	cmpl	$1, %eax
	je	.L294
	.loc 1 159 7 is_stmt 1 discriminator 10
	movzbl	-97(%rbp), %eax
	jmp	.L302
.L300:
	movq	%rax, %r15
	movl	$1, %ebx
	.loc 1 159 7 is_stmt 0 discriminator 11
	jmp	.L297
.L293:
	movq	%r15, %r14
	jmp	.L298
.L301:
	movq	%rax, %r14
.L298:
	movl	$1, %eax
	jmp	.L299
.L294:
	movq	%r14, %rax
	movq	%rax, %rdi
.LEHB7:
	call	_Unwind_Resume@PLT
.L302:
.LBE54:
	.loc 1 156 4 is_stmt 1
	addq	$72, %rsp
.LEHE7:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE30:
	.section	.gcc_except_table
.LLSDA30:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE30-.LLSDACSB30
.LLSDACSB30:
	.uleb128 .LEHB4-.LFB30
	.uleb128 .LEHE4-.LEHB4
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB5-.LFB30
	.uleb128 .LEHE5-.LEHB5
	.uleb128 .L300-.LFB30
	.uleb128 0
	.uleb128 .LEHB6-.LFB30
	.uleb128 .LEHE6-.LEHB6
	.uleb128 .L301-.LFB30
	.uleb128 0
	.uleb128 .LEHB7-.LFB30
	.uleb128 .LEHE7-.LEHB7
	.uleb128 0
	.uleb128 0
.LLSDACSE30:
	.text
	.size	___ghost_silver_profile__is_member, .-___ghost_silver_profile__is_member
	.section	.rodata
	.align 8
.LC35:
	.ascii	"Loop_Invariant failed at silver_profile.adb:176"
	.align 8
.LC36:
	.ascii	"Loop_Invariant failed at silver_profile.adb:178"
	.align 8
.LC37:
	.ascii	"Loop_Variant failed at silver_profile.adb:179"
	.align 8
.LC5:
	.long	1
	.long	45
	.text
	.align 2
	.type	silver_profile__skip_comment___wrapped_statements.10, @function
silver_profile__skip_comment___wrapped_statements.10:
.LFB33:
	.loc 1 161 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -72(%rbp)
	.loc 1 161 4
	movl	24(%rbx), %eax
	movl	%eax, -112(%rbp)
	movl	20(%rbx), %eax
	movl	%eax, -80(%rbp)
.LBB55:
	.loc 1 170 7
	movl	16(%rbx), %eax
	movl	%eax, -52(%rbp)
	.loc 1 174 7
	movb	$0, -73(%rbp)
.L316:
	.loc 1 172 7
	movl	16(%rbx), %eax
	movl	-80(%rbp), %esi
	cmpl	%eax, %esi
	jl	.L317
	.loc 1 173 38
	movl	16(%rbx), %eax
	cmpl	%eax, -112(%rbp)
	jg	.L305
	.loc 1 173 38 is_stmt 0 discriminator 1
	movl	16(%rbx), %eax
	cmpl	%eax, %esi
	jge	.L306
.L305:
	.loc 1 173 38 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$173, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L306:
	.loc 1 173 22 is_stmt 1 discriminator 3
	movq	8(%rbx), %rax
	movq	(%rax), %rdx
	movl	16(%rbx), %eax
	cltq
	movq	(%rbx), %rcx
	subq	%rcx, %rax
	movzbl	(%rdx,%rax), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_comment_end
	.loc 1 173 18 discriminator 4
	xorl	$1, %eax
	.loc 1 173 9 discriminator 4
	testb	%al, %al
	je	.L317
.LBB56:
	.loc 1 176 13
	movl	16(%rbx), %eax
	cmpl	-52(%rbp), %eax
	jl	.L307
	.loc 1 176 55 discriminator 1
	cmpl	$2147483647, -80(%rbp)
	jne	.L308
	.loc 1 176 55 is_stmt 0 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$176, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L308:
	.loc 1 176 55 discriminator 4
	movl	-80(%rbp), %eax
	leal	1(%rax), %edx
	.loc 1 176 22 is_stmt 1 discriminator 5
	movl	16(%rbx), %eax
	cmpl	%eax, %edx
	jge	.L309
.L307:
.LBB57:
	.loc 1 176 13 discriminator 6
	leaq	.LC35(%rip), %rax
	movq	%rax, -96(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -88(%rbp)
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L309:
.LBE57:
	.loc 1 178 13
	movq	8(%rbx), %rax
	movl	-52(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	___ghost_silver_profile__comment_end
	movl	%eax, -100(%rbp)
	.loc 1 178 52 discriminator 1
	movq	8(%rbx), %rax
	movl	16(%rbx), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	___ghost_silver_profile__comment_end
	.loc 1 178 13 discriminator 2
	cmpl	%eax, -100(%rbp)
	je	.L310
.LBB58:
	.loc 1 178 13 is_stmt 0 discriminator 3
	leaq	.LC36(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L310:
.LBE58:
	.loc 1 179 10 is_stmt 1
	cmpb	$0, -73(%rbp)
	je	.L311
	.loc 1 179 44 discriminator 1
	movl	-104(%rbp), %eax
	movl	%eax, -108(%rbp)
.L311:
	.loc 1 179 44 is_stmt 0 discriminator 2
	movl	16(%rbx), %eax
	movl	%eax, -104(%rbp)
	.loc 1 179 10 is_stmt 1 discriminator 2
	cmpb	$0, -73(%rbp)
	je	.L312
	.loc 1 179 44 discriminator 3
	movl	-108(%rbp), %edi
	cmpl	%edi, %eax
	jg	.L313
.LBB59:
	.loc 1 179 44 is_stmt 0 discriminator 4
	leaq	.LC37(%rip), %r12
	leaq	.LC5(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L312:
.LBE59:
	.loc 1 179 10 is_stmt 1 discriminator 5
	movb	$1, -73(%rbp)
.L313:
	.loc 1 180 31
	movl	16(%rbx), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L314
	.loc 1 180 31 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L315
.L314:
	.loc 1 180 31 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$180, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L315:
	.loc 1 180 19 is_stmt 1 discriminator 3
	movl	%eax, 16(%rbx)
.LBE56:
	.loc 1 181 15
	jmp	.L316
.L317:
	.loc 1 182 8 discriminator 1
	nop
.LBE55:
	.loc 1 182 8 is_stmt 0
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE33:
	.size	silver_profile__skip_comment___wrapped_statements.10, .-silver_profile__skip_comment___wrapped_statements.10
	.section	.rodata
	.align 8
.LC38:
	.ascii	"failed precondition from silver_profile.adb:164"
	.align 8
.LC39:
	.ascii	"failed precondition from silver_profile.adb:165"
	.align 8
.LC40:
	.ascii	"failed precondition from silver_profile.adb:166"
	.align 8
.LC41:
	.ascii	"failed postcondition from silver_profile.adb:167"
	.align 8
.LC42:
	.ascii	"failed postcondition from silver_profile.adb:168"
	.align 8
.LC4:
	.long	1
	.long	48
	.text
	.align 2
	.type	silver_profile__skip_comment, @function
silver_profile__skip_comment:
.LFB32:
	.loc 1 161 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$88, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, -128(%rbp)
	movq	%rax, %rsi
	movl	$0, %edi
	movq	-128(%rbp), %rdi
	movq	%rsi, -112(%rbp)
	movq	%rdi, -104(%rbp)
	movl	%edx, -116(%rbp)
	.loc 1 161 4
	leaq	16(%rbp), %rdx
	.loc 1 161 4 is_stmt 0 discriminator 1
	leaq	-112(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -88(%rbp)
	movl	-116(%rbp), %eax
	movl	%eax, -80(%rbp)
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -72(%rbp)
	movq	-104(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -76(%rbp)
	movl	-76(%rbp), %edx
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jl	.L319
	.loc 1 161 4 discriminator 2
	movl	-76(%rbp), %esi
	movslq	%esi, %rax
	cqto
	movl	-72(%rbp), %edi
	movl	%edi, -128(%rbp)
	movslq	-128(%rbp), %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L320
.L319:
	.loc 1 161 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L320:
.LBB60:
	.loc 1 161 4 discriminator 4
	movl	-72(%rbp), %esi
	movslq	%esi, %rsi
	movq	%rsi, -96(%rbp)
	movl	-76(%rbp), %edi
	movl	-72(%rbp), %esi
	cmpl	%esi, %edi
	.loc 1 161 4 discriminator 7
	movl	-76(%rbp), %edi
	movl	-72(%rbp), %esi
	cmpl	%esi, %edi
	.loc 1 161 4 discriminator 10
	movl	-76(%rbp), %edi
	movl	-72(%rbp), %esi
	cmpl	%esi, %edi
	.loc 1 164 15 is_stmt 1
	movl	-72(%rbp), %esi
	cmpl	$1, %esi
	je	.L327
.LBB61:
	.loc 1 164 15 is_stmt 0 discriminator 1
	leaq	.LC38(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L327:
.LBE61:
	.loc 1 165 31 is_stmt 1
	movl	%eax, %esi
	.loc 1 164 15 discriminator 2
	testl	%esi, %esi
	jle	.L328
	.loc 1 165 31 discriminator 1
	cmpl	$4096, %eax
	jle	.L329
.L328:
.LBB62:
	.loc 1 164 15 discriminator 3
	leaq	.LC39(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L329:
.LBE62:
	.loc 1 166 41
	movl	-76(%rbp), %eax
	cmpl	$2147483647, %eax
	jne	.L330
	.loc 1 166 41 is_stmt 0 discriminator 1
	leaq	.LC7(%rip), %rax
	movl	$166, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L330:
	.loc 1 166 41 discriminator 3
	movl	-76(%rbp), %eax
	leal	1(%rax), %edx
	.loc 1 164 15 is_stmt 1 discriminator 4
	movl	-80(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L331
.LBB63:
	.loc 1 164 15 is_stmt 0 discriminator 5
	leaq	.LC40(%rip), %rcx
	leaq	.LC0(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L331:
.LBE63:
	.loc 1 167 36 is_stmt 1
	movl	-80(%rbp), %eax
	movl	%eax, -128(%rbp)
	.loc 1 168 57
	movl	-80(%rbp), %ebx
	.loc 1 161 4 discriminator 13
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
	call	silver_profile__skip_comment___wrapped_statements.10
	.loc 1 167 16 discriminator 1
	movl	-80(%rbp), %eax
	movl	-128(%rbp), %ecx
	cmpl	%ecx, %eax
	jl	.L332
	.loc 1 167 54 discriminator 2
	movl	-76(%rbp), %eax
	cmpl	$2147483647, %eax
	jne	.L333
	.loc 1 167 54 is_stmt 0 discriminator 3
	leaq	.LC7(%rip), %rax
	movl	$167, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L333:
	.loc 1 167 54 discriminator 5
	movl	-76(%rbp), %eax
	leal	1(%rax), %edx
	.loc 1 167 25 is_stmt 1 discriminator 6
	movl	-80(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L334
.L332:
.LBB64:
	.loc 1 167 16 discriminator 7
	leaq	.LC41(%rip), %r14
	leaq	.LC4(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L334:
.LBE64:
	.loc 1 168 30 discriminator 1
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movl	%ebx, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	___ghost_silver_profile__comment_end
	.loc 1 168 28 discriminator 2
	movl	-80(%rbp), %edx
	cmpl	%eax, %edx
	sete	%al
	xorl	$1, %eax
	.loc 1 167 16 discriminator 8
	testb	%al, %al
	je	.L338
.LBB65:
	.loc 1 167 16 is_stmt 0 discriminator 9
	leaq	.LC42(%rip), %r12
	leaq	.LC4(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L338:
.LBE65:
	.loc 1 161 4 is_stmt 1 discriminator 14
	nop
.LBE60:
	.loc 1 161 4 is_stmt 0 discriminator 15
	movl	-80(%rbp), %eax
	.loc 1 161 4
	addq	$88, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE32:
	.size	silver_profile__skip_comment, .-silver_profile__skip_comment
	.section	.rodata
	.align 8
.LC43:
	.ascii	"Loop_Invariant failed at silver_profile.adb:197"
	.align 8
.LC44:
	.ascii	"Loop_Invariant failed at silver_profile.adb:199"
	.align 8
.LC45:
	.ascii	"Loop_Variant failed at silver_profile.adb:200"
	.text
	.align 2
	.type	silver_profile__skip_trivia___wrapped_statements.11, @function
silver_profile__skip_trivia___wrapped_statements.11:
.LFB35:
	.loc 1 184 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$88, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -72(%rbp)
	.loc 1 184 4
	movl	24(%rbx), %eax
	movl	%eax, -80(%rbp)
	movl	20(%rbx), %r12d
.LBB66:
	.loc 1 193 7
	movl	16(%rbx), %eax
	movl	%eax, -52(%rbp)
	.loc 1 195 35
	movb	$0, -73(%rbp)
.L362:
	.loc 1 195 7 discriminator 1
	movl	16(%rbx), %eax
	cmpl	%eax, %r12d
	jl	.L363
.LBB67:
	.loc 1 197 13
	movl	16(%rbx), %eax
	cmpl	-52(%rbp), %eax
	jl	.L341
	.loc 1 197 55 discriminator 1
	cmpl	$2147483647, %r12d
	jne	.L342
	.loc 1 197 55 is_stmt 0 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$197, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L342:
	.loc 1 197 55 discriminator 4
	leal	1(%r12), %edx
	.loc 1 197 22 is_stmt 1 discriminator 5
	movl	16(%rbx), %eax
	cmpl	%eax, %edx
	jge	.L343
.L341:
.LBB68:
	.loc 1 197 13 discriminator 6
	leaq	.LC43(%rip), %rax
	movq	%rax, -112(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -104(%rbp)
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L343:
.LBE68:
	.loc 1 199 13
	movq	8(%rbx), %rax
	movl	-52(%rbp), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	___ghost_silver_profile__trivia_end
	movl	%eax, %r13d
	.loc 1 199 51 discriminator 1
	movq	8(%rbx), %rax
	movl	16(%rbx), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	___ghost_silver_profile__trivia_end
	.loc 1 199 13 discriminator 2
	cmpl	%eax, %r13d
	je	.L344
.LBB69:
	.loc 1 199 13 is_stmt 0 discriminator 3
	leaq	.LC44(%rip), %rax
	movq	%rax, -96(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -88(%rbp)
	movq	-96(%rbp), %rsi
	movq	-88(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L344:
.LBE69:
	.loc 1 200 10 is_stmt 1
	cmpb	$0, -73(%rbp)
	je	.L345
	.loc 1 200 44 discriminator 1
	movl	-116(%rbp), %eax
	movl	%eax, -120(%rbp)
.L345:
	.loc 1 200 44 is_stmt 0 discriminator 2
	movl	16(%rbx), %eax
	movl	%eax, -116(%rbp)
	.loc 1 200 10 is_stmt 1 discriminator 2
	cmpb	$0, -73(%rbp)
	je	.L346
	.loc 1 200 44 discriminator 3
	movl	-120(%rbp), %esi
	cmpl	%esi, %eax
	jg	.L347
.LBB70:
	.loc 1 200 44 is_stmt 0 discriminator 4
	leaq	.LC45(%rip), %r14
	leaq	.LC5(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L346:
.LBE70:
	.loc 1 200 10 is_stmt 1 discriminator 5
	movb	$1, -73(%rbp)
.L347:
	.loc 1 202 28
	movl	16(%rbx), %eax
	cmpl	%eax, -80(%rbp)
	jg	.L348
	.loc 1 202 28 is_stmt 0 discriminator 1
	movl	16(%rbx), %eax
	cmpl	%eax, %r12d
	jge	.L349
.L348:
	.loc 1 202 28 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$202, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L349:
	.loc 1 202 13 is_stmt 1 discriminator 3
	movq	8(%rbx), %rax
	movq	(%rax), %rdx
	movl	16(%rbx), %eax
	cltq
	movq	(%rbx), %rcx
	subq	%rcx, %rax
	movzbl	(%rdx,%rax), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_whitespace
	.loc 1 202 10 discriminator 4
	testb	%al, %al
	je	.L350
	.loc 1 203 34
	movl	16(%rbx), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L351
	.loc 1 203 34 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L352
.L351:
	.loc 1 203 34 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$203, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L352:
	.loc 1 203 22 is_stmt 1 discriminator 3
	movl	%eax, 16(%rbx)
	jmp	.L362
.L350:
	.loc 1 204 16
	movl	16(%rbx), %eax
	cmpl	%eax, -80(%rbp)
	jg	.L354
	.loc 1 204 16 is_stmt 0 discriminator 1
	movl	16(%rbx), %eax
	cmpl	%eax, %r12d
	jge	.L355
.L354:
	.loc 1 204 16 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$204, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L355:
	.loc 1 204 32 is_stmt 1 discriminator 3
	movq	8(%rbx), %rax
	movq	(%rax), %rdx
	movl	16(%rbx), %eax
	cltq
	movq	(%rbx), %rcx
	subq	%rcx, %rax
	movzbl	(%rdx,%rax), %eax
	cmpb	$45, %al
	sete	%al
	.loc 1 204 10 discriminator 3
	testb	%al, %al
	je	.L364
	.loc 1 205 12
	movl	16(%rbx), %eax
	cmpl	%eax, %r12d
	jle	.L364
	.loc 1 206 36
	movl	16(%rbx), %eax
	addl	$1, %eax
	.loc 1 206 21
	cmpl	%eax, -80(%rbp)
	jg	.L357
	.loc 1 206 21 is_stmt 0 discriminator 1
	cmpl	%eax, %r12d
	jge	.L358
.L357:
	.loc 1 206 21 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$206, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L358:
	.loc 1 206 41 is_stmt 1 discriminator 3
	movq	8(%rbx), %rdx
	movq	(%rdx), %rdx
	cltq
	movq	(%rbx), %rcx
	subq	%rcx, %rax
	movzbl	(%rdx,%rax), %eax
	cmpb	$45, %al
	sete	%al
	.loc 1 206 12 discriminator 3
	testb	%al, %al
	je	.L364
	.loc 1 208 34
	movl	16(%rbx), %eax
	addl	$2, %eax
	testl	%eax, %eax
	jle	.L359
	.loc 1 208 34 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L360
.L359:
	.loc 1 208 34 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$208, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L360:
	.loc 1 208 22 is_stmt 1 discriminator 3
	movl	%eax, 16(%rbx)
	.loc 1 209 13
	movq	8(%rbx), %rax
	movl	16(%rbx), %edx
	movq	(%rax), %rcx
	movq	8(%rax), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_profile__skip_comment
	.loc 1 209 13 is_stmt 0 discriminator 1
	movl	%eax, 16(%rbx)
.LBE67:
	.loc 1 213 15 is_stmt 1
	jmp	.L362
.L363:
	.loc 1 214 8
	nop
	jmp	.L339
.L364:
.LBB71:
	.loc 1 211 13
	nop
.L339:
.LBE71:
.LBE66:
	.loc 1 214 8
	addq	$88, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE35:
	.size	silver_profile__skip_trivia___wrapped_statements.11, .-silver_profile__skip_trivia___wrapped_statements.11
	.section	.rodata
	.align 8
.LC46:
	.ascii	"failed precondition from silver_profile.adb:187"
	.align 8
.LC47:
	.ascii	"failed precondition from silver_profile.adb:188"
	.align 8
.LC48:
	.ascii	"failed precondition from silver_profile.adb:189"
	.align 8
.LC49:
	.ascii	"failed postcondition from silver_profile.adb:190"
	.align 8
.LC50:
	.ascii	"failed postcondition from silver_profile.adb:191"
	.text
	.align 2
	.type	silver_profile__skip_trivia, @function
silver_profile__skip_trivia:
.LFB34:
	.loc 1 184 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$88, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, -128(%rbp)
	movq	%rax, %rsi
	movl	$0, %edi
	movq	-128(%rbp), %rdi
	movq	%rsi, -112(%rbp)
	movq	%rdi, -104(%rbp)
	movl	%edx, -116(%rbp)
	.loc 1 184 4
	leaq	16(%rbp), %rdx
	.loc 1 184 4 is_stmt 0 discriminator 1
	leaq	-112(%rbp), %rax
	movq	%rdx, -64(%rbp)
	movq	%rax, -88(%rbp)
	movl	-116(%rbp), %eax
	movl	%eax, -80(%rbp)
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -72(%rbp)
	movq	-104(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -76(%rbp)
	movl	-76(%rbp), %edx
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jl	.L366
	.loc 1 184 4 discriminator 2
	movl	-76(%rbp), %esi
	movslq	%esi, %rax
	cqto
	movl	-72(%rbp), %edi
	movl	%edi, -128(%rbp)
	movslq	-128(%rbp), %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L367
.L366:
	.loc 1 184 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L367:
.LBB72:
	.loc 1 184 4 discriminator 4
	movl	-72(%rbp), %esi
	movslq	%esi, %rsi
	movq	%rsi, -96(%rbp)
	movl	-76(%rbp), %edi
	movl	-72(%rbp), %esi
	cmpl	%esi, %edi
	.loc 1 184 4 discriminator 7
	movl	-76(%rbp), %edi
	movl	-72(%rbp), %esi
	cmpl	%esi, %edi
	.loc 1 184 4 discriminator 10
	movl	-76(%rbp), %edi
	movl	-72(%rbp), %esi
	cmpl	%esi, %edi
	.loc 1 187 15 is_stmt 1
	movl	-72(%rbp), %esi
	cmpl	$1, %esi
	je	.L374
.LBB73:
	.loc 1 187 15 is_stmt 0 discriminator 1
	leaq	.LC46(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L374:
.LBE73:
	.loc 1 188 31 is_stmt 1
	movl	%eax, %esi
	.loc 1 187 15 discriminator 2
	testl	%esi, %esi
	jle	.L375
	.loc 1 188 31 discriminator 1
	cmpl	$4096, %eax
	jle	.L376
.L375:
.LBB74:
	.loc 1 187 15 discriminator 3
	leaq	.LC47(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L376:
.LBE74:
	.loc 1 189 41
	movl	-76(%rbp), %eax
	cmpl	$2147483647, %eax
	jne	.L377
	.loc 1 189 41 is_stmt 0 discriminator 1
	leaq	.LC7(%rip), %rax
	movl	$189, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L377:
	.loc 1 189 41 discriminator 3
	movl	-76(%rbp), %eax
	leal	1(%rax), %edx
	.loc 1 187 15 is_stmt 1 discriminator 4
	movl	-80(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L378
.LBB75:
	.loc 1 187 15 is_stmt 0 discriminator 5
	leaq	.LC48(%rip), %rcx
	leaq	.LC0(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L378:
.LBE75:
	.loc 1 190 36 is_stmt 1
	movl	-80(%rbp), %eax
	movl	%eax, -128(%rbp)
	.loc 1 191 56
	movl	-80(%rbp), %ebx
	.loc 1 184 4 discriminator 13
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
	call	silver_profile__skip_trivia___wrapped_statements.11
	.loc 1 190 16 discriminator 1
	movl	-80(%rbp), %eax
	movl	-128(%rbp), %ecx
	cmpl	%ecx, %eax
	jl	.L379
	.loc 1 190 54 discriminator 2
	movl	-76(%rbp), %eax
	cmpl	$2147483647, %eax
	jne	.L380
	.loc 1 190 54 is_stmt 0 discriminator 3
	leaq	.LC7(%rip), %rax
	movl	$190, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L380:
	.loc 1 190 54 discriminator 5
	movl	-76(%rbp), %eax
	leal	1(%rax), %edx
	.loc 1 190 25 is_stmt 1 discriminator 6
	movl	-80(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L381
.L379:
.LBB76:
	.loc 1 190 16 discriminator 7
	leaq	.LC49(%rip), %r14
	leaq	.LC4(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L381:
.LBE76:
	.loc 1 191 30 discriminator 1
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rax
	movl	%ebx, %edx
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	___ghost_silver_profile__trivia_end
	.loc 1 191 28 discriminator 2
	movl	-80(%rbp), %edx
	cmpl	%eax, %edx
	sete	%al
	xorl	$1, %eax
	.loc 1 190 16 discriminator 8
	testb	%al, %al
	je	.L385
.LBB77:
	.loc 1 190 16 is_stmt 0 discriminator 9
	leaq	.LC50(%rip), %r12
	leaq	.LC4(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L385:
.LBE77:
	.loc 1 184 4 is_stmt 1 discriminator 14
	nop
.LBE72:
	.loc 1 184 4 is_stmt 0 discriminator 15
	movl	-80(%rbp), %eax
	.loc 1 184 4
	addq	$88, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE34:
	.size	silver_profile__skip_trivia, .-silver_profile__skip_trivia
	.align 2
	.type	silver_profile__match_token___wrapped_statements___finalizer.13, @function
silver_profile__match_token___wrapped_statements___finalizer.13:
.LFB38:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE38:
	.size	silver_profile__match_token___wrapped_statements___finalizer.13, .-silver_profile__match_token___wrapped_statements___finalizer.13
	.section	.rodata
	.align 8
.LC51:
	.ascii	"Loop_Invariant failed at silver_profile.adb:241"
	.text
	.align 2
	.type	silver_profile__match_token___wrapped_statements.12, @function
silver_profile__match_token___wrapped_statements.12:
.LFB37:
	.loc 1 216 4 is_stmt 1
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA37
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB8:
	subq	$136, %rsp
.LEHE8:
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -136(%rbp)
	.loc 1 216 4
	leaq	16(%rbp), %rax
	.loc 1 216 4 is_stmt 0 discriminator 1
	movq	%rax, -104(%rbp)
	movl	48(%rbx), %r13d
	movl	44(%rbx), %r12d
.LBB78:
	leaq	-128(%rbp), %rax
	movq	%rax, %rdi
.LEHB9:
	call	system__secondary_stack__ss_mark@PLT
	.loc 1 232 33 is_stmt 1
	movzbl	53(%rbx), %eax
	movzbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__spelling
	.loc 1 232 33 is_stmt 0 discriminator 1
	movq	%rax, %r14
	movq	%rdx, %r15
	movq	%r15, %rax
	movl	(%rax), %eax
	movl	%eax, -60(%rbp)
	movq	%r15, %rax
	movl	4(%rax), %eax
	movl	%eax, -64(%rbp)
	.loc 1 232 7 is_stmt 1 discriminator 1
	movl	-60(%rbp), %eax
	cltq
	movq	%rax, -72(%rbp)
	movl	-64(%rbp), %eax
	cmpl	-60(%rbp), %eax
	jl	.L389
	.loc 1 232 7 is_stmt 0 discriminator 2
	movl	-64(%rbp), %eax
	cltq
	movq	%rax, -80(%rbp)
	jmp	.L390
.L389:
	.loc 1 232 7 discriminator 3
	movl	-60(%rbp), %eax
	cltq
	subq	$1, %rax
	movq	%rax, -80(%rbp)
.L390:
	.loc 1 232 7 discriminator 4
	movl	-64(%rbp), %eax
	cmpl	-60(%rbp), %eax
	.loc 1 232 7 discriminator 7
	movl	-64(%rbp), %eax
	cmpl	-60(%rbp), %eax
	.loc 1 232 33 is_stmt 1 discriminator 10
	movl	-64(%rbp), %eax
	cmpl	-60(%rbp), %eax
	jl	.L395
	.loc 1 232 33 is_stmt 0 discriminator 11
	cmpl	$0, -60(%rbp)
	jg	.L395
	.loc 1 232 33 discriminator 12
	leaq	.LC7(%rip), %rax
	movl	$232, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L395:
	.loc 1 232 7 is_stmt 1 discriminator 13
	movq	%r14, -88(%rbp)
	.loc 1 234 15
	movl	$0, %eax
	movb	%al, 52(%rbx)
	.loc 1 235 14
	movl	-64(%rbp), %eax
	cmpl	-60(%rbp), %eax
	jl	.L396
	.loc 1 235 14 is_stmt 0 discriminator 1
	movl	-64(%rbp), %eax
	movslq	%eax, %rdx
	movl	-60(%rbp), %eax
	cltq
	subq	%rax, %rdx
	movq	%rdx, %rax
	addq	$1, %rax
	jmp	.L397
.L396:
	.loc 1 235 14 discriminator 2
	movl	$0, %eax
.L397:
	.loc 1 235 14 discriminator 3
	cmpq	$2147483647, %rax
	jle	.L398
	.loc 1 235 14 discriminator 4
	leaq	.LC7(%rip), %rax
	movl	$235, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L398:
	.loc 1 235 22 is_stmt 1 discriminator 5
	movl	%eax, %ecx
	.loc 1 235 35 discriminator 5
	movl	40(%rbx), %eax
	movl	$0, %esi
	movl	%r12d, %edx
	subl	%eax, %edx
	jno	.L399
	movl	$1, %esi
.L399:
	.loc 1 235 35 is_stmt 0 discriminator 6
	movl	%esi, %eax
	testl	%eax, %eax
	je	.L401
	.loc 1 235 35 discriminator 7
	leaq	.LC7(%rip), %rax
	movl	$235, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L401:
	.loc 1 235 35 discriminator 9
	movl	%edx, %eax
	.loc 1 235 47 is_stmt 1 discriminator 10
	cmpl	$2147483647, %eax
	jne	.L402
	.loc 1 235 47 is_stmt 0 discriminator 11
	leaq	.LC7(%rip), %rax
	movl	$235, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L402:
	.loc 1 235 47 discriminator 13
	addl	$1, %eax
	.loc 1 235 7 is_stmt 1 discriminator 14
	cmpl	%ecx, %eax
	jge	.L403
	.loc 1 236 10
	movl	$0, %ebx
	jmp	.L404
.L403:
	.loc 1 239 11
	movl	-60(%rbp), %eax
	cmpl	-64(%rbp), %eax
	jg	.L405
.LBB79:
	.loc 1 239 11 is_stmt 0 discriminator 1
	movl	-60(%rbp), %eax
	movl	%eax, -52(%rbp)
.L427:
.LBB80:
	.loc 1 241 13 is_stmt 1
	movb	$1, -137(%rbp)
	.loc 1 241 53
	cmpl	$-2147483648, -52(%rbp)
	jne	.L406
	.loc 1 241 21 discriminator 1
	leaq	.LC7(%rip), %rax
	movl	$241, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L406:
	.loc 1 241 21 is_stmt 0 discriminator 3
	movl	-52(%rbp), %eax
	subl	$1, %eax
	movl	%eax, -92(%rbp)
	.loc 1 241 13 is_stmt 1 discriminator 4
	movl	-60(%rbp), %eax
	cmpl	-92(%rbp), %eax
	jg	.L407
.LBB81:
	.loc 1 241 21 discriminator 5
	movl	-60(%rbp), %eax
	movl	%eax, -56(%rbp)
.L418:
.LBB82:
	.loc 1 242 42
	movl	40(%rbx), %edx
	movl	$0, %ecx
	movl	-56(%rbp), %eax
	addl	%edx, %eax
	jno	.L408
	movl	$1, %ecx
.L408:
	movl	%eax, %edx
	.loc 1 242 42 is_stmt 0 discriminator 1
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L410
	.loc 1 242 42 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$242, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L410:
	.loc 1 242 42 discriminator 4
	movl	%edx, %eax
	.loc 1 242 54 is_stmt 1 discriminator 5
	cmpl	$-2147483648, %eax
	jne	.L411
	.loc 1 242 54 is_stmt 0 discriminator 6
	leaq	.LC7(%rip), %rax
	movl	$242, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L411:
	.loc 1 242 54 discriminator 8
	subl	$1, %eax
	.loc 1 242 26 is_stmt 1 discriminator 9
	cmpl	%eax, %r13d
	jg	.L412
	.loc 1 242 26 is_stmt 0 discriminator 10
	cmpl	%eax, %r12d
	jge	.L413
.L412:
	.loc 1 242 26 discriminator 11
	leaq	.LC7(%rip), %rax
	movl	$242, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L413:
	.loc 1 242 62 is_stmt 1 discriminator 12
	movl	-56(%rbp), %edx
	cmpl	-60(%rbp), %edx
	jl	.L414
	.loc 1 242 62 is_stmt 0 discriminator 13
	movl	-56(%rbp), %edx
	cmpl	-64(%rbp), %edx
	jle	.L415
.L414:
	.loc 1 242 62 discriminator 14
	leaq	.LC7(%rip), %rax
	movl	$242, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L415:
	.loc 1 242 15 is_stmt 1 discriminator 15
	movq	32(%rbx), %rdx
	movq	(%rdx), %rdx
	movslq	%eax, %rcx
	movq	24(%rbx), %rax
	subq	%rax, %rcx
	movzbl	(%rdx,%rcx), %eax
	.loc 1 242 15 is_stmt 0 discriminator 16
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__lowercase
	.loc 1 242 60 is_stmt 1 discriminator 17
	movq	%r14, %rcx
	movl	-56(%rbp), %edx
	movslq	%edx, %rdx
	subq	-72(%rbp), %rdx
	movzbl	(%rcx,%rdx), %edx
	.loc 1 241 13 discriminator 6
	cmpb	%dl, %al
	je	.L416
	.loc 1 241 13 is_stmt 0 discriminator 7
	movb	$0, -137(%rbp)
	jmp	.L407
.L416:
.LBE82:
	.loc 1 241 13 discriminator 8
	movl	-56(%rbp), %eax
	cmpl	-92(%rbp), %eax
	je	.L407
	.loc 1 241 13 discriminator 9
	addl	$1, -56(%rbp)
	jmp	.L418
.L407:
.LBE81:
	.loc 1 241 13 discriminator 10
	movzbl	-137(%rbp), %eax
	xorl	$1, %eax
	testb	%al, %al
	je	.L419
.LBB83:
	.loc 1 241 13 discriminator 11
	leaq	.LC51(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rsi
	movq	-152(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L419:
.LBE83:
	.loc 1 243 40 is_stmt 1
	movl	40(%rbx), %edx
	movl	$0, %ecx
	movl	-52(%rbp), %eax
	addl	%edx, %eax
	jno	.L420
	movl	$1, %ecx
.L420:
	movl	%eax, %edx
	.loc 1 243 40 is_stmt 0 discriminator 1
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L422
	.loc 1 243 40 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$243, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L422:
	.loc 1 243 40 discriminator 4
	movl	%edx, %eax
	.loc 1 243 49 is_stmt 1 discriminator 5
	cmpl	$-2147483648, %eax
	jne	.L423
	.loc 1 243 49 is_stmt 0 discriminator 6
	leaq	.LC7(%rip), %rax
	movl	$243, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L423:
	.loc 1 243 49 discriminator 8
	subl	$1, %eax
	.loc 1 243 24 is_stmt 1 discriminator 9
	cmpl	%eax, %r13d
	jg	.L424
	.loc 1 243 24 is_stmt 0 discriminator 10
	cmpl	%eax, %r12d
	jge	.L425
.L424:
	.loc 1 243 24 discriminator 11
	leaq	.LC7(%rip), %rax
	movl	$243, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L425:
	.loc 1 243 13 is_stmt 1 discriminator 12
	movq	32(%rbx), %rdx
	movq	(%rdx), %rdx
	movslq	%eax, %rcx
	movq	24(%rbx), %rax
	subq	%rax, %rcx
	movzbl	(%rdx,%rcx), %eax
	.loc 1 243 13 is_stmt 0 discriminator 13
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__lowercase
	.loc 1 243 55 is_stmt 1 discriminator 14
	movq	%r14, %rcx
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	subq	-72(%rbp), %rdx
	movzbl	(%rcx,%rdx), %edx
	.loc 1 243 10 discriminator 15
	cmpb	%dl, %al
	je	.L426
	.loc 1 244 13
	movl	$0, %ebx
	jmp	.L404
.L426:
.LBE80:
	.loc 1 239 11 discriminator 2
	movl	-52(%rbp), %eax
	cmpl	-64(%rbp), %eax
	je	.L405
	.loc 1 239 11 is_stmt 0 discriminator 3
	addl	$1, -52(%rbp)
	.loc 1 246 15 is_stmt 1
	jmp	.L427
.L405:
.LBE79:
	.loc 1 248 10
	movzbl	53(%rbx), %eax
	movzbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_word_token
	.loc 1 248 7 discriminator 1
	testb	%al, %al
	je	.L428
	.loc 1 249 33
	movl	-64(%rbp), %eax
	cmpl	-60(%rbp), %eax
	jl	.L429
	.loc 1 249 33 is_stmt 0 discriminator 1
	movl	-64(%rbp), %eax
	movslq	%eax, %rdx
	movl	-60(%rbp), %eax
	cltq
	subq	%rax, %rdx
	movq	%rdx, %rax
	addq	$1, %rax
	jmp	.L430
.L429:
	.loc 1 249 33 discriminator 2
	movl	$0, %eax
.L430:
	.loc 1 249 33 discriminator 3
	cmpq	$2147483647, %rax
	jle	.L431
	.loc 1 249 33 discriminator 4
	leaq	.LC7(%rip), %rax
	movl	$249, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L431:
	.loc 1 249 27 is_stmt 1 discriminator 5
	movl	%eax, %ecx
	movl	40(%rbx), %eax
	movl	$0, %edx
	addl	%ecx, %eax
	jno	.L432
	movl	$1, %edx
.L432:
	movl	%eax, %ecx
	.loc 1 249 27 is_stmt 0 discriminator 6
	movl	%edx, %eax
	testl	%eax, %eax
	je	.L434
	.loc 1 249 27 discriminator 7
	leaq	.LC7(%rip), %rax
	movl	$249, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L434:
	.loc 1 249 27 discriminator 9
	movl	%ecx, %eax
	.loc 1 249 41 is_stmt 1 discriminator 10
	cmpl	%r12d, %eax
	setle	%al
	.loc 1 249 9 discriminator 10
	testb	%al, %al
	je	.L428
	.loc 1 250 64
	movl	-64(%rbp), %eax
	cmpl	-60(%rbp), %eax
	jl	.L435
	.loc 1 250 64 is_stmt 0 discriminator 1
	movl	-64(%rbp), %eax
	movslq	%eax, %rdx
	movl	-60(%rbp), %eax
	cltq
	subq	%rax, %rdx
	movq	%rdx, %rax
	addq	$1, %rax
	jmp	.L436
.L435:
	.loc 1 250 64 discriminator 2
	movl	$0, %eax
.L436:
	.loc 1 250 64 discriminator 3
	cmpq	$2147483647, %rax
	jle	.L437
	.loc 1 250 64 discriminator 4
	leaq	.LC7(%rip), %rax
	movl	$250, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L437:
	.loc 1 250 58 is_stmt 1 discriminator 5
	movl	%eax, %ecx
	movl	40(%rbx), %eax
	movl	$0, %edx
	addl	%ecx, %eax
	jno	.L438
	movl	$1, %edx
.L438:
	movl	%eax, %ecx
	.loc 1 250 58 is_stmt 0 discriminator 6
	movl	%edx, %eax
	testl	%eax, %eax
	je	.L440
	.loc 1 250 58 discriminator 7
	leaq	.LC7(%rip), %rax
	movl	$250, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L440:
	.loc 1 250 58 discriminator 9
	movl	%ecx, %eax
	.loc 1 250 43 is_stmt 1 discriminator 10
	cmpl	%eax, %r13d
	jg	.L441
	.loc 1 250 43 is_stmt 0 discriminator 11
	cmpl	%eax, %r12d
	jge	.L442
.L441:
	.loc 1 250 43 discriminator 12
	leaq	.LC7(%rip), %rax
	movl	$250, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L442:
	.loc 1 250 18 is_stmt 1 discriminator 13
	movq	32(%rbx), %rdx
	movq	(%rdx), %rdx
	movslq	%eax, %rcx
	movq	24(%rbx), %rax
	subq	%rax, %rcx
	movzbl	(%rdx,%rcx), %eax
	.loc 1 250 18 is_stmt 0 discriminator 14
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_identifier_character
	.loc 1 250 9 is_stmt 1 discriminator 15
	testb	%al, %al
	je	.L428
	.loc 1 252 10
	movl	$0, %ebx
	jmp	.L404
.L428:
	.loc 1 255 34
	movl	-64(%rbp), %eax
	cmpl	-60(%rbp), %eax
	jl	.L443
	.loc 1 255 34 is_stmt 0 discriminator 1
	movl	-64(%rbp), %eax
	movslq	%eax, %rdx
	movl	-60(%rbp), %eax
	cltq
	subq	%rax, %rdx
	movq	%rdx, %rax
	addq	$1, %rax
	jmp	.L444
.L443:
	.loc 1 255 34 discriminator 2
	movl	$0, %eax
.L444:
	.loc 1 255 34 discriminator 3
	cmpq	$2147483647, %rax
	jle	.L445
	.loc 1 255 34 discriminator 4
	leaq	.LC7(%rip), %rax
	movl	$255, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L445:
	.loc 1 255 28 is_stmt 1 discriminator 5
	movl	%eax, %ecx
	movl	40(%rbx), %eax
	movl	$0, %edx
	addl	%ecx, %eax
	jno	.L446
	movl	$1, %edx
.L446:
	movl	%eax, %ecx
	.loc 1 255 28 is_stmt 0 discriminator 6
	movl	%edx, %eax
	testl	%eax, %eax
	je	.L448
	.loc 1 255 28 discriminator 7
	leaq	.LC7(%rip), %rax
	movl	$255, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L448:
	.loc 1 255 28 discriminator 9
	movl	%ecx, %eax
	.loc 1 255 28 discriminator 10
	testl	%eax, %eax
	jle	.L449
	.loc 1 255 28 discriminator 11
	cmpl	$4097, %eax
	jle	.L450
.L449:
	.loc 1 255 28 discriminator 12
	leaq	.LC7(%rip), %rax
	movl	$255, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.LEHE9:
.L450:
	.loc 1 255 16 is_stmt 1 discriminator 13
	movl	%eax, 40(%rbx)
	.loc 1 256 15
	movl	$1, %eax
	movb	%al, 52(%rbx)
	.loc 1 257 8
	movl	$0, %ebx
.L404:
	.loc 1 257 0 discriminator 1
	leaq	-128(%rbp), %rax
	movq	%rax, %r10
.LEHB10:
	call	silver_profile__match_token___wrapped_statements___finalizer.13
.LEHE10:
	.loc 1 257 0 is_stmt 0 discriminator 2
	cmpl	$1, %ebx
	je	.L451
	movl	$0, %eax
.L456:
	.loc 1 257 8 is_stmt 1 discriminator 3
	cmpl	$1, %eax
	je	.L452
.LBE78:
	.loc 1 257 8 is_stmt 0
	jmp	.L459
.L457:
	movq	%rax, -176(%rbp)
	movl	$1, %ebx
.LBB84:
	.loc 1 216 4 is_stmt 1 discriminator 2
	jmp	.L404
.L451:
	movq	-176(%rbp), %rax
	movq	%rax, -168(%rbp)
	jmp	.L455
.L458:
	movq	%rax, -168(%rbp)
.L455:
	movl	$1, %eax
	jmp	.L456
.L452:
	movq	-168(%rbp), %rax
	movq	%rax, %rdi
.LEHB11:
	call	_Unwind_Resume@PLT
.L459:
.LBE84:
	.loc 1 257 8
	addq	$136, %rsp
.LEHE11:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE37:
	.section	.gcc_except_table
.LLSDA37:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE37-.LLSDACSB37
.LLSDACSB37:
	.uleb128 .LEHB8-.LFB37
	.uleb128 .LEHE8-.LEHB8
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB9-.LFB37
	.uleb128 .LEHE9-.LEHB9
	.uleb128 .L457-.LFB37
	.uleb128 0
	.uleb128 .LEHB10-.LFB37
	.uleb128 .LEHE10-.LEHB10
	.uleb128 .L458-.LFB37
	.uleb128 0
	.uleb128 .LEHB11-.LFB37
	.uleb128 .LEHE11-.LEHB11
	.uleb128 0
	.uleb128 0
.LLSDACSE37:
	.text
	.size	silver_profile__match_token___wrapped_statements.12, .-silver_profile__match_token___wrapped_statements.12
	.section	.rodata
	.align 8
.LC52:
	.ascii	"failed precondition from silver_profile.adb:221"
	.align 8
.LC53:
	.ascii	"failed precondition from silver_profile.adb:222"
	.align 8
.LC54:
	.ascii	"failed precondition from silver_profile.adb:223"
	.align 8
.LC55:
	.ascii	"failed postcondition from silver_profile.adb:224"
	.align 8
.LC56:
	.ascii	"failed postcondition from silver_profile.adb:225"
	.align 8
.LC57:
	.ascii	"failed postcondition from silver_profile.adb:229"
	.text
	.align 2
	.type	silver_profile__match_token, @function
silver_profile__match_token:
.LFB36:
	.loc 1 216 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA36
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB12:
	subq	$184, %rsp
.LEHE12:
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -128(%rbp)
	movq	%rdi, -120(%rbp)
	movl	%edx, -132(%rbp)
	movb	%cl, -133(%rbp)
	.loc 1 216 4
	leaq	16(%rbp), %rdx
	.loc 1 216 4 is_stmt 0 discriminator 1
	leaq	-128(%rbp), %rax
	movq	%rdx, -56(%rbp)
	movq	%rax, -80(%rbp)
	movl	-132(%rbp), %eax
	movl	%eax, -72(%rbp)
	movzbl	-133(%rbp), %eax
	movb	%al, -59(%rbp)
	movq	-120(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -64(%rbp)
	movq	-120(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -68(%rbp)
	movl	-68(%rbp), %edx
	movl	-64(%rbp), %eax
	cmpl	%eax, %edx
	jl	.L461
	.loc 1 216 4 discriminator 2
	movl	-68(%rbp), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movl	-64(%rbp), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L462
.L461:
	.loc 1 216 4 discriminator 3
	movl	$0, %ecx
	movl	$0, %ebx
.L462:
.LBB85:
	.loc 1 216 4 discriminator 4
	movl	-64(%rbp), %eax
	cltq
	movq	%rax, -88(%rbp)
	movl	-68(%rbp), %edx
	movl	-64(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 216 4 discriminator 7
	movl	-68(%rbp), %edx
	movl	-64(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 216 4 discriminator 10
	movl	-68(%rbp), %edx
	movl	-64(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 221 15 is_stmt 1
	movl	-64(%rbp), %eax
	cmpl	$1, %eax
	je	.L469
.LBB86:
	.loc 1 221 15 is_stmt 0 discriminator 1
	leaq	.LC52(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
.LEHB13:
	call	system__assertions__raise_assert_failure@PLT
.L469:
.LBE86:
	.loc 1 222 31 is_stmt 1
	movl	%ecx, %eax
	.loc 1 221 15 discriminator 2
	testl	%eax, %eax
	jle	.L470
	.loc 1 222 31 discriminator 1
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L471
.L470:
.LBB87:
	.loc 1 221 15 discriminator 3
	leaq	.LC53(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L471:
.LBE87:
	.loc 1 223 41
	movl	-68(%rbp), %eax
	cmpl	$2147483647, %eax
	jne	.L472
	.loc 1 223 41 is_stmt 0 discriminator 1
	leaq	.LC7(%rip), %rax
	movl	$223, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L472:
	.loc 1 223 41 discriminator 3
	movl	-68(%rbp), %eax
	leal	1(%rax), %edx
	.loc 1 221 15 is_stmt 1 discriminator 4
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L473
.LBB88:
	.loc 1 221 15 is_stmt 0 discriminator 5
	leaq	.LC54(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L473:
.LBE88:
	.loc 1 226 27 is_stmt 1
	movl	-72(%rbp), %r12d
	.loc 1 229 48
	movl	-72(%rbp), %r14d
	.loc 1 230 37
	movl	-72(%rbp), %r13d
	.loc 1 216 4 discriminator 13
	leaq	-112(%rbp), %rax
	movq	%rax, %r10
	call	silver_profile__match_token___wrapped_statements.12
.LEHE13:
	leaq	-112(%rbp), %rax
	movq	%rax, %rdi
.LEHB14:
	call	system__secondary_stack__ss_mark@PLT
.LBB89:
	.loc 1 224 38
	movl	-68(%rbp), %eax
	cmpl	$2147483647, %eax
	jne	.L474
	.loc 1 224 38 is_stmt 0 discriminator 1
	leaq	.LC7(%rip), %rax
	movl	$224, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L474:
	.loc 1 224 38 discriminator 3
	movl	-68(%rbp), %eax
	leal	1(%rax), %edx
	.loc 1 224 16 is_stmt 1 discriminator 4
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	jge	.L475
.LBB90:
	.loc 1 224 16 is_stmt 0 discriminator 5
	leaq	.LC55(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC4(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L475:
.LBE90:
	.loc 1 225 29 is_stmt 1
	movzbl	-59(%rbp), %eax
	movzbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_word_token
	movl	%eax, %ebx
	.loc 1 226 33 discriminator 1
	movzbl	-59(%rbp), %eax
	movzbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__spelling
	.loc 1 225 29 discriminator 2
	movzbl	%bl, %ecx
	movq	%rax, %rsi
	movq	-128(%rbp), %rdi
	movq	-120(%rbp), %rax
	movl	%ecx, %r9d
	movq	%rsi, %rcx
	movq	%rdx, %r8
	movl	%r12d, %edx
	movq	%rax, %rsi
	call	___ghost_silver_profile__token_at
	.loc 1 225 27 discriminator 3
	movzbl	-60(%rbp), %edx
	cmpb	%dl, %al
	sete	%al
	xorl	$1, %eax
	.loc 1 224 16 discriminator 6
	testb	%al, %al
	je	.L476
.LBB91:
	.loc 1 224 16 is_stmt 0 discriminator 7
	leaq	.LC56(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC4(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L476:
.LBE91:
	.loc 1 229 13 is_stmt 1 discriminator 1
	movzbl	-60(%rbp), %eax
	testb	%al, %al
	je	.L477
	.loc 1 229 55 discriminator 2
	movzbl	-59(%rbp), %eax
	movzbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__spelling
	.loc 1 229 71 discriminator 3
	movq	%rdx, %rcx
	movl	4(%rcx), %esi
	movq	%rdx, %rcx
	movl	(%rcx), %ecx
	cmpl	%ecx, %esi
	jl	.L478
	.loc 1 229 71 is_stmt 0 discriminator 4
	movq	%rdx, %rcx
	movl	4(%rcx), %ecx
	movq	%rdx, %rax
	movl	(%rax), %eax
	movl	%eax, %edx
	movl	%ecx, %eax
	subl	%edx, %eax
	addl	$1, %eax
	jmp	.L479
.L478:
	.loc 1 229 71 discriminator 5
	movl	$0, %eax
.L479:
	.loc 1 229 53 is_stmt 1 discriminator 6
	movl	$0, %edx
	addl	%r14d, %eax
	jno	.L480
	movl	$1, %edx
.L480:
	movl	%eax, %ecx
	.loc 1 229 53 is_stmt 0 discriminator 7
	movl	%edx, %eax
	testl	%eax, %eax
	je	.L482
	.loc 1 229 53 discriminator 8
	leaq	.LC7(%rip), %rax
	movl	$229, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L482:
	.loc 1 229 53 discriminator 10
	movl	%ecx, %edx
	.loc 1 229 38 is_stmt 1 discriminator 11
	movl	-72(%rbp), %eax
	cmpl	%eax, %edx
	sete	%al
	.loc 1 229 13 discriminator 11
	xorl	$1, %eax
	jmp	.L483
.L477:
	.loc 1 229 13 is_stmt 0 discriminator 12
	movl	-72(%rbp), %eax
	cmpl	%r13d, %eax
	setne	%al
.L483:
	.loc 1 224 16 is_stmt 1 discriminator 8
	testb	%al, %al
	je	.L484
.LBB92:
	.loc 1 224 16 is_stmt 0 discriminator 9
	leaq	.LC57(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC4(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.LEHE14:
.L484:
.LBE92:
	.loc 1 224 0 is_stmt 1 discriminator 10
	movl	$1, %ebx
.L490:
	.loc 1 224 0 is_stmt 0 discriminator 11
	leaq	-112(%rbp), %rax
	movq	%rax, %r10
.LEHB15:
	call	silver_profile__match_token__B261b___finalizer.14
.LEHE15:
	.loc 1 224 0 discriminator 12
	cmpl	$1, %ebx
	jne	.L485
	.loc 1 224 0 discriminator 14
	movl	$1, %eax
.L492:
	.loc 1 224 0 discriminator 15
	cmpl	$1, %eax
	jne	.L486
	.loc 1 224 0 discriminator 16
	nop
.LBE89:
	.loc 1 216 4 is_stmt 1 discriminator 14
	nop
.LBE85:
	.loc 1 216 4 is_stmt 0 discriminator 15
	movl	-72(%rbp), %eax
	movl	%eax, %edx
	movabsq	$-4294967296, %rax
	andq	-144(%rbp), %rax
	orq	%rdx, %rax
	movq	%rax, %rbx
	movzbl	-60(%rbp), %eax
	movzbl	%al, %eax
	salq	$32, %rax
	movabsq	$-1095216660481, %rdx
	andq	%rbx, %rdx
	orq	%rdx, %rax
	movq	%rax, -144(%rbp)
	movl	$0, %eax
.L494:
	cmpl	$1, %eax
	je	.L487
	.loc 1 216 4 discriminator 16
	movq	-144(%rbp), %rax
	jmp	.L498
.L496:
	movq	%rax, -216(%rbp)
	movl	$0, %ebx
.LBB94:
.LBB93:
	.loc 1 224 16 is_stmt 1 discriminator 17
	jmp	.L490
.L485:
	movq	-216(%rbp), %rax
	movq	%rax, -200(%rbp)
	jmp	.L491
.L497:
	movq	%rax, -200(%rbp)
.L491:
	movl	$0, %eax
	jmp	.L492
.L486:
	movq	-200(%rbp), %rax
	movq	%rax, -208(%rbp)
	jmp	.L493
.L495:
	movq	%rax, -208(%rbp)
.L493:
	movl	$1, %eax
	jmp	.L494
.L487:
	movq	-208(%rbp), %rax
	movq	%rax, %rdi
.LEHB16:
	call	_Unwind_Resume@PLT
.L498:
.LBE93:
.LBE94:
	.loc 1 216 4
	addq	$184, %rsp
.LEHE16:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE36:
	.section	.gcc_except_table
.LLSDA36:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE36-.LLSDACSB36
.LLSDACSB36:
	.uleb128 .LEHB12-.LFB36
	.uleb128 .LEHE12-.LEHB12
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB13-.LFB36
	.uleb128 .LEHE13-.LEHB13
	.uleb128 .L495-.LFB36
	.uleb128 0
	.uleb128 .LEHB14-.LFB36
	.uleb128 .LEHE14-.LEHB14
	.uleb128 .L496-.LFB36
	.uleb128 0
	.uleb128 .LEHB15-.LFB36
	.uleb128 .LEHE15-.LEHB15
	.uleb128 .L497-.LFB36
	.uleb128 0
	.uleb128 .LEHB16-.LFB36
	.uleb128 .LEHE16-.LEHB16
	.uleb128 0
	.uleb128 0
.LLSDACSE36:
	.text
	.size	silver_profile__match_token, .-silver_profile__match_token
	.align 2
	.type	silver_profile__match_token__B261b___finalizer.14, @function
silver_profile__match_token__B261b___finalizer.14:
.LFB39:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE39:
	.size	silver_profile__match_token__B261b___finalizer.14, .-silver_profile__match_token__B261b___finalizer.14
	.align 2
	.type	silver_profile__accepts___wrapped_statements__B_4___finalizer.16, @function
silver_profile__accepts___wrapped_statements__B_4___finalizer.16:
.LFB42:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE42:
	.size	silver_profile__accepts___wrapped_statements__B_4___finalizer.16, .-silver_profile__accepts___wrapped_statements__B_4___finalizer.16
	.section	.rodata
	.align 8
.LC58:
	.ascii	"Loop_Invariant failed at silver_profile.adb:278"
	.align 8
.LC59:
	.ascii	"Loop_Invariant failed at silver_profile.adb:280"
	.align 8
.LC60:
	.ascii	"Loop_Variant failed at silver_profile.adb:282"
	.text
	.align 2
	.type	silver_profile__accepts___wrapped_statements.15, @function
silver_profile__accepts___wrapped_statements.15:
.LFB41:
	.loc 1 259 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA41
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB17:
	subq	$168, %rsp
.LEHE17:
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%r10, %rbx
	movq	%r10, -136(%rbp)
	.loc 1 259 4
	leaq	16(%rbp), %rax
	.loc 1 259 4 is_stmt 0 discriminator 1
	movq	%rax, -104(%rbp)
	movl	12(%rbx), %edx
	movl	8(%rbx), %eax
	.loc 1 261 7 is_stmt 1
	cmpl	%eax, %edx
	jg	.L504
	.loc 1 261 50 discriminator 1
	movslq	%edx, %rdx
	addq	$4095, %rdx
	cltq
	.loc 1 261 28 discriminator 1
	cmpq	%rax, %rdx
	jge	.L505
.L504:
	.loc 1 262 10
	movb	$0, -137(%rbp)
	jmp	.L506
.L505:
	leaq	-128(%rbp), %rax
	movq	%rax, %rdi
.LEHB18:
	call	system__secondary_stack__ss_mark@PLT
.LBB95:
	.loc 1 266 36
	movq	(%rbx), %rax
	movq	(%rax), %rdx
	movq	8(%rax), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_profile__normalized
	.loc 1 266 36 is_stmt 0 discriminator 1
	movq	%rax, %r12
	movq	%rdx, %r13
	movq	%r13, %rax
	movl	(%rax), %eax
	movl	%eax, -60(%rbp)
	movq	%r13, %rax
	movl	4(%rax), %eax
	movl	%eax, -64(%rbp)
	.loc 1 266 10 is_stmt 1 discriminator 1
	movl	-60(%rbp), %eax
	cltq
	movq	%rax, -72(%rbp)
	movl	-64(%rbp), %eax
	cmpl	-60(%rbp), %eax
	jl	.L507
	.loc 1 266 10 is_stmt 0 discriminator 2
	movl	-64(%rbp), %eax
	cltq
	movq	%rax, -80(%rbp)
	jmp	.L508
.L507:
	.loc 1 266 10 discriminator 3
	movl	-60(%rbp), %eax
	cltq
	subq	$1, %rax
	movq	%rax, -80(%rbp)
.L508:
	.loc 1 266 10 discriminator 4
	movl	-64(%rbp), %eax
	cmpl	-60(%rbp), %eax
	.loc 1 266 10 discriminator 7
	movl	-64(%rbp), %eax
	cmpl	-60(%rbp), %eax
	.loc 1 266 36 is_stmt 1 discriminator 10
	movl	-64(%rbp), %eax
	cmpl	-60(%rbp), %eax
	jl	.L513
	.loc 1 266 36 is_stmt 0 discriminator 11
	cmpl	$0, -60(%rbp)
	jg	.L513
	.loc 1 266 36 discriminator 12
	leaq	.LC7(%rip), %rax
	movl	$266, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L513:
	.loc 1 266 10 is_stmt 1 discriminator 13
	movq	%r12, -88(%rbp)
	.loc 1 267 10
	movl	$1, -52(%rbp)
	.loc 1 268 10
	movl	$1, -56(%rbp)
	.loc 1 273 17
	movq	%r12, %rax
	movq	%r13, %rdx
	movq	%rax, %rdi
	movq	%rdx, %rsi
	call	silver_profile__allowed_source
	.loc 1 273 17 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 1 273 10 is_stmt 1 discriminator 1
	testb	%al, %al
	je	.L514
	.loc 1 274 13
	movb	$0, -137(%rbp)
	movl	$0, %ebx
	jmp	.L515
.L514:
	.loc 1 277 51
	movb	$0, -138(%rbp)
.L528:
.LBB96:
	.loc 1 277 27 discriminator 1
	cmpl	$15, -56(%rbp)
	jg	.L516
	.loc 1 278 58
	cmpl	$2147483647, -64(%rbp)
	jne	.L517
	.loc 1 278 58 is_stmt 0 discriminator 1
	leaq	.LC7(%rip), %rax
	movl	$278, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L517:
	.loc 1 278 58 discriminator 3
	movl	-64(%rbp), %eax
	addl	$1, %eax
	.loc 1 278 36 is_stmt 1 discriminator 4
	cmpl	-52(%rbp), %eax
	jge	.L518
.LBB97:
	.loc 1 278 36 is_stmt 0 discriminator 5
	leaq	.LC58(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rcx
	movq	-168(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L518:
.LBE97:
	.loc 1 280 16 is_stmt 1
	movq	%r12, %rsi
	movq	%r13, %rax
	movl	$1, %ecx
	movl	$1, %edx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	___ghost_silver_profile__suffix_matches
	movl	%eax, %ebx
	.loc 1 281 18
	movl	-56(%rbp), %edx
	movl	-52(%rbp), %eax
	movq	%r12, %rdi
	movq	%r13, %rsi
	movl	%edx, %ecx
	movl	%eax, %edx
	call	___ghost_silver_profile__suffix_matches
	.loc 1 280 16 discriminator 2
	cmpb	%al, %bl
	je	.L519
.LBB98:
	.loc 1 280 16 is_stmt 0 discriminator 3
	leaq	.LC59(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rcx
	movq	-152(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L519:
.LBE98:
	.loc 1 282 13 is_stmt 1
	cmpb	$0, -138(%rbp)
	je	.L520
	.loc 1 282 47 discriminator 1
	movl	-144(%rbp), %eax
	movl	%eax, -188(%rbp)
.L520:
	.loc 1 282 47 is_stmt 0 discriminator 2
	movl	-56(%rbp), %eax
	movl	%eax, -144(%rbp)
	.loc 1 282 13 is_stmt 1 discriminator 2
	cmpb	$0, -138(%rbp)
	je	.L521
	.loc 1 282 47 discriminator 3
	movl	-188(%rbp), %ecx
	cmpl	%ecx, %eax
	jg	.L522
.LBB99:
	.loc 1 282 47 is_stmt 0 discriminator 4
	leaq	.LC60(%rip), %r14
	leaq	.LC5(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L521:
.LBE99:
	.loc 1 282 13 is_stmt 1 discriminator 5
	movb	$1, -138(%rbp)
.L522:
	.loc 1 284 13
	movl	-52(%rbp), %eax
	movq	%r12, %rsi
	movq	%r13, %rcx
	movl	%eax, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver_profile__skip_trivia
	.loc 1 284 13 is_stmt 0 discriminator 1
	movl	%eax, -52(%rbp)
	.loc 1 286 32 is_stmt 1
	cmpl	$0, -56(%rbp)
	jle	.L523
	.loc 1 286 32 is_stmt 0 discriminator 1
	cmpl	$15, -56(%rbp)
	jle	.L524
.L523:
	.loc 1 286 32 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$286, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L524:
.LBB100:
	.loc 1 285 13 is_stmt 1
	movl	-56(%rbp), %eax
	movslq	%eax, %rdx
	leaq	-1+silver_profile__required_tokens(%rip), %rax
	movzbl	(%rdx,%rax), %eax
	.loc 1 285 13 is_stmt 0 discriminator 1
	movzbl	%al, %edx
	movl	-52(%rbp), %eax
	movq	%r12, %rdi
	movq	%r13, %rsi
	movl	%edx, %ecx
	movl	%eax, %edx
	call	silver_profile__match_token
	.loc 1 285 13 discriminator 2
	movl	%eax, -52(%rbp)
	shrq	$32, %rax
	andb	$-1, %ah
	movb	%al, -89(%rbp)
.LBE100:
	.loc 1 287 16 is_stmt 1
	movzbl	-89(%rbp), %eax
	xorl	$1, %eax
	.loc 1 287 13
	testb	%al, %al
	je	.L525
	.loc 1 288 16
	movb	$0, -137(%rbp)
	movl	$0, %ebx
	jmp	.L515
.L525:
	.loc 1 290 38
	movl	-56(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L526
	.loc 1 290 38 is_stmt 0 discriminator 1
	cmpl	$16, %eax
	jle	.L527
.L526:
	.loc 1 290 38 discriminator 2
	leaq	.LC7(%rip), %rax
	movl	$290, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L527:
	.loc 1 290 24 is_stmt 1 discriminator 3
	movl	%eax, -56(%rbp)
.LBE96:
	.loc 1 291 18
	jmp	.L528
.L516:
	.loc 1 293 10
	movl	-52(%rbp), %eax
	movq	%r12, %rsi
	movq	%r13, %rcx
	movl	%eax, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	silver_profile__skip_trivia
.LEHE18:
	.loc 1 293 10 is_stmt 0 discriminator 1
	movl	%eax, -52(%rbp)
	.loc 1 294 10 is_stmt 1
	movl	-52(%rbp), %eax
	cmpl	-64(%rbp), %eax
	setg	-137(%rbp)
	movl	$0, %ebx
.L515:
	.loc 1 295 0
	leaq	-128(%rbp), %rax
	movq	%rax, %r10
.LEHB19:
	call	silver_profile__accepts___wrapped_statements__B_4___finalizer.16
.LEHE19:
	.loc 1 295 0 is_stmt 0 discriminator 1
	cmpl	$1, %ebx
	je	.L529
	movl	$0, %eax
.L533:
	.loc 1 295 10 is_stmt 1 discriminator 2
	cmpl	$1, %eax
	je	.L530
.L506:
.LBE95:
	.loc 1 296 8
	movzbl	-137(%rbp), %eax
	jmp	.L536
.L534:
	movq	%rax, -200(%rbp)
	movl	$1, %ebx
.LBB101:
	.loc 1 265 7
	jmp	.L515
.L529:
	movq	-200(%rbp), %rax
	movq	%rax, -184(%rbp)
	jmp	.L532
.L535:
	movq	%rax, -184(%rbp)
.L532:
	movl	$1, %eax
	jmp	.L533
.L530:
	movq	-184(%rbp), %rax
	movq	%rax, %rdi
.LEHB20:
	call	_Unwind_Resume@PLT
.L536:
.LBE101:
	.loc 1 296 8
	addq	$168, %rsp
.LEHE20:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE41:
	.section	.gcc_except_table
.LLSDA41:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE41-.LLSDACSB41
.LLSDACSB41:
	.uleb128 .LEHB17-.LFB41
	.uleb128 .LEHE17-.LEHB17
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB18-.LFB41
	.uleb128 .LEHE18-.LEHB18
	.uleb128 .L534-.LFB41
	.uleb128 0
	.uleb128 .LEHB19-.LFB41
	.uleb128 .LEHE19-.LEHB19
	.uleb128 .L535-.LFB41
	.uleb128 0
	.uleb128 .LEHB20-.LFB41
	.uleb128 .LEHE20-.LEHB20
	.uleb128 0
	.uleb128 0
.LLSDACSE41:
	.text
	.size	silver_profile__accepts___wrapped_statements.15, .-silver_profile__accepts___wrapped_statements.15
	.section	.rodata
	.align 8
.LC61:
	.ascii	"failed postcondition from silver_profile.ads:93"
	.text
	.align 2
	.globl	silver_profile__accepts
	.type	silver_profile__accepts, @function
silver_profile__accepts:
.LFB40:
	.loc 1 259 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$56, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	.cfi_offset 3, -40
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -80(%rbp)
	movq	%rdx, -72(%rbp)
	.loc 1 259 4
	leaq	16(%rbp), %rdx
	.loc 1 259 4 is_stmt 0 discriminator 1
	leaq	-80(%rbp), %rax
	movq	%rdx, -48(%rbp)
	movq	%rax, -64(%rbp)
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -52(%rbp)
	movq	-72(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -56(%rbp)
.LBB102:
	movl	-56(%rbp), %edx
	movl	-52(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 259 4 discriminator 4
	movl	-56(%rbp), %edx
	movl	-52(%rbp), %eax
	cmpl	%eax, %edx
	.loc 1 259 4 discriminator 7
	movl	-56(%rbp), %edx
	movl	-52(%rbp), %eax
	cmpl	%eax, %edx
.LBB103:
	.loc 1 259 4 discriminator 10
	leaq	-64(%rbp), %rax
	movq	%rax, %r10
	call	silver_profile__accepts___wrapped_statements.15
	movl	%eax, %ebx
	.loc 2 93 36 is_stmt 1
	movq	-80(%rbp), %rdx
	movq	-72(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	___ghost_silver_profile__is_member
	.loc 2 93 19 discriminator 1
	cmpb	%al, %bl
	je	.L545
.LBB104:
	.loc 2 93 19 is_stmt 0 discriminator 2
	leaq	.LC61(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L545:
.LBE104:
	.loc 1 259 4 is_stmt 1 discriminator 13
	movl	%ebx, %eax
.LBE103:
.LBE102:
	.loc 1 259 4 is_stmt 0
	addq	$56, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE40:
	.size	silver_profile__accepts, .-silver_profile__accepts
	.align 2
	.globl	silver_profile__allowed_source
	.type	silver_profile__allowed_source, @function
silver_profile__allowed_source:
.LFB43:
	.loc 1 60 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$32, %rsp
	.cfi_offset 14, -24
	.cfi_offset 13, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -64(%rbp)
	movq	%rdx, -56(%rbp)
	.loc 1 60 4
	movq	-56(%rbp), %rax
	movl	(%rax), %r13d
	movq	-56(%rbp), %rax
	movl	4(%rax), %r12d
.LBB105:
	.loc 1 61 7
	movl	$1, %r14d
	cmpl	%r12d, %r13d
	jg	.L553
.LBB106:
	.loc 1 61 7 is_stmt 0 discriminator 1
	movl	%r13d, %ebx
.L552:
.LBB107:
	.loc 1 61 7 discriminator 2
	cmpl	%ebx, %r13d
	jg	.L548
	.loc 1 61 7 discriminator 3
	cmpl	%ebx, %r12d
	jge	.L549
.L548:
	.loc 1 61 7 discriminator 4
	leaq	.LC7(%rip), %rax
	movl	$61, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L549:
	.loc 1 61 15 is_stmt 1 discriminator 5
	movq	-64(%rbp), %rcx
	movq	-56(%rbp), %rax
	movl	(%rax), %eax
	movslq	%eax, %rdx
	movslq	%ebx, %rax
	movq	%rax, %rsi
	subq	%rdx, %rsi
	leaq	(%rcx,%rsi), %rdx
	movq	%rdx, -40(%rbp)
	.loc 1 61 31 discriminator 5
	movq	-64(%rbp), %rdx
	movq	-56(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	subq	%rcx, %rax
	movzbl	(%rdx,%rax), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_allowed_character
	.loc 1 61 31 is_stmt 0 discriminator 6
	xorl	$1, %eax
	.loc 1 61 7 is_stmt 1 discriminator 6
	testb	%al, %al
	je	.L550
	.loc 1 61 7 is_stmt 0 discriminator 7
	movl	$0, %r14d
.LBE107:
.LBE106:
	.loc 1 61 7 discriminator 10
	jmp	.L553
.L550:
.LBB108:
	.loc 1 61 7 discriminator 8
	cmpl	%r12d, %ebx
	je	.L553
	.loc 1 61 7 discriminator 9
	addl	$1, %ebx
	jmp	.L552
.L553:
.LBE108:
	.loc 1 61 7 discriminator 11
	movl	%r14d, %eax
.LBE105:
	.loc 1 60 4 is_stmt 1
	addq	$32, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE43:
	.size	silver_profile__allowed_source, .-silver_profile__allowed_source
	.globl	silver_profile_E
	.data
	.align 2
	.type	silver_profile_E, @object
	.size	silver_profile_E, 2
silver_profile_E:
	.zero	2
	.globl	silver_profile__max_source_length
	.section	.rodata
	.align 4
	.type	silver_profile__max_source_length, @object
	.size	silver_profile__max_source_length, 4
silver_profile__max_source_length:
	.long	4096
	.globl	silver_profile__comment_introducer
	.align 2
	.type	silver_profile__comment_introducer, @object
	.size	silver_profile__comment_introducer, 2
silver_profile__comment_introducer:
	.ascii	"--"
	.globl	silver_profile__token_kindS
	.align 32
	.type	silver_profile__token_kindS, @object
	.size	silver_profile__token_kindS, 150
silver_profile__token_kindS:
	.ascii	"PROCEDURE_KEYWORDMAIN_NAMEIS_KEYWORDPRAGMA_KEYWORDSPARK_MODE"
	.ascii	"_NAMEON_NAMEBEGIN_KEYWORDNULL_KEYWORDEND_KEYWORDLEFT_PARENTH"
	.ascii	"ESISRIGHT_PARENTHESISSEMICOLON"
	.globl	silver_profile__token_kindN
	.align 16
	.type	silver_profile__token_kindN, @object
	.size	silver_profile__token_kindN, 26
silver_profile__token_kindN:
	.value	1
	.value	18
	.value	27
	.value	37
	.value	51
	.value	66
	.value	73
	.value	86
	.value	98
	.value	109
	.value	125
	.value	142
	.value	151
	.globl	silver_profile__required_tokens
	.align 16
	.type	silver_profile__required_tokens, @object
	.size	silver_profile__required_tokens, 16
silver_profile__required_tokens:
	.byte	0
	.byte	1
	.byte	2
	.byte	3
	.byte	4
	.byte	9
	.byte	5
	.byte	10
	.byte	11
	.byte	6
	.byte	7
	.byte	11
	.byte	8
	.byte	1
	.byte	11
	.zero	1
	.align 8
	.type	token_kindP.20, @object
	.size	token_kindP.20, 8
token_kindP.20:
	.long	1
	.long	3
	.align 2
	.type	token_kindT1.19, @object
	.size	token_kindT1.19, 2
token_kindT1.19:
	.byte	16
	.byte	3
	.align 2
	.type	token_kindT2.18, @object
	.size	token_kindT2.18, 2
token_kindT2.18:
	.byte	3
	.byte	18
	.align 16
	.type	token_kindG.17, @object
	.size	token_kindG.17, 27
token_kindG.17:
	.byte	8
	.byte	0
	.byte	0
	.byte	7
	.byte	0
	.byte	0
	.byte	2
	.byte	0
	.byte	0
	.byte	9
	.byte	10
	.byte	4
	.byte	0
	.byte	10
	.byte	0
	.byte	0
	.byte	0
	.byte	1
	.byte	10
	.byte	0
	.byte	11
	.byte	0
	.byte	2
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.text
.Letext0:
	.file 3 "<built-in>"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0xacc
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x1d
	.long	.LASF85
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.long	.LLRL3
	.quad	0
	.long	.Ldebug_line0
	.uleb128 0xf
	.long	.LASF26
	.byte	0x4
	.long	0x4c
	.uleb128 0x9
	.byte	0x3
	.quad	silver_profile__max_source_length
	.uleb128 0x10
	.sleb128 2147483647
	.long	.LASF16
	.long	0x51
	.uleb128 0x8
	.long	0x3e
	.uleb128 0xa
	.byte	0x4
	.byte	0x5
	.long	.LASF2
	.uleb128 0x9
	.long	0x6d
	.long	0x68
	.uleb128 0x15
	.long	0x51
	.sleb128 2
	.byte	0
	.uleb128 0x3
	.long	0x58
	.uleb128 0xa
	.byte	0x1
	.byte	0x8
	.long	.LASF3
	.uleb128 0x8
	.long	0x6d
	.uleb128 0x1e
	.long	.LASF86
	.byte	0x7
	.byte	0x1
	.byte	0x2
	.byte	0x25
	.byte	0x9
	.long	0xd0
	.uleb128 0x4
	.long	.LASF4
	.byte	0
	.uleb128 0x4
	.long	.LASF5
	.byte	0x1
	.uleb128 0x4
	.long	.LASF6
	.byte	0x2
	.uleb128 0x4
	.long	.LASF7
	.byte	0x3
	.uleb128 0x4
	.long	.LASF8
	.byte	0x4
	.uleb128 0x4
	.long	.LASF9
	.byte	0x5
	.uleb128 0x4
	.long	.LASF10
	.byte	0x6
	.uleb128 0x4
	.long	.LASF11
	.byte	0x7
	.uleb128 0x4
	.long	.LASF12
	.byte	0x8
	.uleb128 0x4
	.long	.LASF13
	.byte	0x9
	.uleb128 0x4
	.long	.LASF14
	.byte	0xa
	.uleb128 0x4
	.long	.LASF15
	.byte	0xb
	.byte	0
	.uleb128 0x8
	.long	0x79
	.uleb128 0x9
	.long	0x79
	.long	0xe5
	.uleb128 0x15
	.long	0x51
	.sleb128 15
	.byte	0
	.uleb128 0x3
	.long	0xd5
	.uleb128 0x10
	.sleb128 4097
	.long	.LASF17
	.long	0x51
	.uleb128 0x8
	.long	0xea
	.uleb128 0x10
	.sleb128 16
	.long	.LASF18
	.long	0x51
	.uleb128 0x8
	.long	0xfa
	.uleb128 0x1f
	.byte	0x8
	.byte	0x1
	.byte	0xd8
	.byte	0xe
	.long	0x12b
	.uleb128 0x16
	.long	.LASF19
	.byte	0xd9
	.byte	0x16
	.long	0xea
	.byte	0
	.uleb128 0x16
	.long	.LASF20
	.byte	0xda
	.byte	0x7
	.long	0x12b
	.byte	0x4
	.byte	0
	.uleb128 0xa
	.byte	0x1
	.byte	0x2
	.long	.LASF21
	.uleb128 0x8
	.long	0x12b
	.uleb128 0xa
	.byte	0x8
	.byte	0x7
	.long	.LASF22
	.uleb128 0x17
	.long	.LASF23
	.uleb128 0x17
	.long	.LASF24
	.uleb128 0xa
	.byte	0x1
	.byte	0x7
	.long	.LASF25
	.uleb128 0xf
	.long	.LASF27
	.byte	0x5
	.long	0x68
	.uleb128 0x9
	.byte	0x3
	.quad	silver_profile__comment_introducer
	.uleb128 0xf
	.long	.LASF28
	.byte	0x3b
	.long	0xe5
	.uleb128 0x9
	.byte	0x3
	.quad	silver_profile__required_tokens
	.uleb128 0x5
	.long	.LASF31
	.byte	0x3c
	.long	0x12b
	.quad	.LFB43
	.quad	.LFE43-.LFB43
	.uleb128 0x1
	.byte	0x9c
	.long	0x1c8
	.uleb128 0x1
	.long	.LASF33
	.byte	0x1
	.byte	0x3c
	.byte	0x1d
	.long	0x242
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x2
	.quad	.LBB107
	.quad	.LBE107-.LBB107
	.uleb128 0x6
	.long	.LASF37
	.byte	0x3d
	.byte	0xf
	.long	0x26b
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.byte	0
	.byte	0
	.uleb128 0x20
	.long	.LASF87
	.byte	0x10
	.byte	0x3
	.byte	0
	.long	0x20b
	.uleb128 0x18
	.long	.LASF29
	.long	0x1de
	.byte	0
	.uleb128 0x19
	.long	0x247
	.uleb128 0x21
	.byte	0x8
	.byte	0x3
	.byte	0
	.long	0x200
	.uleb128 0x1a
	.string	"LB0"
	.long	0x3e
	.byte	0
	.uleb128 0x1a
	.string	"UB0"
	.long	0x3e
	.byte	0x4
	.byte	0
	.uleb128 0x18
	.long	.LASF30
	.long	0x266
	.byte	0x8
	.byte	0
	.uleb128 0x3
	.long	0x1c8
	.uleb128 0x3
	.long	0x1c8
	.uleb128 0x3
	.long	0x1c8
	.uleb128 0x3
	.long	0x1c8
	.uleb128 0x3
	.long	0x1c8
	.uleb128 0x3
	.long	0x1c8
	.uleb128 0x3
	.long	0x1c8
	.uleb128 0x3
	.long	0x1c8
	.uleb128 0x3
	.long	0x1c8
	.uleb128 0x3
	.long	0x1c8
	.uleb128 0x3
	.long	0x1c8
	.uleb128 0x3
	.long	0x1c8
	.uleb128 0x9
	.long	0x6d
	.long	0x266
	.uleb128 0x22
	.long	0x51
	.uleb128 0x6
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x94
	.byte	0x4
	.uleb128 0x8
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x23
	.uleb128 0x4
	.byte	0x94
	.byte	0x4
	.byte	0
	.uleb128 0x19
	.long	0x1e3
	.uleb128 0x11
	.long	0x6d
	.uleb128 0x23
	.long	.LASF32
	.byte	0x1
	.value	0x103
	.byte	0x4
	.long	0x12b
	.quad	.LFB40
	.quad	.LFE40-.LFB40
	.uleb128 0x1
	.byte	0x9c
	.long	0x352
	.uleb128 0x1
	.long	.LASF34
	.byte	0x2
	.byte	0x5b
	.byte	0x16
	.long	0x23d
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x2
	.quad	.LBB102
	.quad	.LBE102-.LBB102
	.uleb128 0x1b
	.long	.LASF69
	.long	0x12b
	.quad	.LFB41
	.quad	.LFE41-.LFB41
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -152
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0x12
	.long	.LLRL2
	.uleb128 0x7
	.long	.LASF35
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x7
	.long	.LASF36
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x9
	.long	0x6d
	.long	0x30d
	.uleb128 0x1c
	.long	0x51
	.long	0x2dc
	.long	0x2e9
	.byte	0
	.uleb128 0xd
	.long	.LASF33
	.value	0x10a
	.long	0x31c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -104
	.uleb128 0x11
	.long	0x2f6
	.uleb128 0xd
	.long	.LASF19
	.value	0x10b
	.long	0xea
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0xd
	.long	.LASF38
	.value	0x10c
	.long	0xfa
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0xd
	.long	.LASF20
	.value	0x10d
	.long	0x12b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -105
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x13
	.long	.LASF46
	.byte	0xd8
	.long	0x109
	.quad	.LFB36
	.quad	.LFE36-.LFB36
	.uleb128 0x1
	.byte	0x9c
	.long	0x48b
	.uleb128 0x1
	.long	.LASF33
	.byte	0x1
	.byte	0xd9
	.byte	0x7
	.long	0x238
	.uleb128 0x3
	.byte	0x91
	.sleb128 -144
	.uleb128 0x1
	.long	.LASF19
	.byte	0x1
	.byte	0xd9
	.byte	0x16
	.long	0xea
	.uleb128 0x5
	.byte	0x91
	.sleb128 -128
	.byte	0x23
	.uleb128 0x28
	.uleb128 0x1
	.long	.LASF39
	.byte	0x1
	.byte	0xd9
	.byte	0x30
	.long	0xd0
	.uleb128 0x5
	.byte	0x91
	.sleb128 -128
	.byte	0x23
	.uleb128 0x35
	.uleb128 0x1
	.long	.LASF20
	.byte	0x1
	.byte	0xda
	.byte	0x7
	.long	0x12b
	.uleb128 0x5
	.byte	0x91
	.sleb128 -128
	.byte	0x23
	.uleb128 0x34
	.uleb128 0x12
	.long	.LLRL1
	.uleb128 0x14
	.long	.LASF48
	.quad	.LFB37
	.quad	.LFE37-.LFB37
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -152
	.byte	0x6
	.byte	0x23
	.uleb128 0x38
	.byte	0x6
	.uleb128 0x12
	.long	.LLRL0
	.uleb128 0x7
	.long	.LASF40
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x7
	.long	.LASF41
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x9
	.long	0x6d
	.long	0x412
	.uleb128 0x1c
	.long	0x51
	.long	0x3e1
	.long	0x3ee
	.byte	0
	.uleb128 0x6
	.long	.LASF42
	.byte	0xe8
	.byte	0x7
	.long	0x421
	.uleb128 0x3
	.byte	0x91
	.sleb128 -104
	.uleb128 0x11
	.long	0x3fb
	.uleb128 0x2
	.quad	.LBB79
	.quad	.LBE79-.LBB79
	.uleb128 0x6
	.long	.LASF43
	.byte	0xef
	.byte	0xb
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x2
	.quad	.LBB80
	.quad	.LBE80-.LBB80
	.uleb128 0x7
	.long	.LASF44
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -108
	.uleb128 0x2
	.quad	.LBB81
	.quad	.LBE81-.LBB81
	.uleb128 0x6
	.long	.LASF45
	.byte	0xf1
	.byte	0x15
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x13
	.long	.LASF47
	.byte	0xb8
	.long	0xea
	.quad	.LFB34
	.quad	.LFE34-.LFB34
	.uleb128 0x1
	.byte	0x9c
	.long	0x521
	.uleb128 0x1
	.long	.LASF33
	.byte	0x1
	.byte	0xb8
	.byte	0x1b
	.long	0x233
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x1
	.long	.LASF19
	.byte	0x1
	.byte	0xb8
	.byte	0x2a
	.long	0xea
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x2
	.quad	.LBB72
	.quad	.LBE72-.LBB72
	.uleb128 0x14
	.long	.LASF49
	.quad	.LFB35
	.quad	.LFE35-.LFB35
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x2
	.quad	.LBB66
	.quad	.LBE66-.LBB66
	.uleb128 0x6
	.long	.LASF50
	.byte	0xc1
	.byte	0x7
	.long	0xea
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x13
	.long	.LASF51
	.byte	0xa1
	.long	0xea
	.quad	.LFB32
	.quad	.LFE32-.LFB32
	.uleb128 0x1
	.byte	0x9c
	.long	0x5b7
	.uleb128 0x1
	.long	.LASF33
	.byte	0x1
	.byte	0xa1
	.byte	0x1c
	.long	0x22e
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x1
	.long	.LASF19
	.byte	0x1
	.byte	0xa1
	.byte	0x2b
	.long	0xea
	.uleb128 0x5
	.byte	0x91
	.sleb128 -112
	.byte	0x23
	.uleb128 0x10
	.uleb128 0x2
	.quad	.LBB60
	.quad	.LBE60-.LBB60
	.uleb128 0x14
	.long	.LASF52
	.quad	.LFB33
	.quad	.LFE33-.LFB33
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0x23
	.uleb128 0x20
	.byte	0x6
	.uleb128 0x2
	.quad	.LBB55
	.quad	.LBE55-.LBB55
	.uleb128 0x6
	.long	.LASF50
	.byte	0xaa
	.byte	0x7
	.long	0xea
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0xb
	.long	.LASF53
	.byte	0x9c
	.long	.LASF55
	.long	0x12b
	.quad	.LFB30
	.quad	.LFE30-.LFB30
	.uleb128 0x1
	.byte	0x9c
	.long	0x5ec
	.uleb128 0x1
	.long	.LASF34
	.byte	0x2
	.byte	0x53
	.byte	0x18
	.long	0x229
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.byte	0
	.uleb128 0xb
	.long	.LASF54
	.byte	0x8b
	.long	.LASF56
	.long	0x12b
	.quad	.LFB27
	.quad	.LFE27-.LFB27
	.uleb128 0x1
	.byte	0x9c
	.long	0x641
	.uleb128 0x1
	.long	.LASF33
	.byte	0x1
	.byte	0x81
	.byte	0x7
	.long	0x224
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x1
	.long	.LASF19
	.byte	0x1
	.byte	0x81
	.byte	0x16
	.long	0xf5
	.uleb128 0x3
	.byte	0x91
	.sleb128 -132
	.uleb128 0x1
	.long	.LASF38
	.byte	0x1
	.byte	0x81
	.byte	0x29
	.long	0x104
	.uleb128 0x3
	.byte	0x91
	.sleb128 -136
	.byte	0
	.uleb128 0xb
	.long	.LASF57
	.byte	0x71
	.long	.LASF58
	.long	0x12b
	.quad	.LFB26
	.quad	.LFE26-.LFB26
	.uleb128 0x1
	.byte	0x9c
	.long	0x6f3
	.uleb128 0x1
	.long	.LASF33
	.byte	0x1
	.byte	0x66
	.byte	0x7
	.long	0x21f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x1
	.long	.LASF19
	.byte	0x1
	.byte	0x66
	.byte	0x16
	.long	0xf5
	.uleb128 0x3
	.byte	0x91
	.sleb128 -100
	.uleb128 0x1
	.long	.LASF42
	.byte	0x1
	.byte	0x66
	.byte	0x29
	.long	0x21a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x1
	.long	.LASF59
	.byte	0x1
	.byte	0x66
	.byte	0x38
	.long	0x132
	.uleb128 0x3
	.byte	0x91
	.sleb128 -101
	.uleb128 0x2
	.quad	.LBB40
	.quad	.LBE40-.LBB40
	.uleb128 0x7
	.long	.LASF60
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x7
	.long	.LASF61
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x2
	.quad	.LBB46
	.quad	.LBE46-.LBB46
	.uleb128 0x6
	.long	.LASF43
	.byte	0x77
	.byte	0x12
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0xb
	.long	.LASF62
	.byte	0x5b
	.long	.LASF63
	.long	0xea
	.quad	.LFB23
	.quad	.LFE23-.LFB23
	.uleb128 0x1
	.byte	0x9c
	.long	0x76e
	.uleb128 0x1
	.long	.LASF33
	.byte	0x1
	.byte	0x51
	.byte	0x19
	.long	0x215
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF19
	.byte	0x1
	.byte	0x51
	.byte	0x28
	.long	0xf5
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x2
	.quad	.LBB33
	.quad	.LBE33-.LBB33
	.uleb128 0xc
	.long	.LASF66
	.long	0xea
	.quad	.LFB25
	.quad	.LFE25-.LFB25
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -56
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.byte	0
	.byte	0
	.uleb128 0xb
	.long	.LASF64
	.byte	0x4b
	.long	.LASF65
	.long	0xea
	.quad	.LFB20
	.quad	.LFE20-.LFB20
	.uleb128 0x1
	.byte	0x9c
	.long	0x7e9
	.uleb128 0x1
	.long	.LASF33
	.byte	0x1
	.byte	0x41
	.byte	0x1a
	.long	0x210
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x1
	.long	.LASF19
	.byte	0x1
	.byte	0x41
	.byte	0x29
	.long	0xf5
	.uleb128 0x5
	.byte	0x91
	.sleb128 -96
	.byte	0x23
	.uleb128 0x8
	.uleb128 0x2
	.quad	.LBB26
	.quad	.LBE26-.LBB26
	.uleb128 0xc
	.long	.LASF67
	.long	0xea
	.quad	.LFB22
	.quad	.LFE22-.LFB22
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -40
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.byte	0
	.byte	0
	.uleb128 0x5
	.long	.LASF68
	.byte	0x2f
	.long	0x1c8
	.quad	.LFB18
	.quad	.LFE18-.LFB18
	.uleb128 0x1
	.byte	0x9c
	.long	0x892
	.uleb128 0x1
	.long	.LASF34
	.byte	0x1
	.byte	0x2f
	.byte	0x19
	.long	0x20b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x2
	.quad	.LBB20
	.quad	.LBE20-.LBB20
	.uleb128 0x1b
	.long	.LASF70
	.long	0x1c8
	.quad	.LFB19
	.quad	.LFE19-.LFB19
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -104
	.byte	0x6
	.byte	0x23
	.uleb128 0x10
	.byte	0x6
	.uleb128 0x2
	.quad	.LBB19
	.quad	.LBE19-.LBB19
	.uleb128 0x7
	.long	.LASF71
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x9
	.long	0x6d
	.long	0x87e
	.uleb128 0x24
	.long	0x51
	.long	0x85e
	.byte	0
	.uleb128 0x6
	.long	.LASF33
	.byte	0x37
	.byte	0x7
	.long	0x86b
	.uleb128 0x4
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x5
	.long	.LASF72
	.byte	0x2a
	.long	0x6d
	.quad	.LFB16
	.quad	.LFE16-.LFB16
	.uleb128 0x1
	.byte	0x9c
	.long	0x8e4
	.uleb128 0x1
	.long	.LASF37
	.byte	0x2
	.byte	0x1f
	.byte	0x18
	.long	0x74
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.uleb128 0xc
	.long	.LASF73
	.long	0x6d
	.quad	.LFB17
	.quad	.LFE17-.LFB17
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -24
	.byte	0x6
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0
	.uleb128 0x5
	.long	.LASF74
	.byte	0x24
	.long	0x12b
	.quad	.LFB14
	.quad	.LFE14-.LFB14
	.uleb128 0x1
	.byte	0x9c
	.long	0x936
	.uleb128 0x1
	.long	.LASF37
	.byte	0x2
	.byte	0x14
	.byte	0x26
	.long	0x74
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0xe
	.long	.LASF75
	.long	0x12b
	.quad	.LFB15
	.quad	.LFE15-.LFB15
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -24
	.byte	0x6
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0
	.uleb128 0x5
	.long	.LASF76
	.byte	0x21
	.long	0x12b
	.quad	.LFB12
	.quad	.LFE12-.LFB12
	.uleb128 0x1
	.byte	0x9c
	.long	0x988
	.uleb128 0x1
	.long	.LASF37
	.byte	0x2
	.byte	0x1b
	.byte	0x1d
	.long	0x74
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0xe
	.long	.LASF77
	.long	0x12b
	.quad	.LFB13
	.quad	.LFE13-.LFB13
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -24
	.byte	0x6
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0
	.uleb128 0x5
	.long	.LASF78
	.byte	0x1e
	.long	0x12b
	.quad	.LFB10
	.quad	.LFE10-.LFB10
	.uleb128 0x1
	.byte	0x9c
	.long	0x9da
	.uleb128 0x1
	.long	.LASF37
	.byte	0x2
	.byte	0xd
	.byte	0x23
	.long	0x74
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0xc
	.long	.LASF79
	.long	0x12b
	.quad	.LFB11
	.quad	.LFE11-.LFB11
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -24
	.byte	0x6
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0
	.uleb128 0x5
	.long	.LASF80
	.byte	0x18
	.long	0x12b
	.quad	.LFB8
	.quad	.LFE8-.LFB8
	.uleb128 0x1
	.byte	0x9c
	.long	0xa2c
	.uleb128 0x1
	.long	.LASF37
	.byte	0x2
	.byte	0x8
	.byte	0x1c
	.long	0x74
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0xe
	.long	.LASF81
	.long	0x12b
	.quad	.LFB9
	.quad	.LFE9-.LFB9
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -24
	.byte	0x6
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0
	.uleb128 0x5
	.long	.LASF82
	.byte	0x9
	.long	0x1c8
	.quad	.LFB6
	.quad	.LFE6-.LFB6
	.uleb128 0x1
	.byte	0x9c
	.long	0xa7f
	.uleb128 0x1
	.long	.LASF39
	.byte	0x2
	.byte	0x4c
	.byte	0x17
	.long	0xd0
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0xc
	.long	.LASF83
	.long	0x1c8
	.quad	.LFB7
	.quad	.LFE7-.LFB7
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -40
	.byte	0x6
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0
	.uleb128 0x25
	.long	.LASF88
	.byte	0x1
	.byte	0x6
	.byte	0x4
	.long	0x12b
	.quad	.LFB4
	.quad	.LFE4-.LFB4
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x1
	.long	.LASF39
	.byte	0x2
	.byte	0x33
	.byte	0x1c
	.long	0xd0
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0xe
	.long	.LASF84
	.long	0x12b
	.quad	.LFB5
	.quad	.LFE5-.LFB5
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -24
	.byte	0x6
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x28
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x1c
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 10
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x10
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x55
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x14
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x15
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0x16
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x17
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x3e
	.uleb128 0x21
	.sleb128 5
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x18
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x19
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1a
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x1b
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x1c
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1d
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x55
	.uleb128 0x17
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x1e
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1f
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x20
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x21
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x22
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x18
	.uleb128 0x2f
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x23
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x24
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x25
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x5c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.LFE27-.Ltext0
	.quad	.LFB30
	.quad	.LFE34-.LFB30
	.quad	.LFB37
	.quad	.LFE36-.LFB37
	.quad	.LFB41
	.quad	.Letext0-.LFB41
	.quad	0
	.quad	0
	.section	.debug_rnglists,"",@progbits
.Ldebug_ranges0:
	.long	.Ldebug_ranges3-.Ldebug_ranges2
.Ldebug_ranges2:
	.value	0x5
	.byte	0x8
	.byte	0
	.long	0
.LLRL0:
	.byte	0x5
	.quad	.LBB78
	.byte	0x4
	.uleb128 .LBB78-.LBB78
	.uleb128 .LBE78-.LBB78
	.byte	0x4
	.uleb128 .LBB84-.LBB78
	.uleb128 .LBE84-.LBB78
	.byte	0
.LLRL1:
	.byte	0x5
	.quad	.LBB85
	.byte	0x4
	.uleb128 .LBB85-.LBB85
	.uleb128 .LBE85-.LBB85
	.byte	0x4
	.uleb128 .LBB94-.LBB85
	.uleb128 .LBE94-.LBB85
	.byte	0
.LLRL2:
	.byte	0x5
	.quad	.LBB95
	.byte	0x4
	.uleb128 .LBB95-.LBB95
	.uleb128 .LBE95-.LBB95
	.byte	0x4
	.uleb128 .LBB101-.LBB95
	.uleb128 .LBE101-.LBB95
	.byte	0
.LLRL3:
	.byte	0x7
	.quad	.Ltext0
	.uleb128 .LFE27-.Ltext0
	.byte	0x7
	.quad	.LFB30
	.uleb128 .LFE34-.LFB30
	.byte	0x7
	.quad	.LFB37
	.uleb128 .LFE36-.LFB37
	.byte	0x7
	.quad	.LFB41
	.uleb128 .Letext0-.LFB41
	.byte	0
.Ldebug_ranges3:
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF42:
	.string	"word"
.LASF13:
	.string	"silver_profile__left_parenthesis"
.LASF39:
	.string	"token"
.LASF77:
	.string	"silver_profile__is_comment_end___wrapped_statements"
.LASF38:
	.string	"next_token"
.LASF29:
	.string	"P_ARRAY"
.LASF54:
	.string	"silver_profile__suffix_matches"
.LASF33:
	.string	"text"
.LASF76:
	.string	"silver_profile__is_comment_end"
.LASF2:
	.string	"integer"
.LASF56:
	.string	"___ghost_silver_profile__suffix_matches"
.LASF66:
	.string	"silver_profile__trivia_end___wrapped_statements"
.LASF57:
	.string	"silver_profile__token_at"
.LASF20:
	.string	"matched"
.LASF70:
	.string	"silver_profile__normalized___wrapped_statements"
.LASF9:
	.string	"silver_profile__on_name"
.LASF25:
	.string	"system__storage_elements__storage_element"
.LASF31:
	.string	"silver_profile__allowed_source"
.LASF53:
	.string	"silver_profile__is_member"
.LASF86:
	.string	"silver_profile__token_kind"
.LASF22:
	.string	"system__address"
.LASF43:
	.string	"index"
.LASF78:
	.string	"silver_profile__is_allowed_character"
.LASF6:
	.string	"silver_profile__is_keyword"
.LASF74:
	.string	"silver_profile__is_identifier_character"
.LASF45:
	.string	"previous"
.LASF81:
	.string	"silver_profile__is_whitespace___wrapped_statements"
.LASF4:
	.string	"silver_profile__procedure_keyword"
.LASF59:
	.string	"is_word"
.LASF58:
	.string	"___ghost_silver_profile__token_at"
.LASF23:
	.string	"system__storage_elements__Tstorage_offsetB"
.LASF51:
	.string	"silver_profile__skip_comment"
.LASF87:
	.string	"string"
.LASF24:
	.string	"system__parameters__Tsize_typeB"
.LASF80:
	.string	"silver_profile__is_whitespace"
.LASF34:
	.string	"source"
.LASF3:
	.string	"character"
.LASF32:
	.string	"silver_profile__accepts"
.LASF14:
	.string	"silver_profile__right_parenthesis"
.LASF30:
	.string	"P_BOUNDS"
.LASF84:
	.string	"silver_profile__is_word_token___wrapped_statements"
.LASF62:
	.string	"silver_profile__trivia_end"
.LASF73:
	.string	"silver_profile__lowercase___wrapped_statements"
.LASF47:
	.string	"silver_profile__skip_trivia"
.LASF41:
	.string	"B233b"
.LASF50:
	.string	"initial_position"
.LASF46:
	.string	"silver_profile__match_token"
.LASF27:
	.string	"silver_profile__comment_introducer"
.LASF28:
	.string	"silver_profile__required_tokens"
.LASF49:
	.string	"silver_profile__skip_trivia___wrapped_statements"
.LASF75:
	.string	"silver_profile__is_identifier_character___wrapped_statements"
.LASF44:
	.string	"___ghost_silver_profile__match_token___wrapped_statements__L_3__B242b__L243b__T244b___U"
.LASF82:
	.string	"silver_profile__spelling"
.LASF17:
	.string	"silver_profile__cursor"
.LASF35:
	.string	"B276b"
.LASF48:
	.string	"silver_profile__match_token___wrapped_statements"
.LASF60:
	.string	"___ghost_silver_profile__token_at__B153b__L154b__T155b___L"
.LASF7:
	.string	"silver_profile__pragma_keyword"
.LASF88:
	.string	"silver_profile__is_word_token"
.LASF61:
	.string	"___ghost_silver_profile__token_at__B153b__L154b__T155b___U"
.LASF63:
	.string	"___ghost_silver_profile__trivia_end"
.LASF85:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF8:
	.string	"silver_profile__spark_mode_name"
.LASF11:
	.string	"silver_profile__null_keyword"
.LASF52:
	.string	"silver_profile__skip_comment___wrapped_statements"
.LASF15:
	.string	"silver_profile__semicolon"
.LASF26:
	.string	"silver_profile__max_source_length"
.LASF65:
	.string	"___ghost_silver_profile__comment_end"
.LASF16:
	.string	"positive"
.LASF55:
	.string	"___ghost_silver_profile__is_member"
.LASF79:
	.string	"silver_profile__is_allowed_character___wrapped_statements"
.LASF72:
	.string	"silver_profile__lowercase"
.LASF18:
	.string	"silver_profile__token_index"
.LASF68:
	.string	"silver_profile__normalized"
.LASF71:
	.string	"silver_profile__normalized___wrapped_statements__TTtextSP1___U"
.LASF37:
	.string	"item"
.LASF83:
	.string	"silver_profile__spelling___wrapped_statements"
.LASF67:
	.string	"silver_profile__comment_end___wrapped_statements"
.LASF10:
	.string	"silver_profile__begin_keyword"
.LASF36:
	.string	"B280b"
.LASF19:
	.string	"position"
.LASF12:
	.string	"silver_profile__end_keyword"
.LASF5:
	.string	"silver_profile__main_name"
.LASF69:
	.string	"silver_profile__accepts___wrapped_statements"
.LASF40:
	.string	"B229b"
.LASF64:
	.string	"silver_profile__comment_end"
.LASF21:
	.string	"boolean"
	.section	.debug_line_str,"MS",@progbits,1
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_profile.adb"
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
	.hidden	DW.ref.__gnat_personality_v0
	.weak	DW.ref.__gnat_personality_v0
	.section	.data.rel.local.DW.ref.__gnat_personality_v0,"awG",@progbits,DW.ref.__gnat_personality_v0,comdat
	.align 8
	.type	DW.ref.__gnat_personality_v0, @object
	.size	DW.ref.__gnat_personality_v0, 8
DW.ref.__gnat_personality_v0:
	.quad	__gnat_personality_v0
	.globl	__gnat_personality_v0
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
