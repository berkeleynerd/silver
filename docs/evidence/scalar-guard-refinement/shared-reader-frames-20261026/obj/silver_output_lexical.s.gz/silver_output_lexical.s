	.file	"silver_output_lexical.adb"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_output_lexical.adb"
	.section	.rodata
	.align 8
.LC4:
	.ascii	"failed precondition from silver_output_lexical.ads:137"
	.align 8
.LC5:
	.ascii	"failed precondition from silver_output_lexical.ads:138"
.LC6:
	.ascii	"silver_output_lexical.ads"
	.zero	1
	.align 8
.LC7:
	.ascii	"failed precondition from silver_output_lexical.ads:139"
	.align 8
.LC0:
	.long	1
	.long	54
	.text
	.align 2
	.globl	silver_output_lexical__name_is
	.type	silver_output_lexical__name_is, @function
silver_output_lexical__name_is:
.LFB2:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_output_lexical.ads"
	.loc 1 141 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$152, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r10
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r10, %rdi
	movq	%rsi, -80(%rbp)
	movq	%rdi, -72(%rbp)
	movl	%edx, -84(%rbp)
	movl	%ecx, -88(%rbp)
	movq	%r8, -112(%rbp)
	movq	%r9, -104(%rbp)
	.loc 1 141 4
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -96(%rbp)
	movq	-72(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -92(%rbp)
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L2
	.loc 1 141 4 is_stmt 0 discriminator 1
	movq	-72(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %r8
	movq	%rdx, %r9
	jmp	.L3
.L2:
	.loc 1 141 4 discriminator 2
	movl	$0, %r8d
	movl	$0, %r9d
.L3:
	.loc 1 141 4 discriminator 3
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -116(%rbp)
	movq	-104(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -120(%rbp)
	movq	-104(%rbp), %rax
	movl	4(%rax), %edx
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L4
	.loc 1 141 4 discriminator 4
	movq	-104(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rsi
	movq	%rdx, %rdi
	jmp	.L5
.L4:
	.loc 1 141 4 discriminator 5
	movl	$0, %esi
	movl	$0, %edi
.L5:
.LBB2:
	.loc 1 137 15 is_stmt 1
	cmpl	$1, -96(%rbp)
	je	.L6
.LBB3:
	.loc 1 137 15 is_stmt 0 discriminator 1
	leaq	.LC4(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L6:
.LBE3:
	.loc 1 137 51 is_stmt 1 discriminator 2
	movl	%r8d, %eax
	.loc 1 137 15 discriminator 2
	testl	%eax, %eax
	jle	.L7
	.loc 1 137 51 discriminator 3
	movl	%r8d, %eax
	cmpl	$4096, %eax
	jle	.L8
.L7:
.LBB4:
	.loc 1 137 15 discriminator 4
	leaq	.LC4(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L8:
.LBE4:
	.loc 1 137 15 is_stmt 0 discriminator 5
	movl	-84(%rbp), %eax
	cmpl	-88(%rbp), %eax
	jl	.L9
.LBB5:
	.loc 1 137 15 discriminator 6
	leaq	.LC5(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rbx
	movq	-184(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L9:
.LBE5:
	.loc 1 138 61 is_stmt 1
	cmpl	$2147483647, -92(%rbp)
	jne	.L10
	.loc 1 138 61 is_stmt 0 discriminator 1
	leaq	.LC6(%rip), %rax
	movl	$138, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L10:
	.loc 1 138 61 discriminator 3
	movl	-92(%rbp), %eax
	addl	$1, %eax
	.loc 1 137 15 is_stmt 1 discriminator 7
	cmpl	-88(%rbp), %eax
	jge	.L11
.LBB6:
	.loc 1 137 15 is_stmt 0 discriminator 8
	leaq	.LC5(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L11:
.LBE6:
	.loc 1 137 15 discriminator 9
	cmpl	$1, -116(%rbp)
	je	.L12
.LBB7:
	.loc 1 137 15 discriminator 10
	leaq	.LC7(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L12:
.LBE7:
	.loc 1 139 55 is_stmt 1
	movl	%esi, %eax
	.loc 1 137 15 discriminator 11
	testl	%eax, %eax
	jle	.L13
	.loc 1 139 55 discriminator 1
	movl	%esi, %eax
	cmpl	$4096, %eax
	jle	.L14
.L13:
.LBB8:
	.loc 1 137 15 discriminator 12
	leaq	.LC7(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L14:
.LBE8:
	.loc 1 144 13
	movl	-88(%rbp), %eax
	subl	-84(%rbp), %eax
	.loc 1 144 21
	movl	%esi, %edx
	.loc 1 145 7
	cmpl	%edx, %eax
	jne	.L15
	.loc 1 145 17 discriminator 1
	movl	$1, %ebx
	.loc 1 145 52 discriminator 1
	movl	%esi, %eax
	.loc 1 145 25 discriminator 1
	subl	$1, %eax
	movl	%eax, -56(%rbp)
	.loc 1 145 17 discriminator 1
	cmpl	$0, -56(%rbp)
	js	.L16
.LBB9:
	.loc 1 145 25 discriminator 2
	movl	$0, -52(%rbp)
.L27:
	.loc 1 146 32
	movl	$0, %ecx
	movl	-84(%rbp), %edx
	movl	-52(%rbp), %eax
	addl	%edx, %eax
	jno	.L17
	movl	$1, %ecx
.L17:
	movl	%eax, %edx
	.loc 1 146 32 is_stmt 0 discriminator 1
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L19
	.loc 1 146 32 discriminator 2
	leaq	.LC6(%rip), %rax
	movl	$146, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L19:
	.loc 1 146 32 discriminator 4
	movl	%edx, %eax
	.loc 1 146 20 is_stmt 1 discriminator 5
	movl	-96(%rbp), %edi
	cmpl	%edi, %eax
	jl	.L20
	.loc 1 146 20 is_stmt 0 discriminator 6
	movl	-92(%rbp), %edi
	cmpl	%edi, %eax
	jle	.L21
.L20:
	.loc 1 146 20 discriminator 7
	leaq	.LC6(%rip), %rax
	movl	$146, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L21:
	.loc 1 146 53 is_stmt 1 discriminator 8
	cmpl	$2147483647, -52(%rbp)
	jne	.L22
	.loc 1 146 53 is_stmt 0 discriminator 9
	leaq	.LC6(%rip), %rax
	movl	$146, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L22:
	.loc 1 146 53 discriminator 11
	movl	-52(%rbp), %eax
	addl	$1, %eax
	.loc 1 146 45 is_stmt 1 discriminator 12
	movl	-116(%rbp), %edi
	cmpl	%edi, %eax
	jl	.L23
	.loc 1 146 45 is_stmt 0 discriminator 13
	movl	-120(%rbp), %edi
	cmpl	%edi, %eax
	jle	.L24
.L23:
	.loc 1 146 45 discriminator 14
	leaq	.LC6(%rip), %rax
	movl	$146, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L24:
	.loc 1 146 9 is_stmt 1 discriminator 15
	movq	-80(%rbp), %rax
	movq	-72(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 1 146 32 discriminator 15
	movl	-84(%rbp), %esi
	movl	-52(%rbp), %ecx
	addl	%esi, %ecx
	movslq	%ecx, %rcx
	.loc 1 146 9 discriminator 15
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__lowercase@PLT
	.loc 1 146 43 discriminator 16
	movq	-112(%rbp), %rdx
	movq	-104(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	.loc 1 146 53 discriminator 16
	movl	-52(%rbp), %esi
	addl	$1, %esi
	movslq	%esi, %rsi
	.loc 1 146 43 discriminator 16
	subq	%rcx, %rsi
	movzbl	(%rdx,%rsi), %edx
	.loc 1 145 17 discriminator 3
	cmpb	%dl, %al
	je	.L25
	.loc 1 145 17 is_stmt 0 discriminator 4
	movl	$0, %ebx
	jmp	.L16
.L25:
	.loc 1 145 17 discriminator 5
	movl	-52(%rbp), %eax
	cmpl	-56(%rbp), %eax
	je	.L16
	.loc 1 145 17 discriminator 6
	addl	$1, -52(%rbp)
	jmp	.L27
.L16:
.LBE9:
	.loc 1 145 7 is_stmt 1 discriminator 7
	testb	%bl, %bl
	je	.L15
	.loc 1 145 7 is_stmt 0 discriminator 8
	movl	$1, %eax
	jmp	.L28
.L15:
	.loc 1 145 7 discriminator 9
	movl	$0, %eax
.L28:
.LBE2:
	.loc 1 141 4 is_stmt 1
	addq	$152, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	silver_output_lexical__name_is, .-silver_output_lexical__name_is
	.section	.rodata
	.align 8
.LC8:
	.ascii	"failed precondition from silver_output_lexical.ads:152"
	.align 8
.LC9:
	.ascii	"failed precondition from silver_output_lexical.ads:153"
	.align 8
.LC10:
	.ascii	"failed precondition from silver_output_lexical.ads:154"
	.text
	.align 2
	.globl	silver_output_lexical__equal_name
	.type	silver_output_lexical__equal_name, @function
silver_output_lexical__equal_name:
.LFB3:
	.loc 1 156 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$136, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r10
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r10, %rdi
	movq	%rsi, -80(%rbp)
	movq	%rdi, -72(%rbp)
	movl	%edx, -84(%rbp)
	movl	%ecx, -88(%rbp)
	movl	%r8d, -92(%rbp)
	movl	%r9d, -96(%rbp)
	.loc 1 156 4
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	movl	%eax, -100(%rbp)
	movq	-72(%rbp), %rax
	movl	4(%rax), %r13d
	movq	-72(%rbp), %rax
	movl	4(%rax), %edx
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L31
	.loc 1 156 4 is_stmt 0 discriminator 1
	movq	-72(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-72(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L32
.L31:
	.loc 1 156 4 discriminator 2
	movl	$0, %eax
	movl	$0, %edx
.L32:
.LBB10:
	.loc 1 152 15 is_stmt 1
	cmpl	$1, -100(%rbp)
	je	.L33
.LBB11:
	.loc 1 152 15 is_stmt 0 discriminator 1
	leaq	.LC8(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L33:
.LBE11:
	.loc 1 152 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 1 152 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L34
	.loc 1 152 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L35
.L34:
.LBB12:
	.loc 1 152 15 discriminator 4
	leaq	.LC8(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rbx
	movq	-168(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L35:
.LBE12:
	.loc 1 152 15 is_stmt 0 discriminator 5
	movl	-84(%rbp), %eax
	cmpl	-88(%rbp), %eax
	jl	.L36
.LBB13:
	.loc 1 152 15 discriminator 6
	leaq	.LC9(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L36:
.LBE13:
	.loc 1 153 76 is_stmt 1
	cmpl	$2147483647, %r13d
	jne	.L37
	.loc 1 153 76 is_stmt 0 discriminator 1
	leaq	.LC6(%rip), %rax
	movl	$153, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L37:
	.loc 1 153 76 discriminator 3
	leal	1(%r13), %eax
	.loc 1 152 15 is_stmt 1 discriminator 7
	cmpl	-88(%rbp), %eax
	jge	.L38
.LBB14:
	.loc 1 152 15 is_stmt 0 discriminator 8
	leaq	.LC9(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L38:
.LBE14:
	.loc 1 152 15 discriminator 9
	movl	-92(%rbp), %eax
	cmpl	-96(%rbp), %eax
	jl	.L39
.LBB15:
	.loc 1 152 15 discriminator 10
	leaq	.LC10(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L39:
.LBE15:
	.loc 1 154 79 is_stmt 1
	cmpl	$2147483647, %r13d
	jne	.L40
	.loc 1 154 79 is_stmt 0 discriminator 1
	leaq	.LC6(%rip), %rax
	movl	$154, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L40:
	.loc 1 154 79 discriminator 3
	leal	1(%r13), %eax
	.loc 1 152 15 is_stmt 1 discriminator 11
	cmpl	-96(%rbp), %eax
	jge	.L41
.LBB16:
	.loc 1 152 15 is_stmt 0 discriminator 12
	leaq	.LC10(%rip), %r11
	leaq	.LC0(%rip), %r12
	movq	%r11, %rdx
	movq	%r12, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L41:
.LBE16:
	.loc 1 160 18 is_stmt 1
	movl	-88(%rbp), %eax
	subl	-84(%rbp), %eax
	movl	%eax, %edx
	.loc 1 160 45
	movl	-96(%rbp), %eax
	subl	-92(%rbp), %eax
	.loc 1 161 7
	cmpl	%eax, %edx
	jne	.L42
	.loc 1 161 17 discriminator 1
	movl	$1, %ebx
	.loc 1 161 52 discriminator 1
	movl	-88(%rbp), %eax
	subl	-84(%rbp), %eax
	.loc 1 161 25 discriminator 1
	subl	$1, %eax
	movl	%eax, -56(%rbp)
	.loc 1 161 17 discriminator 1
	cmpl	$0, -56(%rbp)
	js	.L43
.LBB17:
	.loc 1 161 25 discriminator 2
	movl	$0, -52(%rbp)
.L56:
	.loc 1 162 37
	movl	$0, %ecx
	movl	-84(%rbp), %edx
	movl	-52(%rbp), %eax
	addl	%edx, %eax
	jno	.L44
	movl	$1, %ecx
.L44:
	movl	%eax, %edx
	.loc 1 162 37 is_stmt 0 discriminator 1
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L46
	.loc 1 162 37 discriminator 2
	leaq	.LC6(%rip), %rax
	movl	$162, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L46:
	.loc 1 162 37 discriminator 4
	movl	%edx, %eax
	.loc 1 162 20 is_stmt 1 discriminator 5
	movl	-100(%rbp), %edi
	cmpl	%edi, %eax
	jl	.L47
	.loc 1 162 20 is_stmt 0 discriminator 6
	cmpl	%r13d, %eax
	jle	.L48
.L47:
	.loc 1 162 20 discriminator 7
	leaq	.LC6(%rip), %rax
	movl	$162, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L48:
	.loc 1 162 79 is_stmt 1 discriminator 8
	movl	$0, %ecx
	movl	-92(%rbp), %edx
	movl	-52(%rbp), %eax
	addl	%edx, %eax
	jno	.L49
	movl	$1, %ecx
.L49:
	movl	%eax, %edx
	.loc 1 162 79 is_stmt 0 discriminator 9
	movl	%ecx, %eax
	testl	%eax, %eax
	je	.L51
	.loc 1 162 79 discriminator 10
	leaq	.LC6(%rip), %rax
	movl	$162, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L51:
	.loc 1 162 79 discriminator 12
	movl	%edx, %eax
	.loc 1 162 61 is_stmt 1 discriminator 13
	movl	-100(%rbp), %edi
	cmpl	%edi, %eax
	jl	.L52
	.loc 1 162 61 is_stmt 0 discriminator 14
	cmpl	%r13d, %eax
	jle	.L53
.L52:
	.loc 1 162 61 discriminator 15
	leaq	.LC6(%rip), %rax
	movl	$162, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L53:
	.loc 1 162 9 is_stmt 1 discriminator 16
	movq	-80(%rbp), %rax
	movq	-72(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 1 162 37 discriminator 16
	movl	-84(%rbp), %esi
	movl	-52(%rbp), %ecx
	addl	%esi, %ecx
	movslq	%ecx, %rcx
	.loc 1 162 9 discriminator 16
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__lowercase@PLT
	.loc 1 162 9 is_stmt 0 discriminator 17
	movl	%eax, %r12d
	.loc 1 162 50 is_stmt 1 discriminator 17
	movq	-80(%rbp), %rax
	movq	-72(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	.loc 1 162 79 discriminator 17
	movl	-92(%rbp), %esi
	movl	-52(%rbp), %ecx
	addl	%esi, %ecx
	movslq	%ecx, %rcx
	.loc 1 162 50 discriminator 17
	subq	%rdx, %rcx
	movzbl	(%rax,%rcx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__lowercase@PLT
	.loc 1 161 17 discriminator 3
	cmpb	%al, %r12b
	je	.L54
	.loc 1 161 17 is_stmt 0 discriminator 4
	movl	$0, %ebx
	jmp	.L43
.L54:
	.loc 1 161 17 discriminator 5
	movl	-52(%rbp), %eax
	cmpl	-56(%rbp), %eax
	je	.L43
	.loc 1 161 17 discriminator 6
	addl	$1, -52(%rbp)
	jmp	.L56
.L43:
.LBE17:
	.loc 1 161 7 is_stmt 1 discriminator 7
	testb	%bl, %bl
	je	.L42
	.loc 1 161 7 is_stmt 0 discriminator 8
	movl	$1, %eax
	jmp	.L57
.L42:
	.loc 1 161 7 discriminator 9
	movl	$0, %eax
.L57:
.LBE10:
	.loc 1 156 4 is_stmt 1
	addq	$136, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.size	silver_output_lexical__equal_name, .-silver_output_lexical__equal_name
	.align 2
	.globl	silver_output_lexical__forbidden_kindH
	.type	silver_output_lexical__forbidden_kindH, @function
silver_output_lexical__forbidden_kindH:
.LFB4:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -16(%rbp)
	movq	%rdx, -8(%rbp)
	movq	-8(%rbp), %rax
	movl	(%rax), %eax
	movq	-8(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L60
	movl	%edx, %ecx
	subl	%eax, %ecx
	leal	1(%rcx), %r11d
	jmp	.L61
.L60:
	movl	$0, %r11d
.L61:
	movslq	%eax, %r9
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	leal	-1(%rax), %r10d
	movl	$0, %ecx
	movl	$0, %edx
	movl	$0, %eax
.L69:
	cmpl	$4, %eax
	jg	.L68
	movslq	%eax, %rsi
	leaq	0(,%rsi,4), %rdi
	leaq	forbidden_kindP.5(%rip), %rsi
	movl	(%rdi,%rsi), %esi
	cmpl	%esi, %r11d
	jl	.L68
	movq	-16(%rbp), %rsi
	movslq	%eax, %rdi
	leaq	0(,%rdi,4), %r8
	leaq	forbidden_kindP.5(%rip), %rdi
	movl	(%r8,%rdi), %edi
	addl	%r10d, %edi
	movslq	%edi, %rdi
	subq	%r9, %rdi
	movzbl	(%rsi,%rdi), %esi
	movzbl	%sil, %edi
	movslq	%eax, %rsi
	leaq	forbidden_kindT1.4(%rip), %r8
	movzbl	(%rsi,%r8), %esi
	movzbl	%sil, %esi
	imull	%edi, %esi
	addl	%ecx, %esi
	movslq	%esi, %rcx
	imulq	$892460737, %rcx, %rcx
	shrq	$32, %rcx
	sarl	$5, %ecx
	movl	%esi, %r8d
	sarl	$31, %r8d
	subl	%r8d, %ecx
	imull	$154, %ecx, %r8d
	movl	%esi, %ecx
	subl	%r8d, %ecx
	movslq	%eax, %rsi
	leaq	forbidden_kindT2.3(%rip), %r8
	movzbl	(%rsi,%r8), %esi
	movzbl	%sil, %esi
	imull	%edi, %esi
	addl	%edx, %esi
	movslq	%esi, %rdx
	imulq	$892460737, %rdx, %rdx
	shrq	$32, %rdx
	sarl	$5, %edx
	movl	%esi, %edi
	sarl	$31, %edi
	subl	%edi, %edx
	imull	$154, %edx, %edi
	movl	%esi, %edx
	subl	%edi, %edx
	addl	$1, %eax
	jmp	.L69
.L68:
	movslq	%ecx, %rax
	leaq	forbidden_kindG.2(%rip), %rcx
	movzbl	(%rax,%rcx), %eax
	movzbl	%al, %ecx
	movslq	%edx, %rax
	leaq	forbidden_kindG.2(%rip), %rdx
	movzbl	(%rax,%rdx), %eax
	movzbl	%al, %eax
	addl	%ecx, %eax
	movslq	%eax, %rdx
	imulq	$1808407283, %rdx, %rdx
	shrq	$32, %rdx
	sarl	$5, %edx
	movl	%eax, %ecx
	sarl	$31, %ecx
	subl	%ecx, %edx
	imull	$76, %edx, %ecx
	subl	%ecx, %eax
	movl	%eax, %edx
	movl	%edx, %eax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	silver_output_lexical__forbidden_kindH, .-silver_output_lexical__forbidden_kindH
	.align 2
	.type	silver_output_lexical__forbidden_name__B100s__L101s__B102s___finalizer.0, @function
silver_output_lexical__forbidden_name__B100s__L101s__B102s___finalizer.0:
.LFB6:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$16, %rsp
	movq	%r10, %rax
	movq	%r10, -8(%rbp)
	movq	%rax, %rdi
	call	system__secondary_stack__ss_release@PLT
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE6:
	.size	silver_output_lexical__forbidden_name__B100s__L101s__B102s___finalizer.0, .-silver_output_lexical__forbidden_name__B100s__L101s__B102s___finalizer.0
	.section	.rodata
	.align 8
.LC11:
	.ascii	"failed precondition from silver_output_lexical.ads:250"
	.align 8
.LC12:
	.ascii	"failed precondition from silver_output_lexical.ads:251"
	.text
	.align 2
	.globl	silver_output_lexical__forbidden_name
	.type	silver_output_lexical__forbidden_name, @function
silver_output_lexical__forbidden_name:
.LFB5:
	.loc 1 253 4
	.cfi_startproc
	.cfi_personality 0x9b,DW.ref.__gnat_personality_v0
	.cfi_lsda 0x1b,.LLSDA5
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
.LEHB0:
	subq	$120, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -112(%rbp)
	movq	%rdi, -104(%rbp)
	movl	%edx, -116(%rbp)
	movl	%ecx, -120(%rbp)
	.loc 1 253 4
	leaq	16(%rbp), %rax
	.loc 1 253 4 is_stmt 0 discriminator 1
	movq	%rax, -72(%rbp)
	movq	-104(%rbp), %rax
	movl	(%rax), %r9d
	movq	-104(%rbp), %rax
	movl	4(%rax), %r8d
	movq	-104(%rbp), %rax
	movl	4(%rax), %edx
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L74
	.loc 1 253 4 discriminator 2
	movq	-104(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-104(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L75
.L74:
	.loc 1 253 4 discriminator 3
	movl	$0, %eax
	movl	$0, %edx
.L75:
.LBB20:
	.loc 1 250 15 is_stmt 1
	cmpl	$1, %r9d
	je	.L76
.LBB21:
	.loc 1 250 15 is_stmt 0 discriminator 1
	leaq	.LC11(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L76:
.LBE21:
	.loc 1 250 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 1 250 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L77
	.loc 1 250 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L78
.L77:
.LBB22:
	.loc 1 250 15 discriminator 4
	leaq	.LC11(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L78:
.LBE22:
	.loc 1 250 15 is_stmt 0 discriminator 5
	movl	-116(%rbp), %eax
	cmpl	-120(%rbp), %eax
	jl	.L79
.LBB23:
	.loc 1 250 15 discriminator 6
	leaq	.LC12(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L79:
.LBE23:
	.loc 1 251 61 is_stmt 1
	cmpl	$2147483647, %r8d
	jne	.L80
	.loc 1 251 61 is_stmt 0 discriminator 1
	leaq	.LC6(%rip), %rax
	movl	$251, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L80:
	.loc 1 251 61 discriminator 3
	leal	1(%r8), %eax
	.loc 1 250 15 is_stmt 1 discriminator 7
	cmpl	-120(%rbp), %eax
	jge	.L81
.LBB24:
	.loc 1 250 15 is_stmt 0 discriminator 8
	leaq	.LC12(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.LEHE0:
.L81:
.LBE24:
	.loc 1 254 7 is_stmt 1
	movl	$0, %r12d
.LBB25:
	.loc 1 254 16 discriminator 1
	movb	$0, -49(%rbp)
.L86:
	leaq	-96(%rbp), %rax
	movq	%rax, %rdi
.LEHB1:
	call	system__secondary_stack__ss_mark@PLT
.LBB26:
.LBB27:
	.loc 1 255 38
	movzbl	-49(%rbp), %eax
	movl	%eax, %edi
	call	silver_output_lexical__forbidden_spelling
	.loc 1 255 9 discriminator 1
	movl	-120(%rbp), %ecx
	movl	-116(%rbp), %r10d
	movq	-112(%rbp), %rdi
	movq	-104(%rbp), %rsi
	movq	%rax, %r8
	movq	%rdx, %r9
	movl	%r10d, %edx
	call	silver_output_lexical__name_is
.LEHE1:
	.loc 1 255 0 discriminator 2
	movl	$1, %ebx
	.loc 1 255 9 discriminator 2
	movb	%al, -145(%rbp)
.L89:
	.loc 1 255 0 discriminator 3
	leaq	-96(%rbp), %rax
	movq	%rax, %r10
.LEHB2:
	call	silver_output_lexical__forbidden_name__B100s__L101s__B102s___finalizer.0
.LEHE2:
	.loc 1 255 0 is_stmt 0 discriminator 4
	cmpl	$1, %ebx
	jne	.L82
	.loc 1 255 0 discriminator 6
	movl	$1, %eax
.L91:
	.loc 1 255 0 discriminator 7
	cmpl	$1, %eax
	jne	.L83
	.loc 1 255 0 discriminator 8
	nop
.LBE27:
	.loc 1 254 7 is_stmt 1 discriminator 2
	cmpb	$0, -145(%rbp)
	je	.L84
	.loc 1 254 7 is_stmt 0 discriminator 3
	movl	$1, %r12d
.LBE26:
.LBE25:
	.loc 1 254 7 discriminator 6
	jmp	.L87
.L84:
.LBB30:
	.loc 1 254 7 discriminator 4
	cmpb	$75, -49(%rbp)
	je	.L87
	.loc 1 254 7 discriminator 5
	addb	$1, -49(%rbp)
	jmp	.L86
.L87:
.LBE30:
	.loc 1 254 7 discriminator 7
	movl	%r12d, %eax
	jmp	.L94
.L92:
	movq	%rax, -160(%rbp)
	movl	$0, %ebx
.LBB31:
.LBB29:
.LBB28:
	.loc 1 255 9 is_stmt 1 discriminator 9
	jmp	.L89
.L82:
	movq	-160(%rbp), %rax
	movq	%rax, -128(%rbp)
	jmp	.L90
.L93:
	movq	%rax, -128(%rbp)
.L90:
	movl	$0, %eax
	jmp	.L91
.L83:
	movq	-128(%rbp), %rax
	movq	%rax, %rdi
.LEHB3:
	call	_Unwind_Resume@PLT
.L94:
.LBE28:
.LBE29:
.LBE31:
.LBE20:
	.loc 1 253 4
	addq	$120, %rsp
.LEHE3:
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE5:
	.section	.gcc_except_table,"a",@progbits
.LLSDA5:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE5-.LLSDACSB5
.LLSDACSB5:
	.uleb128 .LEHB0-.LFB5
	.uleb128 .LEHE0-.LEHB0
	.uleb128 0
	.uleb128 0
	.uleb128 .LEHB1-.LFB5
	.uleb128 .LEHE1-.LEHB1
	.uleb128 .L92-.LFB5
	.uleb128 0
	.uleb128 .LEHB2-.LFB5
	.uleb128 .LEHE2-.LEHB2
	.uleb128 .L93-.LFB5
	.uleb128 0
	.uleb128 .LEHB3-.LFB5
	.uleb128 .LEHE3-.LEHB3
	.uleb128 0
	.uleb128 0
.LLSDACSE5:
	.text
	.size	silver_output_lexical__forbidden_name, .-silver_output_lexical__forbidden_name
	.section	.rodata
	.align 8
.LC13:
	.ascii	"failed precondition from silver_output_lexical.ads:260"
	.align 8
.LC14:
	.ascii	"failed precondition from silver_output_lexical.ads:261"
.LC15:
	.ascii	"silver_arguments"
	.align 8
.LC1:
	.long	1
	.long	16
	.text
	.align 2
	.globl	silver_output_lexical__forbidden_argument_name
	.type	silver_output_lexical__forbidden_argument_name, @function
silver_output_lexical__forbidden_argument_name:
.LFB7:
	.loc 1 263 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$72, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -64(%rbp)
	movq	%rdi, -56(%rbp)
	movl	%edx, -68(%rbp)
	movl	%ecx, -72(%rbp)
	.loc 1 263 4
	movq	-56(%rbp), %rax
	movl	(%rax), %r9d
	movq	-56(%rbp), %rax
	movl	4(%rax), %r8d
	movq	-56(%rbp), %rax
	movl	4(%rax), %edx
	movq	-56(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L96
	.loc 1 263 4 is_stmt 0 discriminator 1
	movq	-56(%rbp), %rax
	movl	4(%rax), %eax
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movq	-56(%rbp), %rax
	movl	(%rax), %eax
	cltq
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L97
.L96:
	.loc 1 263 4 discriminator 2
	movl	$0, %eax
	movl	$0, %edx
.L97:
.LBB32:
	.loc 1 260 15 is_stmt 1
	cmpl	$1, %r9d
	je	.L98
.LBB33:
	.loc 1 260 15 is_stmt 0 discriminator 1
	leaq	.LC13(%rip), %rax
	movq	%rax, -112(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -104(%rbp)
	movq	-112(%rbp), %rbx
	movq	-104(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L98:
.LBE33:
	.loc 1 260 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 1 260 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L99
	.loc 1 260 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L100
.L99:
.LBB34:
	.loc 1 260 15 discriminator 4
	leaq	.LC13(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L100:
.LBE34:
	.loc 1 260 15 is_stmt 0 discriminator 5
	movl	-68(%rbp), %eax
	cmpl	-72(%rbp), %eax
	jl	.L101
.LBB35:
	.loc 1 260 15 discriminator 6
	leaq	.LC14(%rip), %r12
	leaq	.LC0(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L101:
.LBE35:
	.loc 1 261 61 is_stmt 1
	cmpl	$2147483647, %r8d
	jne	.L102
	.loc 1 261 61 is_stmt 0 discriminator 1
	leaq	.LC6(%rip), %rax
	movl	$261, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L102:
	.loc 1 261 61 discriminator 3
	leal	1(%r8), %eax
	.loc 1 260 15 is_stmt 1 discriminator 7
	cmpl	-72(%rbp), %eax
	jge	.L103
.LBB36:
	.loc 1 260 15 is_stmt 0 discriminator 8
	leaq	.LC14(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L103:
.LBE36:
	.loc 1 265 7 is_stmt 1
	movl	-72(%rbp), %ecx
	movl	-68(%rbp), %edx
	movq	-64(%rbp), %rsi
	movq	-56(%rbp), %rax
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__forbidden_name
	.loc 1 266 7
	testb	%al, %al
	jne	.L104
	.loc 1 266 15 discriminator 1
	leaq	.LC15(%rip), %rax
	movq	%rax, -96(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -88(%rbp)
	movl	-72(%rbp), %ecx
	movl	-68(%rbp), %edx
	movq	-64(%rbp), %rsi
	movq	-56(%rbp), %rax
	movq	-96(%rbp), %r8
	movq	-88(%rbp), %r9
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__name_is
	.loc 1 266 7 discriminator 2
	testb	%al, %al
	je	.L105
.L104:
	.loc 1 266 7 is_stmt 0 discriminator 3
	movl	$1, %eax
	jmp	.L106
.L105:
	.loc 1 266 7 discriminator 4
	movl	$0, %eax
.L106:
.LBE32:
	.loc 1 263 4 is_stmt 1
	addq	$72, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE7:
	.size	silver_output_lexical__forbidden_argument_name, .-silver_output_lexical__forbidden_argument_name
	.section	.rodata
	.align 8
.LC16:
	.ascii	"failed precondition from silver_output_lexical.ads:270"
	.text
	.align 2
	.globl	silver_output_lexical__valid_name_state
	.type	silver_output_lexical__valid_name_state, @function
silver_output_lexical__valid_name_state:
.LFB8:
	.loc 1 272 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r12
	pushq	%rbx
	subq	$32, %rsp
	.cfi_offset 12, -24
	.cfi_offset 3, -32
	movq	%rdi, %rax
	movq	%rsi, %rbx
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%rbx, %rdi
	movq	%rsi, -32(%rbp)
	movq	%rdi, -24(%rbp)
	movl	%edx, -36(%rbp)
	movl	%ecx, -40(%rbp)
	.loc 1 272 4
	movq	-24(%rbp), %rax
	movl	(%rax), %edi
	movq	-24(%rbp), %rax
	movl	4(%rax), %esi
	movq	-24(%rbp), %rax
	movl	4(%rax), %edx
	movq	-24(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %edx
	jl	.L109
	.loc 1 272 4 is_stmt 0 discriminator 1
	movq	-24(%rbp), %rax
	movl	4(%rax), %ecx
	movslq	%ecx, %rax
	cqto
	movq	-24(%rbp), %rcx
	movl	(%rcx), %r12d
	movslq	%r12d, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	jmp	.L110
.L109:
	.loc 1 272 4 discriminator 2
	movl	$0, %eax
	movl	$0, %edx
.L110:
	.loc 1 270 15 is_stmt 1
	cmpl	$1, %edi
	je	.L111
.LBB37:
	.loc 1 270 15 is_stmt 0 discriminator 1
	leaq	.LC16(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L111:
.LBE37:
	.loc 1 270 51 is_stmt 1 discriminator 2
	movl	%eax, %ecx
	.loc 1 270 15 discriminator 2
	testl	%ecx, %ecx
	jle	.L112
	.loc 1 270 51 discriminator 3
	cmpl	$4096, %eax
	jle	.L113
.L112:
.LBB38:
	.loc 1 270 15 discriminator 4
	leaq	.LC16(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L113:
.LBE38:
	.loc 1 274 7
	cmpl	$0, -36(%rbp)
	jne	.L114
	.loc 1 273 18
	cmpl	$0, -40(%rbp)
	je	.L115
.L114:
	.loc 1 274 7 discriminator 1
	cmpl	$0, -36(%rbp)
	jle	.L116
	.loc 1 274 26 discriminator 2
	movl	-36(%rbp), %eax
	cmpl	-40(%rbp), %eax
	jge	.L116
	.loc 1 274 77 discriminator 3
	cmpl	$2147483647, %esi
	jne	.L117
	.loc 1 274 77 is_stmt 0 discriminator 4
	leaq	.LC6(%rip), %rax
	movl	$274, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L117:
	.loc 1 274 77 discriminator 6
	leal	1(%rsi), %eax
	.loc 1 274 49 is_stmt 1 discriminator 7
	cmpl	-40(%rbp), %eax
	jl	.L116
.L115:
	.loc 1 274 7 discriminator 8
	movl	$1, %eax
	jmp	.L118
.L116:
	.loc 1 274 7 is_stmt 0 discriminator 9
	movl	$0, %eax
.L118:
	.loc 1 272 4 is_stmt 1
	addq	$32, %rsp
	popq	%rbx
	popq	%r12
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE8:
	.size	silver_output_lexical__valid_name_state, .-silver_output_lexical__valid_name_state
	.align 2
	.globl	silver_output_lexical__decimal_resultIP
	.type	silver_output_lexical__decimal_resultIP, @function
silver_output_lexical__decimal_resultIP:
.LFB9:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE9:
	.size	silver_output_lexical__decimal_resultIP, .-silver_output_lexical__decimal_resultIP
	.align 2
	.globl	silver_output_lexical__is_letter
	.type	silver_output_lexical__is_letter, @function
silver_output_lexical__is_letter:
.LFB10:
	.loc 1 101 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movb	%dil, -1(%rbp)
	.loc 1 102 19
	movzbl	-1(%rbp), %eax
	.loc 1 102 32
	cmpb	$64, %al
	jbe	.L122
	.loc 1 102 19 discriminator 1
	movzbl	-1(%rbp), %eax
	cmpb	$90, %al
	jbe	.L123
.L122:
	.loc 1 102 32 discriminator 2
	movzbl	-1(%rbp), %eax
	cmpb	$96, %al
	jbe	.L124
	.loc 1 102 32 is_stmt 0 discriminator 3
	movzbl	-1(%rbp), %eax
	cmpb	$122, %al
	ja	.L124
.L123:
	.loc 1 102 32 discriminator 4
	movl	$1, %eax
	jmp	.L125
.L124:
	.loc 1 102 32 discriminator 5
	movl	$0, %eax
.L125:
	.loc 1 101 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE10:
	.size	silver_output_lexical__is_letter, .-silver_output_lexical__is_letter
	.section	.rodata
.LC17:
	.ascii	"silver_output_lexical.adb"
	.zero	1
	.text
	.align 2
	.type	silver_output_lexical__forbidden_spelling___wrapped_statements.1, @function
silver_output_lexical__forbidden_spelling___wrapped_statements.1:
.LFB12:
	.file 2 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_output_lexical.adb"
	.loc 2 8 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r13
	pushq	%r12
	subq	$16, %rsp
	.cfi_offset 13, -24
	.cfi_offset 12, -32
	movq	%r10, %rax
	movq	%r10, -24(%rbp)
	.loc 2 10 12
	movzbl	(%rax), %edx
	cmpb	$75, %dl
	jbe	.L128
	.loc 2 10 12 is_stmt 0 discriminator 1
	leaq	.LC17(%rip), %rax
	movl	$10, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L128:
	.loc 2 10 7 is_stmt 1 discriminator 2
	movzbl	(%rax), %eax
	cmpb	$74, %al
	je	.L129
	cmpb	$74, %al
	ja	.L130
	cmpb	$73, %al
	je	.L131
	cmpb	$73, %al
	ja	.L130
	cmpb	$72, %al
	je	.L132
	cmpb	$72, %al
	ja	.L130
	cmpb	$71, %al
	je	.L133
	cmpb	$71, %al
	ja	.L130
	cmpb	$70, %al
	je	.L134
	cmpb	$70, %al
	ja	.L130
	cmpb	$69, %al
	je	.L135
	cmpb	$69, %al
	ja	.L130
	cmpb	$68, %al
	je	.L136
	cmpb	$68, %al
	ja	.L130
	cmpb	$67, %al
	je	.L137
	cmpb	$67, %al
	ja	.L130
	cmpb	$66, %al
	je	.L138
	cmpb	$66, %al
	ja	.L130
	cmpb	$65, %al
	je	.L139
	cmpb	$65, %al
	ja	.L130
	cmpb	$64, %al
	je	.L140
	cmpb	$64, %al
	ja	.L130
	cmpb	$63, %al
	je	.L141
	cmpb	$63, %al
	ja	.L130
	cmpb	$62, %al
	je	.L142
	cmpb	$62, %al
	ja	.L130
	cmpb	$61, %al
	je	.L143
	cmpb	$61, %al
	ja	.L130
	cmpb	$60, %al
	je	.L144
	cmpb	$60, %al
	ja	.L130
	cmpb	$59, %al
	je	.L145
	cmpb	$59, %al
	ja	.L130
	cmpb	$58, %al
	je	.L146
	cmpb	$58, %al
	ja	.L130
	cmpb	$57, %al
	je	.L147
	cmpb	$57, %al
	ja	.L130
	cmpb	$56, %al
	je	.L148
	cmpb	$56, %al
	ja	.L130
	cmpb	$55, %al
	je	.L149
	cmpb	$55, %al
	ja	.L130
	cmpb	$54, %al
	je	.L150
	cmpb	$54, %al
	ja	.L130
	cmpb	$53, %al
	je	.L151
	cmpb	$53, %al
	ja	.L130
	cmpb	$52, %al
	je	.L152
	cmpb	$52, %al
	ja	.L130
	cmpb	$51, %al
	je	.L153
	cmpb	$51, %al
	ja	.L130
	cmpb	$50, %al
	je	.L154
	cmpb	$50, %al
	ja	.L130
	cmpb	$49, %al
	je	.L155
	cmpb	$49, %al
	ja	.L130
	cmpb	$48, %al
	je	.L156
	cmpb	$48, %al
	ja	.L130
	cmpb	$47, %al
	je	.L157
	cmpb	$47, %al
	ja	.L130
	cmpb	$46, %al
	je	.L158
	cmpb	$46, %al
	ja	.L130
	cmpb	$45, %al
	je	.L159
	cmpb	$45, %al
	ja	.L130
	cmpb	$44, %al
	je	.L160
	cmpb	$44, %al
	ja	.L130
	cmpb	$43, %al
	je	.L161
	cmpb	$43, %al
	ja	.L130
	cmpb	$42, %al
	je	.L162
	cmpb	$42, %al
	ja	.L130
	cmpb	$41, %al
	je	.L163
	cmpb	$41, %al
	ja	.L130
	cmpb	$40, %al
	je	.L164
	cmpb	$40, %al
	ja	.L130
	cmpb	$39, %al
	je	.L165
	cmpb	$39, %al
	ja	.L130
	cmpb	$38, %al
	je	.L166
	cmpb	$38, %al
	ja	.L130
	cmpb	$37, %al
	je	.L167
	cmpb	$37, %al
	ja	.L130
	cmpb	$36, %al
	je	.L168
	cmpb	$36, %al
	ja	.L130
	cmpb	$35, %al
	je	.L169
	cmpb	$35, %al
	ja	.L130
	cmpb	$34, %al
	je	.L170
	cmpb	$34, %al
	ja	.L130
	cmpb	$33, %al
	je	.L171
	cmpb	$33, %al
	ja	.L130
	cmpb	$32, %al
	je	.L172
	cmpb	$32, %al
	ja	.L130
	cmpb	$31, %al
	je	.L173
	cmpb	$31, %al
	ja	.L130
	cmpb	$30, %al
	je	.L174
	cmpb	$30, %al
	ja	.L130
	cmpb	$29, %al
	je	.L175
	cmpb	$29, %al
	ja	.L130
	cmpb	$28, %al
	je	.L176
	cmpb	$28, %al
	ja	.L130
	cmpb	$27, %al
	je	.L177
	cmpb	$27, %al
	ja	.L130
	cmpb	$26, %al
	je	.L178
	cmpb	$26, %al
	ja	.L130
	cmpb	$25, %al
	je	.L179
	cmpb	$25, %al
	ja	.L130
	cmpb	$24, %al
	je	.L180
	cmpb	$24, %al
	ja	.L130
	cmpb	$23, %al
	je	.L181
	cmpb	$23, %al
	ja	.L130
	cmpb	$22, %al
	je	.L182
	cmpb	$22, %al
	ja	.L130
	cmpb	$21, %al
	je	.L183
	cmpb	$21, %al
	ja	.L130
	cmpb	$20, %al
	je	.L184
	cmpb	$20, %al
	ja	.L130
	cmpb	$19, %al
	je	.L185
	cmpb	$19, %al
	ja	.L130
	cmpb	$18, %al
	je	.L186
	cmpb	$18, %al
	ja	.L130
	cmpb	$17, %al
	je	.L187
	cmpb	$17, %al
	ja	.L130
	cmpb	$16, %al
	je	.L188
	cmpb	$16, %al
	ja	.L130
	cmpb	$15, %al
	je	.L189
	cmpb	$15, %al
	ja	.L130
	cmpb	$14, %al
	je	.L190
	cmpb	$14, %al
	ja	.L130
	cmpb	$13, %al
	je	.L191
	cmpb	$13, %al
	ja	.L130
	cmpb	$12, %al
	je	.L192
	cmpb	$12, %al
	ja	.L130
	cmpb	$11, %al
	je	.L193
	cmpb	$11, %al
	ja	.L130
	cmpb	$10, %al
	je	.L194
	cmpb	$10, %al
	ja	.L130
	cmpb	$9, %al
	je	.L195
	cmpb	$9, %al
	ja	.L130
	cmpb	$8, %al
	je	.L196
	cmpb	$8, %al
	ja	.L130
	cmpb	$7, %al
	je	.L197
	cmpb	$7, %al
	ja	.L130
	cmpb	$6, %al
	je	.L198
	cmpb	$6, %al
	ja	.L130
	cmpb	$5, %al
	je	.L199
	cmpb	$5, %al
	ja	.L130
	cmpb	$4, %al
	je	.L200
	cmpb	$4, %al
	ja	.L130
	cmpb	$3, %al
	je	.L201
	cmpb	$3, %al
	ja	.L130
	cmpb	$2, %al
	je	.L202
	cmpb	$2, %al
	ja	.L130
	testb	%al, %al
	je	.L203
	cmpb	$1, %al
	je	.L204
	jmp	.L130
.L203:
.LBB39:
	.loc 2 11 34
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 11 34 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$5, 4(%rax)
	movl	$1919902305, 8(%rax)
	movb	$116, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L204:
.LBE39:
.LBB40:
	.loc 2 12 32 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 12 32 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$25185, 8(%rax)
	movb	$115, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L202:
.LBE40:
.LBB41:
	.loc 2 13 37 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 13 37 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$8, 4(%rax)
	movabsq	$8386654075301880417, %rcx
	movq	%rcx, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L201:
.LBE41:
.LBB42:
	.loc 2 14 35 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 14 35 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$6, 4(%rax)
	movl	$1701012321, 8(%rax)
	movw	$29808, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L200:
.LBE42:
.LBB43:
	.loc 2 15 35 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 15 35 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$6, 4(%rax)
	movl	$1701012321, 8(%rax)
	movw	$29555, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L199:
.LBE43:
.LBB44:
	.loc 2 16 36 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 16 36 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$7, 4(%rax)
	movl	$1634298977, 8(%rax)
	movl	$1684370273, 11(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L198:
.LBE44:
.LBB45:
	.loc 2 17 32 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 17 32 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$27745, 8(%rax)
	movb	$108, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L197:
.LBE45:
.LBB46:
	.loc 2 18 32 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 18 32 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$28257, 8(%rax)
	movb	$100, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L196:
.LBE46:
.LBB47:
	.loc 2 19 34 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 19 34 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$5, 4(%rax)
	movl	$1634890337, 8(%rax)
	movb	$121, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L195:
.LBE47:
.LBB48:
	.loc 2 20 31 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 20 31 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$2, 4(%rax)
	movw	$29793, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L194:
.LBE48:
.LBB49:
	.loc 2 21 34 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 21 34 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$5, 4(%rax)
	movl	$1768383842, 8(%rax)
	movb	$110, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L193:
.LBE49:
.LBB50:
	.loc 2 22 33 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 22 33 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$2036625250, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L192:
.LBE50:
.LBB51:
	.loc 2 23 33 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 23 33 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1702060387, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L191:
.LBE51:
.LBB52:
	.loc 2 24 37 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 24 37 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$8, 4(%rax)
	movabsq	$8389750308618530659, %rcx
	movq	%rcx, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L190:
.LBE52:
.LBB53:
	.loc 2 25 36 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 25 36 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$7, 4(%rax)
	movl	$1818453348, 8(%rax)
	movl	$1701994860, 11(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L189:
.LBE53:
.LBB54:
	.loc 2 26 34 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 26 34 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$5, 4(%rax)
	movl	$1634493796, 8(%rax)
	movb	$121, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L188:
.LBE54:
.LBB55:
	.loc 2 27 34 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 27 34 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$5, 4(%rax)
	movl	$1953260900, 8(%rax)
	movb	$97, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L187:
.LBE55:
.LBB56:
	.loc 2 28 35 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 28 35 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$6, 4(%rax)
	movl	$1768384868, 8(%rax)
	movw	$29556, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L186:
.LBE56:
.LBB57:
	.loc 2 29 31 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 29 31 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$2, 4(%rax)
	movw	$28516, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L185:
.LBE57:
.LBB58:
	.loc 2 30 33 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 30 33 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1702063205, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L184:
.LBE58:
.LBB59:
	.loc 2 31 34 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 31 34 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$5, 4(%rax)
	movl	$1769172069, 8(%rax)
	movb	$102, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L183:
.LBE59:
.LBB60:
	.loc 2 32 32 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 32 32 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$28261, 8(%rax)
	movb	$100, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L182:
.LBE60:
.LBB61:
	.loc 2 33 34 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 33 34 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$5, 4(%rax)
	movl	$1920233061, 8(%rax)
	movb	$121, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L181:
.LBE61:
.LBB62:
	.loc 2 34 38 is_stmt 1
	movl	$4, %esi
	movl	$20, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 34 38 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$9, 4(%rax)
	movabsq	$8028075836850796645, %rcx
	movq	%rcx, 8(%rax)
	movb	$110, 16(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L180:
.LBE62:
.LBB63:
	.loc 2 35 33 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 35 33 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1953069157, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L179:
.LBE63:
.LBB64:
	.loc 2 36 32 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 36 32 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$28518, 8(%rax)
	movb	$114, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L178:
.LBE64:
.LBB65:
	.loc 2 37 37 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 37 37 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$8, 4(%rax)
	movabsq	$7957695015192261990, %rcx
	movq	%rcx, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L177:
.LBE65:
.LBB66:
	.loc 2 38 36 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 38 36 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$7, 4(%rax)
	movl	$1701733735, 8(%rax)
	movl	$1667854949, 11(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L176:
.LBE66:
.LBB67:
	.loc 2 39 33 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 39 33 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1869901671, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L175:
.LBE67:
.LBB68:
	.loc 2 40 31 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 40 31 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$2, 4(%rax)
	movw	$26217, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L174:
.LBE68:
.LBB69:
	.loc 2 41 31 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 41 31 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$2, 4(%rax)
	movw	$28265, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L173:
.LBE69:
.LBB70:
	.loc 2 42 38 is_stmt 1
	movl	$4, %esi
	movl	$20, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 42 38 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$9, 4(%rax)
	movabsq	$7161117524010233449, %rcx
	movq	%rcx, 8(%rax)
	movb	$101, 16(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L172:
.LBE70:
.LBB71:
	.loc 2 43 31 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 43 31 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$2, 4(%rax)
	movw	$29545, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L171:
.LBE71:
.LBB72:
	.loc 2 44 36 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 44 36 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$7, 4(%rax)
	movl	$1768778092, 8(%rax)
	movl	$1684370537, 11(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L170:
.LBE72:
.LBB73:
	.loc 2 45 33 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 45 33 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1886351212, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L169:
.LBE73:
.LBB74:
	.loc 2 46 32 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 46 32 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$28525, 8(%rax)
	movb	$100, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L168:
.LBE74:
.LBB75:
	.loc 2 47 32 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 47 32 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$25966, 8(%rax)
	movb	$119, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L167:
.LBE75:
.LBB76:
	.loc 2 48 32 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 48 32 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$28526, 8(%rax)
	movb	$116, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L166:
.LBE76:
.LBB77:
	.loc 2 49 33 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 49 33 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1819047278, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L165:
.LBE77:
.LBB78:
	.loc 2 50 31 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 50 31 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$2, 4(%rax)
	movw	$26223, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L164:
.LBE78:
.LBB79:
	.loc 2 51 31 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 51 31 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$2, 4(%rax)
	movw	$29295, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L163:
.LBE79:
.LBB80:
	.loc 2 52 35 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 52 35 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$6, 4(%rax)
	movl	$1701344367, 8(%rax)
	movw	$29554, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L162:
.LBE80:
.LBB81:
	.loc 2 53 32 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 53 32 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$30063, 8(%rax)
	movb	$116, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L161:
.LBE81:
.LBB82:
	.loc 2 54 39 is_stmt 1
	movl	$4, %esi
	movl	$20, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 54 39 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$10, 4(%rax)
	movabsq	$7594310811919939183, %rcx
	movq	%rcx, 8(%rax)
	movw	$26478, 16(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L160:
.LBE82:
.LBB83:
	.loc 2 55 36 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 55 36 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$7, 4(%rax)
	movl	$1801675120, 8(%rax)
	movl	$1701273963, 11(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L159:
.LBE83:
.LBB84:
	.loc 2 56 37 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 56 37 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$8, 4(%rax)
	movabsq	$7810768341491147120, %rcx
	movq	%rcx, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L158:
.LBE84:
.LBB85:
	.loc 2 57 35 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 57 35 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$6, 4(%rax)
	movl	$1734439536, 8(%rax)
	movw	$24941, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L157:
.LBE85:
.LBB86:
	.loc 2 58 36 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 58 36 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$7, 4(%rax)
	movl	$1986622064, 8(%rax)
	movl	$1702125942, 11(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L156:
.LBE86:
.LBB87:
	.loc 2 59 38 is_stmt 1
	movl	$4, %esi
	movl	$20, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 59 38 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$9, 4(%rax)
	movabsq	$8247608679221654128, %rcx
	movq	%rcx, 8(%rax)
	movb	$101, 16(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L155:
.LBE87:
.LBB88:
	.loc 2 60 38 is_stmt 1
	movl	$4, %esi
	movl	$20, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 60 38 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$9, 4(%rax)
	movabsq	$7310577382525465200, %rcx
	movq	%rcx, 8(%rax)
	movb	$100, 16(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L154:
.LBE88:
.LBB89:
	.loc 2 61 34 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 61 34 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$5, 4(%rax)
	movl	$1936286066, 8(%rax)
	movb	$101, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L153:
.LBE89:
.LBB90:
	.loc 2 62 34 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 62 34 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$5, 4(%rax)
	movl	$1735287154, 8(%rax)
	movb	$101, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L152:
.LBE90:
.LBB91:
	.loc 2 63 35 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 63 35 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$6, 4(%rax)
	movl	$1868785010, 8(%rax)
	movw	$25714, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L151:
.LBE91:
.LBB92:
	.loc 2 64 32 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 64 32 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$25970, 8(%rax)
	movb	$109, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L150:
.LBE92:
.LBB93:
	.loc 2 65 36 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 65 36 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$7, 4(%rax)
	movl	$1634624882, 8(%rax)
	movl	$1936026977, 11(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L149:
.LBE93:
.LBB94:
	.loc 2 66 36 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 66 36 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$7, 4(%rax)
	movl	$1970365810, 8(%rax)
	movl	$1702192501, 11(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L148:
.LBE94:
.LBB95:
	.loc 2 67 35 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 67 35 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$6, 4(%rax)
	movl	$1970562418, 8(%rax)
	movw	$28274, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L147:
.LBE95:
.LBB96:
	.loc 2 68 36 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 68 36 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$7, 4(%rax)
	movl	$1702258034, 8(%rax)
	movl	$1702064741, 11(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L146:
.LBE96:
.LBB97:
	.loc 2 69 35 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 69 35 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$6, 4(%rax)
	movl	$1701602675, 8(%rax)
	movw	$29795, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L145:
.LBE97:
.LBB98:
	.loc 2 70 37 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 70 37 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$8, 4(%rax)
	movabsq	$7310575239018079603, %rcx
	movq	%rcx, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L144:
.LBE98:
.LBB99:
	.loc 2 71 33 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 71 33 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1701670771, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L143:
.LBE99:
.LBB100:
	.loc 2 72 36 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 72 36 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$7, 4(%rax)
	movl	$1952609651, 8(%rax)
	movl	$1701869940, 11(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L142:
.LBE100:
.LBB101:
	.loc 2 73 41 is_stmt 1
	movl	$4, %esi
	movl	$20, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 73 41 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$12, 4(%rax)
	movabsq	$7957704859257305459, %rcx
	movq	%rcx, 8(%rax)
	movl	$1684372073, 16(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L141:
.LBE101:
.LBB102:
	.loc 2 74 35 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 74 35 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$6, 4(%rax)
	movl	$1734828404, 8(%rax)
	movw	$25701, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L140:
.LBE102:
.LBB103:
	.loc 2 75 33 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 75 33 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1802723700, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L139:
.LBE103:
.LBB104:
	.loc 2 76 38 is_stmt 1
	movl	$4, %esi
	movl	$20, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 76 38 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$9, 4(%rax)
	movabsq	$8386105380227409268, %rcx
	movq	%rcx, 8(%rax)
	movb	$101, 16(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L138:
.LBE104:
.LBB105:
	.loc 2 77 33 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 77 33 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1852139636, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L137:
.LBE105:
.LBB106:
	.loc 2 78 33 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 78 33 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1701869940, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L136:
.LBE106:
.LBB107:
	.loc 2 79 34 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 79 34 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$5, 4(%rax)
	movl	$1769238133, 8(%rax)
	movb	$108, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L135:
.LBE107:
.LBB108:
	.loc 2 80 32 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 80 32 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$29557, 8(%rax)
	movb	$101, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L134:
.LBE108:
.LBB109:
	.loc 2 81 33 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 81 33 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1852139639, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L133:
.LBE109:
.LBB110:
	.loc 2 82 34 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 82 34 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$5, 4(%rax)
	movl	$1818847351, 8(%rax)
	movb	$101, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L132:
.LBE110:
.LBB111:
	.loc 2 83 33 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 83 33 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$4, 4(%rax)
	movl	$1752459639, 8(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L131:
.LBE111:
.LBB112:
	.loc 2 84 32 is_stmt 1
	movl	$4, %esi
	movl	$12, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 84 32 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$3, 4(%rax)
	movw	$28536, 8(%rax)
	movb	$114, 10(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L129:
.LBE112:
.LBB113:
	.loc 2 85 35 is_stmt 1
	movl	$4, %esi
	movl	$16, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 85 35 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$6, 4(%rax)
	movl	$1769108595, 8(%rax)
	movw	$26478, 12(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
	jmp	.L205
.L130:
.LBE113:
.LBB114:
	.loc 2 86 38 is_stmt 1
	movl	$4, %esi
	movl	$20, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 2 86 38 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$9, 4(%rax)
	movabsq	$7592913276874025331, %rcx
	movq	%rcx, 8(%rax)
	movb	$111, 16(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
.L205:
.LBE114:
	.loc 2 88 8 is_stmt 1
	movq	%r12, %rax
	movq	%r13, %rdx
	addq	$16, %rsp
	popq	%r12
	popq	%r13
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE12:
	.size	silver_output_lexical__forbidden_spelling___wrapped_statements.1, .-silver_output_lexical__forbidden_spelling___wrapped_statements.1
	.section	.rodata
	.align 8
.LC18:
	.ascii	"failed postcondition from silver_output_lexical.ads:244"
	.align 8
.LC19:
	.ascii	"failed postcondition from silver_output_lexical.ads:245"
	.align 8
.LC2:
	.long	1
	.long	55
	.text
	.align 2
	.globl	silver_output_lexical__forbidden_spelling
	.type	silver_output_lexical__forbidden_spelling, @function
silver_output_lexical__forbidden_spelling:
.LFB11:
	.loc 2 8 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movb	%dil, -65(%rbp)
	.loc 2 8 4
	leaq	16(%rbp), %rax
	.loc 2 8 4 is_stmt 0 discriminator 1
	movq	%rax, -56(%rbp)
	movzbl	-65(%rbp), %eax
	movb	%al, -64(%rbp)
.LBB115:
	leaq	-64(%rbp), %rax
	movq	%rax, %r10
	call	silver_output_lexical__forbidden_spelling___wrapped_statements.1
	.loc 2 8 4 discriminator 2
	movq	%rax, %rcx
	movq	%rdx, %rbx
	movq	%rbx, %rax
	movl	(%rax), %eax
	movq	%rbx, %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	.loc 2 8 4 discriminator 5
	cmpl	%eax, %edx
	.loc 2 8 4 discriminator 8
	cmpl	%eax, %edx
	.loc 2 8 4 discriminator 11
	cmpl	%eax, %edx
	jl	.L213
	.loc 2 8 4 discriminator 12
	testl	%eax, %eax
	jg	.L213
	.loc 2 8 4 discriminator 13
	leaq	.LC17(%rip), %rax
	movl	$8, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L213:
	.loc 1 244 16 is_stmt 1
	cmpl	$1, %eax
	je	.L214
.LBB116:
	.loc 1 244 16 is_stmt 0 discriminator 1
	leaq	.LC18(%rip), %r14
	leaq	.LC2(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L214:
.LBE116:
	.loc 1 244 16 discriminator 2
	cmpl	%eax, %edx
	jl	.L215
	.loc 1 245 52 is_stmt 1
	movl	%edx, %esi
	movl	%eax, %edi
	subl	%edi, %esi
	addl	$1, %esi
	testl	%esi, %esi
	jle	.L215
	.loc 1 245 52 is_stmt 0 discriminator 1
	cmpl	%eax, %edx
	jl	.L216
	.loc 1 245 52 discriminator 2
	movl	%edx, %esi
	movl	%eax, %edx
	movl	%esi, %eax
	subl	%edx, %eax
	addl	$1, %eax
	cmpl	$12, %eax
	jle	.L216
.L215:
.LBB117:
	.loc 1 244 16 is_stmt 1 discriminator 3
	leaq	.LC19(%rip), %r12
	leaq	.LC2(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L216:
.LBE117:
	.loc 2 8 4 discriminator 14
	movq	%rcx, %rax
	movq	%rbx, %rdx
.LBE115:
	.loc 2 8 4 is_stmt 0
	addq	$40, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE11:
	.size	silver_output_lexical__forbidden_spelling, .-silver_output_lexical__forbidden_spelling
	.section	.rodata
	.align 8
.LC20:
	.ascii	"failed precondition from silver_output_lexical.ads:341"
	.align 8
.LC21:
	.ascii	"failed precondition from silver_output_lexical.ads:342"
	.align 8
.LC22:
	.ascii	"Loop_Invariant failed at silver_output_lexical.adb:107"
	.align 8
.LC23:
	.ascii	"Loop_Variant failed at silver_output_lexical.adb:110"
	.align 8
.LC3:
	.long	1
	.long	52
	.text
	.align 2
	.globl	silver_output_lexical__read_capacity
	.type	silver_output_lexical__read_capacity, @function
silver_output_lexical__read_capacity:
.LFB13:
	.loc 2 90 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -80(%rbp)
	movq	%rbx, -72(%rbp)
	movl	%edx, -84(%rbp)
	.loc 2 90 4
	movq	-72(%rbp), %rax
	movl	(%rax), %r9d
	movq	-72(%rbp), %rax
	movl	4(%rax), %r8d
	cmpl	%r9d, %r8d
	jl	.L219
	.loc 2 90 4 is_stmt 0 discriminator 1
	movslq	%r8d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r9d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L220
.L219:
	.loc 2 90 4 discriminator 2
	movl	$0, %ecx
	movl	$0, %ebx
.L220:
.LBB118:
	.loc 2 90 4 discriminator 3
	movslq	%r9d, %rdi
	cmpl	%r9d, %r8d
	.loc 2 90 4 discriminator 6
	cmpl	%r9d, %r8d
	.loc 2 90 4 discriminator 9
	cmpl	%r9d, %r8d
	.loc 1 341 15 is_stmt 1
	cmpl	$1, %r9d
	je	.L227
.LBB119:
	.loc 1 341 15 is_stmt 0 discriminator 1
	leaq	.LC20(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L227:
.LBE119:
	.loc 1 341 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 1 341 15 discriminator 2
	testl	%eax, %eax
	jle	.L228
	.loc 1 341 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L229
.L228:
.LBB120:
	.loc 1 341 15 discriminator 4
	leaq	.LC20(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L229:
.LBE120:
	.loc 1 342 41
	cmpl	$2147483647, %r8d
	jne	.L230
	.loc 1 342 41 is_stmt 0 discriminator 1
	leaq	.LC6(%rip), %rax
	movl	$342, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L230:
	.loc 1 342 41 discriminator 3
	leal	1(%r8), %eax
	.loc 1 341 15 is_stmt 1 discriminator 5
	cmpl	-84(%rbp), %eax
	jge	.L231
.LBB121:
	.loc 1 341 15 is_stmt 0 discriminator 6
	leaq	.LC21(%rip), %rax
	movq	%rax, -112(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -104(%rbp)
	movq	-112(%rbp), %rbx
	movq	-104(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L231:
.LBE121:
	.loc 2 92 7 is_stmt 1
	movl	-84(%rbp), %eax
	movl	%eax, -52(%rbp)
	.loc 2 95 7
	cmpl	-52(%rbp), %r8d
	jl	.L232
	.loc 2 95 35 discriminator 1
	cmpl	-52(%rbp), %r9d
	jg	.L233
	.loc 2 95 35 is_stmt 0 discriminator 2
	cmpl	-52(%rbp), %r8d
	jge	.L234
.L233:
	.loc 2 95 35 discriminator 3
	leaq	.LC17(%rip), %rax
	movl	$95, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L234:
	.loc 2 95 47 is_stmt 1 discriminator 4
	movq	-80(%rbp), %rax
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	subq	%rdi, %rdx
	movzbl	(%rax,%rdx), %eax
	cmpb	$47, %al
	jbe	.L235
	.loc 2 95 47 is_stmt 0 discriminator 5
	movq	-80(%rbp), %rax
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	subq	%rdi, %rdx
	movzbl	(%rax,%rdx), %eax
	cmpb	$57, %al
	jbe	.L236
.L235:
	.loc 2 95 47 discriminator 6
	movl	$1, %eax
	jmp	.L237
.L236:
	.loc 2 95 47 discriminator 7
	movl	$0, %eax
.L237:
	.loc 2 95 27 is_stmt 1 discriminator 8
	testb	%al, %al
	je	.L238
.L232:
	.loc 2 96 10
	movl	$0, %eax
	movq	%rax, -96(%rbp)
	jmp	.L239
.L238:
	.loc 2 98 10
	cmpl	-52(%rbp), %r9d
	jg	.L240
	.loc 2 98 10 is_stmt 0 discriminator 1
	cmpl	-52(%rbp), %r8d
	jge	.L241
.L240:
	.loc 2 98 10 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$98, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L241:
	.loc 2 98 22 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rax
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	subq	%rdi, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 2 98 7 discriminator 3
	cmpb	$48, %al
	jne	.L242
	.loc 2 99 10
	cmpl	-52(%rbp), %r8d
	jle	.L243
	.loc 2 99 75 discriminator 1
	movl	-52(%rbp), %eax
	addl	$1, %eax
	.loc 2 99 64 discriminator 1
	cmpl	%eax, %r9d
	jg	.L244
	.loc 2 99 64 is_stmt 0 discriminator 2
	cmpl	%eax, %r8d
	jge	.L245
.L244:
	.loc 2 99 64 discriminator 3
	leaq	.LC17(%rip), %rax
	movl	$99, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L245:
	.loc 2 99 39 is_stmt 1 discriminator 4
	movq	-80(%rbp), %rdx
	cltq
	subq	%rdi, %rax
	movzbl	(%rdx,%rax), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_identifier_character@PLT
	.loc 2 99 30 discriminator 5
	testb	%al, %al
	je	.L243
	.loc 2 100 13
	movl	$0, %eax
	movq	%rax, -96(%rbp)
	jmp	.L239
.L243:
	.loc 2 102 32
	movl	-52(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L246
	.loc 2 102 32 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L247
.L246:
	.loc 2 102 32 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$102, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L247:
	.loc 2 102 10 is_stmt 1 discriminator 3
	movl	%eax, %edx
	movabsq	$-4294967296, %rax
	andq	-96(%rbp), %rax
	orq	%rdx, %rax
	movl	%eax, %eax
	movq	%rax, -96(%rbp)
	jmp	.L239
.L242:
	.loc 2 104 31
	cmpl	-52(%rbp), %r9d
	jg	.L248
	.loc 2 104 31 is_stmt 0 discriminator 1
	cmpl	-52(%rbp), %r8d
	jge	.L249
.L248:
	.loc 2 104 31 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$104, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L249:
	.loc 2 104 44 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rax
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	subq	%rdi, %rdx
	movzbl	(%rax,%rdx), %eax
	movzbl	%al, %eax
	subl	$48, %eax
	testl	%eax, %eax
	jns	.L250
	.loc 2 104 44 is_stmt 0 discriminator 4
	leaq	.LC17(%rip), %rax
	movl	$104, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L250:
	.loc 2 104 13 is_stmt 1 discriminator 5
	movl	%eax, -56(%rbp)
	.loc 2 105 20
	movl	-52(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L251
	.loc 2 105 20 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L252
.L251:
	.loc 2 105 20 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$105, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L252:
	.loc 2 105 12 is_stmt 1 discriminator 3
	movl	%eax, -52(%rbp)
	.loc 2 106 31
	movl	$0, %edx
.L276:
.LBB122:
	.loc 2 106 18 discriminator 1
	cmpl	-52(%rbp), %r8d
	jl	.L253
	.loc 2 107 33
	movl	-84(%rbp), %eax
	cmpl	-52(%rbp), %eax
	jge	.L254
	.loc 2 107 67 discriminator 1
	cmpl	$2147483647, %r8d
	jne	.L255
	.loc 2 107 67 is_stmt 0 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$107, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L255:
	.loc 2 107 67 discriminator 4
	leal	1(%r8), %eax
	.loc 2 107 38 is_stmt 1 discriminator 5
	cmpl	-52(%rbp), %eax
	jge	.L256
.L254:
.LBB123:
	.loc 2 107 33 discriminator 6
	leaq	.LC22(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L256:
.LBE123:
	.loc 2 110 10
	testb	%dl, %dl
	je	.L257
	.loc 2 110 44 discriminator 1
	movl	-88(%rbp), %eax
	movl	%eax, -132(%rbp)
.L257:
	.loc 2 110 44 is_stmt 0 discriminator 2
	movl	-52(%rbp), %eax
	movl	%eax, -88(%rbp)
	.loc 2 110 10 is_stmt 1 discriminator 2
	testb	%dl, %dl
	je	.L258
	.loc 2 110 44 discriminator 3
	movl	-132(%rbp), %ebx
	cmpl	%ebx, %eax
	jg	.L259
.LBB124:
	.loc 2 110 44 is_stmt 0 discriminator 4
	leaq	.LC23(%rip), %r12
	leaq	.LC3(%rip), %r13
	movq	%r12, %rdx
	movq	%r13, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L258:
.LBE124:
	.loc 2 110 10 is_stmt 1 discriminator 5
	movl	$1, %edx
.L259:
	.loc 2 111 13
	cmpl	-52(%rbp), %r9d
	jg	.L260
	.loc 2 111 13 is_stmt 0 discriminator 1
	cmpl	-52(%rbp), %r8d
	jge	.L261
.L260:
	.loc 2 111 13 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$111, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L261:
	.loc 2 111 25 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rax
	movl	-52(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdi, %rcx
	movzbl	(%rax,%rcx), %eax
	.loc 2 111 10 discriminator 3
	cmpb	$47, %al
	jbe	.L262
	.loc 2 111 25 discriminator 4
	movq	-80(%rbp), %rax
	movl	-52(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdi, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$57, %al
	jbe	.L263
.L262:
	.loc 2 112 41
	cmpl	-52(%rbp), %r9d
	jg	.L264
	.loc 2 112 41 is_stmt 0 discriminator 1
	cmpl	-52(%rbp), %r8d
	jge	.L265
.L264:
	.loc 2 112 41 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$112, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L265:
	.loc 2 112 16 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rax
	movl	-52(%rbp), %edx
	movslq	%edx, %rdx
	subq	%rdi, %rdx
	movzbl	(%rax,%rdx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_identifier_character@PLT
	.loc 2 112 13 discriminator 4
	testb	%al, %al
	je	.L266
	.loc 2 113 16
	movl	$0, %eax
	movq	%rax, -96(%rbp)
	jmp	.L239
.L266:
	.loc 2 115 13
	movl	-52(%rbp), %eax
	movabsq	$-4294967296, %rdx
	andq	-96(%rbp), %rdx
	orq	%rdx, %rax
	movq	%rax, %rbx
	movl	-56(%rbp), %eax
	salq	$32, %rax
	movl	%ebx, %edx
	orq	%rdx, %rax
	movq	%rax, -96(%rbp)
	jmp	.L239
.L263:
.LBB125:
	.loc 2 118 56
	cmpl	-52(%rbp), %r9d
	jg	.L267
	.loc 2 118 56 is_stmt 0 discriminator 1
	cmpl	-52(%rbp), %r8d
	jge	.L268
.L267:
	.loc 2 118 56 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$118, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L268:
	.loc 2 118 69 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rax
	movl	-52(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rdi, %rcx
	movzbl	(%rax,%rcx), %eax
	movzbl	%al, %eax
	subl	$48, %eax
	testl	%eax, %eax
	jns	.L269
	.loc 2 118 69 is_stmt 0 discriminator 4
	leaq	.LC17(%rip), %rax
	movl	$118, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L269:
	.loc 2 118 13 is_stmt 1 discriminator 5
	movl	%eax, -60(%rbp)
	.loc 2 120 43
	movl	$4096, %eax
	subl	-60(%rbp), %eax
	.loc 2 120 52
	movslq	%eax, %rcx
	imulq	$1717986919, %rcx, %rcx
	shrq	$32, %rcx
	movl	%ecx, %esi
	sarl	$2, %esi
	sarl	$31, %eax
	movl	%eax, %ecx
	movl	%esi, %eax
	subl	%ecx, %eax
	.loc 2 120 13
	cmpl	%eax, -56(%rbp)
	jle	.L270
	.loc 2 121 16
	movl	$0, %eax
	movq	%rax, -96(%rbp)
	jmp	.L239
.L270:
	.loc 2 123 33
	movl	-56(%rbp), %ecx
	movl	%ecx, %eax
	sall	$2, %eax
	addl	%ecx, %eax
	addl	%eax, %eax
	movl	%eax, %ecx
	movl	$0, %esi
	movl	-60(%rbp), %eax
	addl	%ecx, %eax
	movl	%eax, %ecx
	.loc 2 123 33 is_stmt 0 discriminator 1
	movl	%esi, %eax
	testl	%eax, %eax
	je	.L271
	.loc 2 123 33 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$123, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L271:
	.loc 2 123 33 discriminator 4
	movl	%ecx, %eax
	.loc 2 123 33 discriminator 5
	testl	%eax, %eax
	js	.L272
	.loc 2 123 33 discriminator 6
	cmpl	$4096, %eax
	jle	.L273
.L272:
	.loc 2 123 33 discriminator 7
	leaq	.LC17(%rip), %rax
	movl	$123, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L273:
	.loc 2 123 19 is_stmt 1 discriminator 8
	movl	%eax, -56(%rbp)
.LBE125:
	.loc 2 125 23
	movl	-52(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L274
	.loc 2 125 23 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L275
.L274:
	.loc 2 125 23 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$125, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L275:
	.loc 2 125 15 is_stmt 1 discriminator 3
	movl	%eax, -52(%rbp)
.LBE122:
	.loc 2 126 15
	jmp	.L276
.L253:
	.loc 2 127 7
	movl	-52(%rbp), %eax
	movabsq	$-4294967296, %rdx
	andq	-96(%rbp), %rdx
	orq	%rdx, %rax
	movq	%rax, %rbx
	movl	-56(%rbp), %eax
	salq	$32, %rax
	movl	%ebx, %edx
	orq	%rdx, %rax
	movq	%rax, -96(%rbp)
.L239:
.LBE118:
	.loc 2 128 8
	movq	-96(%rbp), %rax
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE13:
	.size	silver_output_lexical__read_capacity, .-silver_output_lexical__read_capacity
	.section	.rodata
	.align 8
.LC24:
	.ascii	"failed precondition from silver_output_lexical.ads:349"
	.align 8
.LC25:
	.ascii	"failed precondition from silver_output_lexical.ads:350"
	.align 8
.LC26:
	.ascii	"Loop_Invariant failed at silver_output_lexical.adb:143"
	.align 8
.LC27:
	.ascii	"Loop_Invariant failed at silver_output_lexical.adb:144"
	.align 8
.LC28:
	.ascii	"Loop_Variant failed at silver_output_lexical.adb:149"
	.text
	.align 2
	.globl	silver_output_lexical__match_sized_literal
	.type	silver_output_lexical__match_sized_literal, @function
silver_output_lexical__match_sized_literal:
.LFB14:
	.loc 2 130 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$136, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -80(%rbp)
	movq	%rbx, -72(%rbp)
	movl	%edx, -84(%rbp)
	.loc 2 130 4
	movq	-72(%rbp), %rax
	movl	(%rax), %r13d
	movq	-72(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%r13d, %r12d
	jl	.L278
	.loc 2 130 4 is_stmt 0 discriminator 1
	movslq	%r12d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r13d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L279
.L278:
	.loc 2 130 4 discriminator 2
	movl	$0, %ecx
	movl	$0, %ebx
.L279:
.LBB126:
	.loc 2 130 4 discriminator 3
	movslq	%r13d, %rax
	movq	%rax, -96(%rbp)
	cmpl	%r13d, %r12d
	.loc 2 130 4 discriminator 6
	cmpl	%r13d, %r12d
	.loc 2 130 4 discriminator 9
	cmpl	%r13d, %r12d
	.loc 1 349 15 is_stmt 1
	cmpl	$1, %r13d
	je	.L286
.LBB127:
	.loc 1 349 15 is_stmt 0 discriminator 1
	leaq	.LC24(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L286:
.LBE127:
	.loc 1 349 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 1 349 15 discriminator 2
	testl	%eax, %eax
	jle	.L287
	.loc 1 349 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L288
.L287:
.LBB128:
	.loc 1 349 15 discriminator 4
	leaq	.LC24(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L288:
.LBE128:
	.loc 1 350 41
	cmpl	$2147483647, %r12d
	jne	.L289
	.loc 1 350 41 is_stmt 0 discriminator 1
	leaq	.LC6(%rip), %rax
	movl	$350, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L289:
	.loc 1 350 41 discriminator 3
	leal	1(%r12), %eax
	.loc 1 349 15 is_stmt 1 discriminator 5
	cmpl	-84(%rbp), %eax
	jge	.L290
.LBB129:
	.loc 1 349 15 is_stmt 0 discriminator 6
	leaq	.LC25(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L290:
.LBE129:
	.loc 2 134 7 is_stmt 1
	movl	-84(%rbp), %eax
	movl	%eax, -52(%rbp)
	.loc 2 136 15
	movb	$0, -53(%rbp)
	.loc 2 137 14
	movl	$0, -60(%rbp)
	.loc 2 138 7
	cmpl	-84(%rbp), %r12d
	jl	.L291
	.loc 2 138 39 discriminator 1
	cmpl	-84(%rbp), %r13d
	jg	.L292
	.loc 2 138 39 is_stmt 0 discriminator 2
	cmpl	-84(%rbp), %r12d
	jge	.L293
.L292:
	.loc 2 138 39 discriminator 3
	leaq	.LC17(%rip), %rax
	movl	$138, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L293:
	.loc 2 138 55 is_stmt 1 discriminator 4
	movq	-80(%rbp), %rdx
	movl	-84(%rbp), %eax
	cltq
	movq	-96(%rbp), %rbx
	subq	%rbx, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 138 55 is_stmt 0 discriminator 5
	cmpb	$34, %al
	setne	%al
	.loc 2 138 31 is_stmt 1 discriminator 5
	testb	%al, %al
	jne	.L291
	.loc 2 141 28
	movl	-84(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L294
	.loc 2 141 28 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L295
.L294:
	.loc 2 141 28 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$141, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L295:
	.loc 2 141 16 is_stmt 1 discriminator 3
	movl	%eax, -84(%rbp)
	.loc 2 142 35
	movl	$0, %ebx
.L330:
	.loc 2 142 7 discriminator 1
	cmpl	-84(%rbp), %r12d
	jl	.L332
.LBB130:
	.loc 2 143 33
	movl	-52(%rbp), %eax
	cmpl	-84(%rbp), %eax
	jge	.L297
	.loc 2 143 68 discriminator 1
	cmpl	$2147483647, %r12d
	jne	.L298
	.loc 2 143 68 is_stmt 0 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$143, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L298:
	.loc 2 143 68 discriminator 4
	leal	1(%r12), %eax
	.loc 2 143 42 is_stmt 1 discriminator 5
	cmpl	-84(%rbp), %eax
	jge	.L299
.L297:
.LBB131:
	.loc 2 143 33 discriminator 6
	leaq	.LC26(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L299:
.LBE131:
	.loc 2 144 53
	movl	-84(%rbp), %eax
	subl	-52(%rbp), %eax
	movl	%eax, %edx
	.loc 2 144 40
	movl	-60(%rbp), %eax
	.loc 2 144 33
	cmpl	%eax, %edx
	jg	.L300
.LBB132:
	.loc 2 144 33 is_stmt 0 discriminator 1
	leaq	.LC27(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L300:
.LBE132:
	.loc 2 149 10 is_stmt 1
	testb	%bl, %bl
	je	.L301
	.loc 2 149 44 discriminator 1
	movl	-88(%rbp), %eax
	movl	%eax, -164(%rbp)
.L301:
	.loc 2 149 44 is_stmt 0 discriminator 2
	movl	-84(%rbp), %eax
	movl	%eax, -88(%rbp)
	.loc 2 149 10 is_stmt 1 discriminator 2
	testb	%bl, %bl
	je	.L302
	.loc 2 149 44 discriminator 3
	movl	-164(%rbp), %ecx
	cmpl	%ecx, %eax
	jg	.L303
.LBB133:
	.loc 2 149 44 is_stmt 0 discriminator 4
	leaq	.LC28(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC3(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L302:
.LBE133:
	.loc 2 149 10 is_stmt 1 discriminator 5
	movl	$1, %ebx
.L303:
	.loc 2 150 13
	cmpl	-84(%rbp), %r13d
	jg	.L304
	.loc 2 150 13 is_stmt 0 discriminator 1
	cmpl	-84(%rbp), %r12d
	jge	.L305
.L304:
	.loc 2 150 13 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$150, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L305:
	.loc 2 150 29 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rdx
	movl	-84(%rbp), %eax
	cltq
	movq	-96(%rbp), %rdi
	subq	%rdi, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 150 10 discriminator 4
	cmpb	$34, %al
	jne	.L306
	.loc 2 151 13
	cmpl	-84(%rbp), %r12d
	jle	.L307
	.loc 2 151 61 discriminator 1
	movl	-84(%rbp), %eax
	addl	$1, %eax
	.loc 2 151 46 discriminator 1
	cmpl	%eax, %r13d
	jg	.L308
	.loc 2 151 46 is_stmt 0 discriminator 2
	cmpl	%eax, %r12d
	jge	.L309
.L308:
	.loc 2 151 46 discriminator 3
	leaq	.LC17(%rip), %rax
	movl	$151, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L309:
	.loc 2 151 66 is_stmt 1 discriminator 4
	movq	-80(%rbp), %rdx
	cltq
	movq	-96(%rbp), %rcx
	subq	%rcx, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 151 66 is_stmt 0 discriminator 5
	cmpb	$34, %al
	sete	%al
	.loc 2 151 37 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L307
	.loc 2 152 37
	movl	-84(%rbp), %eax
	addl	$2, %eax
	testl	%eax, %eax
	jle	.L310
	.loc 2 152 37 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L311
.L310:
	.loc 2 152 37 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$152, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L311:
	.loc 2 152 25 is_stmt 1 discriminator 3
	movl	%eax, -84(%rbp)
	.loc 2 153 33
	movl	-60(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L312
	.loc 2 153 33 is_stmt 0 discriminator 1
	cmpl	$4096, %eax
	jle	.L313
.L312:
	.loc 2 153 33 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$153, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L313:
	.loc 2 153 23 is_stmt 1 discriminator 3
	movl	%eax, -60(%rbp)
	jmp	.L330
.L307:
	.loc 2 155 37
	movl	-84(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L315
	.loc 2 155 37 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L316
.L315:
	.loc 2 155 37 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$155, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L316:
	.loc 2 155 25 is_stmt 1 discriminator 3
	movl	%eax, -84(%rbp)
	.loc 2 156 24
	movb	$1, -53(%rbp)
	.loc 2 157 16
	jmp	.L291
.L306:
	.loc 2 159 16
	cmpl	-84(%rbp), %r13d
	jg	.L317
	.loc 2 159 16 is_stmt 0 discriminator 1
	cmpl	-84(%rbp), %r12d
	jge	.L318
.L317:
	.loc 2 159 16 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$159, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L318:
	.loc 2 159 32 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rdx
	movl	-84(%rbp), %eax
	cltq
	movq	-96(%rbp), %rdi
	subq	%rdi, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 159 32 is_stmt 0 discriminator 4
	cmpb	$91, %al
	sete	%al
	.loc 2 159 10 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L319
	.loc 2 159 60 discriminator 5
	movl	-84(%rbp), %eax
	addl	$1, %eax
	.loc 2 159 38 discriminator 5
	cmpl	%eax, %r12d
	jle	.L319
	.loc 2 160 36
	movl	-84(%rbp), %eax
	addl	$1, %eax
	.loc 2 160 21
	cmpl	%eax, %r13d
	jg	.L320
	.loc 2 160 21 is_stmt 0 discriminator 1
	cmpl	%eax, %r12d
	jge	.L321
.L320:
	.loc 2 160 21 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$160, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L321:
	.loc 2 160 41 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rdx
	cltq
	movq	-96(%rbp), %rcx
	subq	%rcx, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 160 41 is_stmt 0 discriminator 4
	cmpb	$34, %al
	sete	%al
	.loc 2 160 12 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L319
	.loc 2 161 61
	movl	-84(%rbp), %eax
	addl	$2, %eax
	.loc 2 161 46
	cmpl	%eax, %r13d
	jg	.L322
	.loc 2 161 46 is_stmt 0 discriminator 1
	cmpl	%eax, %r12d
	jge	.L323
.L322:
	.loc 2 161 46 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$161, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L323:
	.loc 2 161 21 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rdx
	cltq
	movq	-96(%rbp), %rdi
	subq	%rdi, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 161 21 is_stmt 0 discriminator 4
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_identifier_character@PLT
	.loc 2 161 12 is_stmt 1 discriminator 5
	testb	%al, %al
	jne	.L291
.L319:
	.loc 2 164 16
	cmpl	-84(%rbp), %r13d
	jg	.L324
	.loc 2 164 16 is_stmt 0 discriminator 1
	cmpl	-84(%rbp), %r12d
	jge	.L325
.L324:
	.loc 2 164 16 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$164, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L325:
	.loc 2 164 32 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rdx
	movl	-84(%rbp), %eax
	cltq
	movq	-96(%rbp), %rcx
	subq	%rcx, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 164 10 discriminator 4
	cmpb	$31, %al
	jbe	.L291
	.loc 2 164 32 discriminator 5
	movq	-80(%rbp), %rdx
	movl	-84(%rbp), %eax
	cltq
	subq	%rcx, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 164 32 is_stmt 0 discriminator 6
	cmpb	$126, %al
	ja	.L291
	.loc 2 165 34 is_stmt 1
	movl	-84(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L326
	.loc 2 165 34 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L327
.L326:
	.loc 2 165 34 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$165, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L327:
	.loc 2 165 22 is_stmt 1 discriminator 3
	movl	%eax, -84(%rbp)
	.loc 2 166 30
	movl	-60(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	js	.L328
	.loc 2 166 30 is_stmt 0 discriminator 1
	cmpl	$4096, %eax
	jle	.L329
.L328:
	.loc 2 166 30 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$166, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L329:
	.loc 2 166 20 is_stmt 1 discriminator 3
	movl	%eax, -60(%rbp)
.LBE130:
	.loc 2 170 15
	jmp	.L330
.L332:
	.loc 2 171 8
	nop
.L291:
.LBE126:
	.loc 2 171 8 is_stmt 0 discriminator 1
	movl	-84(%rbp), %eax
	movq	-112(%rbp), %rcx
	movabsq	$-4294967296, %rdx
	andq	%rcx, %rdx
	orq	%rdx, %rax
	movq	%rax, -112(%rbp)
	movzbl	-53(%rbp), %eax
	movzbl	%al, %eax
	salq	$32, %rax
	movq	-112(%rbp), %rcx
	movabsq	$-1095216660481, %rdx
	andq	%rcx, %rdx
	orq	%rdx, %rax
	movq	%rax, -112(%rbp)
	movl	-60(%rbp), %eax
	movl	%eax, %edx
	movq	-104(%rbp), %rcx
	movabsq	$-4294967296, %rax
	andq	%rcx, %rax
	orq	%rdx, %rax
	movq	%rax, -104(%rbp)
	.loc 2 171 8 discriminator 3
	movq	-112(%rbp), %rax
	movq	-104(%rbp), %rdx
	.loc 2 171 8
	addq	$136, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE14:
	.size	silver_output_lexical__match_sized_literal, .-silver_output_lexical__match_sized_literal
	.section	.rodata
	.align 8
.LC29:
	.ascii	"failed precondition from silver_output_lexical.ads:363"
	.align 8
.LC30:
	.ascii	"failed precondition from silver_output_lexical.ads:364"
	.align 8
.LC31:
	.ascii	"failed precondition from silver_output_lexical.ads:365"
	.align 8
.LC32:
	.ascii	"Loop_Invariant failed at silver_output_lexical.adb:181"
	.align 8
.LC33:
	.ascii	"Loop_Variant failed at silver_output_lexical.adb:184"
	.text
	.align 2
	.globl	silver_output_lexical__skip_comment
	.type	silver_output_lexical__skip_comment, @function
silver_output_lexical__skip_comment:
.LFB15:
	.loc 2 173 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -80(%rbp)
	movq	%rbx, -72(%rbp)
	movl	%edx, -84(%rbp)
	.loc 2 173 4
	movq	-72(%rbp), %rax
	movl	(%rax), %r13d
	movq	-72(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%r13d, %r12d
	jl	.L334
	.loc 2 173 4 is_stmt 0 discriminator 1
	movslq	%r12d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r13d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L335
.L334:
	.loc 2 173 4 discriminator 2
	movl	$0, %ecx
	movl	$0, %ebx
.L335:
.LBB134:
	.loc 2 173 4 discriminator 3
	movslq	%r13d, %rax
	movq	%rax, -96(%rbp)
	cmpl	%r13d, %r12d
	.loc 2 173 4 discriminator 6
	cmpl	%r13d, %r12d
	.loc 2 173 4 discriminator 9
	cmpl	%r13d, %r12d
	.loc 1 363 15 is_stmt 1
	cmpl	$1, %r13d
	je	.L342
.LBB135:
	.loc 1 363 15 is_stmt 0 discriminator 1
	leaq	.LC29(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L342:
.LBE135:
	.loc 1 364 31 is_stmt 1
	movl	%ecx, %eax
	.loc 1 363 15 discriminator 2
	testl	%eax, %eax
	jle	.L343
	.loc 1 364 31 discriminator 1
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L344
.L343:
.LBB136:
	.loc 1 363 15 discriminator 3
	leaq	.LC30(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L344:
.LBE136:
	.loc 1 365 41
	cmpl	$2147483647, %r12d
	jne	.L345
	.loc 1 365 41 is_stmt 0 discriminator 1
	leaq	.LC6(%rip), %rax
	movl	$365, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L345:
	.loc 1 365 41 discriminator 3
	leal	1(%r12), %eax
	.loc 1 363 15 is_stmt 1 discriminator 4
	cmpl	-84(%rbp), %eax
	jge	.L346
.LBB137:
	.loc 1 363 15 is_stmt 0 discriminator 5
	leaq	.LC31(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L346:
.LBE137:
	.loc 2 175 7 is_stmt 1
	movl	-84(%rbp), %eax
	movl	%eax, -52(%rbp)
	.loc 2 179 7
	movl	$0, %ebx
.L358:
	.loc 2 177 7
	cmpl	-84(%rbp), %r12d
	jl	.L361
	.loc 2 178 38
	cmpl	-84(%rbp), %r13d
	jg	.L348
	.loc 2 178 38 is_stmt 0 discriminator 1
	cmpl	-84(%rbp), %r12d
	jge	.L349
.L348:
	.loc 2 178 38 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$178, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L349:
	.loc 2 178 22 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rax
	movl	-84(%rbp), %edx
	movslq	%edx, %rdx
	movq	-96(%rbp), %rcx
	subq	%rcx, %rdx
	movzbl	(%rax,%rdx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_comment_end@PLT
	.loc 2 178 18 discriminator 4
	xorl	$1, %eax
	.loc 2 178 9 discriminator 4
	testb	%al, %al
	je	.L361
.LBB138:
	.loc 2 181 13
	movl	-84(%rbp), %eax
	cmpl	-52(%rbp), %eax
	jl	.L350
	.loc 2 181 55 discriminator 1
	cmpl	$2147483647, %r12d
	jne	.L351
	.loc 2 181 55 is_stmt 0 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$181, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L351:
	.loc 2 181 55 discriminator 4
	leal	1(%r12), %eax
	.loc 2 181 22 is_stmt 1 discriminator 5
	cmpl	-84(%rbp), %eax
	jge	.L352
.L350:
.LBB139:
	.loc 2 181 13 discriminator 6
	leaq	.LC32(%rip), %rax
	movq	%rax, -112(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -104(%rbp)
	movq	-112(%rbp), %rbx
	movq	-104(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L352:
.LBE139:
	.loc 2 184 10
	testb	%bl, %bl
	je	.L353
	.loc 2 184 44 discriminator 1
	movl	-88(%rbp), %eax
	movl	%eax, -132(%rbp)
.L353:
	.loc 2 184 44 is_stmt 0 discriminator 2
	movl	-84(%rbp), %eax
	movl	%eax, -88(%rbp)
	.loc 2 184 10 is_stmt 1 discriminator 2
	testb	%bl, %bl
	je	.L354
	.loc 2 184 44 discriminator 3
	movl	-132(%rbp), %edi
	cmpl	%edi, %eax
	jg	.L355
.LBB140:
	.loc 2 184 44 is_stmt 0 discriminator 4
	leaq	.LC33(%rip), %r14
	leaq	.LC3(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L354:
.LBE140:
	.loc 2 184 10 is_stmt 1 discriminator 5
	movl	$1, %ebx
.L355:
	.loc 2 185 31
	movl	-84(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L356
	.loc 2 185 31 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L357
.L356:
	.loc 2 185 31 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$185, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L357:
	.loc 2 185 19 is_stmt 1 discriminator 3
	movl	%eax, -84(%rbp)
.LBE138:
	.loc 2 186 15
	jmp	.L358
.L361:
	.loc 2 187 8
	nop
.LBE134:
	.loc 2 187 8 is_stmt 0 discriminator 1
	movl	-84(%rbp), %eax
	.loc 2 187 8
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE15:
	.size	silver_output_lexical__skip_comment, .-silver_output_lexical__skip_comment
	.section	.rodata
	.align 8
.LC34:
	.ascii	"failed precondition from silver_output_lexical.ads:372"
	.align 8
.LC35:
	.ascii	"failed precondition from silver_output_lexical.ads:373"
	.align 8
.LC36:
	.ascii	"failed precondition from silver_output_lexical.ads:374"
	.align 8
.LC37:
	.ascii	"Loop_Invariant failed at silver_output_lexical.adb:195"
	.align 8
.LC38:
	.ascii	"Loop_Variant failed at silver_output_lexical.adb:198"
	.text
	.align 2
	.globl	silver_output_lexical__skip_trivia
	.type	silver_output_lexical__skip_trivia, @function
silver_output_lexical__skip_trivia:
.LFB16:
	.loc 2 189 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -80(%rbp)
	movq	%rbx, -72(%rbp)
	movl	%edx, -84(%rbp)
	.loc 2 189 4
	movq	-72(%rbp), %rax
	movl	(%rax), %r13d
	movq	-72(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%r13d, %r12d
	jl	.L363
	.loc 2 189 4 is_stmt 0 discriminator 1
	movslq	%r12d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r13d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L364
.L363:
	.loc 2 189 4 discriminator 2
	movl	$0, %ecx
	movl	$0, %ebx
.L364:
.LBB141:
	.loc 2 189 4 discriminator 3
	movslq	%r13d, %r14
	cmpl	%r13d, %r12d
	.loc 2 189 4 discriminator 6
	cmpl	%r13d, %r12d
	.loc 2 189 4 discriminator 9
	cmpl	%r13d, %r12d
	.loc 1 372 15 is_stmt 1
	cmpl	$1, %r13d
	je	.L371
.LBB142:
	.loc 1 372 15 is_stmt 0 discriminator 1
	leaq	.LC34(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L371:
.LBE142:
	.loc 1 373 31 is_stmt 1
	movl	%ecx, %eax
	.loc 1 372 15 discriminator 2
	testl	%eax, %eax
	jle	.L372
	.loc 1 373 31 discriminator 1
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L373
.L372:
.LBB143:
	.loc 1 372 15 discriminator 3
	leaq	.LC35(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L373:
.LBE143:
	.loc 1 374 41
	cmpl	$2147483647, %r12d
	jne	.L374
	.loc 1 374 41 is_stmt 0 discriminator 1
	leaq	.LC6(%rip), %rax
	movl	$374, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L374:
	.loc 1 374 41 discriminator 3
	leal	1(%r12), %eax
	.loc 1 372 15 is_stmt 1 discriminator 4
	cmpl	-84(%rbp), %eax
	jge	.L375
.LBB144:
	.loc 1 372 15 is_stmt 0 discriminator 5
	leaq	.LC36(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L375:
.LBE144:
	.loc 2 191 7 is_stmt 1
	movl	-84(%rbp), %eax
	movl	%eax, -52(%rbp)
	.loc 2 193 35
	movl	$0, %ebx
.L396:
	.loc 2 193 7 discriminator 1
	cmpl	-84(%rbp), %r12d
	jl	.L398
.LBB145:
	.loc 2 195 13
	movl	-84(%rbp), %eax
	cmpl	-52(%rbp), %eax
	jl	.L377
	.loc 2 195 55 discriminator 1
	cmpl	$2147483647, %r12d
	jne	.L378
	.loc 2 195 55 is_stmt 0 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$195, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L378:
	.loc 2 195 55 discriminator 4
	leal	1(%r12), %eax
	.loc 2 195 22 is_stmt 1 discriminator 5
	cmpl	-84(%rbp), %eax
	jge	.L379
.L377:
.LBB146:
	.loc 2 195 13 discriminator 6
	leaq	.LC37(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L379:
.LBE146:
	.loc 2 198 10
	testb	%bl, %bl
	je	.L380
	.loc 2 198 44 discriminator 1
	movl	%r15d, -88(%rbp)
.L380:
	.loc 2 198 44 is_stmt 0 discriminator 2
	movl	-84(%rbp), %r15d
	.loc 2 198 10 is_stmt 1 discriminator 2
	testb	%bl, %bl
	je	.L381
	.loc 2 198 44 discriminator 3
	movl	-88(%rbp), %eax
	cmpl	%eax, %r15d
	jg	.L382
.LBB147:
	.loc 2 198 44 is_stmt 0 discriminator 4
	leaq	.LC38(%rip), %rax
	movq	%rax, -112(%rbp)
	leaq	.LC3(%rip), %rax
	movq	%rax, -104(%rbp)
	movq	-112(%rbp), %rbx
	movq	-104(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L381:
.LBE147:
	.loc 2 198 10 is_stmt 1 discriminator 5
	movl	$1, %ebx
.L382:
	.loc 2 200 28
	cmpl	-84(%rbp), %r13d
	jg	.L383
	.loc 2 200 28 is_stmt 0 discriminator 1
	cmpl	-84(%rbp), %r12d
	jge	.L384
.L383:
	.loc 2 200 28 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$200, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L384:
	.loc 2 200 13 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rax
	movl	-84(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r14, %rdx
	movzbl	(%rax,%rdx), %eax
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_whitespace@PLT
	.loc 2 200 10 discriminator 4
	testb	%al, %al
	je	.L385
	.loc 2 201 34
	movl	-84(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L386
	.loc 2 201 34 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L387
.L386:
	.loc 2 201 34 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$201, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L387:
	.loc 2 201 22 is_stmt 1 discriminator 3
	movl	%eax, -84(%rbp)
	jmp	.L396
.L385:
	.loc 2 202 16
	cmpl	-84(%rbp), %r13d
	jg	.L389
	.loc 2 202 16 is_stmt 0 discriminator 1
	cmpl	-84(%rbp), %r12d
	jge	.L390
.L389:
	.loc 2 202 16 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$202, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L390:
	.loc 2 202 32 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rax
	movl	-84(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r14, %rdx
	movzbl	(%rax,%rdx), %eax
	cmpb	$45, %al
	sete	%al
	.loc 2 202 10 discriminator 3
	testb	%al, %al
	je	.L391
	.loc 2 203 12
	cmpl	-84(%rbp), %r12d
	jle	.L391
	.loc 2 204 36
	movl	-84(%rbp), %eax
	addl	$1, %eax
	.loc 2 204 21
	cmpl	%eax, %r13d
	jg	.L392
	.loc 2 204 21 is_stmt 0 discriminator 1
	cmpl	%eax, %r12d
	jge	.L393
.L392:
	.loc 2 204 21 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$204, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L393:
	.loc 2 204 41 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rdx
	cltq
	subq	%r14, %rax
	movzbl	(%rdx,%rax), %eax
	cmpb	$45, %al
	sete	%al
	.loc 2 204 12 discriminator 3
	testb	%al, %al
	je	.L391
	.loc 2 206 34
	movl	-84(%rbp), %eax
	addl	$2, %eax
	testl	%eax, %eax
	jle	.L394
	.loc 2 206 34 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L395
.L394:
	.loc 2 206 34 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$206, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L395:
	.loc 2 206 22 is_stmt 1 discriminator 3
	movl	%eax, -84(%rbp)
	.loc 2 207 13
	movl	-84(%rbp), %edx
	movq	-80(%rbp), %rcx
	movq	-72(%rbp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rsi
	call	silver_output_lexical__skip_comment
	.loc 2 207 13 is_stmt 0 discriminator 1
	movl	%eax, -84(%rbp)
.LBE145:
	.loc 2 211 15 is_stmt 1
	jmp	.L396
.L398:
	.loc 2 212 8
	nop
.L391:
.LBE141:
	.loc 2 212 8 is_stmt 0 discriminator 1
	movl	-84(%rbp), %eax
	.loc 2 212 8
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE16:
	.size	silver_output_lexical__skip_trivia, .-silver_output_lexical__skip_trivia
	.section	.rodata
	.align 8
.LC39:
	.ascii	"failed precondition from silver_output_lexical.ads:381"
	.align 8
.LC40:
	.ascii	"failed precondition from silver_output_lexical.ads:382"
	.align 8
.LC41:
	.ascii	"failed precondition from silver_output_lexical.ads:383"
	.align 8
.LC42:
	.ascii	"Loop_Invariant failed at silver_output_lexical.adb:225"
	.align 8
.LC43:
	.ascii	"Loop_Variant failed at silver_output_lexical.adb:228"
	.text
	.align 2
	.globl	silver_output_lexical__match_literal
	.type	silver_output_lexical__match_literal, @function
silver_output_lexical__match_literal:
.LFB17:
	.loc 2 214 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -80(%rbp)
	movq	%rbx, -72(%rbp)
	movl	%edx, -84(%rbp)
	.loc 2 214 4
	movq	-72(%rbp), %rax
	movl	(%rax), %r14d
	movq	-72(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%r14d, %r12d
	jl	.L400
	.loc 2 214 4 is_stmt 0 discriminator 1
	movslq	%r12d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r14d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L401
.L400:
	.loc 2 214 4 discriminator 2
	movl	$0, %ecx
	movl	$0, %ebx
.L401:
.LBB148:
	.loc 2 214 4 discriminator 3
	movslq	%r14d, %r13
	cmpl	%r14d, %r12d
	.loc 2 214 4 discriminator 6
	cmpl	%r14d, %r12d
	.loc 2 214 4 discriminator 9
	cmpl	%r14d, %r12d
	.loc 1 381 15 is_stmt 1
	cmpl	$1, %r14d
	je	.L408
.LBB149:
	.loc 1 381 15 is_stmt 0 discriminator 1
	leaq	.LC39(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L408:
.LBE149:
	.loc 1 382 31 is_stmt 1
	movl	%ecx, %eax
	.loc 1 381 15 discriminator 2
	testl	%eax, %eax
	jle	.L409
	.loc 1 382 31 discriminator 1
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L410
.L409:
.LBB150:
	.loc 1 381 15 discriminator 3
	leaq	.LC40(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L410:
.LBE150:
	.loc 1 383 41
	cmpl	$2147483647, %r12d
	jne	.L411
	.loc 1 383 41 is_stmt 0 discriminator 1
	leaq	.LC6(%rip), %rax
	movl	$383, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L411:
	.loc 1 383 41 discriminator 3
	leal	1(%r12), %eax
	.loc 1 381 15 is_stmt 1 discriminator 4
	cmpl	-84(%rbp), %eax
	jge	.L412
.LBB151:
	.loc 1 381 15 is_stmt 0 discriminator 5
	leaq	.LC41(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L412:
.LBE151:
	.loc 2 217 7 is_stmt 1
	movl	-84(%rbp), %eax
	movl	%eax, -52(%rbp)
	.loc 2 219 15
	movb	$0, -53(%rbp)
	.loc 2 220 7
	cmpl	-84(%rbp), %r12d
	jl	.L413
	.loc 2 220 39 discriminator 1
	cmpl	-84(%rbp), %r14d
	jg	.L414
	.loc 2 220 39 is_stmt 0 discriminator 2
	cmpl	-84(%rbp), %r12d
	jge	.L415
.L414:
	.loc 2 220 39 discriminator 3
	leaq	.LC17(%rip), %rax
	movl	$220, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L415:
	.loc 2 220 55 is_stmt 1 discriminator 4
	movq	-80(%rbp), %rax
	movl	-84(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 2 220 55 is_stmt 0 discriminator 5
	cmpb	$34, %al
	setne	%al
	.loc 2 220 31 is_stmt 1 discriminator 5
	testb	%al, %al
	jne	.L413
	.loc 2 223 28
	movl	-84(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L416
	.loc 2 223 28 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L417
.L416:
	.loc 2 223 28 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$223, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L417:
	.loc 2 223 16 is_stmt 1 discriminator 3
	movl	%eax, -84(%rbp)
	.loc 2 224 35
	movl	$0, %ebx
.L447:
	.loc 2 224 7 discriminator 1
	cmpl	-84(%rbp), %r12d
	jl	.L449
.LBB152:
	.loc 2 225 33
	movl	-52(%rbp), %eax
	cmpl	-84(%rbp), %eax
	jge	.L419
	.loc 2 225 68 discriminator 1
	cmpl	$2147483647, %r12d
	jne	.L420
	.loc 2 225 68 is_stmt 0 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$225, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L420:
	.loc 2 225 68 discriminator 4
	leal	1(%r12), %eax
	.loc 2 225 42 is_stmt 1 discriminator 5
	cmpl	-84(%rbp), %eax
	jge	.L421
.L419:
.LBB153:
	.loc 2 225 33 discriminator 6
	leaq	.LC42(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L421:
.LBE153:
	.loc 2 228 10
	testb	%bl, %bl
	je	.L422
	.loc 2 228 44 discriminator 1
	movl	%r15d, -88(%rbp)
.L422:
	.loc 2 228 44 is_stmt 0 discriminator 2
	movl	-84(%rbp), %r15d
	.loc 2 228 10 is_stmt 1 discriminator 2
	testb	%bl, %bl
	je	.L423
	.loc 2 228 44 discriminator 3
	movl	-88(%rbp), %eax
	cmpl	%eax, %r15d
	jg	.L424
.LBB154:
	.loc 2 228 44 is_stmt 0 discriminator 4
	leaq	.LC43(%rip), %rax
	movq	%rax, -112(%rbp)
	leaq	.LC3(%rip), %rax
	movq	%rax, -104(%rbp)
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L423:
.LBE154:
	.loc 2 228 10 is_stmt 1 discriminator 5
	movl	$1, %ebx
.L424:
	.loc 2 229 13
	cmpl	-84(%rbp), %r14d
	jg	.L425
	.loc 2 229 13 is_stmt 0 discriminator 1
	cmpl	-84(%rbp), %r12d
	jge	.L426
.L425:
	.loc 2 229 13 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$229, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L426:
	.loc 2 229 29 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rax
	movl	-84(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 2 229 10 discriminator 4
	cmpb	$34, %al
	jne	.L427
	.loc 2 230 13
	cmpl	-84(%rbp), %r12d
	jle	.L428
	.loc 2 231 39
	movl	-84(%rbp), %eax
	addl	$1, %eax
	.loc 2 231 24
	cmpl	%eax, %r14d
	jg	.L429
	.loc 2 231 24 is_stmt 0 discriminator 1
	cmpl	%eax, %r12d
	jge	.L430
.L429:
	.loc 2 231 24 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$231, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L430:
	.loc 2 231 44 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rdx
	cltq
	subq	%r13, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 231 44 is_stmt 0 discriminator 4
	cmpb	$34, %al
	sete	%al
	.loc 2 231 15 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L428
	.loc 2 233 37
	movl	-84(%rbp), %eax
	addl	$2, %eax
	testl	%eax, %eax
	jle	.L431
	.loc 2 233 37 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L432
.L431:
	.loc 2 233 37 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$233, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L432:
	.loc 2 233 25 is_stmt 1 discriminator 3
	movl	%eax, -84(%rbp)
	jmp	.L447
.L428:
	.loc 2 235 37
	movl	-84(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L434
	.loc 2 235 37 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L435
.L434:
	.loc 2 235 37 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$235, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L435:
	.loc 2 235 25 is_stmt 1 discriminator 3
	movl	%eax, -84(%rbp)
	.loc 2 236 24
	movb	$1, -53(%rbp)
	.loc 2 237 16
	jmp	.L413
.L427:
	.loc 2 239 16
	cmpl	-84(%rbp), %r14d
	jg	.L436
	.loc 2 239 16 is_stmt 0 discriminator 1
	cmpl	-84(%rbp), %r12d
	jge	.L437
.L436:
	.loc 2 239 16 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$239, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L437:
	.loc 2 239 32 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rax
	movl	-84(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 2 239 32 is_stmt 0 discriminator 4
	cmpb	$91, %al
	sete	%al
	.loc 2 239 10 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L438
	.loc 2 239 60 discriminator 5
	movl	-84(%rbp), %eax
	addl	$1, %eax
	.loc 2 239 38 discriminator 5
	cmpl	%eax, %r12d
	jle	.L438
	.loc 2 240 36
	movl	-84(%rbp), %eax
	addl	$1, %eax
	.loc 2 240 21
	cmpl	%eax, %r14d
	jg	.L439
	.loc 2 240 21 is_stmt 0 discriminator 1
	cmpl	%eax, %r12d
	jge	.L440
.L439:
	.loc 2 240 21 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$240, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L440:
	.loc 2 240 41 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rdx
	cltq
	subq	%r13, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 240 41 is_stmt 0 discriminator 4
	cmpb	$34, %al
	sete	%al
	.loc 2 240 12 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L438
	.loc 2 241 61
	movl	-84(%rbp), %eax
	addl	$2, %eax
	.loc 2 241 46
	cmpl	%eax, %r14d
	jg	.L441
	.loc 2 241 46 is_stmt 0 discriminator 1
	cmpl	%eax, %r12d
	jge	.L442
.L441:
	.loc 2 241 46 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$241, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L442:
	.loc 2 241 21 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rdx
	cltq
	subq	%r13, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 241 21 is_stmt 0 discriminator 4
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_identifier_character@PLT
	.loc 2 241 12 is_stmt 1 discriminator 5
	testb	%al, %al
	jne	.L413
.L438:
	.loc 2 244 16
	cmpl	-84(%rbp), %r14d
	jg	.L443
	.loc 2 244 16 is_stmt 0 discriminator 1
	cmpl	-84(%rbp), %r12d
	jge	.L444
.L443:
	.loc 2 244 16 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$244, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L444:
	.loc 2 244 32 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rax
	movl	-84(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 2 244 10 discriminator 4
	cmpb	$31, %al
	jbe	.L413
	.loc 2 244 32 discriminator 5
	movq	-80(%rbp), %rax
	movl	-84(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 2 244 32 is_stmt 0 discriminator 6
	cmpb	$126, %al
	ja	.L413
	.loc 2 245 34 is_stmt 1
	movl	-84(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L445
	.loc 2 245 34 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L446
.L445:
	.loc 2 245 34 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$245, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L446:
	.loc 2 245 22 is_stmt 1 discriminator 3
	movl	%eax, -84(%rbp)
.LBE152:
	.loc 2 249 15
	jmp	.L447
.L449:
	.loc 2 250 8
	nop
.L413:
.LBE148:
	.loc 2 250 8 is_stmt 0 discriminator 1
	movl	-84(%rbp), %eax
	movabsq	$-4294967296, %rdx
	andq	-96(%rbp), %rdx
	orq	%rdx, %rax
	movq	%rax, %rcx
	movzbl	-53(%rbp), %eax
	movzbl	%al, %eax
	salq	$32, %rax
	movabsq	$-1095216660481, %rdx
	andq	%rcx, %rdx
	orq	%rdx, %rax
	.loc 2 250 8
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE17:
	.size	silver_output_lexical__match_literal, .-silver_output_lexical__match_literal
	.section	.rodata
	.align 8
.LC44:
	.ascii	"failed precondition from silver_output_lexical.ads:395"
	.align 8
.LC45:
	.ascii	"failed precondition from silver_output_lexical.ads:396"
	.align 8
.LC46:
	.ascii	"Loop_Invariant failed at silver_output_lexical.adb:264"
	.align 8
.LC47:
	.ascii	"Loop_Variant failed at silver_output_lexical.adb:268"
	.text
	.align 2
	.globl	silver_output_lexical__match_identifier
	.type	silver_output_lexical__match_identifier, @function
silver_output_lexical__match_identifier:
.LFB18:
	.loc 2 252 4 is_stmt 1
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$104, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -80(%rbp)
	movq	%rbx, -72(%rbp)
	movl	%edx, -84(%rbp)
	.loc 2 252 4
	movq	-72(%rbp), %rax
	movl	(%rax), %r13d
	movq	-72(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%r13d, %r12d
	jl	.L451
	.loc 2 252 4 is_stmt 0 discriminator 1
	movslq	%r12d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r13d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rcx
	movq	%rdx, %rbx
	jmp	.L452
.L451:
	.loc 2 252 4 discriminator 2
	movl	$0, %ecx
	movl	$0, %ebx
.L452:
.LBB155:
	.loc 2 252 4 discriminator 3
	movslq	%r13d, %r14
	cmpl	%r13d, %r12d
	.loc 2 252 4 discriminator 6
	cmpl	%r13d, %r12d
	.loc 2 252 4 discriminator 9
	cmpl	%r13d, %r12d
	.loc 1 395 15 is_stmt 1
	cmpl	$1, %r13d
	je	.L459
.LBB156:
	.loc 1 395 15 is_stmt 0 discriminator 1
	leaq	.LC44(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L459:
.LBE156:
	.loc 1 395 51 is_stmt 1 discriminator 2
	movl	%ecx, %eax
	.loc 1 395 15 discriminator 2
	testl	%eax, %eax
	jle	.L460
	.loc 1 395 51 discriminator 3
	movl	%ecx, %eax
	cmpl	$4096, %eax
	jle	.L461
.L460:
.LBB157:
	.loc 1 395 15 discriminator 4
	leaq	.LC44(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L461:
.LBE157:
	.loc 1 396 41
	cmpl	$2147483647, %r12d
	jne	.L462
	.loc 1 396 41 is_stmt 0 discriminator 1
	leaq	.LC6(%rip), %rax
	movl	$396, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L462:
	.loc 1 396 41 discriminator 3
	leal	1(%r12), %eax
	.loc 1 395 15 is_stmt 1 discriminator 5
	cmpl	-84(%rbp), %eax
	jge	.L463
.LBB158:
	.loc 1 395 15 is_stmt 0 discriminator 6
	leaq	.LC45(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L463:
.LBE158:
	.loc 2 255 7 is_stmt 1
	movl	-84(%rbp), %eax
	movl	%eax, -56(%rbp)
	.loc 2 256 7
	movb	$0, -49(%rbp)
	.loc 2 258 15
	movb	$0, -57(%rbp)
	.loc 2 259 7
	cmpl	-84(%rbp), %r12d
	jl	.L464
	.loc 2 259 54 discriminator 1
	cmpl	-84(%rbp), %r13d
	jg	.L465
	.loc 2 259 54 is_stmt 0 discriminator 2
	cmpl	-84(%rbp), %r12d
	jge	.L466
.L465:
	.loc 2 259 54 discriminator 3
	leaq	.LC17(%rip), %rax
	movl	$259, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L466:
	.loc 2 259 43 is_stmt 1 discriminator 4
	movq	-80(%rbp), %rax
	movl	-84(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r14, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 2 259 43 is_stmt 0 discriminator 5
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_output_lexical__is_letter
	.loc 2 259 39 is_stmt 1 discriminator 6
	xorl	$1, %eax
	.loc 2 259 31 discriminator 6
	testb	%al, %al
	jne	.L464
	.loc 2 262 28
	movl	-84(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L467
	.loc 2 262 28 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L468
.L467:
	.loc 2 262 28 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$262, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L468:
	.loc 2 262 16 is_stmt 1 discriminator 3
	movl	%eax, -84(%rbp)
	.loc 2 263 86
	movl	$0, %ebx
.L485:
	.loc 2 263 7 discriminator 1
	cmpl	-84(%rbp), %r12d
	jl	.L469
	.loc 2 263 69 discriminator 2
	cmpl	-84(%rbp), %r13d
	jg	.L470
	.loc 2 263 69 is_stmt 0 discriminator 3
	cmpl	-84(%rbp), %r12d
	jge	.L471
.L470:
	.loc 2 263 69 discriminator 4
	leaq	.LC17(%rip), %rax
	movl	$263, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L471:
	.loc 2 263 44 is_stmt 1 discriminator 5
	movq	-80(%rbp), %rax
	movl	-84(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r14, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 2 263 44 is_stmt 0 discriminator 6
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_profile__is_identifier_character@PLT
	.loc 2 263 35 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L469
.LBB159:
	.loc 2 264 33
	movl	-56(%rbp), %eax
	cmpl	-84(%rbp), %eax
	jge	.L472
	.loc 2 264 68 discriminator 1
	cmpl	$2147483647, %r12d
	jne	.L473
	.loc 2 264 68 is_stmt 0 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$264, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L473:
	.loc 2 264 68 discriminator 4
	leal	1(%r12), %eax
	.loc 2 264 42 is_stmt 1 discriminator 5
	cmpl	-84(%rbp), %eax
	jge	.L474
.L472:
.LBB160:
	.loc 2 264 33 discriminator 6
	leaq	.LC46(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L474:
.LBE160:
	.loc 2 268 10
	testb	%bl, %bl
	je	.L475
	.loc 2 268 44 discriminator 1
	movl	%r15d, -88(%rbp)
.L475:
	.loc 2 268 44 is_stmt 0 discriminator 2
	movl	-84(%rbp), %r15d
	.loc 2 268 10 is_stmt 1 discriminator 2
	testb	%bl, %bl
	je	.L476
	.loc 2 268 44 discriminator 3
	movl	-88(%rbp), %eax
	cmpl	%eax, %r15d
	jg	.L477
.LBB161:
	.loc 2 268 44 is_stmt 0 discriminator 4
	leaq	.LC47(%rip), %rax
	movq	%rax, -112(%rbp)
	leaq	.LC3(%rip), %rax
	movq	%rax, -104(%rbp)
	movq	-112(%rbp), %rcx
	movq	-104(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L476:
.LBE161:
	.loc 2 268 10 is_stmt 1 discriminator 5
	movl	$1, %ebx
.L477:
	.loc 2 269 13
	cmpl	-84(%rbp), %r13d
	jg	.L478
	.loc 2 269 13 is_stmt 0 discriminator 1
	cmpl	-84(%rbp), %r12d
	jge	.L479
.L478:
	.loc 2 269 13 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$269, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L479:
	.loc 2 269 29 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rax
	movl	-84(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r14, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 2 269 29 is_stmt 0 discriminator 4
	cmpb	$95, %al
	sete	%al
	.loc 2 269 10 is_stmt 1 discriminator 4
	testb	%al, %al
	je	.L480
	.loc 2 269 35 discriminator 5
	cmpb	$0, -49(%rbp)
	jne	.L488
.L480:
	.loc 2 272 33
	cmpl	-84(%rbp), %r13d
	jg	.L481
	.loc 2 272 33 is_stmt 0 discriminator 1
	cmpl	-84(%rbp), %r12d
	jge	.L482
.L481:
	.loc 2 272 33 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$272, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L482:
	.loc 2 272 49 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rax
	movl	-84(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r14, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 2 272 30 discriminator 4
	cmpb	$95, %al
	sete	%al
	movb	%al, -49(%rbp)
	.loc 2 273 31
	movl	-84(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L483
	.loc 2 273 31 is_stmt 0 discriminator 1
	cmpl	$4097, %eax
	jle	.L484
.L483:
	.loc 2 273 31 discriminator 2
	leaq	.LC17(%rip), %rax
	movl	$273, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L484:
	.loc 2 273 19 is_stmt 1 discriminator 3
	movl	%eax, -84(%rbp)
.LBE159:
	.loc 2 274 15
	jmp	.L485
.L469:
	.loc 2 275 10
	movzbl	-49(%rbp), %eax
	xorl	$1, %eax
	.loc 2 275 7
	testb	%al, %al
	je	.L489
	.loc 2 276 18
	movb	$1, -57(%rbp)
	.loc 2 278 8
	jmp	.L489
.L488:
.LBB162:
	.loc 2 270 13
	nop
	jmp	.L464
.L489:
.LBE162:
	.loc 2 278 8
	nop
.L464:
.LBE155:
	.loc 2 278 8 is_stmt 0 discriminator 1
	movl	-84(%rbp), %eax
	movabsq	$-4294967296, %rdx
	andq	-96(%rbp), %rdx
	orq	%rdx, %rax
	movq	%rax, %rcx
	movzbl	-57(%rbp), %eax
	movzbl	%al, %eax
	salq	$32, %rax
	movabsq	$-1095216660481, %rdx
	andq	%rcx, %rdx
	orq	%rdx, %rax
	.loc 2 278 8
	addq	$104, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE18:
	.size	silver_output_lexical__match_identifier, .-silver_output_lexical__match_identifier
	.globl	silver_output_lexical_E
	.data
	.align 2
	.type	silver_output_lexical_E, @object
	.size	silver_output_lexical_E, 2
silver_output_lexical_E:
	.zero	2
	.globl	silver_output_lexical__forbidden_kindS
	.section	.rodata
	.align 32
	.type	silver_output_lexical__forbidden_kindS, @object
	.size	silver_output_lexical__forbidden_kindS, 1163
silver_output_lexical__forbidden_kindS:
	.ascii	"FORBIDDEN_ABORTFORBIDDEN_ABSFORBIDDEN_ABSTRACTFORBIDDEN_ACCE"
	.ascii	"PTFORBIDDEN_ACCESSFORBIDDEN_ALIASEDFORBIDDEN_ALLFORBIDDEN_AN"
	.ascii	"DFORBIDDEN_ARRAYFORBIDDEN_ATFORBIDDEN_BEGINFORBIDDEN_BODYFOR"
	.ascii	"BIDDEN_CASEFORBIDDEN_CONSTANTFORBIDDEN_DECLAREFORBIDDEN_DELA"
	.ascii	"YFORBIDDEN_DELTAFORBIDDEN_DIGITSFORBIDDEN_DOFORBIDDEN_ELSEFO"
	.ascii	"RBIDDEN_ELSIFFORBIDDEN_ENDFORBIDDEN_ENTRYFORBIDDEN_EXCEPTION"
	.ascii	"FORBIDDEN_EXITFORBIDDEN_FORFORBIDDEN_FUNCTIONFORBIDDEN_GENER"
	.ascii	"ICFORBIDDEN_GOTOFORBIDDEN_IFFORBIDDEN_INFORBIDDEN_INTERFACEF"
	.ascii	"ORBIDDEN_ISFORBIDDEN_LIMITEDFORBIDDEN_LOOPFORBIDDEN_MODFORBI"
	.ascii	"DDEN_NEWFORBIDDEN_NOTFORBIDDEN_NULLFORBIDDEN_OFFORBIDDEN_ORF"
	.ascii	"ORBIDDEN_OTHERSFORBIDDEN_OUTFORBIDDEN_OVERRIDINGFORBIDDEN_PA"
	.ascii	"CKAGEFORBIDDEN_PARALLELFORBIDDEN_PRAGMAFORBIDDEN_PRIVATEFORB"
	.ascii	"IDDEN_PROCEDUREFORBIDDEN_PROTECTEDFORBIDDEN_RAISEFORBIDDEN_R"
	.ascii	"ANGEFORBIDDEN_RECORDFORBIDDEN_REMFORBIDDEN_RENAMESFORBIDDEN_"
	.ascii	"REQUEUEFORBIDDEN_RETURNFORBIDDEN_REVERSEFORBIDDEN_SELECTFORB"
	.ascii	"IDDEN_SEPARATEFORBIDDEN_SOMEFORBIDDEN_SUBTYPEFORBIDDEN_SYNCH"
	.ascii	"RONIZEDFORBIDDEN_TAGGEDFORBIDDEN_TASKFORBIDDEN_TERMINATEFORB"
	.ascii	"IDDEN_THENFORBIDDEN_TYPEFORBIDDEN_UNTILFORBIDDEN_USEFORBIDDE"
	.ascii	"N_WHENFORBIDDEN_WHILEFORBIDDEN_WITHFORBIDDEN_XORFORBIDDEN_ST"
	.ascii	"RINGFORBIDDEN_SILVER_IO"
	.globl	silver_output_lexical__forbidden_kindN
	.align 32
	.type	silver_output_lexical__forbidden_kindN, @object
	.size	silver_output_lexical__forbidden_kindN, 154
silver_output_lexical__forbidden_kindN:
	.value	1
	.value	16
	.value	29
	.value	47
	.value	63
	.value	79
	.value	96
	.value	109
	.value	122
	.value	137
	.value	149
	.value	164
	.value	178
	.value	192
	.value	210
	.value	227
	.value	242
	.value	257
	.value	273
	.value	285
	.value	299
	.value	314
	.value	327
	.value	342
	.value	361
	.value	375
	.value	388
	.value	406
	.value	423
	.value	437
	.value	449
	.value	461
	.value	480
	.value	492
	.value	509
	.value	523
	.value	536
	.value	549
	.value	562
	.value	576
	.value	588
	.value	600
	.value	616
	.value	629
	.value	649
	.value	666
	.value	684
	.value	700
	.value	717
	.value	736
	.value	755
	.value	770
	.value	785
	.value	801
	.value	814
	.value	831
	.value	848
	.value	864
	.value	881
	.value	897
	.value	915
	.value	929
	.value	946
	.value	968
	.value	984
	.value	998
	.value	1017
	.value	1031
	.value	1045
	.value	1060
	.value	1073
	.value	1087
	.value	1102
	.value	1116
	.value	1129
	.value	1145
	.value	1164
	.globl	silver_output_lexical__invalid_decimal
	.align 8
	.type	silver_output_lexical__invalid_decimal, @object
	.size	silver_output_lexical__invalid_decimal, 8
silver_output_lexical__invalid_decimal:
	.zero	8
	.align 16
	.type	forbidden_kindP.5, @object
	.size	forbidden_kindP.5, 20
forbidden_kindP.5:
	.long	11
	.long	12
	.long	13
	.long	14
	.long	15
	.align 8
	.type	forbidden_kindT1.4, @object
	.size	forbidden_kindT1.4, 8
forbidden_kindT1.4:
	.byte	91
	.byte	21
	.byte	64
	.byte	17
	.byte	28
	.zero	3
	.align 8
	.type	forbidden_kindT2.3, @object
	.size	forbidden_kindT2.3, 8
forbidden_kindT2.3:
	.byte	-105
	.byte	79
	.byte	122
	.byte	-126
	.byte	12
	.zero	3
	.align 32
	.type	forbidden_kindG.2, @object
	.size	forbidden_kindG.2, 154
forbidden_kindG.2:
	.byte	75
	.byte	0
	.byte	62
	.byte	0
	.byte	8
	.byte	0
	.byte	12
	.byte	60
	.byte	0
	.byte	36
	.byte	56
	.byte	0
	.byte	4
	.byte	63
	.byte	0
	.byte	73
	.byte	48
	.byte	0
	.byte	68
	.byte	25
	.byte	57
	.byte	14
	.byte	0
	.byte	0
	.byte	50
	.byte	34
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	19
	.byte	0
	.byte	17
	.byte	0
	.byte	68
	.byte	40
	.byte	0
	.byte	40
	.byte	4
	.byte	0
	.byte	0
	.byte	16
	.byte	50
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	34
	.byte	0
	.byte	0
	.byte	27
	.byte	50
	.byte	75
	.byte	1
	.byte	72
	.byte	47
	.byte	0
	.byte	0
	.byte	58
	.byte	0
	.byte	0
	.byte	0
	.byte	10
	.byte	27
	.byte	46
	.byte	58
	.byte	72
	.byte	0
	.byte	20
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	69
	.byte	31
	.byte	28
	.byte	28
	.byte	0
	.byte	23
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	1
	.byte	16
	.byte	0
	.byte	71
	.byte	42
	.byte	7
	.byte	13
	.byte	0
	.byte	52
	.byte	15
	.byte	22
	.byte	68
	.byte	56
	.byte	69
	.byte	0
	.byte	29
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	70
	.byte	0
	.byte	0
	.byte	0
	.byte	14
	.byte	72
	.byte	59
	.byte	0
	.byte	44
	.byte	66
	.byte	0
	.byte	60
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	59
	.byte	47
	.byte	9
	.byte	0
	.byte	0
	.byte	0
	.byte	4
	.byte	7
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	55
	.byte	46
	.byte	0
	.byte	0
	.byte	18
	.byte	0
	.byte	0
	.byte	65
	.byte	0
	.byte	0
	.byte	0
	.text
.Letext0:
	.file 3 "<built-in>"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x99d
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x15
	.long	.LASF127
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.long	.LLRL1
	.quad	0
	.long	.Ldebug_line0
	.uleb128 0xd
	.sleb128 4097
	.long	.LASF99
	.long	0x3a
	.uleb128 0x9
	.long	0x2a
	.uleb128 0xa
	.byte	0x4
	.byte	0x5
	.long	.LASF85
	.uleb128 0xb
	.sleb128 4097
	.long	.LASF78
	.long	0x3a
	.uleb128 0x9
	.long	0x41
	.uleb128 0x16
	.long	.LASF128
	.byte	0x7
	.byte	0x1
	.byte	0x1
	.byte	0xa4
	.byte	0x9
	.long	0x228
	.uleb128 0x1
	.long	.LASF2
	.byte	0
	.uleb128 0x1
	.long	.LASF3
	.byte	0x1
	.uleb128 0x1
	.long	.LASF4
	.byte	0x2
	.uleb128 0x1
	.long	.LASF5
	.byte	0x3
	.uleb128 0x1
	.long	.LASF6
	.byte	0x4
	.uleb128 0x1
	.long	.LASF7
	.byte	0x5
	.uleb128 0x1
	.long	.LASF8
	.byte	0x6
	.uleb128 0x1
	.long	.LASF9
	.byte	0x7
	.uleb128 0x1
	.long	.LASF10
	.byte	0x8
	.uleb128 0x1
	.long	.LASF11
	.byte	0x9
	.uleb128 0x1
	.long	.LASF12
	.byte	0xa
	.uleb128 0x1
	.long	.LASF13
	.byte	0xb
	.uleb128 0x1
	.long	.LASF14
	.byte	0xc
	.uleb128 0x1
	.long	.LASF15
	.byte	0xd
	.uleb128 0x1
	.long	.LASF16
	.byte	0xe
	.uleb128 0x1
	.long	.LASF17
	.byte	0xf
	.uleb128 0x1
	.long	.LASF18
	.byte	0x10
	.uleb128 0x1
	.long	.LASF19
	.byte	0x11
	.uleb128 0x1
	.long	.LASF20
	.byte	0x12
	.uleb128 0x1
	.long	.LASF21
	.byte	0x13
	.uleb128 0x1
	.long	.LASF22
	.byte	0x14
	.uleb128 0x1
	.long	.LASF23
	.byte	0x15
	.uleb128 0x1
	.long	.LASF24
	.byte	0x16
	.uleb128 0x1
	.long	.LASF25
	.byte	0x17
	.uleb128 0x1
	.long	.LASF26
	.byte	0x18
	.uleb128 0x1
	.long	.LASF27
	.byte	0x19
	.uleb128 0x1
	.long	.LASF28
	.byte	0x1a
	.uleb128 0x1
	.long	.LASF29
	.byte	0x1b
	.uleb128 0x1
	.long	.LASF30
	.byte	0x1c
	.uleb128 0x1
	.long	.LASF31
	.byte	0x1d
	.uleb128 0x1
	.long	.LASF32
	.byte	0x1e
	.uleb128 0x1
	.long	.LASF33
	.byte	0x1f
	.uleb128 0x1
	.long	.LASF34
	.byte	0x20
	.uleb128 0x1
	.long	.LASF35
	.byte	0x21
	.uleb128 0x1
	.long	.LASF36
	.byte	0x22
	.uleb128 0x1
	.long	.LASF37
	.byte	0x23
	.uleb128 0x1
	.long	.LASF38
	.byte	0x24
	.uleb128 0x1
	.long	.LASF39
	.byte	0x25
	.uleb128 0x1
	.long	.LASF40
	.byte	0x26
	.uleb128 0x1
	.long	.LASF41
	.byte	0x27
	.uleb128 0x1
	.long	.LASF42
	.byte	0x28
	.uleb128 0x1
	.long	.LASF43
	.byte	0x29
	.uleb128 0x1
	.long	.LASF44
	.byte	0x2a
	.uleb128 0x1
	.long	.LASF45
	.byte	0x2b
	.uleb128 0x1
	.long	.LASF46
	.byte	0x2c
	.uleb128 0x1
	.long	.LASF47
	.byte	0x2d
	.uleb128 0x1
	.long	.LASF48
	.byte	0x2e
	.uleb128 0x1
	.long	.LASF49
	.byte	0x2f
	.uleb128 0x1
	.long	.LASF50
	.byte	0x30
	.uleb128 0x1
	.long	.LASF51
	.byte	0x31
	.uleb128 0x1
	.long	.LASF52
	.byte	0x32
	.uleb128 0x1
	.long	.LASF53
	.byte	0x33
	.uleb128 0x1
	.long	.LASF54
	.byte	0x34
	.uleb128 0x1
	.long	.LASF55
	.byte	0x35
	.uleb128 0x1
	.long	.LASF56
	.byte	0x36
	.uleb128 0x1
	.long	.LASF57
	.byte	0x37
	.uleb128 0x1
	.long	.LASF58
	.byte	0x38
	.uleb128 0x1
	.long	.LASF59
	.byte	0x39
	.uleb128 0x1
	.long	.LASF60
	.byte	0x3a
	.uleb128 0x1
	.long	.LASF61
	.byte	0x3b
	.uleb128 0x1
	.long	.LASF62
	.byte	0x3c
	.uleb128 0x1
	.long	.LASF63
	.byte	0x3d
	.uleb128 0x1
	.long	.LASF64
	.byte	0x3e
	.uleb128 0x1
	.long	.LASF65
	.byte	0x3f
	.uleb128 0x1
	.long	.LASF66
	.byte	0x40
	.uleb128 0x1
	.long	.LASF67
	.byte	0x41
	.uleb128 0x1
	.long	.LASF68
	.byte	0x42
	.uleb128 0x1
	.long	.LASF69
	.byte	0x43
	.uleb128 0x1
	.long	.LASF70
	.byte	0x44
	.uleb128 0x1
	.long	.LASF71
	.byte	0x45
	.uleb128 0x1
	.long	.LASF72
	.byte	0x46
	.uleb128 0x1
	.long	.LASF73
	.byte	0x47
	.uleb128 0x1
	.long	.LASF74
	.byte	0x48
	.uleb128 0x1
	.long	.LASF75
	.byte	0x49
	.uleb128 0x1
	.long	.LASF76
	.byte	0x4a
	.uleb128 0x1
	.long	.LASF77
	.byte	0x4b
	.byte	0
	.uleb128 0x9
	.long	0x51
	.uleb128 0xb
	.sleb128 4096
	.long	.LASF79
	.long	0x3a
	.uleb128 0x17
	.long	.LASF94
	.byte	0x8
	.byte	0x1
	.value	0x115
	.byte	0x9
	.long	0x261
	.uleb128 0x7
	.long	.LASF80
	.value	0x116
	.byte	0x7
	.long	0x41
	.byte	0
	.uleb128 0x7
	.long	.LASF81
	.value	0x117
	.byte	0x7
	.long	0x22d
	.byte	0x4
	.byte	0
	.uleb128 0x9
	.long	0x238
	.uleb128 0xc
	.byte	0x10
	.value	0x159
	.long	0x296
	.uleb128 0x7
	.long	.LASF82
	.value	0x15a
	.byte	0x16
	.long	0x2a
	.byte	0
	.uleb128 0x7
	.long	.LASF83
	.value	0x15a
	.byte	0x30
	.long	0x296
	.byte	0x4
	.uleb128 0x7
	.long	.LASF84
	.value	0x15b
	.byte	0x7
	.long	0x22d
	.byte	0x8
	.byte	0
	.uleb128 0xa
	.byte	0x1
	.byte	0x2
	.long	.LASF86
	.uleb128 0xc
	.byte	0x8
	.value	0x17a
	.long	0x2c0
	.uleb128 0x7
	.long	.LASF82
	.value	0x17b
	.byte	0x16
	.long	0x2a
	.byte	0
	.uleb128 0x7
	.long	.LASF83
	.value	0x17b
	.byte	0x30
	.long	0x296
	.byte	0x4
	.byte	0
	.uleb128 0xc
	.byte	0x8
	.value	0x188
	.long	0x2e3
	.uleb128 0x7
	.long	.LASF82
	.value	0x189
	.byte	0x16
	.long	0x2a
	.byte	0
	.uleb128 0x7
	.long	.LASF83
	.value	0x189
	.byte	0x30
	.long	0x296
	.byte	0x4
	.byte	0
	.uleb128 0xe
	.long	.LASF89
	.uleb128 0xa
	.byte	0x1
	.byte	0x7
	.long	.LASF87
	.uleb128 0xa
	.byte	0x8
	.byte	0x7
	.long	.LASF88
	.uleb128 0xe
	.long	.LASF90
	.uleb128 0x18
	.long	.LASF129
	.byte	0x1
	.value	0x119
	.byte	0x4
	.long	0x261
	.uleb128 0x9
	.byte	0x3
	.quad	silver_output_lexical__invalid_decimal
	.uleb128 0x19
	.long	.LASF130
	.byte	0x1
	.byte	0x1
	.byte	0x6
	.uleb128 0xf
	.byte	0x1
	.long	0x312
	.uleb128 0xf
	.byte	0x2
	.long	0x312
	.uleb128 0x8
	.long	.LASF101
	.byte	0x2
	.byte	0xfc
	.long	0x2c0
	.quad	.LFB18
	.quad	.LFE18-.LFB18
	.uleb128 0x1
	.byte	0x9c
	.long	0x3ab
	.uleb128 0x2
	.long	.LASF91
	.value	0x189
	.byte	0x7
	.long	0x425
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x2
	.long	.LASF82
	.value	0x189
	.byte	0x16
	.long	0x2a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -100
	.uleb128 0x2
	.long	.LASF83
	.value	0x189
	.byte	0x30
	.long	0x296
	.uleb128 0x3
	.byte	0x91
	.sleb128 -73
	.uleb128 0x5
	.quad	.LBB155
	.quad	.LBE155-.LBB155
	.uleb128 0x6
	.long	.LASF92
	.byte	0x2
	.byte	0xff
	.byte	0x7
	.long	0x2a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x1a
	.long	.LASF93
	.byte	0x2
	.value	0x100
	.byte	0x7
	.long	0x296
	.uleb128 0x3
	.byte	0x91
	.sleb128 -65
	.byte	0
	.byte	0
	.uleb128 0x1b
	.long	.LASF95
	.byte	0x10
	.byte	0x3
	.byte	0
	.long	0x3ee
	.uleb128 0x10
	.long	.LASF96
	.long	0x3c1
	.byte	0
	.uleb128 0x11
	.long	0x42a
	.uleb128 0x1c
	.byte	0x8
	.byte	0x3
	.byte	0
	.long	0x3e3
	.uleb128 0x12
	.string	"LB0"
	.long	0x455
	.byte	0
	.uleb128 0x12
	.string	"UB0"
	.long	0x455
	.byte	0x4
	.byte	0
	.uleb128 0x10
	.long	.LASF97
	.long	0x463
	.byte	0x8
	.byte	0
	.uleb128 0x4
	.long	0x3ab
	.uleb128 0x4
	.long	0x3ab
	.uleb128 0x4
	.long	0x3ab
	.uleb128 0x4
	.long	0x3ab
	.uleb128 0x4
	.long	0x3ab
	.uleb128 0x4
	.long	0x3ab
	.uleb128 0x4
	.long	0x3ab
	.uleb128 0x4
	.long	0x3ab
	.uleb128 0x4
	.long	0x3ab
	.uleb128 0x4
	.long	0x3ab
	.uleb128 0x4
	.long	0x3ab
	.uleb128 0x4
	.long	0x3ab
	.uleb128 0x1d
	.long	0x449
	.long	0x449
	.uleb128 0x1e
	.long	0x3a
	.uleb128 0x6
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x94
	.byte	0x4
	.uleb128 0x8
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x23
	.uleb128 0x4
	.byte	0x94
	.byte	0x4
	.byte	0
	.uleb128 0xa
	.byte	0x1
	.byte	0x8
	.long	.LASF98
	.uleb128 0x9
	.long	0x449
	.uleb128 0xd
	.sleb128 2147483647
	.long	.LASF100
	.long	0x3a
	.uleb128 0x11
	.long	0x3c6
	.uleb128 0x8
	.long	.LASF102
	.byte	0x2
	.byte	0xd6
	.long	0x29d
	.quad	.LFB17
	.quad	.LFE17-.LFB17
	.uleb128 0x1
	.byte	0x9c
	.long	0x4dc
	.uleb128 0x2
	.long	.LASF91
	.value	0x17b
	.byte	0x7
	.long	0x420
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x2
	.long	.LASF82
	.value	0x17b
	.byte	0x16
	.long	0x2a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -100
	.uleb128 0x2
	.long	.LASF83
	.value	0x17b
	.byte	0x30
	.long	0x296
	.uleb128 0x3
	.byte	0x91
	.sleb128 -69
	.uleb128 0x5
	.quad	.LBB148
	.quad	.LBE148-.LBB148
	.uleb128 0x6
	.long	.LASF92
	.byte	0x2
	.byte	0xd9
	.byte	0x7
	.long	0x2a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.uleb128 0x8
	.long	.LASF103
	.byte	0x2
	.byte	0xbd
	.long	0x2a
	.quad	.LFB16
	.quad	.LFE16-.LFB16
	.uleb128 0x1
	.byte	0x9c
	.long	0x540
	.uleb128 0x2
	.long	.LASF91
	.value	0x171
	.byte	0x1b
	.long	0x41b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x2
	.long	.LASF82
	.value	0x171
	.byte	0x2a
	.long	0x2a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -100
	.uleb128 0x5
	.quad	.LBB141
	.quad	.LBE141-.LBB141
	.uleb128 0x6
	.long	.LASF104
	.byte	0x2
	.byte	0xbf
	.byte	0x7
	.long	0x2a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.uleb128 0x8
	.long	.LASF105
	.byte	0x2
	.byte	0xad
	.long	0x2a
	.quad	.LFB15
	.quad	.LFE15-.LFB15
	.uleb128 0x1
	.byte	0x9c
	.long	0x5a4
	.uleb128 0x2
	.long	.LASF91
	.value	0x168
	.byte	0x1c
	.long	0x416
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x2
	.long	.LASF82
	.value	0x168
	.byte	0x2b
	.long	0x2a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -100
	.uleb128 0x5
	.quad	.LBB134
	.quad	.LBE134-.LBB134
	.uleb128 0x6
	.long	.LASF104
	.byte	0x2
	.byte	0xaf
	.byte	0x7
	.long	0x2a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.uleb128 0x8
	.long	.LASF106
	.byte	0x2
	.byte	0x82
	.long	0x266
	.quad	.LFB14
	.quad	.LFE14-.LFB14
	.uleb128 0x1
	.byte	0x9c
	.long	0x628
	.uleb128 0x2
	.long	.LASF91
	.value	0x15a
	.byte	0x7
	.long	0x411
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x2
	.long	.LASF82
	.value	0x15a
	.byte	0x16
	.long	0x2a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -100
	.uleb128 0x2
	.long	.LASF83
	.value	0x15a
	.byte	0x30
	.long	0x296
	.uleb128 0x3
	.byte	0x91
	.sleb128 -69
	.uleb128 0x2
	.long	.LASF84
	.value	0x15b
	.byte	0x7
	.long	0x22d
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x5
	.quad	.LBB126
	.quad	.LBE126-.LBB126
	.uleb128 0x6
	.long	.LASF92
	.byte	0x2
	.byte	0x86
	.byte	0x7
	.long	0x2a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.uleb128 0x8
	.long	.LASF107
	.byte	0x2
	.byte	0x5a
	.long	0x238
	.quad	.LFB13
	.quad	.LFE13-.LFB13
	.uleb128 0x1
	.byte	0x9c
	.long	0x6be
	.uleb128 0x2
	.long	.LASF91
	.value	0x153
	.byte	0x1c
	.long	0x40c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x2
	.long	.LASF82
	.value	0x153
	.byte	0x2b
	.long	0x35
	.uleb128 0x3
	.byte	0x91
	.sleb128 -100
	.uleb128 0x5
	.quad	.LBB118
	.quad	.LBE118-.LBB118
	.uleb128 0x6
	.long	.LASF108
	.byte	0x2
	.byte	0x5c
	.byte	0x7
	.long	0x2a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x6
	.long	.LASF81
	.byte	0x2
	.byte	0x5d
	.byte	0x7
	.long	0x22d
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x5
	.quad	.LBB125
	.quad	.LBE125-.LBB125
	.uleb128 0x6
	.long	.LASF109
	.byte	0x2
	.byte	0x76
	.byte	0xd
	.long	0x6be
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0xb
	.sleb128 2147483647
	.long	.LASF110
	.long	0x3a
	.uleb128 0x8
	.long	.LASF111
	.byte	0x2
	.byte	0x8
	.long	0x3ab
	.quad	.LFB11
	.quad	.LFE11-.LFB11
	.uleb128 0x1
	.byte	0x9c
	.long	0x71f
	.uleb128 0x3
	.long	.LASF112
	.byte	0xf2
	.byte	0x21
	.long	0x228
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x1f
	.long	.LASF131
	.long	0x3ab
	.quad	.LFB12
	.quad	.LFE12-.LFB12
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x6
	.byte	0x91
	.sleb128 -40
	.byte	0x6
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0
	.uleb128 0x20
	.long	.LASF113
	.byte	0x1
	.byte	0x65
	.byte	0x4
	.long	0x296
	.quad	.LFB10
	.quad	.LFE10-.LFB10
	.uleb128 0x1
	.byte	0x9c
	.long	0x750
	.uleb128 0x3
	.long	.LASF114
	.byte	0x65
	.byte	0x18
	.long	0x450
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.byte	0
	.uleb128 0x13
	.long	.LASF115
	.value	0x110
	.long	0x296
	.quad	.LFB8
	.quad	.LFE8-.LFB8
	.uleb128 0x1
	.byte	0x9c
	.long	0x79f
	.uleb128 0x2
	.long	.LASF91
	.value	0x10c
	.byte	0x1f
	.long	0x407
	.uleb128 0x2
	.byte	0x91
	.sleb128 -48
	.uleb128 0x2
	.long	.LASF116
	.value	0x10c
	.byte	0x2e
	.long	0x4c
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.uleb128 0x2
	.long	.LASF80
	.value	0x10c
	.byte	0x35
	.long	0x4c
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.byte	0
	.uleb128 0x13
	.long	.LASF117
	.value	0x107
	.long	0x296
	.quad	.LFB7
	.quad	.LFE7-.LFB7
	.uleb128 0x1
	.byte	0x9c
	.long	0x7f1
	.uleb128 0x2
	.long	.LASF91
	.value	0x102
	.byte	0x7
	.long	0x402
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x2
	.long	.LASF116
	.value	0x102
	.byte	0x16
	.long	0x35
	.uleb128 0x3
	.byte	0x91
	.sleb128 -84
	.uleb128 0x2
	.long	.LASF80
	.value	0x102
	.byte	0x1d
	.long	0x35
	.uleb128 0x3
	.byte	0x91
	.sleb128 -88
	.byte	0
	.uleb128 0x8
	.long	.LASF118
	.byte	0x1
	.byte	0xfd
	.long	0x296
	.quad	.LFB5
	.quad	.LFE5-.LFB5
	.uleb128 0x1
	.byte	0x9c
	.long	0x856
	.uleb128 0x3
	.long	.LASF91
	.byte	0xf8
	.byte	0x1d
	.long	0x3fd
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x3
	.long	.LASF116
	.byte	0xf8
	.byte	0x2c
	.long	0x35
	.uleb128 0x3
	.byte	0x91
	.sleb128 -132
	.uleb128 0x3
	.long	.LASF80
	.byte	0xf8
	.byte	0x33
	.long	0x35
	.uleb128 0x3
	.byte	0x91
	.sleb128 -136
	.uleb128 0x21
	.long	.LLRL0
	.uleb128 0x6
	.long	.LASF112
	.byte	0x1
	.byte	0xfe
	.byte	0x10
	.long	0x51
	.uleb128 0x3
	.byte	0x91
	.sleb128 -65
	.byte	0
	.byte	0
	.uleb128 0x8
	.long	.LASF119
	.byte	0x1
	.byte	0x9c
	.long	0x296
	.quad	.LFB3
	.quad	.LFE3-.LFB3
	.uleb128 0x1
	.byte	0x9c
	.long	0x904
	.uleb128 0x3
	.long	.LASF91
	.byte	0x95
	.byte	0x7
	.long	0x3f8
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x3
	.long	.LASF120
	.byte	0x95
	.byte	0x16
	.long	0x35
	.uleb128 0x3
	.byte	0x91
	.sleb128 -100
	.uleb128 0x3
	.long	.LASF121
	.byte	0x95
	.byte	0x22
	.long	0x35
	.uleb128 0x3
	.byte	0x91
	.sleb128 -104
	.uleb128 0x3
	.long	.LASF122
	.byte	0x95
	.byte	0x2e
	.long	0x35
	.uleb128 0x3
	.byte	0x91
	.sleb128 -108
	.uleb128 0x3
	.long	.LASF123
	.byte	0x95
	.byte	0x3b
	.long	0x35
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x5
	.quad	.LBB10
	.quad	.LBE10-.LBB10
	.uleb128 0x14
	.long	.LASF125
	.long	0x3a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x5
	.quad	.LBB17
	.quad	.LBE17-.LBB17
	.uleb128 0x6
	.long	.LASF124
	.byte	0x1
	.byte	0xa1
	.byte	0x19
	.long	0x3a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x22
	.long	.LASF132
	.byte	0x1
	.byte	0x8d
	.byte	0x4
	.long	0x296
	.quad	.LFB2
	.quad	.LFE2-.LFB2
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x3
	.long	.LASF91
	.byte	0x87
	.byte	0x7
	.long	0x3f3
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x3
	.long	.LASF116
	.byte	0x87
	.byte	0x16
	.long	0x35
	.uleb128 0x3
	.byte	0x91
	.sleb128 -100
	.uleb128 0x3
	.long	.LASF80
	.byte	0x87
	.byte	0x1d
	.long	0x35
	.uleb128 0x3
	.byte	0x91
	.sleb128 -104
	.uleb128 0x3
	.long	.LASF112
	.byte	0x87
	.byte	0x2d
	.long	0x3ee
	.uleb128 0x3
	.byte	0x91
	.sleb128 -128
	.uleb128 0x5
	.quad	.LBB2
	.quad	.LBE2-.LBB2
	.uleb128 0x14
	.long	.LASF126
	.long	0x3a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x5
	.quad	.LBB9
	.quad	.LBE9-.LBB9
	.uleb128 0x6
	.long	.LASF124
	.byte	0x1
	.byte	0x91
	.byte	0x19
	.long	0x3a
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x28
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x1c
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 14
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x3e
	.uleb128 0x21
	.sleb128 5
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x3a
	.byte	0
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 6
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x18
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x14
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x15
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x55
	.uleb128 0x17
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x16
	.uleb128 0x4
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x17
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x18
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x19
	.uleb128 0x1e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x1a
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x1b
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1c
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1d
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1e
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x18
	.uleb128 0x2f
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x1f
	.uleb128 0x2e
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x20
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x21
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x55
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x22
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x4c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.LFE3-.Ltext0
	.quad	.LFB5
	.quad	.LFE8-.LFB5
	.quad	.LFB10
	.quad	.Letext0-.LFB10
	.quad	0
	.quad	0
	.section	.debug_rnglists,"",@progbits
.Ldebug_ranges0:
	.long	.Ldebug_ranges3-.Ldebug_ranges2
.Ldebug_ranges2:
	.value	0x5
	.byte	0x8
	.byte	0
	.long	0
.LLRL0:
	.byte	0x5
	.quad	.LBB25
	.byte	0x4
	.uleb128 .LBB25-.LBB25
	.uleb128 .LBE25-.LBB25
	.byte	0x4
	.uleb128 .LBB30-.LBB25
	.uleb128 .LBE30-.LBB25
	.byte	0x4
	.uleb128 .LBB31-.LBB25
	.uleb128 .LBE31-.LBB25
	.byte	0
.LLRL1:
	.byte	0x7
	.quad	.Ltext0
	.uleb128 .LFE3-.Ltext0
	.byte	0x7
	.quad	.LFB5
	.uleb128 .LFE8-.LFB5
	.byte	0x7
	.quad	.LFB10
	.uleb128 .Letext0-.LFB10
	.byte	0
.Ldebug_ranges3:
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF112:
	.string	"word"
.LASF74:
	.string	"silver_output_lexical__forbidden_with"
.LASF131:
	.string	"silver_output_lexical__forbidden_spelling___wrapped_statements"
.LASF94:
	.string	"silver_output_lexical__decimal_result"
.LASF60:
	.string	"silver_output_lexical__forbidden_select"
.LASF96:
	.string	"P_ARRAY"
.LASF27:
	.string	"silver_output_lexical__forbidden_for"
.LASF65:
	.string	"silver_output_lexical__forbidden_tagged"
.LASF111:
	.string	"silver_output_lexical__forbidden_spelling"
.LASF66:
	.string	"silver_output_lexical__forbidden_task"
.LASF85:
	.string	"integer"
.LASF108:
	.string	"next"
.LASF121:
	.string	"left_after"
.LASF114:
	.string	"item"
.LASF89:
	.string	"system__parameters__Tsize_typeB"
.LASF48:
	.string	"silver_output_lexical__forbidden_pragma"
.LASF80:
	.string	"after"
.LASF123:
	.string	"right_after"
.LASF39:
	.string	"silver_output_lexical__forbidden_not"
.LASF41:
	.string	"silver_output_lexical__forbidden_of"
.LASF72:
	.string	"silver_output_lexical__forbidden_when"
.LASF3:
	.string	"silver_output_lexical__forbidden_abs"
.LASF59:
	.string	"silver_output_lexical__forbidden_reverse"
.LASF10:
	.string	"silver_output_lexical__forbidden_array"
.LASF40:
	.string	"silver_output_lexical__forbidden_null"
.LASF37:
	.string	"silver_output_lexical__forbidden_mod"
.LASF73:
	.string	"silver_output_lexical__forbidden_while"
.LASF78:
	.string	"silver_output_lexical__literal_position"
.LASF106:
	.string	"silver_output_lexical__match_sized_literal"
.LASF30:
	.string	"silver_output_lexical__forbidden_goto"
.LASF87:
	.string	"system__storage_elements__storage_element"
.LASF81:
	.string	"value"
.LASF102:
	.string	"silver_output_lexical__match_literal"
.LASF47:
	.string	"silver_output_lexical__forbidden_parallel"
.LASF115:
	.string	"silver_output_lexical__valid_name_state"
.LASF20:
	.string	"silver_output_lexical__forbidden_do"
.LASF110:
	.string	"natural"
.LASF79:
	.string	"silver_output_lexical__capacity_value"
.LASF76:
	.string	"silver_output_lexical__forbidden_string"
.LASF46:
	.string	"silver_output_lexical__forbidden_package"
.LASF45:
	.string	"silver_output_lexical__forbidden_overriding"
.LASF129:
	.string	"silver_output_lexical__invalid_decimal"
.LASF128:
	.string	"silver_output_lexical__forbidden_kind"
.LASF35:
	.string	"silver_output_lexical__forbidden_limited"
.LASF9:
	.string	"silver_output_lexical__forbidden_and"
.LASF69:
	.string	"silver_output_lexical__forbidden_type"
.LASF83:
	.string	"matched"
.LASF71:
	.string	"silver_output_lexical__forbidden_use"
.LASF90:
	.string	"system__storage_elements__Tstorage_offsetB"
.LASF125:
	.string	"silver_output_lexical__equal_name__B38s__L39s__T40s___U"
.LASF63:
	.string	"silver_output_lexical__forbidden_subtype"
.LASF117:
	.string	"silver_output_lexical__forbidden_argument_name"
.LASF68:
	.string	"silver_output_lexical__forbidden_then"
.LASF6:
	.string	"silver_output_lexical__forbidden_access"
.LASF124:
	.string	"offset"
.LASF97:
	.string	"P_BOUNDS"
.LASF62:
	.string	"silver_output_lexical__forbidden_some"
.LASF49:
	.string	"silver_output_lexical__forbidden_private"
.LASF119:
	.string	"silver_output_lexical__equal_name"
.LASF93:
	.string	"previous_underscore"
.LASF50:
	.string	"silver_output_lexical__forbidden_procedure"
.LASF105:
	.string	"silver_output_lexical__skip_comment"
.LASF98:
	.string	"character"
.LASF7:
	.string	"silver_output_lexical__forbidden_aliased"
.LASF11:
	.string	"silver_output_lexical__forbidden_at"
.LASF15:
	.string	"silver_output_lexical__forbidden_constant"
.LASF88:
	.string	"system__address"
.LASF122:
	.string	"right_first"
.LASF84:
	.string	"length"
.LASF38:
	.string	"silver_output_lexical__forbidden_new"
.LASF14:
	.string	"silver_output_lexical__forbidden_case"
.LASF92:
	.string	"start"
.LASF52:
	.string	"silver_output_lexical__forbidden_raise"
.LASF33:
	.string	"silver_output_lexical__forbidden_interface"
.LASF67:
	.string	"silver_output_lexical__forbidden_terminate"
.LASF12:
	.string	"silver_output_lexical__forbidden_begin"
.LASF18:
	.string	"silver_output_lexical__forbidden_delta"
.LASF120:
	.string	"left_first"
.LASF31:
	.string	"silver_output_lexical__forbidden_if"
.LASF17:
	.string	"silver_output_lexical__forbidden_delay"
.LASF61:
	.string	"silver_output_lexical__forbidden_separate"
.LASF104:
	.string	"initial_position"
.LASF32:
	.string	"silver_output_lexical__forbidden_in"
.LASF126:
	.string	"silver_output_lexical__name_is__B23s__L24s__T25s___U"
.LASF5:
	.string	"silver_output_lexical__forbidden_accept"
.LASF4:
	.string	"silver_output_lexical__forbidden_abstract"
.LASF57:
	.string	"silver_output_lexical__forbidden_requeue"
.LASF36:
	.string	"silver_output_lexical__forbidden_loop"
.LASF77:
	.string	"silver_output_lexical__forbidden_silver_io"
.LASF44:
	.string	"silver_output_lexical__forbidden_out"
.LASF103:
	.string	"silver_output_lexical__skip_trivia"
.LASF127:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF13:
	.string	"silver_output_lexical__forbidden_body"
.LASF91:
	.string	"text"
.LASF95:
	.string	"string"
.LASF34:
	.string	"silver_output_lexical__forbidden_is"
.LASF53:
	.string	"silver_output_lexical__forbidden_range"
.LASF99:
	.string	"silver_output_lexical__cursor"
.LASF29:
	.string	"silver_output_lexical__forbidden_generic"
.LASF21:
	.string	"silver_output_lexical__forbidden_else"
.LASF26:
	.string	"silver_output_lexical__forbidden_exit"
.LASF101:
	.string	"silver_output_lexical__match_identifier"
.LASF58:
	.string	"silver_output_lexical__forbidden_return"
.LASF100:
	.string	"positive"
.LASF64:
	.string	"silver_output_lexical__forbidden_synchronized"
.LASF43:
	.string	"silver_output_lexical__forbidden_others"
.LASF56:
	.string	"silver_output_lexical__forbidden_renames"
.LASF8:
	.string	"silver_output_lexical__forbidden_all"
.LASF51:
	.string	"silver_output_lexical__forbidden_protected"
.LASF25:
	.string	"silver_output_lexical__forbidden_exception"
.LASF107:
	.string	"silver_output_lexical__read_capacity"
.LASF23:
	.string	"silver_output_lexical__forbidden_end"
.LASF113:
	.string	"silver_output_lexical__is_letter"
.LASF109:
	.string	"digit"
.LASF132:
	.string	"silver_output_lexical__name_is"
.LASF2:
	.string	"silver_output_lexical__forbidden_abort"
.LASF130:
	.string	"silver_profile"
.LASF42:
	.string	"silver_output_lexical__forbidden_or"
.LASF82:
	.string	"position"
.LASF16:
	.string	"silver_output_lexical__forbidden_declare"
.LASF19:
	.string	"silver_output_lexical__forbidden_digits"
.LASF118:
	.string	"silver_output_lexical__forbidden_name"
.LASF28:
	.string	"silver_output_lexical__forbidden_function"
.LASF22:
	.string	"silver_output_lexical__forbidden_elsif"
.LASF75:
	.string	"silver_output_lexical__forbidden_xor"
.LASF55:
	.string	"silver_output_lexical__forbidden_rem"
.LASF24:
	.string	"silver_output_lexical__forbidden_entry"
.LASF116:
	.string	"first"
.LASF86:
	.string	"boolean"
.LASF54:
	.string	"silver_output_lexical__forbidden_record"
.LASF70:
	.string	"silver_output_lexical__forbidden_until"
	.section	.debug_line_str,"MS",@progbits,1
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_output_lexical.adb"
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
	.hidden	DW.ref.__gnat_personality_v0
	.weak	DW.ref.__gnat_personality_v0
	.section	.data.rel.local.DW.ref.__gnat_personality_v0,"awG",@progbits,DW.ref.__gnat_personality_v0,comdat
	.align 8
	.type	DW.ref.__gnat_personality_v0, @object
	.size	DW.ref.__gnat_personality_v0, 8
DW.ref.__gnat_personality_v0:
	.quad	__gnat_personality_v0
	.globl	__gnat_personality_v0
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
