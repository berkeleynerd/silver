	.file	"silver_numbers.adb"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_numbers.adb"
	.section	.rodata
	.align 8
.LC3:
	.ascii	"Subprogram_Variant failed at silver_numbers.ads:9"
	.align 8
.LC1:
	.long	1
	.long	49
	.text
	.align 2
	.type	___ghost_silver_numbers__represents___variants, @function
___ghost_silver_numbers__represents___variants:
.LFB3:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%rbx
	subq	$40, %rsp
	.cfi_offset 3, -24
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -32(%rbp)
	movq	%rdi, -24(%rbp)
	movl	%edx, -36(%rbp)
	movq	%r10, -48(%rbp)
	movq	-24(%rbp), %rax
	movl	(%rax), %eax
	movq	-24(%rbp), %rdx
	movl	4(%rdx), %edx
	cmpl	%eax, %edx
	jl	.L2
	movslq	%edx, %rsi
	movq	%rsi, %rdi
	sarq	$63, %rdi
	movslq	%eax, %r8
	movq	%r8, %r9
	sarq	$63, %r9
	subq	%r8, %rsi
	sbbq	%r9, %rdi
	addq	$1, %rsi
	adcq	$0, %rdi
	jmp	.L3
.L2:
	movl	$0, %esi
	movl	$0, %edi
.L3:
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	cmpl	%eax, %edx
	movq	(%r10), %rax
	movq	8(%r10), %rdx
	cmpl	%eax, %esi
	jl	.L11
	leaq	.LC3(%rip), %rcx
	leaq	.LC1(%rip), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L11:
	movq	-8(%rbp), %rbx
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.size	___ghost_silver_numbers__represents___variants, .-___ghost_silver_numbers__represents___variants
	.section	.rodata
	.align 8
.LC4:
	.ascii	"failed precondition from silver_numbers.ads:8"
.LC5:
	.ascii	"silver_numbers.adb"
	.zero	1
	.align 8
.LC0:
	.long	1
	.long	45
	.text
	.align 2
	.globl	___ghost_silver_numbers__represents
	.type	___ghost_silver_numbers__represents, @function
___ghost_silver_numbers__represents:
.LFB2:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_numbers.adb"
	.loc 1 2 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rbx
	subq	$96, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%rdi, %rax
	movq	%rax, %rcx
	movl	$0, %ebx
	movq	%rsi, %rbx
	movq	%rcx, -96(%rbp)
	movq	%rbx, -88(%rbp)
	movl	%edx, -100(%rbp)
	.loc 1 2 4
	leaq	16(%rbp), %rax
	.loc 1 2 4 is_stmt 0 discriminator 1
	movq	%rax, -64(%rbp)
	movq	-88(%rbp), %rax
	movl	(%rax), %ebx
	movq	-88(%rbp), %rax
	movl	4(%rax), %eax
	movq	-88(%rbp), %rdx
	movl	4(%rdx), %ecx
	movq	-88(%rbp), %rdx
	movl	(%rdx), %edx
	cmpl	%edx, %ecx
	jl	.L13
	.loc 1 2 4 discriminator 2
	movq	-88(%rbp), %rdx
	movl	4(%rdx), %edx
	movslq	%edx, %rdx
	movq	%rdx, %rsi
	movq	%rdx, %rdi
	sarq	$63, %rdi
	movq	-88(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movq	%rdx, %r10
	movq	%rdx, %r11
	sarq	$63, %r11
	subq	%r10, %rsi
	sbbq	%r11, %rdi
	addq	$1, %rsi
	adcq	$0, %rdi
	jmp	.L14
.L13:
	.loc 1 2 4 discriminator 3
	movl	$0, %esi
	movl	$0, %edi
.L14:
.LBB4:
	.file 2 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_numbers.ads"
	.loc 2 8 30 is_stmt 1
	movslq	%ebx, %rdx
	leaq	10(%rdx), %rcx
	movslq	%eax, %rdx
	.loc 2 8 18
	cmpq	%rdx, %rcx
	jge	.L15
.LBB5:
	.loc 2 8 18 is_stmt 0 discriminator 1
	leaq	.LC4(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L15:
.LBE5:
	.loc 2 9 51 is_stmt 1
	movq	%rsi, -80(%rbp)
	movq	%rdi, -72(%rbp)
	.loc 1 3 7
	cmpl	%eax, %ebx
	jle	.L16
	.loc 1 3 37 discriminator 1
	cmpl	$0, -100(%rbp)
	sete	%al
	jmp	.L17
.L16:
	.loc 1 4 12
	cmpl	%ebx, %eax
	jge	.L18
	.loc 1 4 12 is_stmt 0 discriminator 1
	leaq	.LC5(%rip), %rax
	movl	$4, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L18:
	.loc 1 4 29 is_stmt 1 discriminator 2
	movq	-96(%rbp), %rdx
	movq	-88(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movslq	%eax, %rsi
	subq	%rcx, %rsi
	movzbl	(%rdx,%rsi), %edx
	cmpb	$47, %dl
	jbe	.L19
	.loc 1 4 29 is_stmt 0 discriminator 3
	movq	-96(%rbp), %rdx
	movq	-88(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movslq	%eax, %rsi
	subq	%rcx, %rsi
	movzbl	(%rdx,%rsi), %edx
	cmpb	$57, %dl
	ja	.L19
	.loc 1 4 29 discriminator 4
	movl	$1, %edx
	jmp	.L20
.L19:
	.loc 1 4 29 discriminator 5
	movl	$0, %edx
.L20:
	.loc 1 7 9 is_stmt 1
	testb	%dl, %dl
	je	.L21
	.loc 1 5 33
	cmpl	%ebx, %eax
	jge	.L22
	.loc 1 5 33 is_stmt 0 discriminator 1
	leaq	.LC5(%rip), %rax
	movl	$5, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L22:
	.loc 1 5 51 is_stmt 1 discriminator 2
	movq	-96(%rbp), %rdx
	movq	-88(%rbp), %rcx
	movl	(%rcx), %ecx
	movslq	%ecx, %rcx
	movslq	%eax, %rsi
	subq	%rcx, %rsi
	movzbl	(%rdx,%rsi), %edx
	movzbl	%dl, %edx
	leal	-48(%rdx), %edi
	.loc 1 6 19
	movl	-100(%rbp), %esi
	movslq	%esi, %rdx
	imulq	$1717986919, %rdx, %rdx
	shrq	$32, %rdx
	movl	%edx, %ecx
	sarl	$2, %ecx
	movl	%esi, %edx
	sarl	$31, %edx
	subl	%edx, %ecx
	movl	%ecx, %edx
	sall	$2, %edx
	addl	%ecx, %edx
	addl	%edx, %edx
	subl	%edx, %esi
	movl	%esi, %ecx
	.loc 1 6 11
	cmpl	%ecx, %edi
	sete	%dl
	.loc 1 5 9 discriminator 2
	testb	%dl, %dl
	je	.L21
	.loc 1 7 30 discriminator 1
	cmpl	%ebx, %eax
	.loc 1 7 30 is_stmt 0 discriminator 4
	cmpl	%ebx, %eax
	.loc 1 7 30 discriminator 7
	cmpl	%ebx, %eax
	.loc 1 7 60 is_stmt 1 discriminator 10
	cmpl	$-2147483648, %eax
	jne	.L29
	.loc 1 7 60 is_stmt 0 discriminator 11
	leaq	.LC5(%rip), %rax
	movl	$7, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L29:
	.loc 1 7 60 discriminator 13
	leal	-1(%rax), %r12d
	.loc 1 7 30 is_stmt 1 discriminator 14
	cmpl	%ebx, %r12d
	.loc 1 7 30 is_stmt 0 discriminator 17
	cmpl	%ebx, %r12d
	.loc 1 7 30 discriminator 20
	cmpl	%ebx, %r12d
	.loc 1 7 72 is_stmt 1 discriminator 23
	movl	-100(%rbp), %eax
	movslq	%eax, %rdx
	imulq	$1717986919, %rdx, %rdx
	shrq	$32, %rdx
	movl	%edx, %ecx
	sarl	$2, %ecx
	cltd
	movl	%ecx, %eax
	subl	%edx, %eax
	.loc 1 7 18 discriminator 23
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movslq	%ebx, %rsi
	subq	%rdx, %rsi
	leaq	(%rcx,%rsi), %rdx
	movq	%rdx, -128(%rbp)
	movl	%ebx, -48(%rbp)
	movl	%r12d, -44(%rbp)
	leaq	-48(%rbp), %rdx
	movq	%rdx, -120(%rbp)
	movq	-128(%rbp), %rdx
	movq	-120(%rbp), %rcx
	movq	%rdx, %rsi
	leaq	-80(%rbp), %rdx
	movq	%rdx, %r10
	movl	%eax, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	___ghost_silver_numbers__represents___variants
	.loc 1 7 72 discriminator 24
	movl	-100(%rbp), %eax
	movslq	%eax, %rdx
	imulq	$1717986919, %rdx, %rdx
	shrq	$32, %rdx
	movl	%edx, %ecx
	sarl	$2, %ecx
	cltd
	movl	%ecx, %eax
	subl	%edx, %eax
	.loc 1 7 18 discriminator 24
	movq	-96(%rbp), %rcx
	movq	-88(%rbp), %rdx
	movl	(%rdx), %edx
	movslq	%edx, %rdx
	movslq	%ebx, %rsi
	subq	%rdx, %rsi
	leaq	(%rcx,%rsi), %rdx
	movq	%rdx, %r14
	movl	%ebx, -40(%rbp)
	movl	%r12d, -36(%rbp)
	leaq	-40(%rbp), %rdx
	movq	%rdx, %r15
	movq	%r14, %rsi
	movq	%r15, %rcx
	movl	%eax, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	___ghost_silver_numbers__represents
	.loc 1 7 9 discriminator 25
	testb	%al, %al
	je	.L21
	.loc 1 7 9 is_stmt 0 discriminator 26
	movl	$1, %eax
	.loc 1 7 9 discriminator 28
	jmp	.L17
.L21:
	.loc 1 7 9 discriminator 27
	movl	$0, %eax
.L17:
.LBE4:
	.loc 1 2 4 is_stmt 1
	addq	$96, %rsp
	popq	%rbx
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	___ghost_silver_numbers__represents, .-___ghost_silver_numbers__represents
	.align 2
	.type	silver_numbers__decimal___wrapped_statements.0, @function
silver_numbers__decimal___wrapped_statements.0:
.LFB5:
	.loc 1 9 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$48, %rsp
	.cfi_offset 14, -24
	.cfi_offset 13, -32
	.cfi_offset 12, -40
	.cfi_offset 3, -48
	movq	%r10, %rax
	movq	%r10, -72(%rbp)
	.loc 1 10 7
	movabsq	$3472328296227680304, %rbx
	movq	%rbx, -64(%rbp)
	movl	$808464432, -57(%rbp)
	.loc 1 11 7
	movl	(%rax), %eax
	movl	%eax, -36(%rbp)
.LBB6:
	.loc 1 15 11
	movl	$11, -40(%rbp)
.L58:
	.loc 1 15 11 is_stmt 0 discriminator 1
	cmpl	$0, -40(%rbp)
	jle	.L38
.LBB7:
	.loc 1 16 71 is_stmt 1
	movl	-36(%rbp), %edx
	movslq	%edx, %rax
	imulq	$1717986919, %rax, %rax
	shrq	$32, %rax
	movl	%eax, %ecx
	sarl	$2, %ecx
	movl	%edx, %eax
	sarl	$31, %eax
	subl	%eax, %ecx
	movl	%ecx, %eax
	sall	$2, %eax
	addl	%ecx, %eax
	addl	%eax, %eax
	subl	%eax, %edx
	movl	%edx, %ecx
	.loc 1 16 63
	movl	%ecx, %eax
	leal	48(%rax), %edx
	.loc 1 16 25
	movl	-40(%rbp), %eax
	cltq
	movb	%dl, -65(%rbp,%rax)
	.loc 1 17 15
	movl	-36(%rbp), %eax
	movslq	%eax, %rdx
	imulq	$1717986919, %rdx, %rdx
	shrq	$32, %rdx
	movl	%edx, %ecx
	sarl	$2, %ecx
	cltd
	movl	%ecx, %eax
	subl	%edx, %eax
	movl	%eax, -36(%rbp)
	.loc 1 18 10
	cmpl	$0, -36(%rbp)
	jne	.L39
	.loc 1 19 20
	movl	-40(%rbp), %ebx
	cmpl	$11, %ebx
	.loc 1 19 20 is_stmt 0 discriminator 3
	cmpl	$11, %ebx
	.loc 1 19 20 discriminator 6
	cmpl	$11, %ebx
	jg	.L44
	.loc 1 19 20 discriminator 7
	movslq	%ebx, %rax
	movl	$12, %edx
	subq	%rax, %rdx
	movq	%rdx, %r14
	jmp	.L45
.L44:
	.loc 1 19 20 discriminator 8
	movl	$0, %r14d
.L45:
	.loc 1 19 13 is_stmt 1 discriminator 9
	leaq	11(%r14), %rax
	andq	$-4, %rax
	movl	$4, %esi
	movq	%rax, %rdi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %r8
	.loc 1 19 13 is_stmt 0 discriminator 10
	movq	%r8, %rax
	movl	%ebx, (%rax)
	movl	$11, 4(%rax)
	cmpl	$11, %ebx
	jg	.L46
	.loc 1 19 13 discriminator 11
	movslq	%ebx, %rdx
	jmp	.L47
.L46:
	.loc 1 19 13 discriminator 12
	movl	$12, %edx
.L47:
	.loc 1 19 13 discriminator 13
	leaq	-64(%rbp), %rcx
	subq	$1, %rdx
	leaq	(%rcx,%rdx), %rsi
	addq	$8, %rax
	movl	%r14d, %ecx
	movq	%rax, %rdx
	movq	%rsi, %rax
	cmpl	$64, %ecx
	jnb	.L48
	movl	%ecx, %esi
	andl	$32, %esi
	testl	%esi, %esi
	je	.L50
	movdqu	(%rax), %xmm0
	movups	%xmm0, (%rdx)
	movdqu	16(%rax), %xmm0
	movups	%xmm0, 16(%rdx)
	movl	%ecx, %esi
	addq	%rsi, %rdx
	addq	$32, %rdx
	movl	%ecx, %ecx
	addq	%rcx, %rax
	addq	$32, %rax
	movdqu	-64(%rax), %xmm0
	movups	%xmm0, -64(%rdx)
	movdqu	-48(%rax), %xmm0
	movups	%xmm0, -48(%rdx)
	jmp	.L49
.L50:
	movl	%ecx, %esi
	andl	$16, %esi
	testl	%esi, %esi
	je	.L51
	movdqu	(%rax), %xmm0
	movups	%xmm0, (%rdx)
	movl	%ecx, %esi
	addq	%rsi, %rdx
	addq	$16, %rdx
	movl	%ecx, %ecx
	addq	%rcx, %rax
	addq	$16, %rax
	movdqu	-32(%rax), %xmm0
	movups	%xmm0, -32(%rdx)
	jmp	.L49
.L51:
	movl	%ecx, %esi
	andl	$8, %esi
	testl	%esi, %esi
	je	.L52
	movq	(%rax), %rsi
	movq	%rsi, (%rdx)
	movl	%ecx, %esi
	addq	%rsi, %rdx
	addq	$8, %rdx
	movl	%ecx, %ecx
	addq	%rcx, %rax
	addq	$8, %rax
	movq	-16(%rax), %rax
	movq	%rax, -16(%rdx)
	jmp	.L49
.L52:
	movl	%ecx, %esi
	andl	$4, %esi
	testl	%esi, %esi
	je	.L53
	movl	(%rax), %esi
	movl	%esi, (%rdx)
	movl	%ecx, %esi
	addq	%rsi, %rdx
	addq	$4, %rdx
	movl	%ecx, %ecx
	addq	%rcx, %rax
	addq	$4, %rax
	movl	-8(%rax), %eax
	movl	%eax, -8(%rdx)
	jmp	.L49
.L53:
	testl	%ecx, %ecx
	je	.L49
	movzbl	(%rax), %esi
	movb	%sil, (%rdx)
	movl	%ecx, %esi
	andl	$2, %esi
	testl	%esi, %esi
	je	.L49
	movl	%ecx, %esi
	addq	%rsi, %rdx
	movl	%ecx, %ecx
	addq	%rcx, %rax
	movzwl	-2(%rax), %eax
	movw	%ax, -2(%rdx)
	jmp	.L49
.L48:
	movl	%ecx, %esi
	addq	%rdx, %rsi
	movl	%ecx, %edi
	addq	%rax, %rdi
	movdqu	-64(%rdi), %xmm0
	movups	%xmm0, -64(%rsi)
	movdqu	-48(%rdi), %xmm0
	movups	%xmm0, -48(%rsi)
	movdqu	-32(%rdi), %xmm0
	movups	%xmm0, -32(%rsi)
	movdqu	-16(%rdi), %xmm0
	movups	%xmm0, -16(%rsi)
	subl	$1, %ecx
	cmpl	$64, %ecx
	jb	.L49
	movl	%ecx, %edi
	andl	$-64, %edi
	movl	$0, %esi
.L55:
	movl	%esi, %ecx
	movdqu	(%rax,%rcx), %xmm3
	movdqu	16(%rax,%rcx), %xmm2
	movdqu	32(%rax,%rcx), %xmm1
	movdqu	48(%rax,%rcx), %xmm0
	movups	%xmm3, (%rdx,%rcx)
	movups	%xmm2, 16(%rdx,%rcx)
	movups	%xmm1, 32(%rdx,%rcx)
	movups	%xmm0, 48(%rdx,%rcx)
	addl	$64, %esi
	cmpl	%edi, %esi
	jb	.L55
	movl	%esi, %ecx
	addq	%rcx, %rdx
	addq	%rcx, %rax
.L49:
	.loc 1 19 13 discriminator 14
	movq	%r8, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%r8, %rax
	movq	%rax, %r13
	jmp	.L59
.L39:
.LBE7:
	.loc 1 15 11 is_stmt 1 discriminator 2
	subl	$1, -40(%rbp)
	.loc 1 21 15
	jmp	.L58
.L38:
.LBE6:
	.loc 1 22 7
	movl	$4, %esi
	movl	$20, %edi
	call	system__secondary_stack__ss_allocate@PLT
	movq	%rax, %rdx
	.loc 1 22 7 is_stmt 0 discriminator 1
	movq	%rdx, %rax
	movl	$1, (%rax)
	movl	$11, 4(%rax)
	movq	-64(%rbp), %rcx
	movq	%rcx, 8(%rax)
	movl	-57(%rbp), %ecx
	movl	%ecx, 15(%rax)
	movq	%rdx, %rax
	addq	$8, %rax
	movq	%rax, %r12
	movq	%rdx, %rax
	movq	%rax, %r13
.L59:
	.loc 1 23 8 is_stmt 1
	movq	%r12, %rax
	movq	%r13, %rdx
	addq	$48, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE5:
	.size	silver_numbers__decimal___wrapped_statements.0, .-silver_numbers__decimal___wrapped_statements.0
	.section	.rodata
	.align 8
.LC6:
	.ascii	"failed postcondition from silver_numbers.ads:13"
.LC7:
	.ascii	"silver_numbers.ads"
	.zero	1
	.align 8
.LC8:
	.ascii	"failed postcondition from silver_numbers.ads:14"
	.align 8
.LC9:
	.ascii	"failed postcondition from silver_numbers.ads:15"
	.align 8
.LC10:
	.ascii	"failed postcondition from silver_numbers.ads:16"
	.align 8
.LC2:
	.long	1
	.long	47
	.text
	.align 2
	.globl	silver_numbers__decimal
	.type	silver_numbers__decimal, @function
silver_numbers__decimal:
.LFB4:
	.loc 1 9 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$312, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movl	%edi, -148(%rbp)
	.loc 1 9 4
	leaq	16(%rbp), %rax
	.loc 1 9 4 is_stmt 0 discriminator 1
	movq	%rax, -136(%rbp)
	movl	-148(%rbp), %eax
	movl	%eax, -144(%rbp)
.LBB8:
	leaq	-144(%rbp), %rax
	movq	%rax, %r10
	call	silver_numbers__decimal___wrapped_statements.0
	.loc 1 9 4 discriminator 2
	movq	%rax, %r14
	movq	%rdx, %r15
	movq	%r15, %rax
	movl	(%rax), %ebx
	movq	%r15, %rax
	movl	4(%rax), %r12d
	movslq	%ebx, %r13
	cmpl	%ebx, %r12d
	.loc 1 9 4 discriminator 5
	cmpl	%ebx, %r12d
	.loc 1 9 4 discriminator 8
	cmpl	%ebx, %r12d
	.loc 1 9 4 discriminator 11
	cmpl	%ebx, %r12d
	jl	.L67
	.loc 1 9 4 discriminator 12
	testl	%ebx, %ebx
	jg	.L67
	.loc 1 9 4 discriminator 13
	leaq	.LC5(%rip), %rax
	movl	$9, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L67:
.LBB9:
	.loc 2 13 19 is_stmt 1
	cmpl	%ebx, %r12d
	jl	.L68
	.loc 2 13 41 discriminator 1
	movl	%r12d, %eax
	movl	%ebx, %edx
	subl	%edx, %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L68
	.loc 2 13 41 is_stmt 0 discriminator 2
	cmpl	%ebx, %r12d
	jl	.L69
	.loc 2 13 41 discriminator 3
	movl	%r12d, %eax
	movl	%ebx, %edx
	subl	%edx, %eax
	addl	$1, %eax
	cmpl	$11, %eax
	jle	.L69
.L68:
.LBB10:
	.loc 2 13 19 is_stmt 1 discriminator 4
	leaq	.LC6(%rip), %rax
	movq	%rax, -352(%rbp)
	leaq	.LC2(%rip), %rax
	movq	%rax, -344(%rbp)
	movq	-352(%rbp), %rcx
	movq	-344(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L69:
.LBE10:
	.loc 2 14 23
	movl	$1, %r9d
	movq	%r14, %rax
	movq	%rax, -336(%rbp)
	movl	%ebx, -120(%rbp)
	movl	%r12d, -116(%rbp)
	leaq	-120(%rbp), %rax
	movq	%rax, -328(%rbp)
	movq	-328(%rbp), %rax
	movl	(%rax), %ecx
	movq	%r14, %rax
	movq	%rax, -320(%rbp)
	movl	%ebx, -112(%rbp)
	movl	%r12d, -108(%rbp)
	leaq	-112(%rbp), %rax
	movq	%rax, -312(%rbp)
	movq	-312(%rbp), %rax
	movl	4(%rax), %r8d
	cmpl	%r8d, %ecx
	jg	.L70
.L76:
.LBB11:
.LBB12:
	.loc 2 14 23 is_stmt 0 discriminator 2
	movq	%r14, %rax
	movq	%rax, -304(%rbp)
	movl	%ebx, -104(%rbp)
	movl	%r12d, -100(%rbp)
	leaq	-104(%rbp), %rax
	movq	%rax, -296(%rbp)
	movq	-296(%rbp), %rax
	movl	(%rax), %eax
	cmpl	%eax, %ecx
	jl	.L71
	.loc 2 14 23 discriminator 3
	movq	%r14, %rax
	movq	%rax, -288(%rbp)
	movl	%ebx, -96(%rbp)
	movl	%r12d, -92(%rbp)
	leaq	-96(%rbp), %rax
	movq	%rax, -280(%rbp)
	movq	-280(%rbp), %rax
	movl	4(%rax), %eax
	cmpl	%eax, %ecx
	jle	.L72
.L71:
	.loc 2 14 23 discriminator 4
	leaq	.LC7(%rip), %rax
	movl	$14, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L72:
	.loc 2 14 31 is_stmt 1 discriminator 5
	movq	%r14, %rax
	movq	%rax, -272(%rbp)
	movl	%ebx, -88(%rbp)
	movl	%r12d, -84(%rbp)
	leaq	-88(%rbp), %rax
	movq	%rax, -264(%rbp)
	movq	-272(%rbp), %rdi
	movq	%r14, %rax
	movq	%rax, -256(%rbp)
	movl	%ebx, -80(%rbp)
	movl	%r12d, -76(%rbp)
	leaq	-80(%rbp), %rax
	movq	%rax, -248(%rbp)
	movq	-248(%rbp), %rax
	movl	(%rax), %eax
	movslq	%eax, %rdx
	movslq	%ecx, %rsi
	movq	%rsi, %rax
	subq	%rdx, %rax
	addq	%rdi, %rax
	movq	%rax, -56(%rbp)
	.loc 2 14 62 discriminator 5
	movq	%r14, %rax
	movq	%rax, -240(%rbp)
	movl	%ebx, -72(%rbp)
	movl	%r12d, -68(%rbp)
	leaq	-72(%rbp), %rax
	movq	%rax, -232(%rbp)
	movq	-240(%rbp), %rdi
	movq	%r14, %rax
	movq	%rax, -224(%rbp)
	movl	%ebx, -64(%rbp)
	movl	%r12d, -60(%rbp)
	leaq	-64(%rbp), %rax
	movq	%rax, -216(%rbp)
	movq	-216(%rbp), %rax
	movl	(%rax), %eax
	cltq
	subq	%rax, %rsi
	movq	%rsi, %rdx
	movzbl	(%rdi,%rdx), %edx
	.loc 2 14 62 is_stmt 0 discriminator 6
	movl	%edx, %eax
	.loc 2 14 23 is_stmt 1 discriminator 6
	cmpb	$47, %al
	jbe	.L73
	.loc 2 14 62 discriminator 7
	movl	%edx, %eax
	cmpb	$57, %al
	jbe	.L74
.L73:
	.loc 2 14 23 discriminator 8
	movl	$0, %r9d
	jmp	.L70
.L74:
.LBE12:
	.loc 2 14 23 is_stmt 0 discriminator 9
	cmpl	%r8d, %ecx
	je	.L70
	.loc 2 14 23 discriminator 10
	addl	$1, %ecx
	jmp	.L76
.L70:
.LBE11:
	.loc 2 14 23 discriminator 11
	movl	%r9d, %eax
	xorl	$1, %eax
	.loc 2 13 19 is_stmt 1 discriminator 5
	testb	%al, %al
	je	.L77
.LBB13:
	.loc 2 13 19 is_stmt 0 discriminator 6
	leaq	.LC8(%rip), %rax
	movq	%rax, -208(%rbp)
	leaq	.LC2(%rip), %rax
	movq	%rax, -200(%rbp)
	movq	-208(%rbp), %rcx
	movq	-200(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L77:
.LBE13:
	.loc 2 15 22 is_stmt 1
	movl	-144(%rbp), %eax
	movq	%r14, %rsi
	movq	%r15, %rcx
	movl	%eax, %edx
	movq	%rsi, %rdi
	movq	%rcx, %rsi
	call	___ghost_silver_numbers__represents
	.loc 2 15 22 is_stmt 0 discriminator 1
	xorl	$1, %eax
	.loc 2 13 19 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L78
.LBB14:
	.loc 2 13 19 is_stmt 0 discriminator 8
	leaq	.LC9(%rip), %rax
	movq	%rax, -192(%rbp)
	leaq	.LC2(%rip), %rax
	movq	%rax, -184(%rbp)
	movq	-192(%rbp), %rsi
	movq	-184(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L78:
.LBE14:
	.loc 2 13 19 discriminator 9
	cmpl	%r12d, %ebx
	je	.L79
	.loc 2 17 30 is_stmt 1
	cmpl	%r12d, %ebx
	jle	.L80
	.loc 2 17 30 is_stmt 0 discriminator 1
	leaq	.LC7(%rip), %rax
	movl	$17, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L80:
	.loc 2 17 61 is_stmt 1 discriminator 2
	movq	%r14, %rdx
	movslq	%ebx, %rax
	subq	%r13, %rax
	movzbl	(%rdx,%rax), %eax
	.loc 2 17 61 is_stmt 0 discriminator 3
	cmpb	$48, %al
	setne	%al
	xorl	$1, %eax
	.loc 2 17 15 is_stmt 1 discriminator 3
	testb	%al, %al
	je	.L79
.LBB15:
	.loc 2 13 19 discriminator 10
	leaq	.LC10(%rip), %rax
	movq	%rax, -176(%rbp)
	leaq	.LC2(%rip), %rax
	movq	%rax, -168(%rbp)
	movq	-176(%rbp), %rcx
	movq	-168(%rbp), %rbx
	movq	%rcx, %rdx
	movq	%rbx, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L79:
.LBE15:
.LBE9:
	.loc 1 9 4 discriminator 14
	movq	%r14, %rax
	movq	%r15, %rdx
.LBE8:
	.loc 1 9 4 is_stmt 0
	addq	$312, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	silver_numbers__decimal, .-silver_numbers__decimal
	.globl	silver_numbers_E
	.data
	.align 2
	.type	silver_numbers_E, @object
	.size	silver_numbers_E, 2
silver_numbers_E:
	.zero	2
	.text
.Letext0:
	.file 3 "<built-in>"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x1f3
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x9
	.long	.LASF14
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.quad	.Ltext0
	.quad	.Letext0-.Ltext0
	.long	.Ldebug_line0
	.uleb128 0x1
	.byte	0x8
	.byte	0x7
	.long	.LASF4
	.uleb128 0xa
	.byte	0x8
	.byte	0x5
	.long	.LASF15
	.uleb128 0xb
	.long	.LASF16
	.byte	0x10
	.byte	0x3
	.byte	0
	.long	0x7f
	.uleb128 0x4
	.long	.LASF2
	.long	0x52
	.byte	0
	.uleb128 0x5
	.long	0x84
	.uleb128 0xc
	.byte	0x8
	.byte	0x3
	.byte	0
	.long	0x74
	.uleb128 0x6
	.string	"LB0"
	.long	0xb1
	.byte	0
	.uleb128 0x6
	.string	"UB0"
	.long	0xb1
	.byte	0x4
	.byte	0
	.uleb128 0x4
	.long	.LASF3
	.long	0xbf
	.byte	0x8
	.byte	0
	.uleb128 0xd
	.long	0x3c
	.uleb128 0x7
	.long	0xaa
	.long	0xa3
	.uleb128 0xe
	.long	0xa3
	.uleb128 0x6
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x94
	.byte	0x4
	.uleb128 0x8
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x23
	.uleb128 0x4
	.byte	0x94
	.byte	0x4
	.byte	0
	.uleb128 0x1
	.byte	0x4
	.byte	0x5
	.long	.LASF5
	.uleb128 0x1
	.byte	0x1
	.byte	0x8
	.long	.LASF6
	.uleb128 0xf
	.sleb128 2147483647
	.long	.LASF17
	.long	0xa3
	.uleb128 0x5
	.long	0x57
	.uleb128 0x10
	.long	.LASF18
	.byte	0x1
	.byte	0x9
	.byte	0x4
	.long	0x3c
	.quad	.LFB4
	.quad	.LFE4-.LFB4
	.uleb128 0x1
	.byte	0x9c
	.long	0x190
	.uleb128 0x3
	.long	.LASF11
	.byte	0xb
	.byte	0x16
	.long	0x19f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0x11
	.long	.LASF19
	.long	0x3c
	.quad	.LFB5
	.quad	.LFE5-.LFB5
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x7
	.byte	0x91
	.sleb128 -88
	.byte	0x6
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.long	0x16d
	.uleb128 0x7
	.long	0xaa
	.long	0x12c
	.uleb128 0x12
	.long	0xa3
	.sleb128 11
	.byte	0
	.uleb128 0x2
	.long	.LASF7
	.byte	0x1
	.byte	0xa
	.byte	0x7
	.long	0x11c
	.uleb128 0x3
	.byte	0x91
	.sleb128 -80
	.uleb128 0x2
	.long	.LASF8
	.byte	0x1
	.byte	0xb
	.byte	0x7
	.long	0x190
	.uleb128 0x2
	.byte	0x91
	.sleb128 -52
	.uleb128 0x8
	.quad	.LBB6
	.quad	.LBE6-.LBB6
	.uleb128 0x2
	.long	.LASF9
	.byte	0x1
	.byte	0xf
	.byte	0xb
	.long	0xa3
	.uleb128 0x2
	.byte	0x91
	.sleb128 -56
	.byte	0
	.byte	0
	.uleb128 0x8
	.quad	.LBB12
	.quad	.LBE12-.LBB12
	.uleb128 0x2
	.long	.LASF10
	.byte	0x2
	.byte	0xe
	.byte	0x1f
	.long	0x1a4
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.byte	0
	.byte	0
	.uleb128 0x13
	.sleb128 0
	.sleb128 2147483647
	.long	.LASF20
	.long	0xa3
	.uleb128 0x14
	.long	0x190
	.uleb128 0x15
	.byte	0x8
	.long	0xaa
	.uleb128 0x16
	.long	.LASF21
	.byte	0x1
	.byte	0x2
	.byte	0x4
	.long	.LASF22
	.long	0x1ef
	.quad	.LFB2
	.quad	.LFE2-.LFB2
	.uleb128 0x1
	.byte	0x9c
	.long	0x1ef
	.uleb128 0x3
	.long	.LASF12
	.byte	0x5
	.byte	0x19
	.long	0x7f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x3
	.long	.LASF11
	.byte	0x5
	.byte	0x28
	.long	0x19f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -116
	.byte	0
	.uleb128 0x1
	.byte	0x1
	.byte	0x2
	.long	.LASF13
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 2
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x18
	.uleb128 0x2f
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x48
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0xd
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x14
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x15
	.uleb128 0x10
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x16
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x6e
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x2c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.Letext0-.Ltext0
	.quad	0
	.quad	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF21:
	.string	"silver_numbers__represents"
.LASF11:
	.string	"value"
.LASF3:
	.string	"P_BOUNDS"
.LASF16:
	.string	"string"
.LASF15:
	.string	"system__storage_elements__Tstorage_offsetB"
.LASF17:
	.string	"positive"
.LASF14:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF20:
	.string	"natural"
.LASF12:
	.string	"text"
.LASF2:
	.string	"P_ARRAY"
.LASF4:
	.string	"system__address"
.LASF13:
	.string	"boolean"
.LASF9:
	.string	"index"
.LASF10:
	.string	"T19b"
.LASF19:
	.string	"silver_numbers__decimal___wrapped_statements"
.LASF8:
	.string	"rest"
.LASF5:
	.string	"integer"
.LASF18:
	.string	"silver_numbers__decimal"
.LASF7:
	.string	"buffer"
.LASF6:
	.string	"character"
.LASF22:
	.string	"___ghost_silver_numbers__represents"
	.section	.debug_line_str,"MS",@progbits,1
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_numbers.adb"
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
