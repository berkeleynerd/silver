	.file	"silver_reports.adb"
	.text
.Ltext0:
	.file 0 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj" "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_reports.adb"
	.section	.rodata
	.align 8
.LC9:
	.ascii	"failed precondition from silver_reports.adb:183"
	.align 8
.LC10:
	.ascii	"failed precondition from silver_reports.adb:184"
	.align 8
.LC11:
	.ascii	"failed precondition from silver_reports.adb:185"
.LC12:
	.ascii	"silver_reports.adb"
	.zero	1
	.align 8
.LC0:
	.long	1
	.long	47
	.text
	.align 2
	.type	silver_reports__contains, @function
silver_reports__contains:
.LFB2:
	.file 1 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_reports.adb"
	.loc 1 182 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$120, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %r8
	movq	%rax, %rsi
	movl	$0, %edi
	movq	%r8, %rdi
	movq	%rsi, -80(%rbp)
	movq	%rdi, -72(%rbp)
	movq	%rdx, -96(%rbp)
	movq	%rcx, -88(%rbp)
	.loc 1 182 4
	movq	-88(%rbp), %rax
	movl	(%rax), %r14d
	movq	-88(%rbp), %rax
	movl	4(%rax), %ebx
	movl	%ebx, -100(%rbp)
	cmpl	%r14d, %ebx
	jl	.L2
	.loc 1 182 4 is_stmt 0 discriminator 1
	movslq	%ebx, %rax
	cqto
	movslq	%r14d, %rcx
	movq	%rcx, %rbx
	sarq	$63, %rbx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %r12
	movq	%rdx, %r13
	jmp	.L3
.L2:
	.loc 1 182 4 discriminator 2
	movl	$0, %r12d
	movl	$0, %r13d
.L3:
	.loc 1 182 4 discriminator 3
	movq	-72(%rbp), %rax
	movl	(%rax), %r15d
	movq	-72(%rbp), %rax
	movl	4(%rax), %eax
	movl	%eax, -104(%rbp)
	cmpl	%r15d, %eax
	jl	.L4
	.loc 1 182 4 discriminator 4
	cltq
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r15d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rsi
	movq	%rdx, %rdi
	jmp	.L5
.L4:
	.loc 1 182 4 discriminator 5
	movl	$0, %esi
	movl	$0, %edi
.L5:
.LBB2:
	.loc 1 182 4 discriminator 6
	movl	-100(%rbp), %eax
	cmpl	%r14d, %eax
	.loc 1 182 4 discriminator 9
	cmpl	%r14d, %eax
	.loc 1 182 4 discriminator 12
	cmpl	%r14d, %eax
	.loc 1 182 4 discriminator 15
	movslq	%r15d, %rbx
	movl	-104(%rbp), %eax
	cmpl	%r15d, %eax
	.loc 1 182 4 discriminator 18
	cmpl	%r15d, %eax
	.loc 1 182 4 discriminator 21
	cmpl	%r15d, %eax
	.loc 1 183 18 is_stmt 1
	cmpl	$1, %r15d
	je	.L18
.LBB3:
	.loc 1 183 18 is_stmt 0 discriminator 1
	leaq	.LC9(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L18:
.LBE3:
	.loc 1 183 18 discriminator 2
	cmpl	$1, %r14d
	je	.L19
.LBB4:
	.loc 1 183 18 discriminator 3
	leaq	.LC9(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L19:
.LBE4:
	.loc 1 184 29 is_stmt 1
	movslq	%r15d, %rax
	leaq	262143(%rax), %rdx
	movslq	-104(%rbp), %rax
	.loc 1 183 18 discriminator 4
	cmpq	%rax, %rdx
	jge	.L20
.LBB5:
	.loc 1 183 18 is_stmt 0 discriminator 5
	leaq	.LC10(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L20:
.LBE5:
	.loc 1 185 32 is_stmt 1
	movl	%r12d, %eax
	.loc 1 183 18 discriminator 6
	testl	%eax, %eax
	jle	.L21
	.loc 1 185 32 discriminator 1
	movl	%r12d, %eax
	cmpl	$262144, %eax
	jle	.L22
.L21:
.LBB6:
	.loc 1 183 18 discriminator 7
	leaq	.LC11(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L22:
.LBE6:
	.loc 1 189 25
	movl	%r12d, %edx
	movl	%esi, %eax
	.loc 1 189 7
	cmpl	%eax, %edx
	jle	.L23
	.loc 1 190 10
	movl	$0, %eax
	jmp	.L24
.L23:
	.loc 1 192 38
	movl	%esi, %eax
	movl	%r12d, %ecx
	movl	$0, %edx
	subl	%ecx, %eax
	jno	.L25
	movl	$1, %edx
.L25:
	.loc 1 192 38 is_stmt 0 discriminator 1
	movl	%edx, %eax
	testl	%eax, %eax
	je	.L27
	.loc 1 192 38 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$192, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L27:
	.loc 1 192 38 discriminator 4
	movl	%esi, %eax
	movl	%r12d, %edx
	subl	%edx, %eax
	.loc 1 192 56 is_stmt 1 discriminator 6
	cmpl	$2147483647, %eax
	jne	.L30
	.loc 1 192 11 discriminator 7
	leaq	.LC12(%rip), %rax
	movl	$192, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L30:
	.loc 1 192 11 is_stmt 0 discriminator 9
	addl	$1, %eax
	movl	%eax, -56(%rbp)
	.loc 1 192 11 discriminator 10
	cmpl	$0, -56(%rbp)
	jle	.L31
.LBB7:
	.loc 1 192 11 discriminator 11
	movl	$1, -52(%rbp)
.L50:
.LBB8:
	.loc 1 196 25 is_stmt 1
	movl	%r12d, %eax
	testl	%eax, %eax
	jle	.L32
	.loc 1 196 25 is_stmt 0 discriminator 1
	cmpl	-52(%rbp), %r15d
	jg	.L33
	.loc 1 196 52 is_stmt 1 discriminator 2
	movl	%r12d, %eax
	leal	-1(%rax), %edx
	.loc 1 196 34 discriminator 2
	movl	-52(%rbp), %eax
	addl	%edx, %eax
	.loc 1 196 25 discriminator 2
	cmpl	%eax, -104(%rbp)
	jge	.L32
.L33:
	.loc 1 196 25 is_stmt 0 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$196, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L32:
	.loc 1 196 13 is_stmt 1 discriminator 4
	movl	-52(%rbp), %eax
	.loc 1 196 34 discriminator 4
	movl	%r12d, %edx
	leal	-1(%rdx), %ecx
	movl	$0, %esi
	movl	-52(%rbp), %edx
	addl	%ecx, %edx
	jno	.L34
	movl	$1, %esi
.L34:
	movl	%edx, %ecx
	.loc 1 196 34 is_stmt 0 discriminator 5
	movl	%esi, %edx
	testl	%edx, %edx
	je	.L36
	.loc 1 196 34 discriminator 6
	leaq	.LC12(%rip), %rax
	movl	$196, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L36:
	.loc 1 196 34 discriminator 8
	movl	%ecx, %edx
	.loc 1 196 13 is_stmt 1 discriminator 9
	cmpl	%eax, %edx
	.loc 1 196 13 is_stmt 0 discriminator 12
	cmpl	%eax, %edx
	.loc 1 196 13 discriminator 15
	cmpl	%eax, %edx
	jl	.L41
	.loc 1 196 13 discriminator 16
	movslq	%edx, %rcx
	jmp	.L42
.L41:
	.loc 1 196 13 discriminator 17
	movslq	%eax, %rcx
	subq	$1, %rcx
.L42:
	.loc 1 196 13 discriminator 18
	movslq	%eax, %rsi
	subq	%rsi, %rcx
	leaq	1(%rcx), %rsi
	.loc 1 196 10 is_stmt 1 discriminator 18
	movq	-80(%rbp), %rcx
	movslq	%eax, %rdi
	subq	%rbx, %rdi
	addq	%rdi, %rcx
	cmpl	%eax, %edx
	jge	.L43
	.loc 1 196 10 is_stmt 0 discriminator 20
	cmpl	%r14d, -100(%rbp)
	jl	.L44
.L43:
	.loc 1 196 58 is_stmt 1 discriminator 21
	cmpl	%eax, %edx
	jl	.L45
	.loc 1 196 58 is_stmt 0 discriminator 22
	movslq	%edx, %rdx
	jmp	.L46
.L45:
	.loc 1 196 58 discriminator 23
	movslq	%eax, %rdx
	subq	$1, %rdx
.L46:
	.loc 1 196 58 discriminator 24
	cltq
	subq	%rax, %rdx
	addq	$1, %rdx
	movl	-100(%rbp), %eax
	cmpl	%r14d, %eax
	jl	.L47
	.loc 1 196 58 discriminator 25
	movslq	%eax, %rdi
	movslq	%r14d, %rax
	subq	%rax, %rdi
	leaq	1(%rdi), %rax
	jmp	.L48
.L47:
	.loc 1 196 58 discriminator 26
	movl	$0, %eax
.L48:
	.loc 1 196 58 discriminator 27
	cmpq	%rdx, %rax
	jne	.L49
	.loc 1 196 58 discriminator 28
	movq	-96(%rbp), %rax
	movq	%rsi, %rdx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcmp@PLT
	.loc 1 196 58 discriminator 29
	testl	%eax, %eax
	jne	.L49
.L44:
	.loc 1 197 13 is_stmt 1
	movl	$1, %eax
	jmp	.L24
.L49:
.LBE8:
	.loc 1 192 11 discriminator 12
	movl	-52(%rbp), %eax
	cmpl	-56(%rbp), %eax
	je	.L31
	.loc 1 192 11 is_stmt 0 discriminator 13
	addl	$1, -52(%rbp)
	.loc 1 199 15 is_stmt 1
	jmp	.L50
.L31:
.LBE7:
	.loc 1 200 7
	movl	$0, %eax
.L24:
.LBE2:
	.loc 1 201 8
	addq	$120, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE2:
	.size	silver_reports__contains, .-silver_reports__contains
	.section	.rodata
	.align 8
.LC13:
	.ascii	"failed precondition from silver_reports.adb:204"
	.align 8
.LC14:
	.ascii	"Loop_Invariant failed at silver_reports.adb:215"
	.align 8
.LC15:
	.ascii	"Loop_Variant failed at silver_reports.adb:218"
.LC16:
	.ascii	"\"spark\":{\""
	.align 8
.LC17:
	.ascii	"Loop_Invariant failed at silver_reports.adb:230"
	.align 8
.LC18:
	.ascii	"Loop_Variant failed at silver_reports.adb:234"
	.align 8
.LC1:
	.long	1
	.long	45
	.text
	.align 2
	.type	silver_reports__one_entity, @function
silver_reports__one_entity:
.LFB3:
	.loc 1 203 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$136, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -80(%rbp)
	movq	%rdx, -72(%rbp)
	.loc 1 203 4
	movq	-72(%rbp), %rax
	movl	(%rax), %r12d
	movq	-72(%rbp), %rax
	movl	4(%rax), %r13d
	cmpl	%r12d, %r13d
	jl	.L52
	.loc 1 203 4 is_stmt 0 discriminator 1
	movslq	%r13d, %rax
	movq	%rax, %rsi
	movq	%rax, %rdi
	sarq	$63, %rdi
	movslq	%r12d, %rax
	movq	%rax, %rcx
	movq	%rax, %rbx
	sarq	$63, %rbx
	movq	%rsi, %rax
	movq	%rdi, %rdx
	subq	%rcx, %rax
	sbbq	%rbx, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %r14
	movq	%rdx, %r15
	jmp	.L53
.L52:
	.loc 1 203 4 discriminator 2
	movl	$0, %r14d
	movl	$0, %r15d
.L53:
.LBB9:
	.loc 1 203 4 discriminator 3
	movslq	%r12d, %rbx
	cmpl	%r12d, %r13d
	.loc 1 203 4 discriminator 6
	cmpl	%r12d, %r13d
	.loc 1 203 4 discriminator 9
	cmpl	%r12d, %r13d
	.loc 1 204 18 is_stmt 1
	cmpl	$1, %r12d
	je	.L60
.LBB10:
	.loc 1 204 18 is_stmt 0 discriminator 1
	leaq	.LC13(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L60:
.LBE10:
	.loc 1 204 54 is_stmt 1 discriminator 2
	movslq	%r12d, %rax
	leaq	262143(%rax), %rdx
	movslq	%r13d, %rax
	.loc 1 204 18 discriminator 2
	cmpq	%rax, %rdx
	jge	.L61
.LBB11:
	.loc 1 204 18 is_stmt 0 discriminator 3
	leaq	.LC13(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L61:
.LBE11:
	.loc 1 207 7 is_stmt 1
	movl	$1, -52(%rbp)
	.loc 1 210 22
	movslq	%r12d, %rax
	leaq	17(%rax), %rdx
	movslq	%r13d, %rax
	.loc 1 210 7
	cmpq	%rax, %rdx
	jl	.L62
	.loc 1 211 10
	movl	$0, %eax
	jmp	.L63
.L62:
	.loc 1 213 56
	movb	$0, -81(%rbp)
.L116:
.LBB12:
	.loc 1 213 19 discriminator 1
	movl	%r14d, %eax
	subl	$8, %eax
	cmpl	%eax, -52(%rbp)
	jge	.L64
	.loc 1 215 13
	cmpl	$0, -52(%rbp)
	jle	.L65
	.loc 1 215 19 discriminator 1
	movl	%r14d, %eax
	subl	$7, %eax
	cmpl	%eax, -52(%rbp)
	jl	.L66
.L65:
.LBB13:
	.loc 1 215 13 discriminator 2
	leaq	.LC14(%rip), %rax
	movq	%rax, -160(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rbx
	movq	-152(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L66:
.LBE13:
	.loc 1 218 10
	cmpb	$0, -81(%rbp)
	je	.L67
	.loc 1 218 44 discriminator 1
	movl	-88(%rbp), %eax
	movl	%eax, -92(%rbp)
.L67:
	.loc 1 218 44 is_stmt 0 discriminator 2
	movl	-52(%rbp), %eax
	movl	%eax, -88(%rbp)
	.loc 1 218 10 is_stmt 1 discriminator 2
	cmpb	$0, -81(%rbp)
	je	.L68
	.loc 1 218 44 discriminator 3
	movl	-92(%rbp), %edi
	cmpl	%edi, %eax
	jg	.L69
.LBB14:
	.loc 1 218 44 is_stmt 0 discriminator 4
	leaq	.LC15(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-144(%rbp), %rbx
	movq	-136(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L68:
.LBE14:
	.loc 1 218 10 is_stmt 1 discriminator 5
	movb	$1, -81(%rbp)
.L69:
	.loc 1 219 19
	movl	-52(%rbp), %edx
	.loc 1 219 34
	movl	-52(%rbp), %eax
	addl	$9, %eax
	.loc 1 219 25
	cmpl	%edx, %eax
	jl	.L70
	.loc 1 219 25 is_stmt 0 discriminator 1
	cmpl	%edx, %r12d
	jg	.L71
	.loc 1 219 25 discriminator 2
	cmpl	%eax, %r13d
	jge	.L70
.L71:
	.loc 1 219 25 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$219, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L70:
	.loc 1 219 13 is_stmt 1 discriminator 4
	cmpl	%edx, %eax
	.loc 1 219 13 is_stmt 0 discriminator 7
	cmpl	%edx, %eax
	.loc 1 219 13 discriminator 10
	cmpl	%edx, %eax
	.loc 1 219 57 is_stmt 1 discriminator 13
	subl	%edx, %eax
	.loc 1 219 10 discriminator 13
	cmpl	$9, %eax
	jne	.L78
	.loc 1 219 57 discriminator 14
	movq	-80(%rbp), %rcx
	movslq	%edx, %rax
	subq	%rbx, %rax
	addq	%rax, %rcx
	leaq	.LC16(%rip), %rax
	movl	$10, %edx
	movq	%rax, %rsi
	movq	%rcx, %rdi
	call	memcmp@PLT
	.loc 1 219 57 is_stmt 0 discriminator 15
	testl	%eax, %eax
	jne	.L78
	.loc 1 220 31 is_stmt 1
	movl	-52(%rbp), %eax
	addl	$10, %eax
	testl	%eax, %eax
	jle	.L79
	.loc 1 220 31 is_stmt 0 discriminator 1
	cmpl	$262145, %eax
	jle	.L80
.L79:
	.loc 1 220 31 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$220, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L80:
	.loc 1 220 22 is_stmt 1 discriminator 3
	movl	%eax, -56(%rbp)
	.loc 1 221 25
	movslq	%r12d, %rax
	movl	-56(%rbp), %edx
	movslq	%edx, %rdx
	subq	$1, %rdx
	addq	%rax, %rdx
	movslq	%r13d, %rax
	.loc 1 221 13
	cmpq	%rax, %rdx
	jg	.L81
	.loc 1 222 23
	cmpl	-56(%rbp), %r12d
	jg	.L82
	.loc 1 222 23 is_stmt 0 discriminator 1
	cmpl	-56(%rbp), %r13d
	jge	.L83
.L82:
	.loc 1 222 23 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$222, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L83:
	.loc 1 222 39 is_stmt 1 discriminator 3
	movq	-80(%rbp), %rax
	movl	-56(%rbp), %edx
	movslq	%edx, %rdx
	subq	%rbx, %rdx
	movzbl	(%rax,%rdx), %eax
	cmpb	$47, %al
	jbe	.L84
	.loc 1 222 39 is_stmt 0 discriminator 4
	movq	-80(%rbp), %rax
	movl	-56(%rbp), %edx
	movslq	%edx, %rdx
	subq	%rbx, %rdx
	movzbl	(%rax,%rdx), %eax
	cmpb	$57, %al
	jbe	.L85
.L84:
	.loc 1 222 39 discriminator 5
	movl	$1, %eax
	jmp	.L86
.L85:
	.loc 1 222 39 discriminator 6
	movl	$0, %eax
.L86:
	.loc 1 222 15 is_stmt 1 discriminator 7
	testb	%al, %al
	je	.L87
.L81:
	.loc 1 224 16
	movl	$0, %eax
	jmp	.L63
.L87:
	.loc 1 228 13
	movl	$0, %edx
.L101:
.LBB15:
	.loc 1 226 28
	movslq	%r12d, %rax
	movl	-56(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	$1, %rcx
	addq	%rax, %rcx
	movslq	%r13d, %rax
	.loc 1 227 15
	cmpq	%rax, %rcx
	jg	.L88
	.loc 1 227 24 discriminator 1
	cmpl	-56(%rbp), %r12d
	jg	.L89
	.loc 1 227 24 is_stmt 0 discriminator 2
	cmpl	-56(%rbp), %r13d
	jge	.L90
.L89:
	.loc 1 227 24 discriminator 3
	leaq	.LC12(%rip), %rax
	movl	$227, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L90:
	.loc 1 227 40 is_stmt 1 discriminator 4
	movq	-80(%rbp), %rax
	movl	-56(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rbx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$47, %al
	jbe	.L91
	.loc 1 227 40 is_stmt 0 discriminator 5
	movq	-80(%rbp), %rax
	movl	-56(%rbp), %ecx
	movslq	%ecx, %rcx
	subq	%rbx, %rcx
	movzbl	(%rax,%rcx), %eax
	cmpb	$57, %al
	ja	.L91
	.loc 1 227 40 discriminator 6
	movl	$1, %eax
	jmp	.L92
.L91:
	.loc 1 227 40 discriminator 7
	movl	$0, %eax
.L92:
	.loc 1 227 40 discriminator 8
	xorl	$1, %eax
	.loc 1 227 15 is_stmt 1 discriminator 8
	testb	%al, %al
	jne	.L88
	.loc 1 230 28
	movl	-52(%rbp), %eax
	addl	$9, %eax
	.loc 1 230 19
	cmpl	%eax, -56(%rbp)
	jle	.L93
	.loc 1 230 68 discriminator 1
	movl	%r14d, %eax
	cmpl	$2147483647, %eax
	jne	.L94
	.loc 1 230 68 is_stmt 0 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$230, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L94:
	.loc 1 230 68 discriminator 4
	movl	%r14d, %eax
	addl	$1, %eax
	.loc 1 230 28 is_stmt 1 discriminator 5
	cmpl	-56(%rbp), %eax
	jge	.L95
.L93:
.LBB16:
	.loc 1 230 19 discriminator 6
	leaq	.LC17(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC0(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-128(%rbp), %rbx
	movq	-120(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L95:
.LBE16:
	.loc 1 234 16
	testb	%dl, %dl
	je	.L96
	.loc 1 234 50 discriminator 1
	movl	-96(%rbp), %eax
	movl	%eax, -164(%rbp)
.L96:
	.loc 1 234 50 is_stmt 0 discriminator 2
	movl	-56(%rbp), %eax
	movl	%eax, -96(%rbp)
	.loc 1 234 16 is_stmt 1 discriminator 2
	testb	%dl, %dl
	je	.L97
	.loc 1 234 50 discriminator 3
	movl	-164(%rbp), %edi
	cmpl	%edi, %eax
	jg	.L98
.LBB17:
	.loc 1 234 50 is_stmt 0 discriminator 4
	leaq	.LC18(%rip), %rax
	movq	%rax, -112(%rbp)
	leaq	.LC1(%rip), %rax
	movq	%rax, -104(%rbp)
	movq	-112(%rbp), %rbx
	movq	-104(%rbp), %rsi
	movq	%rbx, %rdx
	movq	%rsi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L97:
.LBE17:
	.loc 1 234 16 is_stmt 1 discriminator 5
	movl	$1, %edx
.L98:
	.loc 1 235 37
	movl	-56(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L99
	.loc 1 235 37 is_stmt 0 discriminator 1
	cmpl	$262145, %eax
	jle	.L100
.L99:
	.loc 1 235 37 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$235, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L100:
	.loc 1 235 25 is_stmt 1 discriminator 3
	movl	%eax, -56(%rbp)
.LBE15:
	.loc 1 236 21
	jmp	.L101
.L88:
	.loc 1 237 51
	movslq	%r12d, %rax
	.loc 1 237 29
	movl	-56(%rbp), %edx
	addl	$7, %edx
	movslq	%edx, %rdx
	.loc 1 237 51
	subq	$1, %rdx
	addq	%rax, %rdx
	movslq	%r13d, %rax
	.loc 1 238 15
	cmpq	%rax, %rdx
	jg	.L102
	.loc 1 238 30 discriminator 1
	movl	-56(%rbp), %eax
	.loc 1 238 51 discriminator 1
	movl	-56(%rbp), %edx
	addl	$7, %edx
	.loc 1 238 39 discriminator 1
	cmpl	%eax, %edx
	jl	.L103
	.loc 1 238 39 is_stmt 0 discriminator 2
	cmpl	%eax, %r12d
	jg	.L104
	.loc 1 238 39 discriminator 3
	cmpl	%edx, %r13d
	jge	.L103
.L104:
	.loc 1 238 39 discriminator 4
	leaq	.LC12(%rip), %rax
	movl	$238, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L103:
	.loc 1 238 24 is_stmt 1 discriminator 5
	cmpl	%eax, %edx
	.loc 1 238 24 is_stmt 0 discriminator 8
	cmpl	%eax, %edx
	.loc 1 238 24 discriminator 11
	cmpl	%eax, %edx
	.loc 1 238 74 is_stmt 1 discriminator 14
	subl	%eax, %edx
	cmpl	$7, %edx
	jne	.L111
	.loc 1 238 74 is_stmt 0 discriminator 15
	movq	-80(%rbp), %rdx
	cltq
	subq	%rbx, %rax
	movq	(%rdx,%rax), %rdx
	movabsq	$9016888616691055138, %rax
	cmpq	%rax, %rdx
	jne	.L111
	.loc 1 238 74 discriminator 16
	movl	$1, %eax
	jmp	.L112
.L111:
	.loc 1 238 74 discriminator 17
	movl	$0, %eax
.L112:
	.loc 1 238 15 is_stmt 1 discriminator 18
	testb	%al, %al
	je	.L102
	.loc 1 238 15 is_stmt 0 discriminator 19
	movl	$1, %eax
	.loc 1 237 13 is_stmt 1 discriminator 1
	jmp	.L63
.L102:
	.loc 1 238 15 discriminator 20
	movl	$0, %eax
	.loc 1 237 13 discriminator 1
	jmp	.L63
.L78:
	.loc 1 240 25
	movl	-52(%rbp), %eax
	addl	$1, %eax
	testl	%eax, %eax
	jle	.L114
	.loc 1 240 25 is_stmt 0 discriminator 1
	cmpl	$262145, %eax
	jle	.L115
.L114:
	.loc 1 240 25 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$240, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L115:
	.loc 1 240 16 is_stmt 1 discriminator 3
	movl	%eax, -52(%rbp)
.LBE12:
	.loc 1 241 15
	jmp	.L116
.L64:
	.loc 1 242 7
	movl	$0, %eax
.L63:
.LBE9:
	.loc 1 243 8
	addq	$136, %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE3:
	.size	silver_reports__one_entity, .-silver_reports__one_entity
	.section	.rodata
	.align 8
.LC19:
	.ascii	"failed precondition from silver_reports.adb:246"
	.align 8
.LC2:
	.long	1
	.long	27
	.align 8
.LC3:
	.long	1
	.long	32
	.align 8
.LC4:
	.long	1
	.long	9
	.align 8
.LC5:
	.long	1
	.long	10
	.align 8
.LC6:
	.long	1
	.long	20
	.align 8
.LC7:
	.long	1
	.long	15
	.align 8
.LC8:
	.long	1
	.long	18
	.text
	.align 2
	.type	silver_reports__matches_compact, @function
silver_reports__matches_compact:
.LFB4:
	.loc 1 245 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	subq	$112, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -48(%rbp)
	movq	%rdx, -40(%rbp)
	.loc 1 245 4
	movq	-40(%rbp), %rax
	movl	(%rax), %edx
	movq	-40(%rbp), %rax
	movl	4(%rax), %ecx
.LBB18:
	cmpl	%edx, %ecx
	.loc 1 245 4 is_stmt 0 discriminator 3
	cmpl	%edx, %ecx
	.loc 1 245 4 discriminator 6
	cmpl	%edx, %ecx
	.loc 1 246 18 is_stmt 1
	cmpl	$1, %edx
	je	.L124
.LBB19:
	.loc 1 246 18 is_stmt 0 discriminator 1
	leaq	.LC19(%rip), %r8
	leaq	.LC0(%rip), %r9
	movq	%r8, %rdx
	movq	%r9, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L124:
.LBE19:
	.loc 1 246 54 is_stmt 1 discriminator 2
	movslq	%edx, %rax
	leaq	262143(%rax), %rdx
	movslq	%ecx, %rax
	.loc 1 246 18 discriminator 2
	cmpq	%rax, %rdx
	jge	.L125
.LBB20:
	.loc 1 246 18 is_stmt 0 discriminator 3
	leaq	.LC19(%rip), %r10
	leaq	.LC0(%rip), %r11
	movq	%r10, %rdx
	movq	%r11, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L125:
.LBE20:
	.loc 1 250 14 is_stmt 1
	leaq	silver_reports__progress_field(%rip), %r12
	leaq	.LC2(%rip), %r13
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movq	%r12, %rdx
	movq	%r13, %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_reports__contains
	.loc 1 258 9
	testb	%al, %al
	je	.L126
	.loc 1 251 18
	leaq	silver_reports__stop_field(%rip), %r14
	leaq	.LC3(%rip), %r15
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movq	%r14, %rdx
	movq	%r15, %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_reports__contains
	.loc 1 251 9 discriminator 1
	testb	%al, %al
	je	.L126
	.loc 1 252 18
	leaq	silver_reports__flow_field(%rip), %rax
	movq	%rax, -144(%rbp)
	leaq	.LC4(%rip), %rax
	movq	%rax, -136(%rbp)
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movq	-144(%rbp), %rdx
	movq	-136(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_reports__contains
	.loc 1 252 9 discriminator 1
	testb	%al, %al
	je	.L126
	.loc 1 253 18
	leaq	silver_reports__proof_field(%rip), %rax
	movq	%rax, -128(%rbp)
	leaq	.LC5(%rip), %rax
	movq	%rax, -120(%rbp)
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movq	-128(%rbp), %rdx
	movq	-120(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_reports__contains
	.loc 1 253 9 discriminator 1
	testb	%al, %al
	je	.L126
	.loc 1 254 18
	leaq	silver_reports__skip_flow_field(%rip), %rax
	movq	%rax, -112(%rbp)
	leaq	.LC6(%rip), %rax
	movq	%rax, -104(%rbp)
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movq	-112(%rbp), %rdx
	movq	-104(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_reports__contains
	.loc 1 254 9 discriminator 1
	testb	%al, %al
	je	.L126
	.loc 1 255 18
	leaq	silver_reports__skip_proof_field(%rip), %rax
	movq	%rax, -96(%rbp)
	leaq	.LC7(%rip), %r15
	movq	%r15, -88(%rbp)
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movq	-96(%rbp), %rdx
	movq	-88(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_reports__contains
	.loc 1 255 9 discriminator 1
	testb	%al, %al
	je	.L126
	.loc 1 256 18
	leaq	silver_reports__assume_field(%rip), %rax
	movq	%rax, -80(%rbp)
	leaq	.LC8(%rip), %rax
	movq	%rax, -72(%rbp)
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movq	-80(%rbp), %rdx
	movq	-72(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_reports__contains
	.loc 1 256 9 discriminator 1
	testb	%al, %al
	je	.L126
	.loc 1 257 18
	leaq	silver_reports__warning_field(%rip), %rax
	movq	%rax, -64(%rbp)
	movq	%r15, -56(%rbp)
	movq	-48(%rbp), %rsi
	movq	-40(%rbp), %rax
	movq	-64(%rbp), %rdx
	movq	-56(%rbp), %rcx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	call	silver_reports__contains
	.loc 1 257 9 discriminator 1
	testb	%al, %al
	je	.L126
	.loc 1 258 18 discriminator 1
	movq	-48(%rbp), %rdx
	movq	-40(%rbp), %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_reports__one_entity
	.loc 1 258 9 discriminator 2
	testb	%al, %al
	je	.L126
	.loc 1 258 9 is_stmt 0 discriminator 3
	movl	$1, %eax
	jmp	.L127
.L126:
	.loc 1 258 9 discriminator 4
	movl	$0, %eax
.L127:
.LBE18:
	.loc 1 259 8 is_stmt 1
	addq	$112, %rsp
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE4:
	.size	silver_reports__matches_compact, .-silver_reports__matches_compact
	.section	.rodata
	.align 8
.LC20:
	.ascii	"Loop_Invariant failed at silver_reports.adb:271"
	.text
	.align 2
	.globl	silver_reports__complete_null_proof
	.type	silver_reports__complete_null_proof, @function
silver_reports__complete_null_proof:
.LFB5:
	.loc 1 261 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rbx
	subq	$136, %rsp
	.cfi_offset 15, -24
	.cfi_offset 14, -32
	.cfi_offset 13, -40
	.cfi_offset 12, -48
	.cfi_offset 3, -56
	movq	%rdi, %rax
	movq	%rsi, %rcx
	movq	%rax, %rax
	movl	$0, %edx
	movq	%rcx, %rdx
	movq	%rax, -144(%rbp)
	movq	%rdx, -136(%rbp)
	.loc 1 261 4
	movq	-136(%rbp), %rax
	movl	(%rax), %ebx
	movq	-136(%rbp), %rax
	movl	4(%rax), %r12d
	cmpl	%ebx, %r12d
	jl	.L130
	.loc 1 261 4 is_stmt 0 discriminator 1
	movslq	%r12d, %rax
	cqto
	movslq	%ebx, %rcx
	movq	%rcx, %rsi
	movq	%rcx, %rdi
	sarq	$63, %rdi
	subq	%rsi, %rax
	sbbq	%rdi, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rsi
	movq	%rdx, %rdi
	jmp	.L131
.L130:
	.loc 1 261 4 discriminator 2
	movl	$0, %esi
	movl	$0, %edi
.L131:
.LBB21:
	.loc 1 261 4 discriminator 3
	movslq	%ebx, %r13
	cmpl	%ebx, %r12d
	.loc 1 261 4 discriminator 6
	cmpl	%ebx, %r12d
	.loc 1 261 4 discriminator 9
	cmpl	%ebx, %r12d
	.loc 1 263 7 is_stmt 1
	cmpl	%r12d, %ebx
	jg	.L138
	.loc 1 263 50 discriminator 1
	movslq	%ebx, %rax
	leaq	262143(%rax), %rdx
	movslq	%r12d, %rax
	.loc 1 263 28 discriminator 1
	cmpq	%rax, %rdx
	jge	.L139
.L138:
	.loc 1 264 10
	movl	$0, %eax
	jmp	.L140
.L139:
.LBB22:
	.loc 1 266 7
	movq	%rsp, %rax
	movq	%rax, -168(%rbp)
	.loc 1 267 10
	movl	%esi, -60(%rbp)
	movl	-60(%rbp), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	cltq
	movq	%rax, -72(%rbp)
	movl	-60(%rbp), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	cltq
	movl	$16, %edx
	subq	$1, %rdx
	addq	%rdx, %rax
	movl	$16, %ecx
	movl	$0, %edx
	divq	%rcx
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	movq	%rax, -80(%rbp)
	.loc 1 267 51 discriminator 1
	movl	-60(%rbp), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovns	%eax, %edx
	movl	%esi, %eax
	movl	$0, %ecx
	testl	%eax, %eax
	cmovs	%ecx, %eax
	cmpl	%eax, %edx
	je	.L141
	.loc 1 267 51 is_stmt 0 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$267, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Length_Check@PLT
.L141:
	.loc 1 267 51 discriminator 3
	movl	-60(%rbp), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	movslq	%eax, %rdx
	movq	-80(%rbp), %rax
	movl	$32, %esi
	movq	%rax, %rdi
	call	memset@PLT
	.loc 1 268 10 is_stmt 1
	movl	$0, -52(%rbp)
	.loc 1 270 14
	movl	%ebx, -84(%rbp)
	movl	%r12d, -88(%rbp)
	movl	-84(%rbp), %eax
	cmpl	-88(%rbp), %eax
	jg	.L142
.LBB23:
	.loc 1 270 14 is_stmt 0 discriminator 1
	movl	-84(%rbp), %eax
	movl	%eax, -56(%rbp)
.L152:
.LBB24:
	.loc 1 271 50 is_stmt 1
	movl	$0, %edx
	movl	-56(%rbp), %eax
	subl	%ebx, %eax
	jno	.L143
	movl	$1, %edx
.L143:
	movl	%eax, %ecx
	.loc 1 271 50 is_stmt 0 discriminator 1
	movl	%edx, %eax
	testl	%eax, %eax
	je	.L145
	.loc 1 271 50 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$271, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L145:
	.loc 1 271 50 discriminator 4
	movl	%ecx, %eax
	.loc 1 271 36 is_stmt 1 discriminator 5
	cmpl	-52(%rbp), %eax
	jge	.L146
.LBB25:
	.loc 1 271 36 is_stmt 0 discriminator 6
	leaq	.LC20(%rip), %r14
	leaq	.LC0(%rip), %r15
	movq	%r14, %rdx
	movq	%r15, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	system__assertions__raise_assert_failure@PLT
.L146:
.LBE25:
	.loc 1 274 20 is_stmt 1
	movq	-144(%rbp), %rax
	movl	-56(%rbp), %edx
	movslq	%edx, %rdx
	subq	%r13, %rdx
	movzbl	(%rax,%rdx), %eax
	.loc 1 274 20 is_stmt 0 discriminator 1
	movsbl	%al, %eax
	movl	%eax, %edi
	call	silver_reports__removed
	.loc 1 274 20 discriminator 2
	xorl	$1, %eax
	.loc 1 274 13 is_stmt 1 discriminator 2
	testb	%al, %al
	je	.L147
	.loc 1 275 29
	cmpl	$2147483647, -52(%rbp)
	jne	.L148
	.loc 1 275 21 discriminator 1
	leaq	.LC12(%rip), %rax
	movl	$275, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Overflow_Check@PLT
.L148:
	.loc 1 275 21 is_stmt 0 discriminator 3
	addl	$1, -52(%rbp)
	.loc 1 276 16 is_stmt 1
	cmpl	$0, -52(%rbp)
	jle	.L149
	.loc 1 276 16 is_stmt 0 discriminator 1
	movl	-52(%rbp), %eax
	cmpl	-60(%rbp), %eax
	jle	.L150
.L149:
	.loc 1 276 16 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$276, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Index_Check@PLT
.L150:
	.loc 1 276 25 is_stmt 1 discriminator 3
	movl	-52(%rbp), %eax
	testl	%eax, %eax
	jns	.L151
	.loc 1 276 25 is_stmt 0 discriminator 4
	leaq	.LC12(%rip), %rax
	movl	$276, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Invalid_Data@PLT
.L151:
	.loc 1 276 31 is_stmt 1 discriminator 5
	movq	-144(%rbp), %rdx
	movl	-56(%rbp), %ecx
	movslq	%ecx, %rcx
	cltq
	subq	%r13, %rcx
	movzbl	(%rdx,%rcx), %ecx
	.loc 1 276 31 is_stmt 0 discriminator 6
	movq	-80(%rbp), %rdx
	movb	%cl, -1(%rdx,%rax)
.L147:
.LBE24:
	.loc 1 270 14 is_stmt 1 discriminator 2
	movl	-56(%rbp), %eax
	cmpl	-88(%rbp), %eax
	je	.L142
	.loc 1 270 14 is_stmt 0 discriminator 3
	addl	$1, -56(%rbp)
	.loc 1 280 18 is_stmt 1
	jmp	.L152
.L142:
.LBE23:
.LBB26:
	.loc 1 283 10
	movq	%rsp, %rax
	movq	%rax, %rbx
	.loc 1 284 53
	movl	-52(%rbp), %eax
	movl	%eax, -92(%rbp)
	.loc 1 284 50
	cmpl	$0, -92(%rbp)
	jle	.L153
	.loc 1 284 50 is_stmt 0 discriminator 1
	movl	-92(%rbp), %eax
	cmpl	-60(%rbp), %eax
	jle	.L153
	.loc 1 284 50 discriminator 2
	leaq	.LC12(%rip), %rax
	movl	$284, %esi
	movq	%rax, %rdi
	call	__gnat_rcheck_CE_Range_Check@PLT
.L153:
	.loc 1 284 13 is_stmt 1 discriminator 3
	movl	-92(%rbp), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	cltq
	movq	%rax, -104(%rbp)
	movl	-92(%rbp), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	movslq	%eax, %rcx
	movl	-92(%rbp), %eax
	movl	$0, %edx
	testl	%eax, %eax
	cmovs	%edx, %eax
	cltq
	movl	$16, %edx
	subq	$1, %rdx
	addq	%rdx, %rax
	movl	$16, %edi
	movl	$0, %edx
	divq	%rdi
	imulq	$16, %rax, %rax
	subq	%rax, %rsp
	movq	%rsp, %rax
	movq	%rax, -112(%rbp)
	.loc 1 284 13 is_stmt 0 discriminator 4
	movq	-80(%rbp), %rax
	movq	-112(%rbp), %rdx
	movq	%rdx, %rdi
	movq	%rcx, %rdx
	movq	%rax, %rsi
	call	memcpy@PLT
	.loc 1 287 20 is_stmt 1
	movq	-112(%rbp), %rax
	movq	%rax, -160(%rbp)
	movl	$1, -120(%rbp)
	movl	-92(%rbp), %eax
	movl	%eax, -116(%rbp)
	leaq	-120(%rbp), %rax
	movq	%rax, -152(%rbp)
	movq	-160(%rbp), %rsi
	movq	-152(%rbp), %rdi
	movq	%rsi, %rdx
	movq	%rdi, %rax
	movq	%rdx, %rdi
	movq	%rax, %rsi
	call	silver_reports__matches_compact
	.loc 1 287 13 discriminator 1
	nop
	.loc 1 288 13
	movq	%rbx, %rsp
.LBE26:
	.loc 1 289 10
	movq	-168(%rbp), %rsp
.L140:
.LBE22:
.LBE21:
	.loc 1 290 8
	leaq	-40(%rbp), %rsp
	popq	%rbx
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE5:
	.size	silver_reports__complete_null_proof, .-silver_reports__complete_null_proof
	.align 2
	.globl	silver_reports__removed
	.type	silver_reports__removed, @function
silver_reports__removed:
.LFB6:
	.loc 1 18 4
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movb	%dil, -1(%rbp)
	.loc 1 20 41
	cmpb	$32, -1(%rbp)
	je	.L155
	.loc 1 19 18
	cmpb	$9, -1(%rbp)
	je	.L155
	.loc 1 20 7 discriminator 1
	cmpb	$10, -1(%rbp)
	je	.L155
	.loc 1 20 41 discriminator 2
	cmpb	$13, -1(%rbp)
	jne	.L156
.L155:
	.loc 1 20 41 is_stmt 0 discriminator 3
	movl	$1, %eax
	jmp	.L157
.L156:
	.loc 1 20 41 discriminator 4
	movl	$0, %eax
.L157:
	.loc 1 18 4 is_stmt 1
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE6:
	.size	silver_reports__removed, .-silver_reports__removed
	.globl	silver_reports_E
	.data
	.align 2
	.type	silver_reports_E, @object
	.size	silver_reports_E, 2
silver_reports_E:
	.zero	2
	.globl	silver_reports__max_report_length
	.section	.rodata
	.align 4
	.type	silver_reports__max_report_length, @object
	.size	silver_reports__max_report_length, 4
silver_reports__max_report_length:
	.long	262144
	.globl	silver_reports__prefix
	.align 16
	.type	silver_reports__prefix, @object
	.size	silver_reports__prefix, 16
silver_reports__prefix:
	.ascii	"\"spark\":{\""
	.zero	6
	.globl	silver_reports__suffix
	.align 8
	.type	silver_reports__suffix, @object
	.size	silver_reports__suffix, 8
silver_reports__suffix:
	.ascii	"\":\"all\"}"
	.globl	silver_reports__progress_field
	.align 16
	.type	silver_reports__progress_field, @object
	.size	silver_reports__progress_field, 27
silver_reports__progress_field:
	.ascii	"\"progress\":\"PROGRESS_PROOF\""
	.globl	silver_reports__stop_field
	.align 32
	.type	silver_reports__stop_field, @object
	.size	silver_reports__stop_field, 32
silver_reports__stop_field:
	.ascii	"\"stop_reason\":\"STOP_REASON_NONE\""
	.globl	silver_reports__flow_field
	.align 16
	.type	silver_reports__flow_field, @object
	.size	silver_reports__flow_field, 16
silver_reports__flow_field:
	.ascii	"\"flow\":[]"
	.zero	7
	.globl	silver_reports__proof_field
	.align 16
	.type	silver_reports__proof_field, @object
	.size	silver_reports__proof_field, 16
silver_reports__proof_field:
	.ascii	"\"proof\":[]"
	.zero	6
	.globl	silver_reports__skip_flow_field
	.align 16
	.type	silver_reports__skip_flow_field, @object
	.size	silver_reports__skip_flow_field, 20
silver_reports__skip_flow_field:
	.ascii	"\"skip_flow_proof\":[]"
	.globl	silver_reports__skip_proof_field
	.align 16
	.type	silver_reports__skip_proof_field, @object
	.size	silver_reports__skip_proof_field, 16
silver_reports__skip_proof_field:
	.ascii	"\"skip_proof\":[]"
	.zero	1
	.globl	silver_reports__assume_field
	.align 16
	.type	silver_reports__assume_field, @object
	.size	silver_reports__assume_field, 18
silver_reports__assume_field:
	.ascii	"\"pragma_assume\":[]"
	.globl	silver_reports__warning_field
	.align 16
	.type	silver_reports__warning_field, @object
	.size	silver_reports__warning_field, 16
silver_reports__warning_field:
	.ascii	"\"warn_error\":[]"
	.zero	1
	.text
.Letext0:
	.file 2 "/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_reports.ads"
	.file 3 "<built-in>"
	.section	.debug_info,"",@progbits
.Ldebug_info0:
	.long	0x4f8
	.value	0x5
	.byte	0x1
	.byte	0x8
	.long	.Ldebug_abbrev0
	.uleb128 0x12
	.long	.LASF38
	.byte	0xd
	.long	.LASF0
	.long	.LASF1
	.quad	.Ltext0
	.quad	.Letext0-.Ltext0
	.long	.Ldebug_line0
	.uleb128 0x3
	.long	.LASF6
	.byte	0x2
	.byte	0x2
	.long	0x51
	.uleb128 0x9
	.byte	0x3
	.quad	silver_reports__max_report_length
	.uleb128 0xb
	.sleb128 2147483647
	.long	.LASF4
	.long	0x56
	.uleb128 0xc
	.long	0x43
	.uleb128 0x9
	.byte	0x4
	.byte	0x5
	.long	.LASF2
	.uleb128 0x2
	.long	0x72
	.long	0x6d
	.uleb128 0x4
	.long	0x56
	.sleb128 10
	.byte	0
	.uleb128 0x1
	.long	0x5d
	.uleb128 0x9
	.byte	0x1
	.byte	0x8
	.long	.LASF3
	.uleb128 0xc
	.long	0x72
	.uleb128 0x2
	.long	0x72
	.long	0x8e
	.uleb128 0x4
	.long	0x56
	.sleb128 8
	.byte	0
	.uleb128 0x1
	.long	0x7e
	.uleb128 0x2
	.long	0x72
	.long	0xa3
	.uleb128 0x4
	.long	0x56
	.sleb128 27
	.byte	0
	.uleb128 0x1
	.long	0x93
	.uleb128 0x2
	.long	0x72
	.long	0xb8
	.uleb128 0x4
	.long	0x56
	.sleb128 32
	.byte	0
	.uleb128 0x1
	.long	0xa8
	.uleb128 0x2
	.long	0x72
	.long	0xcd
	.uleb128 0x4
	.long	0x56
	.sleb128 9
	.byte	0
	.uleb128 0x1
	.long	0xbd
	.uleb128 0x2
	.long	0x72
	.long	0xe2
	.uleb128 0x4
	.long	0x56
	.sleb128 10
	.byte	0
	.uleb128 0x1
	.long	0xd2
	.uleb128 0x2
	.long	0x72
	.long	0xf7
	.uleb128 0x4
	.long	0x56
	.sleb128 20
	.byte	0
	.uleb128 0x1
	.long	0xe7
	.uleb128 0x2
	.long	0x72
	.long	0x10c
	.uleb128 0x4
	.long	0x56
	.sleb128 15
	.byte	0
	.uleb128 0x1
	.long	0xfc
	.uleb128 0x2
	.long	0x72
	.long	0x121
	.uleb128 0x4
	.long	0x56
	.sleb128 18
	.byte	0
	.uleb128 0x1
	.long	0x111
	.uleb128 0x2
	.long	0x72
	.long	0x136
	.uleb128 0x4
	.long	0x56
	.sleb128 15
	.byte	0
	.uleb128 0x1
	.long	0x126
	.uleb128 0xb
	.sleb128 262145
	.long	.LASF5
	.long	0x56
	.uleb128 0x3
	.long	.LASF7
	.byte	0x1
	.byte	0x6
	.long	0x6d
	.uleb128 0x9
	.byte	0x3
	.quad	silver_reports__prefix
	.uleb128 0x3
	.long	.LASF8
	.byte	0x1
	.byte	0x7
	.long	0x8e
	.uleb128 0x9
	.byte	0x3
	.quad	silver_reports__suffix
	.uleb128 0x3
	.long	.LASF9
	.byte	0x1
	.byte	0x8
	.long	0xa3
	.uleb128 0x9
	.byte	0x3
	.quad	silver_reports__progress_field
	.uleb128 0x3
	.long	.LASF10
	.byte	0x1
	.byte	0x9
	.long	0xb8
	.uleb128 0x9
	.byte	0x3
	.quad	silver_reports__stop_field
	.uleb128 0x3
	.long	.LASF11
	.byte	0x1
	.byte	0xa
	.long	0xcd
	.uleb128 0x9
	.byte	0x3
	.quad	silver_reports__flow_field
	.uleb128 0x3
	.long	.LASF12
	.byte	0x1
	.byte	0xb
	.long	0xe2
	.uleb128 0x9
	.byte	0x3
	.quad	silver_reports__proof_field
	.uleb128 0x3
	.long	.LASF13
	.byte	0x1
	.byte	0xc
	.long	0xf7
	.uleb128 0x9
	.byte	0x3
	.quad	silver_reports__skip_flow_field
	.uleb128 0x3
	.long	.LASF14
	.byte	0x1
	.byte	0xd
	.long	0x10c
	.uleb128 0x9
	.byte	0x3
	.quad	silver_reports__skip_proof_field
	.uleb128 0x3
	.long	.LASF15
	.byte	0x1
	.byte	0xe
	.long	0x121
	.uleb128 0x9
	.byte	0x3
	.quad	silver_reports__assume_field
	.uleb128 0x3
	.long	.LASF16
	.byte	0x1
	.byte	0xf
	.long	0x136
	.uleb128 0x9
	.byte	0x3
	.quad	silver_reports__warning_field
	.uleb128 0x13
	.long	.LASF18
	.byte	0x1
	.byte	0x12
	.byte	0x4
	.long	0x24b
	.quad	.LFB6
	.quad	.LFE6-.LFB6
	.uleb128 0x1
	.byte	0x9c
	.long	0x24b
	.uleb128 0x5
	.long	.LASF20
	.byte	0x1
	.byte	0x12
	.byte	0x16
	.long	0x79
	.uleb128 0x2
	.byte	0x91
	.sleb128 -17
	.byte	0
	.uleb128 0x9
	.byte	0x1
	.byte	0x2
	.long	.LASF17
	.uleb128 0x14
	.long	.LASF19
	.byte	0x1
	.value	0x105
	.byte	0x4
	.long	0x24b
	.quad	.LFB5
	.quad	.LFE5-.LFB5
	.uleb128 0x1
	.byte	0x9c
	.long	0x35c
	.uleb128 0x5
	.long	.LASF21
	.byte	0x2
	.byte	0xd
	.byte	0x22
	.long	0x3b3
	.uleb128 0x3
	.byte	0x91
	.sleb128 -160
	.uleb128 0x6
	.quad	.LBB22
	.quad	.LBE22-.LBB22
	.uleb128 0x7
	.long	.LASF24
	.long	0x56
	.uleb128 0x3
	.byte	0x91
	.sleb128 -76
	.uleb128 0x2
	.long	0x72
	.long	0x2b6
	.uleb128 0xd
	.long	0x56
	.long	0x296
	.byte	0
	.uleb128 0x8
	.long	.LASF22
	.value	0x10b
	.byte	0xa
	.long	0x2a3
	.uleb128 0x4
	.byte	0x91
	.sleb128 -96
	.byte	0x6
	.uleb128 0x8
	.long	.LASF23
	.value	0x10c
	.byte	0xa
	.long	0x3dc
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0x7
	.long	.LASF25
	.long	0x56
	.uleb128 0x3
	.byte	0x91
	.sleb128 -100
	.uleb128 0x7
	.long	.LASF26
	.long	0x56
	.uleb128 0x3
	.byte	0x91
	.sleb128 -104
	.uleb128 0x15
	.quad	.LBB23
	.quad	.LBE23-.LBB23
	.long	0x317
	.uleb128 0x8
	.long	.LASF27
	.value	0x10e
	.byte	0xe
	.long	0x56
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.byte	0
	.uleb128 0x6
	.quad	.LBB26
	.quad	.LBE26-.LBB26
	.uleb128 0x7
	.long	.LASF28
	.long	0x3dc
	.uleb128 0x3
	.byte	0x91
	.sleb128 -108
	.uleb128 0x2
	.long	0x72
	.long	0x348
	.uleb128 0xd
	.long	0x56
	.long	0x328
	.byte	0
	.uleb128 0x8
	.long	.LASF29
	.value	0x11c
	.byte	0xd
	.long	0x335
	.uleb128 0x4
	.byte	0x91
	.sleb128 -128
	.byte	0x6
	.byte	0
	.byte	0
	.byte	0
	.uleb128 0x16
	.long	.LASF39
	.byte	0x10
	.byte	0x3
	.byte	0
	.long	0x39f
	.uleb128 0xe
	.long	.LASF30
	.long	0x372
	.byte	0
	.uleb128 0xf
	.long	0x3b8
	.uleb128 0x17
	.byte	0x8
	.byte	0x3
	.byte	0
	.long	0x394
	.uleb128 0x10
	.string	"LB0"
	.long	0x43
	.byte	0
	.uleb128 0x10
	.string	"UB0"
	.long	0x43
	.byte	0x4
	.byte	0
	.uleb128 0xe
	.long	.LASF31
	.long	0x3d7
	.byte	0x8
	.byte	0
	.uleb128 0x1
	.long	0x35c
	.uleb128 0x1
	.long	0x35c
	.uleb128 0x1
	.long	0x35c
	.uleb128 0x1
	.long	0x35c
	.uleb128 0x1
	.long	0x35c
	.uleb128 0x2
	.long	0x72
	.long	0x3d7
	.uleb128 0x18
	.long	0x56
	.uleb128 0x6
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x94
	.byte	0x4
	.uleb128 0x8
	.byte	0x97
	.byte	0x23
	.uleb128 0x8
	.byte	0x6
	.byte	0x23
	.uleb128 0x4
	.byte	0x94
	.byte	0x4
	.byte	0
	.uleb128 0xf
	.long	0x377
	.uleb128 0x19
	.sleb128 0
	.sleb128 2147483647
	.long	.LASF40
	.long	0x56
	.uleb128 0x11
	.long	.LASF32
	.byte	0xf5
	.long	0x24b
	.quad	.LFB4
	.quad	.LFE4-.LFB4
	.uleb128 0x1
	.byte	0x9c
	.long	0x41b
	.uleb128 0x5
	.long	.LASF29
	.byte	0x1
	.byte	0xf5
	.byte	0x1e
	.long	0x3ae
	.uleb128 0x2
	.byte	0x91
	.sleb128 -64
	.byte	0
	.uleb128 0x11
	.long	.LASF33
	.byte	0xcb
	.long	0x24b
	.quad	.LFB3
	.quad	.LFE3-.LFB3
	.uleb128 0x1
	.byte	0x9c
	.long	0x47c
	.uleb128 0x5
	.long	.LASF29
	.byte	0x1
	.byte	0xcb
	.byte	0x19
	.long	0x3a9
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x6
	.quad	.LBB9
	.quad	.LBE9-.LBB9
	.uleb128 0xa
	.long	.LASF34
	.byte	0xcf
	.byte	0x7
	.long	0x13b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.uleb128 0xa
	.long	.LASF35
	.byte	0xd0
	.byte	0x7
	.long	0x13b
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.byte	0
	.byte	0
	.uleb128 0x1a
	.long	.LASF41
	.byte	0x1
	.byte	0xb6
	.byte	0x4
	.long	0x24b
	.quad	.LFB2
	.quad	.LFE2-.LFB2
	.uleb128 0x1
	.byte	0x9c
	.uleb128 0x5
	.long	.LASF29
	.byte	0x1
	.byte	0xb6
	.byte	0x17
	.long	0x3a4
	.uleb128 0x3
	.byte	0x91
	.sleb128 -96
	.uleb128 0x5
	.long	.LASF36
	.byte	0x1
	.byte	0xb6
	.byte	0x1d
	.long	0x39f
	.uleb128 0x3
	.byte	0x91
	.sleb128 -112
	.uleb128 0x6
	.quad	.LBB2
	.quad	.LBE2-.LBB2
	.uleb128 0x7
	.long	.LASF37
	.long	0x56
	.uleb128 0x3
	.byte	0x91
	.sleb128 -72
	.uleb128 0x6
	.quad	.LBB7
	.quad	.LBE7-.LBB7
	.uleb128 0xa
	.long	.LASF34
	.byte	0xc0
	.byte	0xb
	.long	0x56
	.uleb128 0x3
	.byte	0x91
	.sleb128 -68
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_abbrev,"",@progbits
.Ldebug_abbrev0:
	.uleb128 0x1
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.byte	0
	.byte	0
	.uleb128 0x2
	.uleb128 0x1
	.byte	0x1
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x3
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x4
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0xd
	.byte	0
	.byte	0
	.uleb128 0x5
	.uleb128 0x5
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x6
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.byte	0
	.byte	0
	.uleb128 0x7
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x8
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x9
	.uleb128 0x24
	.byte	0
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3e
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0xe
	.byte	0
	.byte	0
	.uleb128 0xa
	.uleb128 0x34
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.byte	0
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xc
	.uleb128 0x26
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xd
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x2f
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0xe
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0xf
	.uleb128 0xf
	.byte	0
	.uleb128 0xb
	.uleb128 0x21
	.sleb128 8
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x10
	.uleb128 0xd
	.byte	0
	.uleb128 0x3
	.uleb128 0x8
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 3
	.uleb128 0x3b
	.uleb128 0x21
	.sleb128 0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x38
	.uleb128 0xb
	.byte	0
	.byte	0
	.uleb128 0x11
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0x21
	.sleb128 1
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0x21
	.sleb128 4
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x12
	.uleb128 0x11
	.byte	0x1
	.uleb128 0x25
	.uleb128 0xe
	.uleb128 0x13
	.uleb128 0xb
	.uleb128 0x3
	.uleb128 0x1f
	.uleb128 0x1b
	.uleb128 0x1f
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x10
	.uleb128 0x17
	.byte	0
	.byte	0
	.uleb128 0x13
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7a
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x14
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3f
	.uleb128 0x19
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0x5
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x15
	.uleb128 0xb
	.byte	0x1
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x16
	.uleb128 0x13
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x17
	.uleb128 0x13
	.byte	0x1
	.uleb128 0xb
	.uleb128 0xb
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x34
	.uleb128 0x19
	.uleb128 0x1
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x18
	.uleb128 0x21
	.byte	0
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x22
	.uleb128 0x18
	.uleb128 0x2f
	.uleb128 0x18
	.byte	0
	.byte	0
	.uleb128 0x19
	.uleb128 0x21
	.byte	0
	.uleb128 0x22
	.uleb128 0xd
	.uleb128 0x2f
	.uleb128 0xd
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x49
	.uleb128 0x13
	.byte	0
	.byte	0
	.uleb128 0x1a
	.uleb128 0x2e
	.byte	0x1
	.uleb128 0x3
	.uleb128 0xe
	.uleb128 0x3a
	.uleb128 0xb
	.uleb128 0x3b
	.uleb128 0xb
	.uleb128 0x39
	.uleb128 0xb
	.uleb128 0x49
	.uleb128 0x13
	.uleb128 0x11
	.uleb128 0x1
	.uleb128 0x12
	.uleb128 0x7
	.uleb128 0x40
	.uleb128 0x18
	.uleb128 0x7c
	.uleb128 0x19
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_aranges,"",@progbits
	.long	0x2c
	.value	0x2
	.long	.Ldebug_info0
	.byte	0x8
	.byte	0
	.value	0
	.value	0
	.quad	.Ltext0
	.quad	.Letext0-.Ltext0
	.quad	0
	.quad	0
	.section	.debug_line,"",@progbits
.Ldebug_line0:
	.section	.debug_str,"MS",@progbits,1
.LASF23:
	.string	"last"
.LASF39:
	.string	"string"
.LASF4:
	.string	"positive"
.LASF8:
	.string	"silver_reports__suffix"
.LASF38:
	.string	"GNU Ada 16.1.0 -gnatA -gnat2022 -gnata -gnato -g -fstack-usage -gnatec=/tmp/GPR.586362/GNAT-TEMP-000003.TMP -gnatem=/tmp/GPR.586362/GNAT-TEMP-000004.TMP -mtune=generic -march=x86-64"
.LASF20:
	.string	"item"
.LASF40:
	.string	"natural"
.LASF41:
	.string	"silver_reports__contains"
.LASF36:
	.string	"pattern"
.LASF26:
	.string	"silver_reports__complete_null_proof__B_4__L_5__T136b___U"
.LASF15:
	.string	"silver_reports__assume_field"
.LASF25:
	.string	"silver_reports__complete_null_proof__B_4__L_5__T136b___L"
.LASF10:
	.string	"silver_reports__stop_field"
.LASF29:
	.string	"text"
.LASF28:
	.string	"R152b"
.LASF7:
	.string	"silver_reports__prefix"
.LASF30:
	.string	"P_ARRAY"
.LASF6:
	.string	"silver_reports__max_report_length"
.LASF13:
	.string	"silver_reports__skip_flow_field"
.LASF22:
	.string	"compact"
.LASF33:
	.string	"silver_reports__one_entity"
.LASF37:
	.string	"silver_reports__contains__L_1__T57b___U"
.LASF34:
	.string	"start"
.LASF35:
	.string	"position"
.LASF17:
	.string	"boolean"
.LASF27:
	.string	"index"
.LASF18:
	.string	"silver_reports__removed"
.LASF24:
	.string	"silver_reports__complete_null_proof__B_4__TTcompactSP1___U"
.LASF14:
	.string	"silver_reports__skip_proof_field"
.LASF31:
	.string	"P_BOUNDS"
.LASF2:
	.string	"integer"
.LASF5:
	.string	"silver_reports__cursor"
.LASF12:
	.string	"silver_reports__proof_field"
.LASF19:
	.string	"silver_reports__complete_null_proof"
.LASF32:
	.string	"silver_reports__matches_compact"
.LASF16:
	.string	"silver_reports__warning_field"
.LASF11:
	.string	"silver_reports__flow_field"
.LASF9:
	.string	"silver_reports__progress_field"
.LASF21:
	.string	"report"
.LASF3:
	.string	"character"
	.section	.debug_line_str,"MS",@progbits,1
.LASF0:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/src/silver_reports.adb"
.LASF1:
	.string	"/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-frame-check/obj"
	.ident	"GCC: (GNAT-FSF-builds) 16.1.0"
	.section	.note.GNU-stack,"",@progbits
