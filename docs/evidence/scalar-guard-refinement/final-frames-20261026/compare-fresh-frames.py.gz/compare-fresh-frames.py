"""Compare already completed frame outputs. No build, proof or probe calls."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
OLD = ROOT / "tmp/scalar-guard-refinement/docs/evidence/scalar-guard-refinement/shared-reader-frames-20261026"
NEW = ROOT / "tmp/guard-native-frames-final"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def record(path):
    return {"path": str(path), "sha256": digest(path.read_bytes())}


def su(text):
    result = defaultdict(list)
    for line in text.splitlines():
        parts = line.split("\t")
        if len(parts) == 3:
            result[parts[0].rsplit(":", 1)[-1]].append({"bytes": int(parts[1]), "classification": parts[2]})
    return dict(result)


def assembly(text):
    result = []
    function = None
    for number, line in enumerate(text.splitlines(), 1):
        match = re.match(r"\s*\.type\s+([^,]+),\s*@function", line)
        if match:
            function = match[1]
        if "call" in line and "system__secondary_stack__ss_" in line:
            operation = re.search(r"ss_(allocate|mark|release)", line).group(1)
            source_function = re.match(r"silver_output_profile__(.*?)(?:___wrapped|\.\d|__B_|$)", function).group(1)
            result.append({"assembly_line": number, "function": function,
                           "source_function": source_function,
                           "operation": operation, "call": line.strip()})
    return result


old_su = su(gzip.decompress((OLD / "obj/silver_output_profile.su.gz").read_bytes()).decode())
new_su = su((NEW / "obj/silver_output_profile.su").read_text())
old_asm = gzip.decompress((OLD / "obj/silver_output_profile.s.gz").read_bytes()).decode()
new_asm = (NEW / "obj/silver_output_profile.s").read_text()
old_sites, new_sites = assembly(old_asm), assembly(new_asm)
recursive = ("Read_Primary_Into", "Read_Relation_Into", "Read_Condition_Into", "Read_Chain_Into",
             "Read_Body", "Body_Tail", "Statement_Body", "Loop_Body", "Conditional_Body", "Alternative_Body")
recursive_rows = [{"routine": name, "old_entries": old_su[name], "new_entries": new_su[name],
                   "old_sum": sum(row["bytes"] for row in old_su[name]),
                   "new_sum": sum(row["bytes"] for row in new_su[name])} for name in recursive]
named_deltas = [{"routine": name, "old_entries": old_su.get(name), "new_entries": new_su.get(name)}
                for name in sorted(old_su.keys() | new_su.keys())
                if old_su.get(name) != new_su.get(name) and not re.match(r"B[0-9_]", name)]

def site_counts(sites):
    counts = Counter((row["source_function"], row["operation"]) for row in sites)
    return [{"source_function": key[0], "operation": key[1], "count": value}
            for key, value in sorted(counts.items())]


old_allocs = Counter(row["source_function"] for row in old_sites if row["operation"] == "allocate")
new_allocs = Counter(row["source_function"] for row in new_sites if row["operation"] == "allocate")
snapshot = json.loads((NEW / "input-snapshot.json").read_text())
snapshot_mismatches = [{"path": name, "expected": expected,
                        "actual": digest((NEW / name).read_bytes())}
                       for name, expected in snapshot.items() if digest((NEW / name).read_bytes()) != expected]
admission = json.loads((NEW / "admission-summary.json").read_text())
shape_summaries = list(NEW.glob("shape-results-*/summary.json"))
shapes = json.loads(shape_summaries[0].read_text()) if len(shape_summaries) == 1 else None
shape_mismatches = [{"path": name, "expected": expected, "actual": digest(Path(name).read_bytes())}
                    for name, expected in shapes["inputs_sha256"].items()
                    if digest(Path(name).read_bytes()) != expected] if shapes else None
result = {
    "recorded_utc": datetime.now(timezone.utc).isoformat(),
    "scope": "Read-only comparison of root-run completed frame/probe outputs, not an additional run.",
    "selected_model": "GPT-6.1 Sol", "selected_effort": "Extra High",
    "runtime_settings": "not independently exposed", "token_cost_evidence": "unavailable",
    "candidate_sha256": digest((NEW / "src/silver_output_profile.adb").read_bytes()),
    "input_snapshot": record(NEW / "input-snapshot.json"),
    "snapshot_files_checked": len(snapshot), "snapshot_mismatches": snapshot_mismatches,
    "files": [record(NEW / name) for name in ("obj/silver_output_profile.s", "obj/silver_output_profile.su", "bin/silver", "run-admission.py", "run-shapes.py", "build.log", "admission.log", "shapes.log")],
    "recursive_frame_sums": recursive_rows,
    "all_named_su_deltas": named_deltas,
    "secondary_calls": {"old": old_sites, "new": new_sites,
                        "old_counts": site_counts(old_sites), "new_counts": site_counts(new_sites),
                        "old_allocate_sites": sum(old_allocs.values()), "new_allocate_sites": sum(new_allocs.values()),
                        "allocation_site_counts_equal_by_source_function": old_allocs == new_allocs,
                        "old_total_calls": len(old_sites), "new_total_calls": len(new_sites)},
    "material_lifetime_change": {
        "routine": "Body_Tail",
        "old_mark_line": 26346, "old_release_finalizer_line": 26135,
        "new_statement_body_call_line": 26376,
        "new_body_tail_mark_or_release_calls": [row for row in new_sites if row["source_function"] == "body_tail" and row["operation"] in {"mark", "release"}],
        "finding": "The old Body_Tail per-iteration secondary mark/release pair disappeared. Completed sibling result allocations cannot be described as released at that former local scope. The old lifetime paragraph needs correction for final956eff."
    },
    "source_weight_applicability": {
        "token_charges": "Grammar, source4096/operator63 bounds and runtime source owners unchanged; prior12D+22L+12I+6C+2P<=4096 and B<=D+L token/count assumptions are unaffected by Static-only additions and control factoring.",
        "primary_local_bundles": "All listed recursive sums unchanged except Body_Tail416->368. Bare_Target ordinary-post frame grows240->256 and must be recorded as an extra16-byte helper leaf; exact all-route/nonrecursive allowance remains conditional. No stronger whole-primary bound follows.",
        "allocation_site_inventory": "All64 parser ss_allocate sites remain, with equal counts per source function. Condition procedure paths still add no secondary vector-return sites; Reading_Names still has no secondary calls.",
        "successful_allocation_count": "The prior S(B)*(4N+6L+9J+4E+3) count deliberately includes every successful-body allocation, including allocations formerly released. Its source/site counting assumptions remain applicable as a conditional total-payload overcount despite longer retention; do not reuse the old per-iteration release claim.",
        "limits": "The existing2,320,464 payload arithmetic is conditional on successful-parse site count/rounding. No allocator metadata, external pool/heap sufficiency, universal8MiB, malformed-prefix or exact total live-stack theorem is established."
    },
    "admission": {"record": record(NEW / "admission-summary.json"), "result": admission,
                  "binary_matches_current": admission["executable_sha256"] == digest((NEW / "bin/silver").read_bytes()),
                  "source_matches_current": admission["source_sha256"] == digest((NEW / "src/silver_output_profile.adb").read_bytes())},
    "shapes": {"record": record(shape_summaries[0]) if shapes else None,
               "run_id": shapes["run_id"] if shapes else None,
               "input_hashes_checked": len(shapes["inputs_sha256"]) if shapes else None,
               "input_mismatches": shape_mismatches,
               "stack_kib": shapes["stack_kib"] if shapes else None,
               "cases": len(shapes["results"]) if shapes else None,
               "all_expected_statuses": all(row["expected"] == row["status"] for row in shapes["results"]) if shapes else None,
               "admitted_4096": sum(row["bytes"] == 4096 and row["status"] == 0 for row in shapes["results"]) if shapes else None,
               "rejected_4097": sum(row["bytes"] == 4097 and row["status"] == 2 for row in shapes["results"]) if shapes else None},
}
(OUT / "fresh-frame-comparison.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"output": str(OUT / "fresh-frame-comparison.json"),
                  "recursive_deltas": [r for r in recursive_rows if r["old_sum"] != r["new_sum"]],
                  "named_deltas": named_deltas,
                  "allocation_site_counts_equal": old_allocs == new_allocs,
                  "old_secondary_calls": len(old_sites), "new_secondary_calls": len(new_sites),
                  "admission": admission, "shapes": result["shapes"]}, indent=2))
