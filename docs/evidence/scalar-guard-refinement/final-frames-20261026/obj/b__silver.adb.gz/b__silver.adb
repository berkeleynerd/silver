pragma Warnings (Off);
pragma Ada_95;
pragma Source_File_Name (ada_main, Spec_File_Name => "b__silver.ads");
pragma Source_File_Name (ada_main, Body_File_Name => "b__silver.adb");
pragma Suppress (Overflow_Check);
with Ada.Exceptions;

package body ada_main is

   E074 : Short_Integer; pragma Import (Ada, E074, "system__os_lib_E");
   E011 : Short_Integer; pragma Import (Ada, E011, "ada__exceptions_E");
   E015 : Short_Integer; pragma Import (Ada, E015, "system__soft_links_E");
   E024 : Short_Integer; pragma Import (Ada, E024, "system__exception_table_E");
   E037 : Short_Integer; pragma Import (Ada, E037, "ada__containers_E");
   E069 : Short_Integer; pragma Import (Ada, E069, "ada__io_exceptions_E");
   E053 : Short_Integer; pragma Import (Ada, E053, "ada__strings_E");
   E055 : Short_Integer; pragma Import (Ada, E055, "ada__strings__maps_E");
   E059 : Short_Integer; pragma Import (Ada, E059, "ada__strings__maps__constants_E");
   E042 : Short_Integer; pragma Import (Ada, E042, "interfaces__c_E");
   E025 : Short_Integer; pragma Import (Ada, E025, "system__exceptions_E");
   E087 : Short_Integer; pragma Import (Ada, E087, "system__object_reader_E");
   E048 : Short_Integer; pragma Import (Ada, E048, "system__dwarf_lines_E");
   E017 : Short_Integer; pragma Import (Ada, E017, "system__soft_links__initialize_E");
   E036 : Short_Integer; pragma Import (Ada, E036, "system__traceback__symbolic_E");
   E146 : Short_Integer; pragma Import (Ada, E146, "ada__assertions_E");
   E174 : Short_Integer; pragma Import (Ada, E174, "ada__numerics_E");
   E105 : Short_Integer; pragma Import (Ada, E105, "ada__strings__utf_encoding_E");
   E113 : Short_Integer; pragma Import (Ada, E113, "ada__tags_E");
   E103 : Short_Integer; pragma Import (Ada, E103, "ada__strings__text_buffers_E");
   E121 : Short_Integer; pragma Import (Ada, E121, "ada__streams_E");
   E137 : Short_Integer; pragma Import (Ada, E137, "system__file_control_block_E");
   E132 : Short_Integer; pragma Import (Ada, E132, "system__finalization_root_E");
   E130 : Short_Integer; pragma Import (Ada, E130, "ada__finalization_E");
   E129 : Short_Integer; pragma Import (Ada, E129, "system__file_io_E");
   E119 : Short_Integer; pragma Import (Ada, E119, "ada__text_io_E");
   E177 : Short_Integer; pragma Import (Ada, E177, "ada__numerics__big_numbers__big_integers_E");
   E171 : Short_Integer; pragma Import (Ada, E171, "silver_library_reports_E");
   E142 : Short_Integer; pragma Import (Ada, E142, "silver_numbers_E");
   E156 : Short_Integer; pragma Import (Ada, E156, "silver_length_intervals_E");
   E154 : Short_Integer; pragma Import (Ada, E154, "silver_profile_E");
   E152 : Short_Integer; pragma Import (Ada, E152, "silver_integer_literals_E");
   E161 : Short_Integer; pragma Import (Ada, E161, "silver_output_lexical_E");
   E159 : Short_Integer; pragma Import (Ada, E159, "silver_names_E");
   E201 : Short_Integer; pragma Import (Ada, E201, "silver_report_projection_types_E");
   E200 : Short_Integer; pragma Import (Ada, E200, "silver_report_projection_E");
   E202 : Short_Integer; pragma Import (Ada, E202, "silver_report_storage_E");
   E204 : Short_Integer; pragma Import (Ada, E204, "silver_reports_E");
   E193 : Short_Integer; pragma Import (Ada, E193, "silver_platform_E");
   E198 : Short_Integer; pragma Import (Ada, E198, "silver_report_reader_E");
   E169 : Short_Integer; pragma Import (Ada, E169, "silver_libraries_E");
   E165 : Short_Integer; pragma Import (Ada, E165, "silver_scalar_literals_E");
   E163 : Short_Integer; pragma Import (Ada, E163, "silver_scalar_expressions_E");
   E148 : Short_Integer; pragma Import (Ada, E148, "silver_output_profile_E");
   E140 : Short_Integer; pragma Import (Ada, E140, "silver_catalogue_E");

   Sec_Default_Sized_Stacks : array (1 .. 1) of aliased System.Secondary_Stack.SS_Stack (System.Parameters.Runtime_Default_Sec_Stack_Size);

   Local_Priority_Specific_Dispatching : constant String := "";
   Local_Interrupt_States : constant String := "";

   Is_Elaborated : Boolean := False;

   procedure finalize_library is
   begin
      E177 := E177 - 1;
      declare
         procedure F1;
         pragma Import (Ada, F1, "ada__numerics__big_numbers__big_integers__finalize_spec");
      begin
         F1;
      end;
      E119 := E119 - 1;
      declare
         procedure F2;
         pragma Import (Ada, F2, "ada__text_io__finalize_spec");
      begin
         F2;
      end;
      declare
         procedure F3;
         pragma Import (Ada, F3, "system__file_io__finalize_body");
      begin
         E129 := E129 - 1;
         F3;
      end;
      declare
         procedure Reraise_Library_Exception_If_Any;
            pragma Import (Ada, Reraise_Library_Exception_If_Any, "__gnat_reraise_library_exception_if_any");
      begin
         Reraise_Library_Exception_If_Any;
      end;
   end finalize_library;

   procedure adafinal is
      procedure s_stalib_adafinal;
      pragma Import (Ada, s_stalib_adafinal, "system__standard_library__adafinal");

      procedure Runtime_Finalize;
      pragma Import (C, Runtime_Finalize, "__gnat_runtime_finalize");

   begin
      if not Is_Elaborated then
         return;
      end if;
      Is_Elaborated := False;
      Runtime_Finalize;
      s_stalib_adafinal;
   end adafinal;

   type No_Param_Proc is access procedure;
   pragma Favor_Top_Level (No_Param_Proc);

   procedure adainit is
      Main_Priority : Integer;
      pragma Import (C, Main_Priority, "__gl_main_priority");
      Time_Slice_Value : Integer;
      pragma Import (C, Time_Slice_Value, "__gl_time_slice_val");
      WC_Encoding : Character;
      pragma Import (C, WC_Encoding, "__gl_wc_encoding");
      Locking_Policy : Character;
      pragma Import (C, Locking_Policy, "__gl_locking_policy");
      Queuing_Policy : Character;
      pragma Import (C, Queuing_Policy, "__gl_queuing_policy");
      Task_Dispatching_Policy : Character;
      pragma Import (C, Task_Dispatching_Policy, "__gl_task_dispatching_policy");
      Priority_Specific_Dispatching : System.Address;
      pragma Import (C, Priority_Specific_Dispatching, "__gl_priority_specific_dispatching");
      Num_Specific_Dispatching : Integer;
      pragma Import (C, Num_Specific_Dispatching, "__gl_num_specific_dispatching");
      Main_CPU : Integer;
      pragma Import (C, Main_CPU, "__gl_main_cpu");
      Interrupt_States : System.Address;
      pragma Import (C, Interrupt_States, "__gl_interrupt_states");
      Num_Interrupt_States : Integer;
      pragma Import (C, Num_Interrupt_States, "__gl_num_interrupt_states");
      Unreserve_All_Interrupts : Integer;
      pragma Import (C, Unreserve_All_Interrupts, "__gl_unreserve_all_interrupts");
      Detect_Blocking : Integer;
      pragma Import (C, Detect_Blocking, "__gl_detect_blocking");
      Default_Stack_Size : Integer;
      pragma Import (C, Default_Stack_Size, "__gl_default_stack_size");
      Default_Secondary_Stack_Size : System.Parameters.Size_Type;
      pragma Import (C, Default_Secondary_Stack_Size, "__gnat_default_ss_size");
      Bind_Env_Addr : System.Address;
      pragma Import (C, Bind_Env_Addr, "__gl_bind_env_addr");
      Interrupts_Default_To_System : Integer;
      pragma Import (C, Interrupts_Default_To_System, "__gl_interrupts_default_to_system");

      procedure Runtime_Initialize (Install_Handler : Integer);
      pragma Import (C, Runtime_Initialize, "__gnat_runtime_initialize");

      Finalize_Library_Objects : No_Param_Proc;
      pragma Import (C, Finalize_Library_Objects, "__gnat_finalize_library_objects");
      Binder_Sec_Stacks_Count : Natural;
      pragma Import (Ada, Binder_Sec_Stacks_Count, "__gnat_binder_ss_count");
      Default_Sized_SS_Pool : System.Address;
      pragma Import (Ada, Default_Sized_SS_Pool, "__gnat_default_ss_pool");

   begin
      if Is_Elaborated then
         return;
      end if;
      Is_Elaborated := True;
      Main_Priority := -1;
      Time_Slice_Value := -1;
      WC_Encoding := 'b';
      Locking_Policy := ' ';
      Queuing_Policy := ' ';
      Task_Dispatching_Policy := ' ';
      Priority_Specific_Dispatching :=
        Local_Priority_Specific_Dispatching'Address;
      Num_Specific_Dispatching := 0;
      Main_CPU := -1;
      Interrupt_States := Local_Interrupt_States'Address;
      Num_Interrupt_States := 0;
      Unreserve_All_Interrupts := 0;
      Detect_Blocking := 0;
      Default_Stack_Size := -1;

      ada_main'Elab_Body;
      Default_Secondary_Stack_Size := System.Parameters.Runtime_Default_Sec_Stack_Size;
      Binder_Sec_Stacks_Count := 1;
      Default_Sized_SS_Pool := Sec_Default_Sized_Stacks'Address;

      Runtime_Initialize (1);

      Finalize_Library_Objects := finalize_library'access;

      Ada.Exceptions'Elab_Spec;
      System.Soft_Links'Elab_Spec;
      System.Exception_Table'Elab_Body;
      E024 := E024 + 1;
      Ada.Containers'Elab_Spec;
      E037 := E037 + 1;
      Ada.Io_Exceptions'Elab_Spec;
      E069 := E069 + 1;
      Ada.Strings'Elab_Spec;
      E053 := E053 + 1;
      Ada.Strings.Maps'Elab_Spec;
      E055 := E055 + 1;
      Ada.Strings.Maps.Constants'Elab_Spec;
      E059 := E059 + 1;
      Interfaces.C'Elab_Spec;
      E042 := E042 + 1;
      System.Exceptions'Elab_Spec;
      E025 := E025 + 1;
      System.Object_Reader'Elab_Spec;
      E087 := E087 + 1;
      System.Dwarf_Lines'Elab_Spec;
      E048 := E048 + 1;
      System.Os_Lib'Elab_Body;
      E074 := E074 + 1;
      System.Soft_Links.Initialize'Elab_Body;
      E017 := E017 + 1;
      E015 := E015 + 1;
      System.Traceback.Symbolic'Elab_Body;
      E036 := E036 + 1;
      E011 := E011 + 1;
      Ada.Assertions'Elab_Spec;
      E146 := E146 + 1;
      Ada.Numerics'Elab_Spec;
      E174 := E174 + 1;
      Ada.Strings.Utf_Encoding'Elab_Spec;
      E105 := E105 + 1;
      Ada.Tags'Elab_Spec;
      Ada.Tags'Elab_Body;
      E113 := E113 + 1;
      Ada.Strings.Text_Buffers'Elab_Spec;
      E103 := E103 + 1;
      Ada.Streams'Elab_Spec;
      E121 := E121 + 1;
      System.File_Control_Block'Elab_Spec;
      E137 := E137 + 1;
      System.Finalization_Root'Elab_Spec;
      E132 := E132 + 1;
      Ada.Finalization'Elab_Spec;
      E130 := E130 + 1;
      System.File_Io'Elab_Body;
      E129 := E129 + 1;
      Ada.Text_Io'Elab_Spec;
      Ada.Text_Io'Elab_Body;
      E119 := E119 + 1;
      Ada.Numerics.Big_Numbers.Big_Integers'Elab_Spec;
      E177 := E177 + 1;
      E171 := E171 + 1;
      E142 := E142 + 1;
      E156 := E156 + 1;
      E154 := E154 + 1;
      E152 := E152 + 1;
      E161 := E161 + 1;
      E159 := E159 + 1;
      Silver_Report_Projection_Types'Elab_Spec;
      E201 := E201 + 1;
      Silver_Report_Projection'Elab_Spec;
      E200 := E200 + 1;
      Silver_Report_Storage'Elab_Spec;
      E202 := E202 + 1;
      E204 := E204 + 1;
      E193 := E193 + 1;
      E198 := E198 + 1;
      E169 := E169 + 1;
      E165 := E165 + 1;
      Silver_Scalar_Expressions'Elab_Spec;
      E163 := E163 + 1;
      Silver_Output_Profile'Elab_Body;
      E148 := E148 + 1;
      E140 := E140 + 1;
   end adainit;

   procedure Ada_Main_Program;
   pragma Import (Ada, Ada_Main_Program, "_ada_silver");

   function main
     (argc : Integer;
      argv : System.Address;
      envp : System.Address)
      return Integer
   is
      procedure Initialize (Addr : System.Address);
      pragma Import (C, Initialize, "__gnat_initialize");

      procedure Finalize;
      pragma Import (C, Finalize, "__gnat_finalize");
      SEH : aliased array (1 .. 2) of Integer;

      Ensure_Reference : aliased System.Address := Ada_Main_Program_Name'Address;
      pragma Volatile (Ensure_Reference);

   begin
      if gnat_argc = 0 then
         gnat_argc := argc;
         gnat_argv := argv;
      end if;
      gnat_envp := envp;

      Initialize (SEH'Address);
      adainit;
      Ada_Main_Program;
      adafinal;
      Finalize;
      return (gnat_exit_status);
   end;

--  BEGIN Object file/option list
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/containers-obj/spark.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/containers-obj/spark-big_integers.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_build.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_libc.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_library_reports.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_library_sources.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_numbers.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_path_facts.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_length_intervals.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_process_runtime.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_profile.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_integer_literals.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_output_lexical.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_names.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_report_projection_types.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_report_projection.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_report_storage.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_reports.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_runtime.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_platform.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_report_reader.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_libraries.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_scalar_literals.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_scalars.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_integer_image.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_scalar_expressions.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_output_profile.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver_catalogue.o
   --   /home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/silver.o
   --   -L/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/
   --   -L/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/obj/
   --   -L/home/canto/src/github.com/berkeleynerd/silver/tmp/guard-native-frames-final/containers-obj/
   --   -L/home/canto/src/github.com/berkeleynerd/silver/.tools/linux-x86_64/alire/toolchains/gnat_native_16.1.0_9f74f58a/lib/gcc/x86_64-pc-linux-gnu/16.1.0/adalib/
   --   -static
   --   -lgnat
   --   -ldl
--  END Object file/option list   

end ada_main;
