from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import resource
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root))
from scripts.platforms import native_layout
from scripts.run_history import ManagedRun

base = Path(__file__).resolve().parent
binary = base / 'bin/silver'
shapes = root / 'tmp/scalar-guard-refinement/tmp/guard-discovery/recognizer-shapes'
out = base / ('shape-results-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
inputs = [binary, base / 'retained/profile-before-flow-repairs.adb', Path(__file__),
          shapes / 'shapes.json', *sorted(shapes.glob('*.adb'))]
hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
records = []
def stack_limit():
    resource.setrlimit(resource.RLIMIT_STACK, (8192*1024, 8192*1024))

with ManagedRun(native_layout(root), 'guard-recognizer-shapes', [sys.executable, str(Path(__file__))],
                {'scope': ['actual-parser-4096-4097-shapes'], 'sha256': hashes, 'stack_kib': 8192},
                [out], workers=1, task='#238', evidence=[out]) as run:
    out.mkdir()
    for source in sorted(shapes.glob('*.adb')):
        start = time.monotonic()
        command = [str(binary), 'check', str(source)]
        expected = 2 if source.stem.endswith('-4097') else 0
        try:
            result = subprocess.run(command, capture_output=True, timeout=120,
                                    preexec_fn=stack_limit, pass_fds=run.pass_fds)
            status = result.returncode
            (out / (source.stem+'.stdout')).write_bytes(result.stdout)
            (out / (source.stem+'.stderr')).write_bytes(result.stderr)
        except subprocess.TimeoutExpired as error:
            status = 'timeout'
            (out / (source.stem+'.stdout')).write_bytes(error.stdout or b'')
            (out / (source.stem+'.stderr')).write_bytes(error.stderr or b'')
        record = {'source': str(source), 'command': command, 'bytes': source.stat().st_size,
                  'expected': expected, 'status': status, 'elapsed_seconds': time.monotonic()-start}
        records.append(record)
        print(json.dumps(record), flush=True)
    assert all(hashlib.sha256(p.read_bytes()).hexdigest() == hashes[str(p)] for p in inputs)
    summary = {'run_id': run.run_id, 'inputs_sha256': hashes, 'stack_kib': 8192, 'results': records,
               'limitations': 'Actual recognizer shape observations; not universal stack sufficiency or application proof.'}
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    failed = [r['source'] for r in records if r['expected'] != r['status']]
    run.finish('failure' if failed else 'success', returncode=int(bool(failed)), failure_keys=failed)
print(out)
sys.exit(bool(failed))
