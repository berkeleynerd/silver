# Relation equality across the update/branch join — 2026-10-26

Owner-authorized #234/#238; selected GPT-6 Astra at Extra High. Runtime settings,
token/cost measurements are unexposed. Observed-clock design/evidence interval:
08:34:44–08:38:26 UTC (222 seconds), excluding final report preparation. This
subthread ran no validator and edited only proposal/evidence files in its owned
scratch directory. The lead remains sole runner and integration author.

## New evidence closes the local-update question

Run `20261026T081952-e61f3ae59ff9`, profile SHA-256
`ee82dcbf34dbfb349437e2e96e809639880f9f6b8950e5085eec2793a05b18c8`,
checked region 2145–2150 in 652.285 seconds. The new early assertion at **2146**
proved with Z3 in **3.46343 seconds**, and every false-write index/range check and
model precondition passed. The retained equality at **2150:18** alone failed;
CVC5, Z3 and Alt-Ergo each reached 30 seconds. The exact retained records are
extracted in `relation-true-join-diagnostic.json`.

The early equality establishes the nonzero indexed update directly. The remaining
joined obligation also includes preservation through the false write and the
zero-target arm. The retained proof report does not distinguish these cases.
Generated Why AST inspection confirms both Ada equalities are encoded as
`Silver_output_profile__scalar_flow.bool_eq`, whereas the false write rebuilds
`condition_result.__split_fields` by updating only `when_false`. Exact generated
input hash and inspected node IDs/field names are in the diagnostic JSON.
This establishes the translation shape; it does not prove which case or solver
heuristic causes the remaining timeout.

## Proposal: supply the proved logical relation in both arms

Keep the newly proved early equality and immediately invoke the already proved:

```ada
Lemma_Flow_Equality
  (Result.When_True, Refined_Flow (Facts, Target, Selected, Threshold, True));
```

Its precondition is precisely that early Ada equality. Its postcondition is
`Same_Flow`, whose checked Logical_Equal annotation makes actual logical equality
available before the record-fields rebuild. The false write changes no true-flow
component or model argument, so that logical equality should transport directly.

Add an `else` arm containing only a Static assertion of the same equality and the
same ghost bridge. In that arm Target = 0, `When_True` is still its initialized
Facts value, and `Refined_Flow`'s zero case is Facts. The assertion is an obligation
to prove that copy/model equality; it is not an assumption. Both arms therefore
supply the same checked logical equality at the join. Keep the original failing
predefined-equality assertion and all following checks in place.

This is one bounded join repair with explicit branch coverage. It avoids asking
the joined VC to rediscover an uncut zero-arm equality at the same time as the
nonzero-arm frame fact. If the zero-arm assertion fails, the focused report will
identify that missing copy/model step separately. If both bridges and the zero
assertion pass but the old join still fails, inspect the record subtype/logical
conversion across the join before adding another proposal.

## Exact frozen deliverable and next check

`relation-true-join-profile.adb`, SHA-256:
`ec2f0a72dcbdcf1ff6dadc9fb8ec2975653a8c0c11db2bf3d53b7a5b8dec3a3d`.

- `relation-true-join-v18.patch` applies to the ee82 v17 source.
- `relation-true-join-from956eff.patch` applies to the unchanged canonical 956eff
  source and includes the previously proved early Static cut.
- Both patches passed `git apply --check` against separate private copies.
- `relation-true-join-manifest.json` records all exact hashes and selectors.

Next managed exploratory selector, at unchanged level 2/30-second settings:

```text
--limit-region=silver_output_profile.adb:2145:2157
```

This includes the retained early update assertion **2146**, new nonzero bridge
**2147**, false-write checks, new zero equality **2152**, zero bridge **2153**, and
retained failing join equality **2157**, including every new call precondition.
Replace the previous selector; do not run all of Read_Relation_Into to diagnose
this local problem. The lead coordinates worker/workspace availability and keeps
the active 956eff Lean source/cache intact.

## Preservation and remaining scope

Relative to ee82, the proposal adds one Static assertion, two Static ghost helper
calls, and a previously empty `else` arm containing only those proof statements.
It removes no line or check. It changes no executable assignment/condition,
function model, contract, input domain or prover setting. Removing precisely
these additions restores the full ee82 file byte-for-byte; generation checked
that identity. The new arm has no runtime statement, though it changes the source
shape and therefore still needs all applicable correspondence/binding updates.

No native success for this candidate is claimed. Focused success must be followed
by the lead's required complete native proof/audit and final source/Lean
correspondence checks. The failed v17 join is not reclassified as a success, and
conditional downstream v16 successes do not discharge it.
